/**
 * Première installation simplifiée (1.3.10, choix d'Amine) : prénom, nom et mot de passe seulement, puis entrée directe dans la plateforme.
 * Le reste (nom de l'hôtel, taxes, heures…) prend des valeurs par défaut, à compléter ensuite dans Administration / Paramètres.
 * Code de sécurité demandé seulement depuis un autre appareil que le PC serveur.
 */
import { useState } from 'react';
import { useI18n, type Key, type Lang } from '../i18n';
import { post } from '../lib/api';
import { useAuth } from '../lib/context';

/** Même règle que le serveur (identifiantDe) : « Karim Benali » → karim.benali ; sans lettre latine → admin. */
export function identifiantDe(prenom: string, nom: string): string {
  const net = (x: string) => x.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '');
  const id = [net(prenom), net(nom)].filter(Boolean).join('.').slice(0, 40);
  return id.length >= 3 ? id : 'admin';
}

export function Setup({ onDone, codeRequired = true }: { onDone: (username: string) => void; codeRequired?: boolean }) {
  const { t, lang, setLang } = useI18n();
  const { refresh } = useAuth();
  const s = (k: string) => t(`setup.${k}` as Key);
  const [f, setF] = useState({ code: '', first_name: '', last_name: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const id = identifiantDe(f.first_name, f.last_name);

  const installer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (codeRequired && f.code.trim().length < 6) { setErr(s('errCode')); return; }
    if (!f.first_name.trim() || !f.last_name.trim() || !f.password) { setErr(s('errSimple')); return; }
    setErr(''); setBusy(true);
    try {
      const r = await post('/api/setup', {
        ...(codeRequired ? { code: f.code.trim() } : {}),
        operations: { primary_language: lang },
        admin: { first_name: f.first_name.trim(), last_name: f.last_name.trim(), password: f.password },
      });
      // entrée directe : connexion automatique avec le compte qui vient d'être créé
      try {
        localStorage.setItem('kh.deviceName', localStorage.getItem('kh.deviceName') || 'Poste serveur');
        await post('/api/auth/login', { username: r.username, password: f.password, device_name: localStorage.getItem('kh.deviceName') });
        await refresh();
      } catch { onDone(r.username); }
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  return (
    <div className="login">
      <form className="login-card" style={{ width: 'min(440px, 100%)' }} onSubmit={installer}>
        <div className="row between">
          <div className="brand"><div className="brand-mark">K</div><div><div className="brand-name">KAYN Hotel</div><div className="brand-sub">{s('title')}</div></div></div>
          <div className="seg">{(['fr', 'ar', 'en'] as Lang[]).map((l) => <button type="button" key={l} className={lang === l ? 'on' : ''} onClick={() => setLang(l)}>{l === 'ar' ? 'ع' : l.toUpperCase()}</button>)}</div>
        </div>
        <p className="muted" style={{ margin: 0, fontSize: 13 }}>{s('hint_simple')}</p>
        {codeRequired && (
          <div className="field"><label htmlFor="s-code">{s('code')}</label>
            <input id="s-code" className="input" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value.toUpperCase() })} style={{ letterSpacing: 3, fontFamily: 'monospace', fontSize: 18 }} autoFocus />
            <span className="muted" style={{ fontSize: 12 }}>{s('hint_code')}</span>
          </div>
        )}
        <div className="field"><label htmlFor="s-prenom">{s('admin_first_name')}</label><input id="s-prenom" className="input" value={f.first_name} onChange={(e) => setF({ ...f, first_name: e.target.value })} autoComplete="given-name" autoFocus={!codeRequired} /></div>
        <div className="field"><label htmlFor="s-nom">{s('admin_last_name')}</label><input id="s-nom" className="input" value={f.last_name} onChange={(e) => setF({ ...f, last_name: e.target.value })} autoComplete="family-name" /></div>
        <div className="field"><label htmlFor="s-mdp">{s('admin_password')}</label><input id="s-mdp" className="input" type="password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} autoComplete="new-password" /></div>
        {(f.first_name || f.last_name) && <div className="alert info" style={{ fontSize: 13 }}>{s('yourId')} <b style={{ fontFamily: 'monospace' }}>{id}</b></div>}
        {err && <div className="alert danger" role="alert">{err}</div>}
        <button className="btn primary" type="submit" disabled={busy} style={{ minHeight: 44 }}>{busy ? s('installing') : s('enter')}</button>
      </form>
    </div>
  );
}
