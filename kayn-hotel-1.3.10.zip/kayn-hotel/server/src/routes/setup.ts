import { fileURLToPath } from 'node:url';
/**
 * Phase 15 — Assistant de première installation (base vide).
 * Tant qu'aucun hôtel n'existe, un code d'installation à usage unique est généré au démarrage du serveur : il est affiché
 * dans la console du serveur et écrit dans server/data/CODE-INSTALLATION.txt (accès physique au serveur requis).
 * L'assistant crée en une transaction : l'établissement, la devise et les taxes, les paramètres d'exploitation,
 * la caisse, les données de référence et le compte administrateur principal (mot de passe fort choisi par l'installateur).
 */
import type { FastifyInstance } from 'fastify';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { existsSync, mkdirSync, unlinkSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { z } from 'zod';
import { config } from '../config.js';
import { getPool, one, tx } from '../db/pool.js';
import { ensureHotelDefaults, syncRolesAndPermissions } from '../db/seed.js';
import { audit } from '../lib/audit.js';
import { hashPassword, sha256 } from '../lib/auth.js';
import { AppError, badRequest, conflict } from '../lib/errors.js';
import { currency as docCurrency } from '../services/exports.js';

const dataDir = () => fileURLToPath(new URL('../../data', import.meta.url));
const codeFile = () => path.join(dataDir(), 'CODE-INSTALLATION.txt');
let codeHash: string | null = null;
let attempts = 0;

/** Connexion venue du PC serveur lui-même : la personne est devant le serveur, le code de sécurité est inutile. */
const LOCAL = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1']);
export const fromServerPc = (req: { ip: string }) => LOCAL.has(req.ip);

export async function setupNeeded() {
  return !(await one(getPool(), 'SELECT 1 FROM hotels LIMIT 1'));
}
/** Appelé au démarrage : génère le code si la base est vide. */
export async function prepareSetup(log: (s: string) => void = console.log) {
  if (!(await setupNeeded())) { try { if (existsSync(codeFile())) unlinkSync(codeFile()); } catch { /* */ } return null; }
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const code = Array.from(randomBytes(8), (b) => alphabet[b % alphabet.length]).join('');
  codeHash = sha256(code);
  attempts = 0;
  try { if (!existsSync(dataDir())) mkdirSync(dataDir(), { recursive: true }); writeFileSync(codeFile(), `Code de sécurité KAYN Hotel : ${code}\nDemandé seulement si la première installation se fait depuis un autre appareil que le PC serveur.\nValable jusqu'à la première installation (un nouveau code est généré à chaque redémarrage).\n`); } catch { /* */ }
  log(`\n================ PREMIÈRE INSTALLATION ================\n  Sur le PC serveur, ouvrez http://localhost : aucun code demandé.\n  Depuis un autre appareil, code de sécurité : ${code}\n  (copie dans ${codeFile()})\n=======================================================\n`);
  return code;
}

const COMMON = ['password', 'motdepasse', 'azerty', 'qwerty', '123456', 'admin', 'kayn', 'hotel', 'bienvenue', 'welcome'];
/** Identifiant tiré du prénom et du nom : « Karim Benali » → karim.benali ; noms sans lettre latine (arabe) → admin. */
export function identifiantDe(prenom: string, nom: string): string {
  const net = (x: string) => x.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '');
  const id = [net(prenom), net(nom)].filter(Boolean).join('.').slice(0, 40);
  return id.length >= 3 ? id : 'admin';
}

export function strongPassword(pw: string, username: string): string | null {
  if (pw.length < 10) return 'Le mot de passe administrateur doit contenir au moins 10 caractères.';
  if (!/[a-z]/.test(pw) || !/[A-Z]/.test(pw) || !/\d/.test(pw)) return 'Le mot de passe administrateur doit contenir des minuscules, des majuscules et des chiffres.';
  const low = pw.toLowerCase();
  if (low.includes(username.toLowerCase()) || COMMON.some((w) => low.includes(w))) return 'Mot de passe trop prévisible : n\'utilisez ni l\'identifiant, ni un mot courant (admin, hotel, azerty…).';
  return null;
}

export async function setupRoutes(app: FastifyInstance) {
  app.get('/api/setup/status', async (req) => { const needed = await setupNeeded(); return { needed, code_required: needed && !fromServerPc(req) }; });

  app.post('/api/setup', { config: { rateLimit: { max: 10, timeWindow: '10 minutes' } } }, async (req) => {
    if (!(await setupNeeded())) throw conflict('KAYN Hotel est déjà installé.');
    // Installation simplifiée (1.3.10, choix d'Amine) : seuls prénom, nom et mot de passe sont demandés ; le reste prend des
    // valeurs par défaut, modifiables ensuite dans Administration / Paramètres. Les taux légaux ne sont jamais inventés : 0 = à saisir.
    const b = z.object({
      code: z.string().trim().max(20).optional().default(''),
      hotel: z.preprocess((v) => v ?? {}, z.object({
        name: z.string().trim().max(120).optional(), commercial_name: z.string().trim().max(120).optional(), address: z.string().trim().max(200).optional(),
        city: z.string().trim().max(80).optional(), country: z.string().trim().max(80).default('Algérie'), phone: z.string().trim().max(40).optional(), email: z.string().trim().max(120).optional(),
        nif: z.string().trim().max(40).optional(), nis: z.string().trim().max(40).optional(), rc: z.string().trim().max(40).optional(), art: z.string().trim().max(40).optional(),
        stars: z.number().int().min(0).max(5).nullish(),
      })),
      finance: z.preprocess((v) => v ?? {}, z.object({
        currency: z.string().trim().toUpperCase().regex(/^[A-Z]{3}$/).default('DZD'), currency_symbol: z.string().trim().min(1).max(6).default('DA'),
        vat_rate: z.number().min(0).max(100).default(0), room_vat: z.number().min(0).max(100).nullish(), restaurant_vat: z.number().min(0).max(100).nullish(), tourist_tax_per_adult_night: z.number().min(0).max(100000).default(0),
      })),
      operations: z.preprocess((v) => v ?? {}, z.object({
        check_in_time: z.string().regex(/^\d{2}:\d{2}$/).default('14:00'), check_out_time: z.string().regex(/^\d{2}:\d{2}$/).default('12:00'),
        timezone: z.string().max(60).refine((tz) => { try { new Intl.DateTimeFormat('fr', { timeZone: tz }); return true; } catch { return false; } }, 'Fuseau horaire inconnu').default('Africa/Algiers'),
        primary_language: z.enum(['fr', 'ar', 'en']).default('fr'), cash_register: z.string().trim().min(2).max(60).default('Caisse réception'),
      })),
      admin: z.object({
        first_name: z.string().trim().min(1, 'Prénom obligatoire').max(60), last_name: z.string().trim().min(1, 'Nom obligatoire').max(60), email: z.string().trim().max(120).optional(),
        username: z.string().trim().min(3).max(40).regex(/^[A-Za-z0-9._-]+$/, 'Identifiant : lettres, chiffres, . _ -').optional(), password: z.string().min(1, 'Mot de passe obligatoire').max(200),
      }),
    }).parse(req.body);
    const username = b.admin.username || identifiantDe(b.admin.first_name, b.admin.last_name);
    const hotelName = b.hotel.name || 'Mon hôtel';
    // code d'installation (accès physique au serveur) : comparaison à temps constant, 10 essais maximum par code
    // depuis le PC serveur : aucun code. Depuis un autre appareil : code de sécurité (accès physique au serveur), 10 essais par code.
    if (!fromServerPc(req)) {
      if (!codeHash) throw new AppError(503, 'setup_code', 'Code de sécurité non généré : redémarrez le PC serveur, ou faites l\'installation directement sur le PC serveur.');
      if (++attempts > 10) { codeHash = null; throw new AppError(429, 'setup_locked', 'Trop d\'essais : redémarrez le PC serveur pour obtenir un nouveau code, ou faites l\'installation directement sur le PC serveur.'); }
      if (b.code.length < 6) throw badRequest('Code de sécurité obligatoire depuis un autre appareil (fichier CODE-INSTALLATION.txt du PC serveur).');
      const given = Buffer.from(sha256(b.code.toUpperCase())), want = Buffer.from(codeHash);
      if (given.length !== want.length || !timingSafeEqual(given, want)) throw badRequest('Code de sécurité incorrect (fichier C:\\KAYN-Hotel\\app\\server\\data\\CODE-INSTALLATION.txt du PC serveur).');
    }

    const r = await tx(async (c) => {
      await c.query('SELECT pg_advisory_xact_lock(4207001)');
      if (await one(c, 'SELECT 1 FROM hotels LIMIT 1')) throw conflict('KAYN Hotel est déjà installé.');
      await syncRolesAndPermissions(c);
      const h = b.hotel;
      const hotel = await one<any>(c, `INSERT INTO hotels (name, commercial_name, address, city, country, phone, email, nif, nis, rc, art, stars, currency, currency_symbol, timezone, primary_language, languages)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,ARRAY['fr','ar','en']) RETURNING *`,
        [hotelName, h.commercial_name || null, h.address || null, h.city || null, h.country, h.phone || null, h.email || null, h.nif || null, h.nis || null, h.rc || null, h.art || null, h.stars ?? null,
          b.finance.currency, b.finance.currency_symbol, b.operations.timezone, b.operations.primary_language]);
      const taxRates: Record<string, number> = {};
      if (b.finance.room_vat !== null && b.finance.room_vat !== undefined) taxRates.room = b.finance.room_vat;
      if (b.finance.restaurant_vat !== null && b.finance.restaurant_vat !== undefined) { taxRates.restaurant = b.finance.restaurant_vat; taxRates.room_service = b.finance.restaurant_vat; taxRates.breakfast = b.finance.restaurant_vat; }
      const settings: Record<string, unknown> = {
        vat_rate: b.finance.vat_rate, tourist_tax_per_adult_night: b.finance.tourist_tax_per_adult_night, tax_rates: taxRates,
        check_in_time: b.operations.check_in_time, check_out_time: b.operations.check_out_time, default_guest_language: b.operations.primary_language,
        meal_supplements: { RO: 0, BB: 0, HB: 0, FB: 0 },
      };
      for (const [k, v] of Object.entries(settings)) await c.query('INSERT INTO settings (hotel_id, key, value) VALUES ($1,$2,$3)', [hotel.id, k, JSON.stringify(v)]);
      await ensureHotelDefaults(c, hotel.id);
      await c.query('INSERT INTO cash_registers (hotel_id, name) VALUES ($1,$2)', [hotel.id, b.operations.cash_register]);
      const role = await one<any>(c, `SELECT id FROM roles WHERE code = 'admin'`);
      const dept = await one<any>(c, `SELECT id FROM hr_departments WHERE hotel_id = $1 AND code = 'direction'`, [hotel.id]);
      const u = await one<any>(c, `INSERT INTO users (hotel_id, username, full_name, first_name, last_name, email, password_hash, role_id, department_id, must_change_password, protected, password_changed_at, language)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,false,true,now(),$10) RETURNING id`,
        [hotel.id, username, `${b.admin.first_name} ${b.admin.last_name}`, b.admin.first_name, b.admin.last_name, b.admin.email || null, await hashPassword(b.admin.password), role.id, dept?.id ?? null, b.operations.primary_language]);
      await audit(c, { userId: u.id, hotelId: hotel.id, ip: req.ip }, 'install', 'hotel', hotel.id, null, { hotel: hotelName, admin: username, currency: b.finance.currency });
      return { hotelId: hotel.id, username };
    });
    config.timezone = b.operations.timezone; docCurrency.tz = b.operations.timezone;
    docCurrency.symbol = b.finance.currency_symbol;
    codeHash = null;
    try { if (existsSync(codeFile())) unlinkSync(codeFile()); } catch { /* */ }
    return { ok: true, username: r.username };
  });
}
