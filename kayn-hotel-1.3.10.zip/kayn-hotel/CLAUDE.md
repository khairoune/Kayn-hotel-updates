# KAYN Hotel — contexte du projet

Document de référence pour toute personne (ou instance de Claude) qui reprend le projet. **À lire en premier, à tenir à jour à
chaque changement** (architecture, règle, procédure, état). Les choix datés sont dans [`docs/DECISIONS.md`](docs/DECISIONS.md).
Aucun secret ici : ni mot de passe, ni jeton, ni clé privée.

## 1. Le produit

- **KAYN Hotel** : logiciel de gestion hôtelière (PMS) **installé localement** dans l'hôtel, fonctionnant sans Internet au quotidien.
  Vendu par **KAYN Services** (Amine, Oran) en licence par hôtel + installation. Interface FR / AR (RTL) / EN, montants en DA.
- **Sans rapport** avec le secteur `hotel` de KAYN ERP (SaaS). La seule liaison avec KAYN ERP est la **console ERP HÔTEL**
  (erp-hotel.kaynservice.com) qui reçoit le signal des installations et délivre les licences (voir §5).
- Périmètre V1 : **un seul hôtel par installation**. Pas de channel manager, booking engine, multi-hôtels, SaaS ni paiement en ligne
  (règle de la phase 14 : ne pas les ajouter sans demande explicite).
- Pilote : **Hotel K** (venait de FANAC HOTEL System), en essai.
- Contact support sur tous les documents : Tél. / WhatsApp **0799 18 78 24**, **info@kaynservice.com**, www.kaynservice.com.

## 2. Architecture

| Partie | Techno | Dossier |
| --- | --- | --- |
| Serveur | Node.js 22 + Fastify + TypeScript, PostgreSQL 16 | `server/` (`src/routes`, `src/services`, `src/db/migrations`) |
| Interface | React + Vite, i18n maison | `web/` (`src/pages`, `src/i18n/index.tsx` = FR, AR, EN dans un seul fichier) |
| Installateur Windows | NSIS + `setup.cjs` | `installer/windows/`, `scripts/build-installer-windows.sh` |
| Mises à jour | zip + `latest.json` dans le dépôt public `khairoune/kayn-hotel-updates` | `scripts/release.sh`, `server/src/services/updates.ts` |

- Le serveur sert aussi l'interface compilée (`web/dist`) sur le port **8080** (démo : 8090, base `kayn_hotel_demo`).
- Aide intégrée : `web/src/lib/help.ts` (une fiche par écran, FR / AR) + vidéos `/aide/*.mp4`.
- Bouclier anti-robot : `server/src/services/shield.ts` (le PC serveur 127.0.0.1 n'est jamais bloqué).
- Variables d'environnement : `server/.env` (créé par l'installateur, ACL restreinte) — `DATABASE_URL`, `PORT`, `KAYN_UPDATE_URL`,
  `KAYN_UPDATE_TOKEN`, `KAYN_PING_URL`, `KAYN_LICENSE_PUBLIC_KEY` (facultatif, la clé publique est intégrée), `PG_BIN`…

## 3. Installation chez le client (Windows, depuis la 1.3.x)

- Un seul fichier **`KAYN-Hotel-Setup-<version>.exe`** (~110 Mo), hors ligne : contient Node, un PostgreSQL 16.15 officiel allégé et l'application.
- Installe dans `C:\KAYN-Hotel` (`app`, `node`, `postgresql`, `pgdata`) ; `setup.cjs` crée son propre cluster PostgreSQL (service
  `kayn-hotel-pg`, port libre à partir de 5433, mot de passe aléatoire dans `.env`), la tâche planifiée **« KAYN Hotel »** (SYSTÈME, au
  démarrage, relance si arrêt), désactive la veille, ouvre le pare-feu, crée le raccourci du bureau, ouvre `http://localhost:8080`.
- Réinstaller / mettre à jour par-dessus garde `server\.env` et `server\data`. La désinstallation garde les données.
- Journal : `C:\KAYN-Hotel\installation.log`. Mode silencieux `/S` (sans navigateur).
- **Première installation** (depuis 1.3.10, choix d'Amine) : un seul écran — prénom, nom, mot de passe (**aucune règle de force**, seulement
  non vide) → compte administrateur, identifiant `prénom.nom` (`identifiantDe`, sans lettre latine → `admin`), connexion automatique.
  Le reste prend des valeurs par défaut (« Mon hôtel », DZD / DA, TVA et taxe de séjour à 0 = à saisir, 14:00 / 12:00, Africa/Algiers),
  à compléter dans Administration. L'API accepte toujours l'envoi complet (hôtel, finance, exploitation). Depuis le PC serveur (loopback)
  **aucun code** ; depuis un autre appareil, **code de sécurité** de `server\data\CODE-INSTALLATION.txt` (10 essais).
- Anciens scripts `.bat` (1-INSTALLER, 2-DEMARRER…) conservés **sans modification** pour les installations d'avant le Setup.
- Le Setup est construit et testé sur un vrai Windows par **GitHub Actions** (`.github/workflows/setup-windows.yml`, à chaque envoi sur
  `master`) ; on le récupère dans « Artifacts » de l'exécution (non téléchargeable depuis l'environnement de Claude).
- Guides PDF client : guide d'installation (3 étapes, 4 écrans) et guide d'utilisation des modules — sources HTML hors dépôt, à refaire
  si l'installation change. Le Setup n'est pas signé : avertissement SmartScreen (« Informations complémentaires → Exécuter quand même »).

## 4. Règles à ne jamais enfreindre

1. **Ne jamais supprimer ni remplacer le secret Vault `kh_licence_cle`** (projet Supabase de KAYN ERP) : c'est la clé privée Ed25519 qui
   signe les licences ; tous les hôtels installés refuseraient les nouveaux jetons. Ne jamais lire la clé privée (ni dans le contexte, ni
   dans un journal). Clé publique intégrée dans `server/src/services/license.ts`.
2. Mots de passe, jetons et secrets : jamais dans les journaux, jamais en clair en base ni à l'écran.
3. Ne jamais écraser une base existante sans confirmation explicite ; une sauvegarde n'est « réussie » qu'une fois le fichier créé et vérifié.
4. Un changement de taux de taxe ne modifie jamais les factures historiques. Rien ne s'efface : avoir ou annulation motivée.
5. Cartes bancaires : 4 derniers chiffres seulement. Taux légaux (TVA, taxe de séjour, IRG…) : **ne jamais les inventer**, c'est l'hôtel
   ou son comptable qui les saisit.
6. Tests destructifs uniquement sur des bases séparées ; ne jamais déclarer un test réussi sans l'avoir lancé.
7. La **source des mises à jour est confidentielle** : jamais affichée dans le logiciel ni renvoyée par l'API.
8. Chaque version publiée dit **pourquoi** : notes « Pourquoi cette mise à jour : … ».
9. **Ne rien pousser sur GitHub ni publier une mise à jour sans le feu vert d'Amine** (« pousse », « publie »). Regrouper les changements.
10. Réponses à Amine : courtes, en français, avec à chaque fois une critique, des questions et des idées. Ne jamais proposer n8n.

## 5. Licence et console (depuis 1.3.7)

- Signal quotidien (horaire si suspendu) vers la fonction Edge `kayn-hotel-ping` (KAYN ERP) : identifiant d'installation + secret
  (empreinte seule côté serveur), compteurs, version, PC — **jamais de données clients**.
- Réponse = **jeton JSON signé Ed25519** `{install, plan essai|client, status, message, expires, warn_days, block_days, …}` ; réponse non
  signée ignorée ; horloge reculée détectée (`license_clock.max`).
- Essai : **30 jours** après la première mise en service, prolongeable depuis la console ; sans signal : avertissement à 7 jours, blocage à
  15 jours (« Connectez le PC à Internet »), levé dès la reconnexion. Clients : délais et échéance réglés par hôtel dans la console ;
  rappel 15 jours avant l'échéance.
- Hôtel sans Internet : code d'activation `KH1-…` (charge utile 12 octets + signature, base32 sans I/O/0/1), lié au code de licence du PC
  (8 caractères, Administration → Licence), généré par la fonction Edge `kayn-hotel-licence` depuis la console.
- Console : KAYN ERP, `src/hotel/ConsoleHotel.jsx`, migrations 187 / 188 / 189 / 197 (voir CLAUDE.md de KAYN ERP §4 octies-quinquies) ;
  alertes Telegram « KAYN Hotel — alertes » (installation, autre PC, résumé du matin).

## 6. Procédures

**Tests** (environnement de Claude) :
```
bash /tmp/pgup.sh            # démarre PostgreSQL 16 local (script de l'environnement, à recréer si absent)
cd server && npx tsc --noEmit -p . && npx tsx --test --test-concurrency=1 test/*.test.ts
cd web && npx tsc --noEmit -p .
```
175 tests au 2026-11-18. Les tests ne doivent pas dépendre du jour de la semaine (cf. correctif tarifs du 2026-11-15).

**Publier une version** (seulement après « publie ») :
1. Monter la version dans `package.json`, `server/package.json`, `web/package.json`, `package-lock.json` ; commit + `git -c push.negotiate=true push`.
2. `bash scripts/release.sh "Pourquoi cette mise à jour : …"` → `release/kayn-hotel-<v>.zip` + `release/latest.json`.
3. Copier les deux fichiers dans le clone de `kayn-hotel-updates`, `git rm` l'ancien zip, commit (auteur « KAYN Services »
   <noreply@kaynservice.com>), push. Les hôtels voient la mise à jour dans la cloche (administrateurs) et l'installent au clic.
4. Vérifier que l'exécution « Setup Windows » de GitHub Actions est verte, donner à Amine le lien de l'exécution.

Commits : messages en français, raison du changement, lignes d'attribution demandées par l'environnement.

## 7. État et reste à faire (au 2026-11-15)

- **1.3.10 prête, non publiée** : installation en un écran (prénom, nom, mot de passe), entrée directe. Versions : **1.3.8** (assistant sans code sur le PC serveur) ; **1.3.9 publiée** : connexion par identifiant, e-mail ou téléphone (`findLoginUser`, `server/src/routes/auth.ts` ; téléphone accepté seulement s'il désigne un seul compte, 9 derniers chiffres).
- À faire : haute disponibilité H1 / H2 (réplication, bascule auto après 2 min, retour manuel, protection split-brain) ; installateur
  Linux puis Mac ; page de téléchargement publique du Setup ; certificat de signature de code (SmartScreen) ; passage d'Hotel K en client
  (date d'échéance à fixer) ; délais sans Internet par défaut des clients à décider ; captures des guides à refaire (écrans de licence).
- `docs/INSTALLATION-ET-EXPLOITATION.md` et le README décrivent encore l'installation par `.bat` : à réécrire pour le Setup.
