# Journal des décisions — KAYN Hotel

Une ligne par décision, la plus récente en haut : date, décision, qui l'a prise, pourquoi. Une décision écrite ici n'est pas
remise en cause sans qu'Amine le demande. À compléter à chaque nouveau choix (règle d'Amine du 2026-11-15, valable pour tous ses projets).

| Date | Décision | Par | Pourquoi |
| --- | --- | --- | --- |
| 2026-11-16 | Connexion avec l'identifiant, l'adresse e-mail ou le téléphone (e-mail unique, téléphone seulement s'il désigne un seul compte) | Amine | Un administrateur a tapé son e-mail à la place de l'identifiant et ne pouvait pas se connecter |
| 2026-11-15 | Chaque dépôt a un `CLAUDE.md` et ce journal des décisions, tenus à jour | Amine | Reprise sans perte de contexte par une nouvelle instance de Claude |
| 2026-11-15 | 1.3.8 : aucun code à la première installation sur le PC serveur ; « code de sécurité » seulement depuis un autre appareil | Amine | Le client ne trouvait pas le code (fichier caché) ; même nom que le code de licence |
| 2026-11-15 | Deux guides PDF client séparés : installation, et utilisation des modules | Amine | Documents distincts selon le besoin |
| 2026-11-15 | Résumé Telegram du matin des licences (essais finissants, échéances, sans signal) | Amine | Suivi sans ouvrir la console |
| 2026-11-14 | Licence : essai 30 jours prolongeable ; prospects avertis à 7 jours et bloqués à 15 jours sans signal ; clients réglés par hôtel ; échéance par hôtel ; codes d'activation expirables ; liaison signée non contournable | Amine | Contrôle des installations, y compris sans Internet |
| 2026-11-13 | Installateur unique `Setup.exe` hors ligne (Node + PostgreSQL inclus), le client installe seul ; Windows d'abord, Linux et Mac ensuite | Amine | Installation sans technicien |
| 2026-11-13 | Anciens fichiers `.bat` gardés sans modification | Amine | Hôtels déjà installés par cette méthode |
| 2026-11-13 | Console de suivi des installations dans KAYN ERP, espace séparé « ERP HÔTEL » (pas dans PNR) | Amine | Un seul système de pilotage |
| 2026-11-13 | Alerte Telegram à chaque nouvelle installation ou autre PC détecté (groupe « KAYN Hotel — alertes ») | Amine | Détecter les copies et les nouveaux clients |
| 2026-11-13 | Mises à jour : dépôt public `kayn-hotel-updates`, installées seulement au clic de l'administrateur (pas la nuit) ; source confidentielle ; notes « pourquoi » obligatoires | Amine | Contrôle du moment de l'interruption ; confidentialité |
| 2026-11-13 | Code source dans le dépôt privé `khairoune/kayn-hotel` | Amine | Protection du code |
| 2026-11 | V1 : un seul hôtel par installation, pas de channel manager, booking engine, multi-hôtels, SaaS ni abonnements | Amine | Périmètre de la V1 |
| 2026-11 | Logiciel local hors ligne (serveur Windows de l'hôtel, navigateur sur le réseau local, PostgreSQL), interface AR / FR / EN, approbation de chaque poste | Amine | Internet intermittent dans les hôtels ; données gardées à l'hôtel |
| 2026-11 | Haute disponibilité H1 / H2 avec bascule automatique : prévue, pas encore faite | Amine | Continuité de service |
