import { useEffect, useState, type ReactNode } from 'react';
import { useI18n } from '../i18n';

type Lic = {
  state: 'ok' | 'warning' | 'blocked'; reason: string | null; message: string | null; plan: string | null; expires: string | null;
  days_offline: number | null; days_left: number | null; install_code: string | null; checked_at: string | null;
};

/** Licence : écran de blocage (suspension, fin d'essai, échéance, trop longtemps sans Internet) et bandeau d'avertissement.
 *  Les données restent intactes. Code d'activation possible pour un PC sans Internet. */
export function LicenseGate({ children }: { children: ReactNode }) {
  const { t } = useI18n();
  const [lic, setLic] = useState<Lic | null>(null);
  const [busy, setBusy] = useState(false);
  const [code, setCode] = useState('');
  const [err, setErr] = useState('');
  const [hide, setHide] = useState(() => sessionStorage.getItem('kh.licWarn') === '1');
  const load = () => fetch('/api/license', { credentials: 'same-origin' }).then((r) => r.json()).then(setLic).catch(() => {});
  useEffect(() => {
    load();
    const i = setInterval(load, 5 * 60_000);
    const on = () => load();
    window.addEventListener('kh-license', on);
    return () => { clearInterval(i); window.removeEventListener('kh-license', on); };
  }, []);
  const check = async () => {
    setBusy(true); setErr('');
    try { const r = await fetch('/api/license/check', { method: 'POST', credentials: 'same-origin', headers: { 'x-kayn-client': 'web' } }); const j = await r.json(); if (j.state) setLic(j); if (j.state !== 'blocked' && lic?.state === 'blocked') window.location.reload(); } catch { /* */ }
    finally { setBusy(false); }
  };
  const activate = async () => {
    setBusy(true); setErr('');
    try {
      const r = await fetch('/api/license/activate', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', 'x-kayn-client': 'web' }, body: JSON.stringify({ code }) });
      const j = await r.json();
      if (!r.ok) { setErr(j.message || 'Code refusé.'); return; }
      setLic(j); setCode('');
      if (j.state !== 'blocked') window.location.reload();
    } catch { setErr('…'); } finally { setBusy(false); }
  };
  const fill = (s: string) => s.replace('{n}', String(lic?.days_offline ?? '')).replace('{d}', String(Math.max(0, lic?.days_left ?? 0)));
  const codeBox = (
    <div style={{ marginTop: 14, textAlign: 'start' }}>
      <textarea className="input" rows={3} dir="ltr" placeholder="KH1-…" value={code} onChange={(e) => setCode(e.target.value)} style={{ width: '100%', fontFamily: 'monospace', fontSize: 13 }} />
      {err && <div style={{ color: '#FCA5A5', fontSize: 13, marginTop: 6 }}>{err}</div>}
      <button className="btn" disabled={busy || code.trim().length < 20} onClick={activate} style={{ marginTop: 8, background: '#fff', color: '#2a0b10', border: 0, fontWeight: 700 }}>{busy ? '…' : t('lic.code_btn')}</button>
    </div>
  );

  if (lic?.state === 'blocked') {
    const title = t(({ suspended: 'lic.t_suspended', trial_ended: 'lic.t_trial_ended', expired: 'lic.t_expired', offline: 'lic.t_offline' } as const)[lic.reason as 'suspended'] ?? 'lic.title');
    return (
      <div style={{ position: 'fixed', inset: 0, background: 'linear-gradient(160deg,#5C1720,#7A1F2B)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, zIndex: 9999, overflow: 'auto' }}>
        <div style={{ maxWidth: 540, textAlign: 'center' }}>
          <div style={{ width: 64, height: 64, borderRadius: 16, background: '#fff', color: '#7A1F2B', font: '800 34px Inter, sans-serif', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>K</div>
          <h1 style={{ color: '#C9A227', margin: '18px 0 8px' }}>{title}</h1>
          <p style={{ fontSize: 17, lineHeight: 1.5 }}>{lic.reason === 'offline' ? t('lic.m_offline') : (lic.message || t('lic.default'))}</p>
          <p style={{ opacity: 0.8, fontSize: 14 }}>{t('lic.data')}</p>
          <button className="btn" style={{ marginTop: 6, background: '#C9A227', color: '#2a0b10', border: 0, fontWeight: 700 }} disabled={busy} onClick={check}>{busy ? '…' : t('lic.check')}</button>
          {lic.reason !== 'suspended' && <div style={{ marginTop: 22, padding: 14, borderRadius: 12, background: 'rgba(0,0,0,.18)' }}>
            <div style={{ fontSize: 13, opacity: 0.85 }}>{t('lic.offline_hint')}</div>
            <div style={{ marginTop: 8, fontSize: 13 }}>{t('lic.install')} : <b dir="ltr" style={{ fontFamily: 'monospace', fontSize: 18, letterSpacing: 2 }}>{lic.install_code}</b></div>
            {codeBox}
          </div>}
          <p style={{ marginTop: 18, fontSize: 13, opacity: 0.85 }}>{t('lic.contact')}</p>
        </div>
      </div>
    );
  }
  const warnText = lic?.state === 'warning'
    ? fill(t(lic.reason === 'offline_soon' ? 'lic.w_offline_soon' : lic.plan === 'essai' ? 'lic.w_trial_soon' : 'lic.w_paid_soon'))
    : null;
  return (
    <>
      {warnText && !hide && (
        <div role="alert" style={{ position: 'sticky', top: 0, zIndex: 9000, background: '#FEF3C7', color: '#78350F', borderBottom: '1px solid #F59E0B', padding: '8px 14px', display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap', fontSize: 14 }}>
          <span style={{ flex: 1, minWidth: 200 }}>⚠ {warnText} <span style={{ opacity: 0.8 }}>{t('lic.contact')}</span></span>
          <button className="btn" disabled={busy} onClick={check}>{busy ? '…' : t('lic.check')}</button>
          <button className="btn" onClick={() => { sessionStorage.setItem('kh.licWarn', '1'); setHide(true); }}>✕</button>
        </div>
      )}
      {children}
    </>
  );
}

/** Saisie d'un code d'activation depuis Administration (PC sans Internet). */
export function ActivationCodeForm({ onDone }: { onDone?: () => void }) {
  const { t } = useI18n();
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true); setMsg(null);
    try {
      const r = await fetch('/api/license/activate', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', 'x-kayn-client': 'web' }, body: JSON.stringify({ code }) });
      const j = await r.json();
      if (!r.ok) setMsg({ ok: false, text: j.message || 'Code refusé.' }); else { setMsg({ ok: true, text: t('lic.code_ok') }); setCode(''); onDone?.(); window.dispatchEvent(new CustomEvent('kh-license')); }
    } catch { setMsg({ ok: false, text: '…' }); } finally { setBusy(false); }
  };
  return (
    <div style={{ marginTop: 10 }}>
      <textarea className="input" rows={3} dir="ltr" placeholder="KH1-…" value={code} onChange={(e) => setCode(e.target.value)} style={{ width: '100%', fontFamily: 'monospace', fontSize: 13 }} />
      <div className="row" style={{ gap: 8, marginTop: 6, alignItems: 'center' }}>
        <button className="btn primary" disabled={busy || code.trim().length < 20} onClick={go}>{busy ? '…' : t('lic.code_btn')}</button>
        {msg && <span style={{ color: msg.ok ? '#15803D' : '#B91C1C', fontSize: 13 }}>{msg.text}</span>}
      </div>
    </div>
  );
}
