/**
 * Licence KAYN Hotel + signal d'assistance KAYN Services.
 *
 * Signal (une fois par jour, toutes les heures en cas d'alerte ou de blocage) : nom, ville et téléphone de l'hôtel, mode,
 * version, nom du PC, nombre de chambres, d'utilisateurs actifs, de réservations et de connexions du mois.
 * JAMAIS de données clients, de montants ni de mots de passe.
 *
 * En retour, la console ERP HÔTEL envoie un JETON DE LICENCE SIGNÉ (Ed25519) : formule (essai / client), statut, date de fin
 * (fin d'essai ou « payé jusqu'au »), délais sans signal (avertissement / blocage). Seule la clé publique est dans ce logiciel :
 * un jeton modifié ou fabriqué est refusé, et il ne vaut que pour CETTE installation.
 * Sans Internet : code d'activation (signé de même, lié à l'installation, à saisir avant sa date limite) généré dans la console.
 * Retour en arrière de l'horloge du PC : la date la plus récente déjà vue est retenue.
 *
 * Règles :
 *  - aucun jeton (jamais connecté) : avertissement après 7 jours, blocage après 15 jours « Connectez le PC à Internet » ;
 *  - jeton de signal : avertissement / blocage selon les délais du jeton (essai 7 / 15 j, client : réglage de la console) ;
 *    le blocage hors ligne s'arrête dès que le PC se reconnecte (nouveau jeton) ;
 *  - date de fin dépassée : bloqué (fin d'essai / licence expirée) ; rappel 15 jours avant ;
 *  - suspension par KAYN Services : bloqué avec le message de la console.
 * Les données ne sont jamais touchées : seul l'accès au logiciel est bloqué.
 */
import { createPublicKey, randomBytes, randomUUID, verify } from 'node:crypto';
import os from 'node:os';
import { getPool, one } from '../db/pool.js';
import { APP_VERSION } from './updates.js';

const pingUrl = () => process.env.KAYN_PING_URL ?? 'https://gdvyymfqeqllsebrbtjm.supabase.co/functions/v1/kayn-hotel-ping';
const PUBLIC_KEY = createPublicKey(process.env.KAYN_LICENSE_PUBLIC_KEY ?? `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAoX6jwCoW9dFivwPKh5TvCnYWhNToW6HBfHu3jI1/DX0=
-----END PUBLIC KEY-----`);
const DAY = 86_400_000;
const NO_TOKEN = { warn: 7, block: 15 };
const EXPIRY_NOTICE_DAYS = 15;

export type Token = {
  v: 1; install: string; plan: 'essai' | 'client'; status: 'active' | 'suspended'; message?: string | null;
  expires?: string | null; warn_days?: number | null; block_days?: number | null; issued_at: string; source: 'ping' | 'code';
};
export type LicState = {
  state: 'ok' | 'warning' | 'blocked';
  reason: null | 'suspended' | 'trial_ended' | 'expired' | 'offline' | 'offline_soon' | 'expires_soon';
  message: string | null; plan: 'essai' | 'client' | null; expires: string | null;
  days_offline: number | null; days_left: number | null; install_code: string | null; checked_at: string | null; source: string | null;
};

let token: Token | null = null;
let install: { id: string; secret: string; first_run: string } | null = null;
let maxSeen = 0;
let lastPingAt: string | null = null;
let loaded = false;

async function getSetting(hotelId: number, key: string) {
  return (await one<any>(getPool(), 'SELECT value FROM settings WHERE hotel_id = $1 AND key = $2', [hotelId, key]))?.value ?? null;
}
async function setSetting(hotelId: number, key: string, v: unknown) {
  await getPool().query(`INSERT INTO settings (hotel_id, key, value) VALUES ($1,$2,$3) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`, [hotelId, key, JSON.stringify(v)]);
}
const firstHotel = () => one<any>(getPool(), 'SELECT id FROM hotels ORDER BY id LIMIT 1').catch(() => null);

/** Code court de l'installation (8 caractères, à lire au téléphone) : début de l'identifiant. */
export const installCode = (id: string) => id.replace(/-/g, '').slice(0, 8).toUpperCase().replace(/^(.{4})/, '$1-');

/** Vérifie un jeton signé { p: base64(JSON), s: base64(signature) } ; renvoie le contenu ou null. */
export function verifyToken(t: any, installId: string): Token | null {
  try {
    if (!t || typeof t.p !== 'string' || typeof t.s !== 'string') return null;
    const raw = Buffer.from(t.p, 'base64');
    if (!verify(null, raw, PUBLIC_KEY, Buffer.from(t.s, 'base64'))) return null;
    const j = JSON.parse(raw.toString('utf8'));
    if (j?.v !== 1 || j.install !== installId || isNaN(Date.parse(j.issued_at))) return null;
    return j as Token;
  } catch { return null; }
}

// ===== Codes d'activation (hors ligne) =====
// 12 octets : version | code d'installation (4) | valable jusqu'au (jours, 2) | licence jusqu'au (jours, 2) | formule | aléa (2)
// + signature Ed25519 (64), en base32 par groupes de 5 : KH1-XXXXX-XXXXX-…
const B32 = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const EPOCH = Date.UTC(2026, 0, 1);
function b32decode(s: string) {
  const clean = s.toUpperCase().replace(/^KH1/, '').replace(/[^A-Z2-9]/g, '');
  let bits = 0; let val = 0; const out: number[] = [];
  for (const ch of clean) { const i = B32.indexOf(ch); if (i < 0) return null; val = (val << 5) | i; bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(out);
}
export function decodeActivationCode(code: string, installId: string, now = Date.now()): { ok: true; token: Token } | { ok: false; error: string } {
  const b = b32decode(code);
  if (!b || b.length < 76) return { ok: false, error: 'code_invalid' };
  const data = b.subarray(0, 12); const sig = b.subarray(12, 76);
  let good = false; try { good = verify(null, data, PUBLIC_KEY, sig); } catch { good = false; }
  if (!good || data[0] !== 1) return { ok: false, error: 'code_invalid' };
  if (data.subarray(1, 5).toString('hex') !== installId.replace(/-/g, '').slice(0, 8).toLowerCase()) return { ok: false, error: 'code_other_install' };
  const validUntil = EPOCH + data.readUInt16BE(5) * DAY + DAY - 1;
  const grants = EPOCH + data.readUInt16BE(7) * DAY + DAY - 1;
  if (now > validUntil) return { ok: false, error: 'code_expired' };
  return { ok: true, token: { v: 1, install: installId, plan: data[9] === 1 ? 'client' : 'essai', status: 'active', message: null, expires: new Date(grants).toISOString(), warn_days: null, block_days: null, issued_at: new Date(now).toISOString(), source: 'code' } };
}

// ===== État =====
function nowSafe() {
  const n = Date.now();
  return Math.max(n, maxSeen); // horloge reculée : la date la plus récente déjà vue fait foi
}
export function computeState(tk: Token | null, firstRun: string | null, now: number): Omit<LicState, 'install_code' | 'checked_at'> {
  const base = { plan: tk?.plan ?? null, expires: tk?.expires ?? null, message: null as string | null, days_offline: null as number | null, days_left: null as number | null, source: tk?.source ?? null };
  if (!tk) {
    const days = firstRun ? Math.floor((now - Date.parse(firstRun)) / DAY) : 0;
    if (days >= NO_TOKEN.block) return { ...base, state: 'blocked', reason: 'offline', days_offline: days };
    if (days >= NO_TOKEN.warn) return { ...base, state: 'warning', reason: 'offline_soon', days_offline: days, days_left: NO_TOKEN.block - days };
    return { ...base, state: 'ok', reason: null, days_offline: days };
  }
  if (tk.status === 'suspended') return { ...base, state: 'blocked', reason: 'suspended', message: tk.message ?? null };
  if (tk.expires && now > Date.parse(tk.expires)) return { ...base, state: 'blocked', reason: tk.plan === 'essai' ? 'trial_ended' : 'expired', message: tk.message ?? null };
  let warn: Omit<LicState, 'install_code' | 'checked_at'> | null = null;
  if (tk.source === 'ping') {
    const days = Math.floor((now - Date.parse(tk.issued_at)) / DAY);
    const w = tk.warn_days ?? NO_TOKEN.warn; const bl = tk.block_days ?? NO_TOKEN.block;
    base.days_offline = days;
    if (days >= bl) return { ...base, state: 'blocked', reason: 'offline' };
    if (days >= w) warn = { ...base, state: 'warning', reason: 'offline_soon', days_left: bl - days };
  }
  if (!warn && tk.expires) {
    const left = Math.ceil((Date.parse(tk.expires) - now) / DAY);
    if (left <= EXPIRY_NOTICE_DAYS) warn = { ...base, state: 'warning', reason: 'expires_soon', days_left: left };
  }
  return warn ?? { ...base, state: 'ok', reason: null };
}
export function licenseState(): LicState {
  const s = computeState(token, install?.first_run ?? null, nowSafe());
  return { ...s, install_code: install ? installCode(install.id) : null, checked_at: lastPingAt };
}
export const isBlocked = () => loaded && licenseState().state === 'blocked';

async function ensureInstall(hotelId: number) {
  let inst = await getSetting(hotelId, 'install');
  if (!inst?.id || !inst?.secret || !inst?.first_run) {
    inst = { id: inst?.id ?? randomUUID(), secret: inst?.secret ?? randomBytes(32).toString('hex'), first_run: inst?.first_run ?? new Date().toISOString() };
    await setSetting(hotelId, 'install', inst);
  }
  install = inst;
  return inst as { id: string; secret: string; first_run: string };
}
async function saveClock(hotelId: number) {
  const n = Date.now();
  if (n > maxSeen + 3600_000 || maxSeen === 0) { maxSeen = Math.max(n, maxSeen); await setSetting(hotelId, 'license_clock', { max: new Date(maxSeen).toISOString() }).catch(() => {}); }
}
async function logChange(hotelId: number, before: LicState, after: LicState) {
  if (before.state === after.state && before.reason === after.reason) return;
  await getPool().query(`INSERT INTO audit_logs (hotel_id, action, entity, entity_id, after, result) VALUES ($1,$2,'license','status',$3,'success')`,
    [hotelId, after.state === 'blocked' ? 'license_blocked' : after.state === 'warning' ? 'license_warning' : 'license_ok', JSON.stringify({ reason: after.reason, plan: after.plan, expires: after.expires })]).catch(() => {});
}

/** Jeton enregistré : jeton signé du signal { p, s } ou code d'activation { code, at } (revérifié à chaque démarrage). */
function tokenFromSetting(v: any, installId: string): Token | null {
  if (v?.code && typeof v.at === 'string') {
    const r = decodeActivationCode(v.code, installId, Date.parse(v.at));
    return r.ok ? { ...r.token, issued_at: v.at } : null;
  }
  return verifyToken(v, installId);
}

export async function loadLicense() {
  const h = await firstHotel();
  if (h) {
    const inst = await ensureInstall(h.id);
    token = tokenFromSetting(await getSetting(h.id, 'license_token').catch(() => null), inst.id);
    const c = await getSetting(h.id, 'license_clock').catch(() => null);
    maxSeen = c?.max ? Date.parse(c.max) || 0 : 0;
    lastPingAt = (await getSetting(h.id, 'last_ping').catch(() => null))?.at ?? null;
    await saveClock(h.id);
  }
  loaded = true;
  return licenseState();
}

/** Envoie le signal et enregistre le jeton signé renvoyé par la console. */
export async function pingHome(hotelId: number) {
  const pool = getPool();
  const inst = await ensureInstall(hotelId);
  const before = licenseState();
  const h = await one<any>(pool, 'SELECT name, city, phone FROM hotels WHERE id = $1', [hotelId]);
  const st = await one<any>(pool, `SELECT
      (SELECT count(*)::int FROM rooms WHERE hotel_id = $1 AND active) AS rooms,
      (SELECT count(*)::int FROM users WHERE hotel_id = $1 AND active) AS users,
      (SELECT count(*)::int FROM reservations WHERE hotel_id = $1 AND created_at >= date_trunc('month', now())) AS reservations_month,
      (SELECT max(last_login_at) FROM users WHERE hotel_id = $1) AS last_activity,
      (SELECT count(*)::int FROM audit_logs WHERE hotel_id = $1 AND action = 'login' AND created_at >= date_trunc('month', now())) AS logins_month,
      (SELECT count(*)::int FROM audit_logs WHERE hotel_id = $1 AND action = 'login') AS logins_total,
      current_database() AS db`, [hotelId]);
  const body = {
    install_id: inst.id, secret: inst.secret, first_run: inst.first_run, hotel: h?.name ?? null, city: h?.city ?? null, phone: h?.phone ?? null,
    mode: /demo/i.test(st.db) || /d[ée]mo/i.test(h?.name ?? '') ? 'demo' : 'reel', version: APP_VERSION,
    hostname: os.hostname(), os: `${os.type()} ${os.release()}`,
    rooms: st.rooms, users: st.users, reservations_month: st.reservations_month, logins_month: st.logins_month, logins_total: st.logins_total, last_activity: st.last_activity,
  };
  let r: Response;
  try { r = await fetch(pingUrl(), { method: 'POST', headers: { 'content-type': 'application/json', 'user-agent': `KAYN-Hotel/${APP_VERSION}` }, body: JSON.stringify(body), signal: AbortSignal.timeout(15_000) }); }
  catch { return { ok: false, offline: true, ...licenseState() }; } // pas d'Internet : dernier jeton conservé
  if (!r.ok) return { ok: false, ...licenseState() };
  const j: any = await r.json().catch(() => ({}));
  const tk = verifyToken(j?.token, inst.id);
  if (!tk) return { ok: false, invalid: true, ...licenseState() }; // réponse non signée ou modifiée : ignorée
  // un code d'activation plus long que la licence de la console reste valable
  if (!(token?.source === 'code' && token.expires && tk.status === 'active' && tk.expires && Date.parse(token.expires) > Date.parse(tk.expires))) {
    token = tk;
    await setSetting(hotelId, 'license_token', j.token);
  }
  lastPingAt = new Date().toISOString();
  maxSeen = Math.max(maxSeen, Date.parse(tk.issued_at) || 0);
  await setSetting(hotelId, 'last_ping', { at: lastPingAt });
  await saveClock(hotelId);
  await logChange(hotelId, before, licenseState());
  return { ok: true, ...licenseState() };
}

/** Saisie d'un code d'activation (hors ligne). */
export async function activateCode(hotelId: number, code: string) {
  const inst = await ensureInstall(hotelId);
  const before = licenseState();
  const r = decodeActivationCode(code, inst.id, nowSafe());
  if (!r.ok) return r;
  if (token?.status === 'suspended' && token.source === 'ping') return { ok: false as const, error: 'suspended' };
  token = r.token;
  // le code lui-même est conservé (signé) : il est revérifié à chaque démarrage
  await setSetting(hotelId, 'license_token', { code: code.trim().toUpperCase(), at: r.token.issued_at });
  await logChange(hotelId, before, licenseState());
  return { ok: true as const, ...licenseState() };
}

/** Planificateur : une fois par 24 h ; toutes les heures en cas d'avertissement ou de blocage. */
export async function pingIfDue(hotelId: number) {
  await saveClock(hotelId).catch(() => {});
  const every = licenseState().state === 'ok' ? 24 * 3600_000 : 3600_000;
  if (lastPingAt && Date.now() - Date.parse(lastPingAt) < every && Date.now() >= Date.parse(lastPingAt)) return;
  await pingHome(hotelId);
}
