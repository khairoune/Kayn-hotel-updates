/**
 * KAYN Hotel — configuration automatique après copie des fichiers (lancée par KAYN-Hotel-Setup.exe, en administrateur).
 *
 * Fait tout ce qu'un technicien ferait à la main :
 *  1. PostgreSQL 16 : réutilise une installation existante (nouvelle base dédiée « kayn-hotel-pg » sur son propre port)
 *     ou installe PostgreSQL 16 sans question (installateur officiel inclus dans le Setup, vérifié SHA-256 ;
 *     à défaut téléchargé depuis le site officiel EDB) ;
 *  2. crée la base kayn_hotel avec un mot de passe aléatoire (jamais affiché, rangé dans server\.env protégé) ;
 *  3. démarrage automatique : tâche planifiée « KAYN Hotel » au démarrage du PC (compte SYSTÈME, même sans session ouverte,
 *     redémarrage automatique en cas d'arrêt) ;
 *  4. PC serveur toujours allumé : mise en veille et veille prolongée désactivées sur secteur ;
 *  5. pare-feu Windows : port de KAYN Hotel ouvert sur le réseau local (profils Privé et Domaine) ;
 *  6. démarre KAYN Hotel, vérifie qu'il répond, puis ouvre le navigateur sur l'assistant de première installation.
 * Une réinstallation garde la configuration et les données (server\.env et server\data ne sont jamais remplacés).
 * Journal : C:\KAYN-Hotel\installation.log
 * Usage : node.exe setup.cjs --dir C:\KAYN-Hotel [--exe-dir <dossier du Setup>] [--port 8080]
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const https = require('node:https');
const http = require('node:http');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');

const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : d; };
const DIR = path.resolve(arg('dir', 'C:\\KAYN-Hotel'));
const EXE_DIR = path.resolve(arg('exe-dir', DIR));
const APP = path.join(DIR, 'app');
const SERVER = path.join(APP, 'server');
const NODE = path.join(DIR, 'node', 'node.exe');
const ENV = path.join(SERVER, '.env');
const LOG = path.join(DIR, 'installation.log');
const TASK = 'KAYN Hotel';
const PG_SERVICE = 'kayn-hotel-pg';

/** PostgreSQL 16.15 officiel (EDB), inclus dans le Setup. Signé EnterpriseDB Corporation (DigiCert), vérifié le 2026-11-13. */
const PG_INSTALLER = {
  file: 'postgresql-16.15-5-windows-x64.exe',
  url: 'https://get.enterprisedb.com/postgresql/postgresql-16.15-5-windows-x64.exe',
  sha256: '4065dbc5ffb52010e7357dfd6a74934878f1c6faf7a75cad1411a22e11b7b929',
};

fs.mkdirSync(DIR, { recursive: true });
const log = (m) => { const l = `${new Date().toISOString()} ${m}`; console.log(m); try { fs.appendFileSync(LOG, l + '\n'); } catch { /* */ } };
const step = (n, m) => log(`\n[${n}/7] ${m}`);
const fail = (m) => { log(`\n[ERREUR] ${m}\nJournal complet : ${LOG}\nContact : KAYN Services — 0799 18 78 24 — info@kaynservice.com`); process.exit(1); };
/** Commande Windows ; le texte des secrets n'est jamais écrit dans le journal. */
const run = (cmd, args, { secret = false, allowFail = false, env } = {}) => {
  if (!secret) log(`  > ${cmd} ${args.join(' ')}`);
  const r = spawnSync(cmd, args, { encoding: 'utf8', windowsHide: true, env: { ...process.env, ...(env || {}) } });
  const out = `${r.stdout || ''}${r.stderr || ''}`.trim();
  if (r.status !== 0 && !allowFail) fail(`${path.basename(cmd)} a échoué (code ${r.status}) : ${secret ? '(détail masqué)' : out.slice(-800)}`);
  return { ok: r.status === 0, out };
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const portFree = (port) => new Promise((ok) => { const s = net.createServer(); s.once('error', () => ok(false)); s.once('listening', () => s.close(() => ok(true))); s.listen(port, '0.0.0.0'); });
const portOpen = (port) => new Promise((ok) => { const s = net.connect(port, '127.0.0.1'); s.once('connect', () => { s.destroy(); ok(true); }); s.once('error', () => ok(false)); s.setTimeout(1500, () => { s.destroy(); ok(false); }); });
async function firstFree(from) { for (let p = from; p < from + 50; p++) if (await portFree(p)) return p; fail(`aucun port libre à partir de ${from}`); }
const readEnv = () => { const o = {}; if (fs.existsSync(ENV)) for (const l of fs.readFileSync(ENV, 'utf8').split(/\r?\n/)) { const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)$/.exec(l); if (m) o[m[1]] = m[2]; } return o; };
const sha256 = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');

function download(url, dest, redirects = 5) {
  return new Promise((ok, ko) => {
    const tmp = `${dest}.part`;
    https.get(url, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) { res.resume(); return ok(download(new URL(res.headers.location, url).toString(), dest, redirects - 1)); }
      if (res.statusCode !== 200) { res.resume(); return ko(new Error(`HTTP ${res.statusCode}`)); }
      const total = Number(res.headers['content-length'] || 0); let got = 0; let last = 0;
      const f = fs.createWriteStream(tmp);
      res.on('data', (c) => { got += c.length; const pct = total ? Math.floor((got / total) * 100) : 0; if (pct >= last + 10) { last = pct; console.log(`  téléchargement ${pct} %`); } });
      res.pipe(f);
      f.on('finish', () => f.close(() => { fs.renameSync(tmp, dest); ok(dest); }));
      f.on('error', ko);
    }).on('error', ko);
  });
}

/** Dossier bin d'un PostgreSQL 16 déjà présent (le nôtre en priorité). */
function findPg16() {
  const cands = [path.join(DIR, 'postgresql', 'bin'), 'C:\\Program Files\\PostgreSQL\\16\\bin'];
  const reg = run('reg', ['query', 'HKLM\\SOFTWARE\\PostgreSQL\\Installations', '/s', '/v', 'Base Directory'], { allowFail: true });
  for (const m of reg.out.matchAll(/Base Directory\s+REG_SZ\s+(.+)/g)) cands.push(path.join(m[1].trim(), 'bin'));
  for (const b of cands) {
    if (!fs.existsSync(path.join(b, 'pg_ctl.exe')) || !fs.existsSync(path.join(b, 'pg_dump.exe'))) continue;
    const v = run(path.join(b, 'pg_ctl.exe'), ['--version'], { allowFail: true }).out;
    if (/\b16\.\d+/.test(v)) return b;
  }
  return null;
}

async function main() {
  log(`=== KAYN Hotel — installation (${new Date().toLocaleString('fr-FR')}) dans ${DIR} ===`);
  if (!fs.existsSync(path.join(SERVER, 'dist', 'index.js'))) fail(`fichiers de l'application absents dans ${APP}`);
  const env = readEnv();
  const reinstall = !!env.DATABASE_URL;
  if (reinstall) log('Configuration existante trouvée : elle est conservée (aucune donnée n\'est effacée).');

  // ---------- 1. PostgreSQL ----------
  step(1, 'Base de données PostgreSQL 16');
  let pgBin = env.PG_BIN && fs.existsSync(path.join(env.PG_BIN, 'pg_dump.exe')) ? env.PG_BIN : findPg16();
  let dbUrl = env.DATABASE_URL;
  if (!reinstall) {
    const password = crypto.randomBytes(24).toString('base64url');
    const pgPort = await firstFree(5433);
    if (!pgBin) {
      log('PostgreSQL 16 n\'est pas installé : installation automatique (aucune question).');
      let exe = [EXE_DIR, DIR].map((d) => path.join(d, PG_INSTALLER.file)).find((f) => fs.existsSync(f));
      if (!exe) {
        exe = path.join(DIR, PG_INSTALLER.file);
        log('Téléchargement de PostgreSQL 16 depuis le site officiel (environ 350 Mo, Internet nécessaire)…');
        try { await download(PG_INSTALLER.url, exe); } catch (e) { fail(`téléchargement impossible (${e.message}). Copiez ${PG_INSTALLER.file} à côté de KAYN-Hotel-Setup.exe puis relancez.`); }
      }
      if (sha256(exe) !== PG_INSTALLER.sha256) { try { fs.unlinkSync(exe); } catch { /* */ } fail(`fichier ${PG_INSTALLER.file} invalide (empreinte SHA-256 différente) : il a été supprimé, relancez l'installation.`); }
      log('Fichier PostgreSQL vérifié (SHA-256). Installation silencieuse (3 à 8 minutes, ne fermez pas cette fenêtre)…');
      const prefix = path.join(DIR, 'postgresql');
      run(exe, ['--mode', 'unattended', '--unattendedmodeui', 'none', '--prefix', prefix, '--datadir', path.join(prefix, 'data'),
        '--superpassword', password, '--serverport', String(pgPort), '--servicename', PG_SERVICE, '--locale', 'C',
        '--enable-components', 'server,commandlinetools', '--disable-components', 'pgAdmin,stackbuilder', '--install_runtimes', '1'], { secret: true });
      pgBin = path.join(prefix, 'bin');
      if (exe.startsWith(DIR)) try { fs.unlinkSync(exe); } catch { /* */ }
      if (!fs.existsSync(path.join(pgBin, 'pg_dump.exe'))) fail('PostgreSQL ne s\'est pas installé correctement (outils introuvables).');
    } else {
      log(`PostgreSQL 16 trouvé : ${pgBin}. Création d'une base dédiée à KAYN Hotel (port ${pgPort}).`);
      const data = path.join(DIR, 'pgdata');
      if (!fs.existsSync(path.join(data, 'PG_VERSION'))) {
        const pw = path.join(DIR, '.pw.tmp');
        fs.writeFileSync(pw, password);
        try { run(path.join(pgBin, 'initdb.exe'), ['-D', data, '-U', 'postgres', '--pwfile', pw, '-E', 'UTF8', '--locale', 'C', '-A', 'scram-sha-256'], { secret: true }); }
        finally { fs.rmSync(pw, { force: true }); }
        fs.appendFileSync(path.join(data, 'postgresql.conf'), `\n# KAYN Hotel\nport = ${pgPort}\nlisten_addresses = 'localhost'\n`);
      }
      // le service PostgreSQL tourne sous « Service réseau » : il doit pouvoir écrire dans son dossier
      run('icacls', [data, '/grant', '*S-1-5-20:(OI)(CI)F', '/T', '/Q'], { allowFail: true });
      run('sc', ['query', PG_SERVICE], { allowFail: true }).ok
        || run(path.join(pgBin, 'pg_ctl.exe'), ['register', '-N', PG_SERVICE, '-D', data, '-S', 'auto', '-w']);
      run('sc', ['start', PG_SERVICE], { allowFail: true });
    }
    log('Attente du démarrage de PostgreSQL…');
    for (let i = 0; i < 60 && !(await portOpen(pgPort)); i++) await sleep(1000);
    if (!(await portOpen(pgPort))) fail(`PostgreSQL ne répond pas sur le port ${pgPort}.`);
    run('sc', ['config', PG_SERVICE, 'start=', 'auto'], { allowFail: true });
    run('sc', ['failure', PG_SERVICE, 'reset=', '86400', 'actions=', 'restart/10000/restart/30000/restart/60000'], { allowFail: true });

    // ---------- 2. Base et configuration ----------
    step(2, 'Base kayn_hotel et configuration');
    const psql = path.join(pgBin, 'psql.exe');
    const penv = { PGPASSWORD: password };
    const exists = run(psql, ['-U', 'postgres', '-h', 'localhost', '-p', String(pgPort), '-tAc', "SELECT 1 FROM pg_database WHERE datname='kayn_hotel'"], { secret: true, env: penv, allowFail: true });
    if (!exists.ok) fail('connexion à PostgreSQL impossible.');
    if (exists.out.trim() !== '1') run(psql, ['-U', 'postgres', '-h', 'localhost', '-p', String(pgPort), '-c', 'CREATE DATABASE kayn_hotel'], { secret: true, env: penv });
    dbUrl = `postgres://postgres:${encodeURIComponent(password)}@localhost:${pgPort}/kayn_hotel`;
    const appPort = Number(arg('port', 0)) || await firstFree(8080);
    fs.writeFileSync(ENV, [
      '# Configuration de KAYN Hotel (créée par l\'installateur) — ne pas partager : contient le mot de passe de la base',
      `DATABASE_URL=${dbUrl}`, `PORT=${appPort}`, 'HOST=0.0.0.0', 'SESSION_HOURS=12', 'HOTEL_TZ=Africa/Algiers',
      'REQUIRE_DEVICE_APPROVAL=true', 'COOKIE_SECURE=false', `PG_BIN=${pgBin}`, '# BACKUP_DIR=D:\\KAYN-Sauvegardes', '',
    ].join('\r\n'));
    log(`Configuration écrite dans ${ENV} (mot de passe aléatoire de la base, jamais affiché).`);
  } else {
    step(2, 'Configuration conservée');
    if (!pgBin) fail('outils PostgreSQL introuvables (PG_BIN).');
    // base KAYN Hotel arrêtée pendant la copie des fichiers : redémarrage
    if (run('sc', ['query', PG_SERVICE], { allowFail: true }).ok) {
      run('sc', ['start', PG_SERVICE], { allowFail: true });
      let pgPort = 5432; try { pgPort = Number(new URL(dbUrl).port) || 5432; } catch { /* */ }
      for (let i = 0; i < 60 && !(await portOpen(pgPort)); i++) await sleep(1000);
      if (!(await portOpen(pgPort))) fail(`PostgreSQL ne répond pas sur le port ${pgPort}.`);
    }
    if (!env.PG_BIN) fs.appendFileSync(ENV, `\r\nPG_BIN=${pgBin}\r\n`);
  }
  // l'installateur PostgreSQL inclus (400 Mo) n'est plus utile
  try { fs.rmSync(path.join(DIR, PG_INSTALLER.file), { force: true }); } catch { /* */ }
  // .env lisible seulement par le système et les administrateurs
  run('icacls', [ENV, '/inheritance:r', '/grant:r', '*S-1-5-18:F', '*S-1-5-32-544:F'], { allowFail: true });
  fs.mkdirSync(path.join(SERVER, 'data', 'logs'), { recursive: true });
  const appPort = Number(readEnv().PORT || 8080);

  // ---------- 3. Démarrage automatique ----------
  step(3, 'Démarrage automatique au démarrage du PC (même sans session ouverte)');
  const xml = `<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Description>Serveur KAYN Hotel (superviseur : relance automatique, mises à jour). KAYN Services.</Description></RegistrationInfo>
  <Triggers><BootTrigger><Enabled>true</Enabled><Delay>PT30S</Delay></BootTrigger></Triggers>
  <Principals><Principal id="Author"><UserId>S-1-5-18</UserId><RunLevel>HighestAvailable</RunLevel></Principal></Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries><StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <StartWhenAvailable>true</StartWhenAvailable><RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings><StopOnIdleEnd>false</StopOnIdleEnd><RestartOnIdle>false</RestartOnIdle></IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand><Enabled>true</Enabled><Hidden>false</Hidden>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit><Priority>5</Priority>
    <RestartOnFailure><Interval>PT1M</Interval><Count>999</Count></RestartOnFailure>
  </Settings>
  <Actions Context="Author"><Exec><Command>${NODE}</Command><Arguments>"${path.join(SERVER, 'start.cjs')}"</Arguments><WorkingDirectory>${SERVER}</WorkingDirectory></Exec></Actions>
</Task>`;
  const xf = path.join(DIR, 'tache-kayn-hotel.xml');
  fs.writeFileSync(xf, Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from(xml, 'utf16le')]));
  run('schtasks', ['/End', '/TN', TASK], { allowFail: true });
  run(NODE, [path.join(SERVER, 'arreter.cjs')], { allowFail: true });
  run('schtasks', ['/Create', '/F', '/TN', TASK, '/XML', xf]);

  // ---------- 4. Toujours allumé ----------
  step(4, 'PC serveur toujours allumé (veille désactivée sur secteur)');
  for (const a of [['-change', '-standby-timeout-ac', '0'], ['-change', '-hibernate-timeout-ac', '0'], ['-change', '-disk-timeout-ac', '0'], ['-h', 'off']]) run('powercfg', a, { allowFail: true });
  // pas de redémarrage automatique de Windows Update pendant qu'une session est ouverte
  run('reg', ['add', 'HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU', '/v', 'NoAutoRebootWithLoggedOnUsers', '/t', 'REG_DWORD', '/d', '1', '/f'], { allowFail: true });

  // ---------- 5. Pare-feu ----------
  step(5, `Pare-feu : port ${appPort} ouvert pour les autres postes de l'hôtel (réseau local)`);
  run('netsh', ['advfirewall', 'firewall', 'delete', 'rule', 'name=KAYN Hotel'], { allowFail: true });
  run('netsh', ['advfirewall', 'firewall', 'add', 'rule', 'name=KAYN Hotel', 'dir=in', 'action=allow', 'protocol=TCP', `localport=${appPort}`, 'profile=private,domain']);

  // ---------- 6. Démarrage ----------
  step(6, 'Démarrage de KAYN Hotel');
  run('schtasks', ['/Run', '/TN', TASK]);
  let ok = false;
  for (let i = 0; i < 90 && !ok; i++) {
    await sleep(2000);
    ok = await new Promise((r) => http.get(`http://127.0.0.1:${appPort}/api/health`, (res) => { res.resume(); r(res.statusCode === 200); }).on('error', () => r(false)));
  }
  if (!ok) fail(`KAYN Hotel ne répond pas sur le port ${appPort}. Détails : ${path.join(SERVER, 'data', 'logs')}`);

  // ---------- 7. Fin ----------
  step(7, 'Terminé');
  fs.writeFileSync(path.join(DIR, 'LISEZ-MOI.txt'), [
    'KAYN Hotel est installé.', '',
    `Sur ce PC : http://localhost:${appPort}`,
    'Sur les autres postes : l\'adresse réseau est affichée dans Administration > Système.', '',
    'Le serveur démarre seul à chaque allumage du PC (même sans ouvrir de session).',
    'La mise en veille du PC a été désactivée (sur secteur). Gardez le PC branché sur un onduleur.',
    'Configuration : app\\server\\.env (ne pas partager). Données : app\\server\\data. Journal : installation.log', '',
    'Assistance : KAYN Services — 0799 18 78 24 — info@kaynservice.com',
  ].join('\r\n'));
  const url = `[InternetShortcut]\r\nURL=http://localhost:${appPort}\r\n`;
  for (const d of [path.join(process.env.PUBLIC || 'C:\\Users\\Public', 'Desktop'), path.join(process.env.ProgramData || 'C:\\ProgramData', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'KAYN Hotel')]) {
    try { fs.mkdirSync(d, { recursive: true }); fs.writeFileSync(path.join(d, d.endsWith('Desktop') ? 'KAYN Hotel.url' : 'Ouvrir KAYN Hotel.url'), url); } catch { /* */ }
  }
  log(`KAYN Hotel fonctionne : http://localhost:${appPort}`);
  if (!process.argv.includes('--no-browser')) spawnSync('cmd', ['/c', 'start', '', `http://localhost:${appPort}`], { windowsHide: true });
}

main().catch((e) => fail(e && e.stack ? e.stack : String(e)));
