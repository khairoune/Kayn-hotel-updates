; KAYN Hotel — installateur Windows (NSIS 3). Construit par scripts/build-installer-windows.sh
Unicode true
!include "MUI2.nsh"
!include "x64.nsh"

Name "KAYN Hotel ${VERSION}"
OutFile "${OUT}"
InstallDir "C:\KAYN-Hotel"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
BrandingText "KAYN Services — 0799 18 78 24"
VIProductVersion "${VERSION}.0"
VIAddVersionKey "ProductName" "KAYN Hotel"
VIAddVersionKey "CompanyName" "KAYN Services"
VIAddVersionKey "FileDescription" "Installation de KAYN Hotel"
VIAddVersionKey "FileVersion" "${VERSION}"
VIAddVersionKey "LegalCopyright" "KAYN Services"

!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Installation de KAYN Hotel ${VERSION}"
!define MUI_WELCOMEPAGE_TEXT "Ce programme installe tout ce qu'il faut sur ce PC serveur :$\r$\n$\r$\n• KAYN Hotel et son moteur (Node.js)$\r$\n• la base de données PostgreSQL 16 (incluse)$\r$\n• le démarrage automatique à l'allumage du PC$\r$\n• la mise en veille désactivée (PC toujours allumé)$\r$\n• l'accès depuis les autres postes de l'hôtel$\r$\n$\r$\nAucune question technique, aucun Internet nécessaire. Durée : 2 à 10 minutes.$\r$\nVos données ne sont jamais effacées par une réinstallation."
!define MUI_FINISHPAGE_TITLE "KAYN Hotel est prêt"
!define MUI_FINISHPAGE_TEXT "Le navigateur s'ouvre sur l'assistant de première installation (création du compte administrateur).$\r$\n$\r$\nAssistance : KAYN Services — 0799 18 78 24 — info@kaynservice.com"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "French"

Function .onInit
  ${IfNot} ${RunningX64}
    MessageBox MB_ICONSTOP "KAYN Hotel demande Windows 10 ou 11 en 64 bits." /SD IDOK
    Abort
  ${EndIf}
FunctionEnd

Section "KAYN Hotel"
  SetShellVarContext all
  ${DisableX64FSRedirection}
  SetRegView 64
  SetOutPath "$INSTDIR"
  ; arrêt propre d'une version déjà installée (les données et la configuration restent)
  IfFileExists "$INSTDIR\node\node.exe" 0 +5
    DetailPrint "Arrêt de la version installée…"
    nsExec::ExecToLog '"$INSTDIR\node\node.exe" "$INSTDIR\app\server\arreter.cjs"'
    Sleep 8000
    nsExec::ExecToLog 'schtasks /End /TN "KAYN Hotel"'
  ; la base est arrêtée le temps de remplacer ses fichiers (setup.cjs la redémarre) ; ses données ne sont pas touchées
  nsExec::ExecToLog 'sc stop kayn-hotel-pg'
  Sleep 5000
  DetailPrint "Copie des fichiers…"
  SetOutPath "$INSTDIR\node"
  File "${SRC}\node.exe"
  SetOutPath "$INSTDIR"
  File "${SRC}\setup.cjs"
  File "${SRC}\app.tar.gz"
  !ifdef PG_EXE
  File "${SRC}\postgresql-16.15-5-windows-x64.exe"
  !endif
  DetailPrint "Décompression de l'application…"
  ; l'archive ne contient ni server\.env ni server\data : configuration et données existantes restent intactes
  nsExec::ExecToLog '"$SYSDIR\tar.exe" -xzf "$INSTDIR\app.tar.gz" -C "$INSTDIR"'
  Pop $0
  StrCmp $0 "0" +3
    MessageBox MB_ICONSTOP "Décompression impossible (Windows 10 version 1803 ou plus récent requis)." /SD IDOK
    Abort
  Delete "$INSTDIR\app.tar.gz"
  WriteUninstaller "$INSTDIR\Desinstaller.exe"

  DetailPrint "Configuration automatique (PostgreSQL, base, démarrage automatique, veille, pare-feu)…"
  StrCpy $1 ""
  IfSilent 0 +2
    StrCpy $1 "--no-browser"
  nsExec::ExecToLog '"$INSTDIR\node\node.exe" "$INSTDIR\setup.cjs" --dir "$INSTDIR" --exe-dir "$EXEDIR" $1'
  Pop $0
  StrCmp $0 "0" ok
    MessageBox MB_ICONSTOP "La configuration n'a pas abouti (code $0).$\r$\nLe détail est dans $INSTDIR\installation.log$\r$\n$\r$\nAppelez KAYN Services : 0799 18 78 24" /SD IDOK
    Abort
  ok:

  CreateDirectory "$SMPROGRAMS\KAYN Hotel"
  CreateShortcut "$SMPROGRAMS\KAYN Hotel\Journal d'installation.lnk" "$INSTDIR\installation.log"
  CreateShortcut "$SMPROGRAMS\KAYN Hotel\Désinstaller KAYN Hotel.lnk" "$INSTDIR\Desinstaller.exe"

  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\KAYN Hotel" "DisplayName" "KAYN Hotel"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\KAYN Hotel" "DisplayVersion" "${VERSION}"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\KAYN Hotel" "Publisher" "KAYN Services"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\KAYN Hotel" "UninstallString" '"$INSTDIR\Desinstaller.exe"'
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\KAYN Hotel" "NoModify" 1
SectionEnd

Section "Uninstall"
  SetShellVarContext all
  ${DisableX64FSRedirection}
  SetRegView 64
  MessageBox MB_YESNO|MB_ICONQUESTION "Désinstaller KAYN Hotel ?$\r$\n$\r$\nLa base de données, les sauvegardes et la configuration sont CONSERVÉES (dossier $INSTDIR). Pour les effacer, supprimez ce dossier vous-même après avoir copié vos sauvegardes." /SD IDYES IDYES +2
    Abort
  nsExec::ExecToLog '"$INSTDIR\node\node.exe" "$INSTDIR\app\server\arreter.cjs"'
  nsExec::ExecToLog 'schtasks /End /TN "KAYN Hotel"'
  nsExec::ExecToLog 'schtasks /Delete /F /TN "KAYN Hotel"'
  nsExec::ExecToLog 'netsh advfirewall firewall delete rule name="KAYN Hotel"'
  Delete "$DESKTOP\KAYN Hotel.url"
  RMDir /r "$SMPROGRAMS\KAYN Hotel"
  RMDir /r "$INSTDIR\node"
  Delete "$INSTDIR\setup.cjs"
  Delete "$INSTDIR\Desinstaller.exe"
  DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\KAYN Hotel"
SectionEnd
