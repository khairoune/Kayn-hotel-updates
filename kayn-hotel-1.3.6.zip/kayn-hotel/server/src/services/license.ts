/**
 * Signal d'assistance KAYN Services + statut de licence.
 * Une fois par jour (et au démarrage), quand Internet est disponible, KAYN Hotel envoie à KAYN Services :
 * nom, ville et téléphone de l'hôtel, mode (démo / réel), version, nom du PC, nombre de chambres, d'utilisateurs actifs,
 * de réservations et de connexions du mois, date de dernière activité. JAMAIS de données clients, de montants ni de mots de passe.
 * En retour, KAYN Services indique si la licence est active ou suspendue.
 * Sans Internet, le dernier statut connu est conservé (une coupure ne bloque jamais l'hôtel).
 */
import { randomBytes, randomUUID } from 'node:crypto';
import os from 'node:os';
import { getPool, one } from '../db/pool.js';
import { APP_VERSION } from './updates.js';

const pingUrl = () => process.env.KAYN_PING_URL ?? 'https://gdvyymfqeqllsebrbtjm.supabase.co/functions/v1/kayn-hotel-ping';
type Lic = { status: 'active' | 'suspended'; message?: string | null; checked_at?: string; since?: string | null };
let cache: Lic = { status: 'active' };
let loaded = false;

async function getSetting(hotelId: number, key: string) {
  return (await one<any>(getPool(), 'SELECT value FROM settings WHERE hotel_id = $1 AND key = $2', [hotelId, key]))?.value ?? null;
}
async function setSetting(hotelId: number, key: string, v: unknown) {
  await getPool().query(`INSERT INTO settings (hotel_id, key, value) VALUES ($1,$2,$3) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`, [hotelId, key, JSON.stringify(v)]);
}
export async function loadLicense() {
  const h = await one<any>(getPool(), 'SELECT id FROM hotels ORDER BY id LIMIT 1').catch(() => null);
  if (h) cache = (await getSetting(h.id, 'license').catch(() => null)) ?? { status: 'active' };
  loaded = true;
  return cache;
}
export const licenseState = () => cache;
export const isSuspended = () => loaded && cache.status === 'suspended';

/** Envoie le signal et applique le statut renvoyé. */
export async function pingHome(hotelId: number) {
  const pool = getPool();
  let inst = await getSetting(hotelId, 'install');
  if (!inst?.id || !inst?.secret) { inst = { id: randomUUID(), secret: randomBytes(32).toString('hex') }; await setSetting(hotelId, 'install', inst); }
  const h = await one<any>(pool, 'SELECT name, city, phone FROM hotels WHERE id = $1', [hotelId]);
  const st = await one<any>(pool, `SELECT
      (SELECT count(*)::int FROM rooms WHERE hotel_id = $1 AND active) AS rooms,
      (SELECT count(*)::int FROM users WHERE hotel_id = $1 AND active) AS users,
      (SELECT count(*)::int FROM reservations WHERE hotel_id = $1 AND created_at >= date_trunc('month', now())) AS reservations_month,
      (SELECT max(last_login_at) FROM users WHERE hotel_id = $1) AS last_activity,
      (SELECT count(*)::int FROM audit_logs WHERE hotel_id = $1 AND action = 'login' AND created_at >= date_trunc('month', now())) AS logins_month,
      (SELECT count(*)::int FROM audit_logs WHERE hotel_id = $1 AND action = 'login') AS logins_total,
      current_database() AS db`, [hotelId]);
  const body = {
    install_id: inst.id, secret: inst.secret, hotel: h?.name ?? null, city: h?.city ?? null, phone: h?.phone ?? null,
    mode: /demo/i.test(st.db) || /d[ée]mo/i.test(h?.name ?? '') ? 'demo' : 'reel', version: APP_VERSION,
    hostname: os.hostname(), os: `${os.type()} ${os.release()}`,
    rooms: st.rooms, users: st.users, reservations_month: st.reservations_month, logins_month: st.logins_month, logins_total: st.logins_total, last_activity: st.last_activity,
  };
  let r: Response;
  try { r = await fetch(pingUrl(), { method: 'POST', headers: { 'content-type': 'application/json', 'user-agent': `KAYN-Hotel/${APP_VERSION}` }, body: JSON.stringify(body), signal: AbortSignal.timeout(15_000) }); }
  catch { return { ok: false, offline: true, ...cache }; } // pas d'Internet : statut conservé
  if (!r.ok) return { ok: false, ...cache };
  const j: any = await r.json().catch(() => ({}));
  const prev = cache.status;
  cache = { status: j.status === 'suspended' ? 'suspended' : 'active', message: j.message ?? null, checked_at: new Date().toISOString(), since: j.status === 'suspended' ? (prev === 'suspended' ? cache.since ?? new Date().toISOString() : new Date().toISOString()) : null };
  loaded = true;
  await setSetting(hotelId, 'license', cache);
  if (prev !== cache.status) await pool.query(`INSERT INTO audit_logs (hotel_id, action, entity, entity_id, after, result) VALUES ($1,$2,'license','status',$3,'success')`, [hotelId, cache.status === 'suspended' ? 'license_suspended' : 'license_activated', JSON.stringify(cache)]).catch(() => {});
  await setSetting(hotelId, 'last_ping', { at: new Date().toISOString() });
  return { ok: true, ...cache };
}

/** Planificateur : au plus une fois par 24 h (toutes les heures si la licence est suspendue, pour une réactivation rapide). */
export async function pingIfDue(hotelId: number) {
  const last = await getSetting(hotelId, 'last_ping');
  const every = cache.status === 'suspended' ? 3600_000 : 24 * 3600_000;
  if (last?.at && Date.now() - new Date(last.at).getTime() < every) return;
  await pingHome(hotelId);
}
