/**
 * Bouclier anti-robot.
 * Bloque temporairement une adresse qui se comporte comme un robot :
 *  - rafale : plus de FLOOD requêtes /api en 1 minute → 15 min ;
 *  - essais de mots de passe : 10 connexions refusées en 10 minutes (tous identifiants confondus) → 30 min ;
 *  - scan : 5 adresses piégées (/wp-admin, .php, /.env, ../…) en 5 minutes → 60 min ;
 *  - récidive : 3e blocage en 24 h → 24 h.
 * Le PC serveur lui-même (127.0.0.1) n'est jamais bloqué, pour que l'administrateur garde toujours la main.
 * Chaque blocage est enregistré (journal + notification « sécurité » des administrateurs) et peut être levé
 * dans Administration → Sécurité.
 */
import type { FastifyInstance } from 'fastify';
import { getPool, one, q } from '../db/pool.js';
import { notify } from './notify.js';

export const SHIELD = { FLOOD: 400, LOGIN_FAILS: 10, SCAN_HITS: 5 };
const MIN = { flood: 15, bruteforce: 30, scan: 60, repeat: 24 * 60 };
const SCAN = /(\.php|\.asp|\.aspx|\.jsp|\.cgi|wp-admin|wp-login|wp-content|phpmyadmin|\/\.env|\/\.git|\/etc\/passwd|\.\.\/|%2e%2e|\/admin\.php|\/xmlrpc|\/cgi-bin|\/vendor\/|\/actuator|\/boaform|\/HNAP1)/i;
const LOCAL = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1']);

type Win = { t: number; n: number };
const req1m = new Map<string, Win>();
const fails10m = new Map<string, number[]>();
const scans5m = new Map<string, number[]>();
const blocked = new Map<string, number>(); // ip → fin du blocage (ms)
let loaded = false;

const recent = (m: Map<string, number[]>, ip: string, windowMs: number) => {
  const now = Date.now();
  const a = (m.get(ip) ?? []).filter((t) => now - t < windowMs);
  a.push(now); m.set(ip, a); return a.length;
};

export async function loadBlocks() {
  const rows = await q<any>(getPool(), `SELECT ip, blocked_until FROM ip_blocks WHERE lifted_at IS NULL AND blocked_until > now()`).catch(() => []);
  blocked.clear();
  for (const r of rows) blocked.set(r.ip, Math.max(blocked.get(r.ip) ?? 0, new Date(r.blocked_until).getTime()));
  loaded = true;
}
export const isBlocked = (ip: string) => { const u = blocked.get(ip); if (!u) return false; if (u < Date.now()) { blocked.delete(ip); return false; } return true; };

async function block(ip: string, reason: 'flood' | 'bruteforce' | 'scan', detail: string) {
  if (LOCAL.has(ip) || isBlocked(ip)) return;
  blocked.set(ip, Date.now() + MIN[reason] * 60_000); // bloqué immédiatement, avant toute écriture
  const pool = getPool();
  const n = (await one<any>(pool, `SELECT count(*)::int AS n FROM ip_blocks WHERE ip = $1 AND created_at > now() - interval '24 hours'`, [ip]).catch(() => ({ n: 0 }))).n;
  const minutes = n >= 2 ? MIN.repeat : MIN[reason];
  const until = new Date(Date.now() + minutes * 60_000);
  blocked.set(ip, until.getTime());
  await pool.query(`INSERT INTO ip_blocks (ip, reason, detail, blocked_until) VALUES ($1,$2,$3,$4)`, [ip, reason, detail.slice(0, 300), until]).catch(() => {});
  await pool.query(`INSERT INTO audit_logs (hotel_id, action, entity, entity_id, after, result, ip) SELECT id, 'ip_blocked', 'security', $1, $2, 'failure', $1 FROM hotels`, [ip, JSON.stringify({ reason, minutes, detail })]).catch(() => {});
  const label = { flood: 'trop de requêtes (robot)', bruteforce: 'essais répétés de mots de passe', scan: 'recherche de failles (scan)' }[reason];
  const hotels = await q<any>(pool, 'SELECT id FROM hotels').catch(() => []);
  for (const h of hotels) {
    await notify(pool, h.id, 'security', { title: `Adresse bloquée : ${ip}`, body: `${label} — bloquée ${minutes >= 60 ? `${Math.round(minutes / 60)} h` : `${minutes} min`}. Administration → Sécurité pour la débloquer.`, link: '/admin?s=security', severity: 'danger', dedupe: `ipblock:${ip}:${until.toISOString().slice(0, 16)}` }).catch(() => {});
  }
}

export function lift(ip: string) { blocked.delete(ip); req1m.delete(ip); fails10m.delete(ip); scans5m.delete(ip); }

/** Branche le bouclier sur le serveur (à appeler en premier). */
export function shield(app: FastifyInstance) {
  app.addHook('onRequest', async (req, rep) => {
    if (!loaded) await loadBlocks();
    const ip = req.ip;
    if (LOCAL.has(ip)) return;
    if (isBlocked(ip)) {
      const msg = 'Accès bloqué temporairement : activité anormale détectée depuis cet appareil. Contactez l\'administrateur de l\'hôtel.';
      if (req.url.startsWith('/api/')) return rep.code(403).send({ error: 'blocked', message: msg });
      return rep.code(403).type('text/html; charset=utf-8').send(`<!doctype html><meta charset="utf-8"><title>Accès bloqué</title><body style="font-family:system-ui;background:#7A1F2B;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center"><div><h1 style="color:#C9A227">KAYN Hotel</h1><p>${msg}</p></div></body>`);
    }
    if (SCAN.test(decodeURIComponentSafe(req.url))) {
      if (recent(scans5m, ip, 5 * 60_000) >= SHIELD.SCAN_HITS) await block(ip, 'scan', req.url);
      return rep.code(404).send({ error: 'not_found', message: 'Introuvable' });
    }
    if (req.url.startsWith('/api/')) {
      const now = Date.now();
      const w = req1m.get(ip);
      if (!w || now - w.t > 60_000) req1m.set(ip, { t: now, n: 1 });
      else if (++w.n > SHIELD.FLOOD) await block(ip, 'flood', `${w.n} requêtes en moins d'une minute`);
    }
  });
  app.addHook('onResponse', async (req, rep) => {
    if (req.method === 'POST' && req.url.startsWith('/api/auth/login') && [400, 401, 423, 429].includes(rep.statusCode) && !LOCAL.has(req.ip)) {
      if (recent(fails10m, req.ip, 10 * 60_000) >= SHIELD.LOGIN_FAILS) await block(req.ip, 'bruteforce', 'connexions refusées répétées');
    }
  });
  // nettoyage des compteurs
  setInterval(() => { const now = Date.now(); for (const [k, v] of req1m) if (now - v.t > 120_000) req1m.delete(k); }, 5 * 60_000).unref();
}
function decodeURIComponentSafe(u: string) { try { return decodeURIComponent(u); } catch { return u; } }
