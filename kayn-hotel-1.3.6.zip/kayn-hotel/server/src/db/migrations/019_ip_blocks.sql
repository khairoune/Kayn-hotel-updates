-- Bouclier anti-robot : adresses bloquées automatiquement (rafales de requêtes, essais de mots de passe, scans)
CREATE TABLE ip_blocks (
  id            serial PRIMARY KEY,
  ip            text NOT NULL,
  reason        text NOT NULL CHECK (reason IN ('flood','bruteforce','scan','manual')),
  detail        text,
  blocked_until timestamptz NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  lifted_at     timestamptz,
  lifted_by     int REFERENCES users(id)
);
CREATE INDEX ip_blocks_active ON ip_blocks(ip, blocked_until) WHERE lifted_at IS NULL;
CREATE INDEX ip_blocks_recent ON ip_blocks(created_at DESC);
