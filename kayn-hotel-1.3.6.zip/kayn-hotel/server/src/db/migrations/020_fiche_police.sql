-- Fiche de police conforme au modèle officiel (fiche de voyageur)
ALTER TABLE guests
  ADD COLUMN maiden_name      text,   -- nom de jeune fille
  ADD COLUMN birth_wilaya     text,   -- wilaya de naissance
  ADD COLUMN id_doc_issued_by text;   -- pièce délivrée par (autorité)
ALTER TABLE check_ins
  ADD COLUMN entry_date date;         -- étrangers : date d'entrée en Algérie
