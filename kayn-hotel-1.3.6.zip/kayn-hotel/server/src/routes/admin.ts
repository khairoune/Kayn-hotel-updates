/**
 * Phase 14 — Administration & sécurité : tableau de bord, utilisateurs, rôles et permissions, départements, établissement,
 * finances et taxes, services, documents, notifications, sécurité (sessions, appareils, politique), journal d'activité,
 * sauvegardes / restaurations, état du système. Toutes les vérifications de droits sont faites ici, côté serveur.
 */
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { createReadStream, createWriteStream } from 'node:fs';
import { pipeline } from 'node:stream/promises';
import path from 'node:path';
import { randomBytes, randomUUID } from 'node:crypto';
import { z } from 'zod';
import { getPool, one, q, tx, type Db } from '../db/pool.js';
import { actorOf, clearSecurityCache, hashPassword, requireAuth, requirePerm, sha256, validatePasswordStrength, securityOf } from '../lib/auth.js';
import { audit, redactSecrets } from '../lib/audit.js';
import { AppError, badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { actionOf, MODULES, PERMISSIONS, SENSITIVE } from '../lib/permissions.js';
import { config } from '../config.js';
import { today } from '../lib/dates.js';
import { getSettings } from '../services/common.js';
import { currency, tableCsv, tablePdf, tableXlsx } from '../services/exports.js';
import { adminDashboard, applyEffectiveTaxes, AUDIT_MODULES, effectiveTaxes, entityPatternOf, moduleOfEntity, recordTaxVersion, systemInfo } from '../services/admin.js';
import { backupDir, backupPath, createBackup, deleteBackupFiles, importUpload, restoreBackup, syncRegistry, testRestore, verifyFile } from '../services/backup.js';
import { NOTIF_KINDS } from '../services/notify.js';
import { lift } from '../services/shield.js';
import { APP_VERSION, checkForUpdate, cmpVersion, lastResult, prepareInstall, supervised, updateState } from '../services/updates.js';

const Id = z.object({ id: z.coerce.number().int().positive() });
const opt = (s: z.ZodString) => s.nullish().transform((v) => (v === undefined ? undefined : v === null || v.trim() === '' ? null : v.trim()));
const isSuper = (req: FastifyRequest) => req.user!.role === 'admin';
const needAny = (...ps: string[]) => async (req: FastifyRequest) => { await requireAuth(req, null as any); if (!ps.some((p) => req.user!.perms.has(p))) throw forbidden(`Permission requise : ${ps.join(' ou ')}`); };
async function setSetting(db: Db, hotelId: number, key: string, value: unknown) {
  await db.query(`INSERT INTO settings (hotel_id, key, value, updated_at) VALUES ($1,$2,$3,now()) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`, [hotelId, key, JSON.stringify(value)]);
}
const USER_COLS = `u.id, u.username, u.full_name, u.first_name, u.last_name, u.email, u.phone, u.job_title, u.department_id, d.name AS department_name, u.role_id, r.code AS role, r.name AS role_name,
  u.active, u.protected, u.language, u.must_change_password, u.last_login_at, u.created_at, u.updated_at, u.disabled_at, u.disabled_reason, u.password_changed_at, u.employee_id,
  (u.locked_until IS NOT NULL AND u.locked_until > now()) AS locked, u.locked_until, cb.full_name AS created_by_name,
  (SELECT count(*)::int FROM sessions s WHERE s.user_id = u.id AND NOT s.revoked AND s.expires_at > now()) AS sessions_open`;
const USER_FROM = `FROM users u JOIN roles r ON r.id = u.role_id LEFT JOIN hr_departments d ON d.id = u.department_id LEFT JOIN users cb ON cb.id = u.created_by`;

/** Pas d'élévation de privilèges : on ne peut attribuer / accorder que des droits que l'on possède soi-même (sauf super administrateur). */
async function assertCanGrant(req: FastifyRequest, db: Db, roleId: number) {
  const role = await one<any>(db, 'SELECT * FROM roles WHERE id = $1', [roleId]);
  if (!role) throw badRequest('Rôle inconnu.');
  if (!role.active) throw badRequest('Ce rôle est désactivé.');
  if (isSuper(req)) return role;
  if (role.code === 'admin') throw forbidden('Seul un super administrateur peut attribuer le rôle Super administrateur.');
  const perms = await q<any>(db, 'SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = $1', [roleId]);
  const missing = perms.map((p) => p.code).filter((c) => !req.user!.perms.has(c));
  if (missing.length) throw forbidden(`Vous ne pouvez pas attribuer un rôle plus puissant que le vôtre (droits manquants : ${missing.slice(0, 5).join(', ')}${missing.length > 5 ? '…' : ''}).`);
  return role;
}
async function loadUser(db: Db, hotelId: number, id: number) {
  const u = await one<any>(db, `SELECT ${USER_COLS} ${USER_FROM} WHERE u.id = $1 AND u.hotel_id = $2`, [id, hotelId]);
  if (!u) throw notFound('Utilisateur introuvable');
  return u;
}
/** Un compte protégé (administrateur principal) ne peut être modifié que par un super administrateur. */
function assertCanTouch(req: FastifyRequest, target: any) {
  if (target.protected && !isSuper(req)) throw forbidden('Compte administrateur principal protégé.');
  if (target.role === 'admin' && !isSuper(req)) throw forbidden('Seul un super administrateur peut modifier un compte Super administrateur.');
}
const fmtDT = (d: any) => (d ? new Date(d).toLocaleString('fr-FR', { timeZone: config.timezone }) : '');

export async function adminRoutes(app: FastifyInstance) {
  // ===================================================== Tableau de bord / système =====================================================
  app.get('/api/admin/dashboard', { preHandler: requirePerm('admin.view') }, async (req) => adminDashboard(req.user!.hotelId));
  app.get('/api/admin/system', { preHandler: requirePerm('admin.view') }, async (req) => systemInfo(req.user!.hotelId));

  // ===================================================== Annuaire du personnel =====================================================
  /** Numéros de tout le personnel actif, pour tous les comptes connectés (appel / WhatsApp en un clic). */
  app.get('/api/directory', { preHandler: requireAuth }, async (req) =>
    q(getPool(), `SELECT * FROM (
        SELECT 'e' || e.id AS key, e.last_name, e.first_name, COALESCE(u.job_title, e.position) AS job_title, COALESCE(d.name, e.department) AS department, d.code AS department_code,
               COALESCE(NULLIF(u.phone, ''), NULLIF(e.phone, '')) AS phone, COALESCE(u.email, e.email) AS email, u.username, (u.id IS NOT NULL AND u.active) AS has_account
          FROM employees e
          LEFT JOIN users u ON u.employee_id = e.id
          LEFT JOIN hr_departments d ON d.hotel_id = e.hotel_id AND d.code = e.department
         WHERE e.hotel_id = $1 AND e.status = 'active'
        UNION ALL
        SELECT 'u' || u.id, COALESCE(u.last_name, u.full_name), u.first_name, u.job_title, d.name, d.code, NULLIF(u.phone, ''), u.email, u.username, true
          FROM users u JOIN roles r ON r.id = u.role_id LEFT JOIN hr_departments d ON d.id = u.department_id
         WHERE u.hotel_id = $1 AND u.active AND u.employee_id IS NULL AND r.code NOT IN ('kiosk', 'hr_terminal')) x
      ORDER BY department NULLS LAST, last_name, first_name`, [req.user!.hotelId]));

  // ===================================================== Utilisateurs =====================================================
  app.get('/api/admin/users', { preHandler: requirePerm('users.manage') }, async (req) => {
    const f = z.object({ q: z.string().max(80).optional(), status: z.enum(['active', 'disabled', 'locked', 'all']).default('all'), role: z.string().max(40).optional(), department_id: z.coerce.number().int().optional() }).parse(req.query);
    const where = ['u.hotel_id = $1'];
    const p: unknown[] = [req.user!.hotelId];
    if (f.q) { p.push(`%${f.q.toLowerCase()}%`); where.push(`(lower(u.username) LIKE $${p.length} OR lower(u.full_name) LIKE $${p.length} OR lower(coalesce(u.email,'')) LIKE $${p.length} OR lower(coalesce(u.job_title,'')) LIKE $${p.length})`); }
    if (f.status === 'active') where.push('u.active'); else if (f.status === 'disabled') where.push('NOT u.active'); else if (f.status === 'locked') where.push('u.locked_until > now()');
    if (f.role) { p.push(f.role); where.push(`r.code = $${p.length}`); }
    if (f.department_id) { p.push(f.department_id); where.push(`u.department_id = $${p.length}`); }
    return q(getPool(), `SELECT ${USER_COLS} ${USER_FROM} WHERE ${where.join(' AND ')} ORDER BY u.active DESC, u.full_name`, p);
  });
  /** Liste courte (nom seulement) pour les sélecteurs : filtres du journal, responsables de départements / services. */
  app.get('/api/admin/users-brief', { preHandler: needAny('users.manage', 'audit.view', 'departments.manage', 'settings.manage', 'services.manage') }, async (req) =>
    q(getPool(), `SELECT u.id, u.full_name, u.username, u.department_id, d.name AS department_name, u.active FROM users u LEFT JOIN hr_departments d ON d.id = u.department_id WHERE u.hotel_id = $1 ORDER BY u.active DESC, u.full_name`, [req.user!.hotelId]));
  app.get('/api/admin/users/:id', { preHandler: requirePerm('users.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const u = await loadUser(getPool(), req.user!.hotelId, id);
    const activity = await q<any>(getPool(), `SELECT id, created_at, action, entity, entity_id, result, ip FROM audit_logs WHERE user_id = $1 ORDER BY id DESC LIMIT 60`, [id]);
    const sessions = await q<any>(getPool(), `SELECT left(s.id, 12) AS ref, s.ip, s.user_agent, s.created_at, s.last_seen_at, s.expires_at, d.name AS device FROM sessions s LEFT JOIN devices d ON d.id = s.device_id
       WHERE s.user_id = $1 AND NOT s.revoked AND s.expires_at > now() ORDER BY s.last_seen_at DESC`, [id]);
    return { ...u, activity: activity.map((a) => ({ ...a, module: moduleOfEntity(a.entity, a.action) })), sessions };
  });

  const UserBody = z.object({
    first_name: z.string().trim().min(1).max(60), last_name: z.string().trim().min(1).max(60),
    username: z.string().trim().min(3).max(40).regex(/^[A-Za-z0-9._-]+$/, 'Identifiant : lettres, chiffres, . _ -'),
    email: opt(z.string().max(120)).refine((v) => !v || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), 'E-mail invalide'),
    phone: opt(z.string().max(40)), job_title: opt(z.string().max(80)), department_id: z.number().int().positive().nullish(),
    role: z.string().min(2).max(40), language: z.enum(['fr', 'ar', 'en']).default('fr'),
  });
  app.post('/api/admin/users', { preHandler: requirePerm('users.manage') }, async (req, rep) => {
    const b = UserBody.extend({ password: z.string().max(200), must_change_password: z.boolean().default(true) }).parse(req.body);
    const h = req.user!.hotelId;
    const err = validatePasswordStrength(b.password, (await securityOf(h)).password_min_length);
    if (err) throw badRequest(err);
    const u = await tx(async (c) => {
      const role = await one<any>(c, 'SELECT id FROM roles WHERE code = $1', [b.role]);
      if (!role) throw badRequest('Rôle inconnu.');
      await assertCanGrant(req, c, role.id);
      if (await one(c, 'SELECT 1 FROM users WHERE lower(username) = lower($1)', [b.username])) throw conflict('Identifiant déjà utilisé.');
      if (b.email && await one(c, 'SELECT 1 FROM users WHERE lower(email) = lower($1)', [b.email])) throw conflict('Cette adresse e-mail est déjà associée à un compte.');
      if (b.department_id && !(await one(c, 'SELECT 1 FROM hr_departments WHERE id = $1 AND hotel_id = $2 AND active', [b.department_id, h]))) throw badRequest('Département inconnu ou désactivé.');
      const r = await one<any>(c, `INSERT INTO users (hotel_id, username, full_name, first_name, last_name, email, phone, job_title, department_id, password_hash, role_id, language, must_change_password, created_by, password_changed_at)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,now()) RETURNING id`,
        [h, b.username, `${b.first_name} ${b.last_name}`, b.first_name, b.last_name, b.email ?? null, b.phone ?? null, b.job_title ?? null, b.department_id ?? null, await hashPassword(b.password), role.id, b.language, b.must_change_password, req.user!.id]);
      await audit(c, actorOf(req), 'create', 'user', r.id, null, { username: b.username, role: b.role, department_id: b.department_id ?? null, email: b.email ?? null });
      return r;
    });
    rep.code(201);
    return loadUser(getPool(), h, u.id);
  });
  app.patch('/api/admin/users/:id', { preHandler: requirePerm('users.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = UserBody.partial().parse(req.body);
    const h = req.user!.hotelId;
    await tx(async (c) => {
      const cur = await one<any>(c, `SELECT u.*, r.code AS role FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1 AND u.hotel_id = $2 FOR UPDATE OF u`, [id, h]);
      if (!cur) throw notFound('Utilisateur introuvable');
      assertCanTouch(req, cur);
      let roleId = cur.role_id;
      if (b.role && b.role !== cur.role) {
        if (cur.protected) throw forbidden('Le rôle du compte administrateur principal ne peut pas être changé.');
        if (id === req.user!.id) throw forbidden('Vous ne pouvez pas modifier votre propre rôle.');
        const role = await one<any>(c, 'SELECT id FROM roles WHERE code = $1', [b.role]);
        if (!role) throw badRequest('Rôle inconnu.');
        await assertCanGrant(req, c, role.id);
        roleId = role.id;
      }
      if (b.username && b.username.toLowerCase() !== cur.username.toLowerCase() && await one(c, 'SELECT 1 FROM users WHERE lower(username) = lower($1) AND id <> $2', [b.username, id])) throw conflict('Identifiant déjà utilisé.');
      if (b.email && await one(c, 'SELECT 1 FROM users WHERE lower(email) = lower($1) AND id <> $2', [b.email, id])) throw conflict('Cette adresse e-mail est déjà associée à un compte.');
      if (b.department_id && b.department_id !== cur.department_id && !(await one(c, 'SELECT 1 FROM hr_departments WHERE id = $1 AND hotel_id = $2 AND active', [b.department_id, h]))) throw badRequest('Département inconnu ou désactivé.');
      const m = { ...cur, ...Object.fromEntries(Object.entries(b).filter(([, v]) => v !== undefined)) };
      await c.query(`UPDATE users SET username = $2, first_name = $3, last_name = $4, full_name = $5, email = $6, phone = $7, job_title = $8, department_id = $9, role_id = $10, language = $11 WHERE id = $1`,
        [id, m.username, m.first_name, m.last_name, `${m.first_name ?? ''} ${m.last_name ?? ''}`.trim() || cur.full_name, m.email, m.phone, m.job_title, m.department_id, roleId, m.language]);
      if (roleId !== cur.role_id) await c.query('UPDATE sessions SET last_seen_at = last_seen_at WHERE user_id = $1', [id]); // droits rechargés à la requête suivante
      const pick = (x: any) => ({ username: x.username, first_name: x.first_name, last_name: x.last_name, email: x.email, phone: x.phone, job_title: x.job_title, department_id: x.department_id, role: x.role, language: x.language });
      await audit(c, actorOf(req), roleId !== cur.role_id ? 'role_change' : 'update', 'user', id, pick(cur), pick({ ...m, role: b.role ?? cur.role }));
    });
    return loadUser(getPool(), h, id);
  });
  app.post('/api/admin/users/:id/status', { preHandler: requirePerm('users.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ active: z.boolean(), reason: z.string().trim().max(300).optional() }).parse(req.body);
    await tx(async (c) => {
      const cur = await one<any>(c, `SELECT u.*, r.code AS role FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1 AND u.hotel_id = $2 FOR UPDATE OF u`, [id, req.user!.hotelId]);
      if (!cur) throw notFound('Utilisateur introuvable');
      assertCanTouch(req, cur);
      if (!b.active && cur.protected) throw forbidden('Le compte administrateur principal ne peut pas être désactivé.');
      if (!b.active && id === req.user!.id) throw forbidden('Vous ne pouvez pas désactiver votre propre compte.');
      if (!b.active && !b.reason) throw badRequest('Indiquez le motif de la désactivation.');
      if (cur.active === b.active) return;
      await c.query(`UPDATE users SET active = $2, disabled_at = CASE WHEN $2 THEN NULL ELSE now() END, disabled_by = CASE WHEN $2 THEN NULL ELSE $3::int END,
          disabled_reason = CASE WHEN $2 THEN NULL ELSE $4 END, failed_logins = 0, locked_until = NULL WHERE id = $1`, [id, b.active, req.user!.id, b.reason ?? null]);
      // désactivation : toutes les sessions sont fermées immédiatement
      if (!b.active) await c.query('UPDATE sessions SET revoked = true WHERE user_id = $1', [id]);
      await audit(c, actorOf(req), b.active ? 'reactivate' : 'deactivate', 'user', id, { active: cur.active }, { active: b.active, reason: b.reason ?? null });
    });
    return loadUser(getPool(), req.user!.hotelId, id);
  });
  /** Code de réinitialisation à usage unique : affiché une seule fois à l'administrateur, stocké haché, expirant. */
  app.post('/api/admin/users/:id/reset-code', { preHandler: requirePerm('users.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const cur = await one<any>(getPool(), `SELECT u.*, r.code AS role FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1 AND u.hotel_id = $2`, [id, req.user!.hotelId]);
    if (!cur) throw notFound('Utilisateur introuvable');
    assertCanTouch(req, cur);
    if (!cur.active) throw badRequest('Réactivez d\'abord le compte.');
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const code = [...randomBytes(10)].map((x) => alphabet[x % alphabet.length]).join('');
    const minutes = Number((await securityOf(req.user!.hotelId)).reset_code_minutes ?? 30);
    await getPool().query(`UPDATE users SET reset_code_hash = $2, reset_expires_at = now() + ($3 || ' minutes')::interval, reset_attempts = 0 WHERE id = $1`, [id, sha256(code), String(minutes)]);
    await audit(getPool(), actorOf(req), 'password_reset_code', 'user', id, null, { expires_minutes: minutes });
    return { code, expires_minutes: minutes, username: cur.username };
  });
  app.post('/api/admin/users/:id/unlock', { preHandler: requirePerm('users.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const cur = await loadUser(getPool(), req.user!.hotelId, id);
    assertCanTouch(req, cur);
    await getPool().query('UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = $1', [id]);
    await audit(getPool(), actorOf(req), 'unlock', 'user', id);
    return { ok: true };
  });
  app.post('/api/admin/users/:id/logout-all', { preHandler: needAny('users.manage', 'security.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const cur = await loadUser(getPool(), req.user!.hotelId, id);
    assertCanTouch(req, cur);
    const r = await getPool().query('UPDATE sessions SET revoked = true WHERE user_id = $1 AND NOT revoked', [id]);
    await audit(getPool(), actorOf(req), 'sessions_revoke', 'user', id, null, { count: r.rowCount });
    return { revoked: r.rowCount };
  });

  // ===================================================== Rôles & permissions =====================================================
  app.get('/api/admin/permissions', { preHandler: needAny('roles.manage', 'users.manage') }, async () => {
    const rows = await q<any>(getPool(), 'SELECT id, code, description, sensitive FROM permissions ORDER BY code');
    return { modules: MODULES, permissions: rows.map((p) => ({ ...p, module: p.code.split('.')[0], action: actionOf(p.code), description: p.description ?? PERMISSIONS[p.code] ?? p.code })) };
  });
  app.get('/api/admin/roles', { preHandler: needAny('roles.manage', 'users.manage') }, async () =>
    q(getPool(), `SELECT r.*, (SELECT count(*)::int FROM users u WHERE u.role_id = r.id AND u.active) AS users_active, (SELECT count(*)::int FROM users u WHERE u.role_id = r.id) AS users_total,
        COALESCE((SELECT array_agg(p.code ORDER BY p.code) FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = r.id), '{}') AS permissions
      FROM roles r ORDER BY r.active DESC, r.builtin DESC, r.name`));
  app.get('/api/admin/roles/:id/users', { preHandler: needAny('roles.manage', 'users.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    return q(getPool(), `SELECT ${USER_COLS} ${USER_FROM} WHERE u.role_id = $1 AND u.hotel_id = $2 ORDER BY u.active DESC, u.full_name`, [id, req.user!.hotelId]);
  });
  const RoleBody = z.object({ name: z.string().trim().min(2).max(80), description: opt(z.string().max(300)), permissions: z.array(z.string().max(60)).max(300) });
  async function setRolePerms(req: FastifyRequest, c: Db, roleId: number, perms: string[], before: string[]) {
    const known = new Set((await q<any>(c, 'SELECT code FROM permissions')).map((p) => p.code));
    const unknown = perms.filter((p) => !known.has(p));
    if (unknown.length) throw badRequest(`Permissions inconnues : ${unknown.join(', ')}`);
    // on ne peut ajouter ou retirer que des droits que l'on possède soi-même
    if (!isSuper(req)) {
      const touched = [...perms.filter((p) => !before.includes(p)), ...before.filter((p) => !perms.includes(p))];
      const bad = touched.filter((p) => !req.user!.perms.has(p));
      if (bad.length) throw forbidden(`Vous ne pouvez pas accorder ou retirer des droits que vous ne possédez pas : ${bad.slice(0, 5).join(', ')}`);
    }
    await c.query('DELETE FROM role_permissions WHERE role_id = $1', [roleId]);
    await c.query(`INSERT INTO role_permissions (role_id, permission_id) SELECT $1, id FROM permissions WHERE code = ANY($2::text[])`, [roleId, [...new Set(perms)]]);
  }
  const permsOf = async (c: Db, roleId: number) => (await q<any>(c, 'SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = $1 ORDER BY 1', [roleId])).map((p) => p.code);
  app.post('/api/admin/roles', { preHandler: requirePerm('roles.manage') }, async (req, rep) => {
    const b = RoleBody.extend({ code: z.string().trim().toLowerCase().regex(/^[a-z][a-z0-9_]{1,39}$/, 'Code : minuscules, chiffres et _'), copy_from: z.number().int().positive().optional() }).parse(req.body);
    const r = await tx(async (c) => {
      if (await one(c, 'SELECT 1 FROM roles WHERE code = $1', [b.code])) throw conflict('Code de rôle déjà utilisé.');
      const r = await one<any>(c, `INSERT INTO roles (code, name, description, builtin, active, customized) VALUES ($1,$2,$3,false,true,true) RETURNING *`, [b.code, b.name, b.description ?? null]);
      const perms = b.copy_from ? await permsOf(c, b.copy_from) : b.permissions;
      await setRolePerms(req, c, r.id, perms, []);
      await audit(c, actorOf(req), b.copy_from ? 'duplicate' : 'create', 'role', r.id, null, { code: b.code, name: b.name, copy_from: b.copy_from ?? null, permissions: perms });
      return r;
    });
    rep.code(201);
    return r;
  });
  app.put('/api/admin/roles/:id', { preHandler: requirePerm('roles.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = RoleBody.parse(req.body);
    return tx(async (c) => {
      const cur = await one<any>(c, 'SELECT * FROM roles WHERE id = $1 FOR UPDATE', [id]);
      if (!cur) throw notFound('Rôle introuvable');
      if (cur.code === 'admin') throw forbidden('Le rôle Super administrateur est verrouillé : il possède toujours tous les droits.');
      if (req.user!.role === cur.code && !isSuper(req)) throw forbidden('Vous ne pouvez pas modifier votre propre rôle.');
      const before = await permsOf(c, id);
      await setRolePerms(req, c, id, b.permissions, before);
      await c.query(`UPDATE roles SET name = $2, description = $3, customized = true, updated_at = now() WHERE id = $1`, [id, b.name, b.description ?? null]);
      await audit(c, actorOf(req), 'permissions_change', 'role', id, { name: cur.name, permissions: before }, { name: b.name, permissions: [...new Set(b.permissions)].sort(),
        added: b.permissions.filter((p) => !before.includes(p)), removed: before.filter((p) => !b.permissions.includes(p)) });
      return { ok: true };
    });
  });
  app.post('/api/admin/roles/:id/status', { preHandler: requirePerm('roles.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ active: z.boolean() }).parse(req.body);
    return tx(async (c) => {
      const cur = await one<any>(c, 'SELECT * FROM roles WHERE id = $1 FOR UPDATE', [id]);
      if (!cur) throw notFound('Rôle introuvable');
      if (cur.code === 'admin') throw forbidden('Le rôle Super administrateur ne peut pas être désactivé.');
      if (!b.active) {
        const n = (await one<any>(c, 'SELECT count(*)::int AS n FROM users WHERE role_id = $1 AND active', [id])).n;
        if (n) throw conflict(`Ce rôle est encore attribué à ${n} utilisateur(s) actif(s) : changez-leur de rôle avant de le désactiver.`);
      }
      await c.query('UPDATE roles SET active = $2, updated_at = now() WHERE id = $1', [id, b.active]);
      await audit(c, actorOf(req), b.active ? 'reactivate' : 'deactivate', 'role', id, { active: cur.active }, { active: b.active });
      return { ok: true };
    });
  });

  // ===================================================== Départements =====================================================
  app.get('/api/admin/departments', { preHandler: needAny('departments.manage', 'users.manage', 'admin.view') }, async (req) =>
    q(getPool(), `SELECT d.*, mu.full_name AS manager_name,
        (SELECT count(*)::int FROM users u WHERE u.department_id = d.id AND u.active) AS users_active,
        (SELECT count(*)::int FROM employees e WHERE e.hotel_id = d.hotel_id AND e.department = d.code AND e.status = 'active') AS employees_active
      FROM hr_departments d LEFT JOIN users mu ON mu.id = d.manager_user_id WHERE d.hotel_id = $1 ORDER BY d.active DESC, d.sort_order, d.name`, [req.user!.hotelId]));
  app.get('/api/admin/departments/:id/members', { preHandler: needAny('departments.manage', 'users.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const d = await one<any>(getPool(), 'SELECT * FROM hr_departments WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!d) throw notFound('Département introuvable');
    return {
      users: await q(getPool(), `SELECT ${USER_COLS} ${USER_FROM} WHERE u.department_id = $1 ORDER BY u.active DESC, u.full_name`, [id]),
      employees: await q(getPool(), `SELECT id, matricule, first_name, last_name, position, status FROM employees WHERE hotel_id = $1 AND department = $2 ORDER BY status, last_name`, [req.user!.hotelId, d.code]).catch(() => []),
    };
  });
  const DeptBody = z.object({ name: z.string().trim().min(2).max(80), description: opt(z.string().max(300)), manager_user_id: z.number().int().positive().nullish() });
  app.post('/api/admin/departments', { preHandler: requirePerm('departments.manage') }, async (req, rep) => {
    const b = DeptBody.extend({ code: z.string().trim().toLowerCase().regex(/^[a-z][a-z0-9_]{1,23}$/, 'Code : minuscules, chiffres et _') }).parse(req.body);
    const h = req.user!.hotelId;
    if (await one(getPool(), 'SELECT 1 FROM hr_departments WHERE hotel_id = $1 AND lower(code) = $2', [h, b.code])) throw conflict('Code de département déjà utilisé.');
    if (await one(getPool(), 'SELECT 1 FROM hr_departments WHERE hotel_id = $1 AND lower(name) = lower($2)', [h, b.name])) throw conflict('Un département porte déjà ce nom.');
    if (b.manager_user_id && !(await one(getPool(), 'SELECT 1 FROM users WHERE id = $1 AND hotel_id = $2 AND active', [b.manager_user_id, h]))) throw badRequest('Responsable inconnu ou inactif.');
    const r = await one<any>(getPool(), `INSERT INTO hr_departments (hotel_id, code, name, description, manager_user_id, sort_order) VALUES ($1,$2,$3,$4,$5,100) RETURNING *`, [h, b.code, b.name, b.description ?? null, b.manager_user_id ?? null]);
    await audit(getPool(), actorOf(req), 'create', 'department', r.id, null, r);
    rep.code(201);
    return r;
  });
  app.patch('/api/admin/departments/:id', { preHandler: requirePerm('departments.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = DeptBody.partial().extend({ active: z.boolean().optional() }).parse(req.body);
    return tx(async (c) => {
      const cur = await one<any>(c, 'SELECT * FROM hr_departments WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!cur) throw notFound('Département introuvable');
      if (b.name && await one(c, 'SELECT 1 FROM hr_departments WHERE hotel_id = $1 AND lower(name) = lower($2) AND id <> $3', [req.user!.hotelId, b.name, id])) throw conflict('Un département porte déjà ce nom.');
      if (b.manager_user_id && !(await one(c, 'SELECT 1 FROM users WHERE id = $1 AND hotel_id = $2 AND active', [b.manager_user_id, req.user!.hotelId]))) throw badRequest('Responsable inconnu ou inactif.');
      if (b.active === false) {
        const n = (await one<any>(c, `SELECT (SELECT count(*) FROM users WHERE department_id = $1 AND active) + (SELECT count(*) FROM employees WHERE hotel_id = $2 AND department = $3 AND status = 'active') AS n`, [id, req.user!.hotelId, cur.code])).n;
        if (Number(n)) throw conflict(`Ce département compte encore ${n} membre(s) actif(s) : réaffectez-les avant de le désactiver.`);
      }
      const m = { ...cur, ...Object.fromEntries(Object.entries(b).filter(([, v]) => v !== undefined)) };
      const r = await one<any>(c, 'UPDATE hr_departments SET name = $2, description = $3, manager_user_id = $4, active = $5 WHERE id = $1 RETURNING *', [id, m.name, m.description, m.manager_user_id, m.active]);
      await audit(c, actorOf(req), b.active === false ? 'deactivate' : b.active === true && !cur.active ? 'reactivate' : 'update', 'department', id, cur, r);
      return r;
    });
  });
  app.post('/api/admin/departments/:id/assign', { preHandler: requirePerm('departments.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ user_ids: z.array(z.number().int().positive()).min(1).max(200) }).parse(req.body);
    return tx(async (c) => {
      const d = await one<any>(c, 'SELECT * FROM hr_departments WHERE id = $1 AND hotel_id = $2 AND active', [id, req.user!.hotelId]);
      if (!d) throw notFound('Département introuvable ou désactivé');
      const r = await c.query('UPDATE users SET department_id = $1 WHERE id = ANY($2::int[]) AND hotel_id = $3', [id, b.user_ids, req.user!.hotelId]);
      await audit(c, actorOf(req), 'assign', 'department', id, null, { user_ids: b.user_ids });
      return { assigned: r.rowCount };
    });
  });

  // ===================================================== Établissement =====================================================
  app.get('/api/admin/hotel', { preHandler: needAny('settings.manage', 'admin.view') }, async (req) => {
    const h = req.user!.hotelId;
    const hotel = await one<any>(getPool(), 'SELECT * FROM hotels WHERE id = $1', [h]);
    const s = await getSettings(getPool(), h);
    const counts = await one<any>(getPool(), `SELECT (SELECT count(*)::int FROM rooms WHERE hotel_id = $1 AND active) AS rooms, (SELECT count(*)::int FROM floors WHERE hotel_id = $1) AS floors,
        (SELECT count(*)::int FROM room_types WHERE hotel_id = $1 AND active) AS room_types,
        (SELECT COALESCE(sum(COALESCE(r.capacity, t.capacity)), 0)::int FROM rooms r JOIN room_types t ON t.id = r.room_type_id WHERE r.hotel_id = $1 AND r.active) AS capacity,
        (SELECT count(*)::int FROM services WHERE hotel_id = $1 AND active) AS services`, [h]).catch(async () => one<any>(getPool(), `SELECT (SELECT count(*)::int FROM rooms WHERE hotel_id = $1) AS rooms, (SELECT count(*)::int FROM floors WHERE hotel_id = $1) AS floors,
        (SELECT count(*)::int FROM room_types WHERE hotel_id = $1) AS room_types, null::int AS capacity, (SELECT count(*)::int FROM services WHERE hotel_id = $1 AND active) AS services`, [h]));
    return { hotel, counts, check_in_time: s.check_in_time, check_out_time: s.check_out_time, timezones: (Intl as any).supportedValuesOf?.('timeZone') ?? [config.timezone] };
  });
  const HotelBody = z.object({
    name: z.string().trim().min(2).max(120), commercial_name: opt(z.string().max(120)), description: opt(z.string().max(2000)), category: opt(z.string().max(60)),
    stars: z.number().int().min(0).max(5).nullish(), address: opt(z.string().max(200)), city: opt(z.string().max(80)), postal_code: opt(z.string().max(20)), country: opt(z.string().max(80)),
    phone: opt(z.string().max(40)), email: opt(z.string().max(120)).refine((v) => !v || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), 'E-mail invalide'), website: opt(z.string().max(200)),
    nif: opt(z.string().max(40)), nis: opt(z.string().max(40)), rc: opt(z.string().max(40)), art: opt(z.string().max(40)),
    restaurants_count: z.number().int().min(0).max(50).nullish(),
    check_in_time: z.string().regex(/^\d{2}:\d{2}$/), check_out_time: z.string().regex(/^\d{2}:\d{2}$/),
    timezone: z.string().max(60).refine((tz) => { try { new Intl.DateTimeFormat('fr', { timeZone: tz }); return true; } catch { return false; } }, 'Fuseau horaire inconnu'),
    primary_language: z.enum(['fr', 'ar', 'en']), languages: z.array(z.enum(['fr', 'ar', 'en'])).min(1),
    date_format: z.enum(['DD/MM/YYYY', 'YYYY-MM-DD', 'MM/DD/YYYY']), time_format: z.enum(['24h', '12h']),
  });
  app.put('/api/admin/hotel', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const b = HotelBody.parse(req.body);
    if (!b.languages.includes(b.primary_language)) throw badRequest('La langue principale doit faire partie des langues disponibles.');
    const h = req.user!.hotelId;
    await tx(async (c) => {
      const before = await one<any>(c, 'SELECT * FROM hotels WHERE id = $1 FOR UPDATE', [h]);
      const s = await getSettings(c, h);
      await c.query(`UPDATE hotels SET name=$2, commercial_name=$3, description=$4, category=$5, stars=$6, address=$7, city=$8, postal_code=$9, country=$10, phone=$11, email=$12, website=$13,
          nif=$14, nis=$15, rc=$16, art=$17, restaurants_count=$18, timezone=$19, primary_language=$20, languages=$21, date_format=$22, time_format=$23, updated_at=now() WHERE id = $1`,
        [h, b.name, b.commercial_name ?? null, b.description ?? null, b.category ?? null, b.stars ?? null, b.address ?? null, b.city ?? null, b.postal_code ?? null, b.country ?? null, b.phone ?? null,
          b.email ?? null, b.website ?? null, b.nif ?? null, b.nis ?? null, b.rc ?? null, b.art ?? null, b.restaurants_count ?? null, b.timezone, b.primary_language, b.languages, b.date_format, b.time_format]);
      await setSetting(c, h, 'check_in_time', b.check_in_time);
      await setSetting(c, h, 'check_out_time', b.check_out_time);
      if (b.primary_language !== s.default_guest_language) await setSetting(c, h, 'default_guest_language', b.primary_language);
      const { logo_id: _l, created_at: _c, updated_at: _u, ...prev } = before;
      await audit(c, actorOf(req), 'update', 'hotel', h, { ...prev, check_in_time: s.check_in_time, check_out_time: s.check_out_time }, b);
    });
    config.timezone = b.timezone; currency.tz = b.timezone; // appliqué immédiatement (dates du jour, rapports, planificateur)
    return one(getPool(), 'SELECT * FROM hotels WHERE id = $1', [h]);
  });
  app.post('/api/admin/hotel/logo', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const file = await (req as any).file({ limits: { fileSize: 1024 * 1024 } });
    if (!file) throw badRequest('Aucun fichier reçu.');
    const buf: Buffer = await file.toBuffer().catch(() => { throw badRequest('Logo trop lourd (1 Mo maximum).'); });
    if (file.file?.truncated) throw badRequest('Logo trop lourd (1 Mo maximum).');
    const png = buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
    const jpg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
    if (!png && !jpg) throw badRequest('Format refusé : PNG ou JPEG uniquement.');
    return tx(async (c) => {
      const before = await one<any>(c, 'SELECT logo_id FROM hotels WHERE id = $1 FOR UPDATE', [req.user!.hotelId]);
      const l = await one<any>(c, 'INSERT INTO hotel_logos (hotel_id, mime, data, size_bytes, created_by) VALUES ($1,$2,$3,$4,$5) RETURNING id', [req.user!.hotelId, png ? 'image/png' : 'image/jpeg', buf, buf.length, req.user!.id]);
      await c.query('UPDATE hotels SET logo_id = $2, updated_at = now() WHERE id = $1', [req.user!.hotelId, l.id]);
      await audit(c, actorOf(req), 'logo', 'hotel', req.user!.hotelId, { logo_id: before.logo_id }, { logo_id: l.id, size: buf.length });
      return { logo_id: l.id };
    });
  });
  app.delete('/api/admin/hotel/logo', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const before = await one<any>(getPool(), 'SELECT logo_id FROM hotels WHERE id = $1', [req.user!.hotelId]);
    await getPool().query('UPDATE hotels SET logo_id = NULL, updated_at = now() WHERE id = $1', [req.user!.hotelId]);
    await audit(getPool(), actorOf(req), 'logo_remove', 'hotel', req.user!.hotelId, { logo_id: before?.logo_id }, { logo_id: null });
    return { ok: true };
  });
  /** Logo (public : affiché sur l'écran de connexion et les documents). Les anciennes versions restent disponibles pour les documents déjà émis. */
  app.get('/api/hotel/logo/:id?', async (req, rep) => {
    const { id } = z.object({ id: z.coerce.number().int().positive().optional() }).parse(req.params);
    const l = await one<any>(getPool(), id ? 'SELECT mime, data FROM hotel_logos WHERE id = $1' : 'SELECT l.mime, l.data FROM hotels h JOIN hotel_logos l ON l.id = h.logo_id ORDER BY h.id LIMIT 1', id ? [id] : []);
    if (!l) throw notFound('Aucun logo');
    rep.header('content-type', l.mime).header('cache-control', id ? 'private, max-age=86400' : 'no-cache');
    return rep.send(l.data);
  });
  app.get('/api/hotel/public', async () => one(getPool(), `SELECT name, commercial_name, logo_id, primary_language, languages FROM hotels ORDER BY id LIMIT 1`));

  // ===================================================== Finances & taxes =====================================================
  app.get('/api/admin/finance', { preHandler: needAny('settings.manage', 'admin.view') }, async (req) => {
    const h = req.user!.hotelId;
    const hotel = await one<any>(getPool(), 'SELECT currency, currency_symbol, nif, nis, rc, art FROM hotels WHERE id = $1', [h]);
    const s = await getSettings(getPool(), h);
    return {
      currency: hotel.currency, currency_symbol: hotel.currency_symbol, fiscal: { nif: hotel.nif, nis: hotel.nis, rc: hotel.rc, art: hotel.art },
      decimals: s.rounding?.decimals ?? 2, payment_methods: s.payment_methods, invoice_footer: s.invoice_footer, vat_rate: s.vat_rate, tourist_tax_per_adult_night: s.tourist_tax_per_adult_night, tax_rates: s.tax_rates,
      taxes: await q(getPool(), `SELECT t.*, u.full_name AS created_by_name FROM tax_versions t LEFT JOIN users u ON u.id = t.created_by WHERE t.hotel_id = $1 ORDER BY t.category, t.valid_from DESC`, [h]),
      effective: await effectiveTaxes(getPool(), h, today()),
    };
  });
  const PM = z.enum(['cash', 'card', 'cheque', 'transfer', 'company_account', 'online']);
  app.put('/api/admin/finance', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const b = z.object({
      currency: z.string().trim().toUpperCase().regex(/^[A-Z]{3}$/, 'Code devise ISO à 3 lettres (DZD, EUR…)'), currency_symbol: z.string().trim().min(1).max(6),
      decimals: z.union([z.literal(0), z.literal(2)]), payment_methods: z.array(PM).min(1), invoice_footer: z.string().max(1000).default(''),
    }).parse(req.body);
    const h = req.user!.hotelId;
    await tx(async (c) => {
      const before = await one<any>(c, 'SELECT currency, currency_symbol FROM hotels WHERE id = $1 FOR UPDATE', [h]);
      const s = await getSettings(c, h);
      await c.query('UPDATE hotels SET currency = $2, currency_symbol = $3, updated_at = now() WHERE id = $1', [h, b.currency, b.currency_symbol]);
      await setSetting(c, h, 'rounding', { ...(s.rounding ?? {}), decimals: b.decimals });
      await setSetting(c, h, 'payment_methods', [...new Set(b.payment_methods)]);
      await setSetting(c, h, 'invoice_footer', b.invoice_footer);
      currency.symbol = b.currency_symbol; currency.decimals = b.decimals;
      await audit(c, actorOf(req), 'update', 'setting', 'finance', { ...before, decimals: s.rounding?.decimals, payment_methods: s.payment_methods, invoice_footer: s.invoice_footer }, b);
    });
    return { ok: true };
  });
  app.post('/api/admin/taxes', { preHandler: requirePerm('settings.manage') }, async (req, rep) => {
    const b = z.object({
      category: z.string().trim().regex(/^[a-z_]{2,30}$/), name: opt(z.string().max(80)), rate: z.number().min(0).max(100000),
      valid_from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), note: opt(z.string().max(300)),
    }).parse(req.body);
    if (b.category !== 'tourist' && b.rate > 100) throw badRequest('Un taux de TVA ne peut pas dépasser 100 %.');
    // pas de rétroactivité : une nouvelle version ne peut s'appliquer qu'à partir d'aujourd'hui
    if (b.valid_from < today()) throw badRequest('Une modification de taxe ne peut pas être rétroactive : choisissez une date d\'application à partir d\'aujourd\'hui.');
    const r = await tx(async (c) => {
      const prev = (await effectiveTaxes(c, req.user!.hotelId, b.valid_from)).find((t) => t.category === b.category) ?? null;
      const v = await recordTaxVersion(c, req.user!.hotelId, req.user!.id, b.category, b.rate, b.valid_from, b.name ?? null, b.note ?? null);
      await audit(c, actorOf(req), 'tax_version', 'tax', b.category, prev ? { rate: Number(prev.rate), valid_from: prev.valid_from } : null, { rate: b.rate, valid_from: b.valid_from, note: b.note ?? null });
      await applyEffectiveTaxes(c, req.user!.hotelId, today());
      return v;
    });
    rep.code(201);
    return r;
  });

  // ===================================================== Services (catalogue étendu) =====================================================
  app.get('/api/admin/services', { preHandler: needAny('settings.manage', 'services.manage') }, async (req) =>
    q(getPool(), `SELECT s.*, u.full_name AS manager_name FROM services s LEFT JOIN users u ON u.id = s.manager_user_id WHERE s.hotel_id = $1 ORDER BY s.active DESC, s.sort_order, s.name`, [req.user!.hotelId]));
  const SvcBody = z.object({
    code: z.string().trim().regex(/^[A-Za-z0-9_-]{1,12}$/, 'Code : 12 lettres ou chiffres max'), name: z.string().trim().min(2).max(80), description: opt(z.string().max(500)),
    category: z.enum(['breakfast', 'restaurant', 'room_service', 'spa', 'parking', 'laundry', 'transfer', 'meeting_room', 'minibar', 'other']),
    price: z.number().min(0).max(10_000_000), unit: z.enum(['unit', 'person', 'night', 'kg', 'trip', 'day']), pricing: z.enum(['fixed', 'variable', 'free', 'none']).default('fixed'),
    opening_hours: opt(z.string().max(120)), manager_user_id: z.number().int().positive().nullish(), active: z.boolean().default(true),
  });
  app.post('/api/admin/services', { preHandler: needAny('settings.manage', 'services.manage') }, async (req, rep) => {
    const b = SvcBody.parse(req.body);
    if (await one(getPool(), 'SELECT 1 FROM services WHERE hotel_id = $1 AND upper(code) = upper($2)', [req.user!.hotelId, b.code])) throw conflict('Code de service déjà utilisé.');
    const r = await one<any>(getPool(), `INSERT INTO services (hotel_id, code, name, description, category, price, unit, pricing, opening_hours, manager_user_id, active) VALUES ($1,upper($2),$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [req.user!.hotelId, b.code, b.name, b.description ?? null, b.category, b.pricing === 'free' ? 0 : b.price, b.unit, b.pricing, b.opening_hours ?? null, b.manager_user_id ?? null, b.active]);
    await audit(getPool(), actorOf(req), 'create', 'service', r.id, null, r);
    rep.code(201);
    return r;
  });
  app.patch('/api/admin/services/:id', { preHandler: needAny('settings.manage', 'services.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = SvcBody.partial().parse(req.body);
    return tx(async (c) => {
      const cur = await one<any>(c, 'SELECT * FROM services WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!cur) throw notFound('Service introuvable');
      const m = { ...cur, ...Object.fromEntries(Object.entries(b).filter(([, v]) => v !== undefined)) };
      const r = await one<any>(c, `UPDATE services SET code = upper($2), name = $3, description = $4, category = $5, price = $6, unit = $7, pricing = $8, opening_hours = $9, manager_user_id = $10, active = $11 WHERE id = $1 RETURNING *`,
        [id, m.code, m.name, m.description, m.category, m.pricing === 'free' ? 0 : m.price, m.unit, m.pricing, m.opening_hours, m.manager_user_id, m.active]);
      await audit(c, actorOf(req), 'update', 'service', id, cur, r);
      return r;
    });
  });

  // ===================================================== Documents & impression =====================================================
  app.get('/api/admin/documents', { preHandler: needAny('settings.manage', 'admin.view') }, async (req) => {
    const s = await getSettings(getPool(), req.user!.hotelId);
    return { ...s.documents, invoice_footer: s.invoice_footer };
  });
  app.put('/api/admin/documents', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const b = z.object({ invoice_paper: z.enum(['A4', 'thermal']), show_logo: z.boolean(), show_fiscal: z.boolean(), receipt_header: z.string().max(300).default(''), copies: z.number().int().min(1).max(3), invoice_footer: z.string().max(1000).default('') }).parse(req.body);
    const h = req.user!.hotelId;
    await tx(async (c) => {
      const s = await getSettings(c, h);
      const { invoice_footer, ...docs } = b;
      await setSetting(c, h, 'documents', docs);
      await setSetting(c, h, 'invoice_footer', invoice_footer);
      await audit(c, actorOf(req), 'update', 'setting', 'documents', { ...s.documents, invoice_footer: s.invoice_footer }, b);
    });
    return { ok: true };
  });

  // ===================================================== Notifications =====================================================
  app.get('/api/admin/notifications', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const s = await getSettings(getPool(), req.user!.hotelId);
    return { kinds: NOTIF_KINDS, config: s.notifications_config, roles: await q(getPool(), 'SELECT code, name FROM roles WHERE active ORDER BY name'), users: await q(getPool(), 'SELECT id, full_name, username FROM users WHERE hotel_id = $1 AND active ORDER BY full_name', [req.user!.hotelId]) };
  });
  app.put('/api/admin/notifications', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const Kind = z.object({ enabled: z.boolean(), roles: z.array(z.string().max(40)).max(40), users: z.array(z.number().int().positive()).max(200) });
    const b = z.object(Object.fromEntries(NOTIF_KINDS.map((k) => [k, Kind])) as Record<string, typeof Kind>).parse(req.body);
    const s = await getSettings(getPool(), req.user!.hotelId);
    await setSetting(getPool(), req.user!.hotelId, 'notifications_config', b);
    await audit(getPool(), actorOf(req), 'update', 'setting', 'notifications_config', s.notifications_config, b);
    return { ok: true };
  });
  app.get('/api/me/notifications', { preHandler: requireAuth }, async (req) => ({
    unread: (await one<any>(getPool(), 'SELECT count(*)::int AS n FROM user_notifications WHERE user_id = $1 AND read_at IS NULL', [req.user!.id])).n,
    items: await q(getPool(), 'SELECT id, kind, severity, title, body, link, created_at, read_at FROM user_notifications WHERE user_id = $1 ORDER BY id DESC LIMIT 40', [req.user!.id]),
  }));
  app.post('/api/me/notifications/read', { preHandler: requireAuth }, async (req) => {
    const b = z.object({ ids: z.array(z.number().int().positive()).max(200).optional(), all: z.boolean().optional() }).parse(req.body);
    const r = b.all ? await getPool().query('UPDATE user_notifications SET read_at = now() WHERE user_id = $1 AND read_at IS NULL', [req.user!.id])
      : await getPool().query('UPDATE user_notifications SET read_at = now() WHERE user_id = $1 AND id = ANY($2::bigint[]) AND read_at IS NULL', [req.user!.id, b.ids ?? []]);
    return { updated: r.rowCount };
  });

  // ===================================================== Sécurité =====================================================
  app.get('/api/admin/security', { preHandler: requirePerm('security.manage') }, async (req) => {
    const h = req.user!.hotelId;
    const s = await getSettings(getPool(), h);
    return {
      policy: s.security, session_hours: config.sessionHours, device_approval: config.requireDeviceApproval,
      sessions: await q(getPool(), `SELECT left(s.id, 12) AS ref, s.ip, s.user_agent, s.created_at, s.last_seen_at, s.expires_at, u.id AS user_id, u.username, u.full_name, r.name AS role_name, d.name AS device
          FROM sessions s JOIN users u ON u.id = s.user_id JOIN roles r ON r.id = u.role_id LEFT JOIN devices d ON d.id = s.device_id
          WHERE u.hotel_id = $1 AND NOT s.revoked AND s.expires_at > now() ORDER BY s.last_seen_at DESC LIMIT 200`, [h]),
      devices: await q(getPool(), `SELECT d.id, d.name, d.status, d.created_at, d.last_seen_at, d.approved_at, u.full_name AS approved_by FROM devices d LEFT JOIN users u ON u.id = d.approved_by WHERE d.hotel_id = $1 ORDER BY d.status = 'pending' DESC, d.last_seen_at DESC NULLS LAST`, [h]),
      locked: await q(getPool(), `SELECT id, username, full_name, locked_until FROM users WHERE hotel_id = $1 AND locked_until > now()`, [h]),
      failed_24h: await q(getPool(), `SELECT a.created_at, a.ip, a.after->>'reason' AS reason, COALESCE(u.username, a.after->>'username') AS username FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
          WHERE a.action = 'login_failed' AND a.created_at > now() - interval '24 hours' ORDER BY a.id DESC LIMIT 50`),
    };
  });
  app.put('/api/admin/security', { preHandler: requirePerm('security.manage') }, async (req) => {
    const b = z.object({
      session_idle_minutes: z.number().int().min(5).max(1440), max_failed_logins: z.number().int().min(3).max(20), lock_minutes: z.number().int().min(1).max(1440),
      password_min_length: z.number().int().min(8).max(64), reset_code_minutes: z.number().int().min(5).max(1440),
    }).parse(req.body);
    const s = await getSettings(getPool(), req.user!.hotelId);
    await setSetting(getPool(), req.user!.hotelId, 'security', b);
    clearSecurityCache();
    await audit(getPool(), actorOf(req), 'update', 'setting', 'security', s.security, b);
    return { ok: true };
  });
  app.post('/api/admin/sessions/:ref/revoke', { preHandler: requirePerm('security.manage') }, async (req) => {
    const { ref } = z.object({ ref: z.string().regex(/^[a-f0-9]{12}$/) }).parse(req.params);
    const r = await getPool().query(`UPDATE sessions s SET revoked = true FROM users u WHERE u.id = s.user_id AND u.hotel_id = $1 AND left(s.id, 12) = $2 AND NOT s.revoked RETURNING s.user_id`, [req.user!.hotelId, ref]);
    if (!r.rowCount) throw notFound('Session introuvable ou déjà fermée');
    await audit(getPool(), actorOf(req), 'session_revoke', 'session', ref, null, { user_id: r.rows[0].user_id });
    return { ok: true };
  });
  app.patch('/api/admin/devices/:id', { preHandler: needAny('security.manage', 'devices.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ name: z.string().trim().min(2).max(80) }).parse(req.body);
    const cur = await one<any>(getPool(), 'SELECT * FROM devices WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!cur) throw notFound('Appareil introuvable');
    await getPool().query('UPDATE devices SET name = $2 WHERE id = $1', [id, b.name]);
    await audit(getPool(), actorOf(req), 'rename', 'device', id, { name: cur.name }, b);
    return { ok: true };
  });

  // ===================================================== Journal d'activité =====================================================
  const AuditQ = z.object({
    user_id: z.coerce.number().int().optional(), module: z.string().max(30).optional(), action: z.string().max(40).optional(), result: z.enum(['success', 'failure', 'denied']).optional(),
    from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), q: z.string().max(80).optional(),
    page: z.coerce.number().int().min(1).default(1), size: z.coerce.number().int().min(10).max(200).default(50), format: z.enum(['pdf', 'xlsx', 'csv']).optional(),
  });
  async function auditSearch(req: FastifyRequest, f: z.infer<typeof AuditQ>, limit: number, offset: number) {
    const where = ['(a.hotel_id = $1 OR a.hotel_id IS NULL)'];
    const p: unknown[] = [req.user!.hotelId];
    const add = (sql: string, v: unknown) => { p.push(v); where.push(sql.replace('?', `$${p.length}`)); };
    if (f.user_id) add('a.user_id = ?', f.user_id);
    if (f.action) add('a.action = ?', f.action);
    if (f.result) add('a.result = ?', f.result);
    if (f.from) add(`a.created_at >= (?::date)::timestamp AT TIME ZONE '${config.timezone.replace(/'/g, '')}'`, f.from);
    if (f.to) add(`a.created_at < ((?::date) + 1)::timestamp AT TIME ZONE '${config.timezone.replace(/'/g, '')}'`, f.to);
    if (f.q) add(`(a.entity_id ILIKE ? OR a.entity ILIKE $${p.length} OR a.ip ILIKE $${p.length})`, `%${f.q}%`);
    if (f.module) {
      if (f.module === 'security') where.push(`(a.entity ~ '^(user|role|device|api|session)$' OR a.action IN ('login','logout','login_failed','permission_denied','password_reset','password_reset_failed','change_password'))`);
      else { const pat = entityPatternOf(f.module); if (!pat) throw badRequest('Module inconnu'); add('a.entity ~ ?', pat); where.push(`a.action NOT IN ('login','logout','login_failed','permission_denied')`); }
    }
    const total = (await one<any>(getPool(), `SELECT count(*)::int AS n FROM audit_logs a WHERE ${where.join(' AND ')}`, p)).n;
    p.push(limit, offset);
    const rows = await q<any>(getPool(), `SELECT a.id, a.created_at, a.action, a.entity, a.entity_id, a.before, a.after, a.ip, a.user_agent, a.result, a.user_id, u.full_name AS user_name, u.username, dv.name AS device
       FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id LEFT JOIN devices dv ON dv.id = a.device_id WHERE ${where.join(' AND ')} ORDER BY a.id DESC LIMIT $${p.length - 1} OFFSET $${p.length}`, p);
    // les anciennes lignes sont aussi masquées à l'affichage (jamais de secret en clair)
    return { total, rows: rows.map((r) => ({ ...r, module: moduleOfEntity(r.entity, r.action), before: redactSecrets(r.before), after: redactSecrets(r.after) })) };
  }
  app.get('/api/admin/audit', { preHandler: requirePerm('audit.view') }, async (req, rep) => {
    const f = AuditQ.parse(req.query);
    if (!f.format) {
      const r = await auditSearch(req, f, f.size, (f.page - 1) * f.size);
      return { ...r, page: f.page, size: f.size, modules: AUDIT_MODULES, actions: (await q<any>(getPool(), 'SELECT DISTINCT action FROM audit_logs ORDER BY 1')).map((a) => a.action) };
    }
    const r = await auditSearch(req, f, 5000, 0);
    const cols = [{ key: 'date', label: 'Date' }, { key: 'user', label: 'Utilisateur' }, { key: 'module', label: 'Module' }, { key: 'action', label: 'Action' }, { key: 'ref', label: 'Enregistrement' }, { key: 'result', label: 'Résultat' }, { key: 'ip', label: 'Poste / IP' }, { key: 'change', label: 'Détail' }];
    const RES: Record<string, string> = { success: 'Réussi', failure: 'Échec', denied: 'Refusé' };
    const rows = r.rows.map((x) => ({ date: fmtDT(x.created_at), user: x.user_name ?? x.after?.username ?? '—', module: AUDIT_MODULES[x.module] ?? x.module, action: x.action, ref: `${x.entity}${x.entity_id ? ` #${x.entity_id}` : ''}`,
      result: RES[x.result] ?? x.result, ip: x.ip ?? '', change: JSON.stringify(x.after ?? x.before ?? '').slice(0, 300) }));
    await audit(getPool(), actorOf(req), 'export', 'api', 'audit', null, { format: f.format, rows: rows.length, filters: { ...f, format: undefined } });
    const name = `journal-${today()}`;
    const sub = `${f.from ?? '…'} → ${f.to ?? '…'} · ${rows.length} ligne(s)${r.total > rows.length ? ` sur ${r.total}` : ''}`;
    if (f.format === 'csv') { rep.header('content-type', 'text/csv; charset=utf-8').header('content-disposition', `attachment; filename="${name}.csv"`); return rep.send(tableCsv(cols, rows)); }
    if (f.format === 'xlsx') { rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('content-disposition', `attachment; filename="${name}.xlsx"`); return rep.send(await tableXlsx('Journal d\'activité', sub, cols, rows)); }
    const h = await one<any>(getPool(), 'SELECT name FROM hotels WHERE id = $1', [req.user!.hotelId]);
    rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${name}.pdf"`);
    return rep.send(await tablePdf(h.name, 'Journal d\'activité', sub, cols, rows));
  });

  // ===================================================== Sauvegardes =====================================================
  app.get('/api/admin/backups', { preHandler: requirePerm('backups.manage') }, async (req) => {
    await syncRegistry();
    const s = await getSettings(getPool(), req.user!.hotelId);
    return {
      config: s.backups, dir: backupDir(),
      items: await q(getPool(), `SELECT * FROM backups ORDER BY created_at DESC LIMIT 200`),
      restores: await q(getPool(), `SELECT * FROM restores ORDER BY started_at DESC LIMIT 50`),
      tools: (await systemInfo(req.user!.hotelId, true)),
    };
  });
  // ===== Bouclier anti-robot : adresses bloquées =====
  app.get('/api/admin/ip-blocks', { preHandler: requirePerm('settings.manage') }, async () =>
    q(getPool(), `SELECT b.*, u.full_name AS lifted_by_name, (b.lifted_at IS NULL AND b.blocked_until > now()) AS active
      FROM ip_blocks b LEFT JOIN users u ON u.id = b.lifted_by ORDER BY b.created_at DESC LIMIT 100`));
  app.post('/api/admin/ip-blocks/:id/lift', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const { id } = z.object({ id: z.coerce.number().int() }).parse(req.params);
    const b = await one<any>(getPool(), `UPDATE ip_blocks SET lifted_at = now(), lifted_by = $2 WHERE id = $1 AND lifted_at IS NULL RETURNING ip`, [id, req.user!.id]);
    if (!b) throw notFound('Blocage introuvable ou déjà levé.');
    await getPool().query(`UPDATE ip_blocks SET lifted_at = now(), lifted_by = $2 WHERE ip = $1 AND lifted_at IS NULL`, [b.ip, req.user!.id]);
    lift(b.ip);
    await audit(getPool(), actorOf(req), 'ip_unblocked', 'security', b.ip, null, { ip: b.ip });
    return { ok: true };
  });

  // ===== Mises à jour en un clic =====
  const updView = async (hotelId: number) => {
    const s = await getSettings(getPool(), hotelId);
    const u = s.updates ?? {};
    const st = await updateState(hotelId);
    // version déjà installée : ne plus la proposer
    if (st.latest && cmpVersion(st.latest.version, APP_VERSION) <= 0) st.latest = null;
    return { current: APP_VERSION, state: st, supervised: supervised(), last: lastResult(),
      config: { auto_check: u.auto_check !== false, auto_install: u.auto_install === true } }; // la source (adresse, jeton) n'est jamais renvoyée : confidentielle
  };
  app.get('/api/admin/update', { preHandler: requirePerm('backups.manage') }, async (req) => updView(req.user!.hotelId));
  app.post('/api/admin/update/check', { preHandler: requirePerm('backups.manage'), config: { rateLimit: { max: 6, timeWindow: '1 minute' } } }, async (req) => {
    await checkForUpdate(req.user!.hotelId);
    return updView(req.user!.hotelId);
  });
  app.put('/api/admin/update/config', { preHandler: requirePerm('backups.manage') }, async (req) => {
    const b = z.object({ auto_check: z.boolean(), auto_install: z.boolean().optional() }).parse(req.body);
    const cur = (await getSettings(getPool(), req.user!.hotelId)).updates ?? {};
    const next = { ...cur, auto_check: b.auto_check, auto_install: b.auto_install ?? cur.auto_install ?? false };
    await setSetting(getPool(), req.user!.hotelId, 'updates', next);
    await audit(getPool(), actorOf(req), 'update', 'setting', 'updates', { auto_check: cur.auto_check, auto_install: cur.auto_install }, { auto_check: next.auto_check, auto_install: next.auto_install });
    return updView(req.user!.hotelId);
  });
  app.post('/api/admin/update/install', { preHandler: requirePerm('backups.manage'), config: { rateLimit: { max: 3, timeWindow: '1 minute' } } }, async (req) => {
    z.object({ confirm: z.literal(true) }).parse(req.body);
    const by = { id: req.user!.id, name: req.user!.fullName };
    return prepareInstall(req.user!.hotelId, by, (note) => createBackup('manual', { ...by, hotelId: req.user!.hotelId }, note));
  });
  app.put('/api/admin/backups/config', { preHandler: requirePerm('backups.manage') }, async (req) => {
    const b = z.object({ enabled: z.boolean(), frequency: z.enum(['daily', 'weekly', 'monthly']), time: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/), weekday: z.number().int().min(0).max(6), monthday: z.number().int().min(1).max(28), keep: z.number().int().min(1).max(365) }).parse(req.body);
    const s = await getSettings(getPool(), req.user!.hotelId);
    await setSetting(getPool(), req.user!.hotelId, 'backups', b);
    await audit(getPool(), actorOf(req), 'update', 'setting', 'backups', s.backups, b);
    return { ok: true };
  });
  app.post('/api/admin/backups', { preHandler: requirePerm('backups.manage') }, async (req, rep) => {
    const b = z.object({ note: opt(z.string().max(200)) }).parse(req.body ?? {});
    const r = await createBackup('manual', { id: req.user!.id, name: req.user!.fullName, hotelId: req.user!.hotelId }, b.note ?? null);
    await audit(getPool(), actorOf(req), 'backup_create', 'backup', r.file_name, null, { size: Number(r.size_bytes), sha256: r.sha256 });
    rep.code(201);
    return r;
  });
  app.post('/api/admin/backups/:file/verify', { preHandler: requirePerm('backups.manage') }, async (req) => {
    const { file } = z.object({ file: z.string().max(200) }).parse(req.params);
    backupPath(file);
    const v = await verifyFile(file);
    await getPool().query(`UPDATE backups SET verified_at = now(), verify_ok = $2, verify_detail = $3 WHERE file_name = $1`, [path.basename(file), v.ok, v.detail.join(' ')]);
    await audit(getPool(), actorOf(req), 'backup_verify', 'backup', file, null, { ok: v.ok, compatible: v.compatible }, { result: v.ok ? 'success' : 'failure' });
    return v;
  });
  /** Restauration d'essai dans une base temporaire : la base de production n'est jamais modifiée. */
  app.post('/api/admin/backups/:file/test-restore', { preHandler: requirePerm('backups.manage') }, async (req) => {
    const { file } = z.object({ file: z.string().max(200) }).parse(req.params);
    backupPath(file);
    const r = await testRestore(file);
    await getPool().query(`UPDATE backups SET verified_at = now(), verify_ok = $2, verify_detail = $3 WHERE file_name = $1`, [path.basename(file), r.ok, `Restauration d'essai : ${r.steps.join(' ')}`]);
    await audit(getPool(), actorOf(req), 'backup_test_restore', 'backup', path.basename(file), null, { ok: r.ok }, { result: r.ok ? 'success' : 'failure' });
    return r;
  });
  app.get('/api/admin/backups/:file/download', { preHandler: requirePerm('backups.restore') }, async (req, rep) => {
    const { file } = z.object({ file: z.string().max(200) }).parse(req.params);
    const f = backupPath(file);
    await audit(getPool(), actorOf(req), 'backup_download', 'backup', path.basename(f));
    rep.header('content-type', 'application/octet-stream').header('content-disposition', `attachment; filename="${path.basename(f)}"`);
    return rep.send(createReadStream(f));
  });
  app.post('/api/admin/backups/upload', { preHandler: requirePerm('backups.restore') }, async (req) => {
    const file = await (req as any).file({ limits: { fileSize: 4 * 1024 * 1024 * 1024 } });
    if (!file) throw badRequest('Aucun fichier reçu.');
    const tmp = path.join(backupDir(), `.upload-${randomUUID()}`);
    await pipeline(file.file, createWriteStream(tmp));
    const r = await importUpload(tmp, String(file.filename ?? 'import.dump'), { id: req.user!.id, name: req.user!.fullName });
    await audit(getPool(), actorOf(req), 'backup_upload', 'backup', r.file, null, { original: file.filename, compatible: r.verify.compatible });
    return r;
  });
  app.delete('/api/admin/backups/:file', { preHandler: requirePerm('backups.restore') }, async (req) => {
    const { file } = z.object({ file: z.string().max(200) }).parse(req.params);
    z.object({ confirm: z.literal('SUPPRIMER', { message: 'Confirmation requise : SUPPRIMER' }) }).parse(req.query);
    const row = await one<any>(getPool(), 'SELECT * FROM backups WHERE file_name = $1', [path.basename(file)]);
    const okCount = (await one<any>(getPool(), `SELECT count(*)::int AS n FROM backups WHERE status = 'ok' AND file_name <> $1`, [path.basename(file)])).n;
    if (!okCount) throw conflict('Impossible de supprimer la seule sauvegarde valide disponible.');
    deleteBackupFiles(file);
    await getPool().query(`UPDATE backups SET status = 'missing', note = coalesce(note || ' · ', '') || 'supprimée le ' || to_char(now(), 'DD/MM/YYYY') WHERE file_name = $1`, [path.basename(file)]);
    await audit(getPool(), actorOf(req), 'backup_delete', 'backup', path.basename(file), row ? { size: Number(row.size_bytes), created_at: row.created_at } : null);
    return { ok: true };
  });
  /** Restauration : confirmation explicite (texte RESTAURER + nom du fichier), vérification, sauvegarde de sécurité, transaction unique, contrôle. */
  app.post('/api/admin/backups/:file/restore', { preHandler: requirePerm('backups.restore') }, async (req) => {
    const { file } = z.object({ file: z.string().max(200) }).parse(req.params);
    const b = z.object({ confirm: z.string(), file_name: z.string() }).parse(req.body);
    if (b.confirm !== 'RESTAURER' || path.basename(b.file_name) !== path.basename(file)) throw badRequest('Confirmation explicite requise : saisissez RESTAURER.');
    backupPath(file);
    await audit(getPool(), actorOf(req), 'backup_restore_start', 'backup', path.basename(file));
    return restoreBackup(file, { id: req.user!.id, name: req.user!.fullName, hotelId: req.user!.hotelId });
  });
}

/** Mode maintenance (restauration) : l'API répond 503 sauf pour l'état de santé. */
export function maintenanceGuard(app: FastifyInstance, flag: { on: boolean; reason: string }) {
  app.addHook('onRequest', async (req, rep) => {
    if (!flag.on || !req.url.startsWith('/api/') || req.url.startsWith('/api/health')) return;
    rep.code(503).send({ error: 'maintenance', message: `${flag.reason || 'Maintenance en cours'}. Réessayez dans quelques instants.` });
    return rep;
  });
}
export { AppError };
