import React, { useEffect, useState } from 'react';
import { LicenseGate } from './components/LicenseGate';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { I18nProvider } from './i18n';
import { AuthProvider, ToastProvider, useAuth } from './lib/context';
import { Rooms } from './pages/Rooms';
import { FrontOffice } from './pages/FrontOffice';
import { Guests } from './pages/Guests';
import { Billing } from './pages/Billing';
import { Housekeeping } from './pages/Housekeeping';
import { Restaurant } from './pages/Restaurant';
import { Stock } from './pages/Stock';
import { Maintenance } from './pages/Maintenance';
import { ClockTerminal, Hr } from './pages/Hr';
import { Crm } from './pages/Crm';
import { Reports } from './pages/Reports';
import { NightAudit } from './pages/NightAudit';
import { Login } from './pages/Login';
import { Planning } from './pages/Planning';
import { PrintInvoice, PrintRegistration, PrintReservation } from './pages/Print';
import { Reservations } from './pages/Reservations';
import { Notifications } from './pages/Notifications';
import { Settings } from './pages/Settings';
import { Admin } from './pages/Admin';
import { Setup } from './pages/Setup';
import { get } from './lib/api';
import '@fontsource/inter/400.css';
import '@fontsource/inter/500.css';
import '@fontsource/inter/600.css';
import '@fontsource/inter/700.css';
import '@fontsource/noto-sans-arabic/400.css';
import '@fontsource/noto-sans-arabic/600.css';
import '@fontsource/noto-sans-arabic/700.css';
import './styles/app.css';

document.documentElement.dataset.theme = localStorage.getItem('kh.night') === 'true' ? 'dark' : 'light';

function Guard({ perm, children }: { perm: string | string[]; children: React.ReactElement }) {
  const { can } = useAuth();
  return ([] as string[]).concat(perm).some(can) ? children : <Navigate to={can('planning.view') ? '/planning' : can('housekeeping.view') ? '/housekeeping' : can('restaurant.view') ? '/restaurant' : can('stock.view') ? '/stock' : can('maintenance.report') ? '/maintenance' : can('hr.self') ? '/rh' : can('hr.terminal') ? '/pointage' : '/'} replace />;
}

function Root() {
  const { me, loading, can } = useAuth();
  const [setup, setSetup] = useState<boolean | null>(null);
  const [installed, setInstalled] = useState('');
  useEffect(() => { if (!me) get('/api/setup/status').then((r) => setSetup(!!r.needed)).catch(() => setSetup(false)); }, [me]);
  if (loading || (!me && setup === null)) return <div style={{ padding: 40 }}>Chargement…</div>;
  if (!me && setup) return <Setup onDone={(u) => { setSetup(false); setInstalled(u); }} />;
  if (!me) return <Login installedUser={installed} />;
  return (
    <Routes>
      <Route path="/print/reservation/:id" element={<PrintReservation />} />
      <Route path="/print/invoice/:id" element={<PrintInvoice />} />
      <Route path="/print/registration/:id" element={<PrintRegistration />} />
      <Route element={<Layout />}>
        <Route index element={<Navigate to={can('reservations.view') ? '/frontoffice' : can('planning.view') ? '/planning' : can('housekeeping.view') ? '/housekeeping' : can('restaurant.view') ? '/restaurant' : can('stock.view') ? '/stock' : can('maintenance.view') ? '/maintenance' : can('hr.self') ? '/rh' : can('hr.terminal') ? '/pointage' : '/planning'} replace />} />
        <Route path="/planning" element={<Guard perm="planning.view"><Planning /></Guard>} />
        <Route path="/reservations" element={<Guard perm="reservations.view"><Reservations /></Guard>} />
        <Route path="/settings" element={<Guard perm="settings.manage"><Settings /></Guard>} />
        <Route path="/admin" element={<Guard perm={['admin.view', 'users.manage', 'roles.manage', 'security.manage', 'audit.view', 'backups.manage', 'settings.manage']}><Admin /></Guard>} />
        <Route path="/notifications" element={<Guard perm="reservations.view"><Notifications /></Guard>} />
        <Route path="/frontoffice" element={<Guard perm="reservations.view"><FrontOffice /></Guard>} />
        <Route path="/guests" element={<Guard perm="guests.view"><Guests /></Guard>} />
        <Route path="/billing" element={<Guard perm="invoices.view"><Billing /></Guard>} />
        <Route path="/rooms" element={<Guard perm="rooms.view"><Rooms /></Guard>} />
        <Route path="/housekeeping" element={<Guard perm="housekeeping.view"><Housekeeping /></Guard>} />
        <Route path="/restaurant" element={<Guard perm="restaurant.view"><Restaurant /></Guard>} />
        <Route path="/stock" element={<Guard perm="stock.view"><Stock /></Guard>} />
        <Route path="/maintenance" element={<Guard perm="maintenance.report"><Maintenance /></Guard>} />
        <Route path="/rh" element={<Guard perm="hr.self"><Hr /></Guard>} />
        <Route path="/crm" element={<Guard perm="crm.view"><Crm /></Guard>} />
        <Route path="/rapports" element={<Guard perm="reports.view"><Reports /></Guard>} />
        <Route path="/night-audit" element={<Guard perm="nightaudit.view"><NightAudit /></Guard>} />
        <Route path="/pointage" element={<Guard perm="hr.terminal"><ClockTerminal /></Guard>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <I18nProvider>
      <ToastProvider>
        <AuthProvider>
          <BrowserRouter>
            <LicenseGate><Root /></LicenseGate>
          </BrowserRouter>
        </AuthProvider>
      </ToastProvider>
    </I18nProvider>
  </React.StrictMode>,
);
