import { CrmSummary } from './CrmCard';
import { IdScan } from './IdScan';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useI18n, type Key } from '../i18n';
import { ApiError, get, newOpKey, post, postOnce } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { addDays, diffDays, fmtDate, money, todayLocal } from '../lib/format';
import { Field, Icon, Modal } from './ui';

const toNum = (v: unknown) => {
  const n = Number(String(v ?? '').replace(/\s/g, '').replace(',', '.'));
  return Number.isFinite(n) ? n : 0;
};
const r2 = (n: number) => Math.round(n * 100) / 100;
/** Une clé d'opération par ouverture de formulaire : un double clic ou un renvoi n'enregistre qu'une fois. */
const useOpKey = () => useState(() => newOpKey())[0];
/** Écran de confirmation : ignore les clics pendant un instant (le 2e clic d'un double-clic ne doit pas y atterrir). */
function useArmed(ms = 800) {
  const [armed, setArmed] = useState(false);
  useEffect(() => { const h = setTimeout(() => setArmed(true), ms); return () => clearTimeout(h); }, []);
  return armed;
}
function DoneModal({ title, onClose, children, action }: { title: string; onClose: () => void; children: ReactNode; action?: ReactNode }) {
  const { t } = useI18n();
  const armed = useArmed();
  return (
    <Modal title={title} onClose={() => armed && onClose()} footer={<fieldset disabled={!armed} style={{ border: 0, margin: 0, padding: 0, display: 'flex', gap: 8 }}><button className="btn" onClick={onClose}>{t('common.close')}</button>{action}</fieldset>}>
      {children}
    </Modal>
  );
}

export const printRegistration = (rrId: number) => window.open(`/print/registration/${rrId}`, '_blank');
export const printInvoice = (id: number) => window.open(`/print/invoice/${id}`, '_blank');

// ===================================================== Briques =====================================================
function Steps({ steps, current }: { steps: string[]; current: number }) {
  return (
    <div className="steps" role="list">
      {steps.map((s, i) => (
        <div key={s} role="listitem" className={`step ${i === current ? 'on' : i < current ? 'done' : ''}`} aria-current={i === current ? 'step' : undefined}>
          <span className="step-n">{i < current ? '✓' : i + 1}</span><span>{s}</span>
        </div>
      ))}
    </div>
  );
}

function Sum({ label, value, strong, tone }: { label: ReactNode; value: ReactNode; strong?: boolean; tone?: 'danger' | 'ok' }) {
  return <div className={`sum-row ${strong ? 'big' : ''}`} style={tone ? { color: tone === 'danger' ? 'var(--danger)' : 'var(--ok)' } : undefined}><span>{label}</span><span>{value}</span></div>;
}

export type GuestForm = Record<string, any>;
const EMPTY_GUEST: GuestForm = { last_name: '', first_name: '', maiden_name: '', gender: '', birth_date: '', birth_place: '', birth_wilaya: '', id_doc_issued_by: '', nationality: 'Algérienne', profession: '', id_doc_type: 'cni', id_doc_number: '', id_doc_issued_on: '', id_doc_issued_place: '', id_doc_expiry: '', phone: '', email: '', address: '', city: '', country: 'Algérie', language: 'fr' };
const fromGuest = (g: any): GuestForm => Object.fromEntries(Object.keys(EMPTY_GUEST).map((k) => [k, g?.[k] ?? EMPTY_GUEST[k]]));
const guestPayload = (g: GuestForm) => Object.fromEntries(Object.entries(g).map(([k, v]) => [k, v === '' ? null : v]).filter(([k, v]) => !(k === 'gender' && !v)));
const missingIdentity = (g: GuestForm) => ['last_name', 'first_name', 'birth_date', 'nationality', 'id_doc_type', 'id_doc_number'].filter((k) => !String(g[k] ?? '').trim());

export function IdentityFields({ g, set, compact }: { g: GuestForm; set: (p: GuestForm) => void; compact?: boolean }) {
  const { t } = useI18n();
  const f = (k: string, label: Key, opts: { type?: string; req?: boolean; dir?: string } = {}) => (
    <Field label={`${t(label)}${opts.req ? ' *' : ''}`} htmlFor={`g-${k}`}>
      <input id={`g-${k}`} className="input" type={opts.type ?? 'text'} value={g[k] ?? ''} dir={opts.dir} onChange={(e) => set({ ...g, [k]: e.target.value })} />
    </Field>
  );
  return (
    <>
    <IdScan context="checkin" onFill={(x) => set({ ...g, ...Object.fromEntries(Object.entries({ last_name: x.last_name, first_name: x.first_name, gender: x.gender, birth_date: x.birth_date,
      nationality: x.nationality, id_doc_type: x.id_doc_type, id_doc_number: x.id_doc_number, id_doc_expiry: x.id_doc_expiry, country: x.issuing_country }).filter(([, v]) => v)) })} />
    <div className="form-grid">
      {f('last_name', 'id.lastName', { req: true })}
      {f('first_name', 'id.firstName', { req: true })}
      {(g.gender === 'F' || g.maiden_name) && f('maiden_name', 'id.maidenName')}
      <Field label={t('id.gender')} htmlFor="g-gender">
        <select id="g-gender" className="input" value={g.gender ?? ''} onChange={(e) => set({ ...g, gender: e.target.value })}><option value="">—</option><option value="M">M</option><option value="F">F</option></select>
      </Field>
      {f('birth_date', 'id.birthDate', { type: 'date', req: true })}
      {f('birth_place', 'id.birthPlace')}
      {f('birth_wilaya', 'id.birthWilaya')}
      {f('nationality', 'id.nationality', { req: true })}
      <Field label={`${t('id.docType')} *`} htmlFor="g-doc">
        <select id="g-doc" className="input" value={g.id_doc_type ?? 'cni'} onChange={(e) => set({ ...g, id_doc_type: e.target.value })}>
          {['cni', 'passport', 'permis', 'other'].map((x) => <option key={x} value={x}>{t(`id.${x}` as Key)}</option>)}
        </select>
      </Field>
      {f('id_doc_number', 'id.docNumber', { req: true })}
      {f('id_doc_issued_on', 'id.issuedOn', { type: 'date' })}
      {f('id_doc_issued_place', 'id.issuedPlace')}
      {f('id_doc_issued_by', 'id.issuedBy')}
      {f('id_doc_expiry', 'id.expiry', { type: 'date' })}
      {!compact && f('profession', 'id.profession')}
      {f('phone', 'id.phone', { type: 'tel' })}
      {!compact && f('email', 'id.email', { type: 'email' })}
      {!compact && f('address', 'id.address')}
      {!compact && f('city', 'id.city')}
      {!compact && f('country', 'id.country')}
      <Field label={t('id.language')} htmlFor="g-lang">
        <select id="g-lang" className="input" value={g.language ?? 'fr'} onChange={(e) => set({ ...g, language: e.target.value })}><option value="fr">Français</option><option value="ar">العربية</option><option value="en">English</option></select>
      </Field>
    </div>
    </>
  );
}

type Companion = { last_name: string; first_name: string; birth_date: string; relation: string; nationality: string; id_doc_number: string };
function Companions({ list, set, max }: { list: Companion[]; set: (l: Companion[]) => void; max: number }) {
  const { t } = useI18n();
  const upd = (i: number, p: Partial<Companion>) => set(list.map((c, j) => (j === i ? { ...c, ...p } : c)));
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      {list.map((c, i) => (
        <div key={i} className="companion">
          <input className="input" aria-label={t('id.lastName')} placeholder={`${t('id.lastName')} *`} value={c.last_name} onChange={(e) => upd(i, { last_name: e.target.value })} />
          <input className="input" aria-label={t('id.firstName')} placeholder={t('id.firstName')} value={c.first_name} onChange={(e) => upd(i, { first_name: e.target.value })} />
          <input className="input" aria-label={t('id.birthDate')} type="date" value={c.birth_date} onChange={(e) => upd(i, { birth_date: e.target.value })} />
          <input className="input" aria-label={t('ci.relation')} placeholder={t('ci.relation')} list="relations" value={c.relation} onChange={(e) => upd(i, { relation: e.target.value })} />
          <input className="input" aria-label={t('id.docNumber')} placeholder={t('id.docNumber')} value={c.id_doc_number} onChange={(e) => upd(i, { id_doc_number: e.target.value })} />
          <button className="btn ghost icon" aria-label="Retirer" onClick={() => set(list.filter((_, j) => j !== i))}><Icon name="close" /></button>
        </div>
      ))}
      <datalist id="relations">{['Conjoint(e)', 'Enfant', 'Parent', 'Frère / sœur', 'Collègue', 'Ami(e)'].map((x) => <option key={x} value={x} />)}</datalist>
      {list.length < max && (
        <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => set([...list, { last_name: '', first_name: '', birth_date: '', relation: '', nationality: '', id_doc_number: '' }])}>
          <Icon name="plus" size={16} /> {t('ci.addCompanion')}
        </button>
      )}
    </div>
  );
}
const companionsPayload = (l: Companion[]) => l.filter((c) => c.last_name.trim()).map((c) => ({ ...c, first_name: c.first_name || null, birth_date: c.birth_date || null, relation: c.relation || null, nationality: c.nationality || null, id_doc_number: c.id_doc_number || null }));

/** Zone de signature (souris, doigt ou stylet). */
export function SignaturePad({ onChange }: { onChange: (dataUrl: string | null) => void }) {
  const { t } = useI18n();
  const ref = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const dirty = useRef(false);
  useEffect(() => {
    const c = ref.current!;
    const ctx = c.getContext('2d')!;
    ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.strokeStyle = '#111';
  }, []);
  const pos = (e: React.PointerEvent) => {
    const r = ref.current!.getBoundingClientRect();
    return [((e.clientX - r.left) / r.width) * ref.current!.width, ((e.clientY - r.top) / r.height) * ref.current!.height];
  };
  const down = (e: React.PointerEvent) => { drawing.current = true; ref.current!.setPointerCapture(e.pointerId); const [x, y] = pos(e); const ctx = ref.current!.getContext('2d')!; ctx.beginPath(); ctx.moveTo(x, y); };
  const move = (e: React.PointerEvent) => { if (!drawing.current) return; const [x, y] = pos(e); const ctx = ref.current!.getContext('2d')!; ctx.lineTo(x, y); ctx.stroke(); dirty.current = true; };
  const up = () => { if (!drawing.current) return; drawing.current = false; if (dirty.current) onChange(ref.current!.toDataURL('image/png')); };
  const clear = () => { const c = ref.current!; c.getContext('2d')!.clearRect(0, 0, c.width, c.height); dirty.current = false; onChange(null); };
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <canvas ref={ref} width={600} height={170} className="sigpad" aria-label={t('ci.signature')} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} />
      <button className="btn sm ghost" style={{ alignSelf: 'flex-end' }} onClick={clear}>{t('ci.clear')}</button>
    </div>
  );
}

function PaymentFields({ p, set, label }: { p: { amount: string; method: string; reference: string }; set: (x: any) => void; label: string }) {
  const { t } = useI18n();
  return (
    <div className="form-grid">
      <Field label={label} htmlFor="pay-a"><input id="pay-a" className="input" inputMode="decimal" value={p.amount} onChange={(e) => set({ ...p, amount: e.target.value })} /></Field>
      <Field label={t('common.method')} htmlFor="pay-m">
        <select id="pay-m" className="input" value={p.method} onChange={(e) => set({ ...p, method: e.target.value })}>
          {['cash', 'card', 'cheque', 'transfer', 'company_account'].map((m) => <option key={m} value={m}>{t(`pm.${m}` as Key)}</option>)}
        </select>
      </Field>
      {p.method !== 'cash' && <Field label={t('common.reference')} htmlFor="pay-r"><input id="pay-r" className="input" value={p.reference} onChange={(e) => set({ ...p, reference: e.target.value })} /></Field>}
    </div>
  );
}
const payPayload = (p: { amount: string; method: string; reference: string }) => (toNum(p.amount) > 0 ? { amount: toNum(p.amount), method: p.method, reference: p.reference || null } : null);

// ================================================== Check-in / Walk-in ==================================================
/** Assistant d'arrivée. Sans rrId : walk-in (client sans réservation). */
export function CheckInWizard({ rrId, onClose, onDone }: { rrId?: number; onClose: () => void; onDone?: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const key = useOpKey();
  const walk = !rrId;
  const T0 = todayLocal();
  const [step, setStep] = useState(0);
  const [res, setRes] = useState<any>(null);
  const [rooms, setRooms] = useState<any[]>([]);
  const [plans, setPlans] = useState<any[]>([]);
  const [roomId, setRoomId] = useState<number | null>(null);
  const [policy, setPolicy] = useState<'keep' | 'new'>('keep');
  const [stay, setStay] = useState({ check_out: addDays(T0, 1), adults: 1, children: 0, meal_plan: 'RO', rate_plan_id: 0, rate: '' });
  const [quote, setQuote] = useState<any>(null);
  const [g, setG] = useState<GuestForm>(EMPTY_GUEST);
  const [comp, setComp] = useState<Companion[]>([]);
  const [pay, setPay] = useState({ amount: '', method: 'cash', reference: '' });
  const [v, setV] = useState({ coming_from: '', going_to: '', entry_date: '', id_checked: false, consent: false, paper: false, notes: '' });
  const [sig, setSig] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [done, setDone] = useState<any>(null);
  const rr = res?.rooms?.find((x: any) => x.id === rrId);

  // Chargement
  useEffect(() => {
    if (walk) {
      get('/api/rate-plans').then((p) => setPlans(p.filter((x: any) => x.active && x.kind !== 'standard'))).catch(() => {});
      return;
    }
    get(`/api/frontoffice/folio/${rrId}`).then(async (f) => {
      const r = await get(`/api/reservations/${f.reservation_id}`);
      setRes(r);
      const x = r.rooms.find((y: any) => y.id === rrId);
      setRoomId(x.room_id);
      setStay((s) => ({ ...s, adults: x.adults, children: x.children }));
      setG(fromGuest(x.occupant ?? r.guest));
      const due = Math.max(0, Number(r.deposit_required ?? 0) - (Number(r.paid) - Number(r.refunded)));
      if (due > 0) setPay((p) => ({ ...p, amount: String(r2(due)) }));
    }).catch((e) => setErr(e.message));
  }, [rrId]);
  // Chambres libres pour la période
  const ci = walk ? T0 : rr?.check_in;
  const co = walk ? stay.check_out : rr?.check_out;
  useEffect(() => {
    if (!ci || !co || co <= ci) return;
    get(`/api/availability?check_in=${ci < T0 ? T0 : ci}&check_out=${co}${rrId ? `&exclude_rr=${rrId}` : ''}`).then(setRooms).catch(() => {});
  }, [ci, co]);
  // Prix walk-in (moteur tarifaire)
  useEffect(() => {
    if (!walk || !roomId || stay.check_out <= T0 || stay.rate) { setQuote(null); return; }
    const h = setTimeout(() => post('/api/rates/quote', { check_in: T0, check_out: stay.check_out, meal_plan: stay.meal_plan, rate_plan_id: stay.rate_plan_id || null, rooms: [{ room_id: roomId, adults: stay.adults, children: stay.children }] })
      .then((r) => setQuote({ ...r.rooms[0], error: r.plan_error })).catch(() => setQuote(null)), 200);
    return () => clearTimeout(h);
  }, [walk, roomId, stay.check_out, stay.meal_plan, stay.rate_plan_id, stay.adults, stay.children, stay.rate]);

  const room = rooms.find((x) => x.id === roomId) ?? (rr && roomId === rr.room_id ? { id: rr.room_id, number: rr.room_number, type_name: rr.room_type, type_id: rr.room_type_id, hk_status: res?.room_hk, capacity: rr.capacity } : null);
  const [hk, setHk] = useState<string | null>(null);
  useEffect(() => { if (rr) get(`/api/rooms/${rr.room_id}`).then((x) => setHk(x.hk_status)).catch(() => {}); }, [rr?.room_id]);
  const currentReady = !rr || roomId !== rr.room_id || ['clean', 'inspected'].includes(hk ?? 'clean');
  const typeChanged = rr && room && room.type_id && room.type_id !== rr.room_type_id;
  const capacity = room?.capacity ?? rr?.capacity ?? 4;
  const nights = co && ci ? diffDays(ci, co) : 0;
  const walkTotal = stay.rate ? toNum(stay.rate) * nights : quote?.total ?? 0;
  const miss = missingIdentity(g);

  const steps = [t('ci.s1'), t('ci.s2'), t('ci.s3'), t('ci.s4')];
  const canNext = [
    !!roomId && currentReady && (!walk || stay.check_out > T0) && stay.adults + stay.children <= capacity,
    miss.length === 0,
    true,
    v.id_checked && v.consent && (!!sig || v.paper),
  ];

  const submit = async () => {
    setBusy(true);
    setErr('');
    const common = {
      guest: guestPayload(g), adults: stay.adults, children: stay.children, companions: companionsPayload(comp),
      coming_from: v.coming_from || null, going_to: v.going_to || null, entry_date: v.entry_date || null, id_checked: v.id_checked, signed: v.paper || !!sig, signature: sig,
      data_consent: v.consent, payment: payPayload(pay), notes: v.notes || null,
    };
    try {
      const r = walk
        ? await postOnce('/api/frontoffice/walk-in', { ...common, room_id: roomId, check_out: stay.check_out, meal_plan: stay.meal_plan, rate_plan_id: stay.rate_plan_id || null, rate: stay.rate ? toNum(stay.rate) : null }, key)
        : await postOnce('/api/frontoffice/check-in', { ...common, rr_id: rrId, room_id: roomId !== rr.room_id ? roomId : null, rate_policy: policy }, key);
      setDone(r);
      toast('success', `${t('ci.done')} — ${t('common.room')} ${room?.number ?? ''}`);
      onDone?.();
    } catch (e: any) {
      setErr(e.message);
      if (e instanceof ApiError && e.message.includes('Fiche de police')) setStep(1);
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <DoneModal title={t('ci.done')} onClose={onClose} action={<button className="btn primary" onClick={() => printRegistration(done.rr_id)}><Icon name="print" /> {t('ci.printCard')}</button>}>
        <div className="done-box"><span className="done-ico">✓</span><div><b>{g.last_name} {g.first_name}</b><br />{t('common.room')} {room?.number} · {fmtDate(ci, locale)} → {fmtDate(co, locale)}</div></div>
      </DoneModal>
    );
  }
  const loading = !walk && !res;
  return (
    <Modal size="lg" title={walk ? t('fo.walkinTitle') : `${t('ci.title')}${res ? ` — ${res.code}` : ''}`} onClose={onClose}
      footer={<>
        {step > 0 && <button className="btn ghost" onClick={() => setStep(step - 1)}>{t('ci.back')}</button>}
        <span style={{ flex: 1 }} />
        {step < 3
          ? <button className="btn primary" disabled={!canNext[step] || loading} onClick={() => setStep(step + 1)}>{t('ci.next')}</button>
          : <button className="btn primary" disabled={!canNext[3] || busy} onClick={submit}>{busy ? '…' : t('ci.confirm')}</button>}
      </>}>
      <Steps steps={steps} current={step} />
      {err && <div className="alert" role="alert" style={{ marginTop: 10 }}>{err}</div>}
      {loading ? <p>{t('common.loading')}</p> : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 12 }}>
          {step === 0 && (
            <>
              {!walk && (
                <div className="kv">
                  <div><span>{t('fo.guest')}</span><b>{res.guest_name}</b></div>
                  <div><span>{t('fo.code')}</span><b>{res.code}</b></div>
                  <div><span>{t('fo.arrival')}</span><b style={rr.check_in !== T0 ? { color: 'var(--danger)' } : undefined}>{fmtDate(rr.check_in, locale)}</b></div>
                  <div><span>{t('res.departure')}</span><b>{fmtDate(rr.check_out, locale)} · {nights} {t('common.nights')}</b></div>
                  <div><span>{t('res.meal')}</span><b>{t(`meal.${res.meal_plan}` as Key)}</b></div>
                  <div><span>{t('fo.amount')}</span><b>{money(res.total, locale)}</b></div>
                </div>
              )}
              {!walk && res?.guest?.id && <CrmSummary guestId={(rr?.guest_id ?? res.guest.id)} />}
              {walk && (
                <div className="form-grid">
                  <Field label={t('fo.arrival')} htmlFor="w-ci"><input id="w-ci" className="input" value={fmtDate(T0, locale)} disabled /></Field>
                  <Field label={t('res.departure')} htmlFor="w-co"><input id="w-co" className="input" type="date" min={addDays(T0, 1)} value={stay.check_out} onChange={(e) => setStay({ ...stay, check_out: e.target.value })} /></Field>
                  <Field label={t('res.meal')} htmlFor="w-meal">
                    <select id="w-meal" className="input" value={stay.meal_plan} onChange={(e) => setStay({ ...stay, meal_plan: e.target.value })}>{['RO', 'BB', 'HB', 'FB'].map((m) => <option key={m} value={m}>{t(`meal.${m}` as Key)}</option>)}</select>
                  </Field>
                  <Field label={t('form.ratePlan')} htmlFor="w-plan">
                    <select id="w-plan" className="input" value={stay.rate_plan_id} onChange={(e) => setStay({ ...stay, rate_plan_id: Number(e.target.value) })}><option value={0}>{t('pk.standard')}</option>{plans.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
                  </Field>
                  {can('reservations.edit') && <Field label={`${t('form.custom')} / ${t('common.nights')}`} htmlFor="w-rate"><input id="w-rate" className="input" inputMode="decimal" placeholder="—" value={stay.rate} onChange={(e) => setStay({ ...stay, rate: e.target.value })} /></Field>}
                </div>
              )}
              <div className="form-grid" style={{ maxWidth: 420 }}>
                <Field label={t('new.adults')} htmlFor="ci-ad"><input id="ci-ad" className="input" type="number" min={1} max={capacity} value={stay.adults} onChange={(e) => setStay({ ...stay, adults: Math.max(1, Number(e.target.value)) })} /></Field>
                <Field label={t('new.children')} htmlFor="ci-ch"><input id="ci-ch" className="input" type="number" min={0} max={capacity} value={stay.children} onChange={(e) => setStay({ ...stay, children: Math.max(0, Number(e.target.value)) })} /></Field>
              </div>
              {stay.adults + stay.children > capacity && <div className="alert">{`Capacité dépassée : ${capacity} pers. max dans cette chambre.`}</div>}
              <div className="section">
                <h3>{walk ? t('mv.newRoom') : t('ci.assigned')}</h3>
                {!walk && rr && (
                  <div className="row">
                    <b style={{ fontSize: 18 }}>{room?.number}</b><span className="muted">{room?.type_name}</span>
                    {roomId === rr.room_id && hk && <span className="pill" style={currentReady ? { background: 'var(--ok-bg)', color: 'var(--ok)' } : { background: 'var(--danger-bg)', color: 'var(--danger)' }}>{currentReady ? t('hk.clean') : `${t('ci.notReady')} (${t(`hk.${hk}` as Key)})`}</span>}
                  </div>
                )}
                {(!walk && can('reservations.edit')) || walk ? (
                  <RoomPicker rooms={rooms} value={roomId} current={rr?.room_id} preferType={rr?.room_type_id} persons={stay.adults + stay.children} onChange={setRoomId} label={walk ? undefined : t('ci.changeRoom')} />
                ) : null}
                {typeChanged && (
                  <div className="seg" role="radiogroup" style={{ alignSelf: 'flex-start', flexWrap: 'wrap' }}>
                    <button className={policy === 'keep' ? 'on' : ''} onClick={() => setPolicy('keep')}>{t('ci.keepRate')}</button>
                    <button className={policy === 'new' ? 'on' : ''} onClick={() => setPolicy('new')}>{t('ci.newRate')}</button>
                  </div>
                )}
                {walk && roomId && (
                  <div className="row" style={{ gap: 16 }}>
                    <span>{nights} {t('common.nights')} · <b>{money(walkTotal, locale)}</b>{quote && nights > 0 ? <span className="muted"> ({money(quote.avg, locale)} / {t('common.nights')})</span> : null}</span>
                    {quote?.error && <span className="muted">{quote.error}</span>}
                  </div>
                )}
              </div>
            </>
          )}
          {step === 1 && (
            <>
              <span className="muted" style={{ fontSize: 12.5 }}>* {t('id.required')}</span>
              <IdentityFields g={g} set={setG} />
              <div className="section">
                <h3>{t('ci.companions')} ({comp.length})</h3>
                <Companions list={comp} set={setComp} max={Math.max(0, stay.adults + stay.children - 1)} />
              </div>
            </>
          )}
          {step === 2 && (
            <div className="grid" style={{ gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)', alignItems: 'start' }}>
              <div className="section">
                <h3>{t('form.finance')}</h3>
                {walk ? <Sum label={t('fo.amount')} value={money(walkTotal, locale)} strong /> : (
                  <>
                    <Sum label={t('fo.amount')} value={money(res.total, locale)} />
                    <Sum label={t('ci.depositReq')} value={money(res.deposit_required, locale)} />
                    <Sum label={t('ci.alreadyPaid')} value={money(Number(res.paid) - Number(res.refunded), locale)} />
                    <Sum label={t('fo.balance')} value={money(res.balance, locale)} strong />
                  </>
                )}
              </div>
              <div className="section">
                <h3>{t('ci.s3')}</h3>
                {can('payments.create') ? <PaymentFields p={pay} set={setPay} label={t('ci.toPay')} /> : <span className="muted">—</span>}
              </div>
            </div>
          )}
          {step === 3 && (
            <>
              <div className="form-grid">
                <Field label={t('ci.comingFrom')} htmlFor="v-from"><input id="v-from" className="input" value={v.coming_from} onChange={(e) => setV({ ...v, coming_from: e.target.value })} /></Field>
                <Field label={t('ci.goingTo')} htmlFor="v-to"><input id="v-to" className="input" value={v.going_to} onChange={(e) => setV({ ...v, going_to: e.target.value })} /></Field>
                {g.nationality && !/alg[eé]r|dz/i.test(g.nationality) && <Field label={`${t('ci.entryDate')} *`} htmlFor="v-entry"><input id="v-entry" type="date" className="input" value={v.entry_date} onChange={(e) => setV({ ...v, entry_date: e.target.value })} /></Field>}
              </div>
              <label className="check"><input type="checkbox" checked={v.id_checked} onChange={(e) => setV({ ...v, id_checked: e.target.checked })} /> {t('ci.idChecked')}</label>
              <label className="check"><input type="checkbox" checked={v.consent} onChange={(e) => setV({ ...v, consent: e.target.checked })} /> {t('ci.consent')}</label>
              <div className="section">
                <h3>{t('ci.signature')}</h3>
                <SignaturePad onChange={setSig} />
                <label className="check"><input type="checkbox" checked={v.paper} onChange={(e) => setV({ ...v, paper: e.target.checked })} /> {t('ci.paperSigned')}</label>
              </div>
              <Field label={t('res.notes')} htmlFor="v-notes"><textarea id="v-notes" className="input" rows={2} value={v.notes} onChange={(e) => setV({ ...v, notes: e.target.value })} /></Field>
              <div className="kv">
                <div><span>{t('fo.guest')}</span><b>{g.last_name} {g.first_name}</b></div>
                <div><span>{t('common.room')}</span><b>{room?.number} · {room?.type_name}</b></div>
                <div><span>{t('res.dates')}</span><b>{fmtDate(ci, locale)} → {fmtDate(co, locale)}</b></div>
                <div><span>{t('ci.toPay')}</span><b>{money(toNum(pay.amount), locale)}</b></div>
              </div>
            </>
          )}
        </div>
      )}
    </Modal>
  );
}

function RoomPicker({ rooms, value, current, preferType, persons, onChange, label }: { rooms: any[]; value: number | null; current?: number; preferType?: number; persons: number; onChange: (id: number) => void; label?: string }) {
  const { t } = useI18n();
  const [all, setAll] = useState(false);
  const list = useMemo(() => {
    const ok = rooms.filter((r) => r.capacity >= persons);
    const sorted = [...ok].sort((a, b) => Number(b.type_id === preferType) - Number(a.type_id === preferType) || Number(['clean', 'inspected'].includes(b.hk_status)) - Number(['clean', 'inspected'].includes(a.hk_status)));
    return all ? sorted : sorted.filter((r) => r.id === current || ['clean', 'inspected'].includes(r.hk_status)).slice(0, 30);
  }, [rooms, persons, preferType, all, current]);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {label && <span className="muted" style={{ fontSize: 12.5 }}>{label}</span>}
      <div className="room-pick">
        {list.map((r) => (
          <button key={r.id} className={`rp ${value === r.id ? 'on' : ''} ${['clean', 'inspected'].includes(r.hk_status) ? '' : 'dirty'}`} onClick={() => onChange(r.id)} title={`${r.type_name} · ${r.capacity} pers.`}>
            <b>{r.number}</b><small>{r.type_name}</small>
          </button>
        ))}
        {!list.length && <span className="muted">{t('common.none')}</span>}
      </div>
      <label className="check" style={{ fontSize: 12.5 }}><input type="checkbox" checked={all} onChange={(e) => setAll(e.target.checked)} /> Afficher aussi les chambres à nettoyer</label>
    </div>
  );
}

// ===================================================== Check-out =====================================================
export function CheckOutModal({ rrId, onClose, onDone }: { rrId: number; onClose: () => void; onDone?: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const key = useOpKey();
  const [f, setF] = useState<any>(null);
  const [pay, setPay] = useState({ amount: '', method: 'cash', reference: '' });
  const [refund, setRefund] = useState({ amount: '', method: 'cash', reason: 'Trop-perçu restitué au client' });
  const [action, setAction] = useState<'' | 'company' | 'override'>('');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [done, setDone] = useState<any>(null);
  useEffect(() => {
    post('/api/frontoffice/check-out/preview', { rr_id: rrId }).then((x) => {
      setF(x);
      if (x.balance > 0) setPay((p) => ({ ...p, amount: String(x.balance) }));
      if (x.balance < 0) setRefund((p) => ({ ...p, amount: String(-x.balance) }));
    }).catch((e) => setErr(e.message));
  }, [rrId]);
  if (!f) return <Modal title={t('co.title')} onClose={onClose}>{err ? <div className="alert">{err}</div> : t('common.loading')}</Modal>;

  const paying = can('payments.create') ? toNum(pay.amount) : 0;
  const refunding = can('frontoffice.refund') ? toNum(refund.amount) : 0;
  const after = r2(f.balance - paying + refunding);
  const enforce = f.scope === 'room' || f.others_in_house === 0;
  const needAction = enforce && after > 0.005;
  const ok = !needAction || (action === 'company' && f.payer) || (action === 'override' && can('frontoffice.checkout_with_balance') && reason.trim().length >= 3);

  const submit = async () => {
    setBusy(true);
    setErr('');
    try {
      const r = await postOnce('/api/frontoffice/check-out', {
        rr_id: rrId, payment: paying > 0 ? { amount: paying, method: pay.method, reference: pay.reference || null } : null,
        refund: refunding > 0 ? { amount: refunding, method: refund.method, reason: refund.reason } : null,
        balance_action: needAction ? action || null : null, override_reason: action === 'override' ? reason : null, notes: notes || null,
      }, key);
      setDone(r);
      toast('success', `${t('co.done')} — ${t('common.room')} ${f.room_number} : ${t('hk.to_clean')}`);
      onDone?.();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };
  if (done) {
    return (
      <DoneModal title={t('co.done')} onClose={onClose} action={done.invoice && <button className="btn primary" onClick={() => printInvoice(done.invoice.id)}><Icon name="print" /> {t('co.printInvoice')}</button>}>
        <div className="done-box"><span className="done-ico">✓</span><div><b>{f.guest_name}</b><br />{t('common.room')} {f.room_number} → {t('hk.to_clean')}{done.invoice ? ` · ${done.invoice.number}` : ''}<br />{t('fo.balance')} : {money(done.folio.balance, locale)}</div></div>
      </DoneModal>
    );
  }
  const nightsTotal = f.nights.reduce((a: number, n: any) => a + n.price - n.discount, 0);
  return (
    <Modal size="lg" title={`${t('co.title')} — ${t('common.room')} ${f.room_number}`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!ok || busy} onClick={submit}>{busy ? '…' : t('co.confirm')}</button></>}>
      {err && <div className="alert" role="alert">{err}</div>}
      <div className="kv" style={{ marginBottom: 12 }}>
        <div><span>{t('fo.guest')}</span><b>{f.guest_name}</b></div>
        <div><span>{t('fo.code')}</span><b>{f.code}{f.room_count > 1 ? ` · ${f.room_count} ch. (${f.scope === 'room' ? 'facture individuelle' : 'facture commune'})` : ''}</b></div>
        <div><span>{t('fo.arrival')}</span><b>{fmtDate(f.nights[0]?.date, locale)}</b></div>
        <div><span>{t('res.departure')}</span><b>{fmtDate(f.check_out, locale)}</b></div>
      </div>
      {f.early && <div className="alert" style={{ marginBottom: 12 }}>{t('co.early')} ({fmtDate(f.planned_check_out, locale)} → {fmtDate(f.check_out, locale)})</div>}
      <div className="grid" style={{ gridTemplateColumns: 'minmax(0,1.3fr) minmax(0,1fr)', alignItems: 'start' }}>
        <div className="section">
          <h3>{t('co.nights')} ({f.nights.length} {t('common.nights')})</h3>
          <div className="folio">
            {f.nights.map((n: any) => <div key={`${n.rr_id}-${n.date}`} className="sum-row"><span>{fmtDate(n.date, locale)} · ch. {n.room}</span><span>{money(n.price - n.discount, locale)}</span></div>)}
          </div>
          <Sum label={t('co.nights')} value={money(nightsTotal, locale)} strong />
          <h3 style={{ marginTop: 8 }}>{t('co.extras')}</h3>
          {f.charges.filter((c: any) => !c.void).length ? f.charges.filter((c: any) => !c.void).map((c: any) => <Sum key={c.id} label={`${fmtDate(c.service_date, locale, { day: 'numeric', month: 'short' })} · ${c.description} × ${Number(c.quantity)}`} value={money(c.total, locale)} />) : <span className="muted">{t('common.none')}</span>}
          <Sum label={t('co.taxes')} value={money(f.vat_amount + f.tourist_tax_amount, locale)} />
          <Sum label={t('common.total')} value={money(f.total, locale)} strong />
          <h3 style={{ marginTop: 8 }}>{t('co.payments')}</h3>
          {f.payments.filter((p: any) => !p.void).map((p: any) => <Sum key={p.id} label={`${fmtDate(p.received_at.slice(0, 10), locale, { day: 'numeric', month: 'short' })} · ${t(`pm.${p.method}` as Key)}`} value={money(p.amount, locale)} />)}
          {f.refunds.map((x: any) => <Sum key={`r${x.id}`} label={`Remboursement · ${x.reason}`} value={`− ${money(x.amount, locale)}`} />)}
          <Sum label={f.balance < 0 ? t('co.credit') : t('fo.balance')} value={money(Math.abs(f.balance), locale)} strong tone={f.balance > 0.005 ? 'danger' : 'ok'} />
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {f.balance > 0.005 && can('payments.create') && <div className="section"><h3>{t('co.final')}</h3><PaymentFields p={pay} set={setPay} label={t('common.amount')} /></div>}
          {f.balance < -0.005 && can('frontoffice.refund') && (
            <div className="section">
              <h3>{t('co.refund')}</h3>
              <div className="form-grid">
                <Field label={t('common.amount')} htmlFor="rf-a"><input id="rf-a" className="input" inputMode="decimal" value={refund.amount} onChange={(e) => setRefund({ ...refund, amount: e.target.value })} /></Field>
                <Field label={t('common.method')} htmlFor="rf-m"><select id="rf-m" className="input" value={refund.method} onChange={(e) => setRefund({ ...refund, method: e.target.value })}>{['cash', 'card', 'cheque', 'transfer'].map((m) => <option key={m} value={m}>{t(`pm.${m}` as Key)}</option>)}</select></Field>
              </div>
              <Field label={t('co.refundReason')} htmlFor="rf-r"><input id="rf-r" className="input" value={refund.reason} onChange={(e) => setRefund({ ...refund, reason: e.target.value })} /></Field>
            </div>
          )}
          <div className="section" style={needAction ? { borderColor: 'var(--danger)' } : undefined}>
            <Sum label={t('fo.balance')} value={money(after, locale)} strong tone={after > 0.005 ? 'danger' : 'ok'} />
            {!enforce && after > 0.005 && <span className="muted" style={{ fontSize: 12.5 }}>Dossier commun : le solde sera réglé au départ de la dernière chambre ({f.others_in_house} encore ouverte(s)).</span>}
            {needAction && (
              <>
                <b style={{ color: 'var(--danger)' }}>{t('co.unpaid')} : {money(after, locale)}</b>
                {f.payer && <label className="check"><input type="radio" name="ba" checked={action === 'company'} onChange={() => setAction('company')} /> {t('co.billCompany')} {f.payer.name}</label>}
                {can('frontoffice.checkout_with_balance') ? (
                  <>
                    <label className="check"><input type="radio" name="ba" checked={action === 'override'} onChange={() => setAction('override')} /> {t('co.override')}</label>
                    {action === 'override' && <input className="input" aria-label={t('co.overrideReason')} placeholder={t('co.overrideReason')} value={reason} onChange={(e) => setReason(e.target.value)} />}
                  </>
                ) : !f.payer && <span className="muted" style={{ fontSize: 12.5 }}>{t('co.noOverride')}</span>}
              </>
            )}
          </div>
          <Field label={t('res.notes')} htmlFor="co-n"><textarea id="co-n" className="input" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
        </div>
      </div>
    </Modal>
  );
}

// ================================================ Changement de chambre ================================================
export function RoomChangeModal({ rrId, onClose, onDone }: { rrId: number; onClose: () => void; onDone?: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const key = useOpKey();
  const [f, setF] = useState<any>(null);
  const [rooms, setRooms] = useState<any[]>([]);
  const [roomId, setRoomId] = useState<number | null>(null);
  const [policy, setPolicy] = useState<'keep' | 'new'>('new');
  const [reason, setReason] = useState('');
  const [q, setQ] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const T0 = todayLocal();
  useEffect(() => {
    get(`/api/frontoffice/folio/${rrId}`).then((x) => {
      setF(x);
      const from = x.status === 'checked_in' && x.check_in < T0 ? T0 : x.check_in;
      return get(`/api/availability?check_in=${from}&check_out=${x.check_out}&exclude_rr=${rrId}`).then((r) => setRooms(r.filter((y: any) => y.number !== x.room_number)));
    }).catch((e) => setErr(e.message));
  }, [rrId]);
  useEffect(() => {
    if (!roomId) return;
    post('/api/frontoffice/room-change/quote', { rr_id: rrId, room_id: roomId, rate_policy: policy }).then(setQ).catch((e) => setErr(e.message));
  }, [roomId, policy]);
  const submit = async () => {
    setBusy(true);
    try {
      await postOnce('/api/frontoffice/room-change', { rr_id: rrId, room_id: roomId, rate_policy: policy, reason }, key);
      toast('success', `${t('mv.title')} : ${f.room_number} → ${q?.room}`);
      onDone?.();
      onClose();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal size="lg" title={`${t('mv.title')}${f ? ` — ${t('common.room')} ${f.room_number}` : ''}`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!roomId || reason.trim().length < 2 || busy} onClick={submit}>{t('common.confirm')}</button></>}>
      {err && <div className="alert" role="alert">{err}</div>}
      {!f ? t('common.loading') : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <span className="muted">{f.guest_name} · {f.room_type} · {fmtDate(f.check_in, locale)} → {fmtDate(f.check_out, locale)}</span>
          <RoomPicker rooms={f.status === 'checked_in' ? rooms.filter((r) => ['clean', 'inspected'].includes(r.hk_status)) : rooms} value={roomId} persons={f.adults + f.children} onChange={setRoomId} label={t('mv.newRoom')} />
          <div className="seg" role="radiogroup" style={{ alignSelf: 'flex-start', flexWrap: 'wrap' }}>
            <button className={policy === 'new' ? 'on' : ''} onClick={() => setPolicy('new')}>{t('ci.newRate')}</button>
            <button className={policy === 'keep' ? 'on' : ''} onClick={() => setPolicy('keep')}>{t('ci.keepRate')}</button>
          </div>
          {q && (
            <div className="kv">
              <div><span>{t('mv.from')}</span><b>{fmtDate(q.from, locale)} · {q.nights} {t('common.nights')}</b></div>
              <div><span>{t('mv.newRoom')}</span><b>{q.room} · {q.room_type}</b></div>
              <div><span>Avant</span><b>{money(q.before_total, locale)}</b></div>
              <div><span>{t('mv.difference')}</span><b style={{ color: q.difference > 0 ? 'var(--danger)' : 'var(--ok)' }}>{q.difference > 0 ? '+' : ''}{money(q.difference, locale)}</b></div>
            </div>
          )}
          <Field label={`${t('mv.reason')} *`} htmlFor="mv-r"><input id="mv-r" className="input" list="mv-reasons" value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
          <datalist id="mv-reasons">{['Demande du client', 'Panne / maintenance', 'Bruit', 'Surclassement', 'Regroupement familial', 'Propreté'].map((x) => <option key={x} value={x} />)}</datalist>
        </div>
      )}
    </Modal>
  );
}

// ===================================================== Prolongation =====================================================
export function ExtendModal({ rrId, onClose, onDone }: { rrId: number; onClose: () => void; onDone?: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const key = useOpKey();
  const [f, setF] = useState<any>(null);
  const [date, setDate] = useState('');
  const [policy, setPolicy] = useState<'keep' | 'new'>('new');
  const [q, setQ] = useState<any>(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => { get(`/api/frontoffice/folio/${rrId}`).then((x) => { setF(x); setDate(addDays(x.check_out, 1)); }).catch((e) => setErr(e.message)); }, [rrId]);
  useEffect(() => {
    if (!f || !date || date <= f.check_out) { setQ(null); return; }
    setErr('');
    post('/api/frontoffice/extend/quote', { rr_id: rrId, check_out: date, rate_policy: policy }).then(setQ).catch((e) => { setQ(null); setErr(e.message); });
  }, [date, policy, f]);
  const submit = async () => {
    setBusy(true);
    try {
      await postOnce('/api/frontoffice/extend', { rr_id: rrId, check_out: date, rate_policy: policy }, key);
      toast('success', `${t('ex.title')} : ${fmtDate(date, locale)}`);
      onDone?.();
      onClose();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal title={`${t('ex.title')}${f ? ` — ${t('common.room')} ${f.room_number}` : ''}`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!q || busy} onClick={submit}>{t('common.confirm')}</button></>}>
      {!f ? t('common.loading') : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <span className="muted">{f.guest_name} · {t('res.departure')} : {fmtDate(f.check_out, locale)}</span>
          <Field label={t('ex.newDate')} htmlFor="ex-d"><input id="ex-d" className="input" type="date" min={addDays(f.check_out, 1)} value={date} onChange={(e) => setDate(e.target.value)} /></Field>
          <div className="seg" role="radiogroup" style={{ alignSelf: 'flex-start', flexWrap: 'wrap' }}>
            <button className={policy === 'new' ? 'on' : ''} onClick={() => setPolicy('new')}>Tarif du jour (saisons, week-end)</button>
            <button className={policy === 'keep' ? 'on' : ''} onClick={() => setPolicy('keep')}>Même prix que le séjour</button>
          </div>
          {err && <div className="alert" role="alert">{err}</div>}
          {q && (
            <div className="section">
              {q.added.map((n: any) => <Sum key={n.date} label={fmtDate(n.date, locale)} value={money(n.price, locale)} />)}
              <Sum label={`${t('ex.added')} : ${q.nights}`} value={`+ ${money(q.added_net, locale)}`} strong />
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}

// ===================================================== Prestations =====================================================
export function ChargeModal({ reservationId, rrId, onClose, onDone }: { reservationId: number; rrId?: number | null; onClose: () => void; onDone?: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [key, setKey] = useState(() => newOpKey());
  const [services, setServices] = useState<any[]>([]);
  const [rooms, setRooms] = useState<any[]>([]);
  const [svc, setSvc] = useState<any>(null);
  const [x, setX] = useState({ rr: rrId ? String(rrId) : '', qty: '1', price: '', desc: '', date: todayLocal(), kind: 'other' });
  const [busy, setBusy] = useState(false);
  const [added, setAdded] = useState<string[]>([]);
  useEffect(() => {
    get('/api/services').then((s) => setServices(s.filter((y: any) => y.active))).catch(() => {});
    get(`/api/reservations/${reservationId}`).then((r) => {
      const open = r.rooms.filter((y: any) => ['pending', 'confirmed', 'checked_in'].includes(y.status));
      setRooms(open);
      if (!rrId && open.length === 1) setX((p) => ({ ...p, rr: String(open[0].id) }));
    }).catch(() => {});
  }, [reservationId]);
  const pick = (s: any) => { setSvc(s); setX({ ...x, price: String(s.price), desc: s.name, kind: s.category }); };
  const free = !svc;
  const total = r2(toNum(x.qty) * toNum(x.price));
  const priceEditable = free || can('services.manage');
  const submit = async () => {
    setBusy(true);
    try {
      await postOnce(`/api/reservations/${reservationId}/charges`, {
        reservation_room_id: x.rr ? Number(x.rr) : null, service_id: svc?.id ?? null, kind: free ? 'other' : undefined,
        description: x.desc || null, quantity: toNum(x.qty), unit_price: priceEditable ? toNum(x.price) : null, service_date: x.date,
      }, key);
      toast('success', `${x.desc} : ${money(total, locale)}`);
      setAdded([...added, `${x.desc} × ${x.qty} = ${money(total, locale)}`]);
      setKey(newOpKey());
      setSvc(null);
      setX({ ...x, qty: '1', price: '', desc: '' });
      onDone?.();
    } catch (e: any) {
      toast('error', e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal size="lg" title={t('ch.title')} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.close')}</button><button className="btn primary" disabled={busy || !x.desc.trim() || !(toNum(x.qty) > 0) || (free && !(toNum(x.price) >= 0 && x.price !== ''))} onClick={submit}>{t('common.add')} · {money(total, locale)}</button></>}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div className="svc-grid">
          {services.map((s) => (
            <button key={s.id} className={`svc ${svc?.id === s.id ? 'on' : ''}`} onClick={() => pick(s)}>
              <b>{s.name}</b><small>{money(s.price, locale)} / {t(`sv.u.${s.unit}` as Key)}</small>
            </button>
          ))}
          <button className={`svc ${free ? 'on' : ''}`} onClick={() => { setSvc(null); setX({ ...x, price: '', desc: '' }); }}><b>{t('ch.free')}</b><small>{t('sv.c.other')}</small></button>
        </div>
        <div className="form-grid">
          {rooms.length > 1 && (
            <Field label={t('ch.room')} htmlFor="ch-rr"><select id="ch-rr" className="input" value={x.rr} onChange={(e) => setX({ ...x, rr: e.target.value })}><option value="">Dossier (commun)</option>{rooms.map((r) => <option key={r.id} value={r.id}>{r.room_number}{r.occupant_name ? ` · ${r.occupant_name}` : ''}</option>)}</select></Field>
          )}
          <Field label={t('ch.desc')} htmlFor="ch-d"><input id="ch-d" className="input" value={x.desc} onChange={(e) => setX({ ...x, desc: e.target.value })} /></Field>
          <Field label={t('ch.qty')} htmlFor="ch-q"><input id="ch-q" className="input" inputMode="decimal" value={x.qty} onChange={(e) => setX({ ...x, qty: e.target.value })} /></Field>
          <Field label={t('ch.price')} htmlFor="ch-p"><input id="ch-p" className="input" inputMode="decimal" value={x.price} disabled={!priceEditable} onChange={(e) => setX({ ...x, price: e.target.value })} /></Field>
          <Field label={t('ch.date')} htmlFor="ch-dt"><input id="ch-dt" className="input" type="date" max={todayLocal()} value={x.date} onChange={(e) => setX({ ...x, date: e.target.value })} /></Field>
        </div>
        {added.length > 0 && <div className="alert" style={{ background: 'var(--ok-bg)', color: 'var(--ok)', border: 0 }}>{added.map((a) => <div key={a}>✓ {a}</div>)}</div>}
      </div>
    </Modal>
  );
}
