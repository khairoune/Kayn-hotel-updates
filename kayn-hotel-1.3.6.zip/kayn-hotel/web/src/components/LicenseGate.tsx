import { useEffect, useState, type ReactNode } from 'react';
import { useI18n } from '../i18n';

/** Licence suspendue par KAYN Services : écran de blocage (les données restent intactes). */
export function LicenseGate({ children }: { children: ReactNode }) {
  const { t } = useI18n();
  const [lic, setLic] = useState<{ status: string; message?: string | null } | null>(null);
  const [busy, setBusy] = useState(false);
  const load = () => fetch('/api/license', { credentials: 'same-origin' }).then((r) => r.json()).then(setLic).catch(() => {});
  useEffect(() => {
    load();
    const i = setInterval(load, 5 * 60_000);
    const on = () => load();
    window.addEventListener('kh-license', on);
    return () => { clearInterval(i); window.removeEventListener('kh-license', on); };
  }, []);
  const check = async () => {
    setBusy(true);
    try { const r = await fetch('/api/license/check', { method: 'POST', credentials: 'same-origin', headers: { 'x-kayn-client': 'web' } }); const j = await r.json(); if (j.status) setLic(j); if (j.status === 'active') window.location.reload(); } catch { /* */ }
    finally { setBusy(false); }
  };
  if (lic?.status !== 'suspended') return <>{children}</>;
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'linear-gradient(160deg,#5C1720,#7A1F2B)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, zIndex: 9999 }}>
      <div style={{ maxWidth: 520, textAlign: 'center' }}>
        <div style={{ width: 64, height: 64, borderRadius: 16, background: '#fff', color: '#7A1F2B', font: '800 34px Inter, sans-serif', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>K</div>
        <h1 style={{ color: '#C9A227', margin: '18px 0 8px' }}>{t('lic.title')}</h1>
        <p style={{ fontSize: 17, lineHeight: 1.5 }}>{lic.message || t('lic.default')}</p>
        <p style={{ opacity: 0.8, fontSize: 14 }}>{t('lic.data')}</p>
        <button className="btn" style={{ marginTop: 14, background: '#C9A227', color: '#2a0b10', border: 0, fontWeight: 700 }} disabled={busy} onClick={check}>{busy ? '…' : t('lic.check')}</button>
      </div>
    </div>
  );
}
