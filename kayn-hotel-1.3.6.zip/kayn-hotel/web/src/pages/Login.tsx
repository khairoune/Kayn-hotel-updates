import { useEffect, useState } from 'react';
import { useI18n, type Lang } from '../i18n';
import { get, post } from '../lib/api';
import { useAuth } from '../lib/context';

export function Login({ installedUser = '' }: { installedUser?: string }) {
  const { t, lang, setLang } = useI18n();
  const { refresh } = useAuth();
  const [username, setUsername] = useState(installedUser);
  const [password, setPassword] = useState('');
  const [device, setDevice] = useState(() => localStorage.getItem('kh.deviceName') ?? '');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [reset, setReset] = useState<{ code: string; pw: string; pw2: string } | null>(null);
  const [info, setInfo] = useState(installedUser ? t('setup.done') : '');
  const [hotel, setHotel] = useState<any>(null);
  useEffect(() => { get('/api/hotel/public').then(setHotel).catch(() => {}); }, []);
  /** Code à usage unique remis par l'administrateur : l'utilisateur choisit lui-même son nouveau mot de passe. */
  const doReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reset) return;
    if (reset.pw !== reset.pw2) { setErr(t('login.pwMismatch')); return; }
    setBusy(true); setErr('');
    try { await post('/api/auth/reset-password', { username, code: reset.code, password: reset.pw }); setReset(null); setPassword(''); setInfo(t('login.resetDone')); }
    catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr('');
    try {
      if (device) localStorage.setItem('kh.deviceName', device);
      await post('/api/auth/login', { username, password, device_name: device || undefined });
      await refresh();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login">
      <form className="login-card" onSubmit={reset ? doReset : submit}>
        <div className="row between">
          <div className="brand">
            {hotel?.logo_id ? <img src={`/api/hotel/logo/${hotel.logo_id}`} alt="" style={{ height: 40, maxWidth: 90, objectFit: 'contain' }} /> : <div className="brand-mark">K</div>}
            <div>
              <div className="brand-name">{hotel?.commercial_name || hotel?.name || 'KAYN Hotel'}</div>
              <div className="brand-sub">{reset ? t('login.resetTitle') : t('login.title')}</div>
            </div>
          </div>
          <div className="seg">
            {(['fr', 'ar', 'en'] as Lang[]).map((l) => (
              <button type="button" key={l} className={lang === l ? 'on' : ''} onClick={() => setLang(l)}>{l === 'ar' ? 'ع' : l.toUpperCase()}</button>
            ))}
          </div>
        </div>
        <div className="field">
          <label htmlFor="u">{t('login.username')}</label>
          <input id="u" className="input" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" autoFocus required />
        </div>
        {!reset ? <>
        <div className="field">
          <label htmlFor="p">{t('login.password')}</label>
          <input id="p" className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
        </div>
        <div className="field">
          <label htmlFor="d">{t('login.device')}</label>
          <input id="d" className="input" value={device} onChange={(e) => setDevice(e.target.value)} placeholder="Réception-01" />
        </div>
        </> : <>
          <div className="field"><label htmlFor="c">{t('login.resetCode')}</label><input id="c" className="input" value={reset.code} onChange={(e) => setReset({ ...reset, code: e.target.value.toUpperCase() })} autoComplete="one-time-code" required style={{ letterSpacing: 2, fontFamily: 'monospace' }} /></div>
          <div className="field"><label htmlFor="n1">{t('login.newPassword')}</label><input id="n1" className="input" type="password" value={reset.pw} onChange={(e) => setReset({ ...reset, pw: e.target.value })} autoComplete="new-password" required /></div>
          <div className="field"><label htmlFor="n2">{t('login.newPassword2')}</label><input id="n2" className="input" type="password" value={reset.pw2} onChange={(e) => setReset({ ...reset, pw2: e.target.value })} autoComplete="new-password" required /></div>
        </>}
        {err && <div className="alert danger" role="alert">{err}</div>}
        {info && <div className="alert info" role="status">{info}</div>}
        <button className="btn primary" type="submit" disabled={busy} style={{ minHeight: 44 }}>{reset ? t('login.resetSubmit') : t('login.submit')}</button>
        <button type="button" className="btn ghost sm" onClick={() => { setErr(''); setInfo(''); setReset(reset ? null : { code: '', pw: '', pw2: '' }); }}>{reset ? t('login.backToLogin') : t('login.haveCode')}</button>
      </form>
      <div style={{ position: 'fixed', bottom: 10, left: 0, right: 0, textAlign: 'center', fontSize: 11, color: 'rgba(255,255,255,.65)' }}>© {new Date().getFullYear()} KAYN Services — KAYN Hotel {__APP_VERSION__}. Logiciel protégé, tous droits réservés. Reproduction et copie interdites.</div>
    </div>
  );
}
