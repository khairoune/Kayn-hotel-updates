/** Phase 14 — Administration & sécurité (tableau de bord, utilisateurs, rôles, départements, établissement, finances, services, documents, notifications, sécurité, journal, sauvegardes, système). */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Page } from '../components/Layout';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { api, get, patch, post, upload } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDateTime } from '../lib/format';

type Sec = 'dashboard' | 'users' | 'roles' | 'departments' | 'hotel' | 'finance' | 'services' | 'documents' | 'notifications' | 'security' | 'audit' | 'backups' | 'updates' | 'system';
const SECS: { k: Sec; perm: string[] }[] = [
  { k: 'dashboard', perm: ['admin.view'] }, { k: 'users', perm: ['users.manage'] }, { k: 'roles', perm: ['roles.manage', 'users.manage'] },
  { k: 'departments', perm: ['departments.manage', 'users.manage'] }, { k: 'hotel', perm: ['settings.manage'] }, { k: 'finance', perm: ['settings.manage'] },
  { k: 'services', perm: ['settings.manage', 'services.manage'] }, { k: 'documents', perm: ['settings.manage'] }, { k: 'notifications', perm: ['settings.manage'] },
  { k: 'security', perm: ['security.manage'] }, { k: 'audit', perm: ['audit.view'] }, { k: 'backups', perm: ['backups.manage'] }, { k: 'updates', perm: ['backups.manage'] }, { k: 'system', perm: ['admin.view'] },
];
const size = (n: number) => (n > 1e9 ? `${(n / 1e9).toFixed(2)} Go` : n > 1e6 ? `${(n / 1e6).toFixed(1)} Mo` : `${Math.max(1, Math.round(n / 1e3))} Ko`);
const pill = (bg: string, fg: string, txt: string) => <span className="pill" style={{ background: bg, color: fg }}>{txt}</span>;
function useA() { const { t, locale } = useI18n(); return { a: (k: string) => t(`adm.${k}` as Key), t, locale }; }
const errT = (toast: any) => (e: any) => toast('error', e.message);

export function Admin() {
  const { a } = useA();
  const { can } = useAuth();
  const [sp, setSp] = useSearchParams();
  const secs = SECS.filter((s) => s.perm.some(can));
  const sec = (secs.find((s) => s.k === sp.get('s'))?.k ?? secs[0]?.k) as Sec;
  const go = (k: Sec) => setSp({ s: k }, { replace: true });
  return (
    <Page>
      <div className="page-head"><h1 className="page-title">{a('title')}</h1></div>
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>{secs.map((s) => <button key={s.k} className={sec === s.k ? 'on' : ''} onClick={() => go(s.k)}>{a(`s_${s.k}`)}</button>)}</div>
      {sec === 'dashboard' && <Dash go={go} />}
      {sec === 'users' && <Users />}
      {sec === 'roles' && <Roles />}
      {sec === 'departments' && <Departments />}
      {sec === 'hotel' && <Hotel />}
      {sec === 'finance' && <Finance />}
      {sec === 'services' && <Services />}
      {sec === 'documents' && <Documents />}
      {sec === 'notifications' && <Notifs />}
      {sec === 'security' && <Security />}
      {sec === 'audit' && <Audit />}
      {sec === 'backups' && <Backups />}
      {sec === 'updates' && <Updates />}
      {sec === 'system' && <SystemInfo />}
    </Page>
  );
}

// ===================================================== Tableau de bord =====================================================
function Dash({ go }: { go: (k: Sec) => void }) {
  const { a, locale } = useA();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  useEffect(() => { get('/api/admin/dashboard').then(setD).catch(errT(toast)); }, []);
  if (!d) return <span className="muted">…</span>;
  const K = ({ l, v, h, c, to }: any) => <div className="card kpi" style={{ borderInlineStart: c ? `4px solid ${c}` : undefined, cursor: to ? 'pointer' : undefined }} onClick={to ? () => go(to) : undefined}><span className="label">{l}</span><span className="value" style={{ fontSize: 22 }}>{v}</span>{h && <span className="hint">{h}</span>}</div>;
  const sys = d.system;
  return (
    <>
      <div className="grid kpis">
        <K l={a('usersTotal')} v={d.users.total} h={`${d.users.active} ${a('active')} · ${d.users.disabled} ${a('disabled')}`} c="#7A1F2B" to="users" />
        <K l={a('locked')} v={d.users.locked} c={d.users.locked ? '#B91C1C' : undefined} to="security" />
        <K l={a('roles')} v={d.roles.active} h={`${d.roles.total} ${a('defined')}`} c="#C9A227" to="roles" />
        <K l={a('departments')} v={d.departments.filter((x: any) => x.active).length} c="#1E40AF" to="departments" />
        <K l={a('lastBackup')} v={d.last_backup ? fmtDateTime(d.last_backup.created_at, locale) : '—'} h={d.last_backup ? size(Number(d.last_backup.size_bytes)) : a('noBackup')} c={d.last_backup ? '#15803D' : '#B91C1C'} to="backups" />
        <K l={a('system')} v={sys.db_ok && !sys.migrations.pending.length ? a('ok') : a('check')} h={`PostgreSQL ${sys.db_latency_ms} ms · ${size(sys.db_size)}`} c={sys.db_ok ? '#15803D' : '#B91C1C'} to="system" />
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))' }}>
        <div className="card"><h3 style={{ marginTop: 0 }}>{a('alerts')}</h3>
          {!d.alerts.length && <span style={{ color: '#15803D' }}>✓ {a('noAlert')}</span>}
          {d.alerts.map((x: any, i: number) => <div key={i} className={`alert ${x.level === 'danger' ? 'danger' : 'warning'}`} style={{ marginBottom: 6 }}>{x.text}</div>)}
        </div>
        <div className="card"><h3 style={{ marginTop: 0 }}>{a('perDept')}</h3>
          {d.departments.filter((x: any) => x.active).map((x: any) => <div key={x.id} className="sum-row"><span>{x.name}</span><span className="muted">{x.users} {a('accounts')} · {x.employees} {a('employees')}</span></div>)}
        </div>
        <div className="card"><h3 style={{ marginTop: 0 }}>{a('lastLogins')}</h3>
          {d.last_logins.map((x: any) => <div key={x.id} className="sum-row"><span>{x.full_name} <span className="muted">· {x.role_name}</span></span><span className="muted">{fmtDateTime(x.last_login_at, locale)}</span></div>)}
        </div>
        <div className="card"><h3 style={{ marginTop: 0 }}>{a('lastActivity')}</h3>
          {d.activity.map((x: any) => <div key={x.id} className="sum-row" style={{ fontSize: 13 }}><span>{x.user_name ?? '—'} · <b>{x.action}</b> <span className="muted">{x.entity}{x.entity_id ? ` #${x.entity_id}` : ''}</span></span><span className="muted">{fmtDateTime(x.created_at, locale)}</span></div>)}
          <button className="btn sm ghost" onClick={() => go('audit')}>{a('seeAudit')} ›</button>
        </div>
      </div>
      <div className="card row" style={{ gap: 8, flexWrap: 'wrap' }}>
        <b>{a('shortcuts')}</b>
        {(['users', 'roles', 'hotel', 'finance', 'security', 'backups'] as Sec[]).map((k) => <button key={k} className="btn sm" onClick={() => go(k)}>{a(`s_${k}`)}</button>)}
      </div>
    </>
  );
}

// ===================================================== Utilisateurs =====================================================
function Users() {
  const { a, t, locale } = useA();
  const toast = useToast();
  const { me } = useAuth();
  const [rows, setRows] = useState<any[]>([]);
  const [f, setF] = useState({ q: '', status: 'all', role: '', department_id: '' });
  const [roles, setRoles] = useState<any[]>([]);
  const [depts, setDepts] = useState<any[]>([]);
  const [edit, setEdit] = useState<any>(null);
  const [view, setView] = useState<number | null>(null);
  const load = useCallback(() => {
    const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v) as any).toString();
    get(`/api/admin/users?${qs}`).then(setRows).catch(errT(toast));
  }, [f]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { get('/api/admin/roles').then(setRoles).catch(() => {}); get('/api/admin/departments').then(setDepts).catch(() => {}); }, []);
  return (
    <>
      <div className="card row" style={{ gap: 8, flexWrap: 'wrap' }}>
        <input className="input" placeholder={t('common.search')} value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} style={{ maxWidth: 240 }} />
        <select className="input" style={{ maxWidth: 170 }} value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}>{['all', 'active', 'disabled', 'locked'].map((s) => <option key={s} value={s}>{a(`st_${s}`)}</option>)}</select>
        <select className="input" style={{ maxWidth: 210 }} value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}><option value="">{a('allRoles')}</option>{roles.map((r) => <option key={r.id} value={r.code}>{r.name}</option>)}</select>
        <select className="input" style={{ maxWidth: 210 }} value={f.department_id} onChange={(e) => setF({ ...f, department_id: e.target.value })}><option value="">{a('allDepts')}</option>{depts.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select>
        <span style={{ flex: 1 }} />
        <button className="btn primary" onClick={() => setEdit({})}><Icon name="plus" size={14} />{a('newUser')}</button>
      </div>
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
        <table className="table">
          <thead><tr><th>{a('name')}</th><th>{a('username')}</th><th>{a('role')}</th><th>{a('department')}</th><th>{a('jobTitle')}</th><th>{a('status')}</th><th>{a('lastLogin')}</th><th /></tr></thead>
          <tbody>{rows.map((u) => (
            <tr key={u.id} style={{ cursor: 'pointer' }} onClick={() => setView(u.id)}>
              <td><b>{u.full_name}</b>{u.protected && <span title={a('protected')}> 🔒</span>}<div className="muted" style={{ fontSize: 12 }}>{u.email ?? ''}</div></td>
              <td>{u.username}</td><td>{u.role_name}</td><td>{u.department_name ?? '—'}</td><td>{u.job_title ?? '—'}</td>
              <td>{!u.active ? pill('#FEE2E2', '#991B1B', a('st_disabled')) : u.locked ? pill('#FEF3C7', '#92400E', a('st_locked')) : pill('#DCFCE7', '#166534', a('st_active'))}</td>
              <td className="muted">{u.last_login_at ? fmtDateTime(u.last_login_at, locale) : '—'}</td>
              <td><button className="btn sm" onClick={(e) => { e.stopPropagation(); setEdit(u); }} disabled={u.protected && me?.role !== 'admin'}>{a('edit')}</button></td>
            </tr>))}
            {!rows.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
          </tbody>
        </table>
      </div>
      {edit && <UserForm u={edit} roles={roles} depts={depts} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); load(); }} />}
      {view && <UserView id={view} onClose={() => setView(null)} onChanged={load} onEdit={(u) => { setView(null); setEdit(u); }} />}
    </>
  );
}
function UserForm({ u, roles, depts, onClose, onSaved }: { u: any; roles: any[]; depts: any[]; onClose: () => void; onSaved: () => void }) {
  const { a, t } = useA();
  const toast = useToast();
  const isNew = !u.id;
  const [f, setF] = useState<any>({ first_name: u.first_name ?? '', last_name: u.last_name ?? '', username: u.username ?? '', email: u.email ?? '', phone: u.phone ?? '', job_title: u.job_title ?? '', department_id: u.department_id ?? '', role: u.role ?? 'employee', language: u.language ?? 'fr', password: '', must_change_password: true });
  const [busy, setBusy] = useState(false);
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const save = async () => {
    setBusy(true);
    try {
      const body: any = { ...f, department_id: f.department_id ? Number(f.department_id) : null };
      if (!isNew) { delete body.password; delete body.must_change_password; }
      if (isNew) await post('/api/admin/users', body); else await patch(`/api/admin/users/${u.id}`, body);
      toast('success', a('saved')); onSaved();
    } catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  return (
    <Modal title={isNew ? a('newUser') : `${a('edit')} — ${u.full_name}`} onClose={onClose} size="lg" footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={busy} onClick={save}>{t('common.save')}</button></>}>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 10 }}>
        <Field label={a('lastName')}><input className="input" value={f.last_name} onChange={set('last_name')} /></Field>
        <Field label={a('firstName')}><input className="input" value={f.first_name} onChange={set('first_name')} /></Field>
        <Field label={a('username')}><input className="input" value={f.username} onChange={set('username')} autoComplete="off" /></Field>
        <Field label={a('email')}><input className="input" type="email" value={f.email} onChange={set('email')} /></Field>
        <Field label={a('phone')}><input className="input" value={f.phone} onChange={set('phone')} /></Field>
        <Field label={a('jobTitle')}><input className="input" value={f.job_title} onChange={set('job_title')} /></Field>
        <Field label={a('department')}><select className="input" value={f.department_id} onChange={set('department_id')}><option value="">—</option>{depts.filter((d) => d.active).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></Field>
        <Field label={a('role')}><select className="input" value={f.role} onChange={set('role')} disabled={u.protected}>{roles.filter((r) => r.active).map((r) => <option key={r.id} value={r.code}>{r.name}</option>)}</select></Field>
        <Field label={a('language')}><select className="input" value={f.language} onChange={set('language')}><option value="fr">Français</option><option value="ar">العربية</option><option value="en">English</option></select></Field>
        {isNew && <Field label={a('initialPassword')}><input className="input" type="password" value={f.password} onChange={set('password')} autoComplete="new-password" /></Field>}
        {isNew && <label className="row" style={{ gap: 8, alignSelf: 'end' }}><input type="checkbox" checked={f.must_change_password} onChange={set('must_change_password')} />{a('mustChange')}</label>}
      </div>
      {isNew && <p className="muted" style={{ fontSize: 12 }}>{a('pwHint')}</p>}
    </Modal>
  );
}
function UserView({ id, onClose, onChanged, onEdit }: { id: number; onClose: () => void; onChanged: () => void; onEdit: (u: any) => void }) {
  const { a, t, locale } = useA();
  const toast = useToast();
  const [u, setU] = useState<any>(null);
  const [code, setCode] = useState<any>(null);
  const [reason, setReason] = useState('');
  const load = () => get(`/api/admin/users/${id}`).then(setU).catch(errT(toast));
  useEffect(() => { load(); }, [id]);
  if (!u) return null;
  const act = async (fn: () => Promise<any>, msg: string) => { try { await fn(); toast('success', msg); load(); onChanged(); } catch (e: any) { toast('error', e.message); } };
  return (
    <Modal title={u.full_name} onClose={onClose} size="lg">
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 8, fontSize: 13 }}>
        {[['username', u.username], ['role', u.role_name], ['department', u.department_name], ['jobTitle', u.job_title], ['email', u.email], ['phone', u.phone], ['createdAt', fmtDateTime(u.created_at, locale)], ['createdBy', u.created_by_name], ['lastLogin', u.last_login_at && fmtDateTime(u.last_login_at, locale)], ['pwChanged', u.password_changed_at && fmtDateTime(u.password_changed_at, locale)]]
          .map(([k, v]) => <div key={k}><span className="muted">{a(k as string)}</span><div><b>{v || '—'}</b></div></div>)}
      </div>
      {!u.active && <div className="alert danger" style={{ marginTop: 8 }}>{a('st_disabled')} — {u.disabled_reason} ({fmtDateTime(u.disabled_at, locale)})</div>}
      {u.locked && <div className="alert warning" style={{ marginTop: 8 }}>{a('st_locked')} → {fmtDateTime(u.locked_until, locale)}</div>}
      <div className="row" style={{ gap: 8, flexWrap: 'wrap', margin: '10px 0' }}>
        <button className="btn sm" onClick={() => onEdit(u)}>{a('edit')}</button>
        {u.active && !u.protected && <><input className="input" style={{ maxWidth: 220 }} placeholder={a('disableReason')} value={reason} onChange={(e) => setReason(e.target.value)} />
          <button className="btn sm danger" onClick={() => act(() => post(`/api/admin/users/${id}/status`, { active: false, reason }), a('done'))}>{a('disable')}</button></>}
        {!u.active && <button className="btn sm primary" onClick={() => act(() => post(`/api/admin/users/${id}/status`, { active: true }), a('done'))}>{a('enable')}</button>}
        {u.locked && <button className="btn sm" onClick={() => act(() => post(`/api/admin/users/${id}/unlock`, {}), a('done'))}>{a('unlock')}</button>}
        {u.active && <button className="btn sm" onClick={() => post(`/api/admin/users/${id}/reset-code`, {}).then(setCode).catch(errT(toast))}><Icon name="key" size={14} />{a('resetCode')}</button>}
        {u.sessions_open > 0 && <button className="btn sm ghost" onClick={() => act(() => post(`/api/admin/users/${id}/logout-all`, {}), a('done'))}>{a('logoutAll')} ({u.sessions_open})</button>}
      </div>
      {code && <div className="alert info" style={{ fontSize: 14 }}>{a('codeFor')} <b>{code.username}</b> : <b style={{ fontSize: 20, letterSpacing: 2, fontFamily: 'monospace' }}>{code.code}</b> — {a('validFor')} {code.expires_minutes} min. {a('codeHint')}</div>}
      <h4>{a('sessions')}</h4>
      {u.sessions.map((s: any) => <div key={s.ref} className="sum-row" style={{ fontSize: 13 }}><span>{s.device ?? '—'} · {s.ip}</span><span className="muted">{fmtDateTime(s.last_seen_at, locale)}</span></div>)}
      {!u.sessions.length && <span className="muted">{t('common.none')}</span>}
      <h4>{a('activity')}</h4>
      <div style={{ maxHeight: 260, overflow: 'auto' }}>{u.activity.map((x: any) => <div key={x.id} className="sum-row" style={{ fontSize: 12.5 }}><span><b>{x.action}</b> <span className="muted">{x.entity}{x.entity_id ? ` #${x.entity_id}` : ''}</span> {x.result !== 'success' && pill('#FEE2E2', '#991B1B', a(`r_${x.result}`))}</span><span className="muted">{fmtDateTime(x.created_at, locale)}</span></div>)}</div>
    </Modal>
  );
}

// ===================================================== Rôles & permissions =====================================================
function Roles() {
  const { a, t } = useA();
  const toast = useToast();
  const { can, me } = useAuth();
  const [roles, setRoles] = useState<any[]>([]);
  const [meta, setMeta] = useState<any>(null);
  const [sel, setSel] = useState<number | null>(null);
  const [perms, setPerms] = useState<Set<string>>(new Set());
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [members, setMembers] = useState<any[]>([]);
  const [create, setCreate] = useState<any>(null);
  const load = () => get('/api/admin/roles').then((r) => { setRoles(r); return r; });
  useEffect(() => { load().then((r) => r[0] && pick(r[0])).catch(errT(toast)); get('/api/admin/permissions').then(setMeta).catch(() => {}); }, []);
  const pick = (r: any) => { setSel(r.id); setPerms(new Set(r.permissions)); setName(r.name); setDesc(r.description ?? ''); get(`/api/admin/roles/${r.id}/users`).then(setMembers).catch(() => setMembers([])); };
  const role = roles.find((r) => r.id === sel);
  const locked = !role || role.code === 'admin' || !can('roles.manage');
  const byModule = useMemo(() => { const m: Record<string, any[]> = {}; for (const p of meta?.permissions ?? []) (m[p.module] ??= []).push(p); return m; }, [meta]);
  const toggle = (c: string) => { if (locked) return; const n = new Set(perms); n.has(c) ? n.delete(c) : n.add(c); setPerms(n); };
  const save = async () => { try { await api('PUT', `/api/admin/roles/${sel}`, { name, description: desc, permissions: [...perms] }); toast('success', a('saved')); const r = await load(); pick(r.find((x: any) => x.id === sel)); } catch (e: any) { toast('error', e.message); } };
  const setActive = async (active: boolean) => { try { await post(`/api/admin/roles/${sel}/status`, { active }); toast('success', a('done')); load(); } catch (e: any) { toast('error', e.message); } };
  const mine = (c: string) => me?.role === 'admin' || me?.permissions.includes(c);
  return (
    <div className="grid" style={{ gridTemplateColumns: 'minmax(220px, 280px) 1fr', alignItems: 'start' }}>
      <div className="card" style={{ padding: 8 }}>
        {can('roles.manage') && <button className="btn sm primary" style={{ width: '100%', marginBottom: 6 }} onClick={() => setCreate({ code: '', name: '', copy_from: '' })}><Icon name="plus" size={14} />{a('newRole')}</button>}
        {roles.map((r) => <div key={r.id} className="row" style={{ cursor: 'pointer', padding: '7px 10px', borderRadius: 8, fontSize: 13.5, background: sel === r.id ? '#7A1F2B' : undefined, color: sel === r.id ? '#fff' : 'inherit', opacity: r.active ? 1 : 0.5, justifyContent: 'space-between' }} onClick={() => pick(r)}><span>{r.name}{r.code === 'admin' && ' 🔒'}</span><span style={{ fontSize: 12, opacity: 0.7 }}>{r.users_active}</span></div>)}
      </div>
      {role && meta && <div className="card">
        <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          <input className="input" style={{ maxWidth: 260, fontWeight: 600 }} value={name} disabled={locked} onChange={(e) => setName(e.target.value)} />
          <input className="input" style={{ flex: 1, minWidth: 200 }} placeholder={a('description')} value={desc} disabled={locked} onChange={(e) => setDesc(e.target.value)} />
          <span className="muted">{role.code} · {role.builtin ? a('builtin') : a('custom')}{role.customized && role.builtin ? ` · ${a('customized')}` : ''}</span>
        </div>
        {role.code === 'admin' && <div className="alert info" style={{ marginTop: 8 }}>{a('adminLocked')}</div>}
        <div className="row" style={{ gap: 8, margin: '8px 0', flexWrap: 'wrap' }}>
          <span className="muted">{perms.size} {a('permissions')} · {role.users_active} {a('activeUsers')}</span><span style={{ flex: 1 }} />
          {!locked && <button className="btn sm" onClick={() => setCreate({ code: `${role.code}_copie`, name: `${role.name} (copie)`, copy_from: role.id })}>{a('duplicate')}</button>}
          {!locked && (role.active ? <button className="btn sm danger" onClick={() => setActive(false)}>{a('disable')}</button> : <button className="btn sm" onClick={() => setActive(true)}>{a('enable')}</button>)}
          {!locked && <button className="btn sm primary" onClick={save}>{t('common.save')}</button>}
        </div>
        <div style={{ maxHeight: '60vh', overflow: 'auto' }}>
          <table className="table" style={{ fontSize: 13 }}><tbody>
            {Object.entries(byModule).map(([mod, ps]) => (
              <tr key={mod}><td style={{ width: 170, verticalAlign: 'top' }}><b>{meta.modules[mod] ?? mod}</b></td>
                <td><div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{ps.map((p: any) => (
                  <label key={p.code} className={`chip ${perms.has(p.code) ? 'on' : ''}`} title={p.description} style={{ fontSize: 12, padding: '4px 10px', opacity: locked || mine(p.code) ? 1 : 0.45, cursor: locked ? 'default' : 'pointer' }}>
                    <input type="checkbox" style={{ display: 'none' }} checked={perms.has(p.code)} onChange={() => toggle(p.code)} disabled={locked || !mine(p.code)} />
                    {a(`ac_${p.action}`)} · {p.code.split('.').slice(1).join('.')}{p.sensitive ? ' ⚠' : ''}
                  </label>))}</div></td></tr>))}
          </tbody></table>
        </div>
        <p className="muted" style={{ fontSize: 12 }}>⚠ {a('sensitiveHint')}</p>
        <h4>{a('members')} ({members.length})</h4>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{members.map((m) => <span key={m.id} className="pill" style={{ background: 'var(--soft)', opacity: m.active ? 1 : 0.5 }}>{m.full_name}</span>)}</div>
      </div>}
      {create && <Modal title={create.copy_from ? a('duplicate') : a('newRole')} onClose={() => setCreate(null)} footer={<><button className="btn" onClick={() => setCreate(null)}>{t('common.cancel')}</button><button className="btn primary" onClick={async () => {
        try { const r = await post('/api/admin/roles', { code: create.code, name: create.name, permissions: [], copy_from: create.copy_from ? Number(create.copy_from) : undefined }); toast('success', a('saved')); setCreate(null); const all = await load(); pick(all.find((x: any) => x.id === r.id)); } catch (e: any) { toast('error', e.message); }
      }}>{t('common.save')}</button></>}>
        <Field label={a('code')}><input className="input" value={create.code} onChange={(e) => setCreate({ ...create, code: e.target.value })} /></Field>
        <Field label={a('name')}><input className="input" value={create.name} onChange={(e) => setCreate({ ...create, name: e.target.value })} /></Field>
        <Field label={a('copyFrom')}><select className="input" value={create.copy_from} onChange={(e) => setCreate({ ...create, copy_from: e.target.value })}><option value="">—</option>{roles.filter((r) => r.code !== 'admin').map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></Field>
      </Modal>}
    </div>
  );
}

// ===================================================== Départements =====================================================
function Departments() {
  const { a, t } = useA();
  const toast = useToast();
  const [rows, setRows] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [edit, setEdit] = useState<any>(null);
  const [mem, setMem] = useState<any>(null);
  const load = () => get('/api/admin/departments').then(setRows).catch(errT(toast));
  useEffect(() => { load(); get('/api/admin/users-brief').then((x) => setUsers(x.filter((u: any) => u.active))).catch(() => {}); }, []);
  const save = async () => {
    try {
      const body = { name: edit.name, description: edit.description, manager_user_id: edit.manager_user_id ? Number(edit.manager_user_id) : null };
      if (edit.id) await patch(`/api/admin/departments/${edit.id}`, body); else await post('/api/admin/departments', { ...body, code: edit.code });
      toast('success', a('saved')); setEdit(null); load();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <>
      <div className="row"><span style={{ flex: 1 }} /><button className="btn primary" onClick={() => setEdit({ code: '', name: '', description: '', manager_user_id: '' })}><Icon name="plus" size={14} />{a('newDept')}</button></div>
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}><table className="table">
        <thead><tr><th>{a('name')}</th><th>{a('code')}</th><th>{a('manager')}</th><th>{a('accounts')}</th><th>{a('employees')}</th><th>{a('status')}</th><th /></tr></thead>
        <tbody>{rows.map((d) => <tr key={d.id} style={{ opacity: d.active ? 1 : 0.55 }}>
          <td><b>{d.name}</b><div className="muted" style={{ fontSize: 12 }}>{d.description}</div></td><td>{d.code}</td><td>{d.manager_name ?? '—'}</td><td>{d.users_active}</td><td>{d.employees_active}</td>
          <td>{d.active ? pill('#DCFCE7', '#166534', a('st_active')) : pill('#F1F5F9', '#475569', a('st_disabled'))}</td>
          <td className="row" style={{ gap: 4 }}>
            <button className="btn sm" onClick={() => get(`/api/admin/departments/${d.id}/members`).then((m) => setMem({ d, ...m, add: '' }))}>{a('members')}</button>
            <button className="btn sm" onClick={() => setEdit({ ...d, manager_user_id: d.manager_user_id ?? '' })}>{a('edit')}</button>
            <button className="btn sm ghost" onClick={() => patch(`/api/admin/departments/${d.id}`, { active: !d.active }).then(load).catch(errT(toast))}>{d.active ? a('disable') : a('enable')}</button>
          </td></tr>)}</tbody></table></div>
      <p className="muted" style={{ fontSize: 12 }}>{a('deptNoDelete')}</p>
      {edit && <Modal title={edit.id ? edit.name : a('newDept')} onClose={() => setEdit(null)} footer={<><button className="btn" onClick={() => setEdit(null)}>{t('common.cancel')}</button><button className="btn primary" onClick={save}>{t('common.save')}</button></>}>
        {!edit.id && <Field label={a('code')}><input className="input" value={edit.code} onChange={(e) => setEdit({ ...edit, code: e.target.value })} /></Field>}
        <Field label={a('name')}><input className="input" value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></Field>
        <Field label={a('description')}><input className="input" value={edit.description ?? ''} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></Field>
        <Field label={a('manager')}><select className="input" value={edit.manager_user_id} onChange={(e) => setEdit({ ...edit, manager_user_id: e.target.value })}><option value="">—</option>{users.map((u) => <option key={u.id} value={u.id}>{u.full_name}</option>)}</select></Field>
      </Modal>}
      {mem && <Modal title={`${a('members')} — ${mem.d.name}`} onClose={() => setMem(null)} size="lg">
        <div className="row" style={{ gap: 8 }}>
          <select className="input" value={mem.add} onChange={(e) => setMem({ ...mem, add: e.target.value })}><option value="">{a('assignUser')}</option>{users.filter((u) => u.department_id !== mem.d.id).map((u) => <option key={u.id} value={u.id}>{u.full_name} ({u.department_name ?? '—'})</option>)}</select>
          <button className="btn primary" disabled={!mem.add} onClick={async () => { try { await post(`/api/admin/departments/${mem.d.id}/assign`, { user_ids: [Number(mem.add)] }); const m = await get(`/api/admin/departments/${mem.d.id}/members`); setMem({ ...mem, ...m, add: '' }); load(); } catch (e: any) { toast('error', e.message); } }}>{a('assign')}</button>
        </div>
        <h4>{a('accounts')}</h4>{mem.users.map((u: any) => <div key={u.id} className="sum-row"><span>{u.full_name}</span><span className="muted">{u.role_name}</span></div>)}
        <h4>{a('employees')}</h4>{mem.employees.map((e: any) => <div key={e.id} className="sum-row"><span>{e.last_name} {e.first_name}</span><span className="muted">{e.position}</span></div>)}
      </Modal>}
    </>
  );
}

// ===================================================== Établissement =====================================================
function Hotel() {
  const { a, t } = useA();
  const toast = useToast();
  const { refresh } = useAuth();
  const [d, setD] = useState<any>(null);
  const [f, setF] = useState<any>(null);
  const [v, setV] = useState(0);
  const load = () => get('/api/admin/hotel').then((r) => { setD(r); const h = r.hotel; setF({ ...h, check_in_time: r.check_in_time, check_out_time: r.check_out_time, languages: h.languages ?? ['fr', 'ar', 'en'] }); }).catch(errT(toast));
  useEffect(() => { load(); }, []);
  if (!f) return null;
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    try {
      const keys = ['name', 'commercial_name', 'description', 'category', 'stars', 'address', 'city', 'postal_code', 'country', 'phone', 'email', 'website', 'nif', 'nis', 'rc', 'art', 'restaurants_count', 'check_in_time', 'check_out_time', 'timezone', 'primary_language', 'languages', 'date_format', 'time_format'];
      const body: any = Object.fromEntries(keys.map((k) => [k, f[k] === '' ? null : f[k]]));
      body.stars = f.stars === '' || f.stars === null ? null : Number(f.stars); body.restaurants_count = f.restaurants_count === '' || f.restaurants_count === null ? null : Number(f.restaurants_count);
      await api('PUT', '/api/admin/hotel', body); toast('success', a('saved')); refresh(); load();
    } catch (e: any) { toast('error', e.message); }
  };
  const In = ({ k, type = 'text' }: { k: string; type?: string }) => <Field label={a(`h_${k}`)}><input className="input" type={type} value={f[k] ?? ''} onChange={set(k)} /></Field>;
  return (
    <>
      <div className="card"><h3 style={{ marginTop: 0 }}>{a('identity')}</h3>
        <div className="row" style={{ gap: 16, alignItems: 'center', marginBottom: 10 }}>
          <div style={{ width: 120, height: 60, border: '1px dashed var(--border)', borderRadius: 8, display: 'grid', placeItems: 'center', overflow: 'hidden' }}>{f.logo_id ? <img src={`/api/hotel/logo/${f.logo_id}?v=${v}`} alt="logo" style={{ maxWidth: '100%', maxHeight: '100%' }} /> : <span className="muted">Logo</span>}</div>
          <label className="btn sm">{a('uploadLogo')}<input type="file" accept="image/png,image/jpeg" style={{ display: 'none' }} onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; try { await upload('/api/admin/hotel/logo', file, {}); setV(v + 1); toast('success', a('saved')); load(); } catch (er: any) { toast('error', er.message); } }} /></label>
          {f.logo_id && <button className="btn sm ghost" onClick={() => api('DELETE', '/api/admin/hotel/logo').then(load).catch(errT(toast))}>{a('removeLogo')}</button>}
          <span className="muted" style={{ fontSize: 12 }}>PNG / JPEG ≤ 1 Mo</span>
        </div>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 10 }}>
          {In({ k: 'name' })}{In({ k: 'commercial_name' })}{In({ k: 'category' })}
          <Field label={a('h_stars')}><select className="input" value={f.stars ?? ''} onChange={set('stars')}><option value="">—</option>{[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{'★'.repeat(n)}</option>)}</select></Field>
          {In({ k: 'address' })}{In({ k: 'city' })}{In({ k: 'postal_code' })}{In({ k: 'country' })}{In({ k: 'phone' })}{In({ k: 'email' })}{In({ k: 'website' })}
        </div>
        <Field label={a('h_description')}><textarea className="input" rows={2} value={f.description ?? ''} onChange={set('description')} /></Field>
      </div>
      <div className="card"><h3 style={{ marginTop: 0 }}>{a('fiscalInfo')}</h3>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 10 }}>{In({ k: 'nif' })}{In({ k: 'nis' })}{In({ k: 'rc' })}{In({ k: 'art' })}</div>
      </div>
      <div className="card"><h3 style={{ marginTop: 0 }}>{a('capacity')}</h3>
        <div className="row" style={{ gap: 18, flexWrap: 'wrap' }}>{['rooms', 'floors', 'room_types', 'capacity', 'services'].map((k) => <span key={k}>{a(`c_${k}`)} : <b>{d.counts?.[k] ?? '—'}</b></span>)}
          <span style={{ minWidth: 160 }}>{In({ k: 'restaurants_count', type: 'number' })}</span></div>
        <p className="muted" style={{ fontSize: 12 }}>{a('capacityHint')}</p>
      </div>
      <div className="card"><h3 style={{ marginTop: 0 }}>{a('operation')}</h3>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 10 }}>
          {In({ k: 'check_in_time', type: 'time' })}{In({ k: 'check_out_time', type: 'time' })}
          <Field label={a('h_timezone')}><select className="input" value={f.timezone} onChange={set('timezone')}>{(d.timezones as string[]).map((z) => <option key={z}>{z}</option>)}</select></Field>
          <Field label={a('h_primary_language')}><select className="input" value={f.primary_language} onChange={set('primary_language')}>{f.languages.map((l: string) => <option key={l} value={l}>{l.toUpperCase()}</option>)}</select></Field>
          <Field label={a('h_languages')}><div className="row" style={{ gap: 6 }}>{['fr', 'ar', 'en'].map((l) => <label key={l} className={`chip ${f.languages.includes(l) ? 'on' : ''}`}><input type="checkbox" style={{ display: 'none' }} checked={f.languages.includes(l)} onChange={() => setF({ ...f, languages: f.languages.includes(l) ? f.languages.filter((x: string) => x !== l) : [...f.languages, l] })} />{l.toUpperCase()}</label>)}</div></Field>
          <Field label={a('h_date_format')}><select className="input" value={f.date_format} onChange={set('date_format')}>{['DD/MM/YYYY', 'YYYY-MM-DD', 'MM/DD/YYYY'].map((x) => <option key={x}>{x}</option>)}</select></Field>
          <Field label={a('h_time_format')}><select className="input" value={f.time_format} onChange={set('time_format')}><option value="24h">24 h</option><option value="12h">12 h (AM/PM)</option></select></Field>
        </div>
        <p className="muted" style={{ fontSize: 12 }}>{a('currencyIn')}</p>
      </div>
      <div className="row"><span style={{ flex: 1 }} /><button className="btn primary" onClick={save}>{t('common.save')}</button></div>
    </>
  );
}

// ===================================================== Finances & taxes =====================================================
const PMS = ['cash', 'card', 'cheque', 'transfer', 'company_account', 'online'];
function Finance() {
  const { a, t, locale } = useA();
  const toast = useToast();
  const { refresh } = useAuth();
  const [d, setD] = useState<any>(null);
  const [f, setF] = useState<any>(null);
  const [tx, setTx] = useState<any>(null);
  const today = new Date().toISOString().slice(0, 10);
  const load = () => get('/api/admin/finance').then((r) => { setD(r); setF({ currency: r.currency, currency_symbol: r.currency_symbol, decimals: r.decimals, payment_methods: r.payment_methods, invoice_footer: r.invoice_footer ?? '' }); }).catch(errT(toast));
  useEffect(() => { load(); }, []);
  if (!f) return null;
  const save = async () => { try { await api('PUT', '/api/admin/finance', { ...f, decimals: Number(f.decimals) }); toast('success', a('saved')); refresh(); load(); } catch (e: any) { toast('error', e.message); } };
  const cats = [...new Set(['default', 'tourist', ...Object.keys(d.tax_rates ?? {}), ...d.taxes.map((x: any) => x.category)])];
  return (
    <>
      <div className="card"><h3 style={{ marginTop: 0 }}>{a('currency')}</h3>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 10 }}>
          <Field label={a('currencyCode')}><input className="input" value={f.currency} onChange={(e) => setF({ ...f, currency: e.target.value.toUpperCase() })} maxLength={3} /></Field>
          <Field label={a('symbol')}><input className="input" value={f.currency_symbol} onChange={(e) => setF({ ...f, currency_symbol: e.target.value })} maxLength={6} /></Field>
          <Field label={a('decimals')}><select className="input" value={f.decimals} onChange={(e) => setF({ ...f, decimals: Number(e.target.value) })}><option value={2}>2 (0,00)</option><option value={0}>0</option></select></Field>
        </div>
        <p className="muted" style={{ fontSize: 12 }}>{a('currencyHint')}</p>
        <h4>{a('paymentMethods')}</h4>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{PMS.map((m) => <label key={m} className={`chip ${f.payment_methods.includes(m) ? 'on' : ''}`}><input type="checkbox" style={{ display: 'none' }} checked={f.payment_methods.includes(m)} onChange={() => setF({ ...f, payment_methods: f.payment_methods.includes(m) ? f.payment_methods.filter((x: string) => x !== m) : [...f.payment_methods, m] })} />{a(`pm_${m}`)}</label>)}</div>
        <Field label={a('invoiceFooter')}><textarea className="input" rows={2} value={f.invoice_footer} onChange={(e) => setF({ ...f, invoice_footer: e.target.value })} /></Field>
        <div className="row"><span className="muted" style={{ fontSize: 12 }}>{a('fiscalWhere')} : NIF {d.fiscal.nif ?? '—'} · NIS {d.fiscal.nis ?? '—'} · RC {d.fiscal.rc ?? '—'}</span><span style={{ flex: 1 }} /><button className="btn primary" onClick={save}>{t('common.save')}</button></div>
      </div>
      <div className="card"><div className="row"><h3 style={{ margin: 0, flex: 1 }}>{a('taxes')}</h3><button className="btn sm primary" onClick={() => setTx({ category: 'default', name: '', rate: '', valid_from: today, note: '' })}><Icon name="plus" size={14} />{a('newTaxVersion')}</button></div>
        <div className="alert info" style={{ margin: '8px 0' }}>{a('taxHint')}</div>
        <table className="table" style={{ fontSize: 13 }}><thead><tr><th>{a('category')}</th><th>{a('name')}</th><th>{a('rate')}</th><th>{a('validFrom')}</th><th>{a('note')}</th><th>{a('by')}</th><th>{a('status')}</th></tr></thead>
          <tbody>{d.taxes.map((x: any) => { const eff = d.effective.some((e: any) => e.id === x.id); const fut = String(x.valid_from).slice(0, 10) > today; return (
            <tr key={x.id}><td>{a(`tc_${x.category}`).startsWith('adm.') ? x.category : a(`tc_${x.category}`)}</td><td>{x.name}</td><td><b>{Number(x.rate)}{x.category === 'tourist' ? ` ${f.currency_symbol}` : ' %'}</b></td><td>{String(x.valid_from).slice(0, 10)}</td><td className="muted">{x.note}</td><td className="muted">{x.created_by_name ?? '—'}</td>
              <td>{eff ? pill('#DCFCE7', '#166534', a('effective')) : fut ? pill('#DBEAFE', '#1E3A8A', a('planned')) : pill('#F1F5F9', '#64748B', a('history'))}</td></tr>); })}</tbody></table>
      </div>
      {tx && <Modal title={a('newTaxVersion')} onClose={() => setTx(null)} footer={<><button className="btn" onClick={() => setTx(null)}>{t('common.cancel')}</button><button className="btn primary" onClick={async () => { try { await post('/api/admin/taxes', { ...tx, rate: Number(tx.rate) }); toast('success', a('saved')); setTx(null); load(); } catch (e: any) { toast('error', e.message); } }}>{t('common.save')}</button></>}>
        <Field label={a('category')}><select className="input" value={tx.category} onChange={(e) => setTx({ ...tx, category: e.target.value })}>{cats.map((c) => <option key={c} value={c}>{a(`tc_${c}`).startsWith('adm.') ? c : a(`tc_${c}`)}</option>)}</select></Field>
        <Field label={a('name')}><input className="input" value={tx.name} onChange={(e) => setTx({ ...tx, name: e.target.value })} /></Field>
        <Field label={`${a('rate')} (${tx.category === 'tourist' ? f.currency_symbol : '%'})`}><input className="input" type="number" min={0} step="0.01" value={tx.rate} onChange={(e) => setTx({ ...tx, rate: e.target.value })} /></Field>
        <Field label={a('validFrom')}><input className="input" type="date" min={today} value={tx.valid_from} onChange={(e) => setTx({ ...tx, valid_from: e.target.value })} /></Field>
        <Field label={a('note')}><input className="input" value={tx.note} onChange={(e) => setTx({ ...tx, note: e.target.value })} placeholder={a('noteHint')} /></Field>
        <span className="muted" style={{ fontSize: 12 }}>{fmtDateTime(new Date().toISOString(), locale)}</span>
      </Modal>}
    </>
  );
}

// ===================================================== Services =====================================================
const SVC_CATS = ['restaurant', 'room_service', 'spa', 'parking', 'laundry', 'transfer', 'meeting_room', 'breakfast', 'minibar', 'other'];
function Services() {
  const { a, t } = useA();
  const toast = useToast();
  const [rows, setRows] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [e, setE] = useState<any>(null);
  const load = () => get('/api/admin/services').then(setRows).catch(errT(toast));
  useEffect(() => { load(); get('/api/admin/users-brief').then((x) => setUsers(x.filter((u: any) => u.active))).catch(() => setUsers([])); }, []);
  const save = async () => {
    try {
      const body = { ...e, price: Number(e.price), manager_user_id: e.manager_user_id ? Number(e.manager_user_id) : null };
      for (const k of ['id', 'hotel_id', 'sort_order', 'manager_name']) delete body[k];
      if (e.id) await patch(`/api/admin/services/${e.id}`, body); else await post('/api/admin/services', body);
      toast('success', a('saved')); setE(null); load();
    } catch (er: any) { toast('error', er.message); }
  };
  return (
    <>
      <div className="row"><span className="muted" style={{ flex: 1, fontSize: 12 }}>{a('servicesHint')}</span><button className="btn primary" onClick={() => setE({ code: '', name: '', description: '', category: 'other', price: 0, unit: 'unit', pricing: 'fixed', opening_hours: '', manager_user_id: '', active: true })}><Icon name="plus" size={14} />{a('newService')}</button></div>
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}><table className="table"><thead><tr><th>{a('name')}</th><th>{a('category')}</th><th>{a('pricing')}</th><th>{a('hours')}</th><th>{a('manager')}</th><th>{a('status')}</th><th /></tr></thead>
        <tbody>{rows.map((s) => <tr key={s.id} style={{ opacity: s.active ? 1 : 0.55 }}><td><b>{s.name}</b> <span className="muted">{s.code}</span><div className="muted" style={{ fontSize: 12 }}>{s.description}</div></td><td>{a(`sc_${s.category}`)}</td>
          <td>{s.pricing === 'free' ? a('pr_free') : s.pricing === 'none' ? '—' : `${Number(s.price)} / ${a(`u_${s.unit}`)}${s.pricing === 'variable' ? ` (${a('pr_variable')})` : ''}`}</td><td>{s.opening_hours ?? '—'}</td><td>{s.manager_name ?? '—'}</td>
          <td>{s.active ? pill('#DCFCE7', '#166534', a('st_active')) : pill('#F1F5F9', '#475569', a('st_disabled'))}</td><td><button className="btn sm" onClick={() => setE({ ...s, manager_user_id: s.manager_user_id ?? '', description: s.description ?? '', opening_hours: s.opening_hours ?? '', price: Number(s.price) })}>{a('edit')}</button></td></tr>)}</tbody></table></div>
      {e && <Modal title={e.id ? e.name : a('newService')} onClose={() => setE(null)} size="lg" footer={<><button className="btn" onClick={() => setE(null)}>{t('common.cancel')}</button><button className="btn primary" onClick={save}>{t('common.save')}</button></>}>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 10 }}>
          <Field label={a('code')}><input className="input" value={e.code} onChange={(x) => setE({ ...e, code: x.target.value })} /></Field>
          <Field label={a('name')}><input className="input" value={e.name} onChange={(x) => setE({ ...e, name: x.target.value })} /></Field>
          <Field label={a('category')}><select className="input" value={e.category} onChange={(x) => setE({ ...e, category: x.target.value })}>{SVC_CATS.map((c) => <option key={c} value={c}>{a(`sc_${c}`)}</option>)}</select></Field>
          <Field label={a('pricing')}><select className="input" value={e.pricing} onChange={(x) => setE({ ...e, pricing: x.target.value })}>{['fixed', 'variable', 'free', 'none'].map((c) => <option key={c} value={c}>{a(`pr_${c}`)}</option>)}</select></Field>
          <Field label={a('price')}><input className="input" type="number" min={0} value={e.price} onChange={(x) => setE({ ...e, price: x.target.value })} disabled={e.pricing === 'free'} /></Field>
          <Field label={a('unit')}><select className="input" value={e.unit} onChange={(x) => setE({ ...e, unit: x.target.value })}>{['unit', 'person', 'night', 'kg', 'trip', 'day'].map((c) => <option key={c} value={c}>{a(`u_${c}`)}</option>)}</select></Field>
          <Field label={a('hours')}><input className="input" value={e.opening_hours} placeholder="07:00-22:00" onChange={(x) => setE({ ...e, opening_hours: x.target.value })} /></Field>
          <Field label={a('manager')}><select className="input" value={e.manager_user_id} onChange={(x) => setE({ ...e, manager_user_id: x.target.value })}><option value="">—</option>{users.map((u) => <option key={u.id} value={u.id}>{u.full_name}</option>)}</select></Field>
          <label className="row" style={{ gap: 8, alignSelf: 'end' }}><input type="checkbox" checked={e.active} onChange={(x) => setE({ ...e, active: x.target.checked })} />{a('st_active')}</label>
        </div>
        <Field label={a('description')}><textarea className="input" rows={2} value={e.description} onChange={(x) => setE({ ...e, description: x.target.value })} /></Field>
      </Modal>}
    </>
  );
}

// ===================================================== Documents =====================================================
function Documents() {
  const { a, t } = useA();
  const toast = useToast();
  const [f, setF] = useState<any>(null);
  useEffect(() => { get('/api/admin/documents').then(setF).catch(errT(toast)); }, []);
  if (!f) return null;
  const save = async () => { try { await api('PUT', '/api/admin/documents', { invoice_paper: f.invoice_paper, show_logo: f.show_logo, show_fiscal: f.show_fiscal, receipt_header: f.receipt_header ?? '', copies: Number(f.copies), invoice_footer: f.invoice_footer ?? '' }); toast('success', a('saved')); } catch (e: any) { toast('error', e.message); } };
  return (
    <div className="card">
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 10 }}>
        <Field label={a('paper')}><select className="input" value={f.invoice_paper} onChange={(e) => setF({ ...f, invoice_paper: e.target.value })}><option value="A4">A4</option><option value="thermal">{a('thermal')}</option></select></Field>
        <Field label={a('copies')}><select className="input" value={f.copies} onChange={(e) => setF({ ...f, copies: Number(e.target.value) })}>{[1, 2, 3].map((n) => <option key={n}>{n}</option>)}</select></Field>
        <label className="row" style={{ gap: 8 }}><input type="checkbox" checked={f.show_logo} onChange={(e) => setF({ ...f, show_logo: e.target.checked })} />{a('showLogo')}</label>
        <label className="row" style={{ gap: 8 }}><input type="checkbox" checked={f.show_fiscal} onChange={(e) => setF({ ...f, show_fiscal: e.target.checked })} />{a('showFiscal')}</label>
      </div>
      <Field label={a('receiptHeader')}><input className="input" value={f.receipt_header ?? ''} onChange={(e) => setF({ ...f, receipt_header: e.target.value })} /></Field>
      <Field label={a('invoiceFooter')}><textarea className="input" rows={2} value={f.invoice_footer ?? ''} onChange={(e) => setF({ ...f, invoice_footer: e.target.value })} /></Field>
      <p className="muted" style={{ fontSize: 12 }}>{a('docsHint')}</p>
      <div className="row"><span style={{ flex: 1 }} /><button className="btn primary" onClick={save}>{t('common.save')}</button></div>
    </div>
  );
}

// ===================================================== Notifications =====================================================
function Notifs() {
  const { a, t } = useA();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  useEffect(() => { get('/api/admin/notifications').then(setD).catch(errT(toast)); }, []);
  if (!d) return null;
  const upd = (k: string, v: any) => setD({ ...d, config: { ...d.config, [k]: { ...d.config[k], ...v } } });
  const save = async () => { try { await api('PUT', '/api/admin/notifications', d.config); toast('success', a('saved')); } catch (e: any) { toast('error', e.message); } };
  return (
    <>
      <p className="muted" style={{ fontSize: 13 }}>{a('notifHint')}</p>
      {d.kinds.map((k: string) => { const c = d.config[k] ?? { enabled: false, roles: [], users: [] }; return (
        <div key={k} className="card">
          <label className="row" style={{ gap: 8, fontWeight: 600 }}><input type="checkbox" checked={c.enabled} onChange={(e) => upd(k, { enabled: e.target.checked })} />{a(`nk_${k}`)}</label>
          <div className="row" style={{ gap: 6, flexWrap: 'wrap', marginTop: 8, opacity: c.enabled ? 1 : 0.5 }}>
            <span className="muted" style={{ fontSize: 12 }}>{a('recipients')} :</span>
            {d.roles.map((r: any) => <label key={r.code} className={`chip ${c.roles.includes(r.code) ? 'on' : ''}`} style={{ fontSize: 12, padding: '3px 9px' }}><input type="checkbox" style={{ display: 'none' }} checked={c.roles.includes(r.code)} onChange={() => upd(k, { roles: c.roles.includes(r.code) ? c.roles.filter((x: string) => x !== r.code) : [...c.roles, r.code] })} />{r.name}</label>)}
          </div>
        </div>); })}
      <div className="row"><span style={{ flex: 1 }} /><button className="btn primary" onClick={save}>{t('common.save')}</button></div>
    </>
  );
}

// ===================================================== Sécurité =====================================================
function Security() {
  const { a, t, locale } = useA();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const [p, setP] = useState<any>(null);
  const load = () => get('/api/admin/security').then((r) => { setD(r); setP(r.policy); }).catch(errT(toast));
  useEffect(() => { load(); }, []);
  if (!d) return null;
  const num = (k: string) => <Field label={a(`sp_${k}`)}><input className="input" type="number" value={p[k]} onChange={(e) => setP({ ...p, [k]: Number(e.target.value) })} /></Field>;
  const act = (fn: () => Promise<any>) => fn().then(() => { toast('success', a('done')); load(); }).catch(errT(toast));
  return (
    <>
      <div className="card"><h3 style={{ marginTop: 0 }}>{a('policy')}</h3>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 10 }}>{num('session_idle_minutes')}{num('max_failed_logins')}{num('lock_minutes')}{num('password_min_length')}{num('reset_code_minutes')}</div>
        <div className="row"><span className="muted" style={{ fontSize: 12, flex: 1 }}>{a('policyHint')} · {a('sessionMax')} {d.session_hours} h · {a('deviceApproval')} : {d.device_approval ? a('yes') : a('no')}</span><button className="btn primary" onClick={() => act(() => api('PUT', '/api/admin/security', p))}>{t('common.save')}</button></div>
      </div>
      {d.locked.length > 0 && <div className="card"><h3 style={{ marginTop: 0 }}>{a('lockedAccounts')}</h3>{d.locked.map((u: any) => <div key={u.id} className="sum-row"><span>{u.full_name} ({u.username}) → {fmtDateTime(u.locked_until, locale)}</span><button className="btn sm" onClick={() => act(() => post(`/api/admin/users/${u.id}/unlock`, {}))}>{a('unlock')}</button></div>)}</div>}
      <div className="card" style={{ overflowX: 'auto' }}><h3 style={{ marginTop: 0 }}>{a('openSessions')} ({d.sessions.length})</h3>
        <table className="table" style={{ fontSize: 13 }}><thead><tr><th>{a('name')}</th><th>{a('role')}</th><th>{a('device')}</th><th>IP</th><th>{a('since')}</th><th>{a('lastSeen')}</th><th /></tr></thead>
          <tbody>{d.sessions.map((s: any) => <tr key={s.ref}><td>{s.full_name}</td><td>{s.role_name}</td><td>{s.device ?? '—'}</td><td>{s.ip}</td><td>{fmtDateTime(s.created_at, locale)}</td><td>{fmtDateTime(s.last_seen_at, locale)}</td><td><button className="btn sm ghost" onClick={() => act(() => post(`/api/admin/sessions/${s.ref}/revoke`, {}))}>{a('revoke')}</button></td></tr>)}</tbody></table>
      </div>
      <div className="card" style={{ overflowX: 'auto' }}><h3 style={{ marginTop: 0 }}>{a('devices')}</h3>
        <table className="table" style={{ fontSize: 13 }}><thead><tr><th>N°</th><th>{a('name')}</th><th>{a('status')}</th><th>{a('lastSeen')}</th><th>{a('approvedBy')}</th><th /></tr></thead>
          <tbody>{d.devices.map((x: any) => <tr key={x.id}><td>{x.id}</td><td>{x.name}</td><td>{x.status === 'approved' ? pill('#DCFCE7', '#166534', a('dv_approved')) : x.status === 'pending' ? pill('#FEF3C7', '#92400E', a('dv_pending')) : pill('#FEE2E2', '#991B1B', a('dv_revoked'))}</td>
            <td>{x.last_seen_at ? fmtDateTime(x.last_seen_at, locale) : '—'}</td><td>{x.approved_by ?? '—'}</td>
            <td className="row" style={{ gap: 4 }}>{x.status !== 'approved' && <button className="btn sm primary" onClick={() => act(() => post(`/api/devices/${x.id}/approve`, {}))}>{a('approve')}</button>}{x.status !== 'revoked' && <button className="btn sm danger" onClick={() => act(() => post(`/api/devices/${x.id}/revoke`, {}))}>{a('block')}</button>}
              <button className="btn sm ghost" onClick={() => { const n = prompt(a('rename'), x.name); if (n) act(() => patch(`/api/admin/devices/${x.id}`, { name: n })); }}>{a('rename')}</button></td></tr>)}</tbody></table>
      </div>
      <div className="card"><h3 style={{ marginTop: 0 }}>{a('failed24')} ({d.failed_24h.length})</h3>
        {d.failed_24h.map((x: any, i: number) => <div key={i} className="sum-row" style={{ fontSize: 13 }}><span>{x.username ?? '—'} · {a(`fr_${x.reason}`).startsWith('adm.') ? x.reason : a(`fr_${x.reason}`)}</span><span className="muted">{x.ip} · {fmtDateTime(x.created_at, locale)}</span></div>)}
        {!d.failed_24h.length && <span className="muted">{t('common.none')}</span>}
      </div>
      <IpBlocks />
    </>
  );
}

/** Bouclier anti-robot : adresses bloquées automatiquement, déblocage manuel. */
function IpBlocks() {
  const { a, locale } = useA();
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null);
  const load = () => get('/api/admin/ip-blocks').then(setRows).catch(() => setRows([]));
  useEffect(() => { load(); }, []);
  if (!rows) return null;
  const R: Record<string, string> = { flood: a('ib_flood'), bruteforce: a('ib_bruteforce'), scan: a('ib_scan'), manual: a('ib_manual') };
  return (
    <div className="card" style={{ overflowX: 'auto' }}>
      <h3 style={{ marginTop: 0 }}>🛡️ {a('ib_title')}</h3>
      <p className="muted" style={{ marginTop: 0, fontSize: 13 }}>{a('ib_intro')}</p>
      {!rows.length ? <span className="muted">{a('ib_none')}</span> : (
        <table className="table"><thead><tr><th>{a('ib_ip')}</th><th>{a('ib_reason')}</th><th>{a('ib_since')}</th><th>{a('ib_until')}</th><th /></tr></thead>
          <tbody>{rows.map((r) => (
            <tr key={r.id} style={{ opacity: r.active ? 1 : 0.55 }}>
              <td><b>{r.ip}</b></td><td>{R[r.reason] ?? r.reason}<div className="muted" style={{ fontSize: 11 }}>{r.detail}</div></td>
              <td>{fmtDateTime(r.created_at, locale)}</td>
              <td>{r.active ? fmtDateTime(r.blocked_until, locale) : r.lifted_at ? `${a('ib_lifted')} ${r.lifted_by_name ?? ''}` : a('ib_expired')}</td>
              <td>{r.active && <button className="btn sm" onClick={() => post(`/api/admin/ip-blocks/${r.id}/lift`, {}).then(() => { toast('success', a('ib_liftedOk')); load(); }).catch((e) => toast('error', e.message))}>{a('ib_lift')}</button>}</td>
            </tr>))}</tbody></table>)}
    </div>
  );
}

// ===================================================== Journal =====================================================
function Audit() {
  const { a, t, locale } = useA();
  const toast = useToast();
  const [f, setF] = useState<any>({ module: '', user_id: '', action: '', result: '', from: '', to: '', q: '', page: 1 });
  const [d, setD] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [open, setOpen] = useState<any>(null);
  const qs = (x: any) => new URLSearchParams(Object.entries(x).filter(([, v]) => v !== '' && v !== null) as any).toString();
  useEffect(() => { get(`/api/admin/audit?${qs(f)}`).then(setD).catch(errT(toast)); }, [f]);
  useEffect(() => { get('/api/admin/users-brief').then(setUsers).catch(() => setUsers([])); }, []);
  const s = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value, page: 1 });
  return (
    <>
      <div className="card row" style={{ gap: 8, flexWrap: 'wrap' }}>
        <select className="input" style={{ maxWidth: 200 }} value={f.module} onChange={s('module')}><option value="">{a('allModules')}</option>{d && Object.entries(d.modules).map(([k, v]: any) => <option key={k} value={k}>{v}</option>)}</select>
        <select className="input" style={{ maxWidth: 200 }} value={f.user_id} onChange={s('user_id')}><option value="">{a('allUsers')}</option>{users.map((u) => <option key={u.id} value={u.id}>{u.full_name}</option>)}</select>
        <select className="input" style={{ maxWidth: 180 }} value={f.action} onChange={s('action')}><option value="">{a('allActions')}</option>{d?.actions.map((x: string) => <option key={x}>{x}</option>)}</select>
        <select className="input" style={{ maxWidth: 140 }} value={f.result} onChange={s('result')}><option value="">{a('allResults')}</option>{['success', 'failure', 'denied'].map((x) => <option key={x} value={x}>{a(`r_${x}`)}</option>)}</select>
        <input className="input" type="date" style={{ maxWidth: 150 }} value={f.from} onChange={s('from')} /><input className="input" type="date" style={{ maxWidth: 150 }} value={f.to} onChange={s('to')} />
        <input className="input" style={{ maxWidth: 160 }} placeholder={a('recordId')} value={f.q} onChange={s('q')} />
        <span style={{ flex: 1 }} />
        {['pdf', 'xlsx', 'csv'].map((x) => <a key={x} className="btn sm" href={`/api/admin/audit?${qs({ ...f, page: '', format: x })}`} target="_blank" rel="noreferrer">{x.toUpperCase()}</a>)}
      </div>
      {d && <div className="card" style={{ padding: 0, overflowX: 'auto' }}><table className="table" style={{ fontSize: 13 }}>
        <thead><tr><th>{a('date')}</th><th>{a('user')}</th><th>{a('module')}</th><th>{a('action')}</th><th>{a('record')}</th><th>{a('result')}</th><th>IP</th></tr></thead>
        <tbody>{d.rows.map((x: any) => <tr key={x.id} style={{ cursor: 'pointer' }} onClick={() => setOpen(x)}><td>{fmtDateTime(x.created_at, locale)}</td><td>{x.user_name ?? x.after?.username ?? '—'}</td><td>{d.modules[x.module] ?? x.module}</td><td><b>{x.action}</b></td><td className="muted">{x.entity}{x.entity_id ? ` #${x.entity_id}` : ''}</td>
          <td>{x.result === 'success' ? pill('#DCFCE7', '#166534', a('r_success')) : x.result === 'denied' ? pill('#FEF3C7', '#92400E', a('r_denied')) : pill('#FEE2E2', '#991B1B', a('r_failure'))}</td><td className="muted">{x.ip}</td></tr>)}</tbody></table>
        <div className="row" style={{ padding: 10, gap: 8 }}><span className="muted">{d.total} {a('entries')}</span><span style={{ flex: 1 }} />
          <button className="btn sm" disabled={f.page <= 1} onClick={() => setF({ ...f, page: f.page - 1 })}>‹</button><span>{f.page} / {Math.max(1, Math.ceil(d.total / d.size))}</span><button className="btn sm" disabled={f.page * d.size >= d.total} onClick={() => setF({ ...f, page: f.page + 1 })}>›</button></div>
      </div>}
      <p className="muted" style={{ fontSize: 12 }}>{a('auditHint')}</p>
      {open && <Modal title={`${open.action} — ${open.entity}${open.entity_id ? ` #${open.entity_id}` : ''}`} onClose={() => setOpen(null)} size="lg">
        <div className="muted" style={{ fontSize: 13 }}>{fmtDateTime(open.created_at, locale)} · {open.user_name ?? '—'} · {open.device ?? ''} · {open.ip} · {open.user_agent ?? ''}</div>
        <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div><h4>{a('oldValue')}</h4><pre style={{ fontSize: 11.5, whiteSpace: 'pre-wrap', background: 'var(--soft)', padding: 8, borderRadius: 6, maxHeight: 360, overflow: 'auto' }}>{open.before ? JSON.stringify(open.before, null, 1) : '—'}</pre></div>
          <div><h4>{a('newValue')}</h4><pre style={{ fontSize: 11.5, whiteSpace: 'pre-wrap', background: 'var(--soft)', padding: 8, borderRadius: 6, maxHeight: 360, overflow: 'auto' }}>{open.after ? JSON.stringify(open.after, null, 1) : '—'}</pre></div>
        </div>
      </Modal>}
    </>
  );
}

// ===================================================== Sauvegardes =====================================================
/** Mises à jour en un clic : vérification, notes, installation (sauvegarde vérifiée + redémarrage + retour arrière automatique). */
function Updates() {
  const { a, locale } = useA();
  const u = (k: string) => a(`up_${k}`);
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const [busy, setBusy] = useState('');
  const [ask, setAsk] = useState(false);
  const [cfg, setCfg] = useState<any>(null);
  const [wait, setWait] = useState<string | null>(null);
  const load = () => get('/api/admin/update').then((r) => { setD(r); setCfg({ auto_check: r.config.auto_check, auto_install: r.config.auto_install }); }).catch(errT(toast));
  useEffect(() => { load(); }, []);
  // après installation : attendre que le serveur revienne avec la nouvelle version, puis recharger
  useEffect(() => {
    if (!wait) return;
    const i = setInterval(() => { get('/api/admin/update').then((r) => { if (r.current === wait || (r.last && r.last.version === wait)) { clearInterval(i); window.location.reload(); } }).catch(() => {}); }, 3000);
    return () => clearInterval(i);
  }, [wait]);
  if (!d) return <span className="muted">…</span>;
  const L = d.state?.latest;
  const run = async (k: string, fn: () => Promise<any>) => { setBusy(k); try { const r = await fn(); if (r?.current) setD(r); return r; } catch (e: any) { toast('error', e.message); } finally { setBusy(''); } };
  if (wait) return <div className="card" style={{ textAlign: 'center', padding: 40 }}><h3>{u('installing')} {wait}…</h3><p className="muted">{u('installingHint')}</p></div>;
  return (
    <>
      <div className="card">
        <div className="row" style={{ gap: 16, flexWrap: 'wrap', alignItems: 'center' }}>
          <div><div className="muted" style={{ fontSize: 12 }}>{u('current')}</div><b style={{ fontSize: 22 }}>{d.current}</b></div>
          <div style={{ flex: 1, minWidth: 220 }}>
            {L ? <div className="alert info" style={{ margin: 0 }}><b>{u('available')} : {L.version}</b>{L.notes && <div style={{ whiteSpace: 'pre-line', marginTop: 4 }}>{L.notes}</div>}</div>
              : <div className="alert success" style={{ margin: 0 }}>✓ {u('upToDate')}</div>}
            {d.state?.error && <div className="alert warning" style={{ margin: '6px 0 0' }}>{d.state.error}</div>}
            <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>{u('checked')} : {d.state?.checked_at ? fmtDateTime(d.state.checked_at, locale) : '—'}</div>
          </div>
          <button className="btn" disabled={!!busy} onClick={() => run('check', () => post('/api/admin/update/check', {}))}>{busy === 'check' ? a('working') : u('checkNow')}</button>
          {L && <button className="btn primary" disabled={!!busy} onClick={() => setAsk(true)}>⬇ {u('install')} {L.version}</button>}
        </div>
        {d.last && <div className={`alert ${d.last.ok ? 'success' : 'danger'}`} style={{ marginTop: 10 }}>{d.last.ok ? `✓ ${u('lastOk')} ${d.last.from} → ${d.last.version} (${fmtDateTime(d.last.at, locale)}) · ${u('backup')} : ${d.last.backup}` : `✗ ${u('lastFail')} ${d.last.version} : ${d.last.error}`}</div>}
      </div>
      <div className="card">
        <h3>{u('how')}</h3>
        <ol style={{ margin: 0, paddingInlineStart: 20, lineHeight: 1.7 }}>{[1, 2, 3, 4].map((i) => <li key={i}>{u(`step${i}`)}</li>)}</ol>
      </div>
      {cfg && <div className="card">
        <h3>{u('options')}</h3>
        <label className="row" style={{ gap: 8 }}><input type="checkbox" checked={cfg.auto_check} onChange={(e) => setCfg({ ...cfg, auto_check: e.target.checked })} /> {u('auto')}</label>
        <label className="row" style={{ gap: 8 }}><input type="checkbox" checked={cfg.auto_install} onChange={(e) => setCfg({ ...cfg, auto_install: e.target.checked })} /> {u('autoInstall')}</label>
        <div style={{ marginTop: 8 }}><button className="btn" disabled={!!busy} onClick={() => run('cfg', () => api('PUT', '/api/admin/update/config', cfg).then((r: any) => { toast('success', a('done')); load(); return r; }))}>{u('save')}</button></div>
      </div>}
      <LicenseCard />
      {ask && L && <Modal title={`${u('install')} ${L.version}`} onClose={() => setAsk(false)} size="sm"
        footer={<><button className="btn" onClick={() => setAsk(false)}>{u('cancel')}</button><button className="btn primary" disabled={!!busy} onClick={async () => { const r = await run('install', () => post('/api/admin/update/install', { confirm: true })); if (r?.version) { setAsk(false); setWait(r.version); } }}>{busy === 'install' ? u('downloading') : u('confirm')}</button></>}>
        <p>{u('confirmText')}</p>
      </Modal>}
    </>
  );
}

function LicenseCard() {
  const { a, locale } = useA();
  const [l, setL] = useState<any>(null);
  useEffect(() => { get('/api/license').then(setL).catch(() => {}); }, []);
  if (!l) return null;
  return (
    <div className="card">
      <h3 style={{ marginTop: 0 }}>🔑 {a('lic_title')}</h3>
      <div className="sum-row"><span>{a('lic_status')}</span><b style={{ color: l.status === 'active' ? '#15803D' : '#B91C1C' }}>{l.status === 'active' ? a('lic_active') : l.status}</b></div>
      <div className="sum-row"><span>{a('lic_last')}</span><span>{l.checked_at ? fmtDateTime(l.checked_at, locale) : '—'}</span></div>
      <p className="muted" style={{ fontSize: 12, marginBottom: 0 }}>{a('lic_text')}</p>
    </div>
  );
}

function Backups() {
  const { a, t, locale } = useA();
  const toast = useToast();
  const { can } = useAuth();
  const [d, setD] = useState<any>(null);
  const [busy, setBusy] = useState('');
  const [cfg, setCfg] = useState<any>(null);
  const [restore, setRestore] = useState<any>(null);
  const [verif, setVerif] = useState<any>(null);
  const load = () => get('/api/admin/backups').then((r) => { setD(r); setCfg(r.config); }).catch(errT(toast));
  useEffect(() => { load(); }, []);
  if (!d) return <span className="muted">…</span>;
  const run = async (k: string, fn: () => Promise<any>, ok?: string) => { setBusy(k); try { const r = await fn(); if (ok) toast('success', ok); load(); return r; } catch (e: any) { toast('error', e.message); } finally { setBusy(''); } };
  const KIND: Record<string, string> = { manual: a('bk_manual'), auto: a('bk_auto'), pre_restore: a('bk_pre_restore'), uploaded: a('bk_uploaded') };
  return (
    <>
      {!d.tools.pg_dump && <div className="alert danger">{a('noPgDump')}</div>}
      <div className="card row" style={{ gap: 8, flexWrap: 'wrap' }}>
        <button className="btn primary" disabled={!!busy || !d.tools.pg_dump} onClick={() => run('create', () => post('/api/admin/backups', {}), a('backupOk'))}><Icon name="box" size={14} />{busy === 'create' ? a('working') : a('backupNow')}</button>
        {can('backups.restore') && <label className="btn">{busy === 'upload' ? a('working') : a('importBackup')}<input type="file" accept=".dump" style={{ display: 'none' }} onChange={(e) => { const f = e.target.files?.[0]; if (f) run('upload', () => upload('/api/admin/backups/upload', f, {}), a('importOk')); }} /></label>}
        <span className="muted" style={{ fontSize: 12 }}>{a('folder')} : <code>{d.dir}</code></span>
      </div>
      {cfg && <div className="card"><h3 style={{ marginTop: 0 }}>{a('autoBackups')}</h3>
        <div className="row" style={{ gap: 10, flexWrap: 'wrap', alignItems: 'end' }}>
          <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={cfg.enabled} onChange={(e) => setCfg({ ...cfg, enabled: e.target.checked })} />{a('enabled')}</label>
          <Field label={a('frequency')}><select className="input" value={cfg.frequency} onChange={(e) => setCfg({ ...cfg, frequency: e.target.value })}>{['daily', 'weekly', 'monthly'].map((x) => <option key={x} value={x}>{a(`fq_${x}`)}</option>)}</select></Field>
          <Field label={a('time')}><input className="input" type="time" value={cfg.time} onChange={(e) => setCfg({ ...cfg, time: e.target.value })} /></Field>
          {cfg.frequency === 'weekly' && <Field label={a('weekday')}><select className="input" value={cfg.weekday} onChange={(e) => setCfg({ ...cfg, weekday: Number(e.target.value) })}>{[0, 1, 2, 3, 4, 5, 6].map((n) => <option key={n} value={n}>{new Intl.DateTimeFormat(locale, { weekday: 'long' }).format(new Date(Date.UTC(2024, 0, 7 + n)))}</option>)}</select></Field>}
          {cfg.frequency === 'monthly' && <Field label={a('monthday')}><input className="input" type="number" min={1} max={28} value={cfg.monthday} onChange={(e) => setCfg({ ...cfg, monthday: Number(e.target.value) })} /></Field>}
          <Field label={a('keep')}><input className="input" type="number" min={1} max={365} value={cfg.keep} onChange={(e) => setCfg({ ...cfg, keep: Number(e.target.value) })} /></Field>
          <button className="btn" onClick={() => run('cfg', () => api('PUT', '/api/admin/backups/config', cfg), a('saved'))}>{t('common.save')}</button>
        </div>
        <p className="muted" style={{ fontSize: 12 }}>{a('autoHint')}</p>
      </div>}
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}><table className="table" style={{ fontSize: 13 }}>
        <thead><tr><th>{a('date')}</th><th>{a('type')}</th><th>{a('size')}</th><th>{a('content')}</th><th>{a('verification')}</th><th>{a('by')}</th><th /></tr></thead>
        <tbody>{d.items.map((b: any) => <tr key={b.id} style={{ opacity: b.status === 'ok' ? 1 : 0.6 }}>
          <td>{fmtDateTime(b.created_at, locale)}<div className="muted" style={{ fontSize: 11 }}>{b.file_name}</div></td><td>{KIND[b.kind]}</td><td>{b.size_bytes ? size(Number(b.size_bytes)) : '—'}</td>
          <td className="muted">{b.tables_count ? `${b.tables_count} ${a('tables')} · ${Number(b.rows_count).toLocaleString(locale)} ${a('rows')}` : b.last_migration ?? '—'}</td>
          <td>{b.status === 'failed' ? <span title={b.error}>{pill('#FEE2E2', '#991B1B', a('bs_failed'))}</span> : b.status === 'missing' ? pill('#F1F5F9', '#64748B', a('bs_missing')) : b.status === 'creating' ? pill('#DBEAFE', '#1E3A8A', a('bs_creating')) : b.verify_ok ? pill('#DCFCE7', '#166534', `✓ ${a('verified')}`) : pill('#FEF3C7', '#92400E', a('bs_unverified'))}</td>
          <td className="muted">{b.created_by_name ?? '—'}</td>
          <td className="row" style={{ gap: 4 }}>{b.status === 'ok' && <>
            <button className="btn sm" disabled={!!busy} onClick={async () => { const v = await run(`v${b.id}`, () => post(`/api/admin/backups/${b.file_name}/verify`, {})); if (v) setVerif({ b, v }); }}>{busy === `v${b.id}` ? '…' : a('verify')}</button>
            <button className="btn sm" disabled={!!busy} title={a('testRestoreHint')} onClick={async () => { const v = await run(`t${b.id}`, () => post(`/api/admin/backups/${b.file_name}/test-restore`, {})); if (v) setVerif({ b, v: { ok: v.ok, compatible: v.ok, detail: v.steps } }); }}>{busy === `t${b.id}` ? '…' : a('testRestore')}</button>
            {can('backups.restore') && <a className="btn sm" href={`/api/admin/backups/${encodeURIComponent(b.file_name)}/download`}>{a('download')}</a>}
            {can('backups.restore') && <button className="btn sm danger" onClick={() => setRestore({ b, confirm: '' })}>{a('restore')}</button>}
            {can('backups.restore') && <button className="btn sm ghost" onClick={() => { if (confirm(a('deleteConfirm'))) run('del', () => api('DELETE', `/api/admin/backups/${encodeURIComponent(b.file_name)}?confirm=SUPPRIMER`), a('done')); }}>×</button>}</>}</td></tr>)}
          {!d.items.length && <tr><td colSpan={7} className="muted">{a('noBackup')}</td></tr>}</tbody></table></div>
      <div className="card"><h3 style={{ marginTop: 0 }}>{a('restoreHistory')}</h3>
        {d.restores.map((r: any) => <div key={r.id} className="sum-row" style={{ fontSize: 13 }}><span>{r.status === 'ok' ? '✓' : r.status === 'running' ? '…' : '✗'} {r.file_name} <span className="muted">· {r.by_name} · {r.detail}</span></span><span className="muted">{fmtDateTime(r.started_at, locale)}</span></div>)}
        {!d.restores.length && <span className="muted">{t('common.none')}</span>}
      </div>
      {verif && <Modal title={a('verification')} onClose={() => setVerif(null)}><div className={`alert ${verif.v.ok && verif.v.compatible ? 'info' : 'danger'}`}>{verif.v.ok ? (verif.v.compatible ? a('verifyOk') : a('verifyIncompatible')) : a('verifyFail')}</div><ul>{verif.v.detail.map((x: string, i: number) => <li key={i} style={{ fontSize: 13 }}>{x}</li>)}</ul></Modal>}
      {restore && <Modal title={a('restore')} onClose={() => busy !== 'restore' && setRestore(null)} footer={<><button className="btn" disabled={busy === 'restore'} onClick={() => setRestore(null)}>{t('common.cancel')}</button>
        <button className="btn danger" disabled={restore.confirm !== 'RESTAURER' || busy === 'restore'} onClick={async () => { const r = await run('restore', () => post(`/api/admin/backups/${restore.b.file_name}/restore`, { confirm: restore.confirm, file_name: restore.b.file_name })); if (r) { setRestore(null); alert(`${r.detail}\n\n${a('reloginHint')}`); window.location.reload(); } }}>{busy === 'restore' ? a('working') : a('restoreNow')}</button></>}>
        <div className="alert danger">{a('restoreWarn')}</div>
        <p style={{ fontSize: 13 }}><b>{restore.b.file_name}</b> — {fmtDateTime(restore.b.created_at, locale)}</p>
        <ol style={{ fontSize: 13 }}>{['rs1', 'rs2', 'rs3', 'rs4', 'rs5', 'rs6'].map((k) => <li key={k}>{a(k)}</li>)}</ol>
        <Field label={a('typeRestore')}><input className="input" value={restore.confirm} onChange={(e) => setRestore({ ...restore, confirm: e.target.value })} placeholder="RESTAURER" /></Field>
      </Modal>}
    </>
  );
}

// ===================================================== Système =====================================================
function SystemInfo() {
  const { a } = useA();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  useEffect(() => { get('/api/admin/system').then(setD).catch(errT(toast)); }, []);
  if (!d) return <span className="muted">…</span>;
  const R = ({ l, v, ok }: any) => <div className="sum-row"><span>{l}</span><b style={{ color: ok === false ? '#B91C1C' : ok ? '#15803D' : undefined }}>{v}</b></div>;
  return (
    <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))' }}>
      <div className="card"><h3 style={{ marginTop: 0 }}>{a('database')}</h3>
        <R l={a('connection')} v={d.db_ok ? `OK (${d.db_latency_ms} ms)` : 'KO'} ok={d.db_ok} /><R l="PostgreSQL" v={d.pg_version} /><R l={a('dbName')} v={d.db_name} /><R l={a('size')} v={size(d.db_size)} />
        <R l={a('connections')} v={d.db_connections} /><R l={a('migrations')} v={`${d.migrations.applied} / ${d.migrations.expected} (${d.migrations.last})`} ok={!d.migrations.pending.length} />
        <R l="pg_dump / pg_restore" v={d.pg_dump && d.pg_restore ? a('available') : a('missing')} ok={d.pg_dump && d.pg_restore} />
      </div>
      <div className="card"><h3 style={{ marginTop: 0 }}>{a('server')}</h3>
        <R l={a('lanAccess')} v={d.server.lan.join(' · ') || '—'} /><R l={a('port')} v={d.server.port} /><R l={a('h_timezone')} v={d.server.timezone} />
        <R l={a('uptime')} v={`${Math.floor(d.uptime_s / 3600)} h ${Math.floor((d.uptime_s % 3600) / 60)} min`} /><R l="Node.js" v={d.node} /><R l={a('openSessions')} v={d.sessions_active} />
        <R l={a('secureCookie')} v={d.server.cookie_secure ? a('yes') : a('no')} /><R l={a('deviceApproval')} v={d.server.device_approval ? a('yes') : a('no')} ok={d.server.device_approval} />
        <p className="muted" style={{ fontSize: 12 }}>{a('lanHint')}</p>
      </div>
      <div className="card"><h3 style={{ marginTop: 0 }}>{a('internet')}</h3>
        <p className="muted" style={{ fontSize: 12 }}>{a('offlineHint')}</p>
        {d.internet.map((x: any) => <div key={x.key} className="sum-row" style={{ alignItems: 'start' }}><span>{x.label}<div className="muted" style={{ fontSize: 12 }}>{x.note}</div></span>{x.configured ? pill('#DCFCE7', '#166534', a('configured')) : pill('#F1F5F9', '#475569', a('notConfigured'))}</div>)}
      </div>
    </div>
  );
}
