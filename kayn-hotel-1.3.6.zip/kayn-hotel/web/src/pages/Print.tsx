import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { get } from '../lib/api';
import { fmtDate, money } from '../lib/format';


function PrintBar() {
  return (
    <div className="no-print" style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginBottom: 16 }}>
      <button className="btn primary" onClick={() => window.print()}>Imprimer / Enregistrer en PDF</button>
      <button className="btn" onClick={() => window.close()}>Fermer</button>
    </div>
  );
}

const VT: Record<string, Record<string, string>> = {
  fr: { title: 'Confirmation de réservation', no: 'N°', guest: 'Client', billed: 'facturé à', phone: 'Téléphone', room: 'Chambre', type: 'Type', arr: 'Arrivée', dep: 'Départ',
    nights: 'Nuits', rate: 'Prix / nuit', amount: 'Montant', meal: 'Formule', persons: 'Personnes', disc: 'Remise', tax: 'Taxes', total: 'Total séjour', paid: 'Acomptes et paiements reçus',
    due: 'Reste à payer', status: 'Statut', pending: 'en attente de confirmation', confirmed: 'confirmée', issued: 'Émis le', special: 'Demandes particulières',
    RO: 'Chambre seule', BB: 'Petit-déjeuner', HB: 'Demi-pension', FB: 'Pension complète', print: 'Imprimer / Enregistrer en PDF', close: 'Fermer' },
  en: { title: 'Booking confirmation', no: 'No.', guest: 'Guest', billed: 'billed to', phone: 'Phone', room: 'Room', type: 'Type', arr: 'Arrival', dep: 'Departure',
    nights: 'Nights', rate: 'Price / night', amount: 'Amount', meal: 'Board', persons: 'Guests', disc: 'Discount', tax: 'Taxes', total: 'Total stay', paid: 'Deposits and payments received',
    due: 'Balance due', status: 'Status', pending: 'awaiting confirmation', confirmed: 'confirmed', issued: 'Issued on', special: 'Special requests',
    RO: 'Room only', BB: 'Bed & breakfast', HB: 'Half board', FB: 'Full board', print: 'Print / Save as PDF', close: 'Close' },
  ar: { title: 'تأكيد الحجز', no: 'رقم', guest: 'الزبون', billed: 'الفوترة باسم', phone: 'الهاتف', room: 'الغرفة', type: 'النوع', arr: 'الوصول', dep: 'المغادرة',
    nights: 'الليالي', rate: 'السعر / ليلة', amount: 'المبلغ', meal: 'الصيغة', persons: 'الأشخاص', disc: 'التخفيض', tax: 'الرسوم', total: 'مجموع الإقامة', paid: 'العرابين والمدفوعات',
    due: 'الباقي للدفع', status: 'الحالة', pending: 'في انتظار التأكيد', confirmed: 'مؤكد', issued: 'صدر في', special: 'طلبات خاصة',
    RO: 'غرفة فقط', BB: 'مع فطور الصباح', HB: 'نصف إقامة', FB: 'إقامة كاملة', print: 'طباعة / حفظ PDF', close: 'إغلاق' },
};
const LOC: Record<string, string> = { fr: 'fr-FR', en: 'en-GB', ar: 'ar-DZ' };

export function PrintReservation() {
  const { id } = useParams();
  const [r, setR] = useState<any>(null);
  const [err, setErr] = useState('');
  const [lang, setLang] = useState<string>(() => new URLSearchParams(location.search).get('lang') ?? '');
  useEffect(() => { get(`/api/reservations/${id}`).then((x) => { setR(x); if (!lang) setLang(x.guest.language ?? 'fr'); }).catch((e) => setErr(e.message)); }, [id]);
  if (err) return <div className="print-page">{err}</div>;
  if (!r || !lang) return <div className="print-page">…</div>;
  const T = VT[lang] ?? VT.fr;
  const loc = LOC[lang];
  const mm = (n: number) => money(n, loc);
  return (
    <div style={{ background: '#eee', minHeight: '100vh', padding: 20 }}>
      <div className="print-page" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
        <div className="no-print" style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginBottom: 16 }}>
          {['fr', 'en', 'ar'].map((l) => <button key={l} className={`btn ${lang === l ? 'primary' : ''}`} onClick={() => setLang(l)}>{l === 'ar' ? 'العربية' : l.toUpperCase()}</button>)}
          <button className="btn primary" onClick={() => window.print()}>{T.print}</button>
          <button className="btn" onClick={() => window.close()}>{T.close}</button>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '3px solid #7A1F2B', paddingBottom: 12 }}>
          <div><h1>{T.title}</h1><div>{T.no} {r.code}</div></div>
          <div style={{ textAlign: 'end' }}><b>Hôtel K</b></div>
        </div>
        <p>{T.guest} : <b>{r.guest_name}</b>{r.payer ? ` — ${T.billed} ${r.payer.company_name}` : ''}<br />{T.phone} : {r.guest.phone ?? '—'}</p>
        <table>
          <thead><tr><th>{T.room}</th><th>{T.type}</th><th>{T.arr}</th><th>{T.dep}</th><th>{T.nights}</th><th>{T.rate}</th><th>{T.amount}</th></tr></thead>
          <tbody>
            {r.rooms.filter((x: any) => !['cancelled', 'no_show'].includes(x.status)).map((x: any) => (
              <tr key={x.id}><td>{x.room_number}</td><td>{x.room_type}</td><td>{fmtDate(x.check_in, loc)}</td><td>{fmtDate(x.check_out, loc)}</td><td>{x.nights}</td><td>{mm(x.rate)}</td><td>{mm(x.rate * x.nights)}</td></tr>
            ))}
          </tbody>
        </table>
        <p>{T.meal} : {T[r.meal_plan]} · {T.persons} : {r.adults + r.children}</p>
        <table>
          <tbody>
            {r.discount_total > 0 && <tr><td>{T.disc}</td><td style={{ textAlign: 'end' }}>− {mm(r.discount_total)}</td></tr>}
            {r.tax_total > 0 && <tr><td>{T.tax}</td><td style={{ textAlign: 'end' }}>{mm(r.tax_total)}</td></tr>}
            <tr><td>{T.total}</td><td style={{ textAlign: 'end' }}><b>{mm(r.total)}</b></td></tr>
            <tr><td>{T.paid}</td><td style={{ textAlign: 'end' }}>{mm(r.paid - r.refunded)}</td></tr>
            <tr><td><b>{T.due}</b></td><td style={{ textAlign: 'end' }}><b>{mm(Math.max(0, r.balance))}</b></td></tr>
          </tbody>
        </table>
        {r.special_requests && <p>{T.special} : {r.special_requests}</p>}
        <p style={{ fontSize: 12, color: '#555', marginTop: 24 }}>{T.status} : {r.status === 'pending' ? T.pending : T.confirmed} · {T.issued} {new Date().toLocaleString(loc)}</p>
      </div>
    </div>
  );
}

const INV_TITLE: Record<string, string> = { invoice: 'Facture', proforma: 'Facture pro forma', credit_note: 'Avoir' };
export function PrintInvoice() {
  const { id } = useParams();
  const [inv, setInv] = useState<any>(null);
  const [err, setErr] = useState('');
  useEffect(() => { get(`/api/invoices/${id}`).then(setInv).catch((e) => setErr(e.message)); }, [id]);
  if (err) return <div className="print-page">{err}</div>;
  if (!inv) return <div className="print-page">Chargement…</div>;
  const h = inv.seller ?? {};
  const b = inv.bill_to ?? {};
  const n = (v: any) => money(Number(v));
  return (
    <div style={{ background: '#eee', minHeight: '100vh', padding: 20 }}>
      <div className="print-page">
        <div className="no-print" style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginBottom: 16 }}>
          <button className="btn" onClick={() => window.open(`/api/invoices/${inv.id}/pdf`, '_blank')}>Télécharger le PDF</button>
          <button className="btn primary" onClick={() => window.print()}>Imprimer</button>
          <button className="btn" onClick={() => window.close()}>Fermer</button>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '3px solid #7A1F2B', paddingBottom: 12 }}>
          <div>
            <b style={{ fontSize: 18 }}>{h.name}</b>
            <div>{[h.address, h.city].filter(Boolean).join(', ')}</div>
            <div style={{ fontSize: 12 }}>{[h.phone, h.email].filter(Boolean).join(' · ')}</div>
            <div style={{ fontSize: 12 }}>{[h.nif && `NIF ${h.nif}`, h.nis && `NIS ${h.nis}`, h.rc && `RC ${h.rc}`, h.art && `Art. ${h.art}`].filter(Boolean).join(' · ')}</div>
          </div>
          <div style={{ textAlign: 'end' }}>
            <h1>{INV_TITLE[inv.type] ?? 'Facture'}</h1>
            <div>N° <b>{inv.number}</b></div>
            <div>{new Date(inv.issued_at).toLocaleDateString('fr-FR')}</div>
            {inv.reservation && <div style={{ fontSize: 12 }}>Séjour {inv.reservation.code} · {fmtDate(inv.reservation.check_in, 'fr-FR')} → {fmtDate(inv.reservation.check_out, 'fr-FR')}</div>}
            {inv.original && <div style={{ fontSize: 12 }}>Sur la facture {inv.original.number}</div>}
          </div>
        </div>
        <p><span style={{ color: '#666' }}>Facturé à</span><br /><b>{b.name}</b>{b.address ? <><br />{b.address}</> : null}{b.nif ? <><br />NIF {b.nif}</> : null}{b.tax_exempt ? <><br />Exonéré de TVA{b.tax_exempt_reason ? ` : ${b.tax_exempt_reason}` : ''}</> : null}</p>
        {inv.reason && <p style={{ fontSize: 13 }}>Motif : {inv.reason}</p>}
        <table>
          <thead><tr><th>Désignation</th><th style={{ textAlign: 'end' }}>Qté</th><th style={{ textAlign: 'end' }}>P.U. HT</th><th style={{ textAlign: 'end' }}>TVA</th><th style={{ textAlign: 'end' }}>Remise</th><th style={{ textAlign: 'end' }}>Total HT</th></tr></thead>
          <tbody>
            {inv.items.map((i: any) => (
              <tr key={i.id}><td>{i.description}</td><td style={{ textAlign: 'end' }}>{Number(i.quantity)}</td><td style={{ textAlign: 'end' }}>{n(i.unit_price)}</td><td style={{ textAlign: 'end' }}>{i.kind === 'tourist_tax' ? '—' : `${Number(i.tax_rate)} %`}</td><td style={{ textAlign: 'end' }}>{Number(i.discount) ? n(i.discount) : ''}</td><td style={{ textAlign: 'end' }}>{n(i.total)}</td></tr>
            ))}
          </tbody>
        </table>
        <table style={{ width: 360, marginInlineStart: 'auto' }}>
          <tbody>
            <tr><td>Total HT</td><td style={{ textAlign: 'end' }}>{n(inv.subtotal)}</td></tr>
            {Number(inv.discount_total) !== 0 && <tr><td>dont remises</td><td style={{ textAlign: 'end' }}>− {n(inv.discount_total)}</td></tr>}
            {(inv.tax_breakdown ?? []).map((g: any) => <tr key={g.rate}><td>TVA {Number(g.rate)} % sur {n(g.base)}</td><td style={{ textAlign: 'end' }}>{n(g.tax)}</td></tr>)}
            {Number(inv.tourist_tax_total) !== 0 && <tr><td>Taxe de séjour</td><td style={{ textAlign: 'end' }}>{n(inv.tourist_tax_total)}</td></tr>}
            <tr><td><b>Total TTC</b></td><td style={{ textAlign: 'end' }}><b>{n(inv.total)}</b></td></tr>
            {inv.type === 'invoice' && <>
              {inv.credited > 0 && <tr><td>Avoirs</td><td style={{ textAlign: 'end' }}>− {n(inv.credited)}</td></tr>}
              <tr><td>Payé</td><td style={{ textAlign: 'end' }}>{n(inv.net_paid)}</td></tr>
              {!inv.reservation_id && <tr><td><b>Reste dû</b></td><td style={{ textAlign: 'end' }}><b>{n(inv.due)}</b></td></tr>}
            </>}
          </tbody>
        </table>
        {inv.notes && <p style={{ fontSize: 12, color: '#555', marginTop: 24 }}>{inv.notes}</p>}
        {inv.type === 'proforma' && <p style={{ textAlign: 'center', color: '#7A1F2B', fontWeight: 700 }}>Document sans valeur comptable — ne constitue pas une facture.</p>}
      </div>
    </div>
  );
}

const DOC: Record<string, string> = { cni: 'Carte nationale d\'identité biométrique', passport: 'Passeport', permis: 'Permis de conduire', other: 'Autre pièce' };
/** Fiche de police (fiche de voyageur) — reprend le modèle officiel : recto (identité) + verso (pièce produite), FR + AR. */
export function PrintRegistration() {
  const { id } = useParams();
  const [x, setX] = useState<any>(null);
  const [err, setErr] = useState('');
  useEffect(() => { get(`/api/frontoffice/registration/${id}`).then(setX).catch((e) => setErr(e.message)); }, [id]);
  if (err) return <div className="print-page">{err}</div>;
  if (!x) return <div className="print-page">Chargement…</div>;
  const g = x.guest;
  const d = (v: string | null) => (v ? fmtDate(v.slice(0, 10), 'fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '');
  const foreign = !!g.nationality && !/alg[eé]r|dz/i.test(g.nationality);
  const L = ({ fr, ar, v }: { fr: string; ar: string; v?: any }) => (
    <div style={{ display: 'grid', gridTemplateColumns: '42% 1fr auto', alignItems: 'end', gap: 8, margin: '7px 0' }}>
      <span style={{ fontWeight: 600 }}>{fr} :</span>
      <span style={{ borderBottom: '1px dotted #555', minHeight: 18, paddingInline: 4, fontWeight: 700, fontFamily: 'inherit' }}>{v || ''}</span>
      <span dir="rtl" style={{ fontWeight: 600, minWidth: 90, textAlign: 'start' }}>{ar}</span>
    </div>
  );
  const card: React.CSSProperties = { border: '1.5px solid #222', borderRadius: 6, padding: '12px 16px', fontSize: 12.5, breakInside: 'avoid' };
  const docLabel = g.id_doc_type === 'passport' ? 'Passeport' : g.id_doc_type === 'cni' ? 'Carte d\'identité' : (DOC[g.id_doc_type] ?? '');
  return (
    <div className="print-page reg" style={{ fontSize: 12.5 }}>
      <PrintBar />
      {/* ---------------- RECTO ---------------- */}
      <div style={card}>
        <div style={{ display: 'grid', gridTemplateColumns: '150px 1fr', borderBottom: '1.5px solid #222', paddingBottom: 8, marginBottom: 6 }}>
          <div style={{ borderInlineEnd: '1.5px solid #222', paddingInlineEnd: 10 }}>
            <div style={{ fontWeight: 800, fontSize: 14, lineHeight: 1.2 }}>FICHE DE<br />VOYAGEUR</div>
            <div dir="rtl" style={{ fontWeight: 700 }}>بطاقة المسافر</div>
            <div style={{ marginTop: 6, fontWeight: 700 }}>CHAMBRE N° <span style={{ fontSize: 16 }}>{x.current_room ?? x.room_number}</span></div>
          </div>
          <div style={{ paddingInlineStart: 12 }}>
            <div style={{ fontWeight: 800, fontSize: 17 }}>{x.hotel.name}</div>
            <div>{[x.hotel.address, x.hotel.city].filter(Boolean).join(' — ')}</div>
            <div>{x.hotel.phone ? `Tél : ${x.hotel.phone}` : ''}{x.hotel.email ? ` · ${x.hotel.email}` : ''}</div>
            <div style={{ fontSize: 11, color: '#555', marginTop: 2 }}>Séjour n° {x.code}</div>
          </div>
        </div>
        <L fr="Nom" ar="اللقب" v={g.last_name} />
        <L fr="Nom de jeune fille" ar="اللقب قبل الزواج" v={g.maiden_name} />
        <L fr="Prénom" ar="الاسم" v={g.first_name} />
        <L fr="Né(e) le" ar="تاريخ الازدياد" v={d(g.birth_date)} />
        <L fr="À" ar="في" v={g.birth_place} />
        <L fr="Wilaya" ar="ولاية" v={g.birth_wilaya} />
        <L fr="Profession" ar="المهنة" v={g.profession} />
        <L fr="Domicile habituel" ar="السكن المعتاد" v={[g.address, g.city].filter(Boolean).join(', ')} />
        <L fr="Pays (pour les étrangers)" ar="البلد (للأجانب)" v={foreign ? g.country : ''} />
        <L fr="NATIONALITÉ" ar="الجنسية" v={g.nationality} />
        <div style={{ textAlign: 'center', fontWeight: 700, marginTop: 4 }}>S.T.V.P</div>
      </div>

      {/* ---------------- VERSO ---------------- */}
      <div style={{ ...card, marginTop: 12 }}>
        <div style={{ textAlign: 'center' }}>
          <div dir="rtl" style={{ fontWeight: 700 }}>عدد الأطفال أقل من 15 سنة المرافقين لرب الأسرة</div>
          <div style={{ fontWeight: 700 }}>Nombre d'enfants de moins de 15 ans accompagnant le chef de famille</div>
          <div style={{ borderBottom: '1px dotted #555', margin: '6px auto 10px', width: '60%', fontWeight: 800, fontSize: 15 }}>{x.children_under_15 ?? 0}</div>
          <div dir="rtl" style={{ fontWeight: 700 }}>قطعة التعريف المقدمة</div>
          <div style={{ fontWeight: 800 }}>PIÈCE D'IDENTITÉ PRODUITE</div>
        </div>
        <div style={{ border: '1.2px solid #222', borderRadius: 6, padding: '8px 12px', marginTop: 8 }}>
          <div style={{ textAlign: 'center' }}><div dir="rtl">بطاقة التعريف أو جواز السفر</div><div>Carte d'identité ou Passeport</div></div>
          <L fr="Nature" ar="النوع" v={docLabel} />
          <L fr="N°" ar="رقم" v={g.id_doc_number} />
          <L fr="Délivrée le" ar="مسلمة في" v={d(g.id_doc_issued_on)} />
          <L fr="À" ar="بـ" v={g.id_doc_issued_place} />
          <L fr="Par" ar="من طرف" v={g.id_doc_issued_by} />
          <div style={{ borderTop: '1px solid #222', margin: '8px 0 4px', textAlign: 'center', fontWeight: 700 }}><span dir="rtl">للأجانب فقط</span> — Pour les étrangers seulement</div>
          <L fr="Date d'entrée en Algérie" ar="تاريخ الدخول إلى الجزائر" v={foreign ? d(x.entry_date) : ''} />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 16, marginTop: 12, alignItems: 'end' }}>
          <div>
            <L fr={`Fait à ${x.hotel.city ?? ''}, le`} ar="حرر في" v={d(x.checked_in_at ?? x.check_in)} />
          </div>
          <div className="reg-sign" style={{ minWidth: 200, textAlign: 'center' }}>
            <div style={{ fontWeight: 700 }}>Signature — الإمضاء</div>
            {x.signature_image ? <img src={x.signature_image} alt="Signature" style={{ maxHeight: 70 }} /> : <div style={{ height: 60 }} />}
          </div>
        </div>
      </div>

      {/* ---------------- Séjour (usage interne) ---------------- */}
      <div style={{ marginTop: 10, fontSize: 11, color: '#333' }}>
        <b>Séjour :</b> arrivée {d(x.check_in)}{x.checked_in_at ? ` à ${new Date(x.checked_in_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}` : ''} · départ prévu {d(x.check_out)} · {x.room_type} · {x.adults} adulte(s){x.children ? `, ${x.children} enfant(s)` : ''}{x.coming_from ? ` · venant de ${x.coming_from}` : ''}{x.going_to ? ` · se rendant à ${x.going_to}` : ''} · tél. {g.phone ?? '—'} · enregistré par {x.done_by ?? '—'}{x.id_checked ? ' (pièce vérifiée)' : ''}
        {x.companions.length > 0 && <div><b>Accompagnants :</b> {x.companions.map((c: any) => `${c.last_name} ${c.first_name ?? ''}${c.birth_date ? ` (né(e) le ${d(c.birth_date)})` : ''}${c.relation ? ` — ${c.relation}` : ''}${c.id_doc_number ? ` — pièce ${c.id_doc_number}` : ''}`).join(' ; ')}</div>}
        <div style={{ marginTop: 4, fontSize: 9.5, color: '#666' }}>Données traitées pour la gestion du séjour et les obligations légales (loi n° 18-07 relative à la protection des données à caractère personnel).</div>
      </div>
    </div>
  );
}
