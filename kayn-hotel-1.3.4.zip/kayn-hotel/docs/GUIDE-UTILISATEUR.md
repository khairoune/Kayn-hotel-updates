# KAYN Hotel — Guide rapide du personnel

Ouvrez KAYN Hotel depuis le favori de votre poste et connectez-vous avec **votre** identifiant. Ne prêtez jamais votre compte : chaque action est enregistrée à votre nom.
En haut de l'écran : langue (FR / ع / EN), mode nuit, cloche des notifications, changement de mot de passe et déconnexion. **Déconnectez-vous** en quittant le poste.

Vous ne voyez que les menus autorisés pour votre poste. Si un écran vous manque, adressez-vous à l'administrateur.

---

## Réception

| Je veux… | Où / comment |
|---|---|
| Voir l'occupation | **Planning** : glisser une barre pour changer de chambre ou de dates, tirer le bord pour prolonger |
| Créer une réservation | **Planning → Nouvelle réservation** : client existant (recherche) ou nouveau, dates, chambre, formule, acompte éventuel |
| Confirmer / annuler | Fiche de la réservation → *Confirmer* ou *Annuler* (motif obligatoire) |
| Faire un check-in | **Réception → Arrivées** → *Check-in* : fiche de police complète (pièce d'identité), chambre, paiement éventuel. La chambre doit être « propre / inspectée ». |
| Ajouter une prestation | Fiche du séjour → *Prestations* (petit-déjeuner, blanchisserie, parking…) |
| Prolonger / changer de chambre | Fiche du séjour → *Prolonger* ou *Changer de chambre* (le tarif est recalculé et tracé) |
| Faire un check-out | **Réception → Départs** → *Check-out* : encaissez le solde. La facture est générée automatiquement et la chambre passe « à nettoyer ». |
| Imprimer | Facture : *Imprimer* (A4 ou ticket) · Fiche de police : *Imprimer la fiche* |

## Caisse et facturation

- **Facturation & caisse → Caisse** : *Ouvrir la caisse* en début de service (fond de caisse), *Fermer* en fin de service (montant compté). Un écart doit être justifié.
- **Encaisser** : depuis la réservation, la facture ou la commande restaurant. Pour une carte, saisissez seulement les **4 derniers chiffres**, jamais le numéro complet.
- Une facture émise ne se modifie pas. Pour la corriger : *Avoir*.
- Un paiement ne s'efface pas. En cas d'erreur : bouton *Annuler* sur le paiement (motif obligatoire, droit de responsable).

## Housekeeping

- **Housekeeping** : liste de vos chambres à nettoyer. Faites *Commencer*, puis *Terminer* une fois la chambre prête : elle passe « à inspecter ».
- La gouvernante inspecte avec la checklist. Si un point critique n'est pas conforme, la chambre retourne « à nettoyer ».
- Respectez « Ne pas déranger ». Signalez une panne (*Déclarer une panne*, menu Maintenance) et un objet trouvé (*Objets trouvés*).

## Restaurant / bar / room service

- **Restaurant** : table → *Nouvelle commande* → plats et boissons (variantes, commentaires) → *Envoyer en cuisine*.
- Règlement (caissier ou responsable) : *Encaisser*, *Sur la chambre* (client hébergé : la note est ajoutée à son compte) ou *Facture* (société).
- Room service : commande avec le point de vente « Room service » et la chambre → affectation du serveur → livraison. La consommation est portée automatiquement au compte du client.

## Stocks, maintenance, RH

- **Stocks** : entrées (réception de commande), sorties, inventaire. Une alerte apparaît sous le stock minimum.
- **Maintenance** : *Déclarer une panne* (chambre, équipement, priorité). Le technicien démarre, saisit pièces et durée, puis clôture. Une chambre bloquée pour travaux n'est pas vendable.
- **Ressources humaines** : planning, pointage (borne : matricule + code), demandes de congé, documents. Votre fiche personnelle s'ouvre depuis le menu RH.

## Night audit (fin de journée)

**Night audit** → *Lancer les vérifications* → traitez chaque anomalie (corriger ou justifier) → comptez la caisse → *Comptabiliser* → *Valider* → *Clôturer* (saisissez la date pour confirmer). La journée suivante s'ouvre automatiquement. Une journée clôturée ne peut plus être modifiée.

## Règles d'or

1. Un compte par personne, jamais partagé.
2. Ne notez jamais un numéro de carte complet ni un mot de passe dans un commentaire.
3. Toute annulation, remise ou correction demande un **motif** : il est enregistré.
4. En cas de doute ou de message d'erreur, ne recommencez pas plusieurs fois : prévenez votre responsable.
