# KAYN Hotel 1.0 — Audit final et rapport de livraison

Date : 11/11/2026 · Périmètre : un seul hôtel, installation locale (sans Channel Manager, moteur de réservation, multi-hôtels ni SaaS).

Avant l'audit, deux précautions ont été prises :

- une sauvegarde complète de la base de démonstration ;
- un point de retour Git `v2.4-avant-audit-v1`.

Tous les tests destructifs ont été faits sur des bases séparées, recréées pour l'occasion : `kayn_hotel_test`, `kayn_hotel_v1check`, `kayn_hotel_perf` et `kayn_hotel_upd`. Aucune donnée réelle n'a été modifiée ni supprimée.

---

## Verdict : **PRÊT POUR UN TEST PILOTE**

Aucun problème CRITIQUE n'est ouvert. Les points IMPORTANTS du § 4 sont surtout des **vérifications à faire sur le site**, pas des défauts du logiciel connus à ce jour : exécution des scripts Windows, imprimantes, taux de taxes réels, copie des sauvegardes hors site. Ils figurent dans la liste du § 10.

---

## 1. Modules réellement vérifiés

Chaque module est vérifié de quatre façons :

- **API** : tests automatisés sur une vraie base PostgreSQL ;
- **Interface** : parcours réel dans un navigateur ;
- **Liaisons** : effets observés dans les autres modules ;
- **Branchements** : les 526 routes du serveur ont été comparées automatiquement aux appels de l'interface. Tous les appels de l'interface aboutissent à une vraie route connectée à la base, aucun écran n'est purement visuel.

| # | Module | Tests API | Liaisons contrôlées |
|---|---|---|---|
| 1 | Dashboard & Planning | flow, rooms, analytics | Occupation, arrivées, départs, encaissements mis à jour après check-in, paiement et check-out |
| 2 | Réservations | 10 + flow 6 + policies 6 | Anti double réservation (contrainte en base), acomptes, annulation, no-show, planning |
| 3 | Chambres | 11 | Statuts, hors service ↔ maintenance, disponibilité, tarifs |
| 4 | Front Office | 12 | Check-in (fiche de police), prolongation, changement de chambre, folio, check-out → facture → ménage |
| 5 | Facturation & Caisse | 14 | Taxes figées, paiements partiels, avoirs, remboursements, numérotation unique, caisse et écarts |
| 6 | Housekeeping | 11 | Tâches automatiques au départ, inspection obligatoire, check-in bloqué si la chambre est sale |
| 7 | Restaurant & Services | 10 | Recette → stock, report sur la chambre → folio → facture, aucune double facturation |
| 8 | Stocks & Achats | 9 | Commandes, réceptions, inventaires, alertes, factures fournisseurs, dépenses |
| 9 | Maintenance | 9 | Panne → chambre bloquée → réparation → validation → chambre réactivée, préventif |
| 10 | Ressources humaines | 9 | Planning ↔ ménage, pointage, congés, paie, sortie → comptes désactivés |
| 11 | CRM & Clients | 10 | Fiche unique, historique des séjours et du restaurant, fidélité, réclamations |
| 12 | Rapports & Statistiques | 11 | Formules ADR / RevPAR / CA, facturé ≠ encaissé, exports PDF / Excel / CSV |
| 13 | Night Audit | 7 | Contrôles, caisse, comptabilisation idempotente, clôture atomique, verrouillage, réouverture |
| 14 | Administration & Sécurité | 9 | Utilisateurs, rôles, permissions immédiates, journal, sauvegarde et restauration |
| 15 | Mise en production | integration 6 + setup 3 | 4 scénarios bout en bout, intégrité, matrice de sécurité, première installation |

## 2. Tests exécutés et résultats

| Série | Résultat |
|---|---|
| Tests automatisés de bout en bout (17 fichiers, base PostgreSQL réelle) | **153 / 153 réussis** (exécutés à nouveau après chaque correction) |
| Scénarios demandés : réservation → check-in · statut de chambre · services au compte · facture + paiement · check-out + libération · dashboard · restaurant → facturation · stocks et achats · housekeeping et maintenance · night audit · rapports | Tous couverts et réussis (fichiers integration, flow, frontoffice, restaurant, stock, housekeeping, maintenance, nightaudit, analytics) |
| **Persistance après redémarrage** (application compilée) | Réservation R26-00320 et facture F2026-000002 créées → arrêt propre → redémarrage → **retrouvées** |
| **Coupure brutale** (arrêt forcé pendant une création) | Au redémarrage : **aucune donnée partielle** (0 client orphelin, 0 réservation sans chambre) |
| Parcours de l'interface : 18 comptes de rôles différents, 117 pages, tous les onglets | **0 erreur JavaScript, 0 erreur API** |
| Affichage tablette et téléphone (16 écrans) | 0 débordement (audit phase 15) |
| Hôtel vide après l'assistant d'installation | 0 erreur |
| Performance (5 106 réservations, voir § 7) | Toutes les pages sous 1,5 s |
| Mise à jour d'une base en service (migration en attente) | Sauvegarde de sécurité vérifiée **avant** migration, puis migration appliquée, puis démarrage |
| Sauvegarde en ligne de commande | Sauvegarde créée et vérifiée (148 tables, 5 889 lignes) |
| Branchements interface ↔ serveur (526 routes) | 100 % des appels de l'interface correspondent à une route existante |

## 3. Bugs découverts et corrigés

**Pendant cet audit 1.0**

| Gravité | Problème | Origine | Correction |
|---|---|---|---|
| IMPORTANT | Messages d'erreur de formulaire **en anglais** et avec des noms techniques, par ex. « username: Too small: expected string to have >=3 characters » | Messages par défaut de la bibliothèque de validation | Messages en français avec le nom du champ, par ex. « Identifiant : au moins 3 caractères · Date de départ : obligatoire » |
| IMPORTANT | Aucune protection automatique des données lors d'une **mise à jour** de la base | Les migrations s'appliquaient directement au démarrage | Sauvegarde vérifiée obligatoire avant toute migration. En cas d'échec, refus de démarrer sans rien modifier. Ajout de `4-METTRE-A-JOUR.bat` et de `npm run backup`. |
| MINEUR | La mesure « recherche de réservations » du rapport de phase 15 portait en réalité sur la liste non filtrée | Mauvais paramètre dans le script de mesure (`q` au lieu de `search`) | Mesure refaite : 154 ms. Rapport corrigé. |
| MINEUR | Numéro de version incohérent (v2.4 interne) | — | Version **1.0.0** partout (application, paquets, écran) |

**Lors de la phase 15** (déjà corrigés et testés, voir `RAPPORT-VALIDATION-PHASE15.md`) :

- lenteur du tableau de bord : 18,8 s → 0,8 s ;
- installation réelle qui créait des données fictives et un administrateur au mot de passe fixe ;
- tâches automatiques dépendantes de l'identifiant « admin » ;
- téléchargement des sauvegardes trop largement autorisé ;
- élévation de privilèges par les écrans RH et Ménage ;
- 8 défauts moins graves.

## 4. Problèmes encore présents

**CRITIQUE** — aucun.

**IMPORTANT** (à traiter avant ou pendant le pilote)

1. **Scripts Windows non exécutés sous Windows** : `1-INSTALLER`, `2-DEMARRER`, `3-ARRETER`, `4-METTRE-A-JOUR`, `DEMARRAGE-AUTOMATIQUE`, `DEMO`. L'environnement de test est sous Linux. Les commandes qu'ils enchaînent (installation, compilation, migrations, sauvegarde, démarrage compilé) ont été validées une par une. → *À tester sur le PC de l'hôtel avant le pilote.*
2. **Impression physique** non testée : le contenu des PDF A4 et des tickets 80 mm a été vérifié, pas le rendu sur les vraies imprimantes. → *Imprimer une facture et un ticket.*
3. **Taux de taxes réels** à saisir et faire valider par le comptable. Le logiciel ne suppose aucun taux.
4. **Copie des sauvegardes hors du serveur** non automatisée : il faut une copie manuelle hebdomadaire (clé USB ou NAS). Sans elle, un vol ou un incendie du serveur ferait perdre les données.
5. **Dépendances** : 4 vulnérabilités « modérées » signalées par `npm audit` (react-router, uuid via exceljs). Elles ne sont pas exploitables dans l'usage local actuel, mais leur correction demande des mises à jour majeures. → *À faire dans la version 1.1.*

**MINEUR**

1. Départ le jour même de l'arrivée (« day use ») : la chambre ne redevient vendable que le lendemain.
2. « Décimales affichées » : n'agit que sur l'affichage ; les calculs restent au centime.
3. Tableau de bord : 0,9 s et rapports annuels : 1,4 s sur 5 000 réservations. C'est acceptable, mais améliorable par mise en cache.
4. Le parcours automatique de l'interface ouvre toutes les pages et tous les onglets, mais ne clique pas chaque bouton d'action. Ces actions sont couvertes par les tests d'API.

## 5. Fonctionnalités pas encore opérationnelles

| Fonction | État |
|---|---|
| Paiement en ligne | Aucune passerelle intégrée : refusé proprement tant qu'elle n'est pas configurée |
| Envoi d'e-mails (confirmations, campagnes, enquêtes) | Fonctionnel **seulement** si un serveur SMTP est configuré (Internet nécessaire) |
| Enquêtes de satisfaction depuis l'extérieur | Exigent d'exposer le serveur sur Internet (non prévu) |
| Accès à distance sécurisé (HTTPS / VPN) | Non prévu dans la 1.0 (réseau local uniquement) |
| Channel Manager, moteur de réservation, multi-hôtels, SaaS, abonnements | Hors périmètre de la 1.0, **volontairement non développés** |

## 6. Risques de sécurité

| Sujet | État |
|---|---|
| Mots de passe | Hachés (bcrypt), jamais affichés, jamais journalisés, jamais renvoyés par l'API. Aucun compte par défaut. Administrateur créé par l'assistant avec un mot de passe fort. |
| Sessions | Cookie HttpOnly + SameSite=Strict, expiration après inactivité, déconnexion effective, coupure immédiate à la désactivation du compte |
| Attaques | Verrouillage contre les essais de mots de passe, protection CSRF, requêtes paramétrées (injection SQL testée), approbation des postes |
| Permissions | Vérifiées côté serveur sur chaque action sensible. Refus tracés dans le journal. Aucune élévation de privilèges possible (testé sur 3 écrans). |
| Risques résiduels | (1) Pas de HTTPS : acceptable sur le réseau interne, **interdit** d'ouvrir le port 8080 vers Internet. (2) `server/.env` contient le mot de passe de la base : protéger le PC serveur (session Windows avec mot de passe). (3) Les sauvegardes contiennent toutes les données : à conserver comme des documents confidentiels. (4) Vulnérabilités modérées des dépendances (§ 4). |

## 7. État de la base de données

- PostgreSQL 16 :
  - 148 tables ;
  - 455 relations (clés étrangères, toutes validées) ;
  - 338 index ;
  - 50 déclencheurs de protection ;
  - 16 migrations transactionnelles.
- Contrôles d'intégrité réussis :
  - aucune réservation sans chambre ;
  - aucun orphelin ;
  - aucune numérotation en double ;
  - aucune consommation facturée deux fois ;
  - stock = somme des mouvements ;
  - aucune facture encaissée au-delà de son total ;
  - aucune double occupation d'une chambre (contrainte d'exclusion).
- **Immuables en base** : paiements, factures émises, journal d'activité, inspections, journées clôturées.
- **Performance** sur 5 106 réservations :

| Écran | Temps |
|---|---|
| Tableau de bord | 0,9 s |
| Planning | 19 ms |
| Liste / recherche des réservations | 152 / 154 ms |
| Rapports | 0,25 à 1,4 s |
| Création de facture | 37 ms |
| Night audit | < 0,3 s |
| 25 requêtes simultanées | 2,9 s au total |

## 8. Sauvegarde et restauration

| Fonction | État |
|---|---|
| Sauvegarde manuelle / automatique (quotidienne, hebdomadaire ou mensuelle, avec rotation) | ✅ Déclarée réussie seulement après relecture et vérification |
| Sauvegarde en ligne de commande / avant mise à jour | ✅ Testée (`npm run backup`, sauvegarde automatique avant migration) |
| Vérification (empreinte SHA-256, contenu, compatibilité de version) | ✅ Fichier corrompu détecté et refusé |
| Restauration d'essai (base temporaire, puis suppression) | ✅ 148 tables et 5 887 lignes identiques, 455 relations valides, base réelle intacte |
| Restauration réelle | ✅ Testée sur base de test : confirmation « RESTAURER », sauvegarde de sécurité préalable, transaction unique, contrôle d'intégrité, application opérationnelle ensuite |
| Copie hors site | ⚠ Manuelle (§ 4, point IMPORTANT 4) |

## 9. Lancer KAYN Hotel localement

1. Installer **Node.js 20 LTS** et **PostgreSQL 16** (noter le mot de passe `postgres`).
2. Décompresser KAYN Hotel (par ex. `C:\KAYN-Hotel`), puis double-cliquer sur **`1-INSTALLER.bat`**.
3. **`2-DEMARRER.bat`** : l'assistant de première installation s'ouvre.
   - Saisir le code affiché par le serveur.
   - Renseigner l'établissement, la devise et les taxes, l'exploitation, l'administrateur.
4. Saisir les chambres, puis les comptes du personnel. Approuver les postes.
5. Depuis les autres PC : ouvrir l'adresse indiquée dans **Administration → Système** (par ex. `http://192.168.1.10:8080`).
6. Arrêt : **`3-ARRETER.bat`** · démarrage automatique : **`DEMARRAGE-AUTOMATIQUE.bat`** (en administrateur) · mise à jour : **`4-METTRE-A-JOUR.bat`**.

Documentation :

- `docs/INSTALLATION-ET-EXPLOITATION.md` : installation, démarrage, administration, utilisateurs et permissions, réseau local, sauvegarde, restauration, pannes, mise à jour ;
- `docs/GUIDE-UTILISATEUR.md` : utilisation des principaux modules par le personnel.

## 10. Recommandations avant la première utilisation dans un hôtel

1. Installer sur le PC réel et faire **une journée à blanc** avec le personnel sur la **version de démonstration** (`DEMO-KAYN-HOTEL.bat`, base séparée) : réservations, check-in et check-out, restaurant, caisse, night audit. La base réelle reste vierge de toute donnée de test.
2. Faire valider par le comptable les **taux de TVA et de taxe de séjour**, puis contrôler une facture.
3. Imprimer une **facture A4 et un ticket 80 mm** sur les imprimantes de l'hôtel.
4. Mettre le serveur sur un **onduleur**, lui donner une **IP fixe** et activer le **démarrage automatique**.
5. Placer les sauvegardes sur un **second disque** (`BACKUP_DIR`). Faire une **copie USB chaque semaine**, gardée hors de l'hôtel. Faire une **restauration d'essai chaque mois**.
6. Créer **un compte par employé**, avec le rôle le plus restreint possible. Ne jamais partager de compte.
7. Former le personnel avec `GUIDE-UTILISATEUR.md` : 1 h pour la réception, 30 min pour les autres services.
8. Pendant le pilote, lire chaque matin **Administration → Tableau de bord** (alertes, dernière sauvegarde) et le journal d'erreurs `server/data/logs/kayn-hotel.log`.
