# KAYN Hotel — Rapport final de validation (Phase 15)

Date : 11/11/2026 · Version : 1.0 (16 migrations, numérotée v2.4 en interne pendant le développement) · Environnement de test : PostgreSQL 16.15, Node.js 22, Linux.
Toutes les opérations destructives ont été faites sur des bases séparées : `kayn_hotel_test`, `kayn_hotel_crawl`, `kayn_hotel_perf`, `kayn_hotel_fresh` et des bases temporaires de restauration d'essai.

## 1. Verdict

**KAYN Hotel peut être mis en service dans un premier hôtel pilote.** Aucune erreur critique connue ne reste ouverte.
Avant l'ouverture, les conditions du § 8 :

1. tester les scripts `.bat` sur le PC Windows réel ;
2. saisir les taux de taxes validés par le comptable ;
3. organiser la copie des sauvegardes hors du serveur ;
4. tester l'imprimante réelle (A4 et ticket).

## 2. Tests exécutés

| Série | Tests | Résultat |
|---|---|---|
| Tests automatisés de bout en bout (API + vraie base PostgreSQL, 17 fichiers) | **153** | **153 réussis / 0 échec** |
| — dont modules (réservations, chambres, réception, facturation et caisse, housekeeping, restaurant, stocks et achats, maintenance, RH, CRM, rapports, night audit, administration) | 144 | ✅ |
| — dont intégration entre modules : 4 scénarios du cahier des charges | 4 | ✅ |
| — dont intégrité de la base | 1 (25 contrôles) | ✅ |
| — dont matrice de sécurité par rôle (14 rôles × 13 API sensibles) | 1 | ✅ |
| — dont première installation sur base vide | 3 | ✅ |
| Parcours de l'interface (navigateur réel) : 18 comptes / rôles, toutes les pages et tous les onglets | 18 parcours | 0 erreur JavaScript, 0 erreur API après corrections |
| Affichage tablette (820 px) et téléphone (390 px), 16 écrans principaux | 32 | 0 débordement |
| Hôtel vide (0 chambre) après l'assistant : 19 pages | 19 | 0 erreur |
| Performance sur une base volumineuse (5 104 réservations, 5 168 clients, 4 657 paiements) | 16 mesures | voir § 5 |
| Sauvegarde + restauration d'essai sur la base de démonstration (148 tables, 5 887 lignes) | 1 | ✅ contenu identique, 455 relations valides |
| Documents : facture A4 et ticket 80 mm (logo, raison sociale, coordonnées, NIF/NIS/RC/Art., numéro, date, TVA, devise, totaux) | 2 | ✅ (contrôle du texte et de l'image) |

**Les 4 scénarios d'intégration, contrôlés de bout en bout :**

1. **Réservation et séjour** : client CRM → réservation → conflit de chambre refusé → confirmation → check-in → chambre occupée et tableau de bord à jour → prestations → départ refusé tant que le solde est dû → paiement → facture payée (au centime : HT = somme des lignes, TTC = HT + taxes, paiements = facture) → PDF → chambre « à nettoyer » → historique CRM → rapports (CA, arrivées, encaissé = paiement).
2. **Restaurant** : carte + recette → commande → TVA 9 % → transfert sur la chambre (double transfert refusé) → folio = commande au centime → stock déduit → facture de départ avec la consommation une seule fois → CA restaurant exact, sans double comptage.
3. **Housekeeping** : départ → « à nettoyer » + tâche automatique → affectation → check-in refusé tant que la chambre est sale → nettoyage → l'agent ne peut pas inspecter → inspection par la gouvernante → chambre inspectée → check-in du client suivant.
4. **Night audit** : contrôles → caisse comptée → comptabilisation idempotente (aucune écriture en double) → anomalies justifiées → validation → clôture → nouvelle journée ouverte → journée clôturée verrouillée → séjour en cours poursuivi normalement.

## 3. Erreurs découvertes et corrections

| # | Gravité | Problème | Correction |
|---|---|---|---|
| 1 | **Bloquant** | Avec 5 000 réservations (environ 1 à 2 ans d'activité), le tableau de bord prenait **18,8 s**, la liste des réservations **10,3 s** et les rapports **13 à 14 s**. Cause : les clés étrangères n'étaient pas indexées (calcul des soldes en balayage complet). | Migration `016` : 44 index sur les relations les plus sollicitées → tableau de bord **0,8 s**, liste **0,13 s**, rapports **0,25 à 1,1 s**. |
| 2 | **Bloquant** | L'installation « réelle » (`npm run seed`) créait un hôtel fictif de 40 chambres et un administrateur au mot de passe codé en dur (`Kayn2026!`). | Assistant de première installation : code d'installation physique, aucun compte par défaut, mot de passe administrateur fort obligatoire, aucune chambre fictive. La démo est séparée (base `kayn_hotel_demo`, port 8090, mot de passe aléatoire). |
| 3 | **Bloquant** | Les tâches automatiques (ménage, préventif, CRM) cherchaient un compte nommé exactement `admin` : avec un autre identifiant, elles ne tournaient plus. | Recherche du compte super administrateur actif, quel que soit son identifiant. |
| 4 | Important (sécurité) | Le rôle Directeur et le Responsable comptabilité pouvaient **télécharger une sauvegarde complète** : toutes les données, empreintes de mots de passe, mot de passe SMTP. | Sauvegardes réservées à l'administration ; téléchargement réservé aux détenteurs du droit « restaurer ». |
| 5 | Important (sécurité) | Élévation de privilèges possible par les écrans RH et Housekeeping : un utilisateur pouvait attribuer un rôle plus puissant que le sien. | Contrôle commun « on n'attribue que des droits que l'on possède » sur tous les écrans qui attribuent un rôle (testé). |
| 6 | Important | Comptable : la page Réservations appelait les types de chambres sans le droit nécessaire (erreur 403). | API ouverte aux droits « réservations » ou « chambres ». |
| 7 | Important | Gouvernante, technicien, maintenance : l'onglet Tarifs de la page Chambres affichait des erreurs 403. | Onglet masqué sans droit sur les tarifs. |
| 8 | Important | Journal d'activité, responsables de départements et de services : listes d'utilisateurs refusées aux non-administrateurs. | Liste courte (nom seulement) réservée aux droits concernés. |
| 9 | Moyen | Montants affichés en « DA » en dur dans une quarantaine de messages serveur, même avec une autre devise. | Symbole de l'établissement partout. |
| 10 | Moyen | Heure des tickets et des documents PDF en UTC (1 h d'écart avec Oran). | Fuseau de l'établissement. |
| 11 | Moyen | Deux relations sans clé étrangère (fidélité → récompense, notification → campagne). | Clés ajoutées puis validées (aucun orphelin trouvé). |
| 12 | Faible | Ticket thermique trop long (papier perdu). | Hauteur ajustée. |
| 13 | Faible | Erreurs serveur affichées uniquement à l'écran. | Journal fichier `server/data/logs/kayn-hotel.log`, rotation à 10 Mo, arrêt propre. |

Les phases 13 et 14 avaient déjà corrigé 23 défauts, tous couverts par des tests.

## 4. État de la base de données

- 148 tables, 455 clés étrangères (toutes validées), 338 index, 50 déclencheurs de protection.
- Migrations 001 à 016 appliquées automatiquement au démarrage, sans suppression de données.
- Contrôles réussis :
  - 0 réservation sans chambre et 0 séjour orphelin ;
  - 0 numéro de facture en double et 0 consommation reportée deux fois ;
  - 0 écriture de night audit en double ;
  - stock = somme des mouvements pour chaque produit ;
  - aucune facture encaissée au-delà de son total ;
  - aucune chambre réservée deux fois sur une même nuit (contrainte d'exclusion).
- **Immuables en base** : paiements, factures émises, journal d'activité, inspections et journées clôturées.
- **Concurrence** : 10 paiements simultanés sur une même facture → 1 seul accepté. 5 factures simultanées → numéros uniques.

## 5. Performance (base de 5 104 réservations, médiane de 3 mesures)

| Écran | Avant | Après |
|---|---|---|
| Tableau de bord | 18 764 ms | **817 ms** |
| Liste des réservations | 10 321 ms | **134 ms** (recherche filtrée : 154 ms, mesurée lors de l'audit 1.0) |
| Rapports vue générale / finances (22 mois) | 13 175 / 14 033 ms | **1 084 / 248 ms** |
| Export Excel finances | 12 445 ms | **248 ms** |

Autres mesures, après correction :

- planning 30 jours : 13 ms ;
- export PDF : 0,8 s ;
- night audit : 80 à 156 ms ;
- création de facture : 21 ms ;
- **25 requêtes simultanées (5 écrans) : 2,5 s au total, toutes réussies.**

## 6. État de la sécurité

| Contrôle | État |
|---|---|
| Mots de passe | Hachés (bcrypt), jamais affichés, journalisés ni renvoyés par l'API |
| Comptes par défaut | Aucun. Administrateur principal protégé, créé avec un mot de passe fort. |
| Mot de passe oublié | Code à usage unique, haché, expirant, 5 essais maximum |
| Sessions | Cookie HttpOnly + SameSite=Strict, expiration après inactivité, déconnexion effective, coupure immédiate à la désactivation du compte |
| Force brute | Verrouillage paramétrable, limitation du nombre de connexions, alerte de sécurité |
| Contournement par l'API | Toutes les permissions sont vérifiées côté serveur ; refus tracés ; protection CSRF |
| Injection SQL | Requêtes paramétrées (testé avec une chaîne malveillante) |
| Postes | Approbation des nouveaux appareils |
| Erreurs | Messages génériques, sans détail technique ni mot de passe de la base |
| Dépendances | 4 vulnérabilités « modérées » signalées par `npm audit` (react-router, uuid via exceljs), non exploitables dans l'usage actuel. À mettre à jour dans une prochaine version : la correction impose des versions majeures. |
| HTTPS | Non actif (réseau local). À prévoir si l'application est un jour exposée à Internet. |

## 7. Sauvegardes et fonctionnement local

- Sauvegarde complète vérifiée (empreinte, relecture, contenu). Elle n'est jamais déclarée réussie avant vérification.
- **Restauration d'essai** non destructive dans une base temporaire, testée sur la base de démo :
  - restaurée en 1,6 s ;
  - 148 tables et 5 887 lignes identiques ;
  - 455 relations valides ;
  - montants cohérents.
- **Restauration réelle**, testée sur la base de test :
  - confirmation explicite et sauvegarde de sécurité préalable ;
  - transaction unique ;
  - contrôle d'intégrité ;
  - application opérationnelle après la restauration ;
  - fichier corrompu détecté et refusé.
- **Hors ligne** : toutes les fonctions essentielles fonctionnent sans Internet (testé avec Internet coupé).
  - Seuls ont besoin d'Internet : les e-mails (SMTP), le paiement en ligne (aucune passerelle) et les enquêtes consultées hors de l'hôtel.
- **Réseau local** :
  - le serveur écoute sur toutes les interfaces ;
  - Administration → Système affiche les adresses à ouvrir depuis les postes ;
  - la configuration du pare-feu est documentée.

## 8. Limites connues et points nécessitant une intervention

**À faire avant l'ouverture (externe)**

1. Exécuter `1-INSTALLER.bat` puis `2-DEMARRER.bat` sur le PC Windows de l'hôtel. Les scripts n'ont pas pu être exécutés sous Windows dans l'environnement de test. Les commandes qu'ils lancent ont été validées sous Linux, et le démarrage compilé (`node dist/index.js`) a été testé.
2. Saisir les **taux de TVA et de taxe de séjour réels**, validés par le comptable.
3. Imprimer une facture A4 et un ticket sur les **imprimantes réelles**. La génération a été vérifiée, pas l'impression physique.
4. Fixer l'adresse IP du serveur, puis organiser une **copie hebdomadaire des sauvegardes hors site**.
5. SMTP, si l'hôtel veut envoyer des e-mails.

**Fonctionnalités incomplètes ou limitées (non bloquantes)**

- Paiement en ligne : aucune passerelle n'est intégrée (refusé proprement).
- Départ le jour même de l'arrivée (« day use ») : la nuit reste comptée et la chambre n'est revendable que le lendemain.
- « Décimales affichées » : n'agit que sur l'affichage ; les calculs restent au centime.
- Pas d'accès distant sécurisé (HTTPS / VPN) : prévu localement seulement.
- Le parcours automatique de l'interface ouvre toutes les pages et tous les onglets, mais n'a pas cliqué chaque bouton d'action. Les actions sont couvertes par les 153 tests d'API.

**Améliorations facultatives**

- Mise à jour majeure de react-router et exceljs.
- Copie automatique des sauvegardes vers un NAS ou une clé USB.
- Service Windows natif (aujourd'hui : tâche planifiée au démarrage).
- Tableau de bord sous 0,5 s : mise en cache des créances.

## 9. Critères de mise en production

| Critère | État |
|---|---|
| Modules essentiels fonctionnels | ✅ |
| Opérations correctement enregistrées et tracées | ✅ |
| Données cohérentes entre les modules (4 scénarios) | ✅ |
| Calculs financiers fiables (au centime, taux figés) | ✅ |
| Permissions respectées côté serveur | ✅ |
| Sauvegardes et restaurations testées | ✅ |
| Erreurs critiques corrigées | ✅ |
| Démarrage et utilisation locale documentés | ✅ (`docs/INSTALLATION-ET-EXPLOITATION.md`, `docs/GUIDE-UTILISATEUR.md`) |
| Utilisable en conditions réelles | ✅ sous réserve des 5 points externes du § 8 |
