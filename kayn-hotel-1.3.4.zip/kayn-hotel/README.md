# KAYN Hotel 1.0 — logiciel de gestion hôtelière (PMS)

Logiciel installé **sur le serveur de l'hôtel** (fonctionne sans Internet). Les postes et tablettes y accèdent par le navigateur, sur le réseau local.

- **Serveur** : Node.js 20+ · TypeScript · Fastify
- **Base de données** : PostgreSQL 16 (avec l'extension `btree_gist`, incluse par défaut)
- **Interface** : React · français / arabe (RTL) / anglais · mode jour / nuit

## Documentation

- [Installation et exploitation](docs/INSTALLATION-ET-EXPLOITATION.md) — installation, première installation, démarrage / arrêt, utilisateurs, réseau local, sauvegarde, restauration, pannes
- [Guide rapide du personnel](docs/GUIDE-UTILISATEUR.md)
- [Rapport de livraison 1.0 (audit final, verdict)](docs/RAPPORT-LIVRAISON-V1.0.md)
- [Rapport de validation (phase 15)](docs/RAPPORT-VALIDATION-PHASE15.md)

## Modules disponibles (version 1.0)

| Module | État |
|---|---|
| Tableau de bord (KPI réels, ADR, RevPAR, CA, encaissements, créances, dépenses, graphiques, alertes) | ✅ |
| Planning (glisser-déposer, prolongation, changement de chambre, recherche, filtres, étages repliables, dispo par jour, 7/14/30 j) | ✅ |
| Réservations — liste complète (14 colonnes), recherche instantanée, filtres avancés, tri, pagination, export Excel / PDF, impression | ✅ |
| Réservations — formulaire complet : client, séjour, type et nombre de chambres, tarif standard ou personnalisé, réduction (% ou DA), TVA, taxe de séjour, acompte, reste à payer | ✅ |
| Réservations — modifier, changer de chambre, modifier les dates, prolonger / réduire, ajouter / annuler une chambre, occupants, historique, voucher PDF | ✅ |
| Groupes / entreprises / agences : plusieurs chambres, plusieurs clients, facture commune ou facture par chambre, paiement par chambre | ✅ |
| Notifications : confirmation, modification, annulation, rappel J-1 (WhatsApp en un clic, e-mail automatique si serveur SMTP configuré) | ✅ |
| Front office de base (check-in, check-out avec facture, paiements, annulation de paiement tracée) | ✅ |
| Housekeeping — tableau de bord : à nettoyer, en cours, à inspecter, propres, occupées, Ne pas déranger, hors service, avancement du jour | ✅ |
| Housekeeping — 6 états de propreté (Sale, À nettoyer, En cours, À inspecter, Nettoyée, Propre et disponible) + Occupée / Ne pas déranger / Hors service ; changements incohérents bloqués (superviseur : forçage tracé) | ✅ |
| Housekeeping — tâches automatiques (départs, recouches, arrivées prioritaires) ou manuelles ; affectation, priorité, échéance ; À faire → En cours → À inspecter → Validée ; commentaires ; problème → ticket de maintenance ; mini-bar → folio du client | ✅ |
| Housekeeping — planning du personnel : horaires, zone, pointage, chambres et minutes par employée, avancement, réaffectation, répartition automatique (étage + charge + plafond) | ✅ |
| Housekeeping — inspection : checklist paramétrable avec points critiques, score minimum, remarques, photos, ticket ; refus → retour automatique « À nettoyer » ; contrôle par une autre personne que celle qui a nettoyé ; inspecteur et date enregistrés | ✅ |
| Linge : stock propre / en chambres / sale / blanchisserie, stock minimum, mouvements immuables, lots de blanchisserie (retour partiel, manquant, coût → dépense en caisse) | ✅ |
| Objets trouvés : chambre ou lieu, date, description, photo, trouvé par, dernier occupant ; En attente → Stocké → Rendu (à qui) / Archivé (motif) | ✅ |
| Rapports ménage : tâches réalisées, en retard, performance du personnel, inspections / refus, consommation de linge, historique quotidien — PDF, Excel, CSV | ✅ |
| Rôles ménage : femme / valet de chambre (ses tâches uniquement), gouvernante / superviseur, réceptionniste (Ne pas déranger, objets trouvés), administrateur | ✅ |
| Sécurité (sessions, rôles, permissions, approbation des appareils, verrouillage après 5 échecs, journal d'audit non modifiable) | ✅ |
| Chambres — vue grille et tableau, filtres bâtiment / étage / catégorie / statut / propreté, recherche par numéro, création, modification, désactivation logique (historique conservé), réactivation | ✅ |
| Chambres — fiche détaillée : client actuel, réservations à venir, historique clients, ménage, incidents, blocages, journal des modifications, photos, équipements, caractéristiques | ✅ |
| Statuts : occupation (disponible / réservée / occupée / maintenance / hors service) distincte de la propreté (propre / inspectée / à nettoyer / en cours), mis à jour automatiquement | ✅ |
| Hors service et maintenance datés (du … au …), refus si une réservation existe, affichage hachuré au planning, remise en service → « À nettoyer » | ✅ |
| Types de chambres (10 modèles + personnalisés) : capacité, adultes / enfants max, lits, m², équipements, photos, tarif semaine / week-end, supplément enfant | ✅ |
| Étages et bâtiments : création, modification, statistiques d'occupation, suppression contrôlée | ✅ |
| Tarifs : nuits week-end paramétrables, saisons (haute / basse / événement, sans chevauchement), plans entreprise / agence / groupe / négocié / promo, prix fixes par catégorie, simulateur de prix ; appliqués automatiquement dans le formulaire de réservation | ✅ |
| Équipements : 13 standards + personnalisés, libellés FR / EN / AR | ✅ |
| Front Office — main courante (recherche, filtres, tri, export Excel), arrivées, départs, indicateurs du jour | ✅ |
| Check-in en 4 étapes : vérification des dates, attribution / changement de chambre, accompagnants, identité complète (fiche de police), consentement loi 18-07, signature à l'écran, paiement, impression de la fiche FR/AR | ✅ |
| Walk-in : client + chambre + tarif + paiement → réservation, séjour et check-in en une seule opération | ✅ |
| Check-out : aperçu exact (départ anticipé recalculé), consommations, taxes, paiement final, remboursement du trop-perçu, solde impayé refusé sauf facturation société ou validation d'un responsable avec motif, facture imprimable | ✅ |
| Changement de chambre (raison, différence de tarif, historique exact par chambre) et prolongation (disponibilité, prix recalculé) | ✅ |
| Prestations : catalogue paramétrable (petit-déjeuner, restaurant, blanchisserie, room service, transport, parking, mini-bar…), ajout au séjour, annulation tracée | ✅ |
| Clients : annuaire, fiche complète, historique séjours / paiements, préférences, demandes, réclamations, notes internes, VIP, pièce masquée selon les droits | ✅ |
| Rapports de réception : arrivées, départs, présents, retards de départ, chambres disponibles, à nettoyer, historiques check-in / check-out (impression + Excel) | ✅ |
| Anti double opération : clé d'opération unique par formulaire (double clic, réseau qui renvoie) + contrôles en base | ✅ |
| Factures : séjour, finale au check-out, pro forma (série PF), factures libres société / comptoir avec remises de ligne, numérotation unique et séquentielle sans trou (F / PF / AV), PDF, impression | ✅ |
| Avoirs (série AV) : commercial total ou partiel, annulation pour réémission ; partage d'une facture entre plusieurs clients au centime près ; facture émise jamais modifiable (verrou en base) | ✅ |
| Folio : regroupement par catégorie, solde par chambre / client, transfert de prestations entre chambres et clients (tracé) | ✅ |
| Paiements : espèces, carte (4 derniers chiffres seulement, numéro complet refusé), chèque, virement, compte société, paiement en ligne si passerelle configurée ; acomptes, partiels, totaux ; remboursements limités au trop-perçu | ✅ |
| Caisse : ouverture avec fond, entrées / sorties, dépenses et recettes, solde théorique automatique, clôture avec écart et justification obligatoire, validation par un superviseur, rapport PDF ; rôles caissier / superviseur / administrateur | ✅ |
| Taxes : TVA par type de prestation, taxe de séjour, exonération client (administrateur), taux figés sur chaque ligne et chaque facture | ✅ |
| Rapports financiers par période : CA, recettes par mode, dépenses, TVA collectée, factures payées / impayées, remboursements, créances, caisses — export PDF, Excel, CSV ; historique des transactions | ✅ |
| Calculs monétaires en centimes entiers (aucun arrondi flottant) ; anti double paiement / double facturation | ✅ |
| Restaurant — tableau de bord : CA, commandes, en attente / en préparation / prêtes / servies, tables occupées, produits les plus vendus, recettes par jour et par point de vente, stock bas | ✅ |
| Carte : plats (photo, description, catégorie, prix, ingrédients, 14 allergènes, disponibilité, désactivation), variantes et suppléments, menus par service / jours / horaires, menu du jour, formule | ✅ |
| Commandes (salle, bar, room service, petit-déjeuner) : plats et boissons, quantités, instructions, remise autorisée et plafonnée, TVA figée par ligne, statuts Nouvelle → Confirmée → En préparation → Prête → Servie / Annulée, historique | ✅ |
| Plan de salle : tables par zone, capacité, statut (disponible / occupée / réservée / à nettoyer), déplacement de commande, regroupement / séparation, réservations de table sans chevauchement | ✅ |
| Cuisine (écran KDS) : temps réel, priorité et heure, postes cuisine / pâtisserie / bar, commentaires en évidence, « Commencer » / « Prêt », chrono et temps moyen de préparation | ✅ |
| Room service : chambre + client hébergé, livreur, départ et heure de livraison, consommations portées automatiquement au folio ; départ du client bloqué si une commande n'est pas réglée | ✅ |
| Petit-déjeuner : ayants droit (BB / HB / FB), inclus consommés, supplément payant au folio, horaires, rapport quotidien | ✅ |
| Bar : ventes au comptoir, encaissement par le barman, stock des boissons | ✅ |
| Règlement : paiement immédiat espèces / carte (4 derniers chiffres), sur la chambre (folio), facture restaurant indépendante (société) ; une seule fois par commande (verrou + index unique en base) | ✅ |
| Stock : articles, recettes par plat, déduction automatique à la vente, portions disponibles, blocage si stock insuffisant, alertes sous le minimum, entrées / pertes / ajustements, historique non modifiable | ✅ |
| Rôles restaurant : serveur, chef cuisinier, barman, responsable restaurant, caissier (+ administrateur) | ✅ |
| Rapports restaurant : ventes quotidiennes / mensuelles, CA par catégorie, plats les plus vendus, annulations, temps de préparation, ventes par serveur, room service, petit-déjeuner, consommation de stock — PDF, Excel, CSV | ✅ |
| Stocks — tableau de bord : valeur (PMP), produits disponibles, ruptures, sous le minimum, péremptions, achats en attente / en retard, achats du mois, dettes fournisseurs, derniers mouvements | ✅ |
| Produits : référence, code-barres, description, 8 catégories (+ libres), unités, prix d'achat et prix moyen pondéré, TVA, stock min / max, lots et dates de péremption, archivage, lien avec le linge | ✅ |
| Multi-entrepôts : magasins et réserves (cuisine, bar, étages, atelier…), stock par entrepôt, transferts avec lots conservés, historique | ✅ |
| Entrées / sorties : réceptions, consommation par département (restaurant, bar, housekeeping, maintenance + ticket, réception, administration), retours fournisseurs, pertes, casse, péremption, ajustements ; FEFO ; sortie au-delà du disponible refusée sauf autorisation « stock.force » | ✅ |
| Fournisseurs : coordonnées, NIF / NIS / RC / AI / RIB, conditions de paiement, produits fournis et derniers prix, historique d'achats, factures, solde | ✅ |
| Achats : demande → validation (pas par le demandeur) → devis et comparaison des offres → bon de commande PDF → réceptions contrôlées (partielles, refus, lots) → facture → paiements ; 7 statuts | ✅ |
| Factures fournisseurs : contrôle facture / réception, échéance automatique, doublon refusé, paiements → dépenses dans Facturation & caisse (espèces = sortie de caisse), annulation tracée | ✅ |
| Inventaires : complet, par catégorie, par entrepôt ; stock théorique figé, comptage, écarts et valeur, validation du responsable au-delà d'un seuil, ajustements automatiques, historique | ✅ |
| Alertes : rupture, minimum atteint, péremption proche / dépassée, commande en retard, écart d'inventaire important, facture fournisseur échue (aussi sur le tableau de bord principal) | ✅ |
| Rapports stocks & achats : état, valeur, mouvements, achats par fournisseur, consommation par département, périmés, écarts d'inventaire, dettes (balance âgée), dépenses par fournisseur / catégorie, journal comptable (SCF) — PDF, Excel, CSV | ✅ |
| Rôles : magasinier, acheteur, comptabilité (paiements), gouvernante / chef / responsable restaurant (sorties, demandes) | ✅ |
| Maintenance — tableau de bord : équipements (opérationnels / en panne / dégradés), pannes en attente / en cours / terminées, critiques et en retard, préventif à venir, chambres bloquées, coûts du mois et de l'année, alertes | ✅ |
| Équipements : référence, 10 catégories, marque, modèle, n° de série, emplacement (chambre, étage, cuisine, réception, piscine…), département, achat, fournisseur, installation, garantie, état, documents PDF et photos, historique complet | ✅ |
| Pannes : déclaration (réception, ménage, restaurant, technicien), équipement ou chambre ou lieu, photos, priorité Faible / Moyenne / Haute / Critique avec délai d'intervention, 6 statuts (+ annulée), affectation d'un technicien | ✅ |
| Ordres de travail : correctifs, préventifs, inspections, travaux ; planification, checklist, temps passé (coût au taux horaire), pièces, prestataires, commentaires, photos, résultat, validation avec évaluation, clôture | ✅ |
| Maintenance préventive : quotidienne → annuelle, plans par équipement, génération automatique des ordres (sans doublon), alertes avant échéance, prochaine échéance recalculée à la validation | ✅ |
| Techniciens : internes (compte utilisateur) ou prestataires, spécialités, taux horaire, disponibilité, charge de travail, interventions, note moyenne | ✅ |
| Pièces détachées : stock partagé avec Stocks & Achats, sortie automatique (département maintenance, rattachée à l'OT), pièce manquante → demande d'achat et panne « en attente de pièces » | ✅ |
| Chambres hors service : blocage depuis la panne, réservation impossible, réactivation uniquement à la validation de la réparation — jamais si une autre restriction existe | ✅ |
| Coûts : main-d'œuvre, pièces, prestataires (dépense en caisse ou facture fournisseur), totaux par intervention / équipement / département | ✅ |
| Rapports maintenance : pannes, interventions par technicien, temps moyen de résolution, équipements les plus en panne, coûts par période / département, préventif réalisé / en retard, chambres indisponibles, historique des équipements — PDF, Excel, CSV | ✅ |
| Rôles : technicien (ses interventions), responsable maintenance, réception et ménage (déclaration), direction, administrateur | ✅ |
| RH — tableau de bord : effectif, actifs / sortis, présents, absents, en congé, retards du jour, contrats à échéance, anniversaires, masse salariale, répartition par département, alertes | ✅ |
| Employés : matricule unique, photo, coordonnées, adresse, naissance, embauche, département, poste, responsable, contrat, salaire, statut (actif / suspendu / en congé / sorti), documents ; données personnelles et salariales masquées selon les droits | ✅ |
| Départements (10 par défaut + personnalisés, chef de département) et postes | ✅ |
| Pointage : borne (matricule + code), pointage personnel, pointage manuel par le responsable, pauses, heures travaillées, retards (tolérance), heures sup. ; corrections justifiées autorisées par les RH | ✅ |
| Planning : équipes matin / soir / nuit / journée, horaires libres, repos, rotations, conflits (chevauchement, repos minimal, congés), vue par département, échanges de postes validés par le responsable ; alimente le planning du housekeeping | ✅ |
| Congés et absences : demande par l'employé, validation / refus motivé, congé annuel avec solde (acquis mensuel, reprise, ajustements), maladie, sans solde, absences justifiées / injustifiées, autorisations de sortie en heures, justificatifs, historique | ✅ |
| Contrats : CDI, CDD, saisonnier, essai, stage ; renouvellement, avenants non modifiables, archivage, alertes avant expiration | ✅ |
| Paie : salaire de base, primes, indemnités, retenues, heures sup., absences non payées, avances (caisse) remboursées par échéances, cotisations et barème d'impôt configurables (aucun taux légal prérempli), bulletins PDF, contrôle croisé calcul / validation, bulletins figés, paiement → dépense « Salaires », exports | ✅ |
| Évaluations (critères, objectifs, commentaires), formations, compétences | ✅ |
| Documents RH : pièces jointes (photo / PDF), dates d'expiration, alertes, confidentialité (RH seulement), consultation tracée | ✅ |
| Rapports RH : effectifs, présences / absences, retards, heures sup., congés, masse salariale, contrats, performance — PDF, Excel, CSV | ✅ |
| Rôles : employé, chef de département, responsable RH, comptable, direction, administrateur, borne de pointage ; accès au logiciel créés depuis la fiche employé ; sortie = comptes désactivés | ✅ |
| CRM — tableau de bord : clients, nouveaux, fidèles, VIP, actifs / inactifs, membres, taux de fidélisation, satisfaction (note + NPS), réclamations en attente / en retard, anniversaires, VIP en séjour et à l'arrivée | ✅ |
| Fiche client unique (code CL000001) : identité, photo, contacts, langue, consentements, statut Standard / Fidèle / VIP / Entreprise, séjours, réservations, restaurant, factures & paiements (permission dédiée), préférences, réclamations, échanges ; détection et fusion des doublons | ✅ |
| Préférences (chambre, alimentation déclarée, services, demandes, occasions, habitudes) visibles à la réservation et au check-in, avec remise membre en un clic | ✅ |
| Fidélité : niveaux configurables (Silver / Gold / Platinum), points par séjour et restaurant (jamais deux fois), bonus, expiration, récompenses, remises membres, historique | ✅ |
| Entreprises : contacts, contrats, tarifs négociés, réservations, facturation centralisée, créances | ✅ |
| Réclamations : catégorie, priorité, délai, responsable, réponses, actions correctives, statuts Nouvelle → Clôturée, satisfaction après résolution ; enquêtes de satisfaction configurables (lien public ou saisie) | ✅ |
| Communication : historique des échanges, modèles FR / AR / EN, remerciement + enquête après départ, message avant arrivée, anniversaire (seulement si l'envoi est configuré), consentement respecté | ✅ |
| Segments dynamiques et campagnes : ciblage, exclusion sans consentement, désinscription en un clic, suivi des réservations et du CA générés | ✅ |
| Rapports CRM (9) en PDF / Excel / CSV ; données personnelles : export, rectification, anonymisation tracés | ✅ |
| Rapports & statistiques — tableau de bord analytique (occupation, ADR, RevPAR, CA total / hébergement / restaurant / services, réservations, arrivées, départs, durée moyenne, annulations, no-shows, dépenses, créances, résultat opérationnel) avec évolution et tendance vs période précédente | ✅ |
| Rapports réservations, hébergement (par chambre / catégorie / étage), finances (facturé ≠ encaissé, TVA, remises, avoirs, caisses), restaurant, housekeeping, stocks, maintenance, RH (salaires protégés), CRM | ✅ |
| Filtres globaux (aujourd'hui → année précédente, période libre, comparaison période précédente / année N-1, regroupement jour / semaine / mois / année, type, étage, canal, statut, point de vente, catégorie, département), graphiques courbes / barres / anneaux, drill-down paginé | ✅ |
| Exports PDF (logo, période, devise, graphiques, totaux), Excel (synthèse + feuilles), CSV ; vues personnalisées, filtres favoris, rapports enregistrés, vue par défaut par rôle | ✅ |
| Night audit — date opérationnelle de l'hôtel, tableau de bord (arrivées, départs, présents, chambres, CA du jour, encaissements, dépenses, impayés, transactions en attente, anomalies) et opérations à traiter | ✅ |
| Contrôles automatiques : réservations (check-in / check-out non faits, no-shows potentiels, sans chambre, dates, conflits, soldes, statuts), chambres, factures, paiements (doublons, sans facture, trop-perçu, remboursements), caisse, dépenses, restaurant (commandes ouvertes, non transférées) | ✅ |
| Anomalies avec gravité, module, référence, responsable, historique de résolution, justification et commentaires ; checklist en 12 points (À vérifier / Conforme / Anomalie / Corrigé / Validé) | ✅ |
| Comptabilisation idempotente des revenus (hébergement, restaurant, room service, services) avec référence d'origine et écritures d'ajustement ; rapprochement de caisse avec justification et autorisation d'un second responsable | ✅ |
| Clôture atomique (verrou, contrôle final, rapport figé), passage au jour suivant, verrouillage des opérations de la journée clôturée, réouverture exceptionnelle justifiée, historique et rapports PDF / Excel / CSV | ✅ |
| Administration — tableau de bord (utilisateurs actifs / désactivés / verrouillés, effectifs par département, rôles, dernières connexions, dernières activités, alertes de sécurité, dernière sauvegarde, état du système, raccourcis) | ✅ |
| Utilisateurs : création, modification, profil, activation / désactivation motivée (sessions coupées), code de réinitialisation à usage unique, déverrouillage, historique d'activité ; identifiant et e-mail uniques, mot de passe jamais affiché ; compte administrateur principal protégé | ✅ |
| Rôles & permissions : 26 rôles (dont les 16 demandés), matrice par module et action, création, duplication, désactivation d'un rôle inutilisé, permissions sensibles signalées, aucune élévation de privilèges, contrôles côté serveur appliqués immédiatement | ✅ |
| Départements (Direction, Réception, Comptabilité, Restaurant, Housekeeping, Maintenance, RH, Stocks + personnalisés), responsable, membres ; jamais supprimés | ✅ |
| Établissement (raison sociale, nom commercial, logo, catégorie, coordonnées, mentions fiscales, capacité calculée, heures d'arrivée / départ, fuseau, langues, formats) utilisé par la réception, les factures et les rapports | ✅ |
| Finances : devise et symbole, décimales, modes de paiement acceptés (contrôlés en base), pied de facture, taxes versionnées et datées (jamais rétroactives, factures émises figées) | ✅ |
| Services (restaurant, room service, spa, parking, blanchisserie, transport, salle de réunion…), documents (A4 ou ticket thermique 80 mm, logo, mentions fiscales), notifications internes réelles par type et rôle (cloche) | ✅ |
| Sécurité : verrouillage anti force brute paramétrable, expiration après inactivité, sessions ouvertes et révocation, postes de travail, validation des entrées, requêtes paramétrées, refus tracés ; journal d'activité inaltérable (filtres, détail ancien / nouveau, exports), aucun secret enregistré | ✅ |
| Sauvegardes : manuelles et automatiques (quotidienne / hebdomadaire / mensuelle, rotation), vérification (SHA-256, lecture, compatibilité), téléchargement, import, restauration confirmée avec sauvegarde de sécurité préalable, transaction unique et contrôle d'intégrité, historique ; état du système (base, migrations, réseau local, fonctions nécessitant Internet) | ✅ |

## Installation sur le serveur Windows de l'hôtel

1. Installer **Node.js 20 LTS** et **PostgreSQL 16**.
2. Double-cliquer sur `1-INSTALLER.bat` (une seule fois), puis `2-DEMARRER.bat` : l'**assistant de première installation** s'ouvre (code d'installation affiché par le serveur, hôtel, devise et taxes, exploitation, administrateur principal). Aucun compte par défaut n'existe.
3. `3-ARRETER.bat` pour arrêter ; `DEMARRAGE-AUTOMATIQUE.bat` (en administrateur) pour un démarrage à chaque allumage du PC ; `4-METTRE-A-JOUR.bat` pour installer une nouvelle version (sauvegarde vérifiée automatique avant toute modification de la base).
4. `DEMO-KAYN-HOTEL.bat` : version de démonstration sur une base séparée (port 8090), sans risque pour la base réelle.

Détails : [docs/INSTALLATION-ET-EXPLOITATION.md](docs/INSTALLATION-ET-EXPLOITATION.md).

### Paramètres (`server/.env`)

| Paramètre | Rôle |
|---|---|
| `DATABASE_URL` | Connexion PostgreSQL (le mot de passe n'est jamais affiché dans les messages d'erreur) |
| `PORT`, `HOST` | Port et interface d'écoute (`0.0.0.0` = accessible depuis le réseau local) |
| `ADMIN_PASSWORD` | Démonstration uniquement (base de démo) ; en production l'administrateur est créé par l'assistant |
| `SESSION_HOURS` | Durée maximale d'une session ; l'inactivité se règle dans Administration → Sécurité |
| `HOTEL_TZ` | Fuseau par défaut (remplacé par celui de Administration → Établissement) |
| `REQUIRE_DEVICE_APPROVAL` | Approbation obligatoire des nouveaux postes |
| `COOKIE_SECURE` | `true` uniquement si le serveur est servi en HTTPS |
| `BACKUP_DIR` | Dossier des sauvegardes (défaut `server/data/backups`) — idéalement un 2e disque |
| `PG_BIN` | Dossier de `pg_dump` / `pg_restore` si introuvables (ex. `C:\Program Files\PostgreSQL\16\bin`) |

Arrêt propre : `Ctrl+C` (ou arrêt du service) — les requêtes en cours se terminent et la connexion à la base est fermée.

### Fonctions qui nécessitent Internet

Tout fonctionne sur le réseau local sans Internet, sauf : l'envoi d'e-mails (SMTP à configurer), le paiement en ligne (aucune passerelle intégrée, refusé tant qu'elle n'est pas configurée) et l'accès aux enquêtes de satisfaction depuis l'extérieur de l'hôtel (serveur à exposer).

`npm run seed:demo` ajoute des données de démonstration (pour la formation ou une démo prospect — **pas sur la base réelle**).

## Développement

```
npm install
npm run seed:demo
npm run dev            # API sur :8080, interface sur :5173
npm test               # 153 tests de bout en bout (base kayn_hotel_test)
```

## Règles métier garanties par la base de données

- **Double réservation impossible** : contrainte d'exclusion PostgreSQL sur (chambre, période).
- **Paiements** : ni suppression ni modification ; seule une annulation avec motif et utilisateur est permise.
- **Factures, lignes de facture, remboursements, dépenses, journal d'audit** : non modifiables.
- Chaque création / modification / déplacement / check-in / check-out / paiement est inscrit dans `audit_logs`.

## Flux automatiques

- Réservation créée → apparaît au planning, chambre bloquée, client enregistré, montant suivi au tableau de bord.
- Check-in → chambre occupée, séjour créé.
- Check-out → séjour clos (départ anticipé = nuits recalculées), facture finale, solde, chambre « À nettoyer », tâche housekeeping.
- Check-out → chambre « À nettoyer », « Ne pas déranger » levé, tâche « Ménage départ » (priorité haute si une arrivée est prévue).
- Ménage terminé → « À inspecter » (si l'inspection est obligatoire) → inspection validée → « Propre et disponible » ; refusée → « À nettoyer ».
- Toutes les 15 min : génération des tâches du jour (départs, recouches, arrivées) sans doublon.
- Démo : comptes ménage `nadia` (gouvernante), `amina`, `sara` (femmes de chambre) — mot de passe `Menage2026!`.
- Commande restaurant réglée → stock des ingrédients déduit, table « À nettoyer » ; « sur la chambre » → prestations au folio (jamais deux fois) ; room service livré → folio automatique.
- Démo restaurant : `karim` (serveur), `chef`, `bar` (barman), `resto` (responsable), `caisse` (caissière) — mot de passe `Resto2026!`.
- Réception d'achat → stock + PMP (+ linge propre pour les articles liés) ; vente restaurant → ingrédients sortis de l'entrepôt du restaurant ; paiement fournisseur → dépense.
- Démo stocks : `magasin` (magasinier), `achat` (acheteuse), `compta` (comptable) — mot de passe `Stock2026!`.
- Panne déclarée → équipement « en panne » (haute / critique) ou « dégradé » ; affectation → ordre de travail ; pièce utilisée → sortie de stock ; validation → panne clôturée, équipement opérationnel, chambre réactivée (si aucune autre restriction), préventif replanifié.
- Toutes les 15 min : génération des ordres de maintenance préventive arrivant à échéance.
- Démo maintenance : `mourad` (responsable maintenance), `yacine`, `omar` (techniciens) — mot de passe `Maint2026!`.
- Congé validé → postes planifiés retirés, technicien de maintenance indisponible ; sortie d'un employé → contrat clos, comptes désactivés ; paie payée → dépense « Salaires » ; avance → sortie de caisse.
- Démo RH : `samia` (responsable RH), `rachid` (chef de réception), `borne` (borne de pointage, page Pointage) — mot de passe `Rh2026!` ; code de pointage de tous les employés : `1234`.
- Départ → points de fidélité (une seule fois par séjour), statut « Fidèle » recalculé, remerciement + enquête mis en file ; note ≤ 2 → réclamation créée automatiquement ; réclamation saisie à la réception → visible au CRM.
- Démo CRM : `nadir` (responsable CRM) — mot de passe `Crm2026!`.
- Rapports : menu « Rapports & statistiques ». Conventions de calcul : nuitée vendue = chambre « en séjour » ou « terminée » (les nuits à venir des réservations en attente / confirmées sont comptées en prévision et signalées) ; occupation = nuitées / chambres disponibles (hors chambres bloquées ou hors service) ; ADR = CA hébergement HT / nuitées ; RevPAR = CA hébergement HT / chambres disponibles ; durée moyenne = nuitées / séjours terminés. CA d'activité (HT), CA facturé (factures − avoirs) et encaissé (paiements + recettes − remboursements) sont trois notions distinctes ; opérations annulées exclues ; une vente restaurant portée sur la chambre n'est comptée qu'une fois.
- Night audit : chaque paiement, facture, dépense, recette, commande, prestation et mouvement de caisse porte la date opérationnelle de la journée en cours. La clôture d'une journée D est possible à partir de minuit (D+1). Elle exige : vérifications lancées, aucune anomalie bloquante (corrigée dans son module ou justifiée), caisses comptées (écart justifié ; au-delà du seuil, autorisé par un second responsable), revenus comptabilisés, validation puis saisie de la date pour confirmer. Ensuite, les montants, dates et annulations de la journée sont verrouillés : toute correction se fait par une opération du jour (remboursement, avoir, ajustement) ; une prestation tardive datée d'une journée close est portée sur la journée en cours. Rôle `night_auditor` (auditeur de nuit) ; démo : journées des J-3 et J-2 déjà clôturées, J-1 à auditer.

## Notifications par e-mail

Ajouter dans la table `settings` la clé `smtp` (exemple) :
`{"host":"smtp.exemple.com","port":587,"user":"reservation@hotel.dz","pass":"…","from":"Hôtel K <reservation@hotel.dz>"}`
Les e-mails en attente partent automatiquement toutes les 15 minutes dès qu'Internet est disponible.
