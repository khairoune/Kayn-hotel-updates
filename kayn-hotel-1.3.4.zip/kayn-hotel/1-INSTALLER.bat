@echo off
chcp 65001 >nul
title KAYN Hotel - Installation
cd /d "%~dp0"
echo ==========================================================
echo   KAYN Hotel - INSTALLATION (a faire une seule fois)
echo ==========================================================
where node >nul 2>nul || (echo [!] Node.js 20 LTS introuvable : installez-le depuis https://nodejs.org puis relancez. & pause & exit /b 1)
set PGBIN=
for /d %%D in ("C:\Program Files\PostgreSQL\*") do if exist "%%D\bin\psql.exe" set PGBIN=%%D\bin
if exist "C:\Program Files\PostgreSQL\16\bin\psql.exe" set PGBIN=C:\Program Files\PostgreSQL\16\bin
if "%PGBIN%"=="" (echo [!] PostgreSQL 16 introuvable : installez-le depuis https://www.postgresql.org/download/windows/ puis relancez. & pause & exit /b 1)
echo PostgreSQL : %PGBIN%

if exist "server\.env" (
  echo Fichier de configuration server\.env deja present : conserve.
) else (
  call :askenv || (pause & exit /b 1)
)

echo.
echo [1/3] Installation des composants (quelques minutes)...
call npm install || (echo [!] Echec de npm install & pause & exit /b 1)
echo [2/3] Compilation de l'application...
call npm run build || (echo [!] Echec de la compilation & pause & exit /b 1)
echo [3/3] Creation / mise a jour de la base de donnees...
call npm run seed || (echo [!] Base inaccessible : verifiez le mot de passe PostgreSQL dans server\.env & pause & exit /b 1)
echo.
echo  Installation terminee.
echo  Lancez 2-DEMARRER.bat : l'assistant de premiere installation s'ouvrira dans le navigateur.
pause
exit /b 0

:askenv
echo.
set /p PGPASS=Mot de passe de l'utilisateur "postgres" (choisi a l'installation de PostgreSQL) : 
set /p PGPORT=Port de PostgreSQL 16 [5432] : 
if "%PGPORT%"=="" set PGPORT=5432
set /p DBNAME=Nom de la base [kayn_hotel] : 
if "%DBNAME%"=="" set DBNAME=kayn_hotel
set PGPASSWORD=%PGPASS%
"%PGBIN%\psql.exe" -U postgres -h localhost -p %PGPORT% -c "SELECT 1" >nul 2>&1 || (echo [!] Connexion refusee sur le port %PGPORT% : mot de passe ou port incorrect. Relancez 1-INSTALLER.bat. & exit /b 1)
"%PGBIN%\psql.exe" -U postgres -h localhost -p %PGPORT% -tc "SELECT 1 FROM pg_database WHERE datname='%DBNAME%'" | find "1" >nul || "%PGBIN%\psql.exe" -U postgres -h localhost -p %PGPORT% -c "CREATE DATABASE %DBNAME%"
if errorlevel 1 (echo [!] Connexion a PostgreSQL impossible : mot de passe incorrect ou service arrete. & exit /b 1)
(
echo # Configuration de KAYN Hotel - ne pas partager ce fichier (il contient le mot de passe de la base^)
echo DATABASE_URL=postgres://postgres:%PGPASS%@localhost:%PGPORT%/%DBNAME%
echo PORT=8080
echo HOST=0.0.0.0
echo SESSION_HOURS=12
echo HOTEL_TZ=Africa/Algiers
echo REQUIRE_DEVICE_APPROVAL=true
echo COOKIE_SECURE=false
echo PG_BIN=%PGBIN%
echo # BACKUP_DIR=D:\KAYN-Sauvegardes
) > "server\.env"
echo Configuration enregistree dans server\.env
exit /b 0
