@echo off
chcp 65001 >nul
title KAYN Hotel - Mise a jour
cd /d "%~dp0"
echo ==========================================================
echo   KAYN Hotel - MISE A JOUR
echo   A lancer dans le dossier de la NOUVELLE version, apres y avoir
echo   copie server\.env et server\data depuis l'ancienne version
echo   (voir docs\INSTALLATION-ET-EXPLOITATION.md, section Mise a jour).
echo ==========================================================
if not exist "server\.env" (echo [!] server\.env absent : copiez-le depuis l'ancienne version. & pause & exit /b 1)
echo [1/5] Arret du serveur...
call "%~dp03-ARRETER.bat" >nul
echo [2/5] Installation des composants...
call npm install || (echo [!] Echec de npm install & pause & exit /b 1)
echo [3/5] Compilation...
call npm run build || (echo [!] Echec de la compilation & pause & exit /b 1)
echo [4/5] Sauvegarde de securite AVANT mise a jour de la base...
call npm run backup -- "Avant mise a jour" || (echo [!] Sauvegarde impossible : mise a jour annulee, aucune donnee modifiee. & pause & exit /b 1)
echo [5/5] Mise a jour de la base (migrations, roles et permissions)...
call npm run seed || (echo [!] Echec de la mise a jour de la base : restaurez la sauvegarde avec l'ancienne version. & pause & exit /b 1)
echo.
echo  Mise a jour terminee. Lancez 2-DEMARRER.bat.
pause
