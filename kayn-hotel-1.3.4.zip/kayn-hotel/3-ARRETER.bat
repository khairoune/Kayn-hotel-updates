@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PORT=8080
if exist "server\.env" for /f "tokens=2 delims==" %%P in ('findstr /b "PORT=" "server\.env"') do set PORT=%%P
set FOUND=
for /f "tokens=5" %%A in ('netstat -ano ^| findstr /r /c:":%PORT% .*LISTENING"') do (set FOUND=1 & taskkill /PID %%A /T /F >nul)
if defined FOUND (echo KAYN Hotel arrete. Les operations en cours sont annulees proprement par la base de donnees.) else (echo KAYN Hotel n'etait pas demarre.)
timeout /t 3 >nul
