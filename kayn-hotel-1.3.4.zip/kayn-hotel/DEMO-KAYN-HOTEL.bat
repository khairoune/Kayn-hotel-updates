@echo off
chcp 65001 >nul
title KAYN Hotel - DEMONSTRATION
cd /d "%~dp0"
echo ==========================================================
echo   KAYN Hotel - VERSION DE DEMONSTRATION (donnees fictives)
echo   Base separee "kayn_hotel_demo", port 8090 : n'affecte jamais
echo   la base reelle de l'hotel.
echo ==========================================================
where node >nul 2>nul || (echo [!] Node.js 20 LTS introuvable : https://nodejs.org & pause & exit /b 1)
set PGBIN=
for /d %%D in ("C:\Program Files\PostgreSQL\*") do if exist "%%D\bin\psql.exe" set PGBIN=%%D\bin
if exist "C:\Program Files\PostgreSQL\16\bin\psql.exe" set PGBIN=C:\Program Files\PostgreSQL\16\bin
if "%PGBIN%"=="" (echo [!] PostgreSQL 16 introuvable : https://www.postgresql.org/download/windows/ & pause & exit /b 1)
if not exist "server\data\.demo-pg" (
  set /p PGPASS=Mot de passe de l'utilisateur "postgres" : 
  set /p PGPORT=Port de PostgreSQL 16 [5432] : 
  call :savepw
)
set /p PGPASS=<"server\data\.demo-pg"
set PGPORT=5432
if exist "server\data\.demo-pg-port" set /p PGPORT=<"server\data\.demo-pg-port"
set PGPORT=%PGPORT: =%
set PGPASSWORD=%PGPASS%
echo Connexion a PostgreSQL : port %PGPORT%, outils %PGBIN%
"%PGBIN%\psql.exe" -U postgres -h localhost -p %PGPORT% -c "SELECT 1" >nul 2>&1
if errorlevel 1 (
  echo.
  echo [!] Connexion refusee sur le port %PGPORT% : mot de passe ou port incorrect.
  echo     Rappel : PostgreSQL 16 est souvent sur 5433 si une autre version occupe 5432.
  echo     Relancez ce fichier : le mot de passe et le port seront redemandes.
  del "server\data\.demo-pg" "server\data\.demo-pg-port" >nul 2>&1
  pause
  exit /b 1
)
"%PGBIN%\psql.exe" -U postgres -h localhost -p %PGPORT% -tc "SELECT 1 FROM pg_database WHERE datname='kayn_hotel_demo'" | find "1" >nul || "%PGBIN%\psql.exe" -U postgres -h localhost -p %PGPORT% -c "CREATE DATABASE kayn_hotel_demo"
set DATABASE_URL=postgres://postgres:%PGPASS%@localhost:%PGPORT%/kayn_hotel_demo
set PORT=8090
set PG_BIN=%PGBIN%
set BACKUP_DIR=%~dp0server\data\backups-demo
set REQUIRE_DEVICE_APPROVAL=false
if not exist "node_modules" (call npm install || (pause & exit /b 1))
call npm run build || (pause & exit /b 1)
call npm run seed:demo || (echo [!] Base de demonstration inaccessible & pause & exit /b 1)
echo.
type "server\data\IDENTIFIANTS-DEMO.txt" 2>nul
start "" http://localhost:8090
cd server
:serveur
node dist\index.js
echo.
echo [!] Le serveur KAYN Hotel s'est arrete (code %errorlevel%) - %date% %time%
echo     Cause detaillee : server\data\logs\kayn-hotel.log
echo     Redemarrage automatique dans 5 secondes (fermez cette fenetre pour arreter)...
>>"data\logs\redemarrages.log" echo %date% %time% arret code %errorlevel%
timeout /t 5 >nul
goto serveur
pause
exit /b 0

:savepw
if not exist "server\data" mkdir "server\data"
>"server\data\.demo-pg" echo %PGPASS%
if "%PGPORT%"=="" set PGPORT=5432
>"server\data\.demo-pg-port" echo %PGPORT%
exit /b 0
