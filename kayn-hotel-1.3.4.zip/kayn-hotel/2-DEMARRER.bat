@echo off
chcp 65001 >nul
title KAYN Hotel - Serveur (ne pas fermer cette fenetre)
cd /d "%~dp0"
if not exist "server\.env" (echo [!] Lancez d'abord 1-INSTALLER.bat & pause & exit /b 1)
if not exist "server\dist\index.js" (echo Compilation... & call npm run build)
set PORT=8080
for /f "tokens=2 delims==" %%P in ('findstr /b "PORT=" "server\.env"') do set PORT=%%P
echo ==========================================================
echo   KAYN Hotel demarre sur http://localhost:%PORT%
echo   Autres postes : Administration ^> Systeme affiche l'adresse reseau.
echo   Pour arreter : 3-ARRETER.bat (ou Ctrl+C dans cette fenetre)
echo   Journal des erreurs : server\data\logs\kayn-hotel.log
echo ==========================================================
start "" http://localhost:%PORT%
cd server
:serveur
node dist\index.js
echo.
echo [!] Le serveur KAYN Hotel s'est arrete (code %errorlevel%) - %date% %time%
echo     Cause detaillee : server\data\logs\kayn-hotel.log
echo     Redemarrage automatique dans 5 secondes (fermez cette fenetre pour arreter)...
>>"data\logs\redemarrages.log" echo %date% %time% arret code %errorlevel%
timeout /t 5 >nul
goto serveur
echo.
echo KAYN Hotel est arrete.
pause
