/** Arrête proprement KAYN Hotel (superviseur + serveur) : drapeau STOP puis arrêt forcé si besoin. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const data = path.join(__dirname, 'data');
fs.mkdirSync(data, { recursive: true });
const pidFile = path.join(data, 'superviseur.pid');
const alive = (p) => { try { process.kill(p, 0); return true; } catch { return false; } };
let pid = 0;
try { pid = Number(fs.readFileSync(pidFile, 'utf8')); } catch { /* */ }
if (!pid || !alive(pid)) { console.log('KAYN Hotel etait deja arrete.'); try { fs.unlinkSync(path.join(data, 'STOP')); } catch { /* */ } process.exit(0); }
fs.writeFileSync(path.join(data, 'STOP'), '');
const t0 = Date.now();
const timer = setInterval(() => {
  if (!alive(pid)) { clearInterval(timer); try { fs.unlinkSync(pidFile); } catch { /* */ } console.log('KAYN Hotel est arrete.'); process.exit(0); }
  if (Date.now() - t0 > 10000) { try { process.kill(pid); } catch { /* */ } }
  if (Date.now() - t0 > 15000) { clearInterval(timer); console.log('Arret force.'); process.exit(0); }
}, 500);
