/**
 * Lance le superviseur KAYN Hotel (start.cjs) en arrière-plan, sans fenêtre, puis rend la main.
 * Le serveur continue même si la fenêtre qui l'a lancé est fermée. Arrêt : 3-ARRETER.bat (arreter.cjs).
 * Usage : node lancer.cjs [--env data/demo.env]
 */
'use strict';
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const pidFile = path.join(__dirname, 'data', 'superviseur.pid');
try {
  const pid = Number(fs.readFileSync(pidFile, 'utf8'));
  if (pid) { process.kill(pid, 0); console.log('KAYN Hotel tourne deja.'); process.exit(0); }
} catch { /* pas de superviseur actif */ }
const child = spawn(process.execPath, [path.join(__dirname, 'start.cjs'), ...process.argv.slice(2)], {
  cwd: __dirname, detached: true, stdio: 'ignore', windowsHide: true,
});
child.unref();
console.log('KAYN Hotel demarre en arriere-plan.');
