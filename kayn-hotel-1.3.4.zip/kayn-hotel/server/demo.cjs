/**
 * KAYN Hotel — lancement de la DÉMONSTRATION (base séparée kayn_hotel_demo, port 8090, données fictives).
 * Remplace la logique de l'ancien DEMO-KAYN-HOTEL.bat (le .bat ne fait plus qu'appeler ce script).
 * Étapes : connexion PostgreSQL (mot de passe/port mémorisés) → composants → base de démo → serveur en arrière-plan → navigateur.
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');
const { spawn, spawnSync } = require('node:child_process');

const SERVER = __dirname;
const ROOT = path.dirname(SERVER);
const DATA = path.join(SERVER, 'data');
const PORT = 8090;
const URL_APP = `http://localhost:${PORT}`;
const WIN = process.platform === 'win32';
fs.mkdirSync(DATA, { recursive: true });

const line = '==========================================================';
const say = (m) => console.log(m);
const fail = (m) => { console.log(`\n[!] ${m}`); process.exit(1); };
let rl = null;
const ask = (q) => new Promise((res) => { rl = rl || readline.createInterface({ input: process.stdin, output: process.stdout }); rl.question(q, (a) => res(a.trim())); });
const closeAsk = () => { if (rl) { rl.close(); rl = null; } };
const read = (f) => { try { return fs.readFileSync(f, 'utf8').trim(); } catch { return ''; } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function pgBin() {
  if (!WIN) return '';
  const base = 'C:\\Program Files\\PostgreSQL';
  try {
    const v = fs.readdirSync(base).filter((d) => fs.existsSync(path.join(base, d, 'bin', 'pg_dump.exe'))).sort((a, b) => Number(b) - Number(a));
    const pick = v.includes('16') ? '16' : v[0];
    return pick ? path.join(base, pick, 'bin') : '';
  } catch { return ''; }
}
function npm(args, env) {
  const cli = path.join(path.dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js');
  const r = fs.existsSync(cli)
    ? spawnSync(process.execPath, [cli, ...args], { cwd: ROOT, stdio: 'inherit', env: { ...process.env, ...env } })
    : spawnSync(WIN ? 'npm.cmd' : 'npm', args, { cwd: ROOT, stdio: 'inherit', shell: WIN, env: { ...process.env, ...env } });
  return r.status === 0;
}
async function up() { try { const r = await fetch(URL_APP, { signal: AbortSignal.timeout(2000) }); return r.status > 0; } catch { return false; } }
function openBrowser() {
  if (WIN) spawn('cmd', ['/c', 'start', '', URL_APP], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
}

(async () => {
  say(line);
  say('  KAYN Hotel - VERSION DE DEMONSTRATION (donnees fictives)');
  say(`  Base separee "kayn_hotel_demo", port ${PORT} : n'affecte jamais`);
  say("  la base reelle de l'hotel.");
  say(line);

  // déjà en marche ?
  if (await up()) {
    say('La demonstration tourne deja.');
    say(read(path.join(DATA, 'IDENTIFIANTS-DEMO.txt')));
    openBrowser();
    return;
  }

  // 1/4 composants (avant tout : le module pg est nécessaire pour tester la connexion)
  say('\n[1/4] Verification des composants...');
  if (!fs.existsSync(path.join(ROOT, 'node_modules', 'pg'))) { say('Installation des composants (quelques minutes, Internet necessaire)...'); if (!npm(['install', '--no-audit', '--no-fund'])) fail('Echec de npm install.'); }
  if (!fs.existsSync(path.join(SERVER, 'dist', 'index.js')) || !fs.existsSync(path.join(ROOT, 'web', 'dist', 'index.html'))) { say('Compilation...'); if (!npm(['run', 'build'])) fail('Echec de la compilation.'); }
  const pg = require(require.resolve('pg', { paths: [SERVER, ROOT] }));

  // 2/4 PostgreSQL : mot de passe et port mémorisés après la première connexion réussie
  say('\n[2/4] Connexion a PostgreSQL...');
  let pass = read(path.join(DATA, '.demo-pg'));
  let port = read(path.join(DATA, '.demo-pg-port')) || '5433';
  const tryConnect = async (db) => { const c = new pg.Client({ host: 'localhost', port: Number(port), user: 'postgres', password: pass, database: db }); await c.connect(); return c; };
  let client = null;
  for (let attempt = 0; attempt < 3 && !client; attempt++) {
    if (!pass || attempt > 0) {
      pass = await ask('Mot de passe de l\'utilisateur "postgres" (celui choisi a l\'installation de PostgreSQL 16) : ');
      const p = await ask(`Port de PostgreSQL 16 [${port}] : `);
      if (p) port = p;
    }
    try { client = await tryConnect('postgres'); } catch (e) {
      const code = e.code || '';
      if (code === '28P01') say('[!] Mot de passe refuse par PostgreSQL. Reessayez (ce n\'est PAS le mot de passe admin de KAYN Hotel).');
      else if (code === 'ECONNREFUSED') say(`[!] Aucun PostgreSQL sur le port ${port}. Essayez 5433 ou 5432.`);
      else say(`[!] Connexion impossible : ${e.message}`);
    }
  }
  if (!client) fail('Connexion a PostgreSQL impossible apres 3 essais. Si vous avez oublie le mot de passe, demandez la procedure de reinitialisation.');
  closeAsk();
  fs.writeFileSync(path.join(DATA, '.demo-pg'), pass);
  fs.writeFileSync(path.join(DATA, '.demo-pg-port'), port);
  const exists = await client.query("SELECT 1 FROM pg_database WHERE datname = 'kayn_hotel_demo'");
  if (!exists.rowCount) { say('Creation de la base kayn_hotel_demo...'); await client.query('CREATE DATABASE kayn_hotel_demo'); }
  await client.end();
  const DATABASE_URL = `postgres://postgres:${encodeURIComponent(pass)}@localhost:${port}/kayn_hotel_demo`;
  const env = { DATABASE_URL, PORT: String(PORT), PG_BIN: pgBin(), BACKUP_DIR: path.join(DATA, 'backups-demo'), REQUIRE_DEVICE_APPROVAL: 'false' };

  // 3/4 base de démonstration (migrations + données fictives si vide)
  say('\n[3/4] Preparation de la base de demonstration (30 s a 1 min)...');
  if (!npm(['run', 'seed:demo'], env)) fail('Preparation de la base de demonstration impossible.');
  fs.writeFileSync(path.join(DATA, 'demo.env'), Object.entries(env).map(([k, v]) => `${k}=${v}`).join('\n') + '\n');

  // 4/4 serveur en arrière-plan (superviseur) + navigateur
  say('\n[4/4] Demarrage du serveur en arriere-plan (jusqu\'a 1 min)...');
  spawn(process.execPath, [path.join(SERVER, 'lancer.cjs'), '--env', path.join('data', 'demo.env')], { cwd: SERVER, stdio: 'inherit' })
    .on('exit', async () => {
      for (let i = 0; i < 45; i++) { if (await up()) break; await sleep(2000); }
      if (!(await up())) fail('Le serveur ne repond pas : voir server\\data\\logs\\kayn-hotel.log et superviseur.log');
      say('');
      say(read(path.join(DATA, 'IDENTIFIANTS-DEMO.txt')));
      openBrowser();
      say(line);
      say(`  Demonstration en ligne : ${URL_APP}`);
      say('  Vous pouvez FERMER cette fenetre : le serveur continue en');
      say('  arriere-plan et redemarre seul en cas de probleme.');
      say('  Pour l\'arreter : 3-ARRETER.bat');
      say(line);
    });
})().catch((e) => fail(e.message));
