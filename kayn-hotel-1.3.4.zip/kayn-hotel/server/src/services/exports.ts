import ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';

const STATUS: Record<string, string> = {
  pending: 'En attente', confirmed: 'Confirmée', checked_in: 'En séjour', checked_out: 'Terminée', cancelled: 'Annulée', no_show: 'No show',
};
const SOURCE: Record<string, string> = { walk_in: 'Sur place', phone: 'Téléphone', email: 'E-mail', company: 'Société', agency: 'Agence', website: 'Site web', other: 'Autre' };
const MEAL: Record<string, string> = { RO: 'Chambre seule', BB: 'Petit-déjeuner', HB: 'Demi-pension', FB: 'Pension complète' };
const fr = (d: string) => `${d.slice(8, 10)}/${d.slice(5, 7)}/${d.slice(0, 4)}`;
/** Symbole monétaire : celui de l'établissement (Administration → Finances), figé dans chaque facture au moment de l'émission. */
export const currency = { symbol: 'DA', decimals: 2, tz: process.env.HOTEL_TZ ?? 'Africa/Algiers' };
const moneyIn = (n: number, sym = currency.symbol, dec = currency.decimals) => `${(Math.round(n * 100) / 100).toFixed(dec).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} ${sym}`;
const money = (n: number) => moneyIn(n);

export const COLUMNS = [
  { key: 'code', label: 'N°', w: 12 },
  { key: 'guest_name', label: 'Client', w: 26 },
  { key: 'phone', label: 'Téléphone', w: 14 },
  { key: 'room_types', label: 'Type', w: 12 },
  { key: 'rooms', label: 'Chambre(s)', w: 12 },
  { key: 'check_in', label: 'Arrivée', w: 11 },
  { key: 'check_out', label: 'Départ', w: 11 },
  { key: 'nights', label: 'Nuits', w: 6 },
  { key: 'persons', label: 'Pers.', w: 6 },
  { key: 'total', label: 'Total (DA)', w: 13 },
  { key: 'deposits', label: 'Acompte (DA)', w: 13 },
  { key: 'balance', label: 'Reste (DA)', w: 13 },
  { key: 'source', label: 'Source', w: 11 },
  { key: 'status', label: 'Statut', w: 11 },
] as const;

export async function reservationsXlsx(rows: any[], title: string): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'KAYN Hotel';
  const ws = wb.addWorksheet('Réservations', { views: [{ state: 'frozen', ySplit: 2 }] });
  ws.mergeCells(1, 1, 1, COLUMNS.length);
  ws.getCell(1, 1).value = title;
  ws.getCell(1, 1).font = { bold: true, size: 13, color: { argb: 'FF7A1F2B' } };
  ws.getRow(2).values = COLUMNS.map((c) => c.label);
  ws.getRow(2).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getRow(2).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF24252A' } };
  COLUMNS.forEach((c, i) => (ws.getColumn(i + 1).width = c.w));
  for (const r of rows) {
    ws.addRow([
      r.code, r.guest_name, r.phone ?? '', r.room_types ?? '', r.rooms ?? '', new Date(r.check_in + 'T00:00:00Z'), new Date(r.check_out + 'T00:00:00Z'),
      r.nights, r.persons, r.total, r.deposits, r.balance, SOURCE[r.source] ?? r.source, STATUS[r.status] ?? r.status,
    ]);
  }
  [6, 7].forEach((c) => (ws.getColumn(c).numFmt = 'dd/mm/yyyy'));
  [10, 11, 12].forEach((c) => (ws.getColumn(c).numFmt = '#,##0.00'));
  const last = ws.rowCount + 1;
  ws.getCell(last, 1).value = 'TOTAL';
  ws.getCell(last, 1).font = { bold: true };
  [10, 11, 12].forEach((c) => {
    const col = ws.getColumn(c).letter;
    ws.getCell(last, c).value = { formula: `SUM(${col}3:${col}${last - 1})` };
    ws.getCell(last, c).font = { bold: true };
  });
  ws.autoFilter = { from: { row: 2, column: 1 }, to: { row: 2, column: COLUMNS.length } };
  return Buffer.from(await wb.xlsx.writeBuffer());
}

function pdfBuffer(build: (doc: PDFKit.PDFDocument) => void, layout: 'portrait' | 'landscape' = 'portrait'): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', layout, margin: 36, info: { Title: 'KAYN Hotel', Creator: 'KAYN Hotel' } });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
    build(doc);
    doc.end();
  });
}

export function reservationsPdf(rows: any[], title: string, hotel: string): Promise<Buffer> {
  return pdfBuffer((doc) => {
    const cols = [
      { k: 'code', l: 'N°', w: 58 }, { k: 'guest_name', l: 'Client', w: 120 }, { k: 'phone', l: 'Téléphone', w: 70 }, { k: 'rooms', l: 'Ch.', w: 52 },
      { k: 'check_in', l: 'Arrivée', w: 52 }, { k: 'check_out', l: 'Départ', w: 52 }, { k: 'nights', l: 'Nuits', w: 30 }, { k: 'persons', l: 'Pers.', w: 30 },
      { k: 'total', l: 'Total', w: 66 }, { k: 'deposits', l: 'Acompte', w: 62 }, { k: 'balance', l: 'Reste', w: 62 }, { k: 'status', l: 'Statut', w: 60 },
    ];
    const head = () => {
      doc.fillColor('#7A1F2B').font('Helvetica-Bold').fontSize(14).text(`${hotel} — ${title}`, 36, 30);
      doc.fillColor('#555').font('Helvetica').fontSize(8).text(`Édité le ${new Date().toLocaleString('fr-FR', { timeZone: currency.tz })} · ${rows.length} réservation(s)`, 36, 48);
      let x = 36;
      const y = 66;
      doc.rect(36, y - 3, cols.reduce((s, c) => s + c.w, 0), 16).fill('#24252A');
      doc.fillColor('#fff').font('Helvetica-Bold').fontSize(8);
      for (const c of cols) { doc.text(c.l, x + 3, y + 1, { width: c.w - 6 }); x += c.w; }
      return y + 18;
    };
    let y = head();
    doc.font('Helvetica').fontSize(8).fillColor('#111');
    let tot = { total: 0, deposits: 0, balance: 0 };
    rows.forEach((r, i) => {
      if (y > doc.page.height - 50) { doc.addPage(); y = head(); doc.font('Helvetica').fontSize(8).fillColor('#111'); }
      if (i % 2) doc.rect(36, y - 2, cols.reduce((s, c) => s + c.w, 0), 14).fill('#F5F3F1').fillColor('#111');
      let x = 36;
      const v: Record<string, string> = {
        code: r.code, guest_name: r.guest_name, phone: r.phone ?? '', rooms: r.rooms ?? '', check_in: fr(r.check_in), check_out: fr(r.check_out),
        nights: String(r.nights), persons: String(r.persons), total: money(r.total), deposits: money(r.deposits), balance: money(r.balance), status: STATUS[r.status],
      };
      for (const c of cols) { doc.text(v[c.k], x + 3, y, { width: c.w - 6, lineBreak: false, ellipsis: true }); x += c.w; }
      tot = { total: tot.total + r.total, deposits: tot.deposits + r.deposits, balance: tot.balance + r.balance };
      y += 14;
    });
    doc.font('Helvetica-Bold').fontSize(9).text(`Totaux : ${money(tot.total)} · Acomptes : ${money(tot.deposits)} · Reste à encaisser : ${money(tot.balance)}`, 36, y + 8);
  }, 'landscape');
}

export function voucherPdf(r: any, hotel: any, settings: any): Promise<Buffer> {
  return pdfBuffer((doc) => {
    doc.rect(0, 0, doc.page.width, 8).fill('#7A1F2B');
    doc.fillColor('#7A1F2B').font('Helvetica-Bold').fontSize(20).text('BON DE RÉSERVATION', 36, 40);
    doc.fillColor('#C9A227').fontSize(11).text(`Voucher n° ${r.code}`, 36, 66);
    doc.fillColor('#111').font('Helvetica-Bold').fontSize(12).text(hotel.name, 350, 40, { width: 210, align: 'right' });
    doc.font('Helvetica').fontSize(9).fillColor('#444').text([hotel.address, hotel.city].filter(Boolean).join(', ') || ' ', 350, 58, { width: 210, align: 'right' });
    if (hotel.phone) doc.text(hotel.phone, 350, 70, { width: 210, align: 'right' });

    let y = 104;
    const box = (label: string, value: string, x: number, w: number) => {
      doc.fillColor('#777').font('Helvetica').fontSize(8).text(label.toUpperCase(), x, y);
      doc.fillColor('#111').font('Helvetica-Bold').fontSize(11).text(value || '—', x, y + 11, { width: w });
    };
    box('Client', r.guest_name, 36, 260);
    box('Statut', STATUS[r.status], 320, 120);
    box('Type', ({ individual: 'Individuelle', group: 'Groupe', company: 'Entreprise', agency: 'Agence' } as any)[r.booker_type], 450, 110);
    y += 40;
    box('Arrivée', `${fr(r.check_in)} à partir de ${settings.check_in_time}`, 36, 260);
    box('Départ', `${fr(r.check_out)} avant ${settings.check_out_time}`, 320, 240);
    y += 40;
    box('Formule', MEAL[r.meal_plan], 36, 260);
    box('Personnes', `${r.adults} adulte(s)${r.children ? ` · ${r.children} enfant(s)` : ''}`, 320, 240);
    y += 40;
    if (r.payer) { box('Facturé à', r.payer.company_name, 36, 260); y += 40; }

    doc.rect(36, y, 523, 18).fill('#24252A');
    doc.fillColor('#fff').font('Helvetica-Bold').fontSize(9);
    const cols = [['Chambre', 60], ['Type', 90], ['Occupant', 120], ['Du', 60], ['Au', 60], ['Nuits', 40], ['Prix/nuit', 93]] as const;
    let x = 36;
    for (const [l, w] of cols) { doc.text(l, x + 4, y + 5, { width: w - 8 }); x += w; }
    y += 22;
    doc.font('Helvetica').fontSize(9).fillColor('#111');
    for (const rr of r.rooms.filter((x: any) => !['cancelled', 'no_show'].includes(x.status))) {
      x = 36;
      const vals = [rr.room_number, rr.room_type, rr.occupant_name ?? r.guest_name, fr(rr.check_in), fr(rr.check_out), String(rr.nights), money(Number(rr.rate))];
      cols.forEach(([, w], i) => { doc.text(vals[i], x + 4, y, { width: w - 8, lineBreak: false, ellipsis: true }); x += w; });
      y += 16;
    }
    y += 10;
    const line = (l: string, v: string, bold = false) => {
      doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(bold ? 11 : 10).fillColor('#111');
      doc.text(l, 330, y, { width: 130 });
      doc.text(v, 460, y, { width: 99, align: 'right' });
      y += bold ? 18 : 15;
    };
    if (r.discount_total > 0) line('Remise', `- ${money(r.discount_total)}`);
    if (r.tax_total > 0) line('Taxes', money(r.tax_total));
    line('Total du séjour', money(r.total), true);
    line('Acomptes / paiements', money(Number(r.paid) - Number(r.refunded)));
    line('Reste à payer', money(Math.max(0, r.balance)), true);
    if (r.special_requests) {
      y += 10;
      doc.fillColor('#777').font('Helvetica').fontSize(8).text('DEMANDES PARTICULIÈRES', 36, y);
      doc.fillColor('#111').fontSize(10).text(r.special_requests, 36, y + 11, { width: 523 });
    }
    doc.fillColor('#888').fontSize(8).text(`Document émis le ${new Date().toLocaleString('fr-FR', { timeZone: currency.tz })} — à présenter à l'arrivée.`, 36, doc.page.height - 60, { width: 523, align: 'center' });
  });
}

// ===================================================== Tableaux génériques =====================================================
type TCol = { key: string; label: string; money?: boolean };
const cell = (c: TCol, v: any) => (v === null || v === undefined ? '' : c.money ? money(Number(v)) : String(v));

export async function tableXlsx(title: string, subtitle: string, cols: TCol[], rows: any[], total?: Record<string, any> | null): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet(title.slice(0, 30));
  ws.addRow([title]).font = { bold: true, size: 13 };
  ws.addRow([subtitle]);
  ws.addRow([]);
  const h = ws.addRow(cols.map((c) => c.label));
  h.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  h.eachCell((c) => { c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF7A1F2B' } }; });
  for (const r of rows) ws.addRow(cols.map((c) => (c.money ? (r[c.key] === null || r[c.key] === undefined ? null : Number(r[c.key])) : r[c.key] ?? '')));
  if (total) { const t = ws.addRow(cols.map((c) => (c.money ? Number(total[c.key] ?? 0) : total[c.key] ?? ''))); t.font = { bold: true }; }
  cols.forEach((c, i) => { ws.getColumn(i + 1).width = c.money ? 16 : 20; if (c.money) ws.getColumn(i + 1).numFmt = '#,##0.00'; });
  return Buffer.from(await wb.xlsx.writeBuffer());
}

export function tableCsv(cols: TCol[], rows: any[], total?: Record<string, any> | null): string {
  const esc = (v: any) => { const s = v === null || v === undefined ? '' : String(v); return /[";\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const num = (c: TCol, v: any) => (c.money && v !== null && v !== undefined && v !== '' ? Number(v).toFixed(2).replace('.', ',') : v);
  const lines = [cols.map((c) => esc(c.label)).join(';'), ...rows.map((r) => cols.map((c) => esc(num(c, r[c.key]))).join(';'))];
  if (total) lines.push(cols.map((c) => esc(num(c, total[c.key]))).join(';'));
  return '﻿' + lines.join('\r\n');   // BOM : accents corrects dans Excel
}

export function tablePdf(hotel: string, title: string, subtitle: string, cols: TCol[], rows: any[], total?: Record<string, any> | null): Promise<Buffer> {
  return new Promise((resolve) => {
    const doc = new PDFDocument({ size: 'A4', layout: cols.length > 6 ? 'landscape' : 'portrait', margin: 36 });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    const W = doc.page.width - 72;
    const widths = cols.map((c) => (c.money ? 1.1 : 1.4));
    const sw = widths.reduce((a, b) => a + b, 0);
    const xs: number[] = [];
    let acc = 36;
    widths.forEach((w) => { xs.push(acc); acc += (w / sw) * W; });
    const colW = (i: number) => (widths[i] / sw) * W - 4;
    const head = () => {
      doc.fillColor('#7A1F2B').font('Helvetica-Bold').fontSize(14).text(`${hotel} — ${title}`, 36, 30, { width: W });
      doc.fillColor('#555').font('Helvetica').fontSize(8).text(`${subtitle} · édité le ${new Date().toLocaleString('fr-FR', { timeZone: currency.tz })}`, 36, 48);
      doc.rect(36, 62, W, 16).fill('#7A1F2B');
      doc.fillColor('#fff').font('Helvetica-Bold').fontSize(7.5);
      cols.forEach((c, i) => doc.text(c.label, xs[i] + 2, 66, { width: colW(i), align: c.money ? 'right' : 'left', lineBreak: false, ellipsis: true }));
      return 84;
    };
    let y = head();
    const row = (r: any, bold = false) => {
      if (y > doc.page.height - 50) { doc.addPage(); y = head(); }
      doc.fillColor('#111').font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(7.5);
      cols.forEach((c, i) => doc.text(cell(c, r[c.key]), xs[i] + 2, y, { width: colW(i), align: c.money ? 'right' : 'left', lineBreak: false, ellipsis: true }));
      y += 13;
      doc.moveTo(36, y - 3).lineTo(36 + W, y - 3).strokeColor('#e5e5e5').lineWidth(0.5).stroke();
    };
    rows.forEach((r) => row(r));
    if (!rows.length) { doc.fillColor('#777').font('Helvetica').fontSize(9).text('Aucune donnée sur la période.', 36, y); y += 14; }
    if (total) row(total, true);
    doc.end();
  });
}

// ===================================================== Facture PDF =====================================================
const TITLES: Record<string, string> = { invoice: 'FACTURE', proforma: 'FACTURE PRO FORMA', credit_note: 'AVOIR' };
export type DocOpts = { logo?: Buffer | null; paper?: 'A4' | 'thermal'; showFiscal?: boolean; header?: string };
export function invoicePdf(inv: any, opts: DocOpts = {}): Promise<Buffer> {
  if (opts.paper === 'thermal') return invoiceTicket(inv, opts);
  const sym = inv.seller?.currency_symbol ?? 'DA';
  const money = (n: number) => moneyIn(n, sym, 2);
  return new Promise((resolve) => {
    const doc = new PDFDocument({ size: 'A4', margin: 40 });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    const s = inv.seller ?? {};
    const b = inv.bill_to ?? {};
    doc.fillColor('#7A1F2B').font('Helvetica-Bold').fontSize(20).text(TITLES[inv.type] ?? 'FACTURE', 40, 40);
    doc.fillColor('#111').fontSize(11).text(`N° ${inv.number}`, 40, 66);
    doc.font('Helvetica').fontSize(9).fillColor('#444').text(`Date : ${new Date(inv.issued_at).toLocaleDateString('fr-FR', { timeZone: currency.tz })}${inv.due_date ? ` · Échéance : ${fr(String(inv.due_date).slice(0, 10))}` : ''}`, 40, 82);
    if (inv.reservation) doc.text(`Séjour ${inv.reservation.code} du ${fr(inv.reservation.check_in)} au ${fr(inv.reservation.check_out)}`, 40, 95);
    if (inv.original) doc.text(`Avoir sur la facture ${inv.original.number}${inv.reason ? ` — ${inv.reason}` : ''}`, 40, 108);
    let sy = 40;
    if (opts.logo) { try { doc.image(opts.logo, 455, 34, { fit: [100, 44], align: 'right' }); sy = 82; } catch { /* image illisible : ignorée */ } }
    doc.font('Helvetica-Bold').fontSize(11).fillColor('#111').text(s.commercial_name || s.name || '', 300, sy, { width: 255, align: 'right' });
    const fiscal = opts.showFiscal === false ? [] : [s.commercial_name && s.name !== s.commercial_name && s.name, s.nif && `NIF ${s.nif}`, s.nis && `NIS ${s.nis}`, s.rc && `RC ${s.rc}`, s.art && `Art. ${s.art}`];
    doc.font('Helvetica').fontSize(8).fillColor('#444').text([[s.address, s.postal_code, s.city].filter(Boolean).join(', '), s.phone, s.email, s.website, ...fiscal].filter(Boolean).join('\n'), 300, sy + 15, { width: 255, align: 'right' });
    doc.roundedRect(40, 130, 255, 66, 4).strokeColor('#ccc').stroke();
    doc.fillColor('#777').fontSize(8).text('Facturé à', 50, 137);
    doc.fillColor('#111').font('Helvetica-Bold').fontSize(10).text(b.name ?? '', 50, 149, { width: 240 });
    doc.font('Helvetica').fontSize(8).fillColor('#444').text([b.address, b.nif && `NIF ${b.nif}`, b.tax_exempt && `Exonéré de TVA${b.tax_exempt_reason ? ` : ${b.tax_exempt_reason}` : ''}`].filter(Boolean).join('\n'), 50, 163, { width: 240 });
    let y = 215;
    const C = [40, 270, 315, 385, 425, 485];
    doc.rect(40, y, 515, 16).fill('#7A1F2B');
    doc.fillColor('#fff').font('Helvetica-Bold').fontSize(8);
    ['Désignation', 'Qté', 'P.U. HT', 'TVA', 'Remise', 'Total HT'].forEach((h, i) => doc.text(h, C[i] + 3, y + 4, { width: (C[i + 1] ?? 555) - C[i] - 6, align: i === 0 ? 'left' : 'right' }));
    y += 20;
    doc.font('Helvetica').fontSize(8).fillColor('#111');
    for (const it of inv.items) {
      const h = Math.max(12, doc.heightOfString(it.description, { width: 225 }));
      if (y + h > 700) { doc.addPage(); y = 40; }
      doc.text(it.description, C[0] + 3, y, { width: 225 });
      doc.text(String(Number(it.quantity)), C[1], y, { width: 42, align: 'right' });
      doc.text(money(Number(it.unit_price)), C[2], y, { width: 67, align: 'right' });
      doc.text(it.kind === 'tourist_tax' ? '—' : `${Number(it.tax_rate)} %`, C[3], y, { width: 37, align: 'right' });
      doc.text(Number(it.discount) ? money(Number(it.discount)) : '', C[4], y, { width: 57, align: 'right' });
      doc.text(money(Number(it.total)), C[5], y, { width: 67, align: 'right' });
      y += h + 4;
      doc.moveTo(40, y - 2).lineTo(555, y - 2).strokeColor('#eee').stroke();
    }
    y += 8;
    const line = (l: string, v: string, bold = false) => { doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(bold ? 11 : 9).fillColor('#111').text(l, 330, y, { width: 130 }).text(v, 460, y, { width: 95, align: 'right' }); y += bold ? 18 : 14; };
    line('Total HT', money(Number(inv.subtotal)));
    if (Number(inv.discount_total)) line('dont remises', `− ${money(Number(inv.discount_total))}`);
    for (const g of inv.tax_breakdown ?? []) line(`TVA ${Number(g.rate)} % sur ${money(Number(g.base))}`, money(Number(g.tax)));
    if (Number(inv.tourist_tax_total)) line('Taxe de séjour', money(Number(inv.tourist_tax_total)));
    line(inv.type === 'credit_note' ? 'Total de l\'avoir TTC' : 'Total TTC', money(Number(inv.total)), true);
    if (inv.type === 'invoice') {
      line('Payé', money(Number(inv.net_paid ?? 0)));
      if (Number(inv.credited)) line('Avoirs', `− ${money(Number(inv.credited))}`);
    }
    if (inv.notes) { doc.font('Helvetica').fontSize(8).fillColor('#555').text(inv.notes, 40, Math.max(y + 10, 720), { width: 515, height: 40, ellipsis: true }); }
    if (inv.type === 'proforma') doc.font('Helvetica-Bold').fontSize(9).fillColor('#7A1F2B').text('Document sans valeur comptable — ne constitue pas une facture.', 40, 770, { width: 515, align: 'center' });
    doc.end();
  });
}

/** Ticket thermique 80 mm (caisse) : même contenu essentiel, une colonne. */
function invoiceTicket(inv: any, opts: DocOpts): Promise<Buffer> {
  const sym = inv.seller?.currency_symbol ?? 'DA';
  const money = (n: number) => moneyIn(n, sym, 2);
  const W = 226, M = 10, CW = W - 2 * M;
  const s = inv.seller ?? {};
  // hauteur estimée selon le nombre de lignes
  const H = 250 + (inv.items?.length ?? 0) * 26 + (inv.tax_breakdown?.length ?? 0) * 12 + (opts.logo ? 60 : 0) + (inv.notes ? 40 : 0);
  return new Promise((resolve) => {
    const doc = new PDFDocument({ size: [W, H], margins: { top: 10, bottom: 0, left: M, right: M } });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    let y = 10;
    if (opts.logo) { try { doc.image(opts.logo, (W - 80) / 2, y, { fit: [80, 50], align: 'center' }); y += 56; } catch { /* */ } }
    const c = (t: string, size = 8, bold = false) => { doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(size).fillColor('#000').text(t, M, y, { width: CW, align: 'center' }); y = doc.y + 2; };
    c(s.commercial_name || s.name || '', 10, true);
    if (opts.header) c(opts.header, 7);
    c([s.address, s.city].filter(Boolean).join(', '), 7);
    if (s.phone) c(s.phone, 7);
    if (opts.showFiscal !== false) c([s.nif && `NIF ${s.nif}`, s.rc && `RC ${s.rc}`].filter(Boolean).join(' · '), 6);
    y += 4; c(`${TITLES[inv.type] ?? 'FACTURE'} N° ${inv.number}`, 9, true);
    c(new Date(inv.issued_at).toLocaleString('fr-FR', { timeZone: currency.tz }), 7);
    if (inv.bill_to?.name) c(inv.bill_to.name, 7);
    const sep = () => { doc.moveTo(M, y).lineTo(W - M, y).dash(2, { space: 2 }).strokeColor('#000').stroke().undash(); y += 5; };
    sep();
    doc.fontSize(7.5);
    for (const it of inv.items ?? []) {
      doc.font('Helvetica').text(it.description, M, y, { width: CW }); y = doc.y;
      doc.text(`${Number(it.quantity)} × ${money(Number(it.unit_price))}${it.kind === 'tourist_tax' ? '' : ` · TVA ${Number(it.tax_rate)} %`}`, M, y, { width: CW - 70 });
      doc.font('Helvetica-Bold').text(money(Number(it.total)), W - M - 70, y, { width: 70, align: 'right' }); y = doc.y + 3;
    }
    sep();
    const l = (a: string, b: string, bold = false) => { doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(bold ? 9 : 7.5).text(a, M, y, { width: CW - 80 }); doc.text(b, W - M - 80, y, { width: 80, align: 'right' }); y = doc.y + 2; };
    l('Total HT', money(Number(inv.subtotal)));
    for (const g of inv.tax_breakdown ?? []) l(`TVA ${Number(g.rate)} %`, money(Number(g.tax)));
    if (Number(inv.tourist_tax_total)) l('Taxe de séjour', money(Number(inv.tourist_tax_total)));
    l('TOTAL TTC', money(Number(inv.total)), true);
    if (inv.type === 'invoice') l('Payé', money(Number(inv.net_paid ?? 0)));
    if (inv.notes) { y += 4; doc.font('Helvetica').fontSize(6.5).text(inv.notes, M, y, { width: CW, align: 'center' }); y = doc.y; }
    y += 6; c('Merci de votre visite', 7);
    doc.end();
  });
}
