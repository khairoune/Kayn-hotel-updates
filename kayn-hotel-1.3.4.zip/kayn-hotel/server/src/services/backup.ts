import { fileURLToPath } from 'node:url';
/**
 * Sauvegarde & restauration de la base complète (toutes les tables, schéma + données) avec les outils officiels PostgreSQL
 * (pg_dump / pg_restore, format personnalisé compressé). Fonctionne hors ligne.
 *
 * Fichiers : <BACKUP_DIR>/<nom>.dump + fiche <nom>.json (empreinte SHA-256, version, nombre de lignes par table).
 * Le dossier est la source de vérité : l'index en base est resynchronisé après chaque restauration.
 *
 * Restauration : 1) vérification du fichier (empreinte, lisibilité, contenu) 2) compatibilité (mêmes migrations)
 * 3) sauvegarde de sécurité de l'état actuel 4) confirmation explicite (route) 5) restauration en UNE transaction
 * (en cas d'échec, la base reste inchangée) 6) contrôle d'intégrité (lignes par table, migrations).
 */
import { spawn } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { createReadStream, existsSync, mkdirSync, readdirSync, readFileSync, renameSync, statSync, unlinkSync, writeFileSync, appendFileSync } from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { closePool, getPool, one, q } from '../db/pool.js';
import { maintenance } from '../lib/auth.js';
import { AppError, badRequest, notFound } from '../lib/errors.js';
import { getSettings } from './common.js';
import { notify } from './notify.js';

export const backupDir = () => {
  const d = process.env.BACKUP_DIR ?? fileURLToPath(new URL('../../data/backups', import.meta.url));
  if (!existsSync(d)) mkdirSync(d, { recursive: true });
  return d;
};
const APP_VERSION = (() => { try { return JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8')).version ?? '0'; } catch { return '0'; } })();

/** Recherche des outils PostgreSQL : PG_BIN, PATH, emplacements usuels Linux / Windows. */
export function pgTool(name: 'pg_dump' | 'pg_restore'): string | null {
  const exe = process.platform === 'win32' ? `${name}.exe` : name;
  const dirs = [process.env.PG_BIN, ...(process.env.PATH ?? '').split(path.delimiter)].filter(Boolean) as string[];
  for (const base of ['/usr/lib/postgresql', 'C:\\Program Files\\PostgreSQL']) {
    try { for (const v of readdirSync(base).sort().reverse()) dirs.push(path.join(base, v, 'bin')); } catch { /* absent */ }
  }
  for (const d of dirs) { const p = path.join(d, exe); if (existsSync(p)) return p; }
  return null;
}
function run(bin: string, args: string[], timeoutMs = 30 * 60_000): Promise<{ code: number; out: string; err: string }> {
  return new Promise((resolve) => {
    const p = spawn(bin, args, { env: { ...process.env, PGCONNECT_TIMEOUT: '10' } });
    let out = '', err = '';
    p.stdout.on('data', (d) => { out += d; if (out.length > 50_000_000) p.kill(); });
    p.stderr.on('data', (d) => { err += d; });
    const t = setTimeout(() => p.kill('SIGKILL'), timeoutMs);
    p.on('close', (code) => { clearTimeout(t); resolve({ code: code ?? 1, out, err }); });
    p.on('error', (e) => { clearTimeout(t); resolve({ code: 1, out, err: String(e) }); });
  });
}
const sha256File = (f: string) => new Promise<string>((resolve, reject) => { const h = createHash('sha256'); createReadStream(f).on('data', (d) => h.update(d)).on('end', () => resolve(h.digest('hex'))).on('error', reject); });
/** Le mot de passe éventuel de l'URL n'apparaît jamais dans un message d'erreur. */
const clean = (s: string) => s.replace(/postgres(ql)?:\/\/[^@\s]*@/g, 'postgres://***@').slice(0, 1500);
const stamp = () => new Date().toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 15);

async function tableCounts(): Promise<Record<string, number>> {
  const tabs = await q<any>(getPool(), `SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY 1`);
  const out: Record<string, number> = {};
  for (const t of tabs) out[t.tablename] = Number((await one<any>(getPool(), `SELECT count(*)::bigint AS n FROM "${t.tablename.replace(/"/g, '')}"`)).n);
  return out;
}
const lastMigration = async () => (await one<any>(getPool(), 'SELECT max(name) AS m FROM schema_migrations'))?.m ?? null;
const knownMigrations = () => readdirSync(new URL('../db/migrations', import.meta.url)).filter((f) => f.endsWith('.sql')).sort();

type Meta = { file: string; kind: string; sha256: string; size: number; app_version: string; last_migration: string | null; migrations: string[]; tables: Record<string, number> | null; created_at: string; created_by_name: string | null; note: string | null };
const metaPath = (file: string) => path.join(backupDir(), file.replace(/\.dump$/, '.json'));
const readMeta = (file: string): Meta | null => { try { return JSON.parse(readFileSync(metaPath(file), 'utf8')); } catch { return null; } };

/** Liste des migrations contenues dans un fichier de sauvegarde (lecture directe des données sauvegardées). */
async function dumpMigrations(file: string): Promise<string[] | null> {
  const bin = pgTool('pg_restore');
  if (!bin) return null;
  const r = await run(bin, ['--data-only', '--table=schema_migrations', '--file=-', file], 120_000);
  if (r.code !== 0) return null;
  const lines = r.out.split('\n');
  const i = lines.findIndex((l) => l.startsWith('COPY public.schema_migrations'));
  if (i < 0) return null;
  const out: string[] = [];
  for (let j = i + 1; j < lines.length && lines[j] !== '\\.'; j++) out.push(lines[j].split('\t')[0]);
  return out.sort();
}

/** Vérification d'un fichier : présence, empreinte, lisibilité par pg_restore, présence des données, compatibilité. */
export async function verifyFile(file: string): Promise<{ ok: boolean; compatible: boolean; detail: string[]; migrations: string[]; sha256?: string }> {
  const detail: string[] = [];
  const full = path.join(backupDir(), path.basename(file));
  if (!existsSync(full)) return { ok: false, compatible: false, detail: ['Fichier introuvable dans le dossier des sauvegardes.'], migrations: [] };
  const meta = readMeta(path.basename(file));
  const sha = await sha256File(full);
  if (meta?.sha256 && meta.sha256 !== sha) return { ok: false, compatible: false, detail: ['Empreinte SHA-256 différente : le fichier a été modifié ou est corrompu.'], migrations: [], sha256: sha };
  detail.push(meta?.sha256 ? 'Empreinte SHA-256 conforme.' : 'Empreinte calculée (aucune fiche d\'origine).');
  const bin = pgTool('pg_restore');
  if (!bin) return { ok: false, compatible: false, detail: [...detail, 'Outil pg_restore introuvable (installez les outils clients PostgreSQL ou renseignez PG_BIN).'], migrations: [], sha256: sha };
  const list = await run(bin, ['--list', full], 120_000);
  if (list.code !== 0) return { ok: false, compatible: false, detail: [...detail, `Fichier illisible : ${clean(list.err)}`], migrations: [], sha256: sha };
  const dataTables = new Set([...list.out.matchAll(/TABLE DATA public (\S+)/g)].map((m) => m[1]));
  for (const must of ['users', 'roles', 'hotels', 'reservations', 'invoices', 'payments', 'schema_migrations']) if (!dataTables.has(must)) return { ok: false, compatible: false, detail: [...detail, `Données de la table « ${must} » absentes : sauvegarde incomplète.`], migrations: [], sha256: sha };
  if (meta?.tables) {
    const missing = Object.keys(meta.tables).filter((t) => !dataTables.has(t));
    if (missing.length) return { ok: false, compatible: false, detail: [...detail, `Tables manquantes : ${missing.join(', ')}`], migrations: [], sha256: sha };
  }
  detail.push(`Contenu lisible : ${dataTables.size} tables avec leurs données.`);
  const migs = (await dumpMigrations(full)) ?? [];
  const known = knownMigrations();
  const compatible = migs.length > 0 && migs.length === known.length && migs.every((m, i) => m === known[i]);
  detail.push(compatible ? `Compatible avec cette version (${migs.length} migrations, dernière ${migs[migs.length - 1]}).`
    : `Incompatible : la sauvegarde contient ${migs.length} migrations (dernière ${migs[migs.length - 1] ?? '—'}) alors que l'application en compte ${known.length} (dernière ${known[known.length - 1]}). Restaurez-la avec la même version de KAYN Hotel.`);
  return { ok: true, compatible, detail, migrations: migs, sha256: sha };
}

/** Crée une sauvegarde complète ; elle n'est déclarée « réussie » qu'après création ET vérification du fichier. */
export async function createBackup(kind: 'manual' | 'auto' | 'pre_restore', by: { id: number | null; name: string | null; hotelId: number | null }, note: string | null = null) {
  const dir = backupDir();
  const file = `kayn-hotel-${stamp()}-${kind}${kind === 'manual' ? `-${randomUUID().slice(0, 4)}` : ''}.dump`;
  const full = path.join(dir, file);
  const pool = getPool();
  await pool.query(`INSERT INTO backups (file_name, kind, status, created_by, created_by_name, note, app_version) VALUES ($1,$2,'creating',$3,$4,$5,$6)`, [file, kind, by.id, by.name, note, APP_VERSION]);
  const fail = async (msg: string) => {
    try { if (existsSync(`${full}.tmp`)) unlinkSync(`${full}.tmp`); } catch { /* */ }
    await pool.query(`UPDATE backups SET status = 'failed', error = $2 WHERE file_name = $1`, [file, msg]);
    if (by.hotelId) await notify(pool, by.hotelId, 'backup', { title: 'Échec de la sauvegarde', body: msg.slice(0, 200), link: '/admin?s=backups', severity: 'danger', dedupe: file }).catch(() => {});
    throw new AppError(500, 'backup_failed', `Sauvegarde échouée : ${msg}`);
  };
  const bin = pgTool('pg_dump');
  if (!bin) return fail('outil pg_dump introuvable (installez les outils clients PostgreSQL ou renseignez PG_BIN).');
  const tables = await tableCounts();
  const last = await lastMigration();
  const r = await run(bin, ['--format=custom', '--compress=6', '--no-owner', '--no-privileges', `--dbname=${config.databaseUrl}`, `--file=${full}.tmp`]);
  if (r.code !== 0) return fail(clean(r.err) || 'pg_dump a échoué');
  renameSync(`${full}.tmp`, full);
  const size = statSync(full).size;
  const sha = await sha256File(full);
  const meta: Meta = { file, kind, sha256: sha, size, app_version: APP_VERSION, last_migration: last, migrations: knownMigrations(), tables, created_at: new Date().toISOString(), created_by_name: by.name, note };
  writeFileSync(metaPath(file), JSON.stringify(meta, null, 1));
  const v = await verifyFile(file);
  if (!v.ok) { try { unlinkSync(full); unlinkSync(metaPath(file)); } catch { /* */ } return fail(`fichier créé mais non vérifié : ${v.detail.join(' ')}`); }
  const rows = Object.values(tables).reduce((s, n) => s + n, 0);
  await pool.query(`UPDATE backups SET status = 'ok', size_bytes = $2, sha256 = $3, last_migration = $4, tables_count = $5, rows_count = $6, verified_at = now(), verify_ok = true, verify_detail = $7 WHERE file_name = $1`,
    [file, size, sha, last, Object.keys(tables).length, rows, v.detail.join(' ')]);
  return one<any>(pool, 'SELECT * FROM backups WHERE file_name = $1', [file]);
}

/** Resynchronise l'index (table backups / restores) à partir du dossier. */
export async function syncRegistry() {
  const dir = backupDir();
  const pool = getPool();
  const files = new Set(readdirSync(dir).filter((f) => f.endsWith('.dump')));
  for (const f of files) {
    const m = readMeta(f);
    const st = statSync(path.join(dir, f));
    await pool.query(`INSERT INTO backups (file_name, kind, status, size_bytes, sha256, app_version, last_migration, tables_count, rows_count, created_by_name, note, created_at)
       VALUES ($1,$2,'ok',$3,$4,$5,$6,$7,$8,$9,$10,$11) ON CONFLICT (file_name) DO UPDATE SET size_bytes = EXCLUDED.size_bytes, status = CASE WHEN backups.status IN ('missing','creating') THEN 'ok' ELSE backups.status END`,
      [f, m?.kind ?? 'uploaded', st.size, m?.sha256 ?? null, m?.app_version ?? null, m?.last_migration ?? null, m?.tables ? Object.keys(m.tables).length : null,
        m?.tables ? Object.values(m.tables).reduce((s, n) => s + n, 0) : null, m?.created_by_name ?? null, m?.note ?? null, m?.created_at ?? st.mtime]);
  }
  for (const r of await q<any>(pool, `SELECT file_name FROM backups WHERE status = 'ok'`)) if (!files.has(r.file_name)) await pool.query(`UPDATE backups SET status = 'missing' WHERE file_name = $1`, [r.file_name]);
  const log = path.join(dir, 'restores.log');
  if (existsSync(log)) {
    for (const line of readFileSync(log, 'utf8').split('\n').filter(Boolean)) {
      try {
        const x = JSON.parse(line);
        await pool.query(`INSERT INTO restores (uid, file_name, safety_file, status, detail, started_at, finished_at, by_name) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
           ON CONFLICT (uid) DO UPDATE SET status = EXCLUDED.status, detail = EXCLUDED.detail, finished_at = EXCLUDED.finished_at`,
          [x.uid, x.file, x.safety ?? null, x.status, x.detail ?? null, x.started_at, x.finished_at ?? null, x.by ?? null]);
      } catch { /* ligne illisible ignorée */ }
    }
  }
}
const logRestore = (x: any) => appendFileSync(path.join(backupDir(), 'restores.log'), `${JSON.stringify(x)}\n`);

let restoring = false;
/** Restauration complète (étapes décrites en tête de fichier). La route a déjà vérifié la permission et la confirmation explicite. */
export async function restoreBackup(file: string, by: { id: number; name: string; hotelId: number }) {
  if (restoring) throw new AppError(409, 'in_progress', 'Une restauration est déjà en cours.');
  file = path.basename(file);
  const v = await verifyFile(file);
  if (!v.ok) throw badRequest(`Fichier refusé : ${v.detail.join(' ')}`);
  if (!v.compatible) throw new AppError(409, 'incompatible', v.detail[v.detail.length - 1]);
  const bin = pgTool('pg_restore');
  if (!bin) throw new AppError(500, 'no_tool', 'Outil pg_restore introuvable.');
  restoring = true;
  const uid = randomUUID();
  const started = new Date().toISOString();
  let safety: any = null;
  try {
    safety = await createBackup('pre_restore', { id: by.id, name: by.name, hotelId: by.hotelId }, `Avant restauration de ${file}`);
    logRestore({ uid, file, safety: safety.file_name, status: 'running', started_at: started, by: by.name });
    const expected = readMeta(file)?.tables ?? null;
    // suspension de l'application : plus aucune requête, connexions fermées
    maintenance.on = true; maintenance.reason = 'Restauration d\'une sauvegarde en cours';
    await new Promise((r) => setTimeout(r, 300));
    await closePool();
    const r = await run(bin, ['--clean', '--if-exists', '--single-transaction', '--exit-on-error', '--no-owner', '--no-privileges', `--dbname=${config.databaseUrl}`, path.join(backupDir(), file)]);
    if (r.code !== 0) throw new AppError(500, 'restore_failed', `Restauration annulée, la base actuelle est inchangée : ${clean(r.err)}`);
    // contrôle d'intégrité des données restaurées
    const problems: string[] = [];
    if (expected) {
      const now = await tableCounts();
      for (const [t, n] of Object.entries(expected)) if (['backups', 'restores', 'sessions', 'idempotency_keys'].includes(t) ? false : now[t] !== n) problems.push(`${t} : ${now[t] ?? 'absente'} ligne(s) au lieu de ${n}`);
    }
    if ((await lastMigration()) !== v.migrations[v.migrations.length - 1]) problems.push('Version du schéma inattendue après restauration.');
    const detail = problems.length ? `Restaurée avec écarts : ${problems.join(' ; ')}` : `Restauration vérifiée : ${expected ? Object.keys(expected).length : '?'} tables conformes. Sauvegarde de sécurité : ${safety.file_name}.`;
    logRestore({ uid, file, safety: safety.file_name, status: problems.length ? 'failed' : 'ok', detail, started_at: started, finished_at: new Date().toISOString(), by: by.name });
    maintenance.on = false;
    await syncRegistry();
    await getPool().query(`INSERT INTO audit_logs (hotel_id, action, entity, entity_id, after, result) VALUES ($1,'backup_restore','backup',$2,$3,$4)`,
      [by.hotelId, file, JSON.stringify({ by: by.name, safety: safety.file_name, detail }), problems.length ? 'failure' : 'success']).catch(() => {});
    return { ok: !problems.length, detail, safety: safety.file_name };
  } catch (e: any) {
    const msg = e?.message ?? String(e);
    logRestore({ uid, file, safety: safety?.file_name ?? null, status: 'failed', detail: msg, started_at: started, finished_at: new Date().toISOString(), by: by.name });
    maintenance.on = false;
    await syncRegistry().catch(() => {});
    await getPool().query(`INSERT INTO audit_logs (hotel_id, user_id, action, entity, entity_id, after, result) VALUES ($1,$2,'backup_restore','backup',$3,$4,'failure')`, [by.hotelId, by.id, file, JSON.stringify({ error: msg })]).catch(() => {});
    throw e instanceof AppError ? e : new AppError(500, 'restore_failed', msg);
  } finally {
    maintenance.on = false;
    restoring = false;
  }
}

/**
 * Restauration d'ESSAI (non destructive) : la sauvegarde est restaurée dans une base temporaire distincte,
 * le contenu est comparé table par table à la fiche de la sauvegarde, les relations sont contrôlées, puis la base temporaire est supprimée.
 * La base de production n'est jamais touchée.
 */
export async function testRestore(file: string) {
  file = path.basename(file);
  const v = await verifyFile(file);
  if (!v.ok) throw badRequest(`Fichier refusé : ${v.detail.join(' ')}`);
  const bin = pgTool('pg_restore');
  if (!bin) throw new AppError(500, 'no_tool', 'Outil pg_restore introuvable.');
  const tmp = `kayn_restore_test_${Date.now()}`;
  const u = new URL(config.databaseUrl);
  const tmpUrl = (() => { const x = new URL(config.databaseUrl); x.pathname = `/${tmp}`; return x.toString(); })();
  const steps: string[] = [];
  await getPool().query(`CREATE DATABASE "${tmp}"`).catch((e) => { throw new AppError(500, 'test_restore', `Impossible de créer la base d'essai (droit CREATEDB requis pour l'utilisateur ${decodeURIComponent(u.username)}) : ${e.message}`); });
  const pg = (await import('pg')).default;
  const c = new pg.Client({ connectionString: tmpUrl });
  try {
    const t0 = Date.now();
    const r = await run(bin, ['--no-owner', '--no-privileges', '--exit-on-error', '--single-transaction', `--dbname=${tmpUrl}`, path.join(backupDir(), file)]);
    if (r.code !== 0) throw new AppError(500, 'test_restore', `Restauration d'essai échouée : ${clean(r.err)}`);
    steps.push(`Restaurée dans une base temporaire en ${((Date.now() - t0) / 1000).toFixed(1)} s.`);
    await c.connect();
    const meta = readMeta(file);
    const tabs = (await c.query(`SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY 1`)).rows.map((x: any) => x.tablename);
    const counts: Record<string, number> = {};
    for (const t of tabs) counts[t] = Number((await c.query(`SELECT count(*)::bigint AS n FROM "${t.replace(/"/g, '')}"`)).rows[0].n);
    const diff = meta?.tables ? Object.entries(meta.tables).filter(([t, n]) => counts[t] !== n).map(([t, n]) => `${t} ${counts[t] ?? 'absente'}/${n}`) : [];
    steps.push(diff.length ? `Écarts de contenu : ${diff.join(', ')}` : `${tabs.length} tables, ${Object.values(counts).reduce((a, b) => a + b, 0)} lignes : contenu identique à la fiche.`);
    const fk = Number((await c.query(`SELECT count(*)::int AS n FROM pg_constraint WHERE contype = 'f' AND NOT convalidated`)).rows[0].n);
    const fkTotal = Number((await c.query(`SELECT count(*)::int AS n FROM pg_constraint WHERE contype = 'f'`)).rows[0].n);
    steps.push(fk ? `${fk} relation(s) non validée(s).` : `${fkTotal} relations entre tables vérifiées par PostgreSQL.`);
    const mig = (await c.query('SELECT max(name) AS m FROM schema_migrations')).rows[0].m;
    steps.push(`Version du schéma : ${mig}.`);
    const fin = (await c.query(`SELECT count(*)::int AS n FROM invoices i WHERE abs(i.total - (i.subtotal + i.tax_total)) > 0.01`)).rows[0].n;
    steps.push(Number(fin) ? `${fin} facture(s) aux totaux incohérents.` : 'Montants des factures cohérents (TTC = HT + taxes).');
    const ok = !diff.length && !fk && !Number(fin);
    return { ok, file, steps };
  } finally {
    await c.end().catch(() => {});
    await getPool().query(`DROP DATABASE IF EXISTS "${tmp}" WITH (FORCE)`).catch(() => {});
  }
}

/** Enregistre un fichier importé (déjà écrit sur disque par la route), après vérification ; refusé et supprimé sinon. */
export async function importUpload(tmpPath: string, originalName: string, by: { id: number; name: string }) {
  const file = `kayn-hotel-${stamp()}-uploaded-${originalName.replace(/[^A-Za-z0-9._-]/g, '_').replace(/\.dump$/i, '').slice(0, 40)}.dump`;
  const full = path.join(backupDir(), file);
  renameSync(tmpPath, full);
  const v = await verifyFile(file);
  if (!v.ok) { unlinkSync(full); throw badRequest(`Fichier refusé : ${v.detail.join(' ')}`); }
  const meta: Meta = { file, kind: 'uploaded', sha256: v.sha256!, size: statSync(full).size, app_version: '?', last_migration: v.migrations[v.migrations.length - 1] ?? null, migrations: v.migrations, tables: null, created_at: new Date().toISOString(), created_by_name: by.name, note: `Importée : ${originalName}` };
  writeFileSync(metaPath(file), JSON.stringify(meta, null, 1));
  await syncRegistry();
  await getPool().query(`UPDATE backups SET verified_at = now(), verify_ok = true, verify_detail = $2, created_by = $3 WHERE file_name = $1`, [file, v.detail.join(' '), by.id]);
  return { file, verify: v };
}
export function backupPath(file: string) {
  const f = path.join(backupDir(), path.basename(file));
  if (!f.endsWith('.dump') || !existsSync(f)) throw notFound('Sauvegarde introuvable');
  return f;
}
export function deleteBackupFiles(file: string) {
  const f = backupPath(file);
  unlinkSync(f);
  try { unlinkSync(metaPath(path.basename(file))); } catch { /* */ }
}

/** Sauvegarde automatique si elle est due (planificateur) + rotation des anciennes sauvegardes automatiques. */
export async function autoBackupIfDue(hotelId: number) {
  const cfg = (await getSettings(getPool(), hotelId)).backups;
  if (!cfg?.enabled) return null;
  const tz = (await one<any>(getPool(), 'SELECT timezone FROM hotels WHERE id = $1', [hotelId]))?.timezone ?? config.timezone;
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', weekday: 'short', hour12: false }).formatToParts(new Date()).map((p) => [p.type, p.value]));
  const hm = `${parts.hour}:${parts.minute}`;
  const wd = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(parts.weekday);
  if (hm < cfg.time) return null;
  if (cfg.frequency === 'weekly' && wd !== Number(cfg.weekday)) return null;
  if (cfg.frequency === 'monthly' && Number(parts.day) !== Number(cfg.monthday)) return null;
  const day = `${parts.year}-${parts.month}-${parts.day}`;
  const done = await one<any>(getPool(), `SELECT 1 FROM backups WHERE kind = 'auto' AND status IN ('ok','creating') AND (created_at AT TIME ZONE $1)::date = $2`, [tz, day]);
  if (done) return null;
  const b = await createBackup('auto', { id: null, name: 'Planificateur', hotelId }, `Sauvegarde automatique (${cfg.frequency})`).catch(() => null);
  // rotation : seules les N dernières sauvegardes automatiques réussies sont conservées
  const old = await q<any>(getPool(), `SELECT file_name FROM backups WHERE kind = 'auto' AND status = 'ok' ORDER BY created_at DESC OFFSET $1`, [Math.max(1, Number(cfg.keep) || 14)]);
  for (const o of old) { try { deleteBackupFiles(o.file_name); } catch { /* */ } await getPool().query(`DELETE FROM backups WHERE file_name = $1`, [o.file_name]); }
  return b;
}
