/**
 * Housekeeping : statuts de propreté (machine d'états), tâches (auto / manuelles), affectation, planning du personnel,
 * inspection avec checklist, « Ne pas déranger », mini-bar, linge et blanchisserie, objets trouvés, rapports.
 */
import type { PoolClient } from 'pg';
import { one, q, type Db } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { addDays, today } from '../lib/dates.js';
import { AppError, badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { getSettings, guestDisplayName, nextNumber } from './common.js';

export type Hk = 'dirty' | 'to_clean' | 'cleaning' | 'to_inspect' | 'clean' | 'inspected';
export const HK_LABEL: Record<string, string> = {
  dirty: 'Sale', to_clean: 'À nettoyer', cleaning: 'En cours de nettoyage', to_inspect: 'À inspecter', clean: 'Nettoyée', inspected: 'Propre et disponible',
};
export const TASK_LABEL: Record<string, string> = {
  checkout_clean: 'Ménage départ', stayover: 'Recouche', arrival_prep: 'Préparation arrivée', deep_clean: 'Grand ménage', inspection: 'Contrôle', turndown: 'Couverture', other: 'Remise en état',
};
export const READY: Hk[] = ['clean', 'inspected'];
const OPEN_TASK = ['todo', 'in_progress', 'to_inspect'];
const PRIO = ['low', 'normal', 'high', 'urgent'];

/** Transitions autorisées sans droit de superviseur (le superviseur peut forcer, avec trace). */
const ALLOWED: Record<Hk, Hk[]> = {
  dirty: ['to_clean', 'cleaning'],
  to_clean: ['cleaning', 'dirty'],
  cleaning: ['to_inspect', 'clean', 'to_clean'],
  to_inspect: ['inspected', 'to_clean'],
  clean: ['inspected', 'to_inspect', 'dirty', 'to_clean'],
  inspected: ['dirty', 'to_clean'],
};

async function hkSettings(db: Db, hotelId: number) {
  const s = await getSettings(db as any, hotelId);
  return s.housekeeping as { inspection_required: boolean; stayover_daily: boolean; min_score: number; minutes: Record<string, number> };
}
const atTime = (d: string, hhmm: string) => `${d}T${hhmm.length === 5 ? hhmm : '12:00'}:00`;

async function lockRoomHk(db: PoolClient, hotelId: number, roomId: number) {
  const r = await one<any>(db, `SELECT r.*, EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL) AS occupied
                                  FROM rooms r WHERE r.id = $1 AND r.hotel_id = $2 FOR UPDATE OF r`, [roomId, hotelId]);
  if (!r) throw notFound('Chambre introuvable');
  return r;
}

/** Change l'état de propreté d'une chambre (avec contrôle de cohérence et historique). */
export async function setHk(db: PoolClient, actor: Actor, roomId: number, to: Hk, opts: { force?: boolean; reason?: string | null; room?: any } = {}) {
  const r = opts.room ?? (await lockRoomHk(db, actor.hotelId, roomId));
  const from = r.hk_status as Hk;
  if (from === to) return;
  if (!opts.force && !(ALLOWED[from] ?? []).includes(to)) {
    throw conflict(`Changement incohérent : « ${HK_LABEL[from]} » → « ${HK_LABEL[to]} ».`, { from, to });
  }
  await db.query('UPDATE rooms SET hk_status = $2, hk_updated_at = now(), updated_at = now() WHERE id = $1', [roomId, to]);
  r.hk_status = to;
  await audit(db, actor, 'housekeeping', 'room', roomId, { hk_status: from }, { hk_status: to, forced: !!opts.force, reason: opts.reason ?? null });
}

// =====================================================================================================
// Tâches
// =====================================================================================================
async function arrivalToday(db: Db, roomId: number, d: string) {
  return one<any>(db, `SELECT rr.id FROM reservation_rooms rr WHERE rr.room_id = $1 AND rr.status IN ('pending','confirmed') AND rr.check_in = $2 LIMIT 1`, [roomId, d]);
}

/** Crée une tâche si aucune tâche ouverte n'existe déjà pour la chambre (pas de doublon). */
export async function ensureTask(db: PoolClient, actor: Actor, roomId: number, kind: string, o: { rrId?: number | null; date?: string; priority?: string; due_at?: string | null; source?: 'auto' | 'manual'; notes?: string | null } = {}) {
  const d = o.date ?? today();
  const open = await one<any>(db, `SELECT * FROM housekeeping_tasks WHERE room_id = $1 AND status = ANY($2::text[]) ORDER BY id LIMIT 1`, [roomId, OPEN_TASK]);
  const s = await getSettings(db, actor.hotelId);
  const arr = await arrivalToday(db, roomId, d);
  const priority = o.priority ?? (arr ? 'high' : 'normal');
  const due = o.due_at ?? (arr ? atTime(d, s.check_in_time ?? '14:00') : null);
  if (open) {
    // tâche existante : priorité relevée si une arrivée est prévue
    if (PRIO.indexOf(priority) > PRIO.indexOf(open.priority)) await db.query('UPDATE housekeeping_tasks SET priority = $2, due_at = COALESCE($3, due_at) WHERE id = $1', [open.id, priority, due]);
    return open;
  }
  return one<any>(db,
    `INSERT INTO housekeeping_tasks (room_id, reservation_room_id, kind, status, created_by, task_date, priority, due_at, source, notes)
     VALUES ($1,$2,$3,'todo',$4,$5,$6,$7,$8,$9) RETURNING *`,
    [roomId, o.rrId ?? null, kind, actor.userId, d, priority, due, o.source ?? 'auto', o.notes ?? null]);
}

/** Départ, changement de chambre, fin de blocage : la chambre devient « À nettoyer » + tâche. Recouche : « Sale » + tâche. */
export async function roomVacated(db: PoolClient, actor: Actor, roomId: number, rrId: number | null, kind: 'checkout_clean' | 'stayover') {
  const r = await lockRoomHk(db, actor.hotelId, roomId);
  if (kind === 'checkout_clean') {
    await db.query('UPDATE rooms SET dnd = false, dnd_set_at = NULL, dnd_set_by = NULL WHERE id = $1', [roomId]);
    await setHk(db, actor, roomId, 'to_clean', { force: true, room: r, reason: 'Départ' });
  } else if (READY.includes(r.hk_status)) {
    await setHk(db, actor, roomId, 'dirty', { force: true, room: r, reason: 'Recouche' });
  }
  return ensureTask(db, actor, roomId, kind, { rrId });
}

/** Génération automatique des tâches du jour (départs, recouches, arrivées). Idempotente. */
export async function generateTasks(db: PoolClient, actor: Actor, d = today()) {
  const s = await hkSettings(db, actor.hotelId);
  const out = { departures: 0, stayovers: 0, arrivals: 0, pending: 0 };
  // chambres déjà à nettoyer sans tâche
  for (const r of await q<any>(db, `SELECT r.id, r.hk_status, EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL) AS occ FROM rooms r
      WHERE r.hotel_id = $1 AND r.active AND r.hk_status IN ('dirty','to_clean')
        AND NOT EXISTS (SELECT 1 FROM housekeeping_tasks t WHERE t.room_id = r.id AND t.status = ANY($2::text[]))`, [actor.hotelId, OPEN_TASK])) {
    await ensureTask(db, actor, r.id, r.occ ? 'stayover' : 'checkout_clean', { date: d }); out.pending++;
  }
  // départs prévus du jour (client encore présent) : tâche planifiée, démarrable après le départ
  for (const x of await q<any>(db, `SELECT s.room_id, rr.id AS rr_id FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN rooms r ON r.id = s.room_id
      WHERE r.hotel_id = $1 AND s.checked_out_at IS NULL AND rr.check_out <= $2`, [actor.hotelId, d])) {
    const t = await one(db, `SELECT 1 FROM housekeeping_tasks WHERE room_id = $1 AND status = ANY($2::text[])`, [x.room_id, OPEN_TASK]);
    if (!t) { await ensureTask(db, actor, x.room_id, 'checkout_clean', { rrId: x.rr_id, date: d }); out.departures++; }
  }
  // recouches : chambres occupées qui ne partent pas
  if (s.stayover_daily) {
    for (const x of await q<any>(db, `SELECT s.room_id, rr.id AS rr_id, r.dnd FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN rooms r ON r.id = s.room_id
        WHERE r.hotel_id = $1 AND s.checked_out_at IS NULL AND rr.check_out > $2 AND rr.check_in < $2
          AND NOT EXISTS (SELECT 1 FROM housekeeping_tasks t WHERE t.room_id = s.room_id AND t.kind = 'stayover' AND t.task_date = $2)`, [actor.hotelId, d])) {
      const t = await one(db, `SELECT 1 FROM housekeeping_tasks WHERE room_id = $1 AND status = ANY($2::text[])`, [x.room_id, OPEN_TASK]);
      if (!t) { await ensureTask(db, actor, x.room_id, 'stayover', { rrId: x.rr_id, date: d, priority: 'low' }); out.stayovers++; }
    }
  }
  // arrivées : chambre pas prête → priorité haute avant l'heure d'arrivée ; nettoyée mais non inspectée → contrôle
  const set = await getSettings(db, actor.hotelId);
  for (const x of await q<any>(db, `SELECT rr.room_id, rr.id AS rr_id, r.hk_status FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id
      WHERE r.hotel_id = $1 AND rr.check_in = $2 AND rr.status IN ('pending','confirmed')`, [actor.hotelId, d])) {
    const open = await one<any>(db, `SELECT id FROM housekeeping_tasks WHERE room_id = $1 AND status = ANY($2::text[])`, [x.room_id, OPEN_TASK]);
    if (open) { await db.query(`UPDATE housekeeping_tasks SET priority = CASE WHEN priority IN ('low','normal') THEN 'high' ELSE priority END, due_at = COALESCE(due_at, $2) WHERE id = $1`, [open.id, atTime(d, set.check_in_time ?? '14:00')]); out.arrivals++; continue; }
    if (x.hk_status === 'clean' && s.inspection_required) {
      // contrôle avant arrivée : la chambre reste vendable (Nettoyée), le contrôle est proposé en priorité
      await ensureTask(db, actor, x.room_id, 'inspection', { rrId: x.rr_id, date: d, priority: 'high' });
      await db.query(`UPDATE housekeeping_tasks SET status = 'to_inspect' WHERE room_id = $1 AND kind = 'inspection' AND status = 'todo'`, [x.room_id]);
      out.arrivals++;
    } else if (!READY.includes(x.hk_status)) {
      await ensureTask(db, actor, x.room_id, 'arrival_prep', { rrId: x.rr_id, date: d, priority: 'high' }); out.arrivals++;
    }
  }
  await audit(db, actor, 'generate_tasks', 'housekeeping', null, null, { date: d, ...out });
  return out;
}

export async function createTask(db: PoolClient, actor: Actor, b: { room_id: number; kind: string; priority?: string; due_at?: string | null; employee_id?: number | null; notes?: string | null; task_date?: string | null }) {
  const r = await lockRoomHk(db, actor.hotelId, b.room_id);
  const open = await one<any>(db, `SELECT id FROM housekeeping_tasks WHERE room_id = $1 AND status = ANY($2::text[])`, [r.id, OPEN_TASK]);
  if (open) throw conflict(`Une tâche est déjà ouverte pour la chambre ${r.number}.`);
  const t = await one<any>(db,
    `INSERT INTO housekeeping_tasks (room_id, kind, status, created_by, task_date, priority, due_at, source, notes) VALUES ($1,$2,'todo',$3,$4,$5,$6,'manual',$7) RETURNING *`,
    [r.id, b.kind, actor.userId, b.task_date ?? today(), b.priority ?? 'normal', b.due_at ?? null, b.notes ?? null]);
  if (b.kind !== 'inspection' && b.kind !== 'turndown' && READY.includes(r.hk_status) && !r.occupied) await setHk(db, actor, r.id, 'to_clean', { force: true, room: r, reason: 'Tâche manuelle' });
  if (b.employee_id) await assignTask(db, actor, t.id, b.employee_id);
  await audit(db, actor, 'create', 'hk_task', t.id, null, { room: r.number, kind: b.kind, priority: t.priority });
  return t;
}

async function loadTask(db: PoolClient, actor: Actor, id: number) {
  const t = await one<any>(db, `SELECT t.*, r.hotel_id, r.number AS room_number FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id WHERE t.id = $1 FOR UPDATE OF t`, [id]);
  if (!t || t.hotel_id !== actor.hotelId) throw notFound('Tâche introuvable');
  return t;
}
async function employeeOf(db: Db, userId: number) {
  return (await one<any>(db, 'SELECT employee_id FROM users WHERE id = $1', [userId]))?.employee_id ?? null;
}
/** Une femme de chambre n'agit que sur ses tâches (ou une tâche non affectée) ; le superviseur sur toutes. */
async function canWork(db: Db, actor: Actor, perms: Set<string>, t: any) {
  if (perms.has('housekeeping.manage')) return;
  const emp = await employeeOf(db, actor.userId);
  if (t.assigned_to && t.assigned_to !== emp) throw forbidden('Tâche affectée à une autre personne.');
}

export async function assignTask(db: PoolClient, actor: Actor, taskId: number, employeeId: number | null) {
  const t = await loadTask(db, actor, taskId);
  if (!OPEN_TASK.includes(t.status) || t.status === 'to_inspect') throw conflict('Tâche terminée : réaffectation impossible.');
  if (employeeId) {
    const e = await one<any>(db, 'SELECT id, active FROM employees WHERE id = $1 AND hotel_id = $2', [employeeId, actor.hotelId]);
    if (!e || !e.active) throw badRequest('Employé introuvable ou inactif.');
  }
  await db.query('UPDATE housekeeping_tasks SET assigned_to = $2, assigned_at = now(), assigned_by = $3 WHERE id = $1', [taskId, employeeId, actor.userId]);
  await audit(db, actor, 'assign', 'hk_task', taskId, { assigned_to: t.assigned_to }, { assigned_to: employeeId });
}

/** Répartition automatique des tâches non affectées : par étage, charge en minutes la plus faible, plafond de chambres. */
export async function autoAssign(db: PoolClient, actor: Actor, d = today()) {
  const s = await hkSettings(db, actor.hotelId);
  let staff = await q<any>(db, `SELECT e.id, e.max_rooms FROM employees e JOIN hk_shifts sh ON sh.employee_id = e.id AND sh.work_date = $2 WHERE e.hotel_id = $1 AND e.active AND e.department = 'housekeeping'`, [actor.hotelId, d]);
  if (!staff.length) staff = await q<any>(db, `SELECT id, max_rooms FROM employees WHERE hotel_id = $1 AND active AND department = 'housekeeping'`, [actor.hotelId]);
  if (!staff.length) throw conflict('Aucun employé du ménage : ajoutez le personnel dans le planning.');
  const load = new Map<number, { minutes: number; rooms: number; floors: Set<number>; max: number }>();
  for (const e of staff) load.set(e.id, { minutes: 0, rooms: 0, floors: new Set(), max: e.max_rooms });
  for (const t of await q<any>(db, `SELECT t.assigned_to, t.kind, f.number AS floor FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id JOIN floors f ON f.id = r.floor_id
      WHERE r.hotel_id = $1 AND t.task_date = $2 AND t.status <> 'cancelled' AND t.assigned_to IS NOT NULL`, [actor.hotelId, d])) {
    const l = load.get(t.assigned_to); if (!l) continue;
    l.minutes += s.minutes[t.kind] ?? 30; l.rooms++; l.floors.add(t.floor);
  }
  const tasks = await q<any>(db, `SELECT t.id, t.kind, t.priority, f.number AS floor FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id JOIN floors f ON f.id = r.floor_id
      WHERE r.hotel_id = $1 AND t.task_date <= $2 AND t.status = 'todo' AND t.assigned_to IS NULL
      ORDER BY array_position(ARRAY['urgent','high','normal','low'], t.priority), f.number, length(r.number), r.number`, [actor.hotelId, d]);
  let n = 0;
  for (const t of tasks) {
    const m = s.minutes[t.kind] ?? 30;
    const cands = [...load.entries()].filter(([, l]) => l.rooms < l.max);
    if (!cands.length) break;
    // même étage d'abord (moins de déplacements), puis la charge la plus faible
    cands.sort((a, b) => Number(b[1].floors.has(t.floor)) - Number(a[1].floors.has(t.floor)) || a[1].minutes - b[1].minutes);
    const best = cands.find(([, l]) => l.floors.has(t.floor) && l.minutes <= Math.min(...cands.map(([, x]) => x.minutes)) + 60) ?? cands.sort((a, b) => a[1].minutes - b[1].minutes)[0];
    await db.query('UPDATE housekeeping_tasks SET assigned_to = $2, assigned_at = now(), assigned_by = $3 WHERE id = $1', [t.id, best[0], actor.userId]);
    best[1].minutes += m; best[1].rooms++; best[1].floors.add(t.floor); n++;
  }
  await audit(db, actor, 'auto_assign', 'housekeeping', null, null, { date: d, assigned: n });
  return { assigned: n, unassigned: tasks.length - n };
}

export async function startTask(db: PoolClient, actor: Actor, perms: Set<string>, id: number) {
  const t = await loadTask(db, actor, id);
  await canWork(db, actor, perms, t);
  if (t.status !== 'todo') throw conflict(t.status === 'in_progress' ? 'Tâche déjà commencée.' : 'Cette tâche ne peut pas être commencée.');
  if (t.kind === 'inspection') throw conflict('Un contrôle se fait depuis l\'écran Inspection.');
  const r = await lockRoomHk(db, actor.hotelId, t.room_id);
  if (r.dnd) throw conflict(`Chambre ${r.number} : « Ne pas déranger ».`);
  if (t.kind === 'checkout_clean' && r.occupied) throw conflict(`Chambre ${r.number} : client encore présent (départ non enregistré).`);
  await db.query(`UPDATE housekeeping_tasks SET status = 'in_progress', started_at = now(), assigned_to = COALESCE(assigned_to, $2) WHERE id = $1`, [id, await employeeOf(db, actor.userId)]);
  await setHk(db, actor, r.id, 'cleaning', { force: !(ALLOWED[r.hk_status as Hk] ?? []).includes('cleaning'), room: r, reason: TASK_LABEL[t.kind] });
  return { ok: true };
}

export async function finishTask(db: PoolClient, actor: Actor, perms: Set<string>, id: number, note?: string | null) {
  const t = await loadTask(db, actor, id);
  await canWork(db, actor, perms, t);
  if (t.status !== 'in_progress') throw conflict('Commencez la tâche avant de la terminer.');
  const s = await hkSettings(db, actor.hotelId);
  const r = await lockRoomHk(db, actor.hotelId, t.room_id);
  const needInspect = s.inspection_required && t.kind !== 'turndown';
  await db.query(`UPDATE housekeeping_tasks SET status = $2, completed_at = now(), completed_by = $3, notes = COALESCE($4, notes) WHERE id = $1`,
    [id, needInspect ? 'to_inspect' : 'done', actor.userId, note ?? null]);
  await setHk(db, actor, r.id, needInspect ? 'to_inspect' : 'clean', { room: r, reason: `${TASK_LABEL[t.kind]} terminé` });
  return { status: needInspect ? 'to_inspect' : 'done' };
}

export async function cancelTask(db: PoolClient, actor: Actor, id: number, reason: string) {
  const t = await loadTask(db, actor, id);
  if (!OPEN_TASK.includes(t.status)) throw conflict('Tâche déjà clôturée.');
  if (!reason?.trim()) throw badRequest('Motif obligatoire.');
  await db.query(`UPDATE housekeeping_tasks SET status = 'cancelled', cancel_reason = $2 WHERE id = $1`, [id, reason.trim()]);
  const r = await lockRoomHk(db, actor.hotelId, t.room_id);
  if (r.hk_status === 'cleaning') await setHk(db, actor, r.id, 'to_clean', { room: r, reason: 'Tâche annulée' });
  await audit(db, actor, 'cancel', 'hk_task', id, { status: t.status }, { status: 'cancelled', reason });
}

// =====================================================================================================
// Inspection
// =====================================================================================================
export async function inspect(db: PoolClient, actor: Actor, b: { room_id: number; decision: 'pass' | 'fail'; items: { item_id: number; ok: boolean; comment?: string | null }[]; remarks?: string | null; create_ticket?: boolean }) {
  const r = await lockRoomHk(db, actor.hotelId, b.room_id);
  const t = await one<any>(db, `SELECT * FROM housekeeping_tasks WHERE room_id = $1 AND status = 'to_inspect' ORDER BY id DESC LIMIT 1 FOR UPDATE`, [r.id]);
  if (!t && !['to_inspect', 'clean'].includes(r.hk_status)) throw conflict(`Chambre ${r.number} : rien à inspecter (${HK_LABEL[r.hk_status]}).`);
  if (t && t.completed_by === actor.userId) throw forbidden('Le contrôle doit être fait par une autre personne que celle qui a nettoyé.');
  const s = await hkSettings(db, actor.hotelId);
  const list = await q<any>(db, 'SELECT * FROM hk_checklist_items WHERE hotel_id = $1 AND active ORDER BY sort_order, id', [actor.hotelId]);
  const byId = new Map(b.items.map((i) => [i.item_id, i]));
  const items = list.map((c) => ({ item_id: c.id, label: c.label, category: c.category, critical: c.critical, ok: byId.get(c.id)?.ok ?? false, comment: byId.get(c.id)?.comment ?? null }));
  if (list.length && b.items.length < list.length) throw badRequest('Checklist incomplète : chaque point doit être coché conforme ou non conforme.');
  const score = items.length ? Math.round((items.filter((i) => i.ok).length * 100) / items.length) : 100;
  const criticalKo = items.filter((i) => i.critical && !i.ok);
  if (b.decision === 'pass' && (criticalKo.length || score < s.min_score)) {
    throw new AppError(409, 'inspection_fail', criticalKo.length ? `Point critique non conforme : ${criticalKo.map((i) => i.label).join(', ')}. La chambre doit être refusée.` : `Score ${score} % inférieur au minimum (${s.min_score} %).`, { score });
  }
  if (b.decision === 'fail' && !b.remarks?.trim() && items.every((i) => i.ok)) throw badRequest('Indiquez la raison du refus.');
  const ins = await one<any>(db, `INSERT INTO hk_inspections (task_id, room_id, inspector_id, result, score, items, remarks) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [t?.id ?? null, r.id, actor.userId, b.decision === 'pass' ? 'passed' : 'failed', score, JSON.stringify(items), b.remarks?.trim() || null]);
  if (b.decision === 'pass') {
    if (t) await db.query(`UPDATE housekeeping_tasks SET status = 'validated', inspected_by = $2, inspected_at = now() WHERE id = $1`, [t.id, actor.userId]);
    await setHk(db, actor, r.id, 'inspected', { force: r.hk_status === 'clean', room: r, reason: `Inspection validée (${score} %)` });
  } else {
    // refus : la chambre retourne automatiquement « À nettoyer », la tâche est rouverte en priorité haute
    if (t) await db.query(`UPDATE housekeeping_tasks SET status = 'todo', refusal_count = refusal_count + 1, priority = CASE WHEN priority IN ('low','normal') THEN 'high' ELSE priority END,
                             started_at = NULL, completed_at = NULL, inspected_by = $2, inspected_at = now() WHERE id = $1`, [t.id, actor.userId]);
    else await ensureTask(db, actor, r.id, 'other', { priority: 'high', notes: 'Refusée à l\'inspection' });
    await setHk(db, actor, r.id, 'to_clean', { force: true, room: r, reason: 'Inspection refusée' });
    const ko = items.filter((i) => !i.ok).map((i) => i.label).join(', ');
    if (t) await db.query(`INSERT INTO hk_task_comments (task_id, kind, text, created_by) VALUES ($1,'status',$2,$3)`, [t.id, `Refusée à l'inspection (${score} %) : ${[ko, b.remarks].filter(Boolean).join(' — ')}`, actor.userId]);
  }
  if (b.create_ticket && b.remarks?.trim()) {
    await db.query(`INSERT INTO maintenance_tickets (room_id, title, description, priority, reported_by, category, source) VALUES ($1,$2,$3,'normal',$4,'other','inspection')`,
      [r.id, `Anomalie inspection ch. ${r.number}`, b.remarks.trim(), actor.userId]);
  }
  await audit(db, actor, 'inspect', 'room', r.id, null, { result: ins.result, score, inspection_id: ins.id });
  return ins;
}

// =====================================================================================================
// Commentaires, problèmes, mini-bar, « Ne pas déranger »
// =====================================================================================================
export async function comment(db: PoolClient, actor: Actor, perms: Set<string>, taskId: number, b: { kind: 'comment' | 'issue'; text: string; priority?: string }) {
  const t = await loadTask(db, actor, taskId);
  await canWork(db, actor, perms, t);
  if (!b.text?.trim()) throw badRequest('Texte obligatoire.');
  let ticketId: number | null = null;
  if (b.kind === 'issue') {
    ticketId = (await one<any>(db, `INSERT INTO maintenance_tickets (room_id, title, description, priority, reported_by, category, source) VALUES ($1,$2,$3,$4,$5,'other','housekeeping') RETURNING id`,
      [t.room_id, `Signalé par le ménage — ch. ${t.room_number}`, b.text.trim(), b.priority ?? 'normal', actor.userId])).id;
  }
  return one<any>(db, `INSERT INTO hk_task_comments (task_id, kind, text, ticket_id, created_by) VALUES ($1,$2,$3,$4,$5) RETURNING *`, [taskId, b.kind, b.text.trim(), ticketId, actor.userId]);
}

/** Consommations mini-bar relevées pendant le ménage → ajoutées au folio du client (Facturation). */
export async function minibar(db: PoolClient, actor: Actor, taskId: number, lines: { service_id: number; quantity: number }[]) {
  const t = await loadTask(db, actor, taskId);
  const stay = await one<any>(db,
    `SELECT rr.id AS rr_id, rr.reservation_id FROM reservation_rooms rr LEFT JOIN stays s ON s.reservation_room_id = rr.id
      WHERE rr.room_id = $1 AND (s.checked_out_at IS NULL AND s.id IS NOT NULL) LIMIT 1`, [t.room_id]);
  if (!stay) throw conflict('Aucun client en séjour dans cette chambre : signalez la consommation à la réception.');
  const { addCharge } = await import('./frontoffice.js');
  const out = [];
  for (const l of lines) {
    if (!(l.quantity > 0)) continue;
    const c = await addCharge(db, actor, { reservation_id: stay.reservation_id, reservation_room_id: stay.rr_id, service_id: l.service_id, quantity: l.quantity });
    await db.query(`INSERT INTO hk_task_comments (task_id, kind, text, charge_id, created_by) VALUES ($1,'minibar',$2,$3,$4)`, [taskId, `${c.description} × ${l.quantity}`, c.id, actor.userId]);
    out.push(c);
  }
  if (!out.length) throw badRequest('Aucune consommation saisie.');
  return out;
}

export async function setDnd(db: PoolClient, actor: Actor, roomId: number, on: boolean) {
  const r = await lockRoomHk(db, actor.hotelId, roomId);
  if (on && !r.occupied) throw conflict('« Ne pas déranger » : seulement pour une chambre occupée.');
  await db.query('UPDATE rooms SET dnd = $2, dnd_set_at = CASE WHEN $2 THEN now() END, dnd_set_by = CASE WHEN $2 THEN $3::int END WHERE id = $1', [roomId, on, actor.userId]);
  await audit(db, actor, on ? 'dnd_on' : 'dnd_off', 'room', roomId, { dnd: r.dnd }, { dnd: on });
}

// =====================================================================================================
// Tableau de bord, tâches, personnel
// =====================================================================================================
export async function board(db: Db, hotelId: number, d = today()) {
  const rooms = await q<any>(db,
    `SELECT r.id, r.number, r.hk_status, r.dnd, r.out_of_service, r.hk_updated_at, f.number AS floor, f.name AS floor_name, t.name AS type_name,
            EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL) AS occupied,
            EXISTS (SELECT 1 FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id WHERE s.room_id = r.id AND s.checked_out_at IS NULL AND rr.check_out <= $2) AS departure,
            (SELECT json_build_object('rr_id', rr.id, 'guest', COALESCE(g.company_name, trim(coalesce(g.last_name,'') || ' ' || coalesce(g.first_name,''))))
               FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id JOIN guests g ON g.id = COALESCE(rr.guest_id, res.guest_id)
              WHERE rr.room_id = r.id AND rr.status IN ('pending','confirmed') AND rr.check_in = $2 LIMIT 1) AS arrival,
            (SELECT row_to_json(x) FROM (SELECT ht.id, ht.kind, ht.status, ht.priority, ht.due_at, ht.assigned_to, ht.refusal_count, e.first_name || ' ' || e.last_name AS assignee
               FROM housekeeping_tasks ht LEFT JOIN employees e ON e.id = ht.assigned_to WHERE ht.room_id = r.id AND ht.status IN ('todo','in_progress','to_inspect') ORDER BY ht.id LIMIT 1) x) AS task
       FROM rooms r JOIN floors f ON f.id = r.floor_id JOIN room_types t ON t.id = r.room_type_id
      WHERE r.hotel_id = $1 AND r.active ORDER BY f.number, length(r.number), r.number`, [hotelId, d]);
  const tasks = await one<any>(db,
    `SELECT count(*) FILTER (WHERE t.status <> 'cancelled')::int AS total,
            count(*) FILTER (WHERE t.status IN ('done','validated'))::int AS finished,
            count(*) FILTER (WHERE t.status = 'to_inspect')::int AS to_inspect,
            count(*) FILTER (WHERE t.status = 'in_progress')::int AS in_progress,
            count(*) FILTER (WHERE t.status = 'todo')::int AS todo,
            count(*) FILTER (WHERE t.status IN ('todo','in_progress') AND t.due_at < now())::int AS late,
            count(*) FILTER (WHERE t.status IN ('todo','in_progress') AND t.assigned_to IS NULL)::int AS unassigned
       FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id WHERE r.hotel_id = $1 AND (t.task_date = $2 OR (t.task_date < $2 AND t.status IN ('todo','in_progress','to_inspect')))`, [hotelId, d]);
  const c = (fn: (r: any) => boolean) => rooms.filter(fn).length;
  return {
    date: d,
    kpi: {
      to_clean: c((r) => ['dirty', 'to_clean'].includes(r.hk_status) && !r.out_of_service), dirty: c((r) => r.hk_status === 'dirty'), cleaning: c((r) => r.hk_status === 'cleaning'),
      to_inspect: c((r) => r.hk_status === 'to_inspect'), clean: c((r) => READY.includes(r.hk_status)), inspected: c((r) => r.hk_status === 'inspected'),
      occupied: c((r) => r.occupied), dnd: c((r) => r.dnd), out_of_service: c((r) => r.out_of_service), total: rooms.length,
      progress: tasks.total ? Math.round((tasks.finished * 100) / tasks.total) : 100, tasks,
    },
    rooms: rooms.map((r) => ({ ...r, display: r.out_of_service ? 'out_of_service' : r.dnd ? 'dnd' : r.hk_status })),
  };
}

export async function listTasks(db: Db, hotelId: number, f: { date?: string; status?: string; employee_id?: number | null; mine_user?: number | null; unassigned?: boolean }) {
  const d = f.date ?? today();
  const emp = f.mine_user ? await employeeOf(db, f.mine_user) : null;
  if (f.mine_user && !emp) return [];
  return q<any>(db,
    `SELECT t.*, r.number AS room_number, r.hk_status, r.dnd, f.number AS floor, rt.name AS room_type,
            e.first_name || ' ' || e.last_name AS assignee, u.full_name AS completed_by_name, ui.full_name AS inspected_by_name,
            EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL) AS occupied,
            (SELECT count(*) FROM hk_task_comments c WHERE c.task_id = t.id)::int AS comments,
            (t.status IN ('todo','in_progress') AND t.due_at < now()) AS late
       FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id JOIN floors f ON f.id = r.floor_id JOIN room_types rt ON rt.id = r.room_type_id
       LEFT JOIN employees e ON e.id = t.assigned_to LEFT JOIN users u ON u.id = t.completed_by LEFT JOIN users ui ON ui.id = t.inspected_by
      WHERE r.hotel_id = $1 AND (t.task_date = $2 OR (t.task_date < $2 AND t.status IN ('todo','in_progress','to_inspect')))
        AND ($3::text IS NULL OR t.status = $3) AND ($4::int IS NULL OR t.assigned_to = $4) AND (NOT $5 OR t.assigned_to IS NULL)
      ORDER BY array_position(ARRAY['in_progress','todo','to_inspect','done','validated','cancelled'], t.status),
               array_position(ARRAY['urgent','high','normal','low'], t.priority), t.due_at NULLS LAST, f.number, length(r.number), r.number`,
    [hotelId, d, f.status ?? null, emp ?? f.employee_id ?? null, !!f.unassigned]);
}

export async function staffDay(db: Db, hotelId: number, d = today()) {
  const s = await hkSettings(db, hotelId);
  const emps = await q<any>(db,
    `SELECT e.*, sh.id AS shift_id, sh.start_time, sh.end_time, sh.started_at, sh.ended_at, sh.zone, u.username
       FROM employees e LEFT JOIN hk_shifts sh ON sh.employee_id = e.id AND sh.work_date = $2 LEFT JOIN users u ON u.employee_id = e.id
      WHERE e.hotel_id = $1 AND e.department = 'housekeeping' ORDER BY e.active DESC, e.last_name`, [hotelId, d]);
  const tasks = await q<any>(db,
    `SELECT t.id, t.assigned_to, t.kind, t.status, t.priority, r.number AS room, t.started_at, t.completed_at FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id
      WHERE r.hotel_id = $1 AND t.assigned_to IS NOT NULL AND t.status <> 'cancelled' AND (t.task_date = $2 OR (t.task_date < $2 AND t.status IN ('todo','in_progress','to_inspect')))
      ORDER BY length(r.number), r.number`, [hotelId, d]);
  return emps.map((e) => {
    const mine = tasks.filter((t) => t.assigned_to === e.id);
    const done = mine.filter((t) => ['done', 'validated', 'to_inspect'].includes(t.status)).length;
    return {
      ...e, tasks: mine, rooms: mine.length, done, progress: mine.length ? Math.round((done * 100) / mine.length) : 0,
      planned_minutes: mine.reduce((a, t) => a + (s.minutes[t.kind] ?? 30), 0),
      first_start: mine.map((t) => t.started_at).filter(Boolean).sort()[0] ?? null,
      last_end: mine.map((t) => t.completed_at).filter(Boolean).sort().reverse()[0] ?? null,
    };
  });
}

// =====================================================================================================
// Linge
// =====================================================================================================
const MOVES: Record<string, Partial<Record<'qty_clean' | 'qty_in_use' | 'qty_dirty' | 'qty_laundry', 1 | -1>>> = {
  purchase: { qty_clean: 1 }, issue: { qty_clean: -1, qty_in_use: 1 }, collect: { qty_in_use: -1, qty_dirty: 1 },
  send_laundry: { qty_dirty: -1, qty_laundry: 1 }, return_laundry: { qty_laundry: -1, qty_clean: 1 },
};
export async function linenMove(db: PoolClient, actor: Actor, b: { item_id: number; kind: string; quantity: number; room_id?: number | null; reason?: string | null; from?: 'clean' | 'dirty' | 'in_use' | 'laundry'; batch_id?: number | null }) {
  const it = await one<any>(db, 'SELECT * FROM linen_items WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [b.item_id, actor.hotelId]);
  if (!it) throw notFound('Article de linge introuvable');
  const qn = Math.trunc(b.quantity);
  if (!qn || (b.kind !== 'adjust' && qn < 0)) throw badRequest('Quantité invalide.');
  let delta: Record<string, number> = {};
  if (b.kind === 'discard') {
    if (!b.reason?.trim()) throw badRequest('Motif obligatoire (usure, tache, perte…).');
    delta[`qty_${b.from ?? 'dirty'}`] = -qn;
  } else if (b.kind === 'adjust') {
    if (!b.reason?.trim()) throw badRequest('Motif obligatoire pour un ajustement d\'inventaire.');
    delta[`qty_${b.from ?? 'clean'}`] = qn;
  } else {
    const m = MOVES[b.kind];
    if (!m) throw badRequest('Mouvement inconnu.');
    for (const [k, sgn] of Object.entries(m)) delta[k] = (sgn as number) * qn;
  }
  for (const [k, v] of Object.entries(delta)) {
    if (Number(it[k]) + v < 0) throw conflict(`Stock insuffisant pour « ${it.name} » (${k.replace('qty_', '').replace('in_use', 'en chambres').replace('clean', 'propre').replace('dirty', 'sale').replace('laundry', 'en blanchisserie')} : ${it[k]}).`);
  }
  const sets = Object.entries(delta).map(([k, v]) => `${k} = ${k} + ${Number(v)}`).join(', ');
  await db.query(`UPDATE linen_items SET ${sets} WHERE id = $1`, [it.id]);
  return one<any>(db, `INSERT INTO linen_movements (item_id, kind, quantity, batch_id, room_id, reason, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [it.id, b.kind, b.kind === 'discard' ? -qn : qn, b.batch_id ?? null, b.room_id ?? null, b.reason?.trim() || null, actor.userId]);
}

export async function sendLaundry(db: PoolClient, actor: Actor, b: { provider?: string | null; lines: { item_id: number; quantity: number }[]; notes?: string | null }) {
  if (!b.lines.some((l) => l.quantity > 0)) throw badRequest('Aucun article à envoyer.');
  const n = await nextNumber(db, `bl-${today().slice(0, 4)}`);
  const batch = await one<any>(db, `INSERT INTO linen_batches (hotel_id, ref, provider, sent_by, notes) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [actor.hotelId, `BL${today().slice(0, 4)}-${String(n).padStart(4, '0')}`, b.provider ?? null, actor.userId, b.notes ?? null]);
  for (const l of b.lines) if (l.quantity > 0) await linenMove(db, actor, { item_id: l.item_id, kind: 'send_laundry', quantity: l.quantity, batch_id: batch.id });
  await audit(db, actor, 'send', 'linen_batch', batch.id, null, { ref: batch.ref, lines: b.lines });
  return batch;
}

export async function batchDetail(db: Db, hotelId: number, id: number) {
  const b = await one<any>(db, 'SELECT * FROM linen_batches WHERE id = $1 AND hotel_id = $2', [id, hotelId]);
  if (!b) throw notFound('Lot introuvable');
  const lines = await q<any>(db, `SELECT i.id AS item_id, i.name, COALESCE(sum(m.quantity) FILTER (WHERE m.kind = 'send_laundry'), 0)::int AS sent,
      COALESCE(sum(m.quantity) FILTER (WHERE m.kind = 'return_laundry'), 0)::int AS returned, COALESCE(-sum(m.quantity) FILTER (WHERE m.kind = 'discard'), 0)::int AS missing
     FROM linen_movements m JOIN linen_items i ON i.id = m.item_id WHERE m.batch_id = $1 GROUP BY i.id ORDER BY i.name`, [id]);
  return { ...b, lines: lines.map((l) => ({ ...l, pending: l.sent - l.returned - l.missing })) };
}

/** Retour de blanchisserie : linge propre réintégré ; à la clôture, le manquant est sorti du stock et le coût enregistré en dépense. */
export async function returnLaundry(db: PoolClient, actor: Actor, id: number, b: { lines: { item_id: number; quantity: number }[]; close?: boolean; cost?: number | null; method?: 'cash' | 'card' | 'cheque' | 'transfer' }) {
  const batch = await one<any>(db, 'SELECT * FROM linen_batches WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!batch) throw notFound('Lot introuvable');
  if (batch.status === 'returned') throw conflict('Lot déjà clôturé.');
  const d = await batchDetail(db, actor.hotelId, id);
  for (const l of b.lines) {
    if (!(l.quantity > 0)) continue;
    const line = d.lines.find((x: any) => x.item_id === l.item_id);
    if (!line || l.quantity > line.pending) throw badRequest(`Retour supérieur à l'envoi pour un article (${line?.name ?? l.item_id}).`);
    await linenMove(db, actor, { item_id: l.item_id, kind: 'return_laundry', quantity: l.quantity, batch_id: id });
  }
  const after = await batchDetail(db, actor.hotelId, id);
  const pending = after.lines.reduce((a: number, l: any) => a + l.pending, 0);
  let status = pending > 0 ? 'partial' : 'returned';
  if (b.close && pending > 0) {
    for (const l of after.lines.filter((x: any) => x.pending > 0)) {
      await db.query('UPDATE linen_items SET qty_laundry = qty_laundry - $2 WHERE id = $1', [l.item_id, l.pending]);
      await db.query(`INSERT INTO linen_movements (item_id, kind, quantity, batch_id, reason, created_by) VALUES ($1,'discard',$2,$3,'Manquant au retour de blanchisserie',$4)`, [l.item_id, -l.pending, id, actor.userId]);
    }
    status = 'returned';
  }
  let expenseId: number | null = null;
  if (b.cost && b.cost > 0) {
    const { addExpense } = await import('./cash.js');
    expenseId = (await addExpense(db, actor, { category: 'Blanchisserie externe', description: `Lot ${batch.ref}${batch.provider ? ` — ${batch.provider}` : ''}`, amount: b.cost, method: b.method ?? 'transfer', supplier: batch.provider, reference: batch.ref })).id;
  }
  await db.query(`UPDATE linen_batches SET status = $2, returned_at = CASE WHEN $2 = 'returned' THEN now() ELSE returned_at END, cost = COALESCE($3, cost), expense_id = COALESCE($4, expense_id) WHERE id = $1`, [id, status, b.cost ?? null, expenseId]);
  await audit(db, actor, 'return', 'linen_batch', id, { status: batch.status }, { status, lines: b.lines, cost: b.cost ?? null });
  return batchDetail(db, actor.hotelId, id);
}

// =====================================================================================================
// Objets trouvés
// =====================================================================================================
export async function recordLost(db: PoolClient, actor: Actor, b: { room_id?: number | null; location?: string | null; category: string; description: string; found_by_name: string; found_at?: string | null; value_note?: string | null }) {
  if (!b.description?.trim() || !b.found_by_name?.trim()) throw badRequest('Description et personne qui l\'a trouvé obligatoires.');
  let guestId: number | null = null;
  if (b.room_id) {
    const r = await one<any>(db, 'SELECT id FROM rooms WHERE id = $1 AND hotel_id = $2', [b.room_id, actor.hotelId]);
    if (!r) throw notFound('Chambre introuvable');
    // dernier occupant de la chambre (pour le contacter)
    guestId = (await one<any>(db, `SELECT COALESCE(rr.guest_id, res.guest_id) AS g FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN reservations res ON res.id = rr.reservation_id
      WHERE s.room_id = $1 ORDER BY COALESCE(s.checked_out_at, now()) DESC LIMIT 1`, [b.room_id]))?.g ?? null;
  }
  const n = await nextNumber(db, `lf-${today().slice(0, 4)}`);
  const row = await one<any>(db,
    `INSERT INTO lost_items (hotel_id, ref, found_at, room_id, location, category, description, value_note, found_by_name, recorded_by, guest_id)
     VALUES ($1,$2,COALESCE($3::timestamptz, now()),$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [actor.hotelId, `OT${today().slice(0, 4)}-${String(n).padStart(4, '0')}`, b.found_at ?? null, b.room_id ?? null, b.location ?? null, b.category, b.description.trim(), b.value_note ?? null, b.found_by_name.trim(), actor.userId, guestId]);
  await audit(db, actor, 'create', 'lost_item', row.id, null, { ref: row.ref, room_id: b.room_id ?? null });
  return row;
}

const LF_NEXT: Record<string, string[]> = { pending: ['stored', 'returned', 'archived'], stored: ['returned', 'archived'], returned: [], archived: [] };
export async function updateLost(db: PoolClient, actor: Actor, id: number, b: { status: 'stored' | 'returned' | 'archived'; storage_location?: string | null; returned_to?: string | null; reason?: string | null; notes?: string | null }) {
  const it = await one<any>(db, 'SELECT * FROM lost_items WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!it) throw notFound('Objet introuvable');
  if (!LF_NEXT[it.status].includes(b.status)) throw conflict(`Passage « ${it.status} » → « ${b.status} » impossible.`);
  if (b.status === 'stored' && !b.storage_location?.trim()) throw badRequest('Lieu de stockage obligatoire.');
  if (b.status === 'returned' && !b.returned_to?.trim()) throw badRequest('Indiquez à qui l\'objet a été rendu (pièce d\'identité vérifiée).');
  if (b.status === 'archived' && !b.reason?.trim()) throw badRequest('Motif d\'archivage obligatoire (délai dépassé, don, destruction…).');
  await db.query(`UPDATE lost_items SET status = $2, storage_location = COALESCE($3, storage_location), returned_to = COALESCE($4, returned_to),
      returned_at = CASE WHEN $2 = 'returned' THEN now() ELSE returned_at END, returned_by = CASE WHEN $2 = 'returned' THEN $5::int ELSE returned_by END,
      archived_reason = CASE WHEN $2 = 'archived' THEN $6 ELSE archived_reason END, notes = COALESCE($7, notes) WHERE id = $1`,
    [id, b.status, b.storage_location?.trim() || null, b.returned_to?.trim() || null, actor.userId, b.reason?.trim() || null, b.notes ?? null]);
  await audit(db, actor, b.status, 'lost_item', id, { status: it.status }, { status: b.status, returned_to: b.returned_to ?? null, reason: b.reason ?? null });
}

// =====================================================================================================
// Rapports
// =====================================================================================================
export const HK_REPORTS: Record<string, { title: string; columns: { key: string; label: string }[] }> = {
  done: { title: 'Tâches réalisées', columns: [{ key: 'day', label: 'Date' }, { key: 'room', label: 'Chambre' }, { key: 'kind_label', label: 'Tâche' }, { key: 'employee', label: 'Employé' }, { key: 'started', label: 'Début' }, { key: 'ended', label: 'Fin' }, { key: 'minutes', label: 'Durée (min)' }, { key: 'status_label', label: 'Statut' }] },
  late: { title: 'Tâches en retard', columns: [{ key: 'day', label: 'Date' }, { key: 'room', label: 'Chambre' }, { key: 'kind_label', label: 'Tâche' }, { key: 'employee', label: 'Employé' }, { key: 'due', label: 'Échéance' }, { key: 'ended', label: 'Terminée' }, { key: 'delay', label: 'Retard (min)' }] },
  performance: { title: 'Performance du personnel', columns: [{ key: 'employee', label: 'Employé' }, { key: 'tasks', label: 'Tâches' }, { key: 'avg_minutes', label: 'Durée moy. (min)' }, { key: 'inspected', label: 'Inspectées' }, { key: 'refused', label: 'Refus' }, { key: 'refusal_rate', label: 'Taux de refus (%)' }, { key: 'late', label: 'En retard' }] },
  inspections: { title: 'Inspections', columns: [{ key: 'date', label: 'Date' }, { key: 'room', label: 'Chambre' }, { key: 'result_label', label: 'Résultat' }, { key: 'score', label: 'Score (%)' }, { key: 'inspector', label: 'Inspecteur' }, { key: 'cleaner', label: 'Nettoyée par' }, { key: 'remarks', label: 'Remarques' }] },
  linen: { title: 'Consommation et mouvements du linge', columns: [{ key: 'item', label: 'Article' }, { key: 'purchase', label: 'Achats' }, { key: 'issue', label: 'Mis en chambre' }, { key: 'collect', label: 'Ramassé sale' }, { key: 'send_laundry', label: 'Envoyé blanch.' }, { key: 'return_laundry', label: 'Revenu blanch.' }, { key: 'discard', label: 'Sorti (usure / perte)' }, { key: 'clean', label: 'Stock propre' }] },
  daily: { title: 'Historique quotidien', columns: [{ key: 'day', label: 'Date' }, { key: 'tasks', label: 'Tâches' }, { key: 'finished', label: 'Terminées' }, { key: 'checkouts', label: 'Ménages départ' }, { key: 'stayovers', label: 'Recouches' }, { key: 'inspections', label: 'Inspections' }, { key: 'refused', label: 'Refus' }, { key: 'lost', label: 'Objets trouvés' }] },
};
const ST: Record<string, string> = { todo: 'À faire', in_progress: 'En cours', done: 'Terminée', to_inspect: 'À inspecter', validated: 'Validée', cancelled: 'Annulée' };
const fmt = (d: any, tz: string) => (d ? new Date(d).toLocaleString('fr-FR', { timeZone: tz, day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '');

export async function hkReport(db: Db, hotelId: number, kind: string, from: string, to: string, tz = 'Africa/Algiers') {
  const def = HK_REPORTS[kind];
  if (!def) throw notFound('Rapport inconnu');
  const P = [hotelId, from, to];
  let rows: any[] = [];
  if (kind === 'done' || kind === 'late') {
    rows = (await q<any>(db, `SELECT t.*, r.number AS room, e.first_name || ' ' || e.last_name AS employee,
        round(extract(epoch FROM (t.completed_at - t.started_at)) / 60)::int AS minutes,
        round(extract(epoch FROM (COALESCE(t.completed_at, now()) - t.due_at)) / 60)::int AS delay
       FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id LEFT JOIN employees e ON e.id = t.assigned_to
      WHERE r.hotel_id = $1 AND t.task_date BETWEEN $2 AND $3 AND ${kind === 'done' ? `t.status IN ('done','to_inspect','validated')` : `t.due_at IS NOT NULL AND COALESCE(t.completed_at, now()) > t.due_at AND t.status <> 'cancelled'`}
      ORDER BY t.task_date, length(r.number), r.number`, P))
      .map((x) => ({ ...x, day: String(x.task_date), kind_label: TASK_LABEL[x.kind], status_label: ST[x.status], started: fmt(x.started_at, tz), ended: fmt(x.completed_at, tz), due: fmt(x.due_at, tz) }));
  } else if (kind === 'performance') {
    rows = (await q<any>(db, `SELECT e.first_name || ' ' || e.last_name AS employee, count(t.id)::int AS tasks,
        round(avg(extract(epoch FROM (t.completed_at - t.started_at)) / 60))::int AS avg_minutes,
        count(t.id) FILTER (WHERE t.status = 'validated')::int AS inspected, COALESCE(sum(t.refusal_count), 0)::int AS refused,
        count(t.id) FILTER (WHERE t.due_at IS NOT NULL AND t.completed_at > t.due_at)::int AS late
       FROM employees e JOIN housekeeping_tasks t ON t.assigned_to = e.id JOIN rooms r ON r.id = t.room_id
      WHERE r.hotel_id = $1 AND t.task_date BETWEEN $2 AND $3 AND t.status IN ('done','to_inspect','validated') GROUP BY e.id ORDER BY tasks DESC`, P))
      .map((x) => ({ ...x, refusal_rate: x.inspected + x.refused ? Math.round((x.refused * 100) / (x.inspected + x.refused)) : 0 }));
  } else if (kind === 'inspections') {
    rows = (await q<any>(db, `SELECT i.*, r.number AS room, u.full_name AS inspector, uc.full_name AS cleaner FROM hk_inspections i JOIN rooms r ON r.id = i.room_id JOIN users u ON u.id = i.inspector_id
        LEFT JOIN housekeeping_tasks t ON t.id = i.task_id LEFT JOIN users uc ON uc.id = t.completed_by
      WHERE r.hotel_id = $1 AND (i.created_at AT TIME ZONE '${tz}')::date BETWEEN $2 AND $3 ORDER BY i.created_at`, P))
      .map((x) => ({ ...x, date: fmt(x.created_at, tz), result_label: x.result === 'passed' ? 'Validée' : 'Refusée' }));
  } else if (kind === 'linen') {
    rows = (await q<any>(db, `SELECT i.name AS item, i.qty_clean AS clean,
        COALESCE(sum(m.quantity) FILTER (WHERE m.kind = 'purchase'), 0)::int AS purchase, COALESCE(sum(m.quantity) FILTER (WHERE m.kind = 'issue'), 0)::int AS issue,
        COALESCE(sum(m.quantity) FILTER (WHERE m.kind = 'collect'), 0)::int AS collect, COALESCE(sum(m.quantity) FILTER (WHERE m.kind = 'send_laundry'), 0)::int AS send_laundry,
        COALESCE(sum(m.quantity) FILTER (WHERE m.kind = 'return_laundry'), 0)::int AS return_laundry, COALESCE(-sum(m.quantity) FILTER (WHERE m.kind = 'discard'), 0)::int AS discard
       FROM linen_items i LEFT JOIN linen_movements m ON m.item_id = i.id AND (m.created_at AT TIME ZONE '${tz}')::date BETWEEN $2 AND $3
      WHERE i.hotel_id = $1 GROUP BY i.id ORDER BY i.name`, P));
  } else if (kind === 'daily') {
    rows = (await q<any>(db, `SELECT d::date AS day,
        (SELECT count(*) FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id WHERE r.hotel_id = $1 AND t.task_date = d::date AND t.status <> 'cancelled')::int AS tasks,
        (SELECT count(*) FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id WHERE r.hotel_id = $1 AND t.task_date = d::date AND t.status IN ('done','validated','to_inspect'))::int AS finished,
        (SELECT count(*) FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id WHERE r.hotel_id = $1 AND t.task_date = d::date AND t.kind = 'checkout_clean' AND t.status <> 'cancelled')::int AS checkouts,
        (SELECT count(*) FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id WHERE r.hotel_id = $1 AND t.task_date = d::date AND t.kind = 'stayover' AND t.status <> 'cancelled')::int AS stayovers,
        (SELECT count(*) FROM hk_inspections i JOIN rooms r ON r.id = i.room_id WHERE r.hotel_id = $1 AND (i.created_at AT TIME ZONE '${tz}')::date = d::date)::int AS inspections,
        (SELECT count(*) FROM hk_inspections i JOIN rooms r ON r.id = i.room_id WHERE r.hotel_id = $1 AND i.result = 'failed' AND (i.created_at AT TIME ZONE '${tz}')::date = d::date)::int AS refused,
        (SELECT count(*) FROM lost_items l WHERE l.hotel_id = $1 AND (l.found_at AT TIME ZONE '${tz}')::date = d::date)::int AS lost
       FROM generate_series($2::date, $3::date, interval '1 day') d ORDER BY d DESC`, P)).map((x) => ({ ...x, day: String(x.day).slice(0, 10) }));
  }
  return { kind, title: def.title, from, to, columns: def.columns, rows };
}

export { addDays, guestDisplayName };
