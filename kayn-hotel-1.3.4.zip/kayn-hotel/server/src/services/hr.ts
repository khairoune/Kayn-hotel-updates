/**
 * Ressources humaines : périmètre d'accès, planning (conflits, rotations, synchronisation housekeeping), pointage
 * (retards, pauses, heures, heures sup.), corrections, congés (jours, solde, validation), contrats, paie (bulletins),
 * avances, alertes, tableau de bord, rapports.
 */
import { currency } from './exports.js';
import type { PoolClient } from 'pg';
import { one, q, type Db } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { addDays, monthStart, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { fromCents, toCents } from '../lib/money.js';
import { config } from '../config.js';
import { getSettings, nextNumber } from './common.js';

export const TZ = config.timezone ?? 'Africa/Algiers';
export const DEFAULT_DEPARTMENTS: [string, string][] = [
  ['reception', 'Réception'], ['housekeeping', 'Housekeeping'], ['restaurant', 'Restaurant'], ['kitchen', 'Cuisine'], ['bar', 'Bar'],
  ['maintenance', 'Maintenance'], ['accounting', 'Comptabilité'], ['admin', 'Administration'], ['security', 'Sécurité'], ['direction', 'Direction'], ['hr', 'Ressources humaines'], ['stock', 'Stocks et achats'],
];
export const DEFAULT_SHIFTS: [string, string, string, string, number, string][] = [
  ['M', 'Matin', '07:00', '15:00', 30, '#F59E0B'], ['S', 'Soir', '15:00', '23:00', 30, '#2563EB'], ['N', 'Nuit', '23:00', '07:00', 30, '#4C1D95'], ['J', 'Journée', '08:00', '17:00', 60, '#15803D'],
];
/** [code, nom, payé, décompté du solde, horaire, justificatif, justifié, couleur] */
export const DEFAULT_LEAVE_TYPES: [string, string, boolean, boolean, boolean, boolean, boolean, string][] = [
  ['annual', 'Congé annuel', true, true, false, false, true, '#0E7490'],
  ['sick', 'Congé maladie', true, false, false, true, true, '#B45309'],
  ['unpaid', 'Congé sans solde', false, false, false, false, true, '#64748B'],
  ['exceptional', 'Congé exceptionnel (événement familial)', true, false, false, true, true, '#7C3AED'],
  ['maternity', 'Congé maternité', true, false, false, true, true, '#DB2777'],
  ['justified', 'Absence justifiée', true, false, false, true, true, '#0891B2'],
  ['unjustified', 'Absence injustifiée', false, false, false, false, false, '#B91C1C'],
  ['exit', 'Autorisation de sortie', true, false, true, false, true, '#CA8A04'],
];
export const STATUS_LABEL: Record<string, string> = { active: 'Actif', suspended: 'Suspendu', leave: 'En congé', left: 'Sorti' };
export const CONTRACT_LABEL: Record<string, string> = { cdi: 'CDI', cdd: 'CDD', seasonal: 'Saisonnier', trial: 'Période d\'essai', internship: 'Stage', consultant: 'Prestataire', other: 'Autre' };
const yr = () => today().slice(0, 4);
const pad = (n: number) => String(n).padStart(4, '0');
const n2 = (v: any) => Math.round(Number(v ?? 0) * 100) / 100;

export interface HrSettings {
  late_tolerance_minutes: number; overtime_threshold_minutes: number; min_rest_hours: number; weekly_rest_days: number[];
  leave_days_per_month: number; leave_year_start_month: number; monthly_hours: number; day_divisor: number; overtime_rate_percent: number;
  contributions: { code: string; label: string; rate: number; side: 'employee' | 'employer' }[];
  tax_brackets: { from: number; to: number | null; rate: number }[];
  contract_alert_days: number; document_alert_days: number; payroll_category: string; advance_category: string;
}
export async function hrSettings(db: Db, hotelId: number): Promise<HrSettings> {
  return (await getSettings(db, hotelId)).hr;
}

// =====================================================================================================
// Périmètre d'accès
// =====================================================================================================
export interface Scope { all: boolean; departments: string[]; employeeId: number | null; salary: boolean; personal: boolean }
/** Ce que l'utilisateur peut voir : tout (RH, paie, direction), son / ses départements (chef), ou seulement lui-même. */
export async function scopeOf(db: Db, actor: Actor, perms: Set<string>): Promise<Scope> {
  const me = await one<any>(db, `SELECT e.id, e.department FROM users u JOIN employees e ON e.id = u.employee_id WHERE u.id = $1`, [actor.userId]);
  const all = perms.has('hr.manage') || perms.has('hr.payroll') || perms.has('hr.salary');
  let departments: string[] = [];
  if (!all && (perms.has('hr.view') || perms.has('hr.team')) && me) {
    const led = await q<any>(db, 'SELECT code FROM hr_departments WHERE hotel_id = $1 AND manager_employee_id = $2', [actor.hotelId, me.id]);
    departments = [...new Set([me.department, ...led.map((x) => x.code)].filter(Boolean))];
  }
  return { all, departments, employeeId: me?.id ?? null, salary: perms.has('hr.salary'), personal: perms.has('hr.manage') };
}
export function scopeSql(s: Scope, alias = 'e', idx = 2) {
  if (s.all) return { sql: 'TRUE', params: [] as any[] };
  return { sql: `(${alias}.department = ANY($${idx}::text[]) OR ${alias}.id = $${idx + 1})`, params: [s.departments, s.employeeId ?? -1] };
}
export async function employeeInScope(db: Db, actor: Actor, s: Scope, id: number, opts: { team?: boolean } = {}) {
  const e = await one<any>(db, 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2', [id, actor.hotelId]);
  if (!e) throw notFound('Employé introuvable');
  if (s.all || e.id === s.employeeId) return e;
  if (s.departments.includes(e.department)) return e;
  throw forbidden(opts.team ? 'Employé hors de votre département.' : 'Accès refusé à ce dossier.');
}
/** Masque les données sensibles selon les droits. */
export function redact(e: any, s: Scope) {
  const own = e.id === s.employeeId;
  const out = { ...e };
  delete out.pin_hash;
  out.has_pin = !!e.pin_hash;
  if (!s.salary && !own) out.base_salary = null;
  if (!s.personal && !own) for (const k of ['birth_date', 'address', 'city', 'emergency_contact', 'notes', 'exit_reason', 'leave_opening']) out[k] = null;
  return out;
}
export async function myEmployee(db: Db, actor: Actor) {
  const e = await one<any>(db, `SELECT e.* FROM users u JOIN employees e ON e.id = u.employee_id WHERE u.id = $1`, [actor.userId]);
  if (!e) throw conflict('Votre compte n\'est lié à aucune fiche employé : contactez les RH.');
  return e;
}

// =====================================================================================================
// Statut, sortie, comptes liés
// =====================================================================================================
export async function setStatus(db: PoolClient, actor: Actor, id: number, b: { status: 'active' | 'suspended' | 'left'; date?: string | null; reason?: string | null }) {
  const e = await one<any>(db, 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!e) throw notFound('Employé introuvable');
  if (e.status === b.status) throw conflict('Statut inchangé.');
  if (b.status !== 'active' && !b.reason?.trim()) throw badRequest('Motif obligatoire.');
  if (b.status === 'left') {
    const d = b.date ?? today();
    await db.query(`UPDATE employees SET status = 'left', exit_date = $2, exit_reason = $3, updated_at = now() WHERE id = $1`, [id, d, b.reason!.trim()]);
    await db.query(`UPDATE hr_contracts SET status = 'ended', end_date = CASE WHEN end_date IS NULL OR end_date > $2 THEN $2 ELSE end_date END WHERE employee_id = $1 AND status = 'active'`, [id, d]);
    await db.query(`DELETE FROM hr_schedule WHERE employee_id = $1 AND work_date > $2`, [id, d]);
    await db.query(`UPDATE hr_leave_requests SET status = 'cancelled', decision_note = 'Départ de l''employé' WHERE employee_id = $1 AND status = 'pending'`, [id]);
  } else {
    await db.query(`UPDATE employees SET status = $2, exit_date = CASE WHEN $2 = 'active' THEN NULL ELSE exit_date END, exit_reason = CASE WHEN $2 = 'active' THEN NULL ELSE $3 END, updated_at = now() WHERE id = $1`, [id, b.status, b.reason ?? null]);
  }
  // comptes utilisateurs liés : désactivés si sorti / suspendu, réactivés au retour
  const users = await q<any>(db, 'UPDATE users SET active = $2 WHERE employee_id = $1 RETURNING id, username', [id, b.status === 'active']);
  if (b.status !== 'active') await db.query(`DELETE FROM sessions WHERE user_id = ANY($1::int[])`, [users.map((u) => u.id)]).catch(() => {});
  // maintenance : technicien lié
  await db.query(`UPDATE maintenance_technicians SET active = $2 WHERE user_id = ANY($1::int[])`, [users.map((u) => u.id), b.status !== 'left']);
  await audit(db, actor, `status_${b.status}`, 'employee', id, { status: e.status }, { status: b.status, reason: b.reason ?? null, users: users.map((u) => u.username) });
}

// =====================================================================================================
// Contrats
// =====================================================================================================
export async function createContract(db: PoolClient, actor: Actor, employeeId: number, b: {
  kind: string; position?: string | null; department?: string | null; start_date: string; end_date?: string | null; trial_end?: string | null; base_salary: number; weekly_hours?: number; notes?: string | null; renew?: boolean;
}) {
  const e = await one<any>(db, 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [employeeId, actor.hotelId]);
  if (!e) throw notFound('Employé introuvable');
  if (e.status === 'left') throw conflict('Employé sorti : réintégrez-le avant un nouveau contrat.');
  if (['cdd', 'seasonal', 'trial', 'internship'].includes(b.kind) && !b.end_date) throw badRequest('Date de fin obligatoire pour ce type de contrat.');
  if (b.end_date && b.end_date < b.start_date) throw badRequest('La fin du contrat précède son début.');
  const cur = await one<any>(db, `SELECT * FROM hr_contracts WHERE employee_id = $1 AND status = 'active'`, [employeeId]);
  if (cur) {
    if (b.start_date <= String(cur.start_date).slice(0, 10)) throw conflict('Le nouveau contrat doit commencer après le contrat en cours.');
    await db.query(`UPDATE hr_contracts SET status = 'ended', end_date = CASE WHEN end_date IS NULL OR end_date >= $2 THEN $2::date - 1 ELSE end_date END WHERE id = $1`, [cur.id, b.start_date]);
  }
  const n = await nextNumber(db, `ct-${yr()}`);
  const c = await one<any>(db, `INSERT INTO hr_contracts (hotel_id, employee_id, number, kind, position, department, start_date, end_date, trial_end, base_salary, weekly_hours, renewed_from, notes, created_by)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
  [actor.hotelId, employeeId, `CT${yr()}-${pad(n)}`, b.kind, b.position ?? e.position, b.department ?? e.department, b.start_date, b.end_date ?? null, b.trial_end ?? null, b.base_salary, b.weekly_hours ?? 40,
    b.renew && cur ? cur.id : null, b.notes ?? null, actor.userId]);
  await db.query(`UPDATE employees SET contract_type = $2, contract_start = $3, contract_end = $4, base_salary = $5, position = COALESCE($6, position), department = COALESCE($7, department), updated_at = now() WHERE id = $1`,
    [employeeId, b.kind, b.start_date, b.end_date ?? null, b.base_salary, b.position ?? null, b.department ?? null]);
  await audit(db, actor, b.renew ? 'renew_contract' : 'create_contract', 'employee', employeeId, cur ? { contract: cur.number, salary: cur.base_salary } : null, { contract: c.number, kind: b.kind, salary: b.base_salary, end: b.end_date ?? null });
  return c;
}
export async function addAmendment(db: PoolClient, actor: Actor, contractId: number, b: { effective_date: string; description: string; new_salary?: number | null; new_position?: string | null; new_end_date?: string | null; new_weekly_hours?: number | null }) {
  const c = await one<any>(db, 'SELECT * FROM hr_contracts WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [contractId, actor.hotelId]);
  if (!c) throw notFound('Contrat introuvable');
  if (c.status !== 'active') throw conflict('Avenant possible uniquement sur le contrat en cours.');
  if (b.new_end_date && b.new_end_date < String(c.start_date).slice(0, 10)) throw badRequest('Nouvelle date de fin invalide.');
  const a = await one<any>(db, `INSERT INTO hr_contract_amendments (contract_id, effective_date, description, new_salary, new_position, new_end_date, new_weekly_hours, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [contractId, b.effective_date, b.description.trim(), b.new_salary ?? null, b.new_position ?? null, b.new_end_date ?? null, b.new_weekly_hours ?? null, actor.userId]);
  await db.query(`UPDATE hr_contracts SET base_salary = COALESCE($2, base_salary), position = COALESCE($3, position), end_date = COALESCE($4, end_date), weekly_hours = COALESCE($5, weekly_hours) WHERE id = $1`,
    [contractId, b.new_salary ?? null, b.new_position ?? null, b.new_end_date ?? null, b.new_weekly_hours ?? null]);
  await db.query(`UPDATE employees SET base_salary = COALESCE($2, base_salary), position = COALESCE($3, position), contract_end = COALESCE($4, contract_end), updated_at = now() WHERE id = $1`,
    [c.employee_id, b.new_salary ?? null, b.new_position ?? null, b.new_end_date ?? null]);
  await audit(db, actor, 'amendment', 'employee', c.employee_id, { salary: c.base_salary, position: c.position, end: c.end_date }, { contract: c.number, ...b });
  return a;
}

// =====================================================================================================
// Planning
// =====================================================================================================
const minutesOf = (t: string) => { const [h, m] = String(t).slice(0, 5).split(':').map(Number); return h * 60 + m; };
export const shiftMinutes = (start: string, end: string, brk = 0) => { let d = minutesOf(end) - minutesOf(start); if (d <= 0) d += 1440; return Math.max(0, d - brk); };
/** Intervalle absolu (minutes depuis l'époque locale) d'un poste. */
const span = (date: string, start: string, end: string) => {
  const base = Date.parse(`${date}T00:00:00Z`) / 60000;
  const s = base + minutesOf(start);
  let e = base + minutesOf(end);
  if (e <= s) e += 1440;
  return [s, e];
};
export async function leaveOn(db: Db, employeeId: number, d: string) {
  return one<any>(db, `SELECT r.*, t.name AS type_name FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id
     WHERE r.employee_id = $1 AND r.status = 'approved' AND NOT t.hourly AND $2::date BETWEEN r.start_date AND r.end_date LIMIT 1`, [employeeId, d]);
}

export async function setShift(db: PoolClient, actor: Actor, b: {
  employee_id: number; work_date: string; shift_type_id?: number | null; start_time?: string | null; end_time?: string | null; break_minutes?: number | null; rest?: boolean; zone?: string | null; notes?: string | null;
}) {
  const e = await one<any>(db, 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2', [b.employee_id, actor.hotelId]);
  if (!e) throw notFound('Employé introuvable');
  if (e.status === 'left' && (!e.exit_date || b.work_date > String(e.exit_date).slice(0, 10))) throw conflict(`${e.first_name} ${e.last_name} a quitté l'établissement.`);
  let start = b.start_time ?? null, end = b.end_time ?? null, brk = b.break_minutes ?? 0, st: any = null;
  if (!b.rest) {
    if (b.shift_type_id) {
      st = await one<any>(db, 'SELECT * FROM hr_shift_types WHERE id = $1 AND hotel_id = $2', [b.shift_type_id, actor.hotelId]);
      if (!st) throw badRequest('Équipe inconnue.');
      start = start ?? String(st.start_time).slice(0, 5); end = end ?? String(st.end_time).slice(0, 5); brk = b.break_minutes ?? st.break_minutes;
    }
    if (!start || !end) throw badRequest('Horaires obligatoires.');
    if (start === end) throw badRequest('Heure de début et de fin identiques.');
    const lv = await leaveOn(db, e.id, b.work_date);
    if (lv) throw conflict(`${e.first_name} ${e.last_name} est en congé ce jour (${lv.type_name}, ${lv.number}).`);
    // chevauchement / repos minimal avec les postes de la veille et du lendemain
    const s = await hrSettings(db, actor.hotelId);
    const [a0, a1] = span(b.work_date, start, end);
    for (const o of await q<any>(db, `SELECT * FROM hr_schedule WHERE employee_id = $1 AND work_date IN ($2::date - 1, $2::date + 1) AND NOT rest`, [e.id, b.work_date])) {
      const [b0, b1] = span(String(o.work_date).slice(0, 10), String(o.start_time).slice(0, 5), String(o.end_time).slice(0, 5));
      if (a0 < b1 && b0 < a1) throw conflict(`Conflit d'horaires avec le poste du ${String(o.work_date).slice(0, 10)} (${String(o.start_time).slice(0, 5)}–${String(o.end_time).slice(0, 5)}).`);
      const gap = b0 >= a1 ? b0 - a1 : a0 - b1;
      if (s.min_rest_hours && gap < s.min_rest_hours * 60) throw conflict(`Repos insuffisant (${Math.floor(gap / 60)} h ${gap % 60} min, minimum ${s.min_rest_hours} h) avec le poste du ${String(o.work_date).slice(0, 10)}.`);
    }
  }
  const r = await one<any>(db, `INSERT INTO hr_schedule (hotel_id, employee_id, work_date, shift_type_id, start_time, end_time, break_minutes, rest, zone, notes, created_by)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
      ON CONFLICT (employee_id, work_date) DO UPDATE SET shift_type_id = EXCLUDED.shift_type_id, start_time = EXCLUDED.start_time, end_time = EXCLUDED.end_time, break_minutes = EXCLUDED.break_minutes,
        rest = EXCLUDED.rest, zone = EXCLUDED.zone, notes = EXCLUDED.notes, updated_at = now() RETURNING *`,
  [actor.hotelId, e.id, b.work_date, b.rest ? null : st?.id ?? b.shift_type_id ?? null, b.rest ? null : start, b.rest ? null : end, b.rest ? 0 : brk, !!b.rest, b.zone ?? null, b.notes ?? null, actor.userId]);
  await syncOperational(db, e, b.work_date, r);
  return r;
}
/** Le planning RH alimente le planning opérationnel du housekeeping (postes du jour). */
async function syncOperational(db: PoolClient, e: any, d: string, r: any | null) {
  if (e.department !== 'housekeeping') return;
  if (!r || r.rest) {
    const busy = await one(db, `SELECT 1 FROM housekeeping_tasks WHERE assigned_to = $1 AND task_date = $2 AND status IN ('todo','in_progress')`, [e.id, d]);
    if (busy && r?.rest) throw conflict(`${e.first_name} ${e.last_name} a des chambres affectées ce jour : réaffectez-les d'abord.`);
    await db.query('DELETE FROM hk_shifts WHERE employee_id = $1 AND work_date = $2 AND started_at IS NULL', [e.id, d]);
    return;
  }
  await db.query(`INSERT INTO hk_shifts (employee_id, work_date, start_time, end_time, zone) VALUES ($1,$2,$3,$4,$5)
      ON CONFLICT (employee_id, work_date) DO UPDATE SET start_time = EXCLUDED.start_time, end_time = EXCLUDED.end_time, zone = COALESCE(EXCLUDED.zone, hk_shifts.zone)`,
  [e.id, d, r.start_time, r.end_time, r.zone]);
}
export async function clearShift(db: PoolClient, actor: Actor, employeeId: number, d: string) {
  const e = await one<any>(db, 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2', [employeeId, actor.hotelId]);
  if (!e) throw notFound('Employé introuvable');
  await syncOperational(db, e, d, null);
  await db.query('DELETE FROM hr_schedule WHERE employee_id = $1 AND work_date = $2', [employeeId, d]);
}
/** Rotation : motif répété (codes d'équipe ou « R » = repos) sur une période. Retourne les conflits sans bloquer les autres jours. */
export async function applyRotation(db: PoolClient, actor: Actor, b: { employee_ids: number[]; start_date: string; end_date: string; pattern: string[]; offset_per_employee?: number }) {
  if (b.end_date < b.start_date) throw badRequest('Période invalide.');
  if ((Date.parse(b.end_date) - Date.parse(b.start_date)) / 86400000 > 92) throw badRequest('Période limitée à 3 mois.');
  const types = await q<any>(db, 'SELECT * FROM hr_shift_types WHERE hotel_id = $1 AND active', [actor.hotelId]);
  const byCode = new Map(types.map((t) => [t.code.toUpperCase(), t]));
  for (const p of b.pattern) if (p.toUpperCase() !== 'R' && !byCode.has(p.toUpperCase())) throw badRequest(`Équipe « ${p} » inconnue.`);
  let done = 0;
  const conflicts: { employee_id: number; date: string; message: string }[] = [];
  for (const [i, emp] of b.employee_ids.entries()) {
    let d = b.start_date, k = (b.offset_per_employee ?? 0) * i;
    while (d <= b.end_date) {
      const code = b.pattern[k % b.pattern.length].toUpperCase();
      try {
        await db.query('SAVEPOINT rot');
        await setShift(db, actor, code === 'R' ? { employee_id: emp, work_date: d, rest: true } : { employee_id: emp, work_date: d, shift_type_id: byCode.get(code)!.id });
        await db.query('RELEASE SAVEPOINT rot');
        done++;
      } catch (e: any) {
        await db.query('ROLLBACK TO SAVEPOINT rot');
        if (!e?.status) throw e;
        conflicts.push({ employee_id: emp, date: d, message: e.message });
      }
      d = addDays(d, 1); k++;
    }
  }
  await audit(db, actor, 'rotation', 'hr_schedule', null, null, { employees: b.employee_ids, from: b.start_date, to: b.end_date, pattern: b.pattern, done, conflicts: conflicts.length });
  return { done, conflicts };
}
export async function decideSwap(db: PoolClient, actor: Actor, s: Scope, id: number, approve: boolean, note?: string | null) {
  const w = await one<any>(db, 'SELECT * FROM hr_shift_swaps WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!w) throw notFound('Échange introuvable');
  if (w.status !== 'pending') throw conflict('Échange déjà traité.');
  const req = await employeeInScope(db, actor, s, w.requester_id, { team: true });
  if (!s.all && req.id === s.employeeId) throw forbidden('Vous ne pouvez pas valider votre propre échange.');
  if (approve) {
    const a = await one<any>(db, 'SELECT * FROM hr_schedule WHERE employee_id = $1 AND work_date = $2', [w.requester_id, w.date_a]);
    const b = await one<any>(db, 'SELECT * FROM hr_schedule WHERE employee_id = $1 AND work_date = $2', [w.target_id, w.date_b]);
    if (!a || !b) throw conflict('Un des postes n\'existe plus dans le planning.');
    const a2 = await one<any>(db, 'SELECT * FROM hr_schedule WHERE employee_id = $1 AND work_date = $2', [w.target_id, w.date_a]);
    const b2 = await one<any>(db, 'SELECT * FROM hr_schedule WHERE employee_id = $1 AND work_date = $2', [w.requester_id, w.date_b]);
    const asShift = (x: any) => (x && !x.rest ? { shift_type_id: x.shift_type_id, start_time: String(x.start_time).slice(0, 5), end_time: String(x.end_time).slice(0, 5), break_minutes: x.break_minutes, zone: x.zone } : { rest: true });
    // le demandeur prend le poste du collègue (date_b) et lui cède le sien (date_a)
    await db.query('DELETE FROM hr_schedule WHERE (employee_id = $1 AND work_date IN ($3::date, $4::date)) OR (employee_id = $2 AND work_date IN ($3::date, $4::date))', [w.requester_id, w.target_id, w.date_a, w.date_b]);
    if (w.date_a === w.date_b || String(w.date_a) === String(w.date_b)) {
      await setShift(db, actor, { employee_id: w.requester_id, work_date: w.date_a, ...asShift(b) });
      await setShift(db, actor, { employee_id: w.target_id, work_date: w.date_a, ...asShift(a) });
    } else {
      await setShift(db, actor, { employee_id: w.target_id, work_date: w.date_a, ...asShift(a) });
      await setShift(db, actor, { employee_id: w.requester_id, work_date: w.date_b, ...asShift(b) });
      await setShift(db, actor, { employee_id: w.requester_id, work_date: w.date_a, ...asShift(a2 ?? { rest: true }) });
      await setShift(db, actor, { employee_id: w.target_id, work_date: w.date_b, ...asShift(b2 ?? { rest: true }) });
    }
  }
  await db.query(`UPDATE hr_shift_swaps SET status = $2, decided_by = $3, decided_at = now(), decision_note = $4 WHERE id = $1`, [id, approve ? 'approved' : 'refused', actor.userId, note ?? null]);
  await audit(db, actor, approve ? 'approve_swap' : 'refuse_swap', 'hr_shift_swap', id, null, { note: note ?? null });
}

// =====================================================================================================
// Pointage
// =====================================================================================================
async function localTs(db: Db, d: string, t: string) {
  return (await one<any>(db, `SELECT (($1::date + $2::time) AT TIME ZONE $3) AS ts`, [d, t, TZ])).ts as Date;
}
/** Recalcule retard, heures travaillées et heures supplémentaires à partir du planning. */
export async function recompute(db: Db, id: number) {
  const a = await one<any>(db, 'SELECT * FROM hr_attendance WHERE id = $1', [id]);
  const s = await hrSettings(db, a.hotel_id);
  const d = String(a.work_date).slice(0, 10);
  const sh = await one<any>(db, 'SELECT * FROM hr_schedule WHERE employee_id = $1 AND work_date = $2', [a.employee_id, d]);
  let sStart: Date | null = null, sEnd: Date | null = null, sMin = 0;
  if (sh && !sh.rest) {
    sStart = await localTs(db, d, String(sh.start_time).slice(0, 5));
    sEnd = await localTs(db, d, String(sh.end_time).slice(0, 5));
    if (sEnd <= sStart) sEnd = new Date(sEnd.getTime() + 86400000);
    sMin = shiftMinutes(String(sh.start_time), String(sh.end_time), sh.break_minutes);
  }
  const cin = a.clock_in ? new Date(a.clock_in) : null, cout = a.clock_out ? new Date(a.clock_out) : null;
  const diff = (x: Date, y: Date) => Math.round((x.getTime() - y.getTime()) / 60000);
  const lateRaw = cin && sStart ? diff(cin, sStart) : 0;
  const late = lateRaw > s.late_tolerance_minutes ? lateRaw : 0;
  const early = cout && sEnd ? Math.max(0, diff(sEnd, cout)) : 0;
  const worked = cin && cout ? Math.max(0, diff(cout, cin) - a.break_minutes) : 0;
  let ot = cout ? (sh && !sh.rest ? worked - sMin : worked) : 0;      // travail un jour de repos = heures supplémentaires
  if (ot < s.overtime_threshold_minutes) ot = 0;
  await db.query(`UPDATE hr_attendance SET scheduled_start = $2, scheduled_end = $3, scheduled_minutes = $4, late_minutes = $5, early_minutes = $6, worked_minutes = $7, overtime_minutes = $8, updated_at = now() WHERE id = $1`,
    [id, sStart, sEnd, sMin, late, early, worked, ot]);
  return one<any>(db, 'SELECT * FROM hr_attendance WHERE id = $1', [id]);
}
/** Pointage : arrivée, début / fin de pause, départ. */
export async function clock(db: PoolClient, actor: Actor, employeeId: number, action: 'in' | 'out' | 'break_start' | 'break_end' | 'toggle', source: 'self' | 'manual' | 'terminal') {
  const e = await one<any>(db, 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2', [employeeId, actor.hotelId]);
  if (!e) throw notFound('Employé introuvable');
  if (e.status === 'left' || e.status === 'suspended') throw conflict(`${e.first_name} ${e.last_name} : ${STATUS_LABEL[e.status].toLowerCase()}, pointage impossible.`);
  const open = await one<any>(db, `SELECT * FROM hr_attendance WHERE employee_id = $1 AND clock_in IS NOT NULL AND clock_out IS NULL AND clock_in > now() - interval '20 hours' ORDER BY clock_in DESC LIMIT 1 FOR UPDATE`, [employeeId]);
  if (action === 'toggle') action = open ? (open.break_started_at ? 'break_end' : 'out') : 'in';
  let id: number;
  if (action === 'in') {
    if (open) throw conflict('Arrivée déjà pointée.');
    const d = today();
    const ex = await one<any>(db, 'SELECT * FROM hr_attendance WHERE employee_id = $1 AND work_date = $2', [employeeId, d]);
    if (ex?.clock_out) throw conflict('Journée déjà clôturée : demandez une correction de pointage.');
    const r = await one<any>(db, `INSERT INTO hr_attendance (hotel_id, employee_id, work_date, clock_in, source, created_by) VALUES ($1,$2,$3,now(),$4,$5)
        ON CONFLICT (employee_id, work_date) DO UPDATE SET clock_in = now(), source = EXCLUDED.source RETURNING id`, [actor.hotelId, employeeId, d, source, actor.userId]);
    id = r.id;
  } else {
    if (!open) throw conflict('Aucune arrivée pointée.');
    id = open.id;
    if (action === 'break_start') {
      if (open.break_started_at) throw conflict('Pause déjà commencée.');
      await db.query('UPDATE hr_attendance SET break_started_at = now() WHERE id = $1', [id]);
    } else if (action === 'break_end') {
      if (!open.break_started_at) throw conflict('Aucune pause en cours.');
      await db.query(`UPDATE hr_attendance SET break_minutes = break_minutes + GREATEST(0, round(extract(epoch FROM now() - break_started_at) / 60))::int, break_started_at = NULL WHERE id = $1`, [id]);
    } else {
      await db.query(`UPDATE hr_attendance SET break_minutes = break_minutes + CASE WHEN break_started_at IS NULL THEN 0 ELSE GREATEST(0, round(extract(epoch FROM now() - break_started_at) / 60))::int END,
          break_started_at = NULL, clock_out = GREATEST(now(), clock_in + interval '1 second') WHERE id = $1`, [id]);
    }
  }
  const r = await recompute(db, id);
  // housekeeping : pointage réel du poste du jour
  if (e.department === 'housekeeping') {
    if (action === 'in') await db.query('UPDATE hk_shifts SET started_at = COALESCE(started_at, now()) WHERE employee_id = $1 AND work_date = $2', [employeeId, String(r.work_date).slice(0, 10)]);
    if (action === 'out') await db.query('UPDATE hk_shifts SET ended_at = now() WHERE employee_id = $1 AND work_date = $2', [employeeId, String(r.work_date).slice(0, 10)]);
  }
  await audit(db, actor, `clock_${action}`, 'employee', employeeId, null, { source, late: r.late_minutes, worked: r.worked_minutes });
  return { ...r, action };
}
/** Correction de pointage : appliquée directement par les RH (motif obligatoire), sinon soumise à leur autorisation. */
export async function requestCorrection(db: PoolClient, actor: Actor, perms: Set<string>, b: { employee_id: number; work_date: string; clock_in?: string | null; clock_out?: string | null; break_minutes?: number | null; reason: string }) {
  if (!b.reason?.trim() || b.reason.trim().length < 5) throw badRequest('Justification obligatoire (5 caractères minimum).');
  if (b.work_date > today()) throw badRequest('Date future.');
  if (b.clock_in && b.clock_out && new Date(b.clock_out) <= new Date(b.clock_in)) throw badRequest('Le départ doit être après l\'arrivée.');
  if (b.clock_out && new Date(b.clock_out).getTime() > Date.now() + 60000) throw badRequest('Heure de départ dans le futur.');
  const cur = await one<any>(db, 'SELECT * FROM hr_attendance WHERE employee_id = $1 AND work_date = $2', [b.employee_id, b.work_date]);
  const c = await one<any>(db, `INSERT INTO hr_attendance_corrections (hotel_id, employee_id, work_date, attendance_id, before, clock_in, clock_out, break_minutes, reason, requested_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [actor.hotelId, b.employee_id, b.work_date, cur?.id ?? null, cur ? JSON.stringify({ clock_in: cur.clock_in, clock_out: cur.clock_out, break_minutes: cur.break_minutes }) : null, b.clock_in ?? null, b.clock_out ?? null, b.break_minutes ?? null, b.reason.trim(), actor.userId]);
  await audit(db, actor, 'attendance_correction_request', 'employee', b.employee_id, null, { date: b.work_date, reason: b.reason });
  if (perms.has('hr.manage')) return decideCorrection(db, actor, c.id, true);
  return c;
}
export async function decideCorrection(db: PoolClient, actor: Actor, id: number, approve: boolean, note?: string | null) {
  const c = await one<any>(db, 'SELECT * FROM hr_attendance_corrections WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!c) throw notFound('Correction introuvable');
  if (c.status !== 'pending') throw conflict('Correction déjà traitée.');
  if (approve) {
    const d = String(c.work_date).slice(0, 10);
    const r = await one<any>(db, `INSERT INTO hr_attendance (hotel_id, employee_id, work_date, clock_in, clock_out, break_minutes, source, corrected, created_by) VALUES ($1,$2,$3,$4,$5,COALESCE($6,0),'correction',true,$7)
        ON CONFLICT (employee_id, work_date) DO UPDATE SET clock_in = COALESCE($4, hr_attendance.clock_in), clock_out = COALESCE($5, hr_attendance.clock_out),
          break_minutes = COALESCE($6, hr_attendance.break_minutes), break_started_at = NULL, corrected = true, source = 'correction' RETURNING id`,
    [c.hotel_id, c.employee_id, d, c.clock_in, c.clock_out, c.break_minutes, actor.userId]);
    const a = await one<any>(db, 'SELECT * FROM hr_attendance WHERE id = $1', [r.id]);
    if (a.clock_in && a.clock_out && new Date(a.clock_out) <= new Date(a.clock_in)) throw badRequest('Le départ doit être après l\'arrivée.');
    await recompute(db, r.id);
    await db.query('UPDATE hr_attendance_corrections SET attendance_id = $2 WHERE id = $1', [id, r.id]);
  }
  await db.query(`UPDATE hr_attendance_corrections SET status = $2, decided_by = $3, decided_at = now() WHERE id = $1`, [id, approve ? 'approved' : 'refused', actor.userId]);
  await audit(db, actor, approve ? 'attendance_corrected' : 'attendance_correction_refused', 'employee', c.employee_id, c.before, { date: c.work_date, clock_in: c.clock_in, clock_out: c.clock_out, break_minutes: c.break_minutes, reason: c.reason, note: note ?? null });
  return one<any>(db, 'SELECT * FROM hr_attendance_corrections WHERE id = $1', [id]);
}

// =====================================================================================================
// Congés
// =====================================================================================================
/** Jours ouvrés d'un congé : hors jours de repos hebdomadaires et repos planifiés. */
export async function leaveDays(db: Db, hotelId: number, employeeId: number, from: string, to: string) {
  const s = await hrSettings(db, hotelId);
  const rests = new Set((await q<any>(db, `SELECT work_date::text AS d FROM hr_schedule WHERE employee_id = $1 AND rest AND work_date BETWEEN $2 AND $3`, [employeeId, from, to])).map((x) => x.d));
  const worked = new Set((await q<any>(db, `SELECT work_date::text AS d FROM hr_schedule WHERE employee_id = $1 AND NOT rest AND work_date BETWEEN $2 AND $3`, [employeeId, from, to])).map((x) => x.d));
  let n = 0;
  for (let d = from; d <= to; d = addDays(d, 1)) {
    if (rests.has(d)) continue;
    if (!worked.has(d) && s.weekly_rest_days.includes(new Date(`${d}T00:00:00Z`).getUTCDay())) continue;
    n++;
  }
  return n;
}
const monthsBetween = (a: string, b: string) => {
  if (b < a) return 0;
  let m = (Number(b.slice(0, 4)) - Number(a.slice(0, 4))) * 12 + Number(b.slice(5, 7)) - Number(a.slice(5, 7));
  if (Number(b.slice(8, 10)) < Number(a.slice(8, 10))) m--;
  return Math.max(0, m);
};
/** Solde de congés annuels : reprise + acquis (mois complets depuis la mise en service) + ajustements − pris ; en attente à part. */
export async function leaveBalance(db: Db, hotelId: number, employeeId: number, at = today()) {
  const s = await hrSettings(db, hotelId);
  const e = await one<any>(db, 'SELECT * FROM employees WHERE id = $1', [employeeId]);
  const created = new Date(e.created_at).toLocaleDateString('sv-SE', { timeZone: TZ });
  const start = e.hire_date && String(e.hire_date).slice(0, 10) > created ? String(e.hire_date).slice(0, 10) : created;
  const months = monthsBetween(start, at);
  const accrued = n2(months * Number(s.leave_days_per_month));
  const adj = Number((await one<any>(db, 'SELECT COALESCE(sum(days),0) AS d FROM hr_leave_adjustments WHERE employee_id = $1', [employeeId])).d);
  const r = await one<any>(db, `SELECT COALESCE(sum(r.days) FILTER (WHERE r.status = 'approved'),0) AS taken, COALESCE(sum(r.days) FILTER (WHERE r.status = 'pending'),0) AS pending
      FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id WHERE r.employee_id = $1 AND t.deducts_balance`, [employeeId]);
  const balance = n2(Number(e.leave_opening) + accrued + adj - Number(r.taken));
  return { opening: Number(e.leave_opening), accrued, months, adjustments: adj, taken: Number(r.taken), pending: Number(r.pending), balance, available: n2(balance - Number(r.pending)), per_month: Number(s.leave_days_per_month) };
}
export async function requestLeave(db: PoolClient, actor: Actor, perms: Set<string>, b: {
  employee_id: number; type_code?: string; type_id?: number; start_date: string; end_date: string; start_time?: string | null; end_time?: string | null; reason?: string | null; force?: boolean; approve?: boolean;
}, s: Scope) {
  const e = await one<any>(db, 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2', [b.employee_id, actor.hotelId]);
  if (!e) throw notFound('Employé introuvable');
  if (e.status === 'left') throw conflict('Employé sorti.');
  const t = b.type_id ? await one<any>(db, 'SELECT * FROM hr_leave_types WHERE id = $1 AND hotel_id = $2 AND active', [b.type_id, actor.hotelId])
    : await one<any>(db, 'SELECT * FROM hr_leave_types WHERE code = $1 AND hotel_id = $2 AND active', [b.type_code, actor.hotelId]);
  if (!t) throw badRequest('Type de congé inconnu.');
  if (b.end_date < b.start_date) throw badRequest('La date de fin précède la date de début.');
  // les absences injustifiées sont constatées par le responsable, jamais demandées
  if (!t.justified && !(perms.has('hr.manage') || perms.has('hr.team'))) throw forbidden('Absence injustifiée : saisie réservée au responsable.');
  let days = 0, hours = 0;
  if (t.hourly) {
    if (b.end_date !== b.start_date || !b.start_time || !b.end_time || b.end_time <= b.start_time) throw badRequest('Autorisation de sortie : une seule date, heure de début et de fin.');
    hours = n2((minutesOf(b.end_time) - minutesOf(b.start_time)) / 60);
  } else {
    days = await leaveDays(db, actor.hotelId, e.id, b.start_date, b.end_date);
    if (!days) throw badRequest('Aucun jour ouvré dans la période demandée.');
    const ov = await one<any>(db, `SELECT r.number FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id WHERE r.employee_id = $1 AND r.status IN ('pending','approved') AND NOT t.hourly
        AND r.start_date <= $3 AND r.end_date >= $2 LIMIT 1`, [e.id, b.start_date, b.end_date]);
    if (ov) throw conflict(`Chevauchement avec la demande ${ov.number}.`);
  }
  if (t.deducts_balance) {
    const bal = await leaveBalance(db, actor.hotelId, e.id);
    if (days > bal.available && !(b.force && perms.has('hr.manage'))) throw conflict(`Solde insuffisant : ${bal.available} jour(s) disponible(s), ${days} demandé(s).`);
  }
  const n = await nextNumber(db, `cg-${yr()}`);
  const r = await one<any>(db, `INSERT INTO hr_leave_requests (hotel_id, number, employee_id, type_id, start_date, end_date, start_time, end_time, days, hours, reason, requested_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
    [actor.hotelId, `CG${yr()}-${pad(n)}`, e.id, t.id, b.start_date, b.end_date, t.hourly ? b.start_time : null, t.hourly ? b.end_time : null, days, hours, b.reason?.trim() || null, actor.userId]);
  await audit(db, actor, 'leave_request', 'employee', e.id, null, { number: r.number, type: t.code, from: b.start_date, to: b.end_date, days, hours });
  if (b.approve || !t.justified) return decideLeave(db, actor, perms, s, r.id, true, null);
  return r;
}
export async function decideLeave(db: PoolClient, actor: Actor, perms: Set<string>, s: Scope, id: number, approve: boolean, note: string | null) {
  const r = await one<any>(db, 'SELECT r.*, t.code, t.hourly, t.deducts_balance, t.name AS type_name FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id WHERE r.id = $1 AND r.hotel_id = $2 FOR UPDATE OF r', [id, actor.hotelId]);
  if (!r) throw notFound('Demande introuvable');
  if (r.status !== 'pending') throw conflict('Demande déjà traitée.');
  if (!perms.has('hr.manage') && !perms.has('hr.team')) throw forbidden('Validation réservée au responsable.');
  const e = await employeeInScope(db, actor, s, r.employee_id, { team: true });
  if (e.id === s.employeeId && !perms.has('hr.manage')) throw forbidden('Vous ne pouvez pas valider votre propre demande.');
  if (!approve && !note?.trim()) throw badRequest('Motif du refus obligatoire.');
  if (approve && r.deducts_balance) {
    const bal = await leaveBalance(db, actor.hotelId, e.id);
    // la demande elle-même est comptée « en attente »
    if (Number(r.days) > bal.balance && !perms.has('hr.manage')) throw conflict(`Solde insuffisant (${bal.balance} jour(s)).`);
  }
  await db.query(`UPDATE hr_leave_requests SET status = $2, decided_by = $3, decided_at = now(), decision_note = $4 WHERE id = $1`, [id, approve ? 'approved' : 'refused', actor.userId, note ?? null]);
  let removed = 0;
  if (approve && !r.hourly) {
    const sd = String(r.start_date).slice(0, 10), ed = String(r.end_date).slice(0, 10);
    // postes planifiés pendant le congé retirés (planning RH + housekeeping)
    const busy = e.department === 'housekeeping' ? await one<any>(db, `SELECT count(*)::int AS n FROM housekeeping_tasks WHERE assigned_to = $1 AND task_date BETWEEN $2 AND $3 AND status IN ('todo','in_progress')`, [e.id, sd, ed]) : { n: 0 };
    if (busy.n) throw conflict(`${e.first_name} ${e.last_name} a ${busy.n} tâche(s) de ménage affectée(s) pendant le congé : réaffectez-les d'abord.`);
    removed = (await db.query(`DELETE FROM hr_schedule WHERE employee_id = $1 AND work_date BETWEEN $2 AND $3 AND NOT rest`, [e.id, sd, ed])).rowCount ?? 0;
    await db.query(`DELETE FROM hk_shifts WHERE employee_id = $1 AND work_date BETWEEN $2 AND $3 AND started_at IS NULL`, [e.id, sd, ed]);
    // maintenance : technicien indisponible jusqu'à la fin du congé
    await db.query(`UPDATE maintenance_technicians SET available = false, unavailable_reason = $2, unavailable_until = $3 WHERE user_id IN (SELECT id FROM users WHERE employee_id = $1) AND active`,
      [e.id, `${r.type_name} (${r.number})`, ed]);
  }
  await audit(db, actor, approve ? 'leave_approved' : 'leave_refused', 'employee', r.employee_id, { status: 'pending' }, { number: r.number, note, removed_shifts: removed });
  return { ...(await one<any>(db, 'SELECT * FROM hr_leave_requests WHERE id = $1', [id])), removed_shifts: removed };
}

// =====================================================================================================
// Paie
// =====================================================================================================
const periodBounds = (p: string) => { const s = `${p}-01`; const n = new Date(Date.UTC(+p.slice(0, 4), +p.slice(5, 7), 0)).getUTCDate(); return { start: s, end: `${p}-${String(n).padStart(2, '0')}`, days: n }; };
const pct = (baseC: number, rate: number) => Math.round((baseC * Math.round(rate * 1000)) / 100000);
/** Impôt progressif par tranches mensuelles (taux configurés par l'établissement ; aucune valeur légale par défaut). */
export function progressiveTax(taxableC: number, brackets: HrSettings['tax_brackets']) {
  let t = 0;
  for (const b of brackets) {
    const lo = toCents(b.from), hi = b.to === null || b.to === undefined ? Infinity : toCents(b.to);
    if (taxableC > lo) t += pct(Math.min(taxableC, hi) - lo, Number(b.rate));
  }
  return t;
}
/** Jours d'une absence non payée tombant dans le mois. */
async function unpaidInMonth(db: Db, hotelId: number, employeeId: number, start: string, end: string) {
  const rows = await q<any>(db, `SELECT r.*, t.hourly FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id
      WHERE r.employee_id = $1 AND r.status = 'approved' AND NOT t.paid AND r.start_date <= $3 AND r.end_date >= $2`, [employeeId, start, end]);
  let days = 0, hours = 0;
  for (const r of rows) {
    if (r.hourly) { hours += Number(r.hours); continue; }
    const a = String(r.start_date).slice(0, 10) < start ? start : String(r.start_date).slice(0, 10);
    const b = String(r.end_date).slice(0, 10) > end ? end : String(r.end_date).slice(0, 10);
    days += await leaveDays(db, hotelId, employeeId, a, b);
  }
  return { days, hours };
}
export async function computePayslip(db: Db, hotelId: number, e: any, period: string, s: HrSettings) {
  const { start, end, days: mdays } = periodBounds(period);
  const baseC = toCents(e.base_salary ?? 0);
  const divisor = Number(s.day_divisor) || 30;
  const hourlyC = Math.round(baseC / (Number(s.monthly_hours) || 173.33));
  const lines: any[] = [];
  // entrée / sortie en cours de mois : jours calendaires hors contrat, ramenés au diviseur
  const hire = e.hire_date ? String(e.hire_date).slice(0, 10) : null, exit = e.exit_date ? String(e.exit_date).slice(0, 10) : null;
  let outside = 0;
  if (hire && hire > start) outside += Math.round((Date.parse(hire) - Date.parse(start)) / 86400000);
  if (exit && exit < end) outside += Math.round((Date.parse(end) - Date.parse(exit)) / 86400000);
  const outsideDays = n2((Math.min(outside, mdays) * divisor) / mdays);
  const un = await unpaidInMonth(db, hotelId, e.id, hire && hire > start ? hire : start, exit && exit < end ? exit : end);
  const absenceDays = Math.min(divisor, n2(outsideDays + un.days));
  let absC = Math.round((baseC * absenceDays) / divisor) + hourlyC * un.hours;
  absC = Math.min(absC, baseC);
  if (absC) lines.push({ code: 'ABS', label: `Absences non rémunérées (${absenceDays} j${un.hours ? ` + ${un.hours} h` : ''})`, kind: 'deduction_gross', amount: -fromCents(absC) });
  const ot = await one<any>(db, `SELECT COALESCE(sum(overtime_minutes),0)::int AS m FROM hr_attendance WHERE employee_id = $1 AND work_date BETWEEN $2 AND $3`, [e.id, start, end]);
  const otC = Math.round((hourlyC * ot.m * (100 + Number(s.overtime_rate_percent))) / 6000);
  if (otC) lines.push({ code: 'HS', label: `Heures supplémentaires (${Math.floor(ot.m / 60)} h ${String(ot.m % 60).padStart(2, '0')}, majoration ${s.overtime_rate_percent} %)`, kind: 'gain', amount: fromCents(otC) });
  const items = await q<any>(db, `SELECT * FROM hr_pay_items WHERE employee_id = $1 AND active AND ((NOT recurring AND period = $2) OR (recurring AND (start_period IS NULL OR start_period <= $2) AND (end_period IS NULL OR end_period >= $2))) ORDER BY id`, [e.id, period]);
  let gainC = 0, nonContribC = 0, nonTaxC = 0, dedC = 0;
  for (const it of items) {
    const a = toCents(it.amount);
    if (it.kind === 'deduction') { dedC += a; lines.push({ code: 'RET', label: it.label, kind: 'deduction', amount: -fromCents(a) }); continue; }
    gainC += a;
    if (!it.contributory) nonContribC += a;
    if (!it.taxable) nonTaxC += a;
    lines.push({ code: it.kind === 'bonus' ? 'PRI' : 'IND', label: it.label, kind: 'gain', amount: fromCents(a), taxable: it.taxable, contributory: it.contributory });
  }
  const grossC = baseC - absC + otC + gainC;
  const contribBaseC = grossC - nonContribC;
  let empC = 0, emplrC = 0;
  for (const c of s.contributions ?? []) {
    const a = pct(contribBaseC, Number(c.rate));
    if (c.side === 'employee') { empC += a; lines.push({ code: c.code, label: `${c.label} (${c.rate} %)`, kind: 'contribution', amount: -fromCents(a) }); }
    else { emplrC += a; lines.push({ code: c.code, label: `${c.label} (${c.rate} %) — part employeur`, kind: 'employer', amount: fromCents(a) }); }
  }
  const taxableC = grossC - empC - nonTaxC;
  const taxC = progressiveTax(taxableC, s.tax_brackets ?? []);
  if (taxC) lines.push({ code: 'IMP', label: 'Impôt sur le revenu', kind: 'tax', amount: -fromCents(taxC) });
  // avances : échéance du mois
  let advC = 0;
  const advances: { id: number; amount: number }[] = [];
  for (const a of await q<any>(db, `SELECT * FROM hr_advances WHERE employee_id = $1 AND status = 'open' AND first_period <= $2 ORDER BY id`, [e.id, period])) {
    const rest = toCents(a.amount) - toCents(a.repaid);
    const inst = Math.min(rest, Math.ceil(toCents(a.amount) / a.installments));
    if (inst > 0) { advC += inst; advances.push({ id: a.id, amount: fromCents(inst) }); lines.push({ code: 'AVA', label: `Remboursement avance du ${String(a.advance_date).slice(0, 10)}`, kind: 'advance', amount: -fromCents(inst) }); }
  }
  const netC = grossC - empC - taxC - dedC - advC;
  return {
    base_salary: fromCents(baseC), paid_days: n2(divisor - absenceDays), absence_days: absenceDays, absence_deduction: fromCents(absC), overtime_minutes: ot.m, overtime_amount: fromCents(otC),
    lines, gross: fromCents(grossC), contributory_base: fromCents(contribBaseC), employee_contrib: fromCents(empC), taxable: fromCents(taxableC), tax: fromCents(taxC),
    deductions: fromCents(dedC), advances: fromCents(advC), net: fromCents(netC), employer_contrib: fromCents(emplrC), _advances: advances,
  };
}
export async function computePayroll(db: PoolClient, actor: Actor, period: string) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(period)) throw badRequest('Période invalide (AAAA-MM).');
  if (period > today().slice(0, 7)) throw badRequest('Période future.');
  const s = await hrSettings(db, actor.hotelId);
  const { start, end } = periodBounds(period);
  let run = await one<any>(db, `SELECT * FROM hr_payroll_runs WHERE hotel_id = $1 AND period = $2 AND status <> 'cancelled' FOR UPDATE`, [actor.hotelId, period]);
  if (run && run.status !== 'draft') throw conflict(`Paie ${period} déjà ${run.status === 'paid' ? 'payée' : 'validée'} : recalcul impossible.`);
  const warnings: string[] = [];
  if (!(s.contributions ?? []).length) warnings.push('Aucune cotisation sociale configurée : renseignez les taux en vigueur dans les paramètres RH.');
  if (!(s.tax_brackets ?? []).length) warnings.push('Barème de l\'impôt sur le revenu non configuré : aucun impôt calculé.');
  if (!run) run = await one<any>(db, `INSERT INTO hr_payroll_runs (hotel_id, period) VALUES ($1,$2) RETURNING *`, [actor.hotelId, period]);
  await db.query('DELETE FROM hr_payslips WHERE run_id = $1', [run.id]);
  const emps = await q<any>(db, `SELECT * FROM employees WHERE hotel_id = $1 AND (hire_date IS NULL OR hire_date <= $3) AND (status <> 'left' OR exit_date >= $2) ORDER BY matricule`, [actor.hotelId, start, end]);
  let gross = 0, net = 0, emplr = 0, i = 0;
  for (const e of emps) {
    if (!Number(e.base_salary)) { warnings.push(`${e.matricule} ${e.last_name} ${e.first_name} : salaire de base non renseigné — exclu.`); continue; }
    const p = await computePayslip(db, actor.hotelId, e, period, s);
    if (p.net < 0) warnings.push(`${e.matricule} ${e.last_name} : net négatif (${p.net}).`);
    const { _advances, ...row } = p;
    await db.query(`INSERT INTO hr_payslips (run_id, employee_id, number, matricule, full_name, department, position, base_salary, paid_days, absence_days, absence_deduction, overtime_minutes, overtime_amount, lines, gross,
        contributory_base, employee_contrib, taxable, tax, deductions, advances, net, employer_contrib) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23)`,
    [run.id, e.id, `BP${period.replace('-', '')}-${pad(++i)}`, e.matricule, `${e.last_name} ${e.first_name}`, e.department, e.position, row.base_salary, row.paid_days, row.absence_days, row.absence_deduction,
      row.overtime_minutes, row.overtime_amount, JSON.stringify(row.lines), row.gross, row.contributory_base, row.employee_contrib, row.taxable, row.tax, row.deductions, row.advances, row.net, row.employer_contrib]);
    gross += toCents(row.gross); net += toCents(row.net); emplr += toCents(row.employer_contrib);
  }
  await db.query(`UPDATE hr_payroll_runs SET gross_total = $2, net_total = $3, employer_total = $4, warnings = $5, rules = $6, computed_by = $7, computed_at = now() WHERE id = $1`,
    [run.id, fromCents(gross), fromCents(net), fromCents(emplr), JSON.stringify(warnings), JSON.stringify(s), actor.userId]);
  await audit(db, actor, 'payroll_compute', 'hr_payroll', run.id, null, { period, employees: i, gross: fromCents(gross), net: fromCents(net) });
  return one<any>(db, 'SELECT * FROM hr_payroll_runs WHERE id = $1', [run.id]);
}
export async function validatePayroll(db: PoolClient, actor: Actor, id: number) {
  const run = await one<any>(db, 'SELECT * FROM hr_payroll_runs WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!run) throw notFound('Paie introuvable');
  if (run.status !== 'draft') throw conflict('Paie déjà validée.');
  if (run.computed_by === actor.userId && !(await one(db, `SELECT 1 FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1 AND r.code IN ('admin','manager')`, [actor.userId]))) {
    throw forbidden('Contrôle croisé : la paie doit être validée par une autre personne que celle qui l\'a calculée.');
  }
  const slips = await q<any>(db, 'SELECT * FROM hr_payslips WHERE run_id = $1', [id]);
  if (!slips.length) throw conflict('Aucun bulletin à valider.');
  // remboursements d'avances imputés définitivement
  const s = run.rules as HrSettings;
  for (const p of slips) {
    if (!Number(p.advances)) continue;
    const e = await one<any>(db, 'SELECT * FROM employees WHERE id = $1', [p.employee_id]);
    const calc = await computePayslip(db, actor.hotelId, e, run.period, s);
    for (const a of calc._advances) {
      await db.query('INSERT INTO hr_advance_repayments (advance_id, payslip_id, amount) VALUES ($1,$2,$3)', [a.id, p.id, a.amount]);
      await db.query(`UPDATE hr_advances SET repaid = repaid + $2, status = CASE WHEN repaid + $2 >= amount THEN 'repaid' ELSE status END WHERE id = $1`, [a.id, a.amount]);
    }
  }
  await db.query(`UPDATE hr_payroll_runs SET status = 'validated', validated_by = $2, validated_at = now() WHERE id = $1`, [id, actor.userId]);
  await audit(db, actor, 'payroll_validate', 'hr_payroll', id, { status: 'draft' }, { status: 'validated', period: run.period, net: run.net_total });
}
/** Paiement des salaires : dépense « Salaires » dans Facturation & Caisse. */
export async function payPayroll(db: PoolClient, actor: Actor, id: number, method: 'cash' | 'cheque' | 'transfer', reference?: string | null) {
  const run = await one<any>(db, 'SELECT * FROM hr_payroll_runs WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!run) throw notFound('Paie introuvable');
  if (run.status !== 'validated') throw conflict('Validez la paie avant de la payer.');
  const s = await hrSettings(db, actor.hotelId);
  const { addExpense } = await import('./cash.js');
  const exp = await addExpense(db, actor, { category: s.payroll_category, description: `Salaires ${run.period} (net à payer)`, amount: Number(run.net_total), method, reference: reference ?? `PAIE-${run.period}` });
  await db.query(`UPDATE hr_payroll_runs SET status = 'paid', paid_by = $2, paid_at = now(), expense_id = $3 WHERE id = $1`, [id, actor.userId, exp.id]);
  await audit(db, actor, 'payroll_paid', 'hr_payroll', id, { status: 'validated' }, { status: 'paid', expense_id: exp.id, amount: run.net_total, method });
  return exp;
}
export async function giveAdvance(db: PoolClient, actor: Actor, b: { employee_id: number; amount: number; installments: number; first_period: string; method: 'cash' | 'cheque' | 'transfer'; reason?: string | null }) {
  const e = await one<any>(db, 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2', [b.employee_id, actor.hotelId]);
  if (!e) throw notFound('Employé introuvable');
  if (e.status === 'left') throw conflict('Employé sorti.');
  if (!/^\d{4}-\d{2}$/.test(b.first_period) || b.first_period < today().slice(0, 7)) throw badRequest('Première retenue : mois en cours ou suivant.');
  const open = await one<any>(db, `SELECT COALESCE(sum(amount - repaid),0) AS r FROM hr_advances WHERE employee_id = $1 AND status = 'open'`, [e.id]);
  if (Number(e.base_salary) && toCents(open.r) + toCents(b.amount) > toCents(e.base_salary)) throw conflict(`Avances cumulées supérieures au salaire de base (${Number(open.r)} ${currency.symbol} déjà en cours).`);
  const s = await hrSettings(db, actor.hotelId);
  const { addExpense } = await import('./cash.js');
  const exp = await addExpense(db, actor, { category: s.advance_category, description: `Avance sur salaire — ${e.matricule} ${e.last_name} ${e.first_name}`, amount: b.amount, method: b.method, reference: e.matricule });
  const a = await one<any>(db, `INSERT INTO hr_advances (hotel_id, employee_id, advance_date, amount, installments, first_period, method, expense_id, reason, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [actor.hotelId, e.id, today(), b.amount, b.installments, b.first_period, b.method, exp.id, b.reason ?? null, actor.userId]);
  await audit(db, actor, 'advance', 'employee', e.id, null, { amount: b.amount, installments: b.installments, expense_id: exp.id });
  return a;
}

// =====================================================================================================
// Alertes, tableau de bord
// =====================================================================================================
export async function hrAlerts(db: Db, hotelId: number, s: Scope) {
  const st = await hrSettings(db, hotelId);
  const t = today();
  const sc = scopeSql(s, 'e', 2);
  const P = [hotelId, ...sc.params];
  const out: { level: 'danger' | 'warning' | 'info'; code: string; message: string; ref?: any }[] = [];
  for (const e of await q<any>(db, `SELECT e.*, c.number FROM employees e LEFT JOIN hr_contracts c ON c.employee_id = e.id AND c.status = 'active'
      WHERE e.hotel_id = $1 AND ${sc.sql} AND e.status <> 'left' AND e.contract_end IS NOT NULL AND e.contract_end <= $${P.length + 1}::date + $${P.length + 2}::int ORDER BY e.contract_end`, [...P, t, st.contract_alert_days])) {
    const d = String(e.contract_end).slice(0, 10);
    out.push({ level: d < t ? 'danger' : 'warning', code: 'contract', message: `${d < t ? 'Contrat expiré' : 'Contrat à renouveler'} : ${e.last_name} ${e.first_name} (${e.matricule}) — fin le ${d}`, ref: { employee_id: e.id } });
  }
  for (const d of await q<any>(db, `SELECT d.*, e.first_name, e.last_name, e.matricule FROM hr_documents d JOIN employees e ON e.id = d.employee_id
      WHERE d.hotel_id = $1 AND ${sc.sql} AND e.status <> 'left' AND d.expiry_date IS NOT NULL AND d.expiry_date <= $${P.length + 1}::date + $${P.length + 2}::int ORDER BY d.expiry_date`, [...P, t, st.document_alert_days])) {
    const x = String(d.expiry_date).slice(0, 10);
    out.push({ level: x < t ? 'danger' : 'warning', code: 'document', message: `${x < t ? 'Document expiré' : 'Document à renouveler'} : ${d.title} — ${d.last_name} ${d.first_name} (${x})`, ref: { employee_id: d.employee_id } });
  }
  const pend = await one<any>(db, `SELECT count(*)::int AS n FROM hr_leave_requests r JOIN employees e ON e.id = r.employee_id WHERE r.hotel_id = $1 AND ${sc.sql} AND r.status = 'pending'`, P);
  if (pend.n) out.push({ level: 'info', code: 'leave_pending', message: `${pend.n} demande(s) de congé à traiter` });
  const corr = await one<any>(db, `SELECT count(*)::int AS n FROM hr_attendance_corrections c JOIN employees e ON e.id = c.employee_id WHERE c.hotel_id = $1 AND ${sc.sql} AND c.status = 'pending'`, P);
  if (corr.n) out.push({ level: 'info', code: 'correction_pending', message: `${corr.n} correction(s) de pointage à autoriser` });
  const swaps = await one<any>(db, `SELECT count(*)::int AS n FROM hr_shift_swaps w JOIN employees e ON e.id = w.requester_id WHERE w.hotel_id = $1 AND ${sc.sql} AND w.status = 'pending'`, P);
  if (swaps.n) out.push({ level: 'info', code: 'swap_pending', message: `${swaps.n} échange(s) de poste à valider` });
  // absents sans justificatif : poste planifié aujourd'hui commencé depuis plus d'une heure, sans pointage ni congé
  for (const x of await q<any>(db, `SELECT e.id, e.first_name, e.last_name, sh.start_time FROM hr_schedule sh JOIN employees e ON e.id = sh.employee_id
      WHERE sh.hotel_id = $1 AND ${sc.sql} AND sh.work_date = $${P.length + 1} AND NOT sh.rest AND e.status = 'active'
        AND (($${P.length + 1}::date + sh.start_time) AT TIME ZONE '${TZ}') < now() - interval '1 hour'
        AND NOT EXISTS (SELECT 1 FROM hr_attendance a WHERE a.employee_id = e.id AND a.work_date = sh.work_date AND a.clock_in IS NOT NULL)
        AND NOT EXISTS (SELECT 1 FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id WHERE r.employee_id = e.id AND r.status = 'approved' AND NOT t.hourly AND sh.work_date BETWEEN r.start_date AND r.end_date)`, [...P, t])) {
    out.push({ level: 'warning', code: 'no_show', message: `Absent non justifié : ${x.last_name} ${x.first_name} (poste de ${String(x.start_time).slice(0, 5)})`, ref: { employee_id: x.id } });
  }
  return out;
}
export const EFFECTIVE_STATUS = (alias = 'e') => `CASE WHEN ${alias}.status = 'active' AND EXISTS (SELECT 1 FROM hr_leave_requests lr JOIN hr_leave_types lt ON lt.id = lr.type_id
  WHERE lr.employee_id = ${alias}.id AND lr.status = 'approved' AND NOT lt.hourly AND (now() AT TIME ZONE '${TZ}')::date BETWEEN lr.start_date AND lr.end_date) THEN 'leave' ELSE ${alias}.status END`;

export async function hrDashboard(db: Db, hotelId: number, s: Scope) {
  const t = today();
  const sc = scopeSql(s, 'e', 2);
  const P = [hotelId, ...sc.params];
  const k = await one<any>(db, `SELECT count(*)::int AS total, count(*) FILTER (WHERE x.st = 'active')::int AS active, count(*) FILTER (WHERE x.st = 'leave')::int AS on_leave,
      count(*) FILTER (WHERE x.st = 'suspended')::int AS suspended, count(*) FILTER (WHERE x.st = 'left')::int AS left_
     FROM (SELECT ${EFFECTIVE_STATUS('e')} AS st FROM employees e WHERE e.hotel_id = $1 AND ${sc.sql}) x`, P);
  const att = await one<any>(db, `SELECT count(*) FILTER (WHERE a.clock_in IS NOT NULL)::int AS present, count(*) FILTER (WHERE a.clock_in IS NOT NULL AND a.clock_out IS NULL)::int AS on_site,
      count(*) FILTER (WHERE a.late_minutes > 0)::int AS late FROM hr_attendance a JOIN employees e ON e.id = a.employee_id WHERE a.hotel_id = $1 AND ${sc.sql} AND a.work_date = $${P.length + 1}`, [...P, t]);
  const sched = await one<any>(db, `SELECT count(*) FILTER (WHERE NOT sh.rest)::int AS scheduled,
      count(*) FILTER (WHERE NOT sh.rest AND e.status = 'active' AND ((sh.work_date + sh.start_time) AT TIME ZONE '${TZ}') < now()
        AND NOT EXISTS (SELECT 1 FROM hr_attendance a WHERE a.employee_id = sh.employee_id AND a.work_date = sh.work_date AND a.clock_in IS NOT NULL)
        AND NOT EXISTS (SELECT 1 FROM hr_leave_requests r JOIN hr_leave_types lt ON lt.id = r.type_id WHERE r.employee_id = sh.employee_id AND r.status = 'approved' AND NOT lt.hourly AND sh.work_date BETWEEN r.start_date AND r.end_date))::int AS absent
     FROM hr_schedule sh JOIN employees e ON e.id = sh.employee_id WHERE sh.hotel_id = $1 AND ${sc.sql} AND sh.work_date = $${P.length + 1}`, [...P, t]);
  const contracts = await one<any>(db, `SELECT count(*)::int AS n FROM employees e WHERE e.hotel_id = $1 AND ${sc.sql} AND e.status <> 'left' AND e.contract_end BETWEEN $${P.length + 1}::date AND $${P.length + 1}::date + 30`, [...P, t]);
  const birthdays = await q<any>(db, `SELECT e.id, e.first_name, e.last_name, e.department, to_char(e.birth_date, 'DD/MM') AS day FROM employees e WHERE e.hotel_id = $1 AND ${sc.sql} AND e.status <> 'left'
      AND extract(month FROM e.birth_date) = extract(month FROM $${P.length + 1}::date) ORDER BY extract(day FROM e.birth_date)`, [...P, t]);
  const byDept = await q<any>(db, `SELECT COALESCE(d.name, e.department, '—') AS department, e.department AS code, count(*)::int AS n FROM employees e LEFT JOIN hr_departments d ON d.hotel_id = e.hotel_id AND d.code = e.department
      WHERE e.hotel_id = $1 AND ${sc.sql} AND e.status <> 'left' GROUP BY 1, 2 ORDER BY n DESC`, P);
  const payroll = s.salary ? await one<any>(db, `SELECT COALESCE(sum(e.base_salary),0) AS base FROM employees e WHERE e.hotel_id = $1 AND ${sc.sql} AND e.status IN ('active','suspended')`, P) : null;
  const lastRun = s.salary ? await one<any>(db, `SELECT period, status, gross_total, net_total, employer_total FROM hr_payroll_runs WHERE hotel_id = $1 AND status <> 'cancelled' ORDER BY period DESC LIMIT 1`, [hotelId]) : null;
  const absent = sched.absent;
  return {
    kpi: { ...k, present: att.present, on_site: att.on_site, late: att.late, scheduled: sched.scheduled, absent, contracts_expiring: contracts.n, birthdays: birthdays.length, payroll_base: payroll ? n2(payroll.base) : null },
    birthdays, by_department: byDept, last_payroll: lastRun, alerts: await hrAlerts(db, hotelId, s),
  };
}

// =====================================================================================================
// Rapports
// =====================================================================================================
const c = (key: string, label: string, money = false) => ({ key, label, money });
export const HR_REPORTS: Record<string, { title: string; columns: any[]; salary?: boolean }> = {
  headcount: { title: 'Effectifs par département', columns: [c('department', 'Département'), c('active', 'Actifs'), c('leave', 'En congé'), c('suspended', 'Suspendus'), c('left', 'Sortis (période)'), c('hired', 'Embauches (période)')] },
  attendance: { title: 'Présences et absences', columns: [c('matricule', 'Matricule'), c('name', 'Employé'), c('department', 'Département'), c('scheduled', 'Jours planifiés'), c('present', 'Jours présents'), c('absent', 'Absences non justifiées'), c('leave', 'Jours de congé'), c('hours', 'Heures travaillées')] },
  late: { title: 'Retards', columns: [c('date', 'Date'), c('matricule', 'Matricule'), c('name', 'Employé'), c('department', 'Département'), c('scheduled', 'Prévu'), c('clock_in', 'Arrivée'), c('late', 'Retard (min)')] },
  overtime: { title: 'Heures supplémentaires', columns: [c('matricule', 'Matricule'), c('name', 'Employé'), c('department', 'Département'), c('days', 'Jours concernés'), c('hours', 'Heures sup.')] },
  leave: { title: 'Congés et absences', columns: [c('number', 'N°'), c('name', 'Employé'), c('type', 'Type'), c('from', 'Du'), c('to', 'Au'), c('days', 'Jours'), c('hours', 'Heures'), c('status', 'Statut'), c('decided_by', 'Décision par')] },
  payroll: { title: 'Masse salariale', salary: true, columns: [c('period', 'Mois'), c('employees', 'Salariés'), c('gross', 'Brut', true), c('employee_contrib', 'Cotisations salariales', true), c('tax', 'Impôt', true), c('net', 'Net', true), c('employer', 'Charges patronales', true), c('cost', 'Coût total', true), c('status', 'Statut')] },
  contracts: { title: 'Contrats expirés ou à renouveler', columns: [c('matricule', 'Matricule'), c('name', 'Employé'), c('department', 'Département'), c('kind', 'Type'), c('number', 'Contrat'), c('start', 'Début'), c('end', 'Fin'), c('days', 'Jours restants')] },
  performance: { title: 'Performance du personnel', columns: [c('matricule', 'Matricule'), c('name', 'Employé'), c('department', 'Département'), c('evaluations', 'Évaluations'), c('last', 'Dernière note /5'), c('avg', 'Moyenne /5'), c('trainings', 'Formations suivies'), c('late', 'Retards (période)')] },
};
const STATUS_LEAVE: Record<string, string> = { pending: 'En attente', approved: 'Validée', refused: 'Refusée', cancelled: 'Annulée' };
export async function hrReport(db: Db, hotelId: number, s: Scope, kind: string, from: string, to: string) {
  const def = HR_REPORTS[kind];
  if (!def) throw notFound('Rapport inconnu');
  if (def.salary && !s.salary) throw forbidden('Rapport réservé aux personnes habilitées à voir les salaires.');
  const sc = scopeSql(s, 'e', 4);
  const P = [hotelId, from, to, ...sc.params];
  const dn = `COALESCE((SELECT name FROM hr_departments d WHERE d.hotel_id = e.hotel_id AND d.code = e.department), e.department, '')`;
  let rows: any[] = [];
  let total: any = null;
  if (kind === 'headcount') {
    rows = await q<any>(db, `SELECT ${dn} AS department, count(*) FILTER (WHERE x.st = 'active')::int AS active, count(*) FILTER (WHERE x.st = 'leave')::int AS leave,
        count(*) FILTER (WHERE x.st = 'suspended')::int AS suspended, count(*) FILTER (WHERE e.status = 'left' AND e.exit_date BETWEEN $2 AND $3)::int AS left,
        count(*) FILTER (WHERE e.hire_date BETWEEN $2 AND $3)::int AS hired
       FROM employees e CROSS JOIN LATERAL (SELECT ${EFFECTIVE_STATUS('e')} AS st) x WHERE e.hotel_id = $1 AND ${sc.sql} GROUP BY 1 ORDER BY 1`, P);
    total = ['active', 'leave', 'suspended', 'left', 'hired'].reduce((a, k) => ({ ...a, [k]: rows.reduce((t, r) => t + r[k], 0) }), { department: 'Total' });
  } else if (kind === 'attendance') {
    rows = (await q<any>(db, `SELECT e.matricule, e.last_name || ' ' || e.first_name AS name, ${dn} AS department,
        (SELECT count(*) FROM hr_schedule sh WHERE sh.employee_id = e.id AND NOT sh.rest AND sh.work_date BETWEEN $2 AND LEAST($3::date, CURRENT_DATE))::int AS scheduled,
        (SELECT count(*) FROM hr_attendance a WHERE a.employee_id = e.id AND a.clock_in IS NOT NULL AND a.work_date BETWEEN $2 AND $3)::int AS present,
        (SELECT count(*) FROM hr_schedule sh WHERE sh.employee_id = e.id AND NOT sh.rest AND sh.work_date BETWEEN $2 AND LEAST($3::date, CURRENT_DATE - 1)
           AND NOT EXISTS (SELECT 1 FROM hr_attendance a WHERE a.employee_id = e.id AND a.work_date = sh.work_date AND a.clock_in IS NOT NULL)
           AND NOT EXISTS (SELECT 1 FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id WHERE r.employee_id = e.id AND r.status = 'approved' AND t.justified AND NOT t.hourly AND sh.work_date BETWEEN r.start_date AND r.end_date))::int AS absent,
        COALESCE((SELECT sum(LEAST(r.end_date, $3::date) - GREATEST(r.start_date, $2::date) + 1) FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id WHERE r.employee_id = e.id AND r.status = 'approved' AND NOT t.hourly AND r.start_date <= $3 AND r.end_date >= $2), 0)::int AS leave,
        COALESCE((SELECT sum(worked_minutes) FROM hr_attendance a WHERE a.employee_id = e.id AND a.work_date BETWEEN $2 AND $3), 0)::int AS minutes
       FROM employees e WHERE e.hotel_id = $1 AND ${sc.sql} AND (e.status <> 'left' OR e.exit_date >= $2) ORDER BY department, name`, P)).map((r) => ({ ...r, hours: Math.round((r.minutes / 60) * 10) / 10 }));
  } else if (kind === 'late') {
    rows = (await q<any>(db, `SELECT a.*, e.matricule, e.last_name || ' ' || e.first_name AS name, ${dn} AS department FROM hr_attendance a JOIN employees e ON e.id = a.employee_id
       WHERE a.hotel_id = $1 AND a.work_date BETWEEN $2 AND $3 AND a.late_minutes > 0 AND ${sc.sql} ORDER BY a.work_date, name`, P)).map((a) => ({
      date: String(a.work_date).slice(0, 10), matricule: a.matricule, name: a.name, department: a.department,
      scheduled: a.scheduled_start ? new Date(a.scheduled_start).toLocaleTimeString('fr-FR', { timeZone: TZ, hour: '2-digit', minute: '2-digit' }) : '',
      clock_in: new Date(a.clock_in).toLocaleTimeString('fr-FR', { timeZone: TZ, hour: '2-digit', minute: '2-digit' }), late: a.late_minutes }));
    total = { date: 'Total', late: rows.reduce((t, r) => t + r.late, 0) };
  } else if (kind === 'overtime') {
    rows = (await q<any>(db, `SELECT e.matricule, e.last_name || ' ' || e.first_name AS name, ${dn} AS department, count(*)::int AS days, sum(a.overtime_minutes)::int AS minutes
       FROM hr_attendance a JOIN employees e ON e.id = a.employee_id WHERE a.hotel_id = $1 AND a.work_date BETWEEN $2 AND $3 AND a.overtime_minutes > 0 AND ${sc.sql} GROUP BY e.id ORDER BY minutes DESC`, P))
      .map((r) => ({ ...r, hours: Math.round((r.minutes / 60) * 100) / 100 }));
    total = { matricule: 'Total', hours: Math.round(rows.reduce((t, r) => t + r.minutes, 0) / 0.6) / 100 };
  } else if (kind === 'leave') {
    rows = (await q<any>(db, `SELECT r.*, t.name AS type, e.last_name || ' ' || e.first_name AS name, u.full_name AS decided FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id JOIN employees e ON e.id = r.employee_id
        LEFT JOIN users u ON u.id = r.decided_by WHERE r.hotel_id = $1 AND r.start_date <= $3 AND r.end_date >= $2 AND ${sc.sql} ORDER BY r.start_date`, P)).map((r) => ({
      number: r.number, name: r.name, type: r.type, from: String(r.start_date).slice(0, 10), to: String(r.end_date).slice(0, 10), days: Number(r.days), hours: Number(r.hours) || '', status: STATUS_LEAVE[r.status], decided_by: r.decided ?? '' }));
  } else if (kind === 'payroll') {
    rows = (await q<any>(db, `SELECT r.period, r.status, count(p.id)::int AS employees, COALESCE(sum(p.gross),0) AS gross, COALESCE(sum(p.employee_contrib),0) AS employee_contrib, COALESCE(sum(p.tax),0) AS tax,
        COALESCE(sum(p.net),0) AS net, COALESCE(sum(p.employer_contrib),0) AS employer FROM hr_payroll_runs r LEFT JOIN hr_payslips p ON p.run_id = r.id
       WHERE r.hotel_id = $1 AND r.status <> 'cancelled' AND r.period BETWEEN substr($2::text, 1, 7) AND substr($3::text, 1, 7) GROUP BY r.id ORDER BY r.period`, [hotelId, from, to])).map((r) => ({
      ...r, gross: n2(r.gross), employee_contrib: n2(r.employee_contrib), tax: n2(r.tax), net: n2(r.net), employer: n2(r.employer), cost: n2(Number(r.gross) + Number(r.employer)),
      status: ({ draft: 'Brouillon', validated: 'Validée', paid: 'Payée' } as any)[r.status] }));
    total = ['gross', 'employee_contrib', 'tax', 'net', 'employer', 'cost'].reduce((a, k) => ({ ...a, [k]: n2(rows.reduce((t, r) => t + r[k], 0)) }), { period: 'Total' });
  } else if (kind === 'contracts') {
    const t = today();
    rows = (await q<any>(db, `SELECT e.*, c.number, ${dn} AS dname FROM employees e LEFT JOIN hr_contracts c ON c.employee_id = e.id AND c.status = 'active'
       WHERE e.hotel_id = $1 AND ${sc.sql} AND e.status <> 'left' AND e.contract_end IS NOT NULL AND e.contract_end <= $3::date + 60 AND $2::date IS NOT NULL ORDER BY e.contract_end`, P)).map((e) => {
      const end = String(e.contract_end).slice(0, 10);
      return { matricule: e.matricule, name: `${e.last_name} ${e.first_name}`, department: e.dname, kind: CONTRACT_LABEL[e.contract_type] ?? e.contract_type ?? '', number: e.number ?? '',
        start: e.contract_start ? String(e.contract_start).slice(0, 10) : '', end, days: Math.round((Date.parse(end) - Date.parse(t)) / 86400000) };
    });
  } else if (kind === 'performance') {
    rows = (await q<any>(db, `SELECT e.matricule, e.last_name || ' ' || e.first_name AS name, ${dn} AS department,
        (SELECT count(*) FROM hr_evaluations v WHERE v.employee_id = e.id AND v.status = 'final')::int AS evaluations,
        (SELECT v.score FROM hr_evaluations v WHERE v.employee_id = e.id AND v.status = 'final' ORDER BY v.eval_date DESC, v.id DESC LIMIT 1) AS last,
        (SELECT round(avg(v.score), 2) FROM hr_evaluations v WHERE v.employee_id = e.id AND v.status = 'final') AS avg,
        (SELECT count(*) FROM hr_trainings t WHERE t.employee_id = e.id AND t.status = 'done')::int AS trainings,
        (SELECT count(*) FROM hr_attendance a WHERE a.employee_id = e.id AND a.late_minutes > 0 AND a.work_date BETWEEN $2 AND $3)::int AS late
       FROM employees e WHERE e.hotel_id = $1 AND ${sc.sql} AND e.status <> 'left' ORDER BY avg DESC NULLS LAST, name`, P)).map((r) => ({ ...r, last: r.last === null ? '' : Number(r.last), avg: r.avg === null ? '' : Number(r.avg) }));
  }
  return { kind, title: def.title, from, to, columns: def.columns, rows, total };
}
export { monthStart };
