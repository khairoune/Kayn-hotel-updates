/**
 * Rapport mensuel de direction (PDF) envoyé automatiquement par e-mail le 1er du mois (à partir de 7 h) pour le mois écoulé.
 * Chiffres calculés depuis la base (mêmes règles que le tableau de bord) ; envoi via le serveur e-mail configuré (Gmail…).
 * Sans Internet : nouvel essai à chaque passage du planificateur (15 min), jusqu'à 20 essais ; jamais deux envois automatiques pour le même mois.
 */
import PDFDocument from 'pdfkit';
import { getPool, one, q } from '../db/pool.js';
import { badRequest } from '../lib/errors.js';
import { BALANCE_EXPR, FIN_SQL, getSettings } from './common.js';
import { currency } from './exports.js';
import { smtpError, smtpTransport } from './notifications.js';

const r2 = (n: number) => Math.round(n * 100) / 100;
const MONTHS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
export const monthLabel = (m: string) => `${MONTHS[Number(m.slice(5, 7)) - 1]} ${m.slice(0, 4)}`;
const PM: Record<string, string> = { cash: 'Espèces', card: 'Carte bancaire', cheque: 'Chèque', transfer: 'Virement', company_account: 'Compte société', online: 'Paiement en ligne' };
const money = (n: number) => `${(Math.round(n * 100) / 100).toFixed(currency.decimals).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} ${currency.symbol}`;
export const prevMonth = (m: string) => { const [y, mo] = m.split('-').map(Number); return mo === 1 ? `${y - 1}-12` : `${y}-${String(mo - 1).padStart(2, '0')}`; };
const bounds = (m: string) => { const [y, mo] = m.split('-').map(Number); const days = new Date(Date.UTC(y, mo, 0)).getUTCDate(); return { from: `${m}-01`, to: `${m}-${String(days).padStart(2, '0')}`, days }; };

/** Chiffres d'un mois (YYYY-MM). */
export async function monthFigures(hotelId: number, m: string) {
  const db = getPool();
  const tz = currency.tz;
  const { from, to, days } = bounds(m);
  const sellable = (await one<any>(db, `SELECT count(*) FILTER (WHERE NOT out_of_service)::int AS n FROM rooms WHERE hotel_id = $1 AND active`, [hotelId])).n || 0;
  const rooms = await one<any>(db, `SELECT
      COALESCE(sum(rr.rate * (LEAST(rr.check_out, $3::date + 1) - GREATEST(rr.check_in, $2::date))), 0) AS revenue,
      COALESCE(sum(LEAST(rr.check_out, $3::date + 1) - GREATEST(rr.check_in, $2::date)), 0)::int AS nights
    FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id
   WHERE r.hotel_id = $1 AND rr.status IN ('checked_in','checked_out') AND rr.check_in <= $3 AND rr.check_out > $2`, [hotelId, from, to]);
  const extras = await one<any>(db, `SELECT COALESCE(sum(c.total), 0) AS n FROM charges c JOIN reservations res ON res.id = c.reservation_id WHERE res.hotel_id = $1 AND NOT c.void AND c.service_date BETWEEN $2 AND $3`, [hotelId, from, to]);
  const resto = await one<any>(db, `SELECT COALESCE(sum(total), 0) AS n FROM rs_orders WHERE hotel_id = $1 AND settlement IN ('paid','invoice') AND (created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`, [hotelId, from, to, tz]);
  const pay = await q<any>(db, `SELECT method, sum(amount) AS amount FROM payments WHERE hotel_id = $1 AND NOT void AND (received_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY method ORDER BY 2 DESC`, [hotelId, from, to, tz]);
  const ref = await one<any>(db, `SELECT COALESCE(sum(f.amount), 0) AS n FROM refunds f JOIN reservations r ON r.id = f.reservation_id WHERE r.hotel_id = $1 AND (f.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`, [hotelId, from, to, tz]);
  const exp = await q<any>(db, `SELECT category, sum(amount) AS amount FROM expenses WHERE hotel_id = $1 AND expense_date BETWEEN $2 AND $3 GROUP BY category ORDER BY 2 DESC`, [hotelId, from, to]);
  const act = await one<any>(db, `SELECT
      count(*) FILTER (WHERE (r.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3)::int AS created,
      count(*) FILTER (WHERE r.status = 'cancelled' AND (r.updated_at AT TIME ZONE $4)::date BETWEEN $2 AND $3)::int AS cancelled,
      count(*) FILTER (WHERE r.status = 'no_show' AND r.check_in BETWEEN $2 AND $3)::int AS no_show
    FROM reservations r WHERE r.hotel_id = $1`, [hotelId, from, to, tz]).catch(() => ({ created: 0, cancelled: 0, no_show: 0 }));
  const arr = await one<any>(db, `SELECT count(*)::int AS n FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id WHERE r.hotel_id = $1 AND rr.moved_from_rr_id IS NULL AND rr.status IN ('checked_in','checked_out') AND rr.check_in BETWEEN $2 AND $3`, [hotelId, from, to]);
  const roomRevenue = Number(rooms.revenue);
  const revenue = roomRevenue + Number(extras.n) + Number(resto.n);
  const payments = pay.reduce((s, p) => s + Number(p.amount), 0) - Number(ref.n);
  const expenses = exp.reduce((s, e) => s + Number(e.amount), 0);
  return {
    month: m, days, sellable,
    revenue: r2(revenue), room_revenue: r2(roomRevenue), extras: r2(Number(extras.n)), restaurant: r2(Number(resto.n)),
    payments: r2(payments), refunds: r2(Number(ref.n)), expenses: r2(expenses), gap: r2(revenue - expenses),
    nights: rooms.nights, occupancy: sellable ? r2((rooms.nights / (sellable * days)) * 100) : 0,
    adr: rooms.nights ? r2(roomRevenue / rooms.nights) : 0, revpar: sellable ? r2(roomRevenue / (sellable * days)) : 0,
    arrivals: arr.n, reservations_created: act.created, cancelled: act.cancelled, no_show: act.no_show,
    payment_methods: pay.map((p) => ({ label: PM[p.method] ?? p.method, amount: r2(Number(p.amount)) })),
    expense_categories: exp.map((e) => ({ label: e.category, amount: r2(Number(e.amount)) })),
  };
}

export async function reportPdf(hotelId: number, m: string): Promise<{ pdf: Buffer; cur: any; prev: any; hotel: string }> {
  const db = getPool();
  const hotel = (await one<any>(db, 'SELECT name FROM hotels WHERE id = $1', [hotelId]))?.name ?? 'Hôtel';
  const cur = await monthFigures(hotelId, m);
  const prev = await monthFigures(hotelId, prevMonth(m));
  const recv = await one<any>(db, `SELECT COALESCE(sum(GREATEST(${BALANCE_EXPR}, 0)), 0) AS n, count(*) FILTER (WHERE ${BALANCE_EXPR} > 0)::int AS debtors
     FROM (SELECT ${FIN_SQL} FROM reservations r WHERE r.hotel_id = $1 AND r.status IN ('checked_in','checked_out','cancelled','no_show')) x`, [hotelId]);
  const pdf = await new Promise<Buffer>((resolve) => {
    const doc = new PDFDocument({ size: 'A4', margin: 40, info: { Title: `Rapport mensuel ${monthLabel(m)}`, Author: 'KAYN Hotel' } });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    const W = doc.page.width - 80;
    const B = '#7A1F2B', G = '#C9A227';
    doc.rect(0, 0, doc.page.width, 78).fill(B);
    doc.fillColor('#fff').font('Helvetica-Bold').fontSize(18).text(hotel, 40, 22, { width: W });
    doc.fillColor(G).font('Helvetica-Bold').fontSize(12).text(`Rapport mensuel de direction — ${monthLabel(m)}`, 40, 46, { width: W });
    let y = 96;
    doc.fillColor('#666').font('Helvetica').fontSize(8).text(`Édité le ${new Date().toLocaleString('fr-FR', { timeZone: currency.tz })} par KAYN Hotel · comparaison avec ${monthLabel(prevMonth(m))}`, 40, y);
    y += 18;
    const evo = (a: number, b: number) => (b ? `${a >= b ? '+' : ''}${(((a - b) / Math.abs(b)) * 100).toFixed(1).replace('.', ',')} %` : '—');
    // cartes indicateurs
    const cards: [string, string, string][] = [
      ["Chiffre d'affaires", money(cur.revenue), evo(cur.revenue, prev.revenue)],
      ['Encaissements nets', money(cur.payments), evo(cur.payments, prev.payments)],
      ['Dépenses', money(cur.expenses), evo(cur.expenses, prev.expenses)],
      ['CA - dépenses', money(cur.gap), evo(cur.gap, prev.gap)],
      ["Taux d'occupation", `${cur.occupancy.toFixed(1).replace('.', ',')} %`, `${prev.occupancy.toFixed(1).replace('.', ',')} % le mois précédent`],
      ['Prix moyen (ADR)', money(cur.adr), evo(cur.adr, prev.adr)],
      ['RevPAR', money(cur.revpar), evo(cur.revpar, prev.revpar)],
      ['Créances clients (à ce jour)', money(Number(recv.n)), `${recv.debtors} dossier(s)`],
    ];
    const cw = (W - 12) / 2;
    cards.forEach(([l, v, h], i) => {
      const x = 40 + (i % 2) * (cw + 12), yy = y + Math.floor(i / 2) * 58;
      doc.roundedRect(x, yy, cw, 50, 6).lineWidth(0.8).strokeColor('#e5e5e5').stroke();
      doc.rect(x, yy, 3, 50).fill(i < 4 ? G : B);
      doc.fillColor('#555').font('Helvetica').fontSize(8.5).text(l, x + 12, yy + 7, { width: cw - 20 });
      doc.fillColor('#111').font('Helvetica-Bold').fontSize(14).text(v, x + 12, yy + 19, { width: cw - 20 });
      doc.fillColor('#777').font('Helvetica').fontSize(7.5).text(h, x + 12, yy + 37, { width: cw - 20 });
    });
    y += 4 * 58 + 8;
    const section = (title: string, rows: [string, string, string?][]) => {
      if (y > doc.page.height - 120) { doc.addPage(); y = 40; }
      doc.fillColor(B).font('Helvetica-Bold').fontSize(11).text(title, 40, y); y += 16;
      if (!rows.length) { doc.fillColor('#777').font('Helvetica').fontSize(9).text('Aucune donnée sur le mois.', 40, y); y += 16; return; }
      rows.forEach(([a, b, c], i) => {
        if (y > doc.page.height - 50) { doc.addPage(); y = 40; }
        if (i % 2 === 0) doc.rect(40, y - 3, W, 15).fill('#FAF7F2');
        doc.fillColor('#111').font('Helvetica').fontSize(9).text(a, 46, y, { width: W * 0.5 });
        if (c) doc.fillColor('#777').text(c, 40 + W * 0.5, y, { width: W * 0.22, align: 'right' });
        doc.fillColor('#111').font('Helvetica-Bold').text(b, 40 + W * 0.72, y, { width: W * 0.28 - 6, align: 'right' });
        y += 15;
      });
      y += 10;
    };
    section("Détail du chiffre d'affaires", [['Hébergement (nuitées)', money(cur.room_revenue), `${cur.nights} nuitée(s)`], ['Prestations (folios)', money(cur.extras)], ['Restaurant / bar (hors chambre)', money(cur.restaurant)], ['Total', money(cur.revenue), `M-1 : ${money(prev.revenue)}`]]);
    section('Activité', [['Arrivées', String(cur.arrivals), `M-1 : ${prev.arrivals}`], ['Réservations créées', String(cur.reservations_created), `M-1 : ${prev.reservations_created}`], ['Annulations', String(cur.cancelled)], ['No-shows', String(cur.no_show)], ['Chambres vendables', String(cur.sellable)]]);
    section('Encaissements par mode de paiement', [...cur.payment_methods.map((p): [string, string] => [p.label, money(p.amount)]), ...(cur.refunds ? [['Remboursements', `- ${money(cur.refunds)}`] as [string, string]] : [])]);
    section('Dépenses par catégorie', cur.expense_categories.map((e): [string, string] => [e.label, money(e.amount)]));
    doc.fillColor('#888').font('Helvetica').fontSize(7).text("« CA - dépenses » n'est pas un résultat comptable officiel (salaires, charges sociales et amortissements non inclus). Chiffres issus de KAYN Hotel à la date d'édition.", 40, doc.page.height - 52, { width: W });
    doc.end();
  });
  return { pdf, cur, prev, hotel };
}

const lastMonth = (todayStr: string) => prevMonth(todayStr.slice(0, 7));
const localNow = () => { const p = new Intl.DateTimeFormat('en-CA', { timeZone: currency.tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hour12: false }).formatToParts(new Date()); const g = (t: string) => p.find((x) => x.type === t)!.value; return { day: `${g('year')}-${g('month')}-${g('day')}`, hour: Number(g('hour')) % 24 }; };

/** Envoie le rapport d'un mois aux destinataires configurés (ou donnés). */
export async function sendMonthlyReport(hotelId: number, m: string, opts: { trigger: 'auto' | 'manual'; userId?: number | null; to?: string[] }) {
  const db = getPool();
  const s = await getSettings(db, hotelId);
  const cfg = s.monthly_report ?? {};
  const to = (opts.to ?? cfg.recipients ?? []).filter(Boolean);
  if (!to.length) throw badRequest('Aucun destinataire : renseignez l\'adresse du directeur (Paramètres → Rapport mensuel).');
  if (!s.smtp?.host) throw badRequest('Serveur e-mail non configuré : Paramètres → Serveur e-mail → « Configurer Gmail ».');
  const row = opts.trigger === 'auto'
    ? await one<any>(db, `INSERT INTO monthly_reports (hotel_id, month, recipients, trigger) VALUES ($1,$2,$3,'auto') ON CONFLICT (hotel_id, month) WHERE trigger = 'auto' DO UPDATE SET recipients = EXCLUDED.recipients RETURNING *`, [hotelId, m, to])
    : await one<any>(db, `INSERT INTO monthly_reports (hotel_id, month, recipients, trigger, created_by) VALUES ($1,$2,$3,'manual',$4) RETURNING *`, [hotelId, m, to, opts.userId ?? null]);
  try {
    const { pdf, cur, hotel } = await reportPdf(hotelId, m);
    const text = `Bonjour,\n\nVeuillez trouver ci-joint le rapport mensuel de ${hotel} pour ${monthLabel(m)}.\n\n`
      + `• Chiffre d'affaires : ${money(cur.revenue)}\n• Encaissements nets : ${money(cur.payments)}\n• Dépenses : ${money(cur.expenses)}\n`
      + `• Taux d'occupation : ${cur.occupancy.toFixed(1).replace('.', ',')} %\n• Prix moyen : ${money(cur.adr)}\n\nRapport envoyé automatiquement par KAYN Hotel.`;
    await smtpTransport(s.smtp).sendMail({ from: s.smtp.from ?? s.smtp.user, to: to.join(', '), subject: `${hotel} — Rapport mensuel ${monthLabel(m)}`, text,
      attachments: [{ filename: `rapport-${m}.pdf`, content: pdf, contentType: 'application/pdf' }] });
    await db.query(`UPDATE monthly_reports SET status = 'sent', sent_at = now(), attempts = attempts + 1, last_error = NULL WHERE id = $1`, [row.id]);
    return { ok: true, month: m, to };
  } catch (e: any) {
    const msg = e?.statusCode ? e.message : smtpError(e);
    await db.query(`UPDATE monthly_reports SET status = CASE WHEN attempts + 1 >= 20 THEN 'failed' ELSE 'pending' END, attempts = attempts + 1, last_error = $2 WHERE id = $1`, [row.id, msg.slice(0, 300)]);
    throw badRequest(`Rapport non envoyé : ${msg}`);
  }
}

/** Planificateur : le 1er du mois à partir de 7 h (ou plus tard si le PC était éteint), une seule fois par mois. */
export async function monthlyReportIfDue(hotelId: number) {
  const s = await getSettings(getPool(), hotelId);
  const cfg = s.monthly_report;
  if (!cfg?.enabled || !(cfg.recipients ?? []).length || !s.smtp?.host) return;
  const now = localNow();
  if (now.day.slice(8) === '01' && now.hour < 7) return;
  const m = lastMonth(now.day);
  const done = await one<any>(getPool(), `SELECT status, attempts FROM monthly_reports WHERE hotel_id = $1 AND month = $2 AND trigger = 'auto'`, [hotelId, m]);
  if (done && (done.status === 'sent' || done.attempts >= 20)) return;
  await sendMonthlyReport(hotelId, m, { trigger: 'auto' }).catch(() => { /* nouvel essai au prochain passage */ });
}
