/**
 * Achats : demande → validation → devis / comparaison → bon de commande → réceptions contrôlées → facture fournisseur → paiements.
 * Statuts : draft (Brouillon), pending (En attente de validation), approved (Validé), ordered (Commandé), partial (Partiellement reçu),
 * received (Reçu), cancelled (Annulé).
 */
import { currency } from './exports.js';
import type { PoolClient } from 'pg';
import { one, q, type Db } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { addDays, today } from '../lib/dates.js';
import { AppError, badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { fromCents, taxCents, toCents } from '../lib/money.js';
import { nextNumber } from './common.js';
import { moveStock, stockSettings } from './stock.js';

export const PO_STATUS: Record<string, string> = { draft: 'Brouillon', pending: 'En attente de validation', approved: 'Validé', ordered: 'Commandé', partial: 'Partiellement reçu', received: 'Reçu', cancelled: 'Annulé' };
const yr = () => today().slice(0, 4);
const pad = (n: number, l = 4) => String(n).padStart(l, '0');

async function lockPo(db: PoolClient, actor: Actor, id: number) {
  const po = await one<any>(db, 'SELECT * FROM purchase_orders WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!po) throw notFound('Achat introuvable');
  return po;
}
async function recalc(db: PoolClient, id: number) {
  const lines = await q<any>(db, 'SELECT * FROM purchase_order_lines WHERE po_id = $1', [id]);
  let ht = 0, tax = 0;
  for (const l of lines) { const b = Math.round(toCents(l.unit_price) * Number(l.quantity)); ht += b; tax += taxCents(b, Number(l.tax_rate)); }
  await db.query('UPDATE purchase_orders SET subtotal = $2, tax_total = $3, total = $4 WHERE id = $1', [id, fromCents(ht), fromCents(tax), fromCents(ht + tax)]);
}

export interface PoLineIn { product_id: number; quantity: number; unit_price?: number | null; tax_rate?: number | null; notes?: string | null }
async function setLines(db: PoolClient, actor: Actor, id: number, lines: PoLineIn[]) {
  if (!lines.length) throw badRequest('Ajoutez au moins un article.');
  if (new Set(lines.map((l) => l.product_id)).size !== lines.length) throw badRequest('Article en double dans la demande.');
  await db.query('DELETE FROM purchase_quote_lines WHERE line_id IN (SELECT id FROM purchase_order_lines WHERE po_id = $1)', [id]);
  await db.query('DELETE FROM purchase_order_lines WHERE po_id = $1', [id]);
  for (const l of lines) {
    const p = await one<any>(db, 'SELECT * FROM products WHERE id = $1 AND hotel_id = $2', [l.product_id, actor.hotelId]);
    if (!p) throw badRequest('Article inconnu.');
    if (p.archived_at) throw conflict(`« ${p.name} » est archivé.`);
    if (!(l.quantity > 0)) throw badRequest(`Quantité invalide : ${p.name}`);
    await db.query('INSERT INTO purchase_order_lines (po_id, product_id, quantity, unit_price, tax_rate, notes) VALUES ($1,$2,$3,$4,$5,$6)',
      [id, p.id, l.quantity, l.unit_price ?? p.cost_price ?? 0, l.tax_rate ?? p.tax_rate ?? 0, l.notes ?? null]);
  }
  await recalc(db, id);
}

export async function createRequest(db: PoolClient, actor: Actor, b: { department: string; warehouse_id?: number | null; needed_by?: string | null; reason?: string | null; notes?: string | null; supplier_id?: number | null; lines: PoLineIn[]; submit?: boolean }) {
  const w = b.warehouse_id ? await one<any>(db, 'SELECT id FROM warehouses WHERE id = $1 AND hotel_id = $2 AND active', [b.warehouse_id, actor.hotelId]) : await one<any>(db, 'SELECT id FROM warehouses WHERE hotel_id = $1 AND is_default', [actor.hotelId]);
  if (!w) throw badRequest('Entrepôt de livraison inconnu.');
  if (b.supplier_id && !(await one(db, 'SELECT 1 FROM suppliers WHERE id = $1 AND hotel_id = $2', [b.supplier_id, actor.hotelId]))) throw badRequest('Fournisseur inconnu.');
  const n = await nextNumber(db, `da-${yr()}`);
  const po = await one<any>(db, `INSERT INTO purchase_orders (hotel_id, number, department, warehouse_id, needed_by, reason, notes, supplier_id, requested_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [actor.hotelId, `DA${yr()}-${pad(n)}`, b.department, w.id, b.needed_by ?? null, b.reason ?? null, b.notes ?? null, b.supplier_id ?? null, actor.userId]);
  await setLines(db, actor, po.id, b.lines);
  await audit(db, actor, 'create', 'purchase', po.id, null, { number: po.number, lines: b.lines.length });
  if (b.submit) await submit(db, actor, po.id);
  return po;
}

export async function updateRequest(db: PoolClient, actor: Actor, perms: Set<string>, id: number, b: { department?: string; warehouse_id?: number | null; needed_by?: string | null; reason?: string | null; notes?: string | null; supplier_id?: number | null; expected_date?: string | null; lines?: PoLineIn[] }) {
  const po = await lockPo(db, actor, id);
  const own = po.requested_by === actor.userId;
  if (po.status === 'draft' ? !(own || perms.has('purchase.approve')) : ['pending'].includes(po.status) ? !perms.has('purchase.approve') : po.status === 'approved' ? !perms.has('purchase.order') : true) {
    throw conflict(`Achat « ${PO_STATUS[po.status]} » : modification impossible.`);
  }
  if (b.warehouse_id && !(await one(db, 'SELECT 1 FROM warehouses WHERE id = $1 AND hotel_id = $2 AND active', [b.warehouse_id, actor.hotelId]))) throw badRequest('Entrepôt inconnu.');
  if (b.supplier_id && !(await one(db, 'SELECT 1 FROM suppliers WHERE id = $1 AND hotel_id = $2', [b.supplier_id, actor.hotelId]))) throw badRequest('Fournisseur inconnu.');
  await db.query(`UPDATE purchase_orders SET department = COALESCE($2, department), warehouse_id = COALESCE($3, warehouse_id), needed_by = CASE WHEN $4::boolean THEN $5::date ELSE needed_by END,
      reason = COALESCE($6, reason), notes = COALESCE($7, notes), supplier_id = CASE WHEN $8::boolean THEN $9::int ELSE supplier_id END, expected_date = COALESCE($10, expected_date) WHERE id = $1`,
    [id, b.department ?? null, b.warehouse_id ?? null, b.needed_by !== undefined, b.needed_by ?? null, b.reason ?? null, b.notes ?? null, b.supplier_id !== undefined, b.supplier_id ?? null, b.expected_date ?? null]);
  if (b.lines) await setLines(db, actor, id, b.lines);
  await audit(db, actor, 'update', 'purchase', id, { status: po.status }, b);
}

export async function submit(db: PoolClient, actor: Actor, id: number) {
  const po = await lockPo(db, actor, id);
  if (po.status !== 'draft') throw conflict('Seul un brouillon peut être soumis.');
  if (!(await one(db, 'SELECT 1 FROM purchase_order_lines WHERE po_id = $1', [id]))) throw badRequest('Demande vide.');
  await db.query(`UPDATE purchase_orders SET status = 'pending', submitted_at = now(), rejection_reason = NULL WHERE id = $1`, [id]);
  await audit(db, actor, 'submit', 'purchase', id, { status: 'draft' }, { status: 'pending' });
}

export async function approve(db: PoolClient, actor: Actor, perms: Set<string>, id: number, b: { decision: 'approve' | 'reject'; reason?: string | null }) {
  const po = await lockPo(db, actor, id);
  if (po.status !== 'pending') throw conflict('Cet achat n\'attend pas de validation.');
  // séparation des tâches : le demandeur ne valide pas sa propre demande (sauf administrateur)
  if (po.requested_by === actor.userId && !perms.has('users.manage')) throw forbidden('Vous ne pouvez pas valider votre propre demande.');
  if (b.decision === 'reject') {
    if (!b.reason?.trim()) throw badRequest('Motif du refus obligatoire.');
    await db.query(`UPDATE purchase_orders SET status = 'draft', rejection_reason = $2 WHERE id = $1`, [id, b.reason.trim()]);
  } else {
    await db.query(`UPDATE purchase_orders SET status = 'approved', approved_by = $2, approved_at = now() WHERE id = $1`, [id, actor.userId]);
  }
  await audit(db, actor, b.decision, 'purchase', id, { status: 'pending' }, { status: b.decision === 'approve' ? 'approved' : 'draft', reason: b.reason ?? null });
}

/** Devis d'un fournisseur (un par fournisseur et par achat ; remplacé s'il est ressaisi). */
export async function saveQuote(db: PoolClient, actor: Actor, id: number, b: { supplier_id: number; reference?: string | null; delivery_days?: number | null; valid_until?: string | null; notes?: string | null; lines: { line_id: number; unit_price: number; tax_rate?: number | null; available?: boolean }[] }) {
  const po = await lockPo(db, actor, id);
  if (po.status !== 'approved') throw conflict('Les devis se saisissent sur un achat validé, avant la commande.');
  const s = await one<any>(db, 'SELECT * FROM suppliers WHERE id = $1 AND hotel_id = $2', [b.supplier_id, actor.hotelId]);
  if (!s || !s.active) throw badRequest('Fournisseur inconnu ou archivé.');
  const lines = await q<any>(db, 'SELECT * FROM purchase_order_lines WHERE po_id = $1', [id]);
  const qt = await one<any>(db, `INSERT INTO purchase_quotes (po_id, supplier_id, reference, delivery_days, valid_until, notes, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7)
      ON CONFLICT (po_id, supplier_id) DO UPDATE SET reference = EXCLUDED.reference, delivery_days = EXCLUDED.delivery_days, valid_until = EXCLUDED.valid_until, notes = EXCLUDED.notes RETURNING *`,
    [id, s.id, b.reference ?? null, b.delivery_days ?? null, b.valid_until ?? null, b.notes ?? null, actor.userId]);
  await db.query('DELETE FROM purchase_quote_lines WHERE quote_id = $1', [qt.id]);
  let ht = 0, tax = 0;
  for (const l of b.lines) {
    const pl = lines.find((x) => x.id === l.line_id);
    if (!pl) throw badRequest('Ligne de devis inconnue.');
    if (!(l.unit_price >= 0)) throw badRequest('Prix invalide.');
    const rate = l.tax_rate ?? Number(pl.tax_rate);
    await db.query('INSERT INTO purchase_quote_lines (quote_id, line_id, unit_price, tax_rate, available) VALUES ($1,$2,$3,$4,$5)', [qt.id, l.line_id, l.unit_price, rate, l.available ?? true]);
    if (l.available !== false) { const base = Math.round(toCents(l.unit_price) * Number(pl.quantity)); ht += base; tax += taxCents(base, rate); }
  }
  await db.query('UPDATE purchase_quotes SET total = $2 WHERE id = $1', [qt.id, fromCents(ht + tax)]);
  await audit(db, actor, 'quote', 'purchase', id, null, { supplier: s.name, total: fromCents(ht + tax) });
  return qt;
}

/** Tableau comparatif des offres : prix par ligne, meilleur prix, total, délai, complétude. */
export async function compareQuotes(db: Db, hotelId: number, id: number) {
  const lines = await q<any>(db, `SELECT l.*, p.name, p.unit FROM purchase_order_lines l JOIN products p ON p.id = l.product_id JOIN purchase_orders po ON po.id = l.po_id WHERE l.po_id = $1 AND po.hotel_id = $2 ORDER BY l.id`, [id, hotelId]);
  const quotes = await q<any>(db, `SELECT qt.*, s.name AS supplier FROM purchase_quotes qt JOIN suppliers s ON s.id = qt.supplier_id WHERE qt.po_id = $1 ORDER BY qt.total`, [id]);
  const ql = await q<any>(db, 'SELECT ql.* FROM purchase_quote_lines ql JOIN purchase_quotes qt ON qt.id = ql.quote_id WHERE qt.po_id = $1', [id]);
  const rows = lines.map((l) => {
    const offers = quotes.map((qt) => { const x = ql.find((y) => y.quote_id === qt.id && y.line_id === l.id); return x ? { quote_id: qt.id, unit_price: Number(x.unit_price), tax_rate: Number(x.tax_rate), available: x.available } : null; });
    const prices = offers.filter((o) => o && o.available).map((o) => o!.unit_price);
    return { line_id: l.id, product: l.name, unit: l.unit, quantity: Number(l.quantity), offers, best: prices.length ? Math.min(...prices) : null };
  });
  const out = quotes.map((qt, i) => ({ ...qt, total: Number(qt.total), complete: rows.every((r) => r.offers[i]?.available), best_lines: rows.filter((r) => r.best !== null && r.offers[i]?.available && r.offers[i]!.unit_price === r.best).length }));
  const complete = out.filter((x) => x.complete);
  return { lines: rows, quotes: out, recommended: complete.length ? complete.reduce((a, b) => (b.total < a.total ? b : a)).id : null };
}

export async function selectQuote(db: PoolClient, actor: Actor, id: number, quoteId: number) {
  const po = await lockPo(db, actor, id);
  if (po.status !== 'approved') throw conflict('Choix du devis possible avant la commande uniquement.');
  const qt = await one<any>(db, 'SELECT * FROM purchase_quotes WHERE id = $1 AND po_id = $2', [quoteId, id]);
  if (!qt) throw notFound('Devis introuvable');
  const ql = await q<any>(db, 'SELECT * FROM purchase_quote_lines WHERE quote_id = $1', [quoteId]);
  const lines = await q<any>(db, 'SELECT * FROM purchase_order_lines WHERE po_id = $1', [id]);
  const missing = lines.filter((l) => !ql.find((x) => x.line_id === l.id && x.available));
  if (missing.length) throw conflict('Ce devis ne couvre pas toutes les lignes : retirez les lignes non disponibles ou choisissez un autre devis.');
  for (const x of ql) await db.query('UPDATE purchase_order_lines SET unit_price = $2, tax_rate = $3 WHERE id = $1', [x.line_id, x.unit_price, x.tax_rate]);
  await db.query('UPDATE purchase_quotes SET selected = (id = $2) WHERE po_id = $1', [id, quoteId]);
  await db.query('UPDATE purchase_orders SET supplier_id = $2 WHERE id = $1', [id, qt.supplier_id]);
  await recalc(db, id);
  await audit(db, actor, 'select_quote', 'purchase', id, null, { quote_id: quoteId, supplier_id: qt.supplier_id });
}

/** Émission du bon de commande. */
export async function placeOrder(db: PoolClient, actor: Actor, id: number, b: { expected_date?: string | null }) {
  const po = await lockPo(db, actor, id);
  if (po.status !== 'approved') throw conflict('Seul un achat validé peut être commandé.');
  if (!po.supplier_id) throw badRequest('Choisissez le fournisseur (ou un devis).');
  const s = await one<any>(db, 'SELECT * FROM suppliers WHERE id = $1', [po.supplier_id]);
  if (!s.active) throw conflict('Fournisseur archivé.');
  const lines = await q<any>(db, 'SELECT * FROM purchase_order_lines WHERE po_id = $1', [id]);
  if (lines.some((l) => !(Number(l.unit_price) > 0))) throw badRequest('Prix d\'achat manquant sur une ligne.');
  const n = await nextNumber(db, `bc-${yr()}`);
  const expected = b.expected_date ?? po.needed_by ?? addDays(today(), 7);
  await db.query(`UPDATE purchase_orders SET status = 'ordered', po_number = $2, ordered_by = $3, ordered_at = now(), expected_date = $4 WHERE id = $1`, [id, `BC${yr()}-${pad(n)}`, actor.userId, expected]);
  for (const l of lines) {
    await db.query(`INSERT INTO supplier_products (supplier_id, product_id, last_price) VALUES ($1,$2,$3) ON CONFLICT (supplier_id, product_id) DO UPDATE SET last_price = EXCLUDED.last_price`, [po.supplier_id, l.product_id, l.unit_price]);
  }
  await audit(db, actor, 'order', 'purchase', id, { status: 'approved' }, { status: 'ordered', po_number: `BC${yr()}-${pad(n)}`, expected });
}

/** Réception contrôlée : quantités ≤ reste à recevoir, lots / péremption, entrée en stock au prix de la commande, jamais deux fois. */
export async function receive(db: PoolClient, actor: Actor, id: number, b: { delivery_note?: string | null; notes?: string | null; warehouse_id?: number | null; lines: { po_line_id: number; quantity: number; rejected_qty?: number; lot_no?: string | null; expiry_date?: string | null; unit_cost?: number | null }[] }) {
  const po = await lockPo(db, actor, id);
  if (!['ordered', 'partial'].includes(po.status)) throw conflict(po.status === 'received' ? 'Commande déjà entièrement reçue.' : 'La commande doit être émise avant la réception.');
  const items = b.lines.filter((l) => l.quantity > 0 || (l.rejected_qty ?? 0) > 0);
  if (!items.length) throw badRequest('Aucune quantité reçue.');
  const wh = b.warehouse_id ?? po.warehouse_id;
  if (!(await one(db, 'SELECT 1 FROM warehouses WHERE id = $1 AND hotel_id = $2 AND active', [wh, actor.hotelId]))) throw badRequest('Entrepôt inconnu.');
  // contrôle complet avant toute écriture : quantités ≤ reste à recevoir
  const checked: { l: typeof items[number]; pl: any; cost: number }[] = [];
  let value = 0;
  for (const l of items) {
    const pl = await one<any>(db, 'SELECT l.*, p.name FROM purchase_order_lines l JOIN products p ON p.id = l.product_id WHERE l.id = $1 AND l.po_id = $2 FOR UPDATE OF l', [l.po_line_id, id]);
    if (!pl) throw badRequest('Ligne de commande inconnue.');
    if (!(l.quantity >= 0) || (l.rejected_qty ?? 0) < 0) throw badRequest('Quantité invalide.');
    const remaining = Number(pl.quantity) - Number(pl.received_qty);
    if (l.quantity > remaining + 1e-9) throw new AppError(409, 'over_receipt', `« ${pl.name} » : ${l.quantity} reçu(s) pour ${Math.round(remaining * 1000) / 1000} restant(s) à recevoir.`);
    if (l.quantity === 0) continue;
    const cost = l.unit_cost ?? Number(pl.unit_price);
    checked.push({ l, pl, cost });
    value += Math.round(toCents(cost) * l.quantity);
  }
  if (!checked.length) throw badRequest('Aucune quantité acceptée.');
  const n = await nextNumber(db, `br-${yr()}`);
  const rec = await one<any>(db, `INSERT INTO purchase_receipts (hotel_id, number, po_id, warehouse_id, delivery_note, received_by, notes, value) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [actor.hotelId, `BR${yr()}-${pad(n)}`, id, wh, b.delivery_note ?? null, actor.userId, b.notes ?? null, fromCents(value)]);
  const alerts: string[] = [];
  for (const { l, pl, cost } of checked) {
    const mv = await moveStock(db, actor, { product_id: pl.product_id, warehouse_id: wh, kind: 'receipt', quantity: l.quantity, unit_cost: cost, lot_no: l.lot_no, expiry_date: l.expiry_date,
      reason: `${rec.number} — ${po.po_number}`, ref_type: 'purchase_receipt', ref_id: rec.id });
    if (mv.alert) alerts.push(mv.alert);
    await db.query(`INSERT INTO purchase_receipt_lines (receipt_id, po_line_id, product_id, quantity, rejected_qty, unit_cost, lot_no, expiry_date, movement_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [rec.id, pl.id, pl.product_id, l.quantity, l.rejected_qty ?? 0, cost, l.lot_no ?? null, l.expiry_date ?? null, mv.movement.id]);
    await db.query('UPDATE purchase_order_lines SET received_qty = received_qty + $2 WHERE id = $1', [pl.id, l.quantity]);
  }
  const left = await one<any>(db, 'SELECT count(*) FILTER (WHERE received_qty < quantity)::int AS n FROM purchase_order_lines WHERE po_id = $1', [id]);
  const status = left.n ? 'partial' : 'received';
  await db.query(`UPDATE purchase_orders SET status = $2, received_at = CASE WHEN $2 = 'received' THEN now() ELSE received_at END WHERE id = $1`, [id, status]);
  await audit(db, actor, 'receive', 'purchase', id, { status: po.status }, { status, receipt: rec.number, value: fromCents(value), lines: items });
  return { receipt: rec, status, alerts };
}

export async function cancelPo(db: PoolClient, actor: Actor, id: number, reason: string) {
  const po = await lockPo(db, actor, id);
  if (!reason?.trim()) throw badRequest('Motif obligatoire.');
  if (['received', 'cancelled'].includes(po.status)) throw conflict('Achat déjà clôturé.');
  if (po.status === 'partial') {
    // reliquat abandonné : la commande est clôturée sur les quantités déjà reçues
    await db.query(`UPDATE purchase_orders SET status = 'received', received_at = now(), cancel_reason = $2, cancelled_by = $3, cancelled_at = now() WHERE id = $1`, [id, `Reliquat annulé : ${reason.trim()}`, actor.userId]);
    await audit(db, actor, 'close_remaining', 'purchase', id, { status: 'partial' }, { status: 'received', reason });
    return 'received';
  }
  await db.query(`UPDATE purchase_orders SET status = 'cancelled', cancel_reason = $2, cancelled_by = $3, cancelled_at = now() WHERE id = $1`, [id, reason.trim(), actor.userId]);
  await audit(db, actor, 'cancel', 'purchase', id, { status: po.status }, { status: 'cancelled', reason });
  return 'cancelled';
}

export async function poDetail(db: Db, hotelId: number, id: number) {
  const po = await one<any>(db, `SELECT po.*, s.name AS supplier, s.payment_terms, w.name AS warehouse, ur.full_name AS requested_by_name, ua.full_name AS approved_by_name, uo.full_name AS ordered_by_name
      FROM purchase_orders po LEFT JOIN suppliers s ON s.id = po.supplier_id JOIN warehouses w ON w.id = po.warehouse_id LEFT JOIN users ur ON ur.id = po.requested_by
      LEFT JOIN users ua ON ua.id = po.approved_by LEFT JOIN users uo ON uo.id = po.ordered_by WHERE po.id = $1 AND po.hotel_id = $2`, [id, hotelId]);
  if (!po) throw notFound('Achat introuvable');
  const lines = await q<any>(db, `SELECT l.*, p.name, p.unit, p.code, p.track_lots, p.stock_qty FROM purchase_order_lines l JOIN products p ON p.id = l.product_id WHERE l.po_id = $1 ORDER BY l.id`, [id]);
  const receipts = await q<any>(db, `SELECT r.*, u.full_name AS received_by_name, w.name AS warehouse,
      COALESCE((SELECT json_agg(json_build_object('product', p.name, 'quantity', rl.quantity, 'rejected', rl.rejected_qty, 'lot', rl.lot_no, 'expiry', rl.expiry_date, 'unit_cost', rl.unit_cost) ORDER BY rl.id)
        FROM purchase_receipt_lines rl JOIN products p ON p.id = rl.product_id WHERE rl.receipt_id = r.id), '[]') AS lines
     FROM purchase_receipts r LEFT JOIN users u ON u.id = r.received_by JOIN warehouses w ON w.id = r.warehouse_id WHERE r.po_id = $1 ORDER BY r.id`, [id]);
  const invoices = await q<any>(db, 'SELECT id, ref, number, total, paid, status, invoice_date, due_date FROM supplier_invoices WHERE po_id = $1 ORDER BY id', [id]);
  const history = await q<any>(db, `SELECT a.created_at, a.action, a.after, u.full_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE a.entity = 'purchase' AND a.entity_id = $1 ORDER BY a.id`, [String(id)]);
  return { ...po, status_label: PO_STATUS[po.status], lines, receipts, invoices, history, quotes: await compareQuotes(db, hotelId, id) };
}

// =====================================================================================================
// Factures et paiements fournisseurs (→ dépenses dans Facturation & Caisse)
// =====================================================================================================
export async function createInvoice(db: PoolClient, actor: Actor, b: { supplier_id: number; number: string; po_id?: number | null; invoice_date: string; due_date?: string | null; subtotal: number; tax_total?: number; stamp_duty?: number; category?: string | null; notes?: string | null }) {
  const s = await one<any>(db, 'SELECT * FROM suppliers WHERE id = $1 AND hotel_id = $2', [b.supplier_id, actor.hotelId]);
  if (!s) throw notFound('Fournisseur introuvable');
  if (b.invoice_date > today()) throw badRequest('Date de facture dans le futur.');
  const warnings: string[] = [];
  let received: number | null = null;
  if (b.po_id) {
    const po = await one<any>(db, 'SELECT * FROM purchase_orders WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [b.po_id, actor.hotelId]);
    if (!po) throw notFound('Commande introuvable');
    if (po.supplier_id !== s.id) throw badRequest('Cette commande appartient à un autre fournisseur.');
    if (!['partial', 'received'].includes(po.status)) throw conflict('Facture rattachée à une commande non réceptionnée.');
    // contrôle facture / réception (valeur TTC réceptionnée)
    const r = await one<any>(db, `SELECT COALESCE(sum(round(rl.unit_cost * rl.quantity, 2) + round(rl.unit_cost * rl.quantity * l.tax_rate / 100, 2)), 0) AS ttc
        FROM purchase_receipt_lines rl JOIN purchase_receipts pr ON pr.id = rl.receipt_id JOIN purchase_order_lines l ON l.id = rl.po_line_id WHERE pr.po_id = $1`, [po.id]);
    const already = await one<any>(db, `SELECT COALESCE(sum(total - stamp_duty), 0) AS t FROM supplier_invoices WHERE po_id = $1 AND status <> 'cancelled'`, [po.id]);
    received = Number(r.ttc);
    const billed = toCents(already.t) + toCents(b.subtotal) + toCents(b.tax_total ?? 0);
    if (Math.abs(billed - toCents(received)) > Math.max(100, toCents(received) / 100)) warnings.push(`Écart facture / réception : facturé ${fromCents(billed)} ${currency.symbol} TTC, réceptionné ${received} ${currency.symbol} TTC.`);
  }
  const total = fromCents(toCents(b.subtotal) + toCents(b.tax_total ?? 0) + toCents(b.stamp_duty ?? 0));
  if (!(total > 0)) throw badRequest('Montant de facture invalide.');
  const n = await nextNumber(db, `ff-${yr()}`);
  let inv: any;
  try {
    inv = await one<any>(db, `INSERT INTO supplier_invoices (hotel_id, ref, supplier_id, number, po_id, invoice_date, due_date, category, subtotal, tax_total, stamp_duty, total, received_value, notes, created_by)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) RETURNING *`,
      [actor.hotelId, `FF${yr()}-${pad(n)}`, s.id, b.number.trim(), b.po_id ?? null, b.invoice_date, b.due_date ?? addDays(b.invoice_date, s.payment_terms ?? 30), b.category?.trim() || (await stockSettings(db, actor.hotelId)).purchase_category,
        b.subtotal, b.tax_total ?? 0, b.stamp_duty ?? 0, total, received, b.notes ?? null, actor.userId]);
  } catch (e: any) {
    if (e.code === '23505') throw conflict(`La facture n° ${b.number} de ${s.name} est déjà enregistrée.`);
    throw e;
  }
  await audit(db, actor, 'create', 'supplier_invoice', inv.id, null, { ref: inv.ref, number: b.number, total, warnings });
  return { ...inv, warnings };
}

export async function payInvoice(db: PoolClient, actor: Actor, id: number, b: { amount: number; method: 'cash' | 'card' | 'cheque' | 'transfer'; reference?: string | null; paid_at?: string | null }) {
  const f = await one<any>(db, 'SELECT f.*, s.name AS supplier FROM supplier_invoices f JOIN suppliers s ON s.id = f.supplier_id WHERE f.id = $1 AND f.hotel_id = $2 FOR UPDATE OF f', [id, actor.hotelId]);
  if (!f) throw notFound('Facture introuvable');
  if (!['unpaid', 'partial'].includes(f.status)) throw conflict('Facture soldée ou annulée.');
  const due = toCents(f.total) - toCents(f.paid);
  if (!(toCents(b.amount) > 0)) throw badRequest('Montant invalide.');
  if (toCents(b.amount) > due) throw badRequest(`Montant supérieur au reste dû (${fromCents(due)} ${currency.symbol}).`);
  if (['cheque', 'transfer'].includes(b.method) && !b.reference?.trim()) throw badRequest('Référence obligatoire (n° de chèque / virement).');
  const paidAt = b.paid_at ?? today();
  if (paidAt > today()) throw badRequest('Date de paiement dans le futur.');
  // Facturation & Caisse : chaque règlement est une dépense (espèces → sortie de caisse contrôlée)
  const { addExpense } = await import('./cash.js');
  const exp = await addExpense(db, actor, { category: f.category, description: `Facture ${f.supplier} n° ${f.number} (${f.ref})`, amount: b.amount, method: b.method, supplier_id: f.supplier_id, expense_date: paidAt, reference: b.reference ?? f.ref });
  const p = await one<any>(db, `INSERT INTO supplier_payments (invoice_id, amount, method, reference, paid_at, expense_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [id, b.amount, b.method, b.reference ?? null, paidAt, exp.id, actor.userId]);
  const paid = fromCents(toCents(f.paid) + toCents(b.amount));
  await db.query(`UPDATE supplier_invoices SET paid = $2, status = CASE WHEN $2 >= total THEN 'paid' ELSE 'partial' END WHERE id = $1`, [id, paid]);
  await audit(db, actor, 'pay', 'supplier_invoice', id, { paid: Number(f.paid) }, { paid, amount: b.amount, method: b.method, expense_id: exp.id });
  return p;
}

export async function cancelInvoice(db: PoolClient, actor: Actor, id: number, reason: string) {
  const f = await one<any>(db, 'SELECT * FROM supplier_invoices WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!f) throw notFound('Facture introuvable');
  if (f.status === 'cancelled') throw conflict('Facture déjà annulée.');
  if (toCents(f.paid) > 0) throw conflict('Facture partiellement payée : annulation impossible (enregistrez un avoir fournisseur).');
  if (!reason?.trim()) throw badRequest('Motif obligatoire.');
  await db.query(`UPDATE supplier_invoices SET status = 'cancelled', cancel_reason = $2 WHERE id = $1`, [id, reason.trim()]);
  await audit(db, actor, 'cancel', 'supplier_invoice', id, { status: f.status }, { status: 'cancelled', reason });
}
