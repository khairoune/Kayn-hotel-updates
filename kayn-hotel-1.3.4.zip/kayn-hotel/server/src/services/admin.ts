/** Phase 14 — Administration : taxes versionnées, modules du journal, tableau de bord, état du système. */
import { networkInterfaces } from 'node:os';
import { readdirSync } from 'node:fs';
import { getPool, one, q, type Db } from '../db/pool.js';
import { config } from '../config.js';
import { getSettings } from './common.js';
import { pgTool } from './backup.js';
import { badRequest, forbidden } from '../lib/errors.js';

/** Module (filtre du journal) d'après l'entité tracée. */
export const AUDIT_MODULES: Record<string, string> = {
  reservations: 'Réservations', frontoffice: 'Réception', billing: 'Facturation & caisse', restaurant: 'Restaurant', stock: 'Stocks & achats', housekeeping: 'Housekeeping',
  maintenance: 'Maintenance', hr: 'Ressources humaines', crm: 'Clients & CRM', rooms: 'Hébergement', nightaudit: 'Night audit', reports: 'Rapports',
  security: 'Sécurité & connexions', admin: 'Administration & paramètres',
};
export function moduleOfEntity(entity: string, action = ''): string {
  if (/^(login|logout|login_failed|permission_denied|password_reset|password_reset_failed|change_password)$/.test(action)) return 'security';
  if (/^(user|role|device|api|session)$/.test(entity)) return 'security';
  if (/^(setting|hotel|service|tax|backup|department|hr_department|notification)/.test(entity)) return entity === 'hr_department' ? 'hr' : 'admin';
  if (/^(reservation)/.test(entity)) return 'reservations';
  if (/^(guest|crm|loyalty)/.test(entity)) return 'crm';
  if (/^(payment|invoice|refund|charge|income|expense|cash)/.test(entity)) return 'billing';
  if (/^rs_/.test(entity)) return 'restaurant';
  if (/^(product|purchase|supplier|inventory|warehouse)/.test(entity)) return 'stock';
  if (/^(hk_|housekeeping|linen|lost_item)/.test(entity)) return 'housekeeping';
  if (/^(maintenance|work_order|equipment)/.test(entity)) return 'maintenance';
  if (/^(employee|hr_)/.test(entity)) return 'hr';
  if (/^(room|floor|building|rate|amenity)/.test(entity)) return 'rooms';
  if (/^audit_(day|anomal|closure|cash|posting|checklist)/.test(entity)) return 'nightaudit';
  if (/^(report|analytics)/.test(entity)) return 'reports';
  return 'admin';
}
/** Entités correspondant à un module (pour le filtre SQL). */
export function entityPatternOf(mod: string): string | null {
  return ({
    security: '^(user|role|device|api|session)$', admin: '^(setting|hotel|service|tax|backup|department|notification)', reservations: '^reservation', crm: '^(guest|crm|loyalty)',
    billing: '^(payment|invoice|refund|charge|income|expense|cash)', restaurant: '^rs_', stock: '^(product|purchase|supplier|inventory|warehouse)', housekeeping: '^(hk_|housekeeping|linen|lost_item)',
    maintenance: '^(maintenance|work_order|equipment)', hr: '^(employee|hr_)', rooms: '^(room|floor|building|rate|amenity)', nightaudit: '^audit_(day|anomal|closure|cash|posting|checklist)', reports: '^(report|analytics)',
  } as Record<string, string>)[mod] ?? null;
}

// ====================================================== Taxes versionnées ======================================================
/**
 * Un changement de taux crée une version datée (valable à partir de…). Le taux effectif du jour est recopié dans les paramètres
 * utilisés pour les NOUVELLES lignes ; chaque ligne déjà saisie / facturée garde son taux figé : l'historique n'est jamais recalculé.
 */
export async function recordTaxVersion(db: Db, hotelId: number, userId: number | null, category: string, rate: number, validFrom: string, name: string | null, note: string | null) {
  return one<any>(db, `INSERT INTO tax_versions (hotel_id, category, name, rate, valid_from, note, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7)
     ON CONFLICT (hotel_id, category, valid_from) DO UPDATE SET rate = EXCLUDED.rate, name = COALESCE(EXCLUDED.name, tax_versions.name), note = EXCLUDED.note, created_by = EXCLUDED.created_by, applied_at = NULL
     RETURNING *`, [hotelId, category, name ?? (category === 'default' ? 'TVA par défaut' : category === 'tourist' ? 'Taxe de séjour' : `TVA ${category}`), rate, validFrom, note, userId]);
}
export async function effectiveTaxes(db: Db, hotelId: number, day: string) {
  return q<any>(db, `SELECT DISTINCT ON (category) * FROM tax_versions WHERE hotel_id = $1 AND valid_from <= $2::date ORDER BY category, valid_from DESC`, [hotelId, day]);
}
export async function applyEffectiveTaxes(db: Db, hotelId: number, day: string) {
  const eff = await effectiveTaxes(db, hotelId, day);
  if (!eff.length) return { changed: false };
  const s = await getSettings(db, hotelId);
  const rates: Record<string, number> = { ...(s.tax_rates ?? {}) };
  let vat = Number(s.vat_rate), tourist = Number(s.tourist_tax_per_adult_night), changed = false;
  for (const t of eff) {
    const r = Number(t.rate);
    if (t.category === 'default') { if (vat !== r) { vat = r; changed = true; } }
    else if (t.category === 'tourist') { if (tourist !== r) { tourist = r; changed = true; } }
    else if (rates[t.category] !== r) { rates[t.category] = r; changed = true; }
  }
  if (changed) {
    for (const [k, v] of [['vat_rate', vat], ['tourist_tax_per_adult_night', tourist], ['tax_rates', rates]] as const) {
      await db.query(`INSERT INTO settings (hotel_id, key, value, updated_at) VALUES ($1,$2,$3,now()) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`, [hotelId, k, JSON.stringify(v)]);
    }
    await db.query(`INSERT INTO audit_logs (hotel_id, action, entity, entity_id, before, after) VALUES ($1,'apply','tax','effective',$2,$3)`,
      [hotelId, JSON.stringify({ vat_rate: s.vat_rate, tourist: s.tourist_tax_per_adult_night, tax_rates: s.tax_rates }), JSON.stringify({ vat_rate: vat, tourist, tax_rates: rates, day })]);
  }
  await db.query(`UPDATE tax_versions SET applied_at = now() WHERE hotel_id = $1 AND applied_at IS NULL AND valid_from <= $2::date`, [hotelId, day]);
  return { changed };
}

// ====================================================== Tableau de bord ======================================================
export async function adminDashboard(hotelId: number) {
  const db = getPool();
  const users = await one<any>(db, `SELECT count(*)::int AS total, count(*) FILTER (WHERE active)::int AS active, count(*) FILTER (WHERE NOT active)::int AS disabled,
      count(*) FILTER (WHERE active AND locked_until > now())::int AS locked FROM users WHERE hotel_id = $1`, [hotelId]);
  const byDept = await q<any>(db, `SELECT d.id, d.code, d.name, d.active,
      (SELECT count(*)::int FROM users u WHERE u.department_id = d.id AND u.active) AS users,
      (SELECT count(*)::int FROM employees e WHERE e.hotel_id = d.hotel_id AND e.department = d.code AND e.status = 'active') AS employees
      FROM hr_departments d WHERE d.hotel_id = $1 ORDER BY d.active DESC, d.sort_order, d.name`, [hotelId]);
  const roles = await one<any>(db, `SELECT count(*)::int AS total, count(*) FILTER (WHERE active)::int AS active FROM roles`);
  const lastLogins = await q<any>(db, `SELECT u.id, u.username, u.full_name, r.name AS role_name, u.last_login_at FROM users u JOIN roles r ON r.id = u.role_id
      WHERE u.hotel_id = $1 AND u.last_login_at IS NOT NULL ORDER BY u.last_login_at DESC LIMIT 8`, [hotelId]);
  const activity = await q<any>(db, `SELECT a.id, a.created_at, a.action, a.entity, a.entity_id, a.result, u.full_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
      WHERE (a.hotel_id = $1 OR a.hotel_id IS NULL) ORDER BY a.id DESC LIMIT 10`, [hotelId]);
  const alerts: any[] = [];
  const failed = await one<any>(db, `SELECT count(*)::int AS n FROM audit_logs WHERE action = 'login_failed' AND created_at > now() - interval '24 hours'`);
  if (failed.n) alerts.push({ level: failed.n >= 10 ? 'danger' : 'warning', code: 'failed_logins', count: failed.n, text: `${failed.n} échec(s) de connexion sur 24 h` });
  const denied = await one<any>(db, `SELECT count(*)::int AS n FROM audit_logs WHERE action = 'permission_denied' AND created_at > now() - interval '24 hours'`);
  if (denied.n) alerts.push({ level: 'warning', code: 'denied', count: denied.n, text: `${denied.n} opération(s) refusée(s) faute de droits sur 24 h` });
  if (users.locked) alerts.push({ level: 'danger', code: 'locked', count: users.locked, text: `${users.locked} compte(s) verrouillé(s)` });
  const pend = await one<any>(db, `SELECT count(*)::int AS n FROM devices WHERE hotel_id = $1 AND status = 'pending'`, [hotelId]);
  if (pend.n) alerts.push({ level: 'warning', code: 'devices', count: pend.n, text: `${pend.n} poste(s) en attente d'approbation` });
  const mustChange = await one<any>(db, `SELECT count(*)::int AS n FROM users u JOIN roles r ON r.id = u.role_id WHERE u.hotel_id = $1 AND u.active AND u.must_change_password AND r.code IN ('admin','tech_admin')`, [hotelId]);
  if (mustChange.n) alerts.push({ level: 'warning', code: 'default_password', count: mustChange.n, text: 'Un compte administrateur n\'a pas encore changé son mot de passe initial' });
  const lastBackup = await one<any>(db, `SELECT * FROM backups WHERE status = 'ok' AND kind <> 'uploaded' ORDER BY created_at DESC LIMIT 1`);
  const lastFailed = await one<any>(db, `SELECT * FROM backups WHERE status = 'failed' ORDER BY created_at DESC LIMIT 1`);
  if (!lastBackup) alerts.push({ level: 'danger', code: 'no_backup', text: 'Aucune sauvegarde réussie : créez-en une maintenant.' });
  else if (Date.now() - new Date(lastBackup.created_at).getTime() > 8 * 86400_000) alerts.push({ level: 'warning', code: 'old_backup', text: 'Dernière sauvegarde réussie il y a plus de 7 jours.' });
  if (lastFailed && (!lastBackup || new Date(lastFailed.created_at) > new Date(lastBackup.created_at))) alerts.push({ level: 'danger', code: 'backup_failed', text: `Dernière sauvegarde en échec : ${String(lastFailed.error ?? '').slice(0, 120)}` });
  return { users, departments: byDept, roles, last_logins: lastLogins, activity, alerts, last_backup: lastBackup, system: await systemInfo(hotelId, true) };
}

// ====================================================== État du système ======================================================
export function lanAddresses() {
  const out: string[] = [];
  for (const [, xs] of Object.entries(networkInterfaces())) for (const x of xs ?? []) if (x.family === 'IPv4' && !x.internal) out.push(x.address);
  return out;
}
export async function systemInfo(hotelId: number, light = false) {
  const db = getPool();
  const t0 = Date.now();
  const v = await one<any>(db, `SELECT version() AS v, pg_database_size(current_database())::bigint AS size, current_database() AS db, (SELECT count(*)::int FROM pg_stat_activity WHERE datname = current_database()) AS conns`);
  const latency = Date.now() - t0;
  const migs = await q<any>(db, 'SELECT name, applied_at FROM schema_migrations ORDER BY name').catch(async () => q<any>(db, 'SELECT name FROM schema_migrations ORDER BY name'));
  const files = readdirSync(new URL('../db/migrations', import.meta.url)).filter((f) => f.endsWith('.sql')).sort();
  const base = {
    db_ok: true, db_latency_ms: latency, db_size: Number(v.size), db_name: v.db, db_connections: v.conns, pg_version: String(v.v).split(' ').slice(0, 2).join(' '),
    migrations: { applied: migs.length, expected: files.length, last: migs[migs.length - 1]?.name ?? null, pending: files.filter((f) => !migs.some((m) => m.name === f)) },
    uptime_s: Math.round(process.uptime()), node: process.version, pg_dump: !!pgTool('pg_dump'), pg_restore: !!pgTool('pg_restore'),
  };
  if (light) return base;
  const s = await getSettings(db, hotelId);
  return {
    ...base,
    server: { port: config.port, host: config.host, lan: lanAddresses().map((ip) => `http://${ip}:${config.port}`), timezone: config.timezone, cookie_secure: config.cookieSecure, device_approval: config.requireDeviceApproval, session_hours: config.sessionHours },
    sessions_active: (await one<any>(db, `SELECT count(*)::int AS n FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.hotel_id = $1 AND NOT s.revoked AND s.expires_at > now()`, [hotelId])).n,
    // Fonctions qui nécessitent Internet (tout le reste fonctionne en réseau local, sans connexion)
    internet: [
      { key: 'smtp', label: 'Envoi d\'e-mails (confirmations, campagnes, enquêtes)', configured: !!s.smtp?.host, note: 'Serveur SMTP à renseigner dans Paramètres.' },
      { key: 'gateway', label: 'Paiement en ligne', configured: !!s.payment_gateway?.enabled, note: 'Aucune passerelle intégrée : les paiements en ligne sont refusés tant qu\'elle n\'est pas configurée.' },
      { key: 'survey', label: 'Enquêtes de satisfaction accessibles depuis l\'extérieur', configured: false, note: 'Le lien public ne fonctionne hors de l\'hôtel que si le serveur est exposé (nom de domaine / redirection de port).' },
    ],
  };
}

/** Pas d'élévation de privilèges (tous les écrans qui attribuent un rôle) : on n'attribue que des droits que l'on possède, sauf super administrateur. */
export async function assertRoleGrantable(db: Db, user: { role: string; perms: Set<string> }, roleCode: string) {
  const role = await one<any>(db, 'SELECT id, code, active FROM roles WHERE code = $1', [roleCode]);
  if (!role) throw badRequest('Rôle inconnu.');
  if (!role.active) throw badRequest('Ce rôle est désactivé.');
  if (user.role === 'admin') return role;
  if (role.code === 'admin') throw forbidden('Seul un super administrateur peut attribuer le rôle Super administrateur.');
  const perms = await q<any>(db, 'SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = $1', [role.id]);
  const missing = perms.map((p) => p.code).filter((c) => !user.perms.has(c));
  if (missing.length) throw forbidden(`Vous ne pouvez pas attribuer un rôle plus puissant que le vôtre (droits manquants : ${missing.slice(0, 5).join(', ')}${missing.length > 5 ? '…' : ''}).`);
  return role;
}
