/**
 * Restaurant & Services : carte, menus, tables, commandes (salle, bar, room service, petit-déjeuner), cuisine (KDS),
 * règlement (paiement immédiat, chambre / folio, facture indépendante), stock des ingrédients, rapports.
 *
 * Montants : prix de la carte HT (comme le catalogue des prestations) + TVA par catégorie figée sur chaque ligne ;
 * calculs en centimes, identiques au folio et aux factures → aucun écart lors d'un transfert.
 */
import { currency } from './exports.js';
import type { PoolClient } from 'pg';
import { one, q, type Db } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { addDays, today } from '../lib/dates.js';
import { AppError, badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { fromCents, shareCents, taxCents, toCents } from '../lib/money.js';
import { getSettings, guestDisplayName, isTaxExempt, nextNumber, taxRateFor } from './common.js';
import { config } from '../config.js';

export type Outlet = 'restaurant' | 'bar' | 'room_service' | 'breakfast';
const TZ = config.timezone ?? 'Africa/Algiers';
const OPEN = ['new', 'confirmed', 'preparing', 'ready'];
/** catégorie fiscale / type de prestation au folio selon le point de vente */
const OUTLET_KIND: Record<Outlet, string> = { restaurant: 'restaurant', bar: 'restaurant', room_service: 'room_service', breakfast: 'breakfast' };
export const OUTLET_LABEL: Record<string, string> = { restaurant: 'Restaurant', bar: 'Bar', room_service: 'Room service', breakfast: 'Petit-déjeuner' };
export const STATUS_LABEL: Record<string, string> = { new: 'Nouvelle', confirmed: 'Confirmée', preparing: 'En préparation', ready: 'Prête', served: 'Servie', cancelled: 'Annulée' };
const SETTLE_LABEL: Record<string, string> = { open: 'À régler', paid: 'Payée', room: 'Sur la chambre', invoice: 'Facturée', cancelled: 'Annulée' };

export async function rsSettings(db: Db, hotelId: number) {
  return (await getSettings(db, hotelId)).restaurant as {
    breakfast_start: string; breakfast_end: string; breakfast_service_code: string; stock_block: boolean; table_to_clean: boolean; max_discount_percent: number;
  };
}

// =====================================================================================================
// Carte : disponibilité (manuelle + stock des ingrédients) et menu en cours
// =====================================================================================================
/** Portions réalisables d'après le stock (null = plat sans recette suivie). */
export async function portions(db: Db, hotelId: number): Promise<Map<number, { portions: number | null; short: string[] }>> {
  // stock de l'entrepôt où le restaurant consomme (cuisine / magasin par défaut)
  const { restaurantWarehouse } = await import('./stock.js');
  const w = await restaurantWarehouse(db, hotelId);
  const rows = await q<any>(db, `SELECT r.item_id, p.name, COALESCE(sl.qty, 0) AS stock_qty, r.quantity FROM rs_recipes r JOIN products p ON p.id = r.product_id JOIN rs_items i ON i.id = r.item_id
      LEFT JOIN stock_levels sl ON sl.product_id = p.id AND sl.warehouse_id = $2 WHERE i.hotel_id = $1`, [hotelId, w.id]);
  const m = new Map<number, { portions: number | null; short: string[] }>();
  for (const r of rows) {
    const n = Math.floor(Number(r.stock_qty) / Number(r.quantity) + 1e-9);
    const cur = m.get(r.item_id) ?? { portions: Infinity as number, short: [] as string[] };
    cur.portions = Math.min(cur.portions as number, Math.max(0, n));
    if (n < 1) cur.short.push(r.name);
    m.set(r.item_id, cur);
  }
  return m;
}

export async function listItems(db: Db, hotelId: number, o: { all?: boolean } = {}) {
  const items = await q<any>(db,
    `SELECT i.*, c.name AS category, c.kind AS category_kind, COALESCE(i.station, c.station) AS eff_station, c.sort_order AS cat_order,
            (SELECT min(p.id) FROM photos p WHERE p.owner_type = 'menu_item' AND p.owner_id = i.id) AS photo_id,
            COALESCE((SELECT json_agg(row_to_json(x) ORDER BY x.kind DESC, x.sort_order, x.id) FROM (SELECT id, kind, name, price_delta, active, sort_order FROM rs_item_options o WHERE o.item_id = i.id ${o.all ? '' : 'AND o.active'}) x), '[]') AS options,
            COALESCE((SELECT json_agg(json_build_object('product_id', r.product_id, 'name', p.name, 'unit', p.unit, 'quantity', r.quantity)) FROM rs_recipes r JOIN products p ON p.id = r.product_id WHERE r.item_id = i.id), '[]') AS recipe
       FROM rs_items i JOIN rs_categories c ON c.id = i.category_id
      WHERE i.hotel_id = $1 ${o.all ? '' : 'AND i.active AND c.active'} ORDER BY c.sort_order, c.name, i.sort_order, i.name`, [hotelId]);
  const pm = await portions(db, hotelId);
  return items.map((i) => {
    const p = pm.get(i.id);
    const stockOut = !!p && (p.portions ?? 1) < 1;
    return { ...i, price: Number(i.price), portions: p ? p.portions : null, stock_short: p?.short ?? [], orderable: i.active && i.available && !stockOut, unavailable_reason: !i.available ? 'manual' : stockOut ? 'stock' : null };
  });
}

/** Plats proposés à un point de vente à une heure donnée : menus actifs (jour, horaire, menu du jour) ; à défaut, toute la carte du point de vente. */
export async function currentMenu(db: Db, hotelId: number, outlet: Outlet, at = new Date()) {
  const local = new Date(at.toLocaleString('en-US', { timeZone: TZ }));
  const hhmm = `${String(local.getHours()).padStart(2, '0')}:${String(local.getMinutes()).padStart(2, '0')}`;
  const d = today();
  const menus = await q<any>(db,
    `SELECT m.*, COALESCE(array_agg(mi.item_id) FILTER (WHERE mi.item_id IS NOT NULL), '{}') AS item_ids FROM rs_menus m LEFT JOIN rs_menu_items mi ON mi.menu_id = m.id
      WHERE m.hotel_id = $1 AND m.active AND $2 = ANY(m.outlets) AND (m.menu_date IS NULL OR m.menu_date = $3) AND $4 = ANY(m.days)
        AND $5::time BETWEEN m.start_time AND m.end_time GROUP BY m.id ORDER BY m.menu_date NULLS LAST, m.name`, [hotelId, outlet, d, local.getDay(), hhmm]);
  const items = await listItems(db, hotelId);
  const configured = await one<any>(db, `SELECT 1 FROM rs_menus WHERE hotel_id = $1 AND active AND $2 = ANY(outlets) LIMIT 1`, [hotelId, outlet]);
  let ids: Set<number> | null = null;
  if (configured && menus.length) ids = new Set(menus.flatMap((m) => m.item_ids));
  const byOutlet = (i: any) => (outlet === 'bar' ? i.category_kind === 'drink' : outlet === 'breakfast' ? ['breakfast', 'drink'].includes(i.category_kind) : true);
  // hors des horaires de tous les menus : la carte du point de vente reste proposée, avec un avertissement
  return { menus: menus.map(({ item_ids, ...m }) => ({ ...m, items: item_ids.length })), items: items.filter((i) => (ids ? ids.has(i.id) : byOutlet(i))), configured: !!configured, outside_hours: !!configured && !menus.length };
}

// =====================================================================================================
// Commandes
// =====================================================================================================
async function lockOrder(db: PoolClient, actor: Actor, id: number) {
  const o = await one<any>(db, 'SELECT * FROM rs_orders WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!o) throw notFound('Commande introuvable');
  return o;
}
const editable = (o: any) => {
  if (o.status === 'cancelled') throw conflict('Commande annulée.');
  if (o.settlement !== 'open') throw conflict('Commande déjà réglée : modification impossible (annulez au folio ou faites un avoir).');
};
/** Table principale si la table est regroupée. */
async function mainTable(db: Db, hotelId: number, tableId: number) {
  const t = await one<any>(db, 'SELECT * FROM rs_tables WHERE id = $1 AND hotel_id = $2 AND active', [tableId, hotelId]);
  if (!t) throw notFound('Table introuvable');
  return t.merged_into ? (await one<any>(db, 'SELECT * FROM rs_tables WHERE id = $1', [t.merged_into])) : t;
}
const openOrdersOnTable = (db: Db, tableId: number, except = 0) =>
  q<any>(db, `SELECT id, number FROM rs_orders WHERE table_id = $1 AND id <> $2 AND status <> 'cancelled' AND (settlement = 'open' OR status <> 'served')`, [tableId, except]);

/** Séjour en cours dans une chambre (client hébergé). */
export async function stayOfRoom(db: Db, hotelId: number, roomId: number) {
  return one<any>(db,
    `SELECT s.id AS stay_id, rr.id AS rr_id, rr.reservation_id, rr.adults, rr.children, rm.number AS room_number, res.code, res.meal_plan, res.status AS res_status,
            COALESCE(rr.guest_id, res.guest_id) AS guest_id, g.kind, g.last_name, g.first_name, g.company_name, g.vip
       FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN reservations res ON res.id = rr.reservation_id JOIN rooms rm ON rm.id = s.room_id
       JOIN guests g ON g.id = COALESCE(rr.guest_id, res.guest_id)
      WHERE s.room_id = $1 AND rm.hotel_id = $2 AND s.checked_out_at IS NULL LIMIT 1`, [roomId, hotelId]);
}

export async function createOrder(db: PoolClient, actor: Actor, perms: Set<string>, b: {
  outlet: Outlet; table_id?: number | null; room_id?: number | null; covers?: number; guest_name?: string | null; notes?: string | null; priority?: 'normal' | 'high' | 'urgent';
  lines?: LineIn[];
}) {
  let tableId: number | null = null, roomId: number | null = null, stay: any = null;
  if (b.table_id) {
    if (b.outlet === 'room_service') throw badRequest('Room service : choisissez une chambre, pas une table.');
    const t = await mainTable(db, actor.hotelId, b.table_id);
    const busy = await openOrdersOnTable(db, t.id);
    if (busy.length) throw conflict(`Table ${t.number} occupée : ajoutez les plats à la commande ${busy[0].number}.`, { order_id: busy[0].id });
    tableId = t.id;
  }
  if (b.room_id) {
    stay = await stayOfRoom(db, actor.hotelId, b.room_id);
    if (!stay) throw conflict('Aucun client hébergé dans cette chambre.');
    roomId = b.room_id;
  }
  if (b.outlet === 'room_service' && !stay) throw badRequest('Room service : sélectionnez une chambre occupée.');
  const year = today().slice(0, 4);
  const n = await nextNumber(db, `rso-${year}`);
  const o = await one<any>(db,
    `INSERT INTO rs_orders (hotel_id, number, outlet, table_id, room_id, reservation_id, reservation_room_id, guest_id, guest_name, covers, notes, priority, waiter_id, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$13) RETURNING *`,
    [actor.hotelId, `R${year}-${String(n).padStart(5, '0')}`, b.outlet, tableId, roomId, stay?.reservation_id ?? null, stay?.rr_id ?? null, stay?.guest_id ?? null,
      b.guest_name?.trim() || (stay ? guestDisplayName(stay) : null), b.covers ?? 1, b.notes?.trim() || null, b.priority ?? 'normal', actor.userId]);
  if (tableId) await db.query(`UPDATE rs_tables SET status = 'occupied' WHERE id = $1`, [tableId]);
  await audit(db, actor, 'create', 'rs_order', o.id, null, { number: o.number, outlet: b.outlet, table_id: tableId, room_id: roomId });
  if (b.lines?.length) await addLines(db, actor, perms, o.id, b.lines);
  return o;
}

export interface LineIn { item_id: number; quantity: number; option_ids?: number[]; comment?: string | null }

export async function addLines(db: PoolClient, actor: Actor, perms: Set<string>, orderId: number, lines: LineIn[]) {
  const o = await lockOrder(db, actor, orderId);
  editable(o);
  if (!lines.length) throw badRequest('Aucun plat.');
  const settings = await getSettings(db, actor.hotelId);
  const rs = settings.restaurant;
  const exempt = o.reservation_id ? await isTaxExempt(db, [o.guest_id]) : o.guest_id ? await isTaxExempt(db, [o.guest_id]) : false;
  const pm = await portions(db, actor.hotelId);
  const warnings: string[] = [];
  // portions déjà demandées dans les commandes non encore réglées (le stock n'est déduit qu'à la vente)
  const reserved = new Map<number, number>((await q<any>(db, `SELECT l.item_id, sum(l.quantity)::int AS n FROM rs_order_lines l JOIN rs_orders o ON o.id = l.order_id
      WHERE o.hotel_id = $1 AND NOT l.cancelled AND o.settlement = 'open' AND o.status <> 'cancelled' GROUP BY l.item_id`, [actor.hotelId])).map((r) => [r.item_id, r.n]));
  for (const l of lines) {
    const it = await one<any>(db, `SELECT i.*, c.kind AS category_kind, COALESCE(i.station, c.station) AS eff_station, c.active AS cat_active
                                     FROM rs_items i JOIN rs_categories c ON c.id = i.category_id WHERE i.id = $1 AND i.hotel_id = $2`, [l.item_id, actor.hotelId]);
    if (!it || !it.active || !it.cat_active) throw notFound('Plat introuvable ou retiré de la carte.');
    if (!it.available) throw conflict(`« ${it.name} » est indisponible.`);
    if (!(l.quantity >= 1 && l.quantity <= 100 && Number.isInteger(l.quantity))) throw badRequest('Quantité invalide.');
    const p = pm.get(it.id);
    if (p && p.portions !== null) {
      const left = (p.portions as number) - (reserved.get(it.id) ?? 0);
      if (left < l.quantity) {
        const msg = `Stock insuffisant pour « ${it.name} » (${Math.max(0, left)} portion(s) possible(s)${p.short.length ? ` — manque : ${p.short.join(', ')}` : ''}).`;
        if (rs.stock_block) throw new AppError(409, 'stock', msg);
        warnings.push(msg);
      }
      reserved.set(it.id, (reserved.get(it.id) ?? 0) + l.quantity);
    }
    const ids = [...new Set(l.option_ids ?? [])];
    const opts = ids.length ? await q<any>(db, 'SELECT * FROM rs_item_options WHERE item_id = $1 AND id = ANY($2::int[]) AND active', [it.id, ids]) : [];
    if (opts.length !== ids.length) throw badRequest('Option invalide pour ce plat.');
    if (opts.filter((x) => x.kind === 'variant').length > 1) throw badRequest('Une seule variante par plat.');
    const hasVariants = await one(db, `SELECT 1 FROM rs_item_options WHERE item_id = $1 AND kind = 'variant' AND active`, [it.id]);
    if (hasVariants && !opts.some((x) => x.kind === 'variant')) throw badRequest(`Choisissez une variante pour « ${it.name} ».`);
    const unit = fromCents(toCents(it.price) + opts.reduce((a, x) => a + toCents(x.price_delta), 0));
    if (unit < 0) throw badRequest('Prix négatif.');
    const rate = exempt ? 0 : taxRateFor(settings, OUTLET_KIND[o.outlet as Outlet]);
    await db.query(
      `INSERT INTO rs_order_lines (order_id, item_id, name, category_kind, station, unit_price, options, quantity, comment, tax_rate, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
      [o.id, it.id, it.name, it.category_kind, it.eff_station, unit, JSON.stringify(opts.map((x) => ({ id: x.id, kind: x.kind, name: x.name, price_delta: Number(x.price_delta) }))),
        l.quantity, l.comment?.trim() || null, rate, actor.userId]);
  }
  await recalc(db, o.id);
  await refreshStatus(db, o.id);
  await audit(db, actor, 'add_lines', 'rs_order', o.id, null, { lines });
  return { warnings };
}

export async function updateLine(db: PoolClient, actor: Actor, lineId: number, b: { quantity?: number; comment?: string | null }) {
  const l = await one<any>(db, 'SELECT l.* FROM rs_order_lines l JOIN rs_orders o ON o.id = l.order_id WHERE l.id = $1 AND o.hotel_id = $2', [lineId, actor.hotelId]);
  if (!l) throw notFound('Ligne introuvable');
  const o = await lockOrder(db, actor, l.order_id);
  editable(o);
  if (l.cancelled) throw conflict('Ligne annulée.');
  if (l.kitchen_status !== 'pending') throw conflict('Plat déjà envoyé en cuisine : annulez la ligne puis ajoutez-en une nouvelle.');
  if (b.quantity !== undefined && !(Number.isInteger(b.quantity) && b.quantity >= 1 && b.quantity <= 100)) throw badRequest('Quantité invalide.');
  await db.query('UPDATE rs_order_lines SET quantity = COALESCE($2, quantity), comment = CASE WHEN $3::boolean THEN $4 ELSE comment END WHERE id = $1',
    [lineId, b.quantity ?? null, b.comment !== undefined, b.comment?.trim() || null]);
  await recalc(db, o.id);
  await audit(db, actor, 'update_line', 'rs_order', o.id, { line: lineId, quantity: l.quantity, comment: l.comment }, { line: lineId, ...b });
}

export async function cancelLine(db: PoolClient, actor: Actor, perms: Set<string>, lineId: number, reason: string) {
  const l = await one<any>(db, 'SELECT l.* FROM rs_order_lines l JOIN rs_orders o ON o.id = l.order_id WHERE l.id = $1 AND o.hotel_id = $2', [lineId, actor.hotelId]);
  if (!l) throw notFound('Ligne introuvable');
  const o = await lockOrder(db, actor, l.order_id);
  editable(o);
  if (l.cancelled) throw conflict('Ligne déjà annulée.');
  if (l.kitchen_status !== 'pending') {
    if (!perms.has('restaurant.cancel')) throw forbidden('Plat déjà envoyé en cuisine : annulation réservée au responsable.');
    if (!reason?.trim()) throw badRequest('Motif obligatoire.');
  }
  await db.query('UPDATE rs_order_lines SET cancelled = true, cancel_reason = $2, cancelled_by = $3 WHERE id = $1', [lineId, reason?.trim() || 'Retiré avant envoi', actor.userId]);
  await recalc(db, o.id);
  await refreshStatus(db, o.id);
  await audit(db, actor, 'cancel_line', 'rs_order', o.id, { line: lineId, name: l.name, quantity: l.quantity, sent: l.kitchen_status !== 'pending' }, { reason });
}

/** Totaux : remise répartie sur les lignes (centime près), TVA par ligne sur le net — mêmes règles que le folio et les factures. */
export async function recalc(db: PoolClient, orderId: number) {
  const o = await one<any>(db, 'SELECT * FROM rs_orders WHERE id = $1', [orderId]);
  const lines = await q<any>(db, 'SELECT * FROM rs_order_lines WHERE order_id = $1 AND NOT cancelled ORDER BY id', [orderId]);
  const gross = lines.map((l) => Math.round(toCents(l.unit_price) * l.quantity));
  const total = gross.reduce((a, b) => a + b, 0);
  let disc = 0;
  if (o.discount_type === 'percent') disc = Math.round((total * Number(o.discount_value)) / 100);
  else if (o.discount_type === 'amount') disc = Math.min(toCents(o.discount_value), total);
  let left = disc, tax = 0;
  for (const [i, l] of lines.entries()) {
    const d = i === lines.length - 1 ? left : Math.min(left, shareCents(disc, gross[i], total));
    left -= d;
    tax += taxCents(gross[i] - d, Number(l.tax_rate));
    await db.query('UPDATE rs_order_lines SET discount = $2 WHERE id = $1', [l.id, fromCents(d)]);
  }
  await db.query('UPDATE rs_orders SET subtotal = $2, discount_total = $3, tax_total = $4, total = $5 WHERE id = $1',
    [orderId, fromCents(total), fromCents(disc), fromCents(tax), fromCents(total - disc + tax)]);
}

export async function setDiscount(db: PoolClient, actor: Actor, id: number, b: { type: 'percent' | 'amount' | null; value: number; reason?: string | null }) {
  const o = await lockOrder(db, actor, id);
  editable(o);
  const rs = await rsSettings(db, actor.hotelId);
  if (b.type) {
    if (!(b.value > 0)) throw badRequest('Valeur de remise invalide.');
    if (!b.reason?.trim()) throw badRequest('Motif de la remise obligatoire.');
    if (b.type === 'percent' && b.value > rs.max_discount_percent) throw badRequest(`Remise maximale autorisée : ${rs.max_discount_percent} %.`);
    if (b.type === 'amount' && toCents(b.value) > toCents(o.subtotal)) throw badRequest('Remise supérieure au montant de la commande.');
  }
  await db.query('UPDATE rs_orders SET discount_type = $2, discount_value = $3, discount_reason = $4, discount_by = $5 WHERE id = $1',
    [id, b.type, b.type ? b.value : 0, b.type ? b.reason!.trim() : null, b.type ? actor.userId : null]);
  await recalc(db, id);
  await audit(db, actor, 'discount', 'rs_order', id, { type: o.discount_type, value: Number(o.discount_value) }, b);
}

/** Statut de la commande déduit des lignes (chaque poste — cuisine, bar, pâtisserie — avance indépendamment). */
export async function refreshStatus(db: PoolClient, orderId: number) {
  const o = await one<any>(db, 'SELECT * FROM rs_orders WHERE id = $1', [orderId]);
  if (o.status === 'cancelled') return o.status;
  const all = await q<any>(db, 'SELECT kitchen_status, station FROM rs_order_lines WHERE order_id = $1 AND NOT cancelled', [orderId]);
  // les articles sans préparation (eau, sodas) prêts d'office ne font pas passer la commande « en préparation »
  const prep = all.filter((l) => l.station !== 'none');
  const ls = (prep.length && !all.every((l) => l.kitchen_status === 'served' || l.kitchen_status === 'ready') ? prep : all).map((l) => l.kitchen_status);
  if (prep.length && all.some((l) => l.kitchen_status === 'pending') && !ls.includes('pending')) ls.push('pending');
  let st = 'new';
  if (!ls.length || ls.every((s) => s === 'pending')) st = 'new';
  else if (ls.every((s) => s === 'served')) st = 'served';
  else if (ls.every((s) => s === 'ready' || s === 'served')) st = 'ready';
  else if (ls.some((s) => s === 'preparing' || s === 'ready' || s === 'served')) st = 'preparing';
  else st = 'confirmed';
  await db.query(`UPDATE rs_orders SET status = $2,
      confirmed_at = CASE WHEN $2 <> 'new' THEN COALESCE(confirmed_at, now()) ELSE confirmed_at END,
      preparing_at = CASE WHEN $2 IN ('preparing','ready','served') THEN COALESCE(preparing_at, now()) ELSE preparing_at END,
      ready_at = CASE WHEN $2 IN ('ready','served') THEN COALESCE(ready_at, now()) ELSE NULL END,
      served_at = CASE WHEN $2 = 'served' THEN COALESCE(served_at, now()) ELSE NULL END WHERE id = $1`, [orderId, st]);
  if (st === 'served') await maybeFreeTable(db, orderId);
  return st;
}

/** Envoi en cuisine des lignes en attente (les articles sans préparation sont prêts immédiatement). */
export async function confirmOrder(db: PoolClient, actor: Actor, id: number) {
  const o = await lockOrder(db, actor, id);
  if (o.status === 'cancelled') throw conflict('Commande annulée.');
  const r = await db.query(`UPDATE rs_order_lines SET kitchen_status = CASE WHEN station = 'none' THEN 'ready' ELSE 'sent' END, sent_at = now(),
      ready_at = CASE WHEN station = 'none' THEN now() END WHERE order_id = $1 AND NOT cancelled AND kitchen_status = 'pending'`, [id]);
  if (!r.rowCount) throw conflict('Aucun plat à envoyer en cuisine.');
  const st = await refreshStatus(db, id);
  await audit(db, actor, 'confirm', 'rs_order', id, { status: o.status }, { status: st, lines: r.rowCount });
  return { status: st, sent: r.rowCount };
}

/** Cuisine / bar : démarrer la préparation ou signaler « prêt » pour un poste (ou toute la commande). */
export async function kitchenAction(db: PoolClient, actor: Actor, id: number, action: 'start' | 'ready', station?: string | null) {
  const o = await lockOrder(db, actor, id);
  if (o.status === 'cancelled') throw conflict('Commande annulée.');
  const from = action === 'start' ? ['sent'] : ['sent', 'preparing'];
  const r = await db.query(
    `UPDATE rs_order_lines SET kitchen_status = $2, started_at = COALESCE(started_at, now()), ready_at = CASE WHEN $2 = 'ready' THEN now() ELSE ready_at END
      WHERE order_id = $1 AND NOT cancelled AND kitchen_status = ANY($3::text[]) AND ($4::text IS NULL OR station = $4)`,
    [id, action === 'start' ? 'preparing' : 'ready', from, station ?? null]);
  if (!r.rowCount) throw conflict(action === 'start' ? 'Rien à préparer pour ce poste.' : 'Aucun plat en préparation pour ce poste.');
  const st = await refreshStatus(db, id);
  await audit(db, actor, `kitchen_${action}`, 'rs_order', id, { status: o.status }, { status: st, station: station ?? null });
  return { status: st };
}

/** Service en salle / livraison room service. Room service livré → consommations ajoutées au folio. */
export async function serveOrder(db: PoolClient, actor: Actor, perms: Set<string>, id: number) {
  const o = await lockOrder(db, actor, id);
  if (o.status === 'cancelled') throw conflict('Commande annulée.');
  const pending = await one<any>(db, `SELECT count(*) FILTER (WHERE kitchen_status IN ('pending','sent','preparing'))::int AS n, count(*)::int AS total FROM rs_order_lines WHERE order_id = $1 AND NOT cancelled`, [id]);
  if (!pending.total) throw conflict('Commande vide.');
  if (pending.n) throw conflict('Des plats ne sont pas encore prêts.');
  await db.query(`UPDATE rs_order_lines SET kitchen_status = 'served' WHERE order_id = $1 AND NOT cancelled AND kitchen_status = 'ready'`, [id]);
  const st = await refreshStatus(db, id);
  await audit(db, actor, o.outlet === 'room_service' ? 'deliver' : 'serve', 'rs_order', id, { status: o.status }, { status: st });
  let settled = null;
  if (o.outlet === 'room_service') {
    if (o.settlement === 'open') settled = await settle(db, actor, id, { mode: 'room' }, { system: true });
    await trayNote(db, actor, o);
  }
  return { status: st, settled };
}

/** Housekeeping : le plateau du room service est signalé sur la tâche ménage ouverte de la chambre. */
async function trayNote(db: PoolClient, actor: Actor, o: any) {
  const t = await one<any>(db, `SELECT id FROM housekeeping_tasks WHERE room_id = $1 AND status IN ('todo','in_progress') ORDER BY id DESC LIMIT 1`, [o.room_id]);
  if (t) await db.query(`INSERT INTO hk_task_comments (task_id, kind, text, created_by) VALUES ($1,'comment',$2,$3)`, [t.id, `Plateau room service à récupérer (${o.number})`, actor.userId]);
}

export async function roomServiceAction(db: PoolClient, actor: Actor, id: number, b: { action: 'assign' | 'out'; user_id?: number | null }) {
  const o = await lockOrder(db, actor, id);
  if (o.outlet !== 'room_service') throw badRequest('Commande hors room service.');
  if (o.status === 'cancelled' || o.status === 'served') throw conflict('Commande clôturée.');
  if (b.action === 'assign') {
    const u = b.user_id ? await one<any>(db, 'SELECT id, full_name FROM users WHERE id = $1 AND hotel_id = $2 AND active', [b.user_id, actor.hotelId]) : null;
    if (b.user_id && !u) throw badRequest('Employé introuvable.');
    await db.query('UPDATE rs_orders SET assigned_to = $2 WHERE id = $1', [id, b.user_id ?? null]);
  } else {
    if (o.status !== 'ready') throw conflict('La commande doit être prête avant de partir en livraison.');
    await db.query('UPDATE rs_orders SET out_at = now(), assigned_to = COALESCE(assigned_to, $2) WHERE id = $1', [id, actor.userId]);
  }
  await audit(db, actor, `rs_${b.action}`, 'rs_order', id, { assigned_to: o.assigned_to }, b);
}

export async function cancelOrder(db: PoolClient, actor: Actor, perms: Set<string>, id: number, reason: string) {
  const o = await lockOrder(db, actor, id);
  if (o.status === 'cancelled') throw conflict('Commande déjà annulée.');
  if (o.settlement !== 'open') throw conflict('Commande réglée : annulation impossible ici (annulez les prestations au folio ou émettez un avoir).');
  if (!reason?.trim()) throw badRequest('Motif obligatoire.');
  const sent = await one(db, `SELECT 1 FROM rs_order_lines WHERE order_id = $1 AND NOT cancelled AND kitchen_status <> 'pending'`, [id]);
  if (sent && !perms.has('restaurant.cancel')) throw forbidden('Commande envoyée en cuisine : annulation réservée au responsable.');
  await db.query(`UPDATE rs_order_lines SET cancelled = true, cancel_reason = COALESCE(cancel_reason, $2), cancelled_by = COALESCE(cancelled_by, $3) WHERE order_id = $1 AND NOT cancelled`, [id, reason.trim(), actor.userId]);
  await db.query(`UPDATE rs_orders SET status = 'cancelled', settlement = 'cancelled', cancelled_at = now(), cancelled_by = $2, cancel_reason = $3 WHERE id = $1`, [id, actor.userId, reason.trim()]);
  await maybeFreeTable(db, id, !!sent);
  await audit(db, actor, 'cancel', 'rs_order', id, { status: o.status, total: Number(o.total) }, { status: 'cancelled', reason });
}

async function maybeFreeTable(db: PoolClient, orderId: number, used = true) {
  const o = await one<any>(db, 'SELECT * FROM rs_orders WHERE id = $1', [orderId]);
  if (!o.table_id) return;
  const closed = o.status === 'cancelled' || (o.status === 'served' && o.settlement !== 'open');
  if (!closed) return;
  if ((await openOrdersOnTable(db, o.table_id, o.id)).length) return;
  const rs = await rsSettings(db, o.hotel_id);
  await db.query(`UPDATE rs_tables SET status = $2 WHERE id = $1`, [o.table_id, used && rs.table_to_clean ? 'to_clean' : 'available']);
}

export async function moveOrder(db: PoolClient, actor: Actor, id: number, tableId: number) {
  const o = await lockOrder(db, actor, id);
  editable(o);
  if (o.outlet === 'room_service') throw badRequest('Room service : pas de table.');
  const t = await mainTable(db, actor.hotelId, tableId);
  if (t.id === o.table_id) throw conflict('La commande est déjà sur cette table.');
  const busy = await openOrdersOnTable(db, t.id, id);
  if (busy.length) throw conflict(`Table ${t.number} occupée (commande ${busy[0].number}).`);
  await db.query('UPDATE rs_orders SET table_id = $2 WHERE id = $1', [id, t.id]);
  await db.query(`UPDATE rs_tables SET status = 'occupied' WHERE id = $1`, [t.id]);
  if (o.table_id && !(await openOrdersOnTable(db, o.table_id)).length) await db.query(`UPDATE rs_tables SET status = 'available' WHERE id = $1`, [o.table_id]);
  await audit(db, actor, 'move', 'rs_order', id, { table_id: o.table_id }, { table_id: t.id });
}

// =====================================================================================================
// Tables : regroupement / séparation, réservations
// =====================================================================================================
export async function mergeTables(db: PoolClient, actor: Actor, mainId: number, ids: number[]) {
  const main = await one<any>(db, 'SELECT * FROM rs_tables WHERE id = $1 AND hotel_id = $2 AND active FOR UPDATE', [mainId, actor.hotelId]);
  if (!main) throw notFound('Table introuvable');
  if (main.merged_into) throw conflict(`La table ${main.number} est déjà regroupée.`);
  for (const id of ids.filter((x) => x !== mainId)) {
    const t = await one<any>(db, 'SELECT * FROM rs_tables WHERE id = $1 AND hotel_id = $2 AND active FOR UPDATE', [id, actor.hotelId]);
    if (!t) throw notFound('Table introuvable');
    if (t.merged_into && t.merged_into !== mainId) throw conflict(`La table ${t.number} est déjà regroupée.`);
    if (await one(db, 'SELECT 1 FROM rs_tables WHERE merged_into = $1', [id])) throw conflict(`La table ${t.number} est principale d'un autre groupe.`);
    if ((await openOrdersOnTable(db, id)).length) throw conflict(`Table ${t.number} : commande en cours, déplacez-la d'abord.`);
    await db.query('UPDATE rs_tables SET merged_into = $2 WHERE id = $1', [id, mainId]);
  }
  await audit(db, actor, 'merge', 'rs_table', mainId, null, { tables: ids });
}
export async function splitTable(db: PoolClient, actor: Actor, id: number) {
  const t = await one<any>(db, 'SELECT * FROM rs_tables WHERE id = $1 AND hotel_id = $2', [id, actor.hotelId]);
  if (!t) throw notFound('Table introuvable');
  const r = t.merged_into ? await db.query('UPDATE rs_tables SET merged_into = NULL WHERE id = $1', [id]) : await db.query('UPDATE rs_tables SET merged_into = NULL WHERE merged_into = $1', [id]);
  if (!r.rowCount) throw conflict('Table non regroupée.');
  await audit(db, actor, 'split', 'rs_table', id, null, null);
}

export async function bookTable(db: PoolClient, actor: Actor, b: { table_id: number; guest_name: string; phone?: string | null; room_id?: number | null; party_size: number; starts_at: string; duration_min?: number; notes?: string | null }) {
  const t = await one<any>(db, 'SELECT * FROM rs_tables WHERE id = $1 AND hotel_id = $2 AND active FOR UPDATE', [b.table_id, actor.hotelId]);
  if (!t) throw notFound('Table introuvable');
  const capacity = Number((await one<any>(db, 'SELECT sum(capacity)::int AS c FROM rs_tables WHERE id = $1 OR merged_into = $1', [t.id])).c);
  if (b.party_size > capacity) throw badRequest(`Capacité de la table ${t.number} : ${capacity} couverts.`);
  if (new Date(b.starts_at).getTime() < Date.now() - 15 * 60_000) throw badRequest('Horaire passé.');
  const dur = b.duration_min ?? 90;
  const clash = await one<any>(db, `SELECT guest_name, starts_at FROM rs_table_bookings WHERE table_id = $1 AND status IN ('booked','seated')
      AND tstzrange(starts_at, starts_at + make_interval(mins => duration_min)) && tstzrange($2::timestamptz, $2::timestamptz + make_interval(mins => $3))`, [t.id, b.starts_at, dur]);
  if (clash) throw conflict(`Table ${t.number} déjà réservée sur ce créneau (${clash.guest_name}).`);
  let guestId: number | null = null;
  if (b.room_id) guestId = (await stayOfRoom(db, actor.hotelId, b.room_id))?.guest_id ?? null;
  const r = await one<any>(db, `INSERT INTO rs_table_bookings (hotel_id, table_id, guest_name, phone, guest_id, room_id, party_size, starts_at, duration_min, notes, created_by)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [actor.hotelId, t.id, b.guest_name.trim(), b.phone ?? null, guestId, b.room_id ?? null, b.party_size, b.starts_at, dur, b.notes ?? null, actor.userId]);
  await audit(db, actor, 'book', 'rs_table', t.id, null, { booking_id: r.id, guest: b.guest_name, at: b.starts_at });
  return r;
}
export async function bookingStatus(db: PoolClient, actor: Actor, id: number, status: 'seated' | 'cancelled' | 'no_show') {
  const bk = await one<any>(db, 'SELECT * FROM rs_table_bookings WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!bk) throw notFound('Réservation de table introuvable');
  if (bk.status !== 'booked') throw conflict('Réservation déjà traitée.');
  await db.query('UPDATE rs_table_bookings SET status = $2 WHERE id = $1', [id, status]);
  await audit(db, actor, status, 'rs_table_booking', id, { status: bk.status }, { status });
}

/** Plan de salle : statut affiché = occupée (commande ouverte) > à nettoyer > réservée (créneau dans l'heure) > disponible. */
export async function floorPlan(db: Db, hotelId: number) {
  const tables = await q<any>(db, `SELECT t.*, m.number AS merged_into_number,
      (SELECT row_to_json(x) FROM (SELECT o.id, o.number, o.status, o.total, o.covers, o.created_at, o.settlement, u.full_name AS waiter FROM rs_orders o LEFT JOIN users u ON u.id = o.waiter_id
        WHERE o.table_id = t.id AND o.status <> 'cancelled' AND (o.settlement = 'open' OR o.status <> 'served') ORDER BY o.id LIMIT 1) x) AS order,
      (SELECT row_to_json(b) FROM (SELECT id, guest_name, party_size, starts_at, phone, status FROM rs_table_bookings WHERE table_id = t.id AND status IN ('booked','seated')
        AND starts_at BETWEEN now() - interval '30 minutes' AND now() + interval '60 minutes' ORDER BY starts_at LIMIT 1) b) AS booking
     FROM rs_tables t LEFT JOIN rs_tables m ON m.id = t.merged_into WHERE t.hotel_id = $1 AND t.active ORDER BY t.area, length(t.number), t.number`, [hotelId]);
  const byId = new Map(tables.map((t) => [t.id, t]));
  return tables.map((t) => {
    const main = t.merged_into ? byId.get(t.merged_into) : t;
    const order = main?.order ?? null;
    const display = order ? 'occupied' : (main?.status === 'to_clean' || t.status === 'to_clean') ? 'to_clean' : main?.booking?.status === 'booked' || t.booking?.status === 'booked' ? 'reserved' : 'available';
    return { ...t, order, display };
  });
}

// =====================================================================================================
// Règlement : paiement immédiat, chambre (folio), facture indépendante — une seule fois par commande
// =====================================================================================================
async function walkInGuest(db: PoolClient, hotelId: number) {
  const g = await one<any>(db, `SELECT id FROM guests WHERE hotel_id = $1 AND kind = 'person' AND last_name = 'Client restaurant' AND first_name IS NULL ORDER BY id LIMIT 1`, [hotelId]);
  if (g) return g.id as number;
  return (await one<any>(db, `INSERT INTO guests (hotel_id, kind, last_name) VALUES ($1,'person','Client restaurant') RETURNING id`, [hotelId])).id as number;
}

export async function settle(db: PoolClient, actor: Actor, id: number, b: {
  mode: 'pay' | 'room' | 'invoice'; room_id?: number | null;
  payments?: { method: 'cash' | 'card' | 'cheque' | 'transfer'; amount: number; reference?: string | null; card_last4?: string | null }[];
  bill_to?: { id?: number; kind?: 'person' | 'company'; last_name?: string | null; first_name?: string | null; company_name?: string | null; nif?: string | null; address?: string | null } | null;
}, opts: { system?: boolean } = {}) {
  const o = await lockOrder(db, actor, id);
  if (o.status === 'cancelled') throw conflict('Commande annulée.');
  if (o.settlement !== 'open') throw new AppError(409, 'already_settled', `Commande déjà réglée (${SETTLE_LABEL[o.settlement]}) : aucune double facturation possible.`);
  // les plats non encore envoyés partent en cuisine (vente comptoir)
  const pend = await one(db, `SELECT 1 FROM rs_order_lines WHERE order_id = $1 AND NOT cancelled AND kitchen_status = 'pending'`, [id]);
  if (pend) await confirmOrder(db, actor, id);
  await recalc(db, id);
  const ord = await one<any>(db, 'SELECT * FROM rs_orders WHERE id = $1', [id]);
  const lines = await q<any>(db, 'SELECT * FROM rs_order_lines WHERE order_id = $1 AND NOT cancelled ORDER BY id', [id]);
  if (!lines.length || toCents(ord.total) <= 0) throw conflict('Commande vide : rien à régler.');
  const kind = OUTLET_KIND[o.outlet as Outlet];
  let invoiceId: number | null = null;

  if (b.mode === 'room') {
    let rrId = o.reservation_room_id, resId = o.reservation_id;
    const roomId = b.room_id ?? o.room_id;
    if (!roomId) throw badRequest('Choisissez la chambre du client.');
    const stay = await stayOfRoom(db, actor.hotelId, roomId);
    if (!stay) throw conflict('Aucun client hébergé dans cette chambre : réglez sur place.');
    if (rrId && rrId !== stay.rr_id) throw conflict('Le client de cette chambre a changé : vérifiez la chambre.');
    rrId = stay.rr_id; resId = stay.reservation_id;
    const res = await one<any>(db, 'SELECT status FROM reservations WHERE id = $1 FOR UPDATE', [resId]);
    if (['cancelled', 'no_show', 'checked_out'].includes(res.status)) throw conflict('Dossier clôturé : impossible de porter sur la chambre.');
    for (const l of lines) {
      const net = toCents(l.unit_price) * l.quantity - toCents(l.discount);
      const plain = toCents(l.discount) === 0;
      const opt = (l.options as any[]).map((x) => x.name).join(', ');
      const desc = `${l.name}${opt ? ` (${opt})` : ''}${plain ? '' : ` × ${l.quantity} (remise incluse)`} — ${o.number}`;
      await db.query(
        `INSERT INTO charges (reservation_id, reservation_room_id, service_date, kind, description, quantity, unit_price, total, created_by, tax_rate, rs_order_line_id)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        [resId, rrId, today(), kind, desc, plain ? l.quantity : 1, plain ? Number(l.unit_price) : fromCents(net), fromCents(net), actor.userId, l.tax_rate, l.id]);
    }
    await db.query('UPDATE rs_orders SET room_id = $2, reservation_id = $3, reservation_room_id = $4, guest_id = COALESCE(guest_id, $5) WHERE id = $1', [id, roomId, resId, rrId, stay.guest_id]);
  } else {
    let guest: any;
    if (b.mode === 'invoice') {
      if (!b.bill_to) throw badRequest('Indiquez le client à facturer.');
      guest = b.bill_to;
    } else guest = { id: o.guest_id ?? (await walkInGuest(db, actor.hotelId)) };
    const { manualInvoice, payInvoice } = await import('./billing.js');
    const inv = await manualInvoice(db, actor, {
      guest, notes: `${OUTLET_LABEL[o.outlet]} — commande ${o.number}`,
      lines: lines.map((l) => ({ description: `${l.name}${(l.options as any[]).length ? ` (${(l.options as any[]).map((x) => x.name).join(', ')})` : ''}`, category: kind, quantity: l.quantity, unit_price: Number(l.unit_price), discount: Number(l.discount), tax_rate: Number(l.tax_rate) })),
    });
    if (toCents(inv.total) !== toCents(ord.total)) throw new AppError(500, 'mismatch', `Écart de calcul facture (${inv.total}) / commande (${ord.total}).`);
    invoiceId = inv.id;
    if (b.mode === 'pay') {
      const pays = b.payments ?? [];
      const sum = pays.reduce((a, p) => a + toCents(p.amount), 0);
      if (sum !== toCents(ord.total)) throw badRequest(`Total des paiements (${fromCents(sum)} ${currency.symbol}) différent du montant de la commande (${ord.total} ${currency.symbol}).`);
      for (const p of pays) await payInvoice(db, actor, inv.id, p);
    }
  }
  await db.query(`UPDATE rs_orders SET settlement = $2, invoice_id = $3, settled_at = now(), settled_by = $4 WHERE id = $1`, [id, b.mode === 'pay' ? 'paid' : b.mode, invoiceId, actor.userId]);
  const alerts = await deductStock(db, actor, id);
  await maybeFreeTable(db, id);
  await audit(db, actor, opts.system ? 'auto_settle' : 'settle', 'rs_order', id, { settlement: 'open' }, { settlement: b.mode, invoice_id: invoiceId, total: Number(ord.total) });
  // CRM : points de fidélité sur une commande réglée directement (une seule fois)
  const { earnForOrder } = await import('./crm.js');
  await earnForOrder(db, actor, id);
  return { settlement: b.mode === 'pay' ? 'paid' : b.mode, invoice_id: invoiceId, total: Number(ord.total), stock_alerts: alerts };
}

/** Déduction du stock des ingrédients à la validation de la vente (une seule fois), depuis l'entrepôt du restaurant. */
async function deductStock(db: PoolClient, actor: Actor, orderId: number) {
  const o = await one<any>(db, 'SELECT * FROM rs_orders WHERE id = $1 FOR UPDATE', [orderId]);
  if (o.stock_done) return [];
  const { moveStock, restaurantWarehouse } = await import('./stock.js');
  const w = await restaurantWarehouse(db, actor.hotelId);
  const need = await q<any>(db, `SELECT r.product_id, sum(r.quantity * l.quantity) AS qty FROM rs_order_lines l JOIN rs_recipes r ON r.item_id = l.item_id
      WHERE l.order_id = $1 AND NOT l.cancelled GROUP BY r.product_id ORDER BY r.product_id`, [orderId]);
  const alerts: string[] = [];
  for (const n of need) {
    // vente déjà validée : la sortie est enregistrée même si le stock théorique est insuffisant (écart signalé à l'inventaire)
    const r = await moveStock(db, actor, { product_id: n.product_id, warehouse_id: w.id, kind: 'sale', quantity: -Number(n.qty), reason: `Vente ${o.number}`, rs_order_id: orderId,
      department: o.outlet === 'bar' ? 'bar' : 'restaurant', ref_type: 'rs_order', ref_id: orderId, allowNegative: true });
    if (r.alert) alerts.push(r.alert);
  }
  await db.query('UPDATE rs_orders SET stock_done = true WHERE id = $1', [orderId]);
  return alerts;
}

/** Ancienne saisie rapide (écran Restaurant › Stock) : entrée, perte, ajustement — via le service de stock central. */
export async function stockMove(db: PoolClient, actor: Actor, b: { product_id: number; kind: 'in' | 'adjust' | 'waste'; quantity: number; reason?: string | null; warehouse_id?: number | null; unit_cost?: number | null }) {
  const { moveStock } = await import('./stock.js');
  if (!b.quantity) throw badRequest('Quantité invalide.');
  if (b.kind !== 'adjust' && b.quantity < 0) throw badRequest('Quantité positive attendue.');
  if (b.kind !== 'in' && !b.reason?.trim()) throw badRequest('Motif obligatoire.');
  const r = await moveStock(db, actor, { product_id: b.product_id, warehouse_id: b.warehouse_id, kind: b.kind, quantity: b.kind === 'waste' ? -b.quantity : b.quantity, reason: b.reason, unit_cost: b.unit_cost ?? null });
  await audit(db, actor, `stock_${b.kind}`, 'product', b.product_id, null, { quantity: b.quantity, reason: b.reason ?? null });
  return r.movement;
}

// =====================================================================================================
// Petit-déjeuner
// =====================================================================================================
export async function breakfastList(db: Db, hotelId: number, d = today()) {
  const rows = await q<any>(db,
    `SELECT rr.id AS rr_id, rr.room_id, rm.number AS room, res.code, res.meal_plan, rr.adults, rr.children, rr.status,
            g.kind, g.last_name, g.first_name, g.company_name, g.vip,
            COALESCE((SELECT sum(b.included) FROM rs_breakfasts b WHERE b.reservation_room_id = rr.id AND b.service_date = $2), 0)::int AS used,
            COALESCE((SELECT sum(b.extra) FROM rs_breakfasts b WHERE b.reservation_room_id = rr.id AND b.service_date = $2), 0)::int AS extra
       FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id JOIN rooms rm ON rm.id = rr.room_id JOIN guests g ON g.id = COALESCE(rr.guest_id, res.guest_id)
      WHERE res.hotel_id = $1 AND rr.check_in < $2 AND rr.check_out >= $2 AND (rr.status = 'checked_in' OR (rr.status = 'checked_out' AND rr.check_out = $2))
      ORDER BY length(rm.number), rm.number`, [hotelId, d]);
  return rows.map((r) => {
    const entitled = ['BB', 'HB', 'FB'].includes(r.meal_plan) ? r.adults + r.children : 0;
    return { ...r, guest: guestDisplayName(r), entitled, remaining: Math.max(0, entitled - r.used) };
  });
}

export async function recordBreakfast(db: PoolClient, actor: Actor, b: { rr_id: number; included: number; extra: number; date?: string }) {
  const d = b.date ?? today();
  if (d > today() || d < addDays(today(), -1)) throw badRequest('Pointage possible pour aujourd\'hui (ou hier) seulement.');
  if (!(b.included >= 0 && b.extra >= 0 && b.included + b.extra > 0)) throw badRequest('Indiquez au moins un petit-déjeuner.');
  await db.query('SELECT pg_advisory_xact_lock($1)', [b.rr_id]);
  const row = (await breakfastList(db, actor.hotelId, d)).find((r) => r.rr_id === b.rr_id);
  if (!row) throw conflict('Client non présent ce jour-là.');
  if (b.included > row.remaining) throw conflict(`Petits-déjeuners inclus restants : ${row.remaining}. Le surplus doit être compté en supplément payant.`);
  const rs = await rsSettings(db, actor.hotelId);
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: TZ }));
  const hhmm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const late = d === today() && (hhmm < rs.breakfast_start || hhmm > rs.breakfast_end);
  let chargeId: number | null = null;
  if (b.extra > 0) {
    const svc = await one<any>(db, 'SELECT id FROM services WHERE hotel_id = $1 AND code = $2 AND active', [actor.hotelId, rs.breakfast_service_code]);
    if (!svc) throw conflict(`Prestation « ${rs.breakfast_service_code} » introuvable dans le catalogue.`);
    const rr = await one<any>(db, 'SELECT reservation_id FROM reservation_rooms WHERE id = $1', [b.rr_id]);
    const { addCharge } = await import('./frontoffice.js');
    chargeId = (await addCharge(db, actor, { reservation_id: rr.reservation_id, reservation_room_id: b.rr_id, service_id: svc.id, quantity: b.extra, service_date: d, description: `Petit-déjeuner supplémentaire` })).id;
  }
  const r = await one<any>(db, `INSERT INTO rs_breakfasts (hotel_id, service_date, reservation_room_id, room_id, guest_name, included, extra, charge_id, late, recorded_by)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`, [actor.hotelId, d, b.rr_id, row.room_id, row.guest, b.included, b.extra, chargeId, late, actor.userId]);
  await audit(db, actor, 'breakfast', 'reservation_room', b.rr_id, null, { date: d, included: b.included, extra: b.extra, late });
  return { ...r, late };
}

// =====================================================================================================
// Tableau de bord & rapports
// =====================================================================================================
const SETTLED = `o.settlement IN ('paid','room','invoice')`;
const day = (col: string) => `(${col} AT TIME ZONE '${TZ}')::date`;

export async function rsDashboard(db: Db, hotelId: number, from: string, to: string) {
  const P = [hotelId, from, to];
  const k = await one<any>(db, `SELECT COALESCE(sum(o.total) FILTER (WHERE ${SETTLED}), 0) AS revenue, count(*) FILTER (WHERE o.status <> 'cancelled')::int AS orders,
      count(*) FILTER (WHERE o.status = 'cancelled')::int AS cancelled, COALESCE(sum(o.covers) FILTER (WHERE o.status <> 'cancelled' AND o.outlet = 'restaurant'), 0)::int AS covers,
      COALESCE(avg(o.total) FILTER (WHERE ${SETTLED}), 0) AS avg_ticket
     FROM rs_orders o WHERE o.hotel_id = $1 AND ${day('o.created_at')} BETWEEN $2 AND $3`, P);
  const live = await one<any>(db, `SELECT count(*) FILTER (WHERE status IN ('new','confirmed'))::int AS pending, count(*) FILTER (WHERE status = 'preparing')::int AS preparing,
      count(*) FILTER (WHERE status = 'ready')::int AS ready, count(*) FILTER (WHERE status = 'served' AND ${day('served_at')} = $2)::int AS served_today,
      count(*) FILTER (WHERE settlement = 'open' AND status <> 'cancelled')::int AS unpaid
     FROM rs_orders WHERE hotel_id = $1`, [hotelId, today()]);
  const plan = await floorPlan(db, hotelId);
  const top = await q<any>(db, `SELECT l.name, sum(l.quantity)::int AS qty, sum(l.unit_price * l.quantity - l.discount) AS revenue FROM rs_order_lines l JOIN rs_orders o ON o.id = l.order_id
      WHERE o.hotel_id = $1 AND ${SETTLED} AND NOT l.cancelled AND ${day('o.created_at')} BETWEEN $2 AND $3 GROUP BY l.name ORDER BY qty DESC, revenue DESC LIMIT 8`, P);
  const series = await q<any>(db, `SELECT d::date AS day, COALESCE((SELECT sum(o.total) FROM rs_orders o WHERE o.hotel_id = $1 AND ${SETTLED} AND ${day('o.created_at')} = d::date), 0) AS revenue
      FROM generate_series($2::date, $3::date, interval '1 day') d ORDER BY d`, P);
  const outlets = await q<any>(db, `SELECT o.outlet, count(*)::int AS orders, COALESCE(sum(o.total), 0) AS revenue FROM rs_orders o
      WHERE o.hotel_id = $1 AND ${SETTLED} AND ${day('o.created_at')} BETWEEN $2 AND $3 GROUP BY o.outlet`, P);
  const low = await q<any>(db, `SELECT id, name, unit, stock_qty, min_stock FROM products WHERE hotel_id = $1 AND active AND stock_qty <= min_stock ORDER BY name`, [hotelId]);
  return {
    kpi: { ...k, revenue: Number(k.revenue), avg_ticket: Math.round(Number(k.avg_ticket) * 100) / 100, ...live,
      tables_total: plan.filter((t) => !t.merged_into).length, tables_occupied: plan.filter((t) => !t.merged_into && t.display === 'occupied').length,
      tables_available: plan.filter((t) => !t.merged_into && t.display === 'available').length },
    top: top.map((t) => ({ ...t, revenue: Number(t.revenue) })), series: series.map((s) => ({ day: String(s.day).slice(0, 10), revenue: Number(s.revenue) })),
    outlets: outlets.map((x) => ({ ...x, label: OUTLET_LABEL[x.outlet], revenue: Number(x.revenue) })), low_stock: low,
  };
}

const col = (key: string, label: string, money = false) => ({ key, label, money });
export const RS_REPORTS: Record<string, { title: string; columns: any[] }> = {
  daily: { title: 'Ventes quotidiennes', columns: [col('day', 'Date'), col('orders', 'Commandes'), col('covers', 'Couverts'), col('gross', 'Brut HT', true), col('discount', 'Remises', true), col('tax', 'TVA', true), col('total', 'Total TTC', true), col('avg', 'Ticket moyen', true)] },
  monthly: { title: 'Ventes mensuelles', columns: [col('month', 'Mois'), col('orders', 'Commandes'), col('covers', 'Couverts'), col('gross', 'Brut HT', true), col('discount', 'Remises', true), col('tax', 'TVA', true), col('total', 'Total TTC', true)] },
  category: { title: 'Chiffre d\'affaires par catégorie', columns: [col('category', 'Catégorie'), col('qty', 'Quantité'), col('revenue', 'CA net HT', true), col('share', 'Part (%)')] },
  items: { title: 'Plats les plus vendus', columns: [col('item', 'Plat'), col('category', 'Catégorie'), col('qty', 'Quantité'), col('revenue', 'CA net HT', true)] },
  cancelled: { title: 'Commandes et plats annulés', columns: [col('date', 'Date'), col('number', 'Commande'), col('what', 'Annulé'), col('amount', 'Montant HT', true), col('reason', 'Motif'), col('by', 'Par')] },
  prep: { title: 'Temps moyen de préparation', columns: [col('station', 'Poste'), col('item', 'Plat'), col('count', 'Préparations'), col('avg_min', 'Moyenne (min)'), col('max_min', 'Maximum (min)')] },
  waiters: { title: 'Ventes par serveur', columns: [col('waiter', 'Serveur'), col('orders', 'Commandes'), col('covers', 'Couverts'), col('total', 'Total TTC', true), col('avg', 'Ticket moyen', true), col('discounts', 'Remises accordées', true)] },
  room_service: { title: 'Consommations en chambre', columns: [col('date', 'Date'), col('number', 'Commande'), col('room', 'Chambre'), col('guest', 'Client'), col('ordered', 'Commandée'), col('delivered', 'Livrée'), col('minutes', 'Délai (min)'), col('total', 'Total TTC', true), col('settlement', 'Règlement')] },
  breakfast: { title: 'Petit-déjeuner', columns: [col('day', 'Date'), col('entitled', 'Inclus (droits)'), col('included', 'Inclus consommés'), col('extra', 'Supplémentaires payants'), col('rate', 'Taux de présence (%)'), col('late', 'Hors horaires')] },
  stock: { title: 'Consommation de stock (ventes)', columns: [col('product', 'Article'), col('unit', 'Unité'), col('sold', 'Consommé (ventes)'), col('waste', 'Pertes'), col('in', 'Entrées'), col('stock', 'Stock actuel'), col('min', 'Minimum')] },
};
const fmtT = (d: any) => (d ? new Date(d).toLocaleString('fr-FR', { timeZone: TZ, day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '');
const n2 = (v: any) => Math.round(Number(v ?? 0) * 100) / 100;

export async function rsReport(db: Db, hotelId: number, kind: string, from: string, to: string) {
  const def = RS_REPORTS[kind];
  if (!def) throw notFound('Rapport inconnu');
  const P = [hotelId, from, to];
  const inP = `o.hotel_id = $1 AND ${day('o.created_at')} BETWEEN $2 AND $3`;
  let rows: any[] = [];
  let total: any = null;
  if (kind === 'daily' || kind === 'monthly') {
    const g = kind === 'daily' ? `${day('o.created_at')}` : `to_char(o.created_at AT TIME ZONE '${TZ}', 'YYYY-MM')`;
    rows = (await q<any>(db, `SELECT ${g} AS k, count(*)::int AS orders, sum(o.covers)::int AS covers, sum(o.subtotal) AS gross, sum(o.discount_total) AS discount, sum(o.tax_total) AS tax, sum(o.total) AS total
        FROM rs_orders o WHERE ${inP} AND ${SETTLED} GROUP BY 1 ORDER BY 1`, P))
      .map((r) => ({ [kind === 'daily' ? 'day' : 'month']: String(r.k).slice(0, 10), orders: r.orders, covers: r.covers, gross: n2(r.gross), discount: n2(r.discount), tax: n2(r.tax), total: n2(r.total), avg: n2(Number(r.total) / r.orders) }));
    total = { orders: rows.reduce((a, r) => a + r.orders, 0), gross: n2(rows.reduce((a, r) => a + r.gross, 0)), discount: n2(rows.reduce((a, r) => a + r.discount, 0)), tax: n2(rows.reduce((a, r) => a + r.tax, 0)), total: n2(rows.reduce((a, r) => a + r.total, 0)) };
  } else if (kind === 'category' || kind === 'items') {
    const KL: Record<string, string> = { starter: 'Entrées', main: 'Plats principaux', dessert: 'Desserts', drink: 'Boissons', breakfast: 'Petit-déjeuner' };
    const r0 = await q<any>(db, `SELECT ${kind === 'items' ? 'l.name AS item,' : ''} l.category_kind, sum(l.quantity)::int AS qty, sum(l.unit_price * l.quantity - l.discount) AS revenue
        FROM rs_order_lines l JOIN rs_orders o ON o.id = l.order_id WHERE ${inP} AND ${SETTLED} AND NOT l.cancelled GROUP BY ${kind === 'items' ? 'l.name,' : ''} l.category_kind ORDER BY ${kind === 'items' ? 'qty DESC, revenue DESC' : 'revenue DESC'}`, P);
    const sum = r0.reduce((a, r) => a + Number(r.revenue), 0);
    rows = r0.map((r) => ({ item: r.item, category: KL[r.category_kind] ?? r.category_kind, qty: r.qty, revenue: n2(r.revenue), share: sum ? Math.round((Number(r.revenue) * 1000) / sum) / 10 : 0 }));
    total = { qty: rows.reduce((a, r) => a + r.qty, 0), revenue: n2(sum) };
  } else if (kind === 'cancelled') {
    rows = (await q<any>(db, `SELECT o.created_at, o.number, CASE WHEN o.status = 'cancelled' THEN 'Commande entière' ELSE l.name || ' × ' || l.quantity END AS what,
        CASE WHEN o.status = 'cancelled' THEN o.subtotal ELSE l.unit_price * l.quantity END AS amount, COALESCE(o.cancel_reason, l.cancel_reason) AS reason, u.full_name AS by
       FROM rs_orders o LEFT JOIN rs_order_lines l ON l.order_id = o.id AND l.cancelled AND o.status <> 'cancelled' LEFT JOIN users u ON u.id = COALESCE(o.cancelled_by, l.cancelled_by)
      WHERE ${inP} AND (o.status = 'cancelled' OR l.id IS NOT NULL) ORDER BY o.created_at`, P)).map((r) => ({ ...r, date: fmtT(r.created_at), amount: n2(r.amount) }));
  } else if (kind === 'prep') {
    const SL: Record<string, string> = { kitchen: 'Cuisine', bar: 'Bar', pastry: 'Pâtisserie', none: 'Sans préparation' };
    rows = (await q<any>(db, `SELECT l.station, l.name AS item, count(*)::int AS count, round(avg(extract(epoch FROM (l.ready_at - l.sent_at)) / 60)::numeric, 1) AS avg_min,
        round(max(extract(epoch FROM (l.ready_at - l.sent_at)) / 60)::numeric, 1) AS max_min FROM rs_order_lines l JOIN rs_orders o ON o.id = l.order_id
      WHERE ${inP} AND l.ready_at IS NOT NULL AND l.sent_at IS NOT NULL AND l.station <> 'none' AND NOT l.cancelled GROUP BY l.station, l.name ORDER BY l.station, avg_min DESC`, P))
      .map((r) => ({ ...r, station: SL[r.station] ?? r.station, avg_min: Number(r.avg_min), max_min: Number(r.max_min) }));
  } else if (kind === 'waiters') {
    rows = (await q<any>(db, `SELECT COALESCE(u.full_name, '—') AS waiter, count(*)::int AS orders, sum(o.covers)::int AS covers, sum(o.total) AS total, sum(o.discount_total) AS discounts
        FROM rs_orders o LEFT JOIN users u ON u.id = o.waiter_id WHERE ${inP} AND ${SETTLED} GROUP BY u.full_name ORDER BY total DESC`, P))
      .map((r) => ({ ...r, total: n2(r.total), discounts: n2(r.discounts), avg: n2(Number(r.total) / r.orders) }));
  } else if (kind === 'room_service') {
    rows = (await q<any>(db, `SELECT o.*, r.number AS room FROM rs_orders o LEFT JOIN rooms r ON r.id = o.room_id WHERE ${inP} AND o.outlet = 'room_service' AND o.status <> 'cancelled' ORDER BY o.created_at`, P))
      .map((r) => ({ date: fmtT(r.created_at).slice(0, 5), number: r.number, room: r.room, guest: r.guest_name, ordered: fmtT(r.created_at), delivered: fmtT(r.served_at),
        minutes: r.served_at ? Math.round((new Date(r.served_at).getTime() - new Date(r.created_at).getTime()) / 60000) : '', total: n2(r.total), settlement: SETTLE_LABEL[r.settlement] }));
    total = { total: n2(rows.reduce((a, r) => a + r.total, 0)) };
  } else if (kind === 'breakfast') {
    const days = await q<any>(db, `SELECT d::date AS day FROM generate_series($1::date, $2::date, interval '1 day') d ORDER BY d DESC`, [from, to]);
    for (const d of days.slice(0, 62)) {
      const ds = String(d.day).slice(0, 10);
      const list = await breakfastList(db, hotelId, ds);
      const c = await one<any>(db, `SELECT COALESCE(sum(included),0)::int AS inc, COALESCE(sum(extra),0)::int AS extra, count(*) FILTER (WHERE late)::int AS late FROM rs_breakfasts WHERE hotel_id = $1 AND service_date = $2`, [hotelId, ds]);
      const entitled = list.reduce((a, r) => a + r.entitled, 0);
      rows.push({ day: ds, entitled, included: c.inc, extra: c.extra, rate: entitled ? Math.round((c.inc * 100) / entitled) : 0, late: c.late });
    }
  } else if (kind === 'stock') {
    rows = (await q<any>(db, `SELECT p.name AS product, p.unit, p.stock_qty AS stock, p.min_stock AS min,
        COALESCE(-sum(m.quantity) FILTER (WHERE m.kind = 'sale'), 0) AS sold, COALESCE(-sum(m.quantity) FILTER (WHERE m.kind = 'waste'), 0) AS waste, COALESCE(sum(m.quantity) FILTER (WHERE m.kind = 'in'), 0) AS in
       FROM products p LEFT JOIN stock_movements m ON m.product_id = p.id AND ${day('m.created_at')} BETWEEN $2 AND $3 WHERE p.hotel_id = $1 GROUP BY p.id ORDER BY p.name`, P))
      .map((r) => ({ ...r, stock: Number(r.stock), min: Number(r.min), sold: Number(r.sold), waste: Number(r.waste), in: Number(r.in) }));
  }
  return { kind, title: def.title, from, to, columns: def.columns, rows, total };
}

export { STATUS_LABEL as RS_STATUS };
