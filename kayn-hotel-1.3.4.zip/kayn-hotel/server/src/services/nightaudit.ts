/**
 * Phase 13 — Night audit : date opérationnelle, contrôles automatiques, anomalies, checklist, comptabilisation idempotente des revenus,
 * rapprochement de caisse, clôture atomique, ouverture du jour suivant, réouverture exceptionnelle, rapport de clôture.
 *
 * Règles :
 *  - la date opérationnelle est celle de la journée « courante » (table audit_days), jamais la date de l'ordinateur ;
 *  - aucune réservation ni aucun montant n'est modifié automatiquement : les anomalies sont signalées, traitées dans leur module,
 *    ou justifiées (« acceptées ») par un utilisateur autorisé, avec historique ;
 *  - la clôture se fait dans une seule transaction, sous verrou consultatif : en cas d'échec, rien n'est clôturé ;
 *  - la comptabilisation ne crée que les écritures manquantes (écart entre la valeur d'origine et le déjà comptabilisé).
 */
import { currency } from './exports.js';
import type { PoolClient } from 'pg';
import { one, q, type Db } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { addDays, today } from '../lib/dates.js';
import { AppError, badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { sessionSummary } from './cash.js';
import { BALANCE_EXPR, FIN_SQL, getSettings, guestDisplayName } from './common.js';

const r2 = (n: number) => Math.round(n * 100) / 100;
const n0 = (v: any) => (v === null || v === undefined || v === '' ? 0 : Number(v));
const d10 = (d: any) => (d instanceof Date ? d.toISOString() : String(d ?? '')).slice(0, 10);
const fr = (d: string) => `${d.slice(8, 10)}/${d.slice(5, 7)}/${d.slice(0, 4)}`;
const CURRENT = `status IN ('open','checking','ready','reopened')`;

export const CHECKLIST: { key: string; label: string }[] = [
  { key: 'reservations', label: 'Vérification des réservations' }, { key: 'arrivals', label: 'Vérification des arrivées' }, { key: 'departures', label: 'Vérification des départs' },
  { key: 'rooms', label: 'Vérification des chambres' }, { key: 'invoices', label: 'Vérification des factures' }, { key: 'payments', label: 'Vérification des paiements' },
  { key: 'cash', label: 'Vérification de la caisse' }, { key: 'expenses', label: 'Vérification des dépenses' }, { key: 'restaurant', label: 'Vérification du restaurant' },
  { key: 'posting', label: 'Comptabilisation des revenus' }, { key: 'anomalies', label: 'Vérification des anomalies' }, { key: 'final', label: 'Validation finale' },
];
export const DEPT_LBL: Record<string, string> = { room: 'Hébergement', restaurant: 'Restaurant', room_service: 'Room service', services: 'Services', other: 'Autres prestations' };
const METHOD_LBL: Record<string, string> = { cash: 'Espèces', card: 'Carte bancaire', cheque: 'Chèque', transfer: 'Virement', company_account: 'Compte société', online: 'Paiement en ligne' };

// ===================================================== Journée opérationnelle =====================================================
async function tzOf(db: Db, hotelId: number) { return (await one<any>(db, 'SELECT timezone FROM hotels WHERE id = $1', [hotelId]))?.timezone ?? 'Africa/Algiers'; }

/** Journée courante de l'hôtel (créée à la date du jour local si aucune n'existe encore). */
export async function currentDay(db: Db, hotelId: number, userId: number | null = null) {
  let d = await one<any>(db, `SELECT * FROM audit_days WHERE hotel_id = $1 AND ${CURRENT}`, [hotelId]);
  if (d) return d;
  const any = await one<any>(db, `SELECT count(*)::int AS n, max(business_date) AS last FROM audit_days WHERE hotel_id = $1`, [hotelId]);
  if (any.n > 0) {
    const susp = await one<any>(db, `SELECT * FROM audit_days WHERE hotel_id = $1 AND status = 'suspended' ORDER BY business_date LIMIT 1`, [hotelId]);
    if (susp) throw conflict('Aucune journée courante : une réouverture est en cours de traitement.');
  }
  const date = any.n > 0 ? addDays(d10(any.last), 1) : today(await tzOf(db, hotelId));
  await db.query(`INSERT INTO audit_days (hotel_id, business_date, opened_by) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`, [hotelId, date, userId]);
  d = await one<any>(db, `SELECT * FROM audit_days WHERE hotel_id = $1 AND ${CURRENT}`, [hotelId]);
  return d;
}
export async function dayById(db: Db, hotelId: number, id: number) {
  const d = await one<any>(db, 'SELECT * FROM audit_days WHERE id = $1 AND hotel_id = $2', [id, hotelId]);
  if (!d) throw notFound('Journée introuvable');
  return d;
}
const event = (db: Db, dayId: number, kind: string, userId: number | null, detail: any = null) =>
  db.query('INSERT INTO audit_day_events (audit_day_id, kind, detail, user_id) VALUES ($1,$2,$3,$4)', [dayId, kind, detail ? JSON.stringify(detail) : null, userId]);
function assertCurrent(d: any) { if (!['open', 'checking', 'ready', 'reopened'].includes(d.status)) throw new AppError(409, 'day_closed', `La journée du ${fr(d10(d.business_date))} est clôturée.`); }

// ===================================================== Chiffres de la journée =====================================================
export async function dayFacts(db: Db, hotelId: number, D: string, live: boolean) {
  const tz = await tzOf(db, hotelId);
  const rooms = await one<any>(db, `SELECT count(*)::int AS total,
      count(*) FILTER (WHERE EXISTS (SELECT 1 FROM room_blocks b WHERE b.room_id = r.id AND b.start_date <= $2 AND $2 < LEAST(COALESCE(b.end_date,'infinity'::date),
        CASE WHEN b.status = 'released' THEN COALESCE((b.released_at AT TIME ZONE $3)::date,'infinity'::date) ELSE 'infinity'::date END)) OR ($4 AND r.out_of_service))::int AS oos,
      count(*) FILTER (WHERE r.hk_status IN ('dirty','to_clean','cleaning'))::int AS cleaning,
      count(*) FILTER (WHERE r.hk_status = 'inspected')::int AS inspected
     FROM rooms r WHERE r.hotel_id = $1 AND r.active`, [hotelId, D, tz, live]);
  const occ = await one<any>(db, `SELECT count(DISTINCT rr.room_id)::int AS occupied, COALESCE(sum(rr.adults + rr.children),0)::int AS guests
     FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id
    WHERE res.hotel_id = $1 AND rr.check_in <= $2 AND rr.check_out > $2 AND rr.status IN ('checked_in','checked_out')`, [hotelId, D]);
  const inHouse = live ? await one<any>(db, `SELECT count(*)::int AS stays, count(DISTINCT s.room_id)::int AS rooms FROM stays s JOIN rooms r ON r.id = s.room_id WHERE r.hotel_id = $1 AND s.checked_out_at IS NULL`, [hotelId]) : null;
  const mv = await one<any>(db, `SELECT
      count(*) FILTER (WHERE rr.check_in = $2 AND rr.moved_from_rr_id IS NULL AND rr.status IN ('checked_in','checked_out'))::int AS arrivals,
      count(*) FILTER (WHERE rr.check_in = $2 AND rr.moved_from_rr_id IS NULL AND rr.status IN ('pending','confirmed'))::int AS arrivals_pending,
      count(*) FILTER (WHERE rr.check_out = $2 AND rr.status = 'checked_out' AND NOT EXISTS (SELECT 1 FROM reservation_rooms nx WHERE nx.moved_from_rr_id = rr.id))::int AS departures,
      count(*) FILTER (WHERE rr.check_out <= $2 AND rr.status = 'checked_in')::int AS departures_pending
     FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id WHERE res.hotel_id = $1`, [hotelId, D]);
  const pay = await q<any>(db, `SELECT method, count(*)::int AS n, sum(amount) AS amount FROM payments WHERE hotel_id = $1 AND business_date = $2 AND NOT void GROUP BY 1 ORDER BY 3 DESC`, [hotelId, D]);
  const inc = await one<any>(db, `SELECT COALESCE(sum(amount),0) AS amount, count(*)::int AS n FROM incomes WHERE hotel_id = $1 AND business_date = $2 AND NOT void`, [hotelId, D]);
  const ref = await one<any>(db, `SELECT COALESCE(sum(f.amount),0) AS amount, count(*)::int AS n FROM refunds f WHERE f.business_date = $2
      AND COALESCE((SELECT hotel_id FROM reservations WHERE id = f.reservation_id), (SELECT hotel_id FROM invoices WHERE id = f.invoice_id), (SELECT hotel_id FROM payments WHERE id = f.payment_id)) = $1`, [hotelId, D]);
  const exp = await q<any>(db, `SELECT category, count(*)::int AS n, sum(amount) AS amount FROM expenses WHERE hotel_id = $1 AND business_date = $2 AND NOT void GROUP BY 1 ORDER BY 3 DESC`, [hotelId, D]);
  const invDay = await one<any>(db, `SELECT count(*) FILTER (WHERE type = 'invoice')::int AS created,
      count(*) FILTER (WHERE type = 'invoice' AND status = 'paid')::int AS paid, count(*) FILTER (WHERE type = 'invoice' AND status = 'partially_paid')::int AS partial,
      count(*) FILTER (WHERE type = 'invoice' AND status = 'issued')::int AS unpaid, count(*) FILTER (WHERE type = 'credit_note')::int AS credit_notes,
      COALESCE(sum(total) FILTER (WHERE type IN ('invoice','credit_note')),0) AS billed, COALESCE(sum(tax_total) FILTER (WHERE type IN ('invoice','credit_note')),0) AS taxes,
      COALESCE(sum(tourist_tax_total) FILTER (WHERE type IN ('invoice','credit_note')),0) AS tourist, COALESCE(sum(discount_total) FILTER (WHERE type = 'invoice'),0) AS discounts
     FROM invoices WHERE hotel_id = $1 AND business_date = $2`, [hotelId, D]);
  const unpaid = await one<any>(db, `SELECT count(*)::int AS n, COALESCE(sum(i.total - COALESCE((SELECT sum(p.amount) FROM payments p WHERE p.invoice_id = i.id AND NOT p.void),0)
      - COALESCE((SELECT sum(-c.total) FROM invoices c WHERE c.credit_of_invoice_id = i.id AND c.type = 'credit_note'),0)),0) AS due
     FROM invoices i WHERE i.hotel_id = $1 AND i.type = 'invoice' AND i.status IN ('issued','partially_paid') AND i.business_date <= $2`, [hotelId, D]);
  const voided = await one<any>(db, `SELECT (SELECT count(*) FROM payments WHERE hotel_id = $1 AND void AND (voided_at AT TIME ZONE $3)::date = $2)::int
      + (SELECT count(*) FROM expenses WHERE hotel_id = $1 AND void AND (voided_at AT TIME ZONE $3)::date = $2)::int
      + (SELECT count(*) FROM charges ch JOIN reservations r ON r.id = ch.reservation_id WHERE r.hotel_id = $1 AND ch.void AND (ch.voided_at AT TIME ZONE $3)::date = $2)::int
      + (SELECT count(*) FROM rs_orders WHERE hotel_id = $1 AND status = 'cancelled' AND (cancelled_at AT TIME ZONE $3)::date = $2)::int AS n`, [hotelId, D, tz]);
  const cashMv = await one<any>(db, `SELECT count(*)::int AS n, COALESCE(sum(amount) FILTER (WHERE direction = 'in'),0) AS cash_in, COALESCE(sum(amount) FILTER (WHERE direction = 'out'),0) AS cash_out
     FROM cash_movements m JOIN cash_sessions s ON s.id = m.session_id JOIN cash_registers cr ON cr.id = s.cash_register_id WHERE cr.hotel_id = $1 AND m.business_date = $2`, [hotelId, D]);
  const pending = await one<any>(db, `SELECT (SELECT count(*) FROM rs_orders WHERE hotel_id = $1 AND settlement = 'open' AND status <> 'cancelled' AND business_date <= $2)::int AS rs_open,
      (SELECT count(*) FROM cash_sessions s JOIN cash_registers cr ON cr.id = s.cash_register_id WHERE cr.hotel_id = $1 AND s.status = 'open')::int AS cash_open,
      (SELECT count(*) FROM cash_sessions s JOIN cash_registers cr ON cr.id = s.cash_register_id WHERE cr.hotel_id = $1 AND s.status = 'closed' AND s.validated_by IS NULL AND COALESCE(s.difference,0) <> 0)::int AS cash_unvalidated`, [hotelId, D]);
  const rev = await revenuePreview(db, hotelId, D);
  const payments = pay.map((p) => ({ method: p.method, label: METHOD_LBL[p.method] ?? p.method, n: p.n, amount: r2(n0(p.amount)) }));
  const received = r2(payments.reduce((s, x) => s + x.amount, 0) + n0(inc.amount));
  const sellable = Math.max(0, rooms.total - rooms.oos);
  const occupied = live && inHouse ? inHouse.rooms : occ.occupied;
  return {
    business_date: D,
    rooms: { total: rooms.total, oos: rooms.oos, occupied, available: Math.max(0, sellable - occupied), cleaning: rooms.cleaning, inspected: rooms.inspected, occupancy: sellable ? r2((occ.occupied / sellable) * 100) : 0, sold: occ.occupied },
    guests: live && inHouse ? inHouse.stays : occ.guests, in_house_guests: occ.guests,
    arrivals: mv.arrivals, arrivals_pending: mv.arrivals_pending, departures: mv.departures, departures_pending: mv.departures_pending,
    revenue: rev.by_dept, revenue_total: rev.total, revenue_posted: rev.posted, revenue_pending: rev.pending,
    payments, incomes: r2(n0(inc.amount)), refunds: r2(n0(ref.amount)), refunds_n: ref.n, received, collected: r2(received - n0(ref.amount)),
    expenses: exp.map((e) => ({ category: e.category, n: e.n, amount: r2(n0(e.amount)) })), expenses_total: r2(exp.reduce((s, e) => s + n0(e.amount), 0)),
    invoices: { ...invDay, billed: r2(n0(invDay.billed)), taxes: r2(n0(invDay.taxes)), tourist: r2(n0(invDay.tourist)), discounts: r2(n0(invDay.discounts)) },
    unpaid_invoices: { n: unpaid.n, due: r2(n0(unpaid.due)) }, voided: voided.n,
    cash_movements: { n: cashMv.n, in: r2(n0(cashMv.cash_in)), out: r2(n0(cashMv.cash_out)) },
    pending: { ...pending, total: pending.rs_open + pending.cash_unvalidated },
  };
}

// ===================================================== Comptabilisation des revenus (idempotente) =====================================================
type Src = { department: string; source_type: 'room_night' | 'rs_order' | 'charge'; source_id: number; reference: string; description: string; amount: number; tax: number; origin: string };
/** Valeur actuelle de chaque opération éligible de la journée D, plus les opérations antérieures dont la valeur a changé depuis leur comptabilisation. */
async function revenueSources(db: Db, hotelId: number, D: string): Promise<(Src & { posted: number })[]> {
  const nights = await q<any>(db, `SELECT rr.id, rr.rate, res.vat_rate, res.code, r.number AS room,
      COALESCE((SELECT sum(p.amount) FROM audit_postings p WHERE p.source_type = 'room_night' AND p.source_id = rr.id AND p.business_date = $2),0) AS posted
     FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id LEFT JOIN rooms r ON r.id = rr.room_id
    WHERE res.hotel_id = $1 AND rr.check_in <= $2 AND rr.check_out > $2 AND rr.status IN ('checked_in','checked_out') ORDER BY rr.id`, [hotelId, D]);
  const orders = await q<any>(db, `SELECT o.id, o.number, o.outlet, o.business_date, CASE WHEN o.status = 'cancelled' OR o.settlement = 'cancelled' THEN 0 ELSE o.subtotal - o.discount_total END AS amount,
      CASE WHEN o.status = 'cancelled' OR o.settlement = 'cancelled' THEN 0 ELSE o.tax_total END AS tax,
      COALESCE((SELECT sum(p.amount) FROM audit_postings p WHERE p.source_type = 'rs_order' AND p.source_id = o.id),0) AS posted
     FROM rs_orders o WHERE o.hotel_id = $1 AND (o.business_date = $2 OR (o.business_date < $2 AND EXISTS (SELECT 1 FROM audit_postings p WHERE p.source_type = 'rs_order' AND p.source_id = o.id)))`, [hotelId, D]);
  const charges = await q<any>(db, `SELECT ch.id, ch.kind, ch.description, ch.service_date, res.code, CASE WHEN ch.void THEN 0 ELSE ch.total END AS amount,
      CASE WHEN ch.void THEN 0 ELSE round(ch.total * COALESCE(ch.tax_rate,0) / 100, 2) END AS tax,
      COALESCE((SELECT sum(p.amount) FROM audit_postings p WHERE p.source_type = 'charge' AND p.source_id = ch.id),0) AS posted
     FROM charges ch JOIN reservations res ON res.id = ch.reservation_id
    WHERE res.hotel_id = $1 AND ch.rs_order_line_id IS NULL AND (ch.service_date = $2 OR (ch.service_date < $2 AND EXISTS (SELECT 1 FROM audit_postings p WHERE p.source_type = 'charge' AND p.source_id = ch.id)))`, [hotelId, D]);
  const OTHER = ['cancellation_fee', 'no_show_fee', 'adjustment', 'other'];
  return [
    ...nights.map((x) => ({ department: 'room', source_type: 'room_night' as const, source_id: x.id, reference: `${x.code}${x.room ? ` · ch. ${x.room}` : ''}`, description: `Nuitée du ${fr(D)}`, amount: r2(n0(x.rate)), tax: r2((n0(x.rate) * n0(x.vat_rate)) / 100), posted: n0(x.posted), origin: D })),
    ...orders.map((x) => ({ department: x.outlet === 'room_service' ? 'room_service' : 'restaurant', source_type: 'rs_order' as const, source_id: x.id, reference: x.number, description: `Commande ${x.number}`, amount: r2(n0(x.amount)), tax: r2(n0(x.tax)), posted: n0(x.posted), origin: d10(x.business_date) })),
    ...charges.map((x) => ({ department: OTHER.includes(x.kind) ? 'other' : 'services', source_type: 'charge' as const, source_id: x.id, reference: x.code, description: x.description, amount: r2(n0(x.amount)), tax: r2(n0(x.tax)), posted: n0(x.posted), origin: d10(x.service_date) })),
  ];
}
export async function revenuePreview(db: Db, hotelId: number, D: string) {
  const src = await revenueSources(db, hotelId, D);
  const done = await q<any>(db, `SELECT department, sum(amount) AS amount FROM audit_postings WHERE hotel_id = $1 AND business_date = $2 GROUP BY 1`, [hotelId, D]);
  const by: Record<string, { department: string; label: string; amount: number; posted: number; pending: number }> = {};
  const get = (k: string) => (by[k] ??= { department: k, label: DEPT_LBL[k], amount: 0, posted: 0, pending: 0 });
  for (const s of src) {
    const x = get(s.department);
    if (s.origin === D) x.amount = r2(x.amount + s.amount);
    x.pending = r2(x.pending + (s.amount - s.posted));
  }
  for (const d of done) get(d.department).posted = r2(n0(d.amount));
  const rows = Object.keys(DEPT_LBL).filter((k) => by[k]).map((k) => by[k]);
  return { by_dept: rows, total: r2(rows.reduce((t, x) => t + x.amount, 0)), posted: r2(rows.reduce((t, x) => t + x.posted, 0)), pending: r2(rows.reduce((t, x) => t + x.pending, 0)), pending_count: src.filter((s) => Math.abs(s.amount - s.posted) > 0.004).length };
}
/** Enregistre uniquement les écritures manquantes (différence entre valeur d'origine et déjà comptabilisé). À appeler dans une transaction. */
export async function postRevenue(db: PoolClient, actor: Actor, day: any) {
  assertCurrent(day);
  const D = d10(day.business_date);
  await db.query('SELECT pg_advisory_xact_lock(hashtext($1), $2)', ['nightaudit_post', actor.hotelId]);
  const src = await revenueSources(db, actor.hotelId, D);
  let inserted = 0, amount = 0;
  for (const s of src) {
    const delta = r2(s.amount - s.posted);
    if (Math.abs(delta) < 0.005) continue;
    const seq = (await one<any>(db, `SELECT COALESCE(max(seq),0) + 1 AS n FROM audit_postings WHERE business_date = $1 AND source_type = $2 AND source_id = $3`, [D, s.source_type, s.source_id])).n;
    const isAdj = s.posted !== 0 || s.origin !== D;
    const taxDelta = s.posted === 0 ? s.tax : r2((s.tax * delta) / (s.amount || delta));
    await db.query(`INSERT INTO audit_postings (hotel_id, audit_day_id, business_date, department, source_type, source_id, seq, kind, reference, description, amount, tax, posted_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
      [actor.hotelId, day.id, D, s.department, s.source_type, s.source_id, seq, isAdj ? 'adjustment' : 'posting', s.reference,
        isAdj ? `${s.description} — ajustement${s.origin !== D ? ` (opération du ${fr(s.origin)})` : ''}` : s.description, delta, taxDelta, actor.userId]);
    inserted++; amount = r2(amount + delta);
  }
  if (inserted) {
    await event(db, day.id, 'posting', actor.userId, { inserted, amount });
    await audit(db, actor, 'post_revenue', 'audit_day', day.id, null, { business_date: D, inserted, amount });
  }
  return { inserted, amount };
}
export async function postings(db: Db, hotelId: number, D: string) {
  return q<any>(db, `SELECT p.*, u.full_name AS posted_by_name FROM audit_postings p LEFT JOIN users u ON u.id = p.posted_by WHERE p.hotel_id = $1 AND p.business_date = $2 ORDER BY p.department, p.id`, [hotelId, D]);
}

// ===================================================== Rapprochement de caisse =====================================================
/** Pour chaque caisse active : session concernée par la journée, solde théorique, dernier comptage. */
export async function cashStatus(db: Db, hotelId: number, day: any) {
  const D = d10(day.business_date);
  const tz = await tzOf(db, hotelId);
  const regs = await q<any>(db, `SELECT cr.id, cr.name, s.id AS session_id FROM cash_registers cr
     LEFT JOIN LATERAL (SELECT cs.id FROM cash_sessions cs WHERE cs.cash_register_id = cr.id AND (cs.opened_at AT TIME ZONE $3)::date <= $2
        AND (cs.status = 'open' OR (cs.closed_at AT TIME ZONE $3)::date >= $2) ORDER BY cs.opened_at DESC LIMIT 1) s ON true
     WHERE cr.hotel_id = $1 AND cr.active ORDER BY cr.name`, [hotelId, D, tz]);
  const out = [];
  for (const r of regs) {
    const count = await one<any>(db, `SELECT c.*, u.full_name AS counted_by_name, a.full_name AS approved_by_name FROM audit_cash_counts c JOIN users u ON u.id = c.counted_by LEFT JOIN users a ON a.id = c.approved_by
       WHERE c.audit_day_id = $1 AND c.register_id = $2 AND NOT c.superseded ORDER BY c.id DESC LIMIT 1`, [day.id, r.id]);
    if (!r.session_id) { out.push({ register_id: r.id, name: r.name, session: null, count, required: false }); continue; }
    const s = await sessionSummary(db, hotelId, r.session_id);
    const refunds = r2(s.operations.filter((o: any) => o.type === 'refund' && o.method === 'cash').reduce((t: number, o: any) => t - n0(o.amount), 0));
    out.push({
      register_id: r.id, name: r.name, required: true,
      session: { id: s.id, status: s.status, opened_at: s.opened_at, opened_by: s.opened_by_name, closed_at: s.closed_at, declared: s.declared_amount === null ? null : n0(s.declared_amount) },
      opening: n0(s.totals.opening), receipts: n0(s.totals.cash_in), outflows: r2(n0(s.totals.cash_out) - refunds), refunds, expected: n0(s.totals.expected), count,
    });
  }
  return out;
}
export async function countCash(db: PoolClient, actor: Actor, day: any, b: { register_id: number; counted: number; justification?: string | null }) {
  assertCurrent(day);
  const settings = await getSettings(db, actor.hotelId);
  const na = settings.night_audit;
  const st = (await cashStatus(db, actor.hotelId, day)).find((x) => x.register_id === b.register_id);
  if (!st) throw notFound('Caisse introuvable');
  if (!st.session) throw badRequest('Aucune session de caisse sur cette journée pour cette caisse.');
  const diff = r2(b.counted - st.expected!);
  const just = b.justification?.trim() || null;
  if (Math.abs(diff) > n0(na.cash_tolerance) && (!just || just.length < 5)) throw new AppError(409, 'cash_difference', `Écart de caisse de ${diff} ${currency.symbol} : justification obligatoire.`, { expected: st.expected, difference: diff });
  const needs = Math.abs(diff) > n0(na.approval_threshold);
  await db.query(`UPDATE audit_cash_counts SET superseded = true WHERE audit_day_id = $1 AND register_id = $2 AND NOT superseded`, [day.id, b.register_id]);
  const c = await one<any>(db, `INSERT INTO audit_cash_counts (audit_day_id, register_id, session_id, opening, receipts, outflows, refunds, expected, counted, difference, justification, counted_by, needs_approval)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
    [day.id, b.register_id, st.session.id, st.opening, st.receipts, st.outflows, st.refunds, st.expected, b.counted, diff, just, actor.userId, needs]);
  await event(db, day.id, 'cash_count', actor.userId, { register: st.name, expected: st.expected, counted: b.counted, difference: diff });
  await audit(db, actor, 'cash_count', 'audit_day', day.id, null, { register: st.name, expected: st.expected, counted: b.counted, difference: diff, justification: just, needs_approval: needs });
  return c;
}
export async function approveCash(db: PoolClient, actor: Actor, day: any, countId: number, note: string | null) {
  assertCurrent(day);
  const c = await one<any>(db, 'SELECT * FROM audit_cash_counts WHERE id = $1 AND audit_day_id = $2 FOR UPDATE', [countId, day.id]);
  if (!c) throw notFound('Comptage introuvable');
  if (c.superseded) throw conflict('Ce comptage a été remplacé par un nouveau comptage.');
  if (!c.needs_approval) throw badRequest('Ce comptage ne nécessite pas d\'autorisation.');
  if (c.approved_by) throw conflict('Écart déjà autorisé.');
  if (c.counted_by === actor.userId) throw forbidden('L\'autorisation doit être donnée par un autre responsable que la personne qui a compté.');
  await db.query('UPDATE audit_cash_counts SET approved_by = $2, approved_at = now(), approval_note = $3 WHERE id = $1', [countId, actor.userId, note]);
  await event(db, day.id, 'cash_approved', actor.userId, { count_id: countId, difference: n0(c.difference) });
  await audit(db, actor, 'cash_approve', 'audit_day', day.id, null, { count_id: countId, difference: n0(c.difference), note });
}

// ===================================================== Détection des anomalies =====================================================
type Anom = { code: string; item: string; module: string; severity: 'info' | 'warning' | 'critical'; ref_type?: string; ref_id?: number; ref_label?: string; description: string; responsible?: number | null; key?: string };
export const ANOMALY_LABEL: Record<string, string> = {
  arrival_pending: 'Check-in non effectué / no-show potentiel', departure_pending: 'Check-out non effectué', no_room: 'Réservation confirmée sans chambre attribuée',
  bad_dates: 'Dates incohérentes', conflict: 'Réservations en conflit', unpaid_departure: 'Départ avec solde impayé', status_mismatch: 'Statut de réservation incorrect',
  room_oos_occupied: 'Chambre hors service occupée', room_multi_stay: 'Chambre avec plusieurs séjours incompatibles', room_status: 'Statut de chambre incohérent', room_dnd_vacant: '« Ne pas déranger » sur chambre libre',
  payment_orphan: 'Paiement sans facture ni dossier', invoice_amount: 'Facture aux montants incohérents', payment_duplicate: 'Doublon de transaction possible', overpaid: 'Encaissé supérieur au facturé',
  invoice_paid_mismatch: 'Facture « payée » non soldée', refund_unjustified: 'Remboursement non justifié', payment_voided: 'Paiement annulé', cash_unvalidated: 'Session de caisse avec écart non validée',
  cash_count_missing: 'Caisse non comptée', cash_count_unapproved: 'Écart de caisse à autoriser', cash_difference: 'Écart de caisse justifié', expense_voided: 'Dépense annulée', expense_no_session: 'Dépense en espèces hors session de caisse',
  rs_open: 'Commande restaurant non réglée', rs_not_transferred: 'Vente non transférée à la facturation', rs_invoice_unpaid: 'Commande facturée non réglée', rs_cancelled: 'Commande annulée',
  posting_pending: 'Revenus non comptabilisés',
};
async function detectList(db: Db, hotelId: number, day: any): Promise<Anom[]> {
  const D = d10(day.business_date);
  const tz = await tzOf(db, hotelId);
  const settings = await getSettings(db, hotelId);
  const out: Anom[] = [];
  const gname = (x: any) => guestDisplayName(x);
  // ---------- Réservations
  for (const x of await q<any>(db, `SELECT rr.id, rr.check_in, rr.status, res.id AS res_id, res.code, res.created_by, g.kind, g.last_name, g.first_name, g.company_name, r.number AS room
      FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id JOIN guests g ON g.id = res.guest_id LEFT JOIN rooms r ON r.id = rr.room_id
     WHERE res.hotel_id = $1 AND rr.status IN ('pending','confirmed') AND rr.check_in <= $2 AND rr.moved_from_rr_id IS NULL ORDER BY rr.check_in`, [hotelId, D]))
    out.push({ code: 'arrival_pending', item: 'arrivals', module: 'reservations', severity: 'warning', ref_type: 'reservation', ref_id: x.res_id, ref_label: `${x.code} · ${gname(x)}${x.room ? ` · ch. ${x.room}` : ''}`,
      description: `Arrivée prévue le ${fr(d10(x.check_in))} non enregistrée (${x.status === 'pending' ? 'en attente' : 'confirmée'}) : effectuer le check-in, marquer no-show ou justifier une arrivée tardive.`, responsible: x.created_by, key: `rr${x.id}` });
  for (const x of await q<any>(db, `SELECT rr.id, rr.check_out, res.id AS res_id, res.code, g.kind, g.last_name, g.first_name, g.company_name, r.number AS room
      FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id JOIN guests g ON g.id = res.guest_id LEFT JOIN rooms r ON r.id = rr.room_id
     WHERE res.hotel_id = $1 AND rr.status = 'checked_in' AND rr.check_out <= $2`, [hotelId, D]))
    out.push({ code: 'departure_pending', item: 'departures', module: 'front_office', severity: 'warning', ref_type: 'reservation', ref_id: x.res_id, ref_label: `${x.code} · ${gname(x)} · ch. ${x.room ?? '—'}`,
      description: `Départ prévu le ${fr(d10(x.check_out))} : client toujours en séjour. Effectuer le check-out ou prolonger le séjour.`, key: `rr${x.id}` });
  for (const x of await q<any>(db, `SELECT rr.id, rr.check_in, res.id AS res_id, res.code, res.created_by FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id
     WHERE res.hotel_id = $1 AND rr.status IN ('pending','confirmed') AND rr.room_id IS NULL AND rr.check_in <= $2::date + 1`, [hotelId, D]))
    out.push({ code: 'no_room', item: 'reservations', module: 'reservations', severity: 'warning', ref_type: 'reservation', ref_id: x.res_id, ref_label: x.code, description: `Arrivée le ${fr(d10(x.check_in))} sans chambre attribuée.`, responsible: x.created_by, key: `rr${x.id}` });
  for (const x of await q<any>(db, `SELECT rr.id, rr.check_in, rr.check_out, rr.status, res.id AS res_id, res.code, res.check_in AS r_in, res.check_out AS r_out FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id
     WHERE res.hotel_id = $1 AND rr.status NOT IN ('cancelled','no_show') AND ((rr.status = 'checked_in' AND rr.check_in > $2::date + 1) OR rr.check_in < res.check_in OR rr.check_out > res.check_out)`, [hotelId, D]))
    out.push({ code: 'bad_dates', item: 'reservations', module: 'reservations', severity: 'critical', ref_type: 'reservation', ref_id: x.res_id, ref_label: x.code,
      description: `Chambre du ${fr(d10(x.check_in))} au ${fr(d10(x.check_out))} incohérente avec le dossier (${fr(d10(x.r_in))} → ${fr(d10(x.r_out))}) ou séjour commencé dans le futur.`, key: `rr${x.id}` });
  for (const x of await q<any>(db, `SELECT a.id AS a_id, b.id AS b_id, ra.id AS res_id, ra.code AS a_code, rb.code AS b_code, r.number FROM reservation_rooms a JOIN reservation_rooms b ON b.room_id = a.room_id AND b.id > a.id
      JOIN reservations ra ON ra.id = a.reservation_id JOIN reservations rb ON rb.id = b.reservation_id JOIN rooms r ON r.id = a.room_id
     WHERE ra.hotel_id = $1 AND a.status IN ('pending','confirmed','checked_in') AND b.status IN ('pending','confirmed','checked_in') AND a.check_in < b.check_out AND b.check_in < a.check_out AND a.check_out > $2`, [hotelId, D]))
    out.push({ code: 'conflict', item: 'reservations', module: 'reservations', severity: 'critical', ref_type: 'reservation', ref_id: x.res_id, ref_label: `${x.a_code} / ${x.b_code}`, description: `Chambre ${x.number} réservée deux fois sur des dates qui se chevauchent.`, key: `${x.a_id}-${x.b_id}` });
  for (const x of await q<any>(db, `SELECT * FROM (SELECT r.id, r.code, r.status, g.kind, g.last_name, g.first_name, g.company_name, ${FIN_SQL} FROM reservations r JOIN guests g ON g.id = r.guest_id
      WHERE r.hotel_id = $1 AND EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.reservation_id = r.id AND rr.status = 'checked_out' AND rr.check_out = $2)) x WHERE ${BALANCE_EXPR} > 0.004`, [hotelId, D])) {
    const due = r2(n0(x.room_total) + n0(x.extras_total) + n0(x.room_vat) + n0(x.extras_vat) + n0(x.fin_tt) * n0(x.adult_nights) - n0(x.paid) + n0(x.refunded));
    out.push({ code: 'unpaid_departure', item: 'invoices', module: 'billing', severity: 'warning', ref_type: 'reservation', ref_id: x.id, ref_label: `${x.code} · ${gname(x)}`, description: `Client parti avec un solde de ${due} ${currency.symbol} (facturé non encaissé).`, key: `res${x.id}` });
  }
  for (const x of await q<any>(db, `SELECT DISTINCT res.id, res.code, res.status, CASE
        WHEN res.status = 'checked_out' AND EXISTS (SELECT 1 FROM reservation_rooms z WHERE z.reservation_id = res.id AND z.status = 'checked_in') THEN 'Dossier terminé mais une chambre est encore en séjour.'
        WHEN res.status IN ('pending','confirmed') AND EXISTS (SELECT 1 FROM reservation_rooms z WHERE z.reservation_id = res.id AND z.status IN ('checked_in','checked_out')) THEN 'Dossier non arrivé alors qu''une chambre est en séjour ou terminée.'
        WHEN EXISTS (SELECT 1 FROM reservation_rooms z WHERE z.reservation_id = res.id AND z.status = 'checked_in' AND z.room_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM stays s WHERE s.reservation_room_id = z.id AND s.checked_out_at IS NULL)) THEN 'Chambre « en séjour » sans séjour actif enregistré.'
        WHEN EXISTS (SELECT 1 FROM reservation_rooms z JOIN stays s ON s.reservation_room_id = z.id AND s.checked_out_at IS NULL WHERE z.reservation_id = res.id AND z.status <> 'checked_in') THEN 'Séjour actif sur une chambre non « en séjour ».'
      END AS problem FROM reservations res WHERE res.hotel_id = $1 AND res.status NOT IN ('cancelled','no_show')`, [hotelId]))
    if (x.problem) out.push({ code: 'status_mismatch', item: 'reservations', module: 'reservations', severity: 'critical', ref_type: 'reservation', ref_id: x.id, ref_label: x.code, description: x.problem, key: `res${x.id}` });
  // ---------- Chambres
  for (const x of await q<any>(db, `SELECT r.id, r.number, r.out_of_service, r.dnd,
      (SELECT count(DISTINCT rr.reservation_id) FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id WHERE s.room_id = r.id AND s.checked_out_at IS NULL)::int AS res_n,
      EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL) AS occupied,
      EXISTS (SELECT 1 FROM room_blocks b WHERE b.room_id = r.id AND b.status = 'active' AND b.start_date <= GREATEST($2::date, $3::date) AND (b.end_date IS NULL OR b.end_date > $2)) AS blocked
     FROM rooms r WHERE r.hotel_id = $1 AND r.active`, [hotelId, D, today(tz)])) {
    const ref = { ref_type: 'room', ref_id: x.id, ref_label: `Chambre ${x.number}`, key: `room${x.id}` };
    if (x.occupied && x.out_of_service) out.push({ code: 'room_oos_occupied', item: 'rooms', module: 'rooms', severity: 'critical', ...ref, description: 'Chambre marquée hors service alors qu\'un client y séjourne.' });
    if (x.res_n > 1) out.push({ code: 'room_multi_stay', item: 'rooms', module: 'front_office', severity: 'critical', ...ref, description: `${x.res_n} séjours actifs de dossiers différents dans la même chambre.` });
    if (x.blocked && !x.out_of_service && !x.occupied) out.push({ code: 'room_status', item: 'rooms', module: 'rooms', severity: 'warning', ...ref, description: 'Blocage actif aujourd\'hui mais la chambre n\'est pas marquée hors service.' });
    if (x.out_of_service && !x.blocked) out.push({ code: 'room_status', item: 'rooms', module: 'rooms', severity: 'warning', ...ref, description: 'Chambre hors service sans blocage enregistré (motif / dates manquants).' });
    if (x.dnd && !x.occupied) out.push({ code: 'room_dnd_vacant', item: 'rooms', module: 'housekeeping', severity: 'warning', ...ref, description: '« Ne pas déranger » actif sur une chambre libre : le ménage ne sera pas planifié.' });
  }
  // ---------- Paiements et factures de la journée
  for (const x of await q<any>(db, `SELECT p.id, p.amount, p.method, p.received_by FROM payments p WHERE p.hotel_id = $1 AND p.business_date = $2 AND NOT p.void AND p.reservation_id IS NULL AND p.invoice_id IS NULL`, [hotelId, D]))
    out.push({ code: 'payment_orphan', item: 'payments', module: 'billing', severity: 'warning', ref_type: 'payment', ref_id: x.id, ref_label: `Paiement #${x.id}`, description: `${n0(x.amount)} ${currency.symbol} (${METHOD_LBL[x.method] ?? x.method}) sans facture ni dossier associé.`, responsible: x.received_by });
  for (const x of await q<any>(db, `SELECT i.id, i.number, i.total, i.created_by, (SELECT COALESCE(sum(it.total + COALESCE(it.tax_amount,0)),0) FROM invoice_items it WHERE it.invoice_id = i.id) AS lines
     FROM invoices i WHERE i.hotel_id = $1 AND i.business_date = $2 AND i.type IN ('invoice','credit_note')`, [hotelId, D]))
    if (Math.abs(n0(x.total) - n0(x.lines)) > 0.01) out.push({ code: 'invoice_amount', item: 'invoices', module: 'billing', severity: 'critical', ref_type: 'invoice', ref_id: x.id, ref_label: x.number, description: `Total ${n0(x.total)} ${currency.symbol} ≠ somme des lignes ${r2(n0(x.lines))} ${currency.symbol}.`, responsible: x.created_by });
  for (const x of await q<any>(db, `SELECT b.id, b.amount, b.method, b.received_by, a.id AS first_id, COALESCE(r.code, i.number, '') AS ref FROM payments b JOIN payments a ON a.id < b.id AND NOT a.void
      AND a.amount = b.amount AND a.method = b.method AND COALESCE(a.reservation_id,0) = COALESCE(b.reservation_id,0) AND COALESCE(a.invoice_id,0) = COALESCE(b.invoice_id,0)
      AND abs(EXTRACT(EPOCH FROM (b.received_at - a.received_at))) <= 120 LEFT JOIN reservations r ON r.id = b.reservation_id LEFT JOIN invoices i ON i.id = b.invoice_id
     WHERE b.hotel_id = $1 AND b.business_date = $2 AND NOT b.void`, [hotelId, D]))
    out.push({ code: 'payment_duplicate', item: 'payments', module: 'billing', severity: 'warning', ref_type: 'payment', ref_id: x.id, ref_label: `${x.ref} · paiement #${x.id}`, description: `Même montant (${n0(x.amount)} ${currency.symbol}), même mode et même dossier que le paiement #${x.first_id}, à moins de 2 minutes d'intervalle.`, responsible: x.received_by, key: `p${x.id}` });
  for (const x of await q<any>(db, `SELECT * FROM (SELECT r.id, r.code, ${FIN_SQL} FROM reservations r WHERE r.hotel_id = $1 AND EXISTS (SELECT 1 FROM payments p WHERE p.reservation_id = r.id AND p.business_date = $2 AND NOT p.void)) x
     WHERE ${BALANCE_EXPR} < -0.004`, [hotelId, D]))
    out.push({ code: 'overpaid', item: 'payments', module: 'billing', severity: 'warning', ref_type: 'reservation', ref_id: x.id, ref_label: x.code, description: 'Le client a payé plus que le montant facturé : rembourser ou affecter le trop-perçu.', key: `res${x.id}` });
  for (const x of await q<any>(db, `SELECT i.id, i.number, i.total, (SELECT COALESCE(sum(p.amount),0) FROM payments p WHERE p.invoice_id = i.id AND NOT p.void) - (SELECT COALESCE(sum(f.amount),0) FROM refunds f WHERE f.invoice_id = i.id) AS paid,
      (SELECT COALESCE(sum(-c.total),0) FROM invoices c WHERE c.credit_of_invoice_id = i.id AND c.type = 'credit_note') AS credited
     FROM invoices i WHERE i.hotel_id = $1 AND i.type = 'invoice' AND i.status = 'paid' AND i.reservation_id IS NULL AND i.business_date = $2`, [hotelId, D]))
    if (n0(x.paid) + n0(x.credited) < n0(x.total) - 0.01) out.push({ code: 'invoice_paid_mismatch', item: 'invoices', module: 'billing', severity: 'warning', ref_type: 'invoice', ref_id: x.id, ref_label: x.number, description: `Facture « payée » : encaissé ${r2(n0(x.paid))} ${currency.symbol} pour ${n0(x.total)} ${currency.symbol}.` });
  for (const x of await q<any>(db, `SELECT f.id, f.amount, f.reason, f.created_by, p.amount AS paid, (SELECT sum(z.amount) FROM refunds z WHERE z.payment_id = f.payment_id) AS refunded, COALESCE(r.code, '') AS ref
     FROM refunds f LEFT JOIN payments p ON p.id = f.payment_id LEFT JOIN reservations r ON r.id = f.reservation_id
    WHERE f.business_date = $2 AND COALESCE(r.hotel_id, p.hotel_id, (SELECT hotel_id FROM invoices WHERE id = f.invoice_id)) = $1`, [hotelId, D])) {
    const tooMuch = x.paid !== null && n0(x.refunded) > n0(x.paid) + 0.01;
    if (tooMuch || !x.reason || String(x.reason).trim().length < 5)
      out.push({ code: 'refund_unjustified', item: 'payments', module: 'billing', severity: 'warning', ref_type: 'refund', ref_id: x.id, ref_label: `${x.ref} · remboursement #${x.id}`, responsible: x.created_by,
        description: tooMuch ? `Remboursements (${n0(x.refunded)} ${currency.symbol}) supérieurs au paiement d'origine (${n0(x.paid)} ${currency.symbol}).` : 'Remboursement sans motif suffisant.' });
  }
  for (const x of await q<any>(db, `SELECT p.id, p.amount, p.void_reason, p.voided_by FROM payments p WHERE p.hotel_id = $1 AND p.void AND (p.voided_at AT TIME ZONE $3)::date = $2`, [hotelId, D, tz]))
    out.push({ code: 'payment_voided', item: 'payments', module: 'billing', severity: 'info', ref_type: 'payment', ref_id: x.id, ref_label: `Paiement #${x.id}`, description: `${n0(x.amount)} ${currency.symbol} annulé : ${x.void_reason}`, responsible: x.voided_by });
  // ---------- Caisse
  for (const x of await q<any>(db, `SELECT s.id, cr.name, s.difference, s.closed_by FROM cash_sessions s JOIN cash_registers cr ON cr.id = s.cash_register_id
     WHERE cr.hotel_id = $1 AND s.status = 'closed' AND s.validated_by IS NULL AND COALESCE(s.difference,0) <> 0 AND (s.closed_at AT TIME ZONE $3)::date <= $2`, [hotelId, D, tz]))
    out.push({ code: 'cash_unvalidated', item: 'cash', module: 'cash', severity: 'warning', ref_type: 'cash_session', ref_id: x.id, ref_label: `${x.name} · session #${x.id}`, description: `Écart de ${n0(x.difference)} ${currency.symbol} à la fermeture, non validé par un responsable.`, responsible: x.closed_by });
  if (settings.night_audit.require_cash_count) {
    for (const c of await cashStatus(db, hotelId, day)) {
      if (!c.required) continue;
      const ref = { ref_type: 'cash_register', ref_id: c.register_id, ref_label: c.name, key: `reg${c.register_id}` };
      if (!c.count) out.push({ code: 'cash_count_missing', item: 'cash', module: 'cash', severity: 'critical', ...ref, description: `Caisse non comptée : solde théorique ${c.expected} ${currency.symbol} à rapprocher du montant réel.` });
      else if (c.count.needs_approval && !c.count.approved_by) out.push({ code: 'cash_count_unapproved', item: 'cash', module: 'cash', severity: 'critical', ...ref, description: `Écart de ${n0(c.count.difference)} ${currency.symbol} au-delà du seuil : autorisation d'un second responsable requise.`, responsible: c.count.counted_by });
      else if (n0(c.count.difference) !== 0) out.push({ code: 'cash_difference', item: 'cash', module: 'cash', severity: 'info', ...ref, description: `Écart de ${n0(c.count.difference)} ${currency.symbol} justifié : « ${c.count.justification} » (${c.count.counted_by_name}).`, responsible: c.count.counted_by });
    }
  }
  // ---------- Dépenses
  for (const x of await q<any>(db, `SELECT e.id, e.amount, e.category, e.description, e.void, e.void_reason, e.cash_session_id, e.created_by, e.voided_by, e.business_date, e.voided_at FROM expenses e
     WHERE e.hotel_id = $1 AND ((e.business_date = $2 AND e.method = 'cash' AND e.cash_session_id IS NULL AND NOT e.void) OR (e.void AND (e.voided_at AT TIME ZONE $3)::date = $2))`, [hotelId, D, tz])) {
    if (x.void) out.push({ code: 'expense_voided', item: 'expenses', module: 'expenses', severity: 'info', ref_type: 'expense', ref_id: x.id, ref_label: `${x.category} — ${x.description}`, description: `${n0(x.amount)} ${currency.symbol} annulée : ${x.void_reason}`, responsible: x.voided_by });
    else out.push({ code: 'expense_no_session', item: 'expenses', module: 'expenses', severity: 'warning', ref_type: 'expense', ref_id: x.id, ref_label: `${x.category} — ${x.description}`, description: `Dépense de ${n0(x.amount)} ${currency.symbol} en espèces non rattachée à une session de caisse.`, responsible: x.created_by });
  }
  // ---------- Restaurant
  for (const x of await q<any>(db, `SELECT o.id, o.number, o.outlet, o.status, o.total, o.waiter_id, o.business_date FROM rs_orders o WHERE o.hotel_id = $1 AND o.settlement = 'open' AND o.status <> 'cancelled' AND o.business_date <= $2`, [hotelId, D]))
    out.push({ code: 'rs_open', item: 'restaurant', module: 'restaurant', severity: 'warning', ref_type: 'rs_order', ref_id: x.id, ref_label: `${x.number} (${x.outlet === 'room_service' ? 'room service' : x.outlet})`, responsible: x.waiter_id,
      description: `Commande du ${fr(d10(x.business_date))} (${n0(x.total)} ${currency.symbol}) ouverte, non facturée ni réglée.` });
  for (const x of await q<any>(db, `SELECT o.id, o.number, o.total FROM rs_orders o WHERE o.hotel_id = $1 AND o.settlement = 'room' AND o.business_date <= $2 AND o.business_date >= $2::date - 7
      AND EXISTS (SELECT 1 FROM rs_order_lines l WHERE l.order_id = o.id AND NOT l.cancelled AND NOT EXISTS (SELECT 1 FROM charges ch WHERE ch.rs_order_line_id = l.id AND NOT ch.void))`, [hotelId, D]))
    out.push({ code: 'rs_not_transferred', item: 'restaurant', module: 'restaurant', severity: 'critical', ref_type: 'rs_order', ref_id: x.id, ref_label: x.number, description: `Commande portée sur la chambre mais absente du folio (${n0(x.total)} ${currency.symbol}).` });
  for (const x of await q<any>(db, `SELECT o.id, o.number, i.number AS inv, i.total FROM rs_orders o JOIN invoices i ON i.id = o.invoice_id WHERE o.hotel_id = $1 AND o.settlement = 'invoice' AND i.status IN ('issued','partially_paid') AND o.business_date = $2`, [hotelId, D]))
    out.push({ code: 'rs_invoice_unpaid', item: 'restaurant', module: 'restaurant', severity: 'info', ref_type: 'rs_order', ref_id: x.id, ref_label: `${x.number} · ${x.inv}`, description: `Facturée (${n0(x.total)} ${currency.symbol}), en attente de règlement.` });
  for (const x of await q<any>(db, `SELECT o.id, o.number, o.total, o.cancel_reason, o.cancelled_by FROM rs_orders o WHERE o.hotel_id = $1 AND o.status = 'cancelled' AND (o.cancelled_at AT TIME ZONE $3)::date = $2`, [hotelId, D, tz]))
    out.push({ code: 'rs_cancelled', item: 'restaurant', module: 'restaurant', severity: 'info', ref_type: 'rs_order', ref_id: x.id, ref_label: x.number, description: `Annulée (${n0(x.total)} ${currency.symbol}) : ${x.cancel_reason ?? ''}`, responsible: x.cancelled_by });
  // ---------- Revenus
  const pv = await revenuePreview(db, hotelId, D);
  if (pv.pending_count) out.push({ code: 'posting_pending', item: 'posting', module: 'night_audit', severity: 'warning', ref_type: 'posting', ref_label: `${pv.pending_count} opération(s)`, description: `${pv.pending} ${currency.symbol} de revenus non encore comptabilisés : lancer la comptabilisation.`, key: 'posting' });
  return out;
}

/** Recalcule les anomalies : nouvelles → ouvertes ; disparues → corrigées (avec historique) ; justifiées → conservées. */
export async function runChecks(db: PoolClient, actor: Actor, day: any) {
  assertCurrent(day);
  await db.query('SELECT pg_advisory_xact_lock(hashtext($1), $2)', ['nightaudit_check', actor.hotelId]);
  const list = await detectList(db, actor.hotelId, day);
  const seen = new Set<string>();
  for (const a of list) {
    const fp = `${a.code}:${a.key ?? `${a.ref_type ?? ''}${a.ref_id ?? ''}`}`;
    if (seen.has(fp)) continue;
    seen.add(fp);
    const cur = await one<any>(db, 'SELECT * FROM audit_anomalies WHERE audit_day_id = $1 AND fingerprint = $2', [day.id, fp]);
    if (!cur) {
      const n = await one<any>(db, `INSERT INTO audit_anomalies (audit_day_id, hotel_id, code, item, module, severity, ref_type, ref_id, ref_label, description, fingerprint, responsible_user_id, status)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING id`,
        [day.id, actor.hotelId, a.code, a.item, a.module, a.severity, a.ref_type ?? null, a.ref_id ?? null, a.ref_label ?? null, a.description, fp, a.responsible ?? null, 'open']);
      await db.query(`INSERT INTO audit_anomaly_history (anomaly_id, kind, text, user_id) VALUES ($1,'detected',$2,$3)`, [n.id, a.description, actor.userId]);
    } else {
      await db.query('UPDATE audit_anomalies SET last_seen_at = now(), description = $2, severity = $3 WHERE id = $1', [cur.id, a.description, a.severity]);
      if (cur.status === 'corrected') {
        await db.query(`UPDATE audit_anomalies SET status = 'open', resolved_at = NULL, resolved_by = NULL, resolution = NULL WHERE id = $1`, [cur.id]);
        await db.query(`INSERT INTO audit_anomaly_history (anomaly_id, kind, text, user_id) VALUES ($1,'redetected','Anomalie de nouveau constatée',$2)`, [cur.id, actor.userId]);
      }
    }
  }
  for (const x of await q<any>(db, `SELECT id, fingerprint FROM audit_anomalies WHERE audit_day_id = $1 AND status = 'open'`, [day.id])) {
    if (seen.has(x.fingerprint)) continue;
    await db.query(`UPDATE audit_anomalies SET status = 'corrected', resolved_at = now(), resolved_by = $2, resolution = 'Corrigée dans le module concerné (constat au contrôle)' WHERE id = $1`, [x.id, actor.userId]);
    await db.query(`INSERT INTO audit_anomaly_history (anomaly_id, kind, text, user_id) VALUES ($1,'auto_resolved','Plus constatée lors du contrôle : corrigée',$2)`, [x.id, actor.userId]);
  }
  const newStatus = day.status === 'open' ? 'checking' : day.status === 'ready' ? 'ready' : day.status;
  await db.query(`UPDATE audit_days SET status = $2, last_check_at = now(), check_started_at = COALESCE(check_started_at, now()), check_started_by = COALESCE(check_started_by, $3) WHERE id = $1`, [day.id, newStatus, actor.userId]);
  if (day.status === 'open') await event(db, day.id, 'check_started', actor.userId);
  await event(db, day.id, 'check', actor.userId, { found: seen.size });
  // une journée « prête » qui présente de nouvelles anomalies bloquantes revient en vérification
  const blocking = await blockingCount(db, day.id);
  if (newStatus === 'ready' && blocking > 0) await db.query(`UPDATE audit_days SET status = 'checking' WHERE id = $1`, [day.id]);
  return { found: seen.size, blocking };
}
const blockingCount = async (db: Db, dayId: number) => (await one<any>(db, `SELECT count(*)::int AS n FROM audit_anomalies WHERE audit_day_id = $1 AND status = 'open' AND severity <> 'info'`, [dayId])).n;

export async function anomalyAction(db: PoolClient, actor: Actor, perms: Set<string>, day: any, id: number, b: { action: 'comment' | 'accept' | 'reopen'; text: string }) {
  const a = await one<any>(db, 'SELECT * FROM audit_anomalies WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!a) throw notFound('Anomalie introuvable');
  const d = await dayById(db, actor.hotelId, a.audit_day_id);
  if (b.action !== 'comment') assertCurrent(d);
  const text = b.text.trim();
  if (b.action === 'comment') {
    if (!perms.has('nightaudit.check') && !perms.has('nightaudit.correct')) throw forbidden();
    if (text.length < 2) throw badRequest('Commentaire vide.');
  } else {
    if (!perms.has('nightaudit.correct')) throw forbidden('Permission requise : nightaudit.correct');
    if (b.action === 'accept') {
      if (a.status !== 'open') throw conflict('Anomalie déjà traitée.');
      if (text.length < 10) throw badRequest('Justification obligatoire (10 caractères minimum).');
      if (['cash_count_missing', 'cash_count_unapproved', 'posting_pending', 'rs_not_transferred'].includes(a.code))
        throw conflict('Cette anomalie ne peut pas être simplement justifiée : elle doit être corrigée (comptage de caisse, autorisation de l\'écart, comptabilisation, transfert au folio).');
      await db.query(`UPDATE audit_anomalies SET status = 'accepted', resolved_at = now(), resolved_by = $2, resolution = $3 WHERE id = $1`, [id, actor.userId, text]);
    } else {
      if (a.status === 'open') throw conflict('Anomalie déjà ouverte.');
      await db.query(`UPDATE audit_anomalies SET status = 'open', resolved_at = NULL, resolved_by = NULL, resolution = NULL WHERE id = $1`, [id]);
      if (d.status === 'ready') await db.query(`UPDATE audit_days SET status = 'checking' WHERE id = $1`, [d.id]);
    }
  }
  await db.query('INSERT INTO audit_anomaly_history (anomaly_id, kind, text, user_id) VALUES ($1,$2,$3,$4)', [id, b.action === 'accept' ? 'accepted' : b.action === 'reopen' ? 'reopened' : 'comment', text || null, actor.userId]);
  await audit(db, actor, `anomaly_${b.action}`, 'audit_anomaly', id, { status: a.status }, { text });
}

// ===================================================== Checklist =====================================================
export async function checklist(db: Db, day: any) {
  const anoms = await q<any>(db, `SELECT item, status, severity FROM audit_anomalies WHERE audit_day_id = $1`, [day.id]);
  const vals = await q<any>(db, `SELECT c.*, u.full_name AS by_name FROM audit_checklist c LEFT JOIN users u ON u.id = c.validated_by WHERE c.audit_day_id = $1`, [day.id]);
  const checked = !!day.last_check_at;
  const blocking = anoms.filter((a) => a.status === 'open' && a.severity !== 'info').length;
  return CHECKLIST.map(({ key, label }) => {
    const mine = key === 'anomalies' ? anoms : anoms.filter((a) => a.item === key);
    const open = mine.filter((a) => a.status === 'open' && a.severity !== 'info').length;
    const handled = mine.filter((a) => a.status !== 'open').length;
    const v = vals.find((x) => x.item === key);
    let status: string;
    if (key === 'final') status = v?.validated_at ? 'validated' : 'to_check';
    else if (!checked) status = 'to_check';
    else if (open) status = 'anomaly';
    else if (v?.validated_at) status = 'validated';
    else if (handled) status = 'corrected';
    else status = 'ok';
    return { key, label, status, open: key === 'anomalies' ? blocking : open, handled, info: mine.filter((a) => a.severity === 'info').length, validated_by: v?.by_name ?? null, validated_at: v?.validated_at ?? null, note: v?.note ?? null };
  });
}
export async function validateItem(db: PoolClient, actor: Actor, day: any, item: string, note: string | null) {
  assertCurrent(day);
  if (item === 'final') throw badRequest('La validation finale se fait depuis l\'étape « Validation ».');
  const cl = (await checklist(db, day)).find((x) => x.key === item);
  if (!cl) throw notFound('Point de checklist inconnu');
  if (cl.status === 'to_check') throw conflict('Lancez d\'abord les vérifications.');
  if (cl.status === 'anomaly') throw conflict('Des anomalies restent à traiter sur ce point.');
  await db.query(`INSERT INTO audit_checklist (audit_day_id, item, validated_by, validated_at, note) VALUES ($1,$2,$3,now(),$4)
     ON CONFLICT (audit_day_id, item) DO UPDATE SET validated_by = EXCLUDED.validated_by, validated_at = now(), note = EXCLUDED.note`, [day.id, item, actor.userId, note]);
  await event(db, day.id, 'item_validated', actor.userId, { item, note });
}

// ===================================================== Validation, clôture, réouverture =====================================================
async function preconditions(db: Db, hotelId: number, day: any) {
  const D = d10(day.business_date);
  const settings = await getSettings(db, hotelId);
  const problems: string[] = [];
  if (!day.last_check_at) problems.push('Les vérifications n\'ont pas été lancées.');
  const blocking = await blockingCount(db, day.id);
  if (blocking) problems.push(`${blocking} anomalie(s) bloquante(s) à corriger ou justifier.`);
  const cal = today(await tzOf(db, hotelId));
  if (!settings.night_audit.allow_early_close && D >= cal) problems.push(`La journée du ${fr(D)} n'est pas terminée : la clôture est possible à partir de minuit.`);
  return problems;
}
export async function validateDay(db: PoolClient, actor: Actor, day: any, note: string | null) {
  assertCurrent(day);
  await runChecks(db, actor, day);
  const fresh = await dayById(db, actor.hotelId, day.id);
  const problems = await preconditions(db, actor.hotelId, fresh);
  if (problems.length) throw new AppError(409, 'not_ready', problems.join(' '), { problems });
  await db.query(`INSERT INTO audit_checklist (audit_day_id, item, validated_by, validated_at, note) VALUES ($1,'final',$2,now(),$3)
     ON CONFLICT (audit_day_id, item) DO UPDATE SET validated_by = EXCLUDED.validated_by, validated_at = now(), note = EXCLUDED.note`, [day.id, actor.userId, note]);
  await db.query(`UPDATE audit_days SET status = 'ready' WHERE id = $1`, [day.id]);
  await event(db, day.id, 'validated', actor.userId, { note });
  await audit(db, actor, 'night_audit_validate', 'audit_day', day.id, { status: fresh.status }, { status: 'ready' });
}

/**
 * Clôture atomique : verrou, contrôle final, comptabilisation des écritures manquantes, instantané du rapport, verrouillage de la journée,
 * ouverture (ou reprise) du jour suivant. Toute erreur annule l'ensemble (la journée reste ouverte et peut être reprise).
 */
export async function closeDay(db: PoolClient, actor: Actor, b: { confirm: string }, hooks: { failAfterPosting?: boolean } = {}) {
  await db.query('SELECT pg_advisory_xact_lock(hashtext($1), $2)', ['nightaudit_close', actor.hotelId]);
  const day = await one<any>(db, `SELECT * FROM audit_days WHERE hotel_id = $1 AND ${CURRENT} FOR UPDATE`, [actor.hotelId]);
  if (!day) throw conflict('Aucune journée à clôturer.');
  const D = d10(day.business_date);
  if (day.status !== 'ready') throw new AppError(409, 'not_ready', 'La journée doit d\'abord être validée (étape « Validation »).');
  if (b.confirm.trim() !== fr(D)) throw badRequest(`Confirmation incorrecte : saisissez la date ${fr(D)} pour confirmer la clôture.`);
  // comptabilisation des écritures manquantes (opérations modifiées depuis la validation), puis contrôle final
  const posted = await postRevenue(db, actor, day);
  await runChecks(db, actor, day);
  const problems = await preconditions(db, actor.hotelId, await dayById(db, actor.hotelId, day.id));
  if (problems.length) throw new AppError(409, 'not_ready', problems.join(' '), { problems });
  if (hooks.failAfterPosting) throw new AppError(500, 'interrupted', 'Interruption simulée pendant la clôture.');
  const report = await buildReport(db, actor.hotelId, day, actor.userId);
  const cashDiff = r2(report.cash.reduce((s: number, c: any) => s + n0(c.count?.difference), 0));
  const version = day.close_count + 1;
  const an = report.anomalies;
  await db.query(`INSERT INTO audit_closures (audit_day_id, hotel_id, business_date, version, closed_by, confirmation, revenue, collected, expenses, cash_difference, anomalies, anomalies_resolved, anomalies_accepted, report)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`,
    [day.id, actor.hotelId, D, version, actor.userId, b.confirm.trim(), report.facts.revenue_total, report.facts.collected, report.facts.expenses_total, cashDiff,
      an.length, an.filter((a: any) => a.status === 'corrected').length, an.filter((a: any) => a.status === 'accepted').length, JSON.stringify(report)]);
  await db.query(`UPDATE audit_days SET status = 'closed', closed_at = now(), closed_by = $2, close_count = $3 WHERE id = $1`, [day.id, actor.userId, version]);
  await event(db, day.id, 'closed', actor.userId, { version, revenue: report.facts.revenue_total, collected: report.facts.collected });
  // Ouverture du jour suivant (ou reprise de la journée suspendue pendant une réouverture)
  const susp = await one<any>(db, `SELECT * FROM audit_days WHERE hotel_id = $1 AND status = 'suspended' AND business_date > $2 ORDER BY business_date LIMIT 1`, [actor.hotelId, D]);
  let next;
  if (susp) {
    next = await one<any>(db, `UPDATE audit_days SET status = CASE WHEN close_count > 0 THEN 'reopened' WHEN last_check_at IS NULL THEN 'open' ELSE 'checking' END WHERE id = $1 RETURNING *`, [susp.id]);
    await event(db, susp.id, 'resumed', actor.userId, { after_reclose_of: D });
  } else {
    next = await one<any>(db, `INSERT INTO audit_days (hotel_id, business_date, opened_by) VALUES ($1,$2,$3) RETURNING *`, [actor.hotelId, addDays(D, 1), actor.userId]);
    await event(db, next.id, 'opened', actor.userId, { previous: D });
  }
  await audit(db, actor, 'night_audit_close', 'audit_day', day.id, { status: 'ready' }, { status: 'closed', business_date: D, version, posted, next_business_date: d10(next.business_date) });
  return { closed: D, version, posted, next_business_date: d10(next.business_date), report };
}

export async function reopenDay(db: PoolClient, actor: Actor, dayId: number, reason: string) {
  await db.query('SELECT pg_advisory_xact_lock(hashtext($1), $2)', ['nightaudit_close', actor.hotelId]);
  if (reason.trim().length < 10) throw badRequest('Justification obligatoire (10 caractères minimum).');
  const d = await one<any>(db, 'SELECT * FROM audit_days WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [dayId, actor.hotelId]);
  if (!d) throw notFound('Journée introuvable');
  if (d.status !== 'closed') throw conflict('Seule une journée clôturée peut être réouverte.');
  const last = await one<any>(db, `SELECT max(business_date) AS m FROM audit_days WHERE hotel_id = $1 AND status = 'closed'`, [actor.hotelId]);
  if (d10(last.m) !== d10(d.business_date)) throw conflict('Seule la dernière journée clôturée peut être réouverte (réouvrez les journées dans l\'ordre inverse).');
  if (await one<any>(db, `SELECT 1 FROM audit_days WHERE hotel_id = $1 AND (status = 'suspended' OR status = 'reopened')`, [actor.hotelId])) throw conflict('Une réouverture est déjà en cours : clôturez d\'abord la journée réouverte.');
  const cur = await one<any>(db, `SELECT * FROM audit_days WHERE hotel_id = $1 AND ${CURRENT} FOR UPDATE`, [actor.hotelId]);
  if (cur) { await db.query(`UPDATE audit_days SET status = 'suspended' WHERE id = $1`, [cur.id]); await event(db, cur.id, 'suspended', actor.userId, { reopened: d10(d.business_date) }); }
  await db.query(`UPDATE audit_days SET status = 'reopened', reopen_count = reopen_count + 1 WHERE id = $1`, [d.id]);
  await db.query(`DELETE FROM audit_checklist WHERE audit_day_id = $1 AND item = 'final'`, [d.id]);
  await event(db, d.id, 'reopened', actor.userId, { reason: reason.trim() });
  await audit(db, actor, 'night_audit_reopen', 'audit_day', d.id, { status: 'closed' }, { status: 'reopened', reason: reason.trim() });
}

// ===================================================== Rapport de clôture =====================================================
export async function buildReport(db: Db, hotelId: number, day: any, closedBy: number | null) {
  const D = d10(day.business_date);
  const live = ['open', 'checking', 'ready', 'reopened'].includes(day.status);
  const facts = await dayFacts(db, hotelId, D, live);
  const posts = await q<any>(db, `SELECT department, kind, count(*)::int AS n, sum(amount) AS amount, sum(tax) AS tax FROM audit_postings WHERE hotel_id = $1 AND business_date = $2 GROUP BY 1, 2 ORDER BY 1, 2`, [hotelId, D]);
  const anomalies = await q<any>(db, `SELECT a.id, a.code, a.item, a.module, a.severity, a.ref_label, a.description, a.status, a.resolution, a.detected_at, a.resolved_at, u.full_name AS resolved_by_name, r.full_name AS responsible
     FROM audit_anomalies a LEFT JOIN users u ON u.id = a.resolved_by LEFT JOIN users r ON r.id = a.responsible_user_id WHERE a.audit_day_id = $1 ORDER BY a.severity DESC, a.id`, [day.id]);
  const unpaid = await q<any>(db, `SELECT i.number, i.issued_at, i.bill_to->>'name' AS client, i.total,
      i.total - COALESCE((SELECT sum(p.amount) FROM payments p WHERE p.invoice_id = i.id AND NOT p.void),0) - COALESCE((SELECT sum(-c.total) FROM invoices c WHERE c.credit_of_invoice_id = i.id AND c.type = 'credit_note'),0) AS due
     FROM invoices i WHERE i.hotel_id = $1 AND i.type = 'invoice' AND i.status IN ('issued','partially_paid') AND i.business_date <= $2 ORDER BY i.issued_at`, [hotelId, D]);
  const cash = await cashStatus(db, hotelId, day);
  const user = closedBy ? await one<any>(db, 'SELECT full_name FROM users WHERE id = $1', [closedBy]) : null;
  return {
    business_date: D, generated_at: new Date().toISOString(), closed_by: user?.full_name ?? null, facts,
    postings: posts.map((p) => ({ department: p.department, label: DEPT_LBL[p.department], kind: p.kind, n: p.n, amount: r2(n0(p.amount)), tax: r2(n0(p.tax)) })),
    anomalies: anomalies.map((a) => ({ ...a, label: ANOMALY_LABEL[a.code] ?? a.code })),
    unpaid_invoices: unpaid.map((i) => ({ number: i.number, date: d10(i.issued_at), client: i.client ?? '', total: n0(i.total), due: r2(n0(i.due)) })),
    cash: cash.map((c) => ({ name: c.name, required: c.required, opening: c.opening ?? null, receipts: c.receipts ?? null, outflows: c.outflows ?? null, refunds: c.refunds ?? null, expected: c.expected ?? null,
      count: c.count ? { counted: n0(c.count.counted), difference: n0(c.count.difference), justification: c.count.justification, counted_by: c.count.counted_by_name, approved_by: c.count.approved_by_name ?? null } : null })),
  };
}

export async function history(db: Db, hotelId: number, limit = 90) {
  return q<any>(db, `SELECT d.id, d.business_date, d.status, d.reopen_count, c.id AS closure_id, c.version, c.closed_at, u.full_name AS closed_by, c.revenue, c.collected, c.expenses, c.cash_difference,
      c.anomalies, c.anomalies_resolved, c.anomalies_accepted
     FROM audit_days d LEFT JOIN LATERAL (SELECT * FROM audit_closures x WHERE x.audit_day_id = d.id ORDER BY x.version DESC LIMIT 1) c ON true LEFT JOIN users u ON u.id = c.closed_by
    WHERE d.hotel_id = $1 ORDER BY d.business_date DESC LIMIT $2`, [hotelId, limit]);
}
