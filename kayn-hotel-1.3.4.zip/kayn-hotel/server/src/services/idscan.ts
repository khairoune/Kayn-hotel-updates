/**
 * Lecture automatique de la zone MRZ (les 2 ou 3 lignes « <<< » au bas des passeports et au dos de la CNI biométrique)
 * entièrement HORS LIGNE : moteur Tesseract (WebAssembly) + modèle MRZ local (assets/ocr/mrz.traineddata, licence BSD-3).
 * Aucune image n'est envoyée sur Internet. Les sommes de contrôle de la MRZ permettent de corriger les confusions
 * de lecture courantes (0/O/D, 1/I, 5/S, 8/B, 2/Z) et de signaler un résultat douteux : l'utilisateur valide toujours.
 */
import { fileURLToPath } from 'node:url';
import { mkdirSync } from 'node:fs';
import { createWorker, type Worker } from 'tesseract.js';
import { parse } from 'mrz';

const LANG_DIR = fileURLToPath(new URL('../../assets/ocr', import.meta.url));
const CACHE_DIR = fileURLToPath(new URL('../../data/ocr-cache', import.meta.url));
const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<';

let worker: Promise<Worker> | null = null;
let idleTimer: NodeJS.Timeout | null = null;
let queue: Promise<unknown> = Promise.resolve();
function getWorker() {
  if (!worker) {
    mkdirSync(CACHE_DIR, { recursive: true });
    worker = createWorker('mrz', 1, { langPath: LANG_DIR, cachePath: CACHE_DIR, gzip: false, logger: () => {}, errorHandler: () => {} })
      .then(async (w) => { await w.setParameters({ tessedit_char_whitelist: CHARS }); return w; })
      .catch((e) => { worker = null; throw e; });
  }
  if (idleTimer) clearTimeout(idleTimer);
  // moteur libéré après 10 min sans lecture (mémoire)
  idleTimer = setTimeout(async () => { const w = worker; worker = null; try { await (await w)?.terminate(); } catch { /* */ } }, 10 * 60_000);
  idleTimer.unref?.();
  return worker;
}

/** Arrêt du moteur (fin des tests, arrêt du serveur). */
export async function stopOcr() {
  if (idleTimer) clearTimeout(idleTimer);
  const w = worker; worker = null;
  try { await (await w)?.terminate(); } catch { /* */ }
}

// ------------------------------------------------------------------ contrôle et correction MRZ
const val = (c: string) => (c === '<' ? 0 : /\d/.test(c) ? Number(c) : c.charCodeAt(0) - 55);
const check = (s: string) => String([...s].reduce((t, c, i) => t + val(c) * [7, 3, 1][i % 3], 0) % 10);
const TO_DIGIT: Record<string, string> = { O: '0', Q: '0', D: '0', U: '0', I: '1', L: '1', T: '1', Z: '2', S: '5', G: '6', B: '8', A: '4' };
const TO_ALPHA: Record<string, string> = { '0': 'O', '1': 'I', '2': 'Z', '5': 'S', '8': 'B', '6': 'G', '4': 'A' };
const AMBIG: Record<string, string[]> = { '0': ['O', 'D', 'Q'], O: ['0', 'D', 'Q'], D: ['0', 'O'], Q: ['0', 'O'], '1': ['I'], I: ['1'], '5': ['S'], S: ['5'], '8': ['B'], B: ['8'], '2': ['Z'], Z: ['2'], '6': ['G'], G: ['6'] };
const digits = (s: string) => s.replace(/[A-Z]/g, (c) => TO_DIGIT[c] ?? c);
const alphas = (s: string) => s.replace(/\d/g, (c) => TO_ALPHA[c] ?? c);

/** Corrige un champ alphanumérique (n° de document) pour qu'il respecte son chiffre de contrôle (au plus 3 ambiguïtés testées). */
function fixAlnum(field: string, cd: string): string {
  if (check(field) === cd) return field;
  const pos = [...field].map((c, i) => (AMBIG[c] ? i : -1)).filter((i) => i >= 0).slice(0, 6);
  const tries: string[] = [field];
  for (const p of pos) for (const t of [...tries]) for (const alt of AMBIG[t[p]] ?? []) { const n = t.slice(0, p) + alt + t.slice(p + 1); tries.push(n); if (check(n) === cd) return n; if (tries.length > 400) return field; }
  return field;
}
const fit = (l: string, n: number) => (l.length >= n ? l.slice(0, n) : l + '<'.repeat(n - l.length));

/** Normalise les lignes lues selon le format (positions numériques / alphabétiques connues). */
function normalize(lines: string[]): string[] | null {
  const ls = lines.map((l) => l.toUpperCase().replace(/[^A-Z0-9<]/g, ''));
  const lens = ls.map((l) => l.length);
  // TD3 (passeport) : 2 × 44 · TD1 (CNI) : 3 × 30 · TD2 : 2 × 36
  let fmt: 'TD1' | 'TD2' | 'TD3' | null = null;
  for (let i = 0; i + 1 < ls.length && !fmt; i++) {
    if (lens[i] >= 40 && lens[i + 1] >= 40) { fmt = 'TD3'; ls.splice(0, i); }
  }
  if (!fmt) for (let i = 0; i + 2 < ls.length && !fmt; i++) if ([0, 1, 2].every((k) => lens[i + k] >= 27 && lens[i + k] <= 33)) { fmt = 'TD1'; ls.splice(0, i); }
  if (!fmt) for (let i = 0; i + 1 < ls.length && !fmt; i++) if (lens[i] >= 33 && lens[i] <= 39 && lens[i + 1] >= 33 && lens[i + 1] <= 39) { fmt = 'TD2'; ls.splice(0, i); }
  if (!fmt) return null;
  if (fmt === 'TD1') {
    let [a, b, c] = [fit(ls[0], 30), fit(ls[1], 30), fit(ls[2], 30)];
    a = alphas(a.slice(0, 5)) + fixAlnum(a.slice(5, 14), digits(a[14])) + digits(a[14]) + a.slice(15);
    b = digits(b.slice(0, 7)) + (b[7] === 'H' || b[7] === 'N' ? 'M' : b[7]) + digits(b.slice(8, 15)) + alphas(b.slice(15, 18)) + b.slice(18, 29) + digits(b[29]);
    c = alphas(c);
    return [a, b, c];
  }
  const n = fmt === 'TD3' ? 44 : 36;
  let [a, b] = [fit(ls[0], n), fit(ls[1], n)];
  a = alphas(a);
  b = fixAlnum(b.slice(0, 9), digits(b[9])) + digits(b[9]) + alphas(b.slice(10, 13)) + digits(b.slice(13, 20)) + b[20] + digits(b.slice(21, 28)) + b.slice(28, n - 1) + digits(b[n - 1]);
  return [a, b];
}

const NATIONALITIES: Record<string, string> = {
  DZA: 'Algérienne', MAR: 'Marocaine', TUN: 'Tunisienne', LBY: 'Libyenne', EGY: 'Égyptienne', MRT: 'Mauritanienne', FRA: 'Française', ESP: 'Espagnole', ITA: 'Italienne',
  DEU: 'Allemande', BEL: 'Belge', CHE: 'Suisse', GBR: 'Britannique', USA: 'Américaine', CAN: 'Canadienne', TUR: 'Turque', CHN: 'Chinoise', SAU: 'Saoudienne', ARE: 'Émiratie',
  QAT: 'Qatarienne', SYR: 'Syrienne', LBN: 'Libanaise', JOR: 'Jordanienne', PSE: 'Palestinienne', IRQ: 'Irakienne', MLI: 'Malienne', NER: 'Nigérienne', SEN: 'Sénégalaise',
  CIV: 'Ivoirienne', CMR: 'Camerounaise', NGA: 'Nigériane', PRT: 'Portugaise', NLD: 'Néerlandaise', RUS: 'Russe', D: 'Allemande',
};
const COUNTRY: Record<string, string> = { DZA: 'Algérie', MAR: 'Maroc', TUN: 'Tunisie', FRA: 'France', ESP: 'Espagne', ITA: 'Italie', DEU: 'Allemagne', D: 'Allemagne', BEL: 'Belgique', GBR: 'Royaume-Uni', USA: 'États-Unis', CAN: 'Canada', TUR: 'Turquie', CHN: 'Chine' };
/** YYMMDD → YYYY-MM-DD (naissance : jamais dans le futur ; expiration : 20YY). */
function isoDate(yymmdd: string | null | undefined, kind: 'birth' | 'expiry'): string | null {
  if (!yymmdd || !/^\d{6}$/.test(yymmdd)) return null;
  const yy = Number(yymmdd.slice(0, 2)), mm = yymmdd.slice(2, 4), dd = yymmdd.slice(4, 6);
  const nowYY = new Date().getFullYear() % 100;
  const year = kind === 'expiry' ? 2000 + yy : yy > nowYY ? 1900 + yy : 2000 + yy;
  const d = `${year}-${mm}-${dd}`;
  return Number.isNaN(Date.parse(d)) || Number(mm) > 12 || Number(dd) > 31 ? null : d;
}
const clean = (s?: string | null) => (s ?? '').replace(/</g, ' ').replace(/\s+/g, ' ').trim();

export type MrzResult = {
  read: boolean; valid: boolean; format: string | null; lines: string[]; checks: { field: string; ok: boolean }[];
  fields: { last_name: string | null; first_name: string | null; birth_date: string | null; gender: 'M' | 'F' | null; nationality: string | null; nationality_code: string | null;
    id_doc_type: 'passport' | 'cni' | 'other'; id_doc_number: string | null; id_doc_expiry: string | null; issuing_country: string | null } | null;
  ms: number;
};

function interpret(lines: string[]): Omit<MrzResult, 'ms'> | null {
  const norm = normalize(lines);
  if (!norm) return null;
  let r: any;
  try { r = parse(norm, { autocorrect: true } as any); } catch { return null; }
  const f = r.fields ?? {};
  const checks = (r.details ?? []).filter((d: any) => /CheckDigit$/.test(d.field)).map((d: any) => ({ field: d.field, ok: !!d.valid }));
  const code = String(f.documentCode ?? '');
  const nat = f.nationality ?? f.issuingState ?? null;
  return {
    read: true, valid: !!r.valid, format: r.format ?? null, lines: norm, checks,
    fields: {
      last_name: clean(f.lastName) || null, first_name: clean(f.firstName) || null, birth_date: isoDate(f.birthDate, 'birth'),
      gender: f.sex === 'male' ? 'M' : f.sex === 'female' ? 'F' : null, nationality: nat ? (NATIONALITIES[nat] ?? nat) : null, nationality_code: nat,
      id_doc_type: code.startsWith('P') ? 'passport' : /^(I|A|C)/.test(code) ? 'cni' : 'other', id_doc_number: clean(f.documentNumber) || null,
      id_doc_expiry: isoDate(f.expirationDate, 'expiry'), issuing_country: f.issuingState ? (COUNTRY[f.issuingState] ?? f.issuingState) : null,
    },
  };
}

function jpegOrPngSize(b: Buffer): { w: number; h: number } | null {
  if (b[0] === 0x89 && b[1] === 0x50) return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
  let i = 2;
  while (i + 9 < b.length) {
    if (b[i] !== 0xff) { i++; continue; }
    const m = b[i + 1];
    const len = b.readUInt16BE(i + 2);
    if (m >= 0xc0 && m <= 0xc3) return { h: b.readUInt16BE(i + 5), w: b.readUInt16BE(i + 7) };
    i += 2 + len;
  }
  return null;
}

/** Lit la MRZ d'une photo (JPEG / PNG). Essaie plusieurs zones et modes ; garde le meilleur résultat validé par les sommes de contrôle. */
export async function readMrz(image: Buffer): Promise<MrzResult> {
  const run = async (): Promise<MrzResult> => {
    const t0 = Date.now();
    const w = await getWorker();
    const dim = jpegOrPngSize(image);
    const zones: [string, any][] = [];
    if (dim) for (const top of [0.55, 0.65, 0.4]) zones.push(['6', { rectangle: { left: 0, top: Math.round(dim.h * top), width: dim.w, height: dim.h - Math.round(dim.h * top) } }]);
    zones.push(['11', {}], ['6', {}]);
    let best: Omit<MrzResult, 'ms'> | null = null;
    const score = (x: Omit<MrzResult, 'ms'>) => (x.valid ? 100 : 0) + x.checks.filter((c) => c.ok).length * 10 + (x.fields?.last_name ? 2 : 0);
    for (const [psm, opts] of zones) {
      await w.setParameters({ tessedit_pageseg_mode: psm as any });
      const { data } = await w.recognize(image, opts);
      const lines = data.text.split('\n').map((l) => l.replace(/\s/g, '')).filter((l) => l.length >= 25);
      const x = interpret(lines);
      if (x && (!best || score(x) > score(best))) best = x;
      if (best?.valid) break;
    }
    return { ...(best ?? { read: false, valid: false, format: null, lines: [], checks: [], fields: null }), ms: Date.now() - t0 };
  };
  // une lecture à la fois (le moteur n'est pas réentrant)
  const p = queue.then(run, run);
  queue = p.catch(() => {});
  return p;
}
