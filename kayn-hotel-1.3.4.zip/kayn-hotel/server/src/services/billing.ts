/**
 * Facturation : factures de séjour, pro forma, factures libres (comptoir / entreprises), avoirs, partage,
 * transferts de prestations, règles de paiement (caisse, carte, paiement en ligne).
 * Tous les montants sont calculés en centimes entiers ; les taux et montants sont figés dans chaque facture.
 */
import { currency } from './exports.js';
import type { PoolClient } from 'pg';
import { one, q, type Db } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { today } from '../lib/dates.js';
import { AppError, badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { fromCents, shareCents, taxCents, toCents } from '../lib/money.js';
import { getSettings, guestDisplayName, nextNumber, taxRateFor } from './common.js';
import { getReservation, upsertGuest, type GuestInput, type PayMethod } from './reservations.js';

export type InvoiceType = 'invoice' | 'proforma' | 'credit_note';
export interface Line { kind: string; category?: string | null; description: string; service_date?: string | null; quantity: number; unit_price: number; discount?: number; tax_rate: number; group?: string }
const MEAL_LBL: Record<string, string> = { RO: 'chambre seule', BB: 'petit-déjeuner', HB: 'demi-pension', FB: 'pension complète' };
const SERIES: Record<InvoiceType, [string, string]> = { invoice: ['inv', 'F'], proforma: ['pf', 'PF'], credit_note: ['av', 'AV'] };

// =====================================================================================================
// Lignes d'un séjour
// =====================================================================================================
/** Lignes de facture d'un dossier (chambres choisies ou tout le dossier), au taux figé de chaque ligne. */
export async function stayLines(db: Db, hotelId: number, resId: number, rrIds: number[] | null, includeUnassigned: boolean): Promise<Line[]> {
  const res = await getReservation(db as any, hotelId, resId);
  const vat = Number(res.vat_rate ?? 0);
  const lines: Line[] = [];
  let taxNights = 0;
  const rooms = res.rooms.filter((rr: any) => !['cancelled', 'no_show'].includes(rr.status) && (!rrIds || rrIds.includes(rr.id)));
  for (const rr of rooms) {
    const n = Number(rr.nights);
    if (n <= 0) continue;
    lines.push({
      kind: 'room', category: 'room', group: `rr${rr.id}`, service_date: rr.check_in, quantity: n, unit_price: Number(rr.rack_rate), tax_rate: vat,
      discount: fromCents(toCents(rr.discount_per_night) * n),
      description: `Hébergement ch. ${rr.room_number} (${rr.room_type}, ${MEAL_LBL[res.meal_plan]}) du ${rr.check_in} au ${rr.check_out}${rr.occupant_name ? ` — ${rr.occupant_name}` : ''}`,
    });
    taxNights += n * rr.adults;
  }
  for (const c of res.charges) {
    if (c.void) continue;
    const mine = c.reservation_room_id ? !rrIds || rrIds.includes(c.reservation_room_id) : includeUnassigned;
    if (!mine) continue;
    lines.push({ kind: c.kind, category: c.kind, description: c.description, service_date: c.service_date, quantity: Number(c.quantity), unit_price: Number(c.unit_price), tax_rate: Number(c.tax_rate), group: `c${c.id}` });
  }
  const tt = Number(res.tourist_tax ?? 0);
  if (tt > 0 && taxNights > 0) lines.push({ kind: 'tourist_tax', category: 'tourist_tax', description: 'Taxe de séjour (par adulte et par nuit)', quantity: taxNights, unit_price: tt, tax_rate: 0 });
  return lines;
}

/** Montants d'une ligne en centimes : HT net, TVA (arrondie à la ligne), TTC. */
function lineAmounts(l: Line) {
  const gross = Math.round(toCents(l.unit_price) * l.quantity);
  const net = gross - toCents(l.discount ?? 0);
  const tax = l.kind === 'tourist_tax' ? 0 : taxCents(net, l.tax_rate);
  return { gross, net, tax };
}

export function computeTotals(lines: Line[]) {
  let subtotal = 0, tax = 0, discount = 0, tourist = 0;
  const groups = new Map<number, { base: number; tax: number }>();
  for (const l of lines) {
    const a = lineAmounts(l);
    if (l.kind === 'tourist_tax') { tourist += a.net; continue; }
    subtotal += a.net;
    tax += a.tax;
    discount += toCents(l.discount ?? 0);
    const g = groups.get(l.tax_rate) ?? { base: 0, tax: 0 };
    g.base += a.net; g.tax += a.tax;
    groups.set(l.tax_rate, g);
  }
  return {
    subtotal: fromCents(subtotal), tax_total: fromCents(tax), discount_total: fromCents(discount), tourist_tax_total: fromCents(tourist),
    total: fromCents(subtotal + tax + tourist),
    breakdown: [...groups.entries()].sort((a, b) => a[0] - b[0]).map(([rate, g]) => ({ rate, base: fromCents(g.base), tax: fromCents(g.tax) })),
  };
}

// =====================================================================================================
// Émission
// =====================================================================================================
async function snapshots(db: Db, hotelId: number, guestId: number) {
  const h = await one<any>(db, 'SELECT name, commercial_name, address, city, postal_code, country, phone, email, website, nif, nis, rc, art, logo_id, currency, currency_symbol FROM hotels WHERE id = $1', [hotelId]);
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2', [guestId, hotelId]);
  if (!g) throw notFound('Client à facturer introuvable');
  return {
    seller: h,
    bill_to: { id: g.id, name: guestDisplayName(g), kind: g.kind, address: [g.address, g.city, g.country].filter(Boolean).join(', ') || null, nif: g.nif ?? null, phone: g.phone ?? null, email: g.email ?? null, tax_exempt: g.tax_exempt, tax_exempt_reason: g.tax_exempt_reason ?? null },
  };
}

export async function issueInvoice(db: PoolClient, actor: Actor, o: {
  type: InvoiceType; guest_id: number; lines: Line[]; reservation_id?: number | null; reservation_room_id?: number | null; kind?: string;
  credit_of_invoice_id?: number | null; credit_mode?: 'commercial' | 'cancel_reissue' | null; reason?: string | null; notes?: string | null; due_date?: string | null;
}) {
  if (!o.lines.length) throw badRequest('Facture vide : aucune ligne à facturer.');
  for (const l of o.lines) {
    if (!(l.quantity > 0)) throw badRequest(`Quantité invalide : ${l.description}`);
    if (l.tax_rate < 0 || l.tax_rate > 100) throw badRequest('Taux de taxe invalide.');
    if (o.type !== 'credit_note' && l.unit_price < 0 && l.kind !== 'adjustment') throw badRequest('Prix négatif interdit (utilisez un avoir).');
  }
  const t = computeTotals(o.lines);
  const year = today().slice(0, 4);
  const [key, prefix] = SERIES[o.type];
  const seq = await nextNumber(db, `${key}-${year}`);
  const number = `${prefix}${year}-${String(seq).padStart(6, '0')}`;
  const snap = await snapshots(db, actor.hotelId, o.guest_id);
  const settings = await getSettings(db, actor.hotelId);
  const inv = await one<any>(
    db,
    `INSERT INTO invoices (hotel_id, number, reservation_id, reservation_room_id, guest_id, kind, type, status, subtotal, tax_total, total, discount_total, tourist_tax_total,
                           tax_breakdown, bill_to, seller, credit_of_invoice_id, credit_mode, reason, notes, due_date, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22) RETURNING *`,
    [actor.hotelId, number, o.reservation_id ?? null, o.reservation_room_id ?? null, o.guest_id, o.kind ?? (o.reservation_id ? 'stay' : 'service'), o.type,
      o.type === 'proforma' ? 'proforma' : 'issued', t.subtotal, t.tax_total, t.total, t.discount_total, t.tourist_tax_total, JSON.stringify(t.breakdown),
      JSON.stringify(snap.bill_to), JSON.stringify(snap.seller), o.credit_of_invoice_id ?? null, o.credit_mode ?? null, o.reason ?? null,
      o.notes ?? (settings.invoice_footer || null), o.due_date ?? null, actor.userId],
  );
  for (const l of o.lines) {
    const a = lineAmounts(l);
    await db.query(
      `INSERT INTO invoice_items (invoice_id, kind, category, description, service_date, quantity, unit_price, discount, tax_rate, tax_amount, total) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
      [inv.id, l.kind, l.category ?? null, l.description, l.service_date ?? null, l.quantity, l.unit_price, l.discount ?? 0, l.tax_rate, fromCents(a.tax), fromCents(a.net)],
    );
  }
  await audit(db, actor, 'create', o.type, inv.id, null, { number, total: t.total, reservation_id: o.reservation_id ?? null, credit_of: o.credit_of_invoice_id ?? null });
  return inv;
}

/** Facture de séjour / finale (également utilisée au check-out). */
export async function stayInvoice(db: PoolClient, actor: Actor, resId: number, rrIds: number[] | null, includeUnassigned: boolean) {
  const res = await getReservation(db, actor.hotelId, resId);
  const lines = await stayLines(db, actor.hotelId, resId, rrIds, includeUnassigned);
  const single = rrIds && rrIds.length >= 1 ? res.rooms.find((x: any) => x.id === rrIds[0]) : null;
  const billTo = single?.guest_id ?? res.payer_guest_id ?? res.guest_id;
  const inv = await issueInvoice(db, actor, {
    type: 'invoice', guest_id: billTo, lines, reservation_id: resId, reservation_room_id: single?.id ?? null,
    kind: rrIds && res.rooms.length > 1 ? 'stay' : res.rooms.length > 1 ? 'group' : 'stay',
  });
  await refreshInvoiceStatus(db, resId);
  return one<any>(db, 'SELECT * FROM invoices WHERE id = $1', [inv.id]);
}

/** Pro forma : document de devis / prévision, sans valeur comptable (série PF). */
export async function proforma(db: PoolClient, actor: Actor, resId: number, rrIds: number[] | null) {
  const res = await getReservation(db, actor.hotelId, resId);
  if (['cancelled', 'no_show'].includes(res.status)) throw conflict('Réservation annulée.');
  const lines = await stayLines(db, actor.hotelId, resId, rrIds, true);
  return issueInvoice(db, actor, { type: 'proforma', guest_id: res.payer_guest_id ?? res.guest_id, lines, reservation_id: resId, kind: 'proforma' });
}

// =====================================================================================================
// Factures libres (comptoir, salle, entreprises sans séjour)
// =====================================================================================================
export async function manualInvoice(db: PoolClient, actor: Actor, o: { guest: GuestInput; lines: { description: string; category: string; quantity: number; unit_price: number; discount?: number; tax_rate?: number | null }[]; due_date?: string | null; notes?: string | null }) {
  const guestId = await upsertGuest(db, actor, o.guest);
  const g = await one<any>(db, 'SELECT tax_exempt FROM guests WHERE id = $1', [guestId]);
  const settings = await getSettings(db, actor.hotelId);
  const lines: Line[] = o.lines.map((l) => {
    const gross = Math.round(toCents(l.unit_price) * l.quantity);
    if (toCents(l.discount ?? 0) > gross) throw badRequest(`Remise supérieure au montant : ${l.description}`);
    return { kind: 'service', category: l.category, description: l.description, quantity: l.quantity, unit_price: l.unit_price, discount: l.discount ?? 0,
      tax_rate: g.tax_exempt ? 0 : l.tax_rate ?? taxRateFor(settings, l.category) };
  });
  return issueInvoice(db, actor, { type: 'invoice', guest_id: guestId, lines, kind: 'service', due_date: o.due_date ?? null, notes: o.notes ?? null });
}

// =====================================================================================================
// Avoirs & partage
// =====================================================================================================
/**
 * Répartit un montant TTC exact (centimes) sur les taux d'une facture, au prorata de leur TTC.
 * Chaque part est convertie en HT de sorte que HT + TVA arrondie = part ; l'éventuel centime restant
 * (TTC inatteignable à ce taux) est reporté sur le taux suivant, puis sur une ligne « écart d'arrondi » à 0 %.
 */
function ttcToLines(target: number, groups: { rate: number; gross: number }[], totalGross: number, label: (rate: number, tourist: boolean) => string, kind: string): Line[] {
  const lines: Line[] = [];
  let left = target;
  let carry = 0;
  groups.forEach((g, i) => {
    let part = (i === groups.length - 1 ? left : shareCents(target, g.gross, totalGross)) + carry;
    if (i !== groups.length - 1) left -= part - carry;
    carry = 0;
    if (part === 0) return;
    const tourist = g.rate === -1;
    let base = tourist ? part : shareCents(part, 10_000, 10_000 + Math.round(g.rate * 100));
    if (!tourist) {
      const hit = [0, -1, 1, -2, 2].find((d) => base + d + taxCents(base + d, g.rate) === part);
      if (hit !== undefined) base += hit;
      carry = part - (base + taxCents(base, g.rate));
    }
    lines.push({ kind: tourist ? 'tourist_tax' : kind, category: tourist ? 'tourist_tax' : kind, description: label(g.rate, tourist), quantity: 1, unit_price: fromCents(base), tax_rate: tourist ? 0 : g.rate });
  });
  if (carry !== 0) lines.push({ kind, category: kind, description: 'Écart d\'arrondi', quantity: 1, unit_price: fromCents(carry), tax_rate: 0 });
  return lines;
}

async function loadInvoice(db: Db, hotelId: number, id: number, lock = false) {
  const inv = await one<any>(db, `SELECT * FROM invoices WHERE id = $1 AND hotel_id = $2${lock ? ' FOR UPDATE' : ''}`, [id, hotelId]);
  if (!inv) throw notFound('Facture introuvable');
  return inv;
}
async function creditedSoFar(db: Db, invId: number) {
  const r = await one<any>(db, `SELECT COALESCE(sum(-total), 0) AS n FROM invoices WHERE credit_of_invoice_id = $1 AND type = 'credit_note'`, [invId]);
  return toCents(r.n);
}

/**
 * Avoir. full = annulation totale ; amount = avoir partiel TTC (réparti au prorata des taux de la facture).
 * commercial : réduit ce que le client doit (geste, erreur) ; cancel_reissue : annule pour réémettre (le dû du séjour ne change pas).
 */
export async function creditNote(db: PoolClient, actor: Actor, invId: number, o: { mode: 'commercial' | 'cancel_reissue'; reason: string; amount?: number | null }) {
  const inv = await loadInvoice(db, actor.hotelId, invId, true);
  if (inv.type !== 'invoice') throw conflict('Un avoir ne peut porter que sur une facture.');
  if (inv.status === 'credited' || inv.status === 'cancelled') throw conflict('Facture déjà entièrement annulée par avoir.');
  if (!o.reason?.trim() || o.reason.trim().length < 3) throw badRequest('Motif de l\'avoir obligatoire.');
  const already = await creditedSoFar(db, invId);
  const totalC = toCents(inv.total);
  const remaining = totalC - already;
  const full = o.amount == null || toCents(o.amount) >= remaining;
  if (!full && !(toCents(o.amount!) > 0)) throw badRequest('Montant de l\'avoir invalide.');
  if (o.mode === 'cancel_reissue' && (!full || already > 0)) throw conflict('L\'annulation pour réémission porte sur la totalité d\'une facture sans avoir antérieur.');
  const items = await q<any>(db, 'SELECT * FROM invoice_items WHERE invoice_id = $1 ORDER BY id', [invId]);
  let lines: Line[];
  if (full && already === 0) {
    lines = items.map((i) => ({ kind: i.kind, category: i.category, description: `Annulation : ${i.description}`, service_date: i.service_date, quantity: Number(i.quantity), unit_price: -Number(i.unit_price), discount: -Number(i.discount), tax_rate: Number(i.tax_rate) }));
  } else {
    // avoir partiel (ou solde restant) : réparti par taux de TVA au prorata, taxe de séjour comprise
    const target = full ? remaining : toCents(o.amount!);
    const groups = (inv.tax_breakdown as any[]).map((g) => ({ rate: Number(g.rate), gross: toCents(g.base) + toCents(g.tax) }));
    if (toCents(inv.tourist_tax_total) > 0) groups.push({ rate: -1, gross: toCents(inv.tourist_tax_total) });
    lines = ttcToLines(-target, groups, totalC, (rate, tourist) => (tourist ? 'Avoir — taxe de séjour' : `Avoir partiel (TVA ${rate} %)`), 'adjustment');
  }
  const cn = await issueInvoice(db, actor, {
    type: 'credit_note', guest_id: inv.guest_id, lines, reservation_id: inv.reservation_id, reservation_room_id: inv.reservation_room_id,
    kind: 'credit_note', credit_of_invoice_id: inv.id, credit_mode: o.mode, reason: o.reason.trim(),
  });
  if (toCents(cn.total) + remaining < 0) throw conflict('L\'avoir dépasse le montant restant de la facture.');
  // avoir commercial sur un séjour : le dû du dossier diminue (ajustements négatifs, au même taux)
  if (o.mode === 'commercial' && inv.reservation_id) {
    for (const l of lines) {
      const a = lineAmounts(l);
      await db.query(
        `INSERT INTO charges (reservation_id, reservation_room_id, service_date, kind, description, quantity, unit_price, total, created_by, tax_rate, invoice_ref)
         VALUES ($1,$2,$3,'adjustment',$4,1,$5,$5,$6,$7,$8)`,
        [inv.reservation_id, inv.reservation_room_id, today(), `Avoir ${cn.number} sur ${inv.number}`, fromCents(l.kind === 'tourist_tax' ? a.net : a.net), actor.userId, l.kind === 'tourist_tax' ? 0 : l.tax_rate, cn.number],
      );
    }
  }
  if (already - toCents(cn.total) >= totalC) await db.query(`UPDATE invoices SET status = 'credited' WHERE id = $1`, [inv.id]);
  if (inv.reservation_id) await refreshInvoiceStatus(db, inv.reservation_id);
  else await refreshManualInvoice(db, inv.id);
  await audit(db, actor, 'credit_note', 'invoice', inv.id, { status: inv.status }, { credit_note: cn.number, total: Number(cn.total), mode: o.mode, reason: o.reason });
  return cn;
}

/** Partage d'une facture entre plusieurs clients : avoir d'annulation puis une facture par client, au prorata exact. */
export async function splitInvoice(db: PoolClient, actor: Actor, invId: number, parts: { guest: GuestInput; percent?: number; amount?: number }[], reason: string) {
  const inv = await loadInvoice(db, actor.hotelId, invId, true);
  if (inv.type !== 'invoice' || inv.status === 'credited') throw conflict('Seule une facture active peut être partagée.');
  if (parts.length < 2) throw badRequest('Au moins deux clients pour partager une facture.');
  const totalC = toCents(inv.total);
  // montants exacts en centimes : pourcentages ou montants, dernier = reste
  const shares: number[] = [];
  let left = totalC;
  parts.forEach((p, i) => {
    const s = i === parts.length - 1 ? left : p.amount != null ? toCents(p.amount) : shareCents(totalC, Math.round((p.percent ?? 0) * 100), 10_000);
    if (s <= 0) throw badRequest('Chaque part doit être positive.');
    shares.push(s);
    left -= s;
  });
  if (left !== 0) throw badRequest('La somme des parts doit être égale au total de la facture.');
  if (shares.some((s) => s <= 0)) throw badRequest('Chaque part doit être positive.');
  await creditNote(db, actor, invId, { mode: 'cancel_reissue', reason: reason || 'Partage de la facture' });
  const groups = (inv.tax_breakdown as any[]).map((g) => ({ rate: Number(g.rate), gross: toCents(g.base) + toCents(g.tax) }));
  if (toCents(inv.tourist_tax_total) > 0) groups.push({ rate: -1, gross: toCents(inv.tourist_tax_total) });
  const out = [];
  for (let i = 0; i < parts.length; i++) {
    const guestId = await upsertGuest(db, actor, parts[i].guest);
    const pct = (shares[i] * 100 / totalC).toFixed(2);
    const lines = ttcToLines(shares[i], groups, totalC, (rate, tourist) => (tourist ? `Quote-part taxe de séjour — facture ${inv.number}` : `Quote-part ${pct} % de la facture ${inv.number} (TVA ${rate} %)`), 'service');
    out.push(await issueInvoice(db, actor, { type: 'invoice', guest_id: guestId, lines, reservation_id: inv.reservation_id, kind: inv.kind, reason: `Partage de ${inv.number}` }));
  }
  if (inv.reservation_id) await refreshInvoiceStatus(db, inv.reservation_id);
  return out;
}

// =====================================================================================================
// Statut des factures (paiements, avoirs)
// =====================================================================================================
/** Factures d'un séjour : paiements rattachés à la chambre d'abord, puis paiements communs, dans l'ordre des factures. */
export async function refreshInvoiceStatus(db: Db, resId: number) {
  const invs = await q<any>(db, `SELECT i.id, i.total, i.reservation_room_id,
      (SELECT COALESCE(sum(-c.total), 0) FROM invoices c WHERE c.credit_of_invoice_id = i.id AND c.type = 'credit_note') AS credited
     FROM invoices i WHERE i.reservation_id = $1 AND i.type = 'invoice' AND i.status NOT IN ('cancelled','credited') ORDER BY i.id`, [resId]);
  if (!invs.length) return;
  const pays = await q<any>(db, `SELECT reservation_room_id, sum(amount) AS amount FROM payments WHERE reservation_id = $1 AND NOT void GROUP BY 1`, [resId]);
  const refunded = toCents((await one<any>(db, `SELECT COALESCE(sum(amount),0) AS n FROM refunds WHERE reservation_id = $1`, [resId])).n);
  const byRoom = new Map<number | null, number>(pays.map((p) => [p.reservation_room_id, toCents(p.amount)]));
  let pool = (byRoom.get(null) ?? 0) - refunded;
  for (const inv of invs) {
    const due = toCents(inv.total) - toCents(inv.credited);
    let paid = inv.reservation_room_id ? byRoom.get(inv.reservation_room_id) ?? 0 : 0;
    if (!inv.reservation_room_id) for (const [k, v] of byRoom) if (k !== null) paid += v;
    const take = Math.max(0, Math.min(Math.max(0, due - paid), pool));
    pool -= take;
    paid += take;
    const st = due <= 0 ? 'credited' : paid >= due ? 'paid' : paid > 0 ? 'partially_paid' : 'issued';
    await db.query(`UPDATE invoices SET status = $2 WHERE id = $1`, [inv.id, st]);
  }
}

/** Facture libre : payée par les paiements qui lui sont rattachés. */
export async function refreshManualInvoice(db: Db, invId: number) {
  const r = await one<any>(db, `SELECT i.total,
      (SELECT COALESCE(sum(-c.total),0) FROM invoices c WHERE c.credit_of_invoice_id = i.id AND c.type = 'credit_note') AS credited,
      (SELECT COALESCE(sum(p.amount),0) FROM payments p WHERE p.invoice_id = i.id AND NOT p.void) AS paid,
      (SELECT COALESCE(sum(f.amount),0) FROM refunds f WHERE f.invoice_id = i.id) AS refunded, i.status
     FROM invoices i WHERE i.id = $1`, [invId]);
  if (r.status === 'cancelled') return;
  const due = toCents(r.total) - toCents(r.credited);
  const paid = toCents(r.paid) - toCents(r.refunded);
  const st = due <= 0 ? 'credited' : paid >= due ? 'paid' : paid > 0 ? 'partially_paid' : 'issued';
  await db.query(`UPDATE invoices SET status = $2 WHERE id = $1`, [invId, st]);
}

export async function invoiceDetail(db: Db, hotelId: number, id: number) {
  const inv = await loadInvoice(db, hotelId, id);
  const items = await q<any>(db, 'SELECT * FROM invoice_items WHERE invoice_id = $1 ORDER BY id', [id]);
  const credits = await q<any>(db, `SELECT id, number, total, issued_at, reason, credit_mode FROM invoices WHERE credit_of_invoice_id = $1 ORDER BY id`, [id]);
  const original = inv.credit_of_invoice_id ? await one<any>(db, 'SELECT id, number FROM invoices WHERE id = $1', [inv.credit_of_invoice_id]) : null;
  const payments = inv.reservation_id
    ? await q<any>(db, `SELECT p.*, u.full_name AS received_by_name FROM payments p LEFT JOIN users u ON u.id = p.received_by WHERE p.reservation_id = $1 ORDER BY p.received_at`, [inv.reservation_id])
    : await q<any>(db, `SELECT p.*, u.full_name AS received_by_name FROM payments p LEFT JOIN users u ON u.id = p.received_by WHERE p.invoice_id = $1 ORDER BY p.received_at`, [id]);
  const refunds = inv.reservation_id
    ? await q<any>(db, 'SELECT * FROM refunds WHERE reservation_id = $1 ORDER BY created_at', [inv.reservation_id])
    : await q<any>(db, 'SELECT * FROM refunds WHERE invoice_id = $1 ORDER BY created_at', [id]);
  const res = inv.reservation_id ? await one<any>(db, 'SELECT code, check_in, check_out FROM reservations WHERE id = $1', [inv.reservation_id]) : null;
  const credited = fromCents(credits.reduce((s, c) => s - toCents(c.total), 0));
  const netPaid = fromCents(payments.filter((p) => !p.void).reduce((s, p) => s + toCents(p.amount), 0) - refunds.reduce((s, f) => s + toCents(f.amount), 0));
  return { ...inv, guest_name: inv.bill_to?.name ?? '', items, credits, original, payments, refunds, reservation: res, credited, net_paid: netPaid, due: inv.type === 'invoice' ? fromCents(Math.max(0, toCents(inv.total) - toCents(credited) - (inv.reservation_id ? 0 : toCents(netPaid)))) : 0 };
}

// =====================================================================================================
// Transfert de prestations entre chambres / clients
// =====================================================================================================
export async function transferCharge(db: PoolClient, actor: Actor, chargeId: number, to: { reservation_id: number; reservation_room_id?: number | null }, reason: string) {
  const c = await one<any>(db, `SELECT c.*, r.hotel_id, r.status AS res_status FROM charges c JOIN reservations r ON r.id = c.reservation_id WHERE c.id = $1 FOR UPDATE OF c`, [chargeId]);
  if (!c || c.hotel_id !== actor.hotelId) throw notFound('Prestation introuvable');
  if (c.void) throw conflict('Prestation annulée : transfert impossible.');
  if (c.kind === 'adjustment') throw conflict('Un ajustement d\'avoir ne se transfère pas.');
  if (c.res_status === 'checked_out') throw conflict('Dossier facturé : faites un avoir.');
  if (!reason?.trim()) throw badRequest('Motif du transfert obligatoire.');
  const tgt = await one<any>(db, `SELECT id, status, hotel_id FROM reservations WHERE id = $1 FOR UPDATE`, [to.reservation_id]);
  if (!tgt || tgt.hotel_id !== actor.hotelId) throw notFound('Dossier destinataire introuvable');
  if (['cancelled', 'no_show', 'checked_out'].includes(tgt.status)) throw conflict('Dossier destinataire clôturé.');
  if (to.reservation_room_id) {
    const rr = await one<any>(db, 'SELECT status FROM reservation_rooms WHERE id = $1 AND reservation_id = $2', [to.reservation_room_id, to.reservation_id]);
    if (!rr || ['checked_out', 'cancelled', 'no_show'].includes(rr.status)) throw badRequest('Chambre destinataire invalide ou clôturée.');
  }
  if (c.reservation_id === to.reservation_id) {
    if ((c.reservation_room_id ?? null) === (to.reservation_room_id ?? null)) throw badRequest('Même destination.');
    await db.query('UPDATE charges SET reservation_room_id = $2 WHERE id = $1', [chargeId, to.reservation_room_id ?? null]);
    await audit(db, actor, 'transfer', 'charge', chargeId, { reservation_room_id: c.reservation_room_id }, { reservation_room_id: to.reservation_room_id ?? null, reason });
    return { id: chargeId };
  }
  // vers un autre dossier : la ligne d'origine est annulée (tracée) et recréée chez le destinataire au même prix et même taux
  const code = (await one<any>(db, 'SELECT code FROM reservations WHERE id = $1', [to.reservation_id])).code;
  await db.query('UPDATE charges SET void = true, void_reason = $2, voided_by = $3, voided_at = now() WHERE id = $1', [chargeId, `Transférée vers ${code} : ${reason}`, actor.userId]);
  const n = await one<any>(db,
    `INSERT INTO charges (reservation_id, reservation_room_id, service_date, kind, description, quantity, unit_price, total, created_by, service_id, tax_rate, source_charge_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
    [to.reservation_id, to.reservation_room_id ?? null, c.service_date, c.kind, c.description, c.quantity, c.unit_price, c.total, actor.userId, c.service_id, c.tax_rate, c.id]);
  await audit(db, actor, 'transfer', 'charge', chargeId, { reservation_id: c.reservation_id }, { reservation_id: to.reservation_id, new_charge_id: n.id, reason });
  return n;
}

// =====================================================================================================
// Règles de paiement (caisse, carte, en ligne)
// =====================================================================================================
const PAN = /\d[\d\s-]{11,}\d/;
/** Valide un encaissement et renvoie la session de caisse à laquelle il est rattaché. */
export async function paymentRules(db: Db, actor: Actor, p: { method: PayMethod | 'online'; amount: number; reference?: string | null; card_last4?: string | null }) {
  if (!(toCents(p.amount) > 0)) throw badRequest('Montant invalide.');
  if (p.reference && PAN.test(p.reference.replace(/[^\d\s-]/g, ' ')) && p.reference.replace(/\D/g, '').length >= 12)
    throw badRequest('Ne saisissez jamais le numéro complet d\'une carte : indiquez seulement le n° d\'autorisation et les 4 derniers chiffres.');
  if (p.card_last4 && !/^\d{4}$/.test(p.card_last4)) throw badRequest('Carte : 4 derniers chiffres uniquement.');
  if ((p.method === 'cheque' || p.method === 'transfer' || p.method === 'online') && !p.reference?.trim()) throw badRequest('Référence obligatoire pour ce mode de paiement.');
  const settings = await getSettings(db, actor.hotelId);
  if (p.method === 'online' && !settings.payment_gateway?.enabled) throw badRequest('Aucune passerelle de paiement en ligne n\'est configurée.');
  const session = await findOpenSession(db, actor);
  if (p.method === 'cash' && !session && settings.cash_session_required !== false) throw new AppError(409, 'cash_closed', 'Caisse fermée : ouvrez la caisse avant d\'encaisser en espèces.');
  return session?.id ?? null;
}

/** Session de caisse de l'utilisateur (sinon la caisse ouverte de l'hôtel). */
export async function findOpenSession(db: Db, actor: Actor) {
  return one<any>(db,
    `SELECT cs.* FROM cash_sessions cs JOIN cash_registers cr ON cr.id = cs.cash_register_id
      WHERE cr.hotel_id = $1 AND cs.status = 'open' ORDER BY (cs.opened_by = $2) DESC, cs.opened_at DESC LIMIT 1`, [actor.hotelId, actor.userId]);
}

/** Paiement d'une facture libre (sans séjour). */
export async function payInvoice(db: PoolClient, actor: Actor, invId: number, p: { amount: number; method: PayMethod | 'online'; reference?: string | null; card_last4?: string | null; card_brand?: string | null }) {
  const inv = await loadInvoice(db, actor.hotelId, invId, true);
  if (inv.type !== 'invoice') throw conflict('Seule une facture peut être encaissée.');
  if (inv.reservation_id) throw conflict('Facture de séjour : encaissez depuis la réservation.');
  const d = await invoiceDetail(db, actor.hotelId, invId);
  if (toCents(p.amount) > toCents(d.due)) throw badRequest(`Montant supérieur au reste à payer (${d.due} ${currency.symbol}).`);
  const sessionId = await paymentRules(db, actor, p);
  const pay = await one<any>(db,
    `INSERT INTO payments (hotel_id, invoice_id, guest_id, kind, method, amount, reference, cash_session_id, received_by, card_last4, card_brand)
     VALUES ($1,$2,$3,'payment',$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [actor.hotelId, invId, inv.guest_id, p.method, p.amount, p.reference ?? null, sessionId, actor.userId, p.card_last4 ?? null, p.card_brand ?? null]);
  await refreshManualInvoice(db, invId);
  await audit(db, actor, 'create', 'payment', pay.id, null, { invoice_id: invId, amount: p.amount, method: p.method });
  return pay;
}

/** Remboursement d'un trop-perçu sur un dossier (jamais plus que le crédit du client). */
export async function refundReservation(db: PoolClient, actor: Actor, resId: number, r: { amount: number; method: 'cash' | 'card' | 'cheque' | 'transfer' | 'online'; reason: string; reservation_room_id?: number | null }) {
  const res = await getReservation(db, actor.hotelId, resId);
  await one(db, 'SELECT id FROM reservations WHERE id = $1 FOR UPDATE', [resId]);
  if (!r.reason?.trim()) throw badRequest('Motif du remboursement obligatoire.');
  const credit = -toCents(res.balance);
  if (!(toCents(r.amount) > 0)) throw badRequest('Montant invalide.');
  if (toCents(r.amount) > credit) throw badRequest(`Remboursement limité au trop-perçu (${fromCents(Math.max(0, credit))} ${currency.symbol}).`);
  const session = await findOpenSession(db, actor);
  const settings = await getSettings(db, actor.hotelId);
  if (r.method === 'cash' && !session && settings.cash_session_required !== false) throw new AppError(409, 'cash_closed', 'Caisse fermée : ouvrez la caisse avant de rembourser en espèces.');
  const f = await one<any>(db, `INSERT INTO refunds (reservation_id, reservation_room_id, amount, method, reason, cash_session_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [resId, r.reservation_room_id ?? null, r.amount, r.method, r.reason.trim(), session?.id ?? null, actor.userId]);
  await refreshInvoiceStatus(db, resId);
  await audit(db, actor, 'refund', 'reservation', resId, null, { refund_id: f.id, amount: r.amount, method: r.method, reason: r.reason });
  return f;
}

export function ensure(perms: Set<string>, p: string, msg?: string) {
  if (!perms.has(p)) throw forbidden(msg ?? `Permission requise : ${p}`);
}
