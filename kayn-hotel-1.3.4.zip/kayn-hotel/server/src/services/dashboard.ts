import { getPool, one, q } from '../db/pool.js';
import { config } from '../config.js';
import { addDays, monthStart } from '../lib/dates.js';
import { BALANCE_EXPR, FIN_SQL, getSettings, guestDisplayName } from './common.js';

const r2 = (n: number) => Math.round(n * 100) / 100;

export async function dashboard(hotelId: number, d: string, withFinance: boolean) {
  const db = getPool();
  const tz = config.timezone;
  const settings = await getSettings(db, hotelId);

  const rooms = await one<any>(
    db,
    `SELECT count(*)::int AS total,
            count(*) FILTER (WHERE out_of_service)::int AS oos,
            count(*) FILTER (WHERE NOT out_of_service AND hk_status NOT IN ('clean','inspected'))::int AS cleaning
       FROM rooms WHERE hotel_id = $1 AND active`,
    [hotelId],
  );
  const occ = await one<any>(
    db,
    `SELECT count(DISTINCT s.room_id)::int AS occupied FROM stays s JOIN rooms r ON r.id = s.room_id
      WHERE r.hotel_id = $1 AND s.checked_out_at IS NULL`,
    [hotelId],
  );
  const reserved = await one<any>(
    db,
    `SELECT count(DISTINCT rr.room_id)::int AS n FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id
      WHERE r.hotel_id = $1 AND rr.status IN ('pending','confirmed') AND rr.check_in <= $2 AND rr.check_out > $2`,
    [hotelId, d],
  );
  const sellable = Math.max(0, rooms.total - rooms.oos);
  const available = Math.max(0, sellable - occ.occupied - reserved.n);
  const occupancy = sellable ? r2(((occ.occupied + reserved.n) / sellable) * 100) : 0;

  const moves = await one<any>(
    db,
    `SELECT
       count(*) FILTER (WHERE rr.check_in = $2 AND rr.moved_from_rr_id IS NULL AND rr.status IN ('pending','confirmed','checked_in','checked_out'))::int AS arrivals,
       count(*) FILTER (WHERE rr.check_in = $2 AND rr.moved_from_rr_id IS NULL AND rr.status IN ('checked_in','checked_out'))::int AS arrivals_done,
       count(*) FILTER (WHERE rr.check_out = $2 AND NOT EXISTS (SELECT 1 FROM reservation_rooms nx WHERE nx.moved_from_rr_id = rr.id) AND rr.status IN ('checked_in','checked_out'))::int AS departures,
       count(*) FILTER (WHERE rr.check_out = $2 AND NOT EXISTS (SELECT 1 FROM reservation_rooms nx WHERE nx.moved_from_rr_id = rr.id) AND rr.status = 'checked_out')::int AS departures_done,
       count(*) FILTER (WHERE rr.check_out < $2 AND rr.status = 'checked_in')::int AS overdue
     FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id WHERE r.hotel_id = $1`,
    [hotelId, d],
  );
  const created = await one<any>(
    db,
    `SELECT count(*)::int AS n FROM reservations WHERE hotel_id = $1 AND (created_at AT TIME ZONE $3)::date = $2`,
    [hotelId, d, tz],
  );

  // Revenus (nuitées réalisées + extras) par jour sur 30 jours
  const from30 = addDays(d, -29);
  const series = await q<any>(
    db,
    `WITH days AS (SELECT generate_series($2::date, $3::date, '1 day')::date AS day)
     SELECT to_char(day, 'YYYY-MM-DD') AS day,
       COALESCE((SELECT sum(rr.rate) FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id
                  WHERE r.hotel_id = $1 AND rr.status IN ('checked_in','checked_out')
                    AND rr.check_in <= days.day AND rr.check_out > days.day), 0) AS room_revenue,
       COALESCE((SELECT count(*) FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id
                  WHERE r.hotel_id = $1 AND rr.status IN ('checked_in','checked_out')
                    AND rr.check_in <= days.day AND rr.check_out > days.day), 0)::int AS rooms_sold,
       COALESCE((SELECT sum(c.total) FROM charges c JOIN reservations res ON res.id = c.reservation_id
                  WHERE res.hotel_id = $1 AND NOT c.void AND c.service_date = days.day), 0) AS extras
     FROM days ORDER BY day`,
    [hotelId, from30, d],
  );
  const dayRow = series[series.length - 1];
  const sellableN = sellable || 1;
  const history = series.map((s) => ({
    day: s.day,
    revenue: r2(Number(s.room_revenue) + Number(s.extras)),
    occupancy: r2((s.rooms_sold / sellableN) * 100),
  }));

  const forecast = await q<any>(
    db,
    `WITH days AS (SELECT generate_series($2::date, $3::date, '1 day')::date AS day)
     SELECT to_char(day, 'YYYY-MM-DD') AS day,
       (SELECT count(DISTINCT rr.room_id) FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id
         WHERE r.hotel_id = $1 AND rr.status IN ('pending','confirmed','checked_in')
           AND rr.check_in <= days.day AND rr.check_out > days.day)::int AS rooms_sold
     FROM days ORDER BY day`,
    [hotelId, d, addDays(d, 13)],
  );

  const ms = monthStart(d);
  const month = await one<any>(
    db,
    `SELECT
       COALESCE((SELECT sum(rr.rate * (LEAST(rr.check_out, $3::date + 1) - GREATEST(rr.check_in, $2::date)))
                   FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id
                  WHERE r.hotel_id = $1 AND rr.status IN ('checked_in','checked_out')
                    AND rr.check_in <= $3 AND rr.check_out > $2), 0) AS room_revenue,
       COALESCE((SELECT sum(LEAST(rr.check_out, $3::date + 1) - GREATEST(rr.check_in, $2::date))
                   FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id
                  WHERE r.hotel_id = $1 AND rr.status IN ('checked_in','checked_out')
                    AND rr.check_in <= $3 AND rr.check_out > $2), 0)::int AS rooms_sold,
       COALESCE((SELECT sum(c.total) FROM charges c JOIN reservations res ON res.id = c.reservation_id
                  WHERE res.hotel_id = $1 AND NOT c.void AND c.service_date BETWEEN $2 AND $3), 0) AS extras`,
    [hotelId, ms, d],
  );
  const monthDays = Number(d.slice(8, 10));

  const dayRoomRevenue = Number(dayRow.room_revenue);
  const kpi = {
    adr_day: dayRow.rooms_sold ? r2(dayRoomRevenue / dayRow.rooms_sold) : 0,
    revpar_day: r2(dayRoomRevenue / sellableN),
    adr_month: month.rooms_sold ? r2(Number(month.room_revenue) / month.rooms_sold) : 0,
    revpar_month: r2(Number(month.room_revenue) / (sellableN * monthDays)),
  };

  let finance: any = null;
  if (withFinance) {
    const pay = await one<any>(
      db,
      `SELECT
         COALESCE(sum(amount) FILTER (WHERE (received_at AT TIME ZONE $4)::date = $2), 0) AS today,
         COALESCE(sum(amount) FILTER (WHERE (received_at AT TIME ZONE $4)::date BETWEEN $3 AND $2), 0) AS month
       FROM payments WHERE hotel_id = $1 AND NOT void`,
      [hotelId, d, ms, tz],
    );
    const ref = await one<any>(
      db,
      `SELECT
         COALESCE(sum(f.amount) FILTER (WHERE (f.created_at AT TIME ZONE $4)::date = $2), 0) AS today,
         COALESCE(sum(f.amount) FILTER (WHERE (f.created_at AT TIME ZONE $4)::date BETWEEN $3 AND $2), 0) AS month
       FROM refunds f JOIN reservations r ON r.id = f.reservation_id WHERE r.hotel_id = $1`,
      [hotelId, d, ms, tz],
    );
    const exp = await one<any>(
      db,
      `SELECT COALESCE(sum(amount) FILTER (WHERE expense_date = $2), 0) AS today,
              COALESCE(sum(amount) FILTER (WHERE expense_date BETWEEN $3 AND $2), 0) AS month
         FROM expenses WHERE hotel_id = $1`,
      [hotelId, d, ms],
    );
    const recv = await one<any>(
      db,
      `SELECT COALESCE(sum(GREATEST(${BALANCE_EXPR}, 0)), 0) AS receivables,
              count(*) FILTER (WHERE ${BALANCE_EXPR} > 0)::int AS debtors
         FROM (SELECT ${FIN_SQL} FROM reservations r WHERE r.hotel_id = $1 AND r.status IN ('checked_in','checked_out','cancelled','no_show')) x`,
      [hotelId],
    );
    const methods = await q<any>(
      db,
      `SELECT method, sum(amount) AS amount FROM payments
        WHERE hotel_id = $1 AND NOT void AND (received_at AT TIME ZONE $4)::date BETWEEN $3 AND $2 GROUP BY method ORDER BY 2 DESC`,
      [hotelId, d, ms, tz],
    );
    // ventes restaurant réglées hors chambre (celles portées sur la chambre sont déjà dans les prestations du folio)
    const rsv = await one<any>(db, `SELECT COALESCE(sum(total) FILTER (WHERE (created_at AT TIME ZONE $4)::date = $2), 0) AS today, COALESCE(sum(total), 0) AS month,
        COALESCE(sum(total) FILTER (WHERE (created_at AT TIME ZONE $4)::date = $2 AND settlement = 'room'), 0) AS room_today, COALESCE(sum(total) FILTER (WHERE settlement = 'room'), 0) AS room_month
       FROM rs_orders WHERE hotel_id = $1 AND settlement IN ('paid','room','invoice') AND (created_at AT TIME ZONE $4)::date BETWEEN $3 AND $2`, [hotelId, d, ms, tz]);
    // 12 derniers mois (comptabilisation mensuelle) : CA, encaissements nets, dépenses
    const m12 = await q<any>(db, `WITH m AS (SELECT generate_series(date_trunc('month', $2::date) - interval '11 months', date_trunc('month', $2::date), interval '1 month')::date AS ms)
      SELECT to_char(ms, 'YYYY-MM') AS month,
        COALESCE((SELECT sum(rr.rate * GREATEST(0, LEAST(rr.check_out, (ms + interval '1 month')::date) - GREATEST(rr.check_in, ms)))
                    FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id
                   WHERE r.hotel_id = $1 AND rr.status IN ('checked_in','checked_out') AND rr.check_in < (ms + interval '1 month')::date AND rr.check_out > ms), 0)
        + COALESCE((SELECT sum(c.total) FROM charges c JOIN reservations res ON res.id = c.reservation_id
                    WHERE res.hotel_id = $1 AND NOT c.void AND c.service_date >= ms AND c.service_date < (ms + interval '1 month')::date), 0)
        + COALESCE((SELECT sum(o.total) FROM rs_orders o WHERE o.hotel_id = $1 AND o.settlement IN ('paid','invoice')
                    AND (o.created_at AT TIME ZONE $3)::date >= ms AND (o.created_at AT TIME ZONE $3)::date < (ms + interval '1 month')::date), 0) AS revenue,
        COALESCE((SELECT sum(p.amount) FROM payments p WHERE p.hotel_id = $1 AND NOT p.void
                    AND (p.received_at AT TIME ZONE $3)::date >= ms AND (p.received_at AT TIME ZONE $3)::date < (ms + interval '1 month')::date), 0)
        - COALESCE((SELECT sum(f.amount) FROM refunds f JOIN reservations r ON r.id = f.reservation_id WHERE r.hotel_id = $1
                    AND (f.created_at AT TIME ZONE $3)::date >= ms AND (f.created_at AT TIME ZONE $3)::date < (ms + interval '1 month')::date), 0) AS payments,
        COALESCE((SELECT sum(e.amount) FROM expenses e WHERE e.hotel_id = $1 AND e.expense_date >= ms AND e.expense_date < (ms + interval '1 month')::date), 0) AS expenses
      FROM m ORDER BY ms`, [hotelId, d, tz]);
    const months = m12.map((x) => ({ month: x.month, revenue: r2(Number(x.revenue)), payments: r2(Number(x.payments)), expenses: r2(Number(x.expenses)) }));
    const prev = months.length > 1 ? months[months.length - 2] : null;
    finance = {
      revenue_day: r2(dayRoomRevenue + Number(dayRow.extras) + Number(rsv.today) - Number(rsv.room_today)),
      revenue_month: r2(Number(month.room_revenue) + Number(month.extras) + Number(rsv.month) - Number(rsv.room_month)),
      restaurant_day: r2(Number(rsv.today)),
      restaurant_month: r2(Number(rsv.month)),
      payments_day: r2(Number(pay.today) - Number(ref.today)),
      payments_month: r2(Number(pay.month) - Number(ref.month)),
      receivables: r2(Number(recv.receivables)),
      debtors: recv.debtors,
      expenses_day: r2(Number(exp.today)),
      expenses_month: r2(Number(exp.month)),
      payment_methods: methods.map((m) => ({ method: m.method, amount: Number(m.amount) })),
      months,
      prev_month: prev,
    };
  }

  // ===== Restaurant (synchronisation) =====
  const rsLive = await one<any>(db, `SELECT count(*) FILTER (WHERE status IN ('new','confirmed','preparing','ready'))::int AS open_orders,
      count(*) FILTER (WHERE status = 'ready')::int AS ready, count(*) FILTER (WHERE outlet = 'room_service' AND status NOT IN ('served','cancelled'))::int AS room_service
     FROM rs_orders WHERE hotel_id = $1`, [hotelId]);
  const lowStock = await one<any>(db, `SELECT count(*)::int AS n FROM products WHERE hotel_id = $1 AND active AND archived_at IS NULL AND stock_qty <= min_stock AND min_stock > 0`, [hotelId]);
  // Stocks & achats (synchronisation)
  const stk = await one<any>(db, `SELECT (SELECT count(*) FROM purchase_orders WHERE hotel_id = $1 AND status = 'pending')::int AS to_approve,
      (SELECT count(*) FROM purchase_orders WHERE hotel_id = $1 AND status IN ('ordered','partial') AND expected_date < $2)::int AS late_po,
      (SELECT count(*) FROM supplier_invoices WHERE hotel_id = $1 AND status IN ('unpaid','partial') AND due_date < $2)::int AS overdue_invoices,
      (SELECT count(*) FROM stock_lots l JOIN products p ON p.id = l.product_id WHERE p.hotel_id = $1 AND l.qty > 0 AND l.expiry_date <= $2::date + 7)::int AS expiring,
      (SELECT COALESCE(sum(stock_qty * avg_cost) FILTER (WHERE stock_qty > 0), 0) FROM products WHERE hotel_id = $1 AND archived_at IS NULL) AS stock_value`, [hotelId, d]);

  // ===== Alertes =====
  const alerts: { level: 'danger' | 'warning' | 'info'; code: string; message: string; count: number }[] = [];
  // Night audit : date opérationnelle en retard sur le calendrier (après 6 h, la journée de la veille devrait être clôturée)
  const bd = await one<any>(db, `SELECT business_date FROM audit_days WHERE hotel_id = $1 AND status IN ('open','checking','ready','reopened') LIMIT 1`, [hotelId]);
  if (bd) {
    const b = String(bd.business_date instanceof Date ? bd.business_date.toISOString() : bd.business_date).slice(0, 10);
    const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', hour12: false }).format(new Date()));
    const lag = Math.round((Date.parse(d) - Date.parse(b)) / 86_400_000);
    if (lag > 1 || (lag === 1 && hour >= 6)) alerts.push({ level: 'danger', code: 'night_audit_late', count: lag, message: `Night audit en retard : la date opérationnelle est toujours le ${b.slice(8, 10)}/${b.slice(5, 7)}/${b.slice(0, 4)}` });
  }
  if (moves.overdue) alerts.push({ level: 'danger', code: 'overdue_departures', count: moves.overdue, message: `${moves.overdue} client(s) en dépassement de date de départ` });
  if (rsLive.room_service) alerts.push({ level: 'info', code: 'room_service', count: rsLive.room_service, message: `${rsLive.room_service} commande(s) room service en cours` });
  if (lowStock.n) alerts.push({ level: 'warning', code: 'low_stock', count: lowStock.n, message: `${lowStock.n} article(s) de stock sous le minimum` });
  if (stk.expiring) alerts.push({ level: 'warning', code: 'expiring', count: stk.expiring, message: `${stk.expiring} lot(s) périmé(s) ou à péremption sous 7 jours` });
  if (stk.to_approve) alerts.push({ level: 'info', code: 'po_to_approve', count: stk.to_approve, message: `${stk.to_approve} demande(s) d'achat à valider` });
  if (stk.late_po) alerts.push({ level: 'warning', code: 'late_po', count: stk.late_po, message: `${stk.late_po} commande(s) fournisseur en retard` });
  if (stk.overdue_invoices) alerts.push({ level: 'warning', code: 'supplier_overdue', count: stk.overdue_invoices, message: `${stk.overdue_invoices} facture(s) fournisseur échue(s)` });
  const pendingArr = moves.arrivals - moves.arrivals_done;
  if (pendingArr) alerts.push({ level: 'info', code: 'arrivals_pending', count: pendingArr, message: `${pendingArr} arrivée(s) attendue(s) aujourd'hui` });
  const pendingDep = moves.departures - moves.departures_done;
  if (pendingDep) alerts.push({ level: 'info', code: 'departures_pending', count: pendingDep, message: `${pendingDep} départ(s) à traiter aujourd'hui` });
  const dirtyArr = await one<any>(
    db,
    `SELECT count(*)::int AS n, string_agg(r.number, ', ' ORDER BY r.number) AS rooms FROM reservation_rooms rr JOIN rooms r ON r.id = rr.room_id
      WHERE r.hotel_id = $1 AND rr.check_in = $2 AND rr.status IN ('pending','confirmed') AND r.hk_status NOT IN ('clean','inspected')`,
    [hotelId, d],
  );
  if (dirtyArr.n) alerts.push({ level: 'warning', code: 'dirty_arrivals', count: dirtyArr.n, message: `Chambre(s) pas prête(s) pour une arrivée du jour : ${dirtyArr.rooms}` });
  const pend = await one<any>(
    db,
    `SELECT count(*)::int AS n FROM reservations WHERE hotel_id = $1 AND status = 'pending' AND check_in BETWEEN $2 AND $3`,
    [hotelId, d, addDays(d, 3)],
  );
  if (pend.n) alerts.push({ level: 'warning', code: 'pending_soon', count: pend.n, message: `${pend.n} réservation(s) en attente arrivant sous 3 jours` });
  const balDep = await one<any>(
    db,
    `SELECT count(*)::int AS n FROM (SELECT ${FIN_SQL} FROM reservations r
       WHERE r.hotel_id = $1 AND r.status = 'checked_in' AND r.check_out <= $2) x
      WHERE ${BALANCE_EXPR} > 0`,
    [hotelId, d],
  );
  if (balDep.n) alerts.push({ level: 'warning', code: 'departure_balance', count: balDep.n, message: `${balDep.n} départ(s) avec solde à encaisser` });
  if (rooms.oos) alerts.push({ level: 'info', code: 'out_of_service', count: rooms.oos, message: `${rooms.oos} chambre(s) hors service` });
  const maint = await one<any>(
    db,
    `SELECT count(*)::int AS n, count(*) FILTER (WHERE m.priority = 'urgent')::int AS critical, count(*) FILTER (WHERE m.due_at < now())::int AS late,
        count(*) FILTER (WHERE m.status = 'waiting_parts')::int AS waiting_parts,
        (SELECT count(*) FROM work_orders w WHERE w.hotel_id = $1 AND w.status = 'done')::int AS to_validate,
        (SELECT count(*) FROM maintenance_plans p WHERE p.hotel_id = $1 AND p.active AND p.next_due < CURRENT_DATE)::int AS preventive_late,
        (SELECT count(*) FROM equipment e WHERE e.hotel_id = $1 AND e.active AND e.status IN ('broken','out_of_service'))::int AS broken
       FROM maintenance_tickets m WHERE m.hotel_id = $1 AND m.status IN ('new','assigned','in_progress','waiting_parts')`,
    [hotelId],
  );
  if (maint.critical) alerts.push({ level: 'danger', code: 'maintenance_critical', count: maint.critical, message: `${maint.critical} panne(s) critique(s) en cours` });
  if (maint.n) alerts.push({ level: 'info', code: 'maintenance_open', count: maint.n, message: `${maint.n} panne(s) de maintenance ouverte(s)${maint.late ? ` dont ${maint.late} en retard` : ''}` });
  if (maint.preventive_late) alerts.push({ level: 'warning', code: 'preventive_late', count: maint.preventive_late, message: `${maint.preventive_late} maintenance(s) préventive(s) en retard` });
  const hr = await one<any>(
    db,
    `SELECT (SELECT count(*) FROM employees WHERE hotel_id = $1 AND status <> 'left')::int AS staff,
        (SELECT count(*) FROM hr_attendance WHERE hotel_id = $1 AND work_date = $2 AND clock_in IS NOT NULL)::int AS present,
        (SELECT count(*) FROM hr_attendance WHERE hotel_id = $1 AND work_date = $2 AND late_minutes > 0)::int AS late,
        (SELECT count(*) FROM hr_schedule WHERE hotel_id = $1 AND work_date = $2 AND NOT rest)::int AS scheduled,
        (SELECT count(DISTINCT r.employee_id) FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id WHERE r.hotel_id = $1 AND r.status = 'approved' AND NOT t.hourly AND $2::date BETWEEN r.start_date AND r.end_date)::int AS on_leave,
        (SELECT count(*) FROM hr_leave_requests WHERE hotel_id = $1 AND status = 'pending')::int AS leave_pending,
        (SELECT count(*) FROM employees WHERE hotel_id = $1 AND status <> 'left' AND contract_end BETWEEN $2::date AND $2::date + 30)::int AS contracts,
        (SELECT count(*) FROM hr_schedule sh JOIN employees e2 ON e2.id = sh.employee_id WHERE sh.hotel_id = $1 AND sh.work_date = $2 AND NOT sh.rest AND e2.status = 'active'
          AND ((sh.work_date + sh.start_time) AT TIME ZONE '${config.timezone}') < now()
          AND NOT EXISTS (SELECT 1 FROM hr_attendance a WHERE a.employee_id = sh.employee_id AND a.work_date = sh.work_date AND a.clock_in IS NOT NULL)
          AND NOT EXISTS (SELECT 1 FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id WHERE r.employee_id = sh.employee_id AND r.status = 'approved' AND NOT t.hourly AND sh.work_date BETWEEN r.start_date AND r.end_date))::int AS absent`,
    [hotelId, d],
  );
  if (hr.contracts) alerts.push({ level: 'warning', code: 'hr_contracts', count: hr.contracts, message: `${hr.contracts} contrat(s) de travail à renouveler sous 30 jours` });
  if (hr.leave_pending) alerts.push({ level: 'info', code: 'hr_leave_pending', count: hr.leave_pending, message: `${hr.leave_pending} demande(s) de congé en attente` });
  const crm = await one<any>(
    db,
    `SELECT (SELECT count(*) FROM crm_complaints WHERE hotel_id = $1 AND status IN ('new','in_progress') AND kind = 'complaint')::int AS complaints,
        (SELECT count(*) FROM crm_complaints WHERE hotel_id = $1 AND status IN ('new','in_progress') AND due_at < now())::int AS complaints_late,
        (SELECT count(*) FROM stays s JOIN guests g ON g.id = s.guest_id WHERE g.hotel_id = $1 AND s.checked_out_at IS NULL AND g.crm_status = 'vip')::int AS vip_inhouse,
        (SELECT count(DISTINCT r.guest_id) FROM reservations r JOIN guests g ON g.id = r.guest_id WHERE r.hotel_id = $1 AND r.check_in = $2 AND r.status IN ('pending','confirmed') AND g.crm_status IN ('vip','loyal'))::int AS vip_arrivals,
        (SELECT round(avg(score), 2) FROM crm_survey_responses WHERE hotel_id = $1 AND completed_at > now() - interval '90 days') AS satisfaction,
        (SELECT count(*) FROM guests WHERE hotel_id = $1 AND kind = 'person' AND merged_into_id IS NULL AND anonymized_at IS NULL AND birth_date IS NOT NULL AND to_char(birth_date, 'MM-DD') = to_char($2::date, 'MM-DD'))::int AS birthdays_today`,
    [hotelId, d],
  );
  if (crm.complaints) alerts.push({ level: crm.complaints_late ? 'warning' : 'info', code: 'crm_complaints', count: crm.complaints, message: `${crm.complaints} réclamation(s) client en cours${crm.complaints_late ? ` dont ${crm.complaints_late} hors délai` : ''}` });
  if (crm.vip_arrivals) alerts.push({ level: 'info', code: 'crm_vip_arrivals', count: crm.vip_arrivals, message: `${crm.vip_arrivals} client(s) VIP / fidèle(s) arrive(nt) aujourd'hui` });
  const cash = await one<any>(
    db,
    `SELECT count(*)::int AS n FROM cash_sessions cs JOIN cash_registers cr ON cr.id = cs.cash_register_id WHERE cr.hotel_id = $1 AND cs.status = 'open'`,
    [hotelId],
  );
  if (!cash.n) alerts.push({ level: 'info', code: 'cash_closed', count: 1, message: 'Aucune caisse ouverte : les paiements ne sont rattachés à aucune session' });

  const arrivalsList = await q<any>(
    db,
    `SELECT rr.id AS rr_id, rr.reservation_id, rr.status, rm.number AS room, g.kind, g.last_name, g.first_name, g.company_name
       FROM reservation_rooms rr JOIN rooms rm ON rm.id = rr.room_id JOIN reservations r ON r.id = rr.reservation_id JOIN guests g ON g.id = r.guest_id
      WHERE r.hotel_id = $1 AND rr.check_in = $2 AND rr.moved_from_rr_id IS NULL AND rr.status IN ('pending','confirmed','checked_in') ORDER BY rr.status DESC, rm.number LIMIT 12`,
    [hotelId, d],
  );
  const departuresList = await q<any>(
    db,
    `SELECT rr.id AS rr_id, rr.reservation_id, rr.status, rm.number AS room, g.kind, g.last_name, g.first_name, g.company_name
       FROM reservation_rooms rr JOIN rooms rm ON rm.id = rr.room_id JOIN reservations r ON r.id = rr.reservation_id JOIN guests g ON g.id = r.guest_id
      WHERE r.hotel_id = $1 AND rr.status = 'checked_in' AND rr.check_out <= $2 ORDER BY rr.check_out, rm.number LIMIT 12`,
    [hotelId, d],
  );
  const mapMove = (x: any) => ({ rr_id: x.rr_id, reservation_id: x.reservation_id, status: x.status, room: x.room, guest: guestDisplayName(x) });

  return {
    date: d,
    currency: 'DA',
    rooms: { total: rooms.total, available, occupied: occ.occupied, reserved: reserved.n, cleaning: rooms.cleaning, out_of_service: rooms.oos, occupancy },
    movements: { ...moves, reservations_today: created.n },
    kpi,
    finance,
    restaurant: { ...rsLive, low_stock: lowStock.n },
    stock: { ...stk, low_stock: lowStock.n, stock_value: withFinance ? r2(Number(stk.stock_value)) : null },
    hr,
    crm: { ...crm, satisfaction: crm.satisfaction === null ? null : Number(crm.satisfaction) },
    maintenance: { open: maint.n, critical: maint.critical, late: maint.late, waiting_parts: maint.waiting_parts, to_validate: maint.to_validate, preventive_late: maint.preventive_late, broken: maint.broken },
    history: withFinance ? history : history.map((h) => ({ day: h.day, occupancy: h.occupancy, revenue: null })),
    forecast: forecast.map((f) => ({ day: f.day, occupancy: r2((f.rooms_sold / sellableN) * 100), rooms_sold: f.rooms_sold })),
    alerts,
    arrivals: arrivalsList.map(mapMove),
    departures: departuresList.map(mapMove),
    settings: { check_in_time: settings.check_in_time, check_out_time: settings.check_out_time },
  };
}
