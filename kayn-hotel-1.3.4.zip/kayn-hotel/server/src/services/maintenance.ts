/**
 * Maintenance : équipements, pannes (tickets), ordres de travail (temps, pièces, prestataires, checklist), techniciens,
 * maintenance préventive, blocage / réactivation des chambres, coûts, alertes, rapports.
 */
import type { PoolClient } from 'pg';
import { one, q, type Db } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { addDays, monthStart, today } from '../lib/dates.js';
import { AppError, badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { fromCents, toCents } from '../lib/money.js';
import { getSettings, nextNumber } from './common.js';
import { config } from '../config.js';

const TZ = config.timezone ?? 'Africa/Algiers';
export const OPEN_TICKET = ['new', 'assigned', 'in_progress', 'waiting_parts'];
export const OPEN_TICKET_SQL = `('new','assigned','in_progress','waiting_parts')`;
export const EQ_CATEGORY: Record<string, string> = {
  hvac: 'Climatisation', heating: 'Chauffage', plumbing: 'Plomberie', electrical: 'Électricité', elevator: 'Ascenseurs', kitchen: 'Équipements de cuisine',
  furniture: 'Mobilier', it: 'Informatique et réseau', fire_safety: 'Sécurité incendie', other: 'Autres équipements',
};
export const TICKET_STATUS: Record<string, string> = { new: 'Nouvelle', assigned: 'Affectée', in_progress: 'En cours', waiting_parts: 'En attente de pièces', resolved: 'Résolue', closed: 'Clôturée', cancelled: 'Annulée' };
export const WO_STATUS: Record<string, string> = { planned: 'Planifié', in_progress: 'En cours', on_hold: 'En attente', done: 'Terminé', validated: 'Validé', cancelled: 'Annulé' };
export const PRIO_LABEL: Record<string, string> = { low: 'Faible', normal: 'Moyenne', high: 'Haute', urgent: 'Critique' };
export const DEPT_LABEL: Record<string, string> = { rooms: 'Hébergement', restaurant: 'Restaurant', reception: 'Réception', housekeeping: 'Housekeeping', technical: 'Technique', leisure: 'Loisirs / piscine', admin: 'Administration', other: 'Autre' };
const yr = () => today().slice(0, 4);
const pad = (n: number) => String(n).padStart(4, '0');
const n2 = (v: any) => Math.round(Number(v ?? 0) * 100) / 100;

export async function maintSettings(db: Db, hotelId: number) {
  return (await getSettings(db, hotelId)).maintenance as { sla_hours: Record<string, number>; preventive_horizon_days: number; warranty_alert_days: number; expense_category: string; default_hourly_rate: number };
}
export function warrantyUntil(e: any): string | null {
  const start = e.install_date ?? e.purchase_date;
  if (!start || !e.warranty_months) return null;
  const d = new Date(`${String(start).slice(0, 10)}T00:00:00Z`);
  d.setUTCMonth(d.getUTCMonth() + Number(e.warranty_months));
  return d.toISOString().slice(0, 10);
}
const underWarranty = (e: any) => { const w = warrantyUntil(e); return !!w && w >= today(); };

/** Technicien associé à l'utilisateur connecté (pour « mes interventions »). */
export async function myTechnician(db: Db, actor: Actor) {
  return one<any>(db, 'SELECT * FROM maintenance_technicians WHERE user_id = $1 AND hotel_id = $2 AND active', [actor.userId, actor.hotelId]);
}
async function techOf(db: Db, hotelId: number, id: number) {
  const t = await one<any>(db, 'SELECT * FROM maintenance_technicians WHERE id = $1 AND hotel_id = $2', [id, hotelId]);
  if (!t || !t.active) throw badRequest('Technicien inconnu ou désactivé.');
  if (!t.available && (!t.unavailable_until || String(t.unavailable_until).slice(0, 10) >= today())) throw conflict(`${t.name} est indisponible${t.unavailable_reason ? ` (${t.unavailable_reason})` : ''}${t.unavailable_until ? ` jusqu'au ${String(t.unavailable_until).slice(0, 10)}` : ''}.`);
  return t;
}

/** État de l'équipement selon ses pannes ouvertes (jamais modifié s'il est retiré / mis hors service manuellement). */
async function refreshEquipment(db: PoolClient, actor: Actor, equipmentId: number | null) {
  if (!equipmentId) return;
  const e = await one<any>(db, 'SELECT * FROM equipment WHERE id = $1', [equipmentId]);
  if (!e || ['retired', 'out_of_service'].includes(e.status)) return;
  const open = await one<any>(db, `SELECT count(*) FILTER (WHERE priority IN ('high','urgent'))::int AS hi, count(*)::int AS n FROM maintenance_tickets WHERE equipment_id = $1 AND status IN ${OPEN_TICKET_SQL}`, [equipmentId]);
  const st = open.hi ? 'broken' : open.n ? 'degraded' : 'operational';
  if (st !== e.status) {
    await db.query('UPDATE equipment SET status = $2, updated_at = now() WHERE id = $1', [equipmentId, st]);
    await audit(db, actor, 'status', 'equipment', equipmentId, { status: e.status }, { status: st });
  }
}

// =====================================================================================================
// Pannes
// =====================================================================================================
export async function declareFault(db: PoolClient, actor: Actor, perms: Set<string>, b: {
  title: string; description?: string | null; category?: string | null; priority: 'low' | 'normal' | 'high' | 'urgent'; equipment_id?: number | null; room_id?: number | null; location?: string | null;
  source?: string; technician_id?: number | null; block_room?: { end_date?: string | null; reason?: string | null } | null;
}) {
  let roomId = b.room_id ?? null;
  let eq: any = null;
  if (b.equipment_id) {
    eq = await one<any>(db, 'SELECT * FROM equipment WHERE id = $1 AND hotel_id = $2', [b.equipment_id, actor.hotelId]);
    if (!eq) throw notFound('Équipement introuvable');
    if (eq.status === 'retired') throw conflict('Équipement retiré du parc.');
    roomId = roomId ?? eq.room_id;
  }
  if (roomId && !(await one(db, 'SELECT 1 FROM rooms WHERE id = $1 AND hotel_id = $2', [roomId, actor.hotelId]))) throw notFound('Chambre introuvable');
  if (!roomId && !eq && !b.location?.trim()) throw badRequest('Indiquez l\'équipement, la chambre ou le lieu.');
  if (b.block_room && !perms.has('maintenance.manage') && !perms.has('maintenance.supervise')) throw forbidden('Blocage de chambre : droit de mise hors service requis.');
  if (b.technician_id && !perms.has('maintenance.supervise')) throw forbidden('Affectation réservée au responsable maintenance.');
  const s = await maintSettings(db, actor.hotelId);
  const hours = s.sla_hours?.[b.priority] ?? 72;
  const t = await one<any>(db,
    `INSERT INTO maintenance_tickets (hotel_id, room_id, equipment_id, location, title, description, priority, category, reported_by, source, due_at, puts_out_of_service)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10, now() + make_interval(hours => $11), $12) RETURNING *`,
    [actor.hotelId, roomId, eq?.id ?? null, b.location?.trim() || null, b.title.trim(), b.description?.trim() || null, b.priority, b.category ?? eq?.category ?? 'other', actor.userId, b.source ?? 'manual', hours, !!b.block_room]);
  await audit(db, actor, 'declare', 'maintenance_ticket', t.id, null, { number: t.number, title: b.title, priority: b.priority, equipment_id: eq?.id ?? null, room_id: roomId });
  await refreshEquipment(db, actor, eq?.id ?? null);
  if (b.block_room) {
    if (!roomId) throw badRequest('Aucune chambre à bloquer.');
    const { createBlock } = await import('./rooms.js');
    await createBlock(db, actor, roomId, { start_date: today(), end_date: b.block_room.end_date ?? null, reason: b.block_room.reason?.trim() || `${t.number} — ${b.title.trim()}`, kind: 'out_of_service', ticket_id: t.id });
  }
  if (b.technician_id) {
    await assignTicket(db, actor, t.id, b.technician_id);
  }
  return one<any>(db, 'SELECT * FROM maintenance_tickets WHERE id = $1', [t.id]);
}

async function lockTicket(db: PoolClient, actor: Actor, id: number) {
  const t = await one<any>(db, 'SELECT * FROM maintenance_tickets WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!t) throw notFound('Panne introuvable');
  return t;
}

/** Affectation : la panne passe « Affectée » et un ordre de travail correctif est créé (ou réaffecté). */
export async function assignTicket(db: PoolClient, actor: Actor, id: number, technicianId: number, o: { scheduled_at?: string | null } = {}) {
  const t = await lockTicket(db, actor, id);
  if (!OPEN_TICKET.includes(t.status)) throw conflict(`Panne ${TICKET_STATUS[t.status].toLowerCase()} : affectation impossible.`);
  const tech = await techOf(db, actor.hotelId, technicianId);
  await db.query(`UPDATE maintenance_tickets SET technician_id = $2, assigned_at = now(), assigned_by = $3, status = CASE WHEN status = 'new' THEN 'assigned' ELSE status END, updated_at = now() WHERE id = $1`, [id, tech.id, actor.userId]);
  let wo = await one<any>(db, `SELECT * FROM work_orders WHERE ticket_id = $1 AND status IN ('planned','in_progress','on_hold') ORDER BY id DESC LIMIT 1`, [id]);
  if (wo) await db.query('UPDATE work_orders SET technician_id = $2, scheduled_at = COALESCE($3, scheduled_at) WHERE id = $1', [wo.id, tech.id, o.scheduled_at ?? null]);
  else wo = await createWorkOrder(db, actor, { ticket_id: id, technician_id: tech.id, scheduled_at: o.scheduled_at ?? null });
  await audit(db, actor, 'assign', 'maintenance_ticket', id, { technician_id: t.technician_id }, { technician_id: tech.id, technician: tech.name, work_order: wo.number });
  return wo;
}

export async function ticketStatus(db: PoolClient, actor: Actor, perms: Set<string>, id: number, b: { action: 'start' | 'waiting_parts' | 'close' | 'cancel' | 'reopen'; reason?: string | null }) {
  const t = await lockTicket(db, actor, id);
  const sup = perms.has('maintenance.supervise');
  if (b.action === 'start') {
    if (!['new', 'assigned', 'waiting_parts'].includes(t.status)) throw conflict('Panne déjà en cours ou clôturée.');
    await db.query(`UPDATE maintenance_tickets SET status = 'in_progress', started_at = COALESCE(started_at, now()), waiting_reason = NULL, updated_at = now() WHERE id = $1`, [id]);
  } else if (b.action === 'waiting_parts') {
    if (!OPEN_TICKET.includes(t.status)) throw conflict('Panne clôturée.');
    if (!b.reason?.trim()) throw badRequest('Indiquez les pièces attendues.');
    await db.query(`UPDATE maintenance_tickets SET status = 'waiting_parts', waiting_reason = $2, updated_at = now() WHERE id = $1`, [id, b.reason.trim()]);
  } else if (b.action === 'close') {
    if (!sup) throw forbidden('Clôture réservée au responsable maintenance.');
    if (!['resolved', ...OPEN_TICKET].includes(t.status)) throw conflict('Panne déjà clôturée.');
    if (t.status !== 'resolved' && !b.reason?.trim()) throw badRequest('Panne non résolue : motif de clôture obligatoire.');
    await closeTicket(db, actor, t, b.reason ?? null);
  } else if (b.action === 'cancel') {
    if (!sup) throw forbidden('Annulation réservée au responsable maintenance.');
    if (!OPEN_TICKET.includes(t.status)) throw conflict('Panne déjà clôturée.');
    if (!b.reason?.trim()) throw badRequest('Motif obligatoire.');
    await db.query(`UPDATE work_orders SET status = 'cancelled', cancel_reason = $2 WHERE ticket_id = $1 AND status IN ('planned','in_progress','on_hold')`, [id, `Panne annulée : ${b.reason.trim()}`]);
    await db.query(`UPDATE maintenance_tickets SET status = 'cancelled', resolution = $2, closed_at = now(), closed_by = $3, updated_at = now() WHERE id = $1`, [id, b.reason.trim(), actor.userId]);
    await releaseTicketBlocks(db, actor, id, `Panne annulée : ${b.reason.trim()}`);
    await refreshEquipment(db, actor, t.equipment_id);
  } else {
    if (!sup) throw forbidden('Réouverture réservée au responsable maintenance.');
    if (t.status !== 'resolved') throw conflict('Seule une panne résolue (non clôturée) peut être rouverte.');
    await db.query(`UPDATE maintenance_tickets SET status = CASE WHEN technician_id IS NULL THEN 'new' ELSE 'assigned' END, resolved_at = NULL, updated_at = now() WHERE id = $1`, [id]);
    await refreshEquipment(db, actor, t.equipment_id);
  }
  await audit(db, actor, `ticket_${b.action}`, 'maintenance_ticket', id, { status: t.status }, { reason: b.reason ?? null });
}

/** Clôture validée : chambre réactivée (seulement ce blocage — les autres restrictions restent), ménage demandé, équipement mis à jour. */
async function closeTicket(db: PoolClient, actor: Actor, t: any, note: string | null) {
  await db.query(`UPDATE maintenance_tickets SET status = 'closed', closed_at = now(), closed_by = $2, resolved_at = COALESCE(resolved_at, now()), resolved_by = COALESCE(resolved_by, $2),
      resolution = COALESCE(resolution, $3), updated_at = now() WHERE id = $1`, [t.id, actor.userId, note]);
  await releaseTicketBlocks(db, actor, t.id, note);
  await refreshEquipment(db, actor, t.equipment_id);
}
async function releaseTicketBlocks(db: PoolClient, actor: Actor, ticketId: number, note: string | null) {
  const { releaseBlock } = await import('./rooms.js');
  for (const bl of await q<any>(db, `SELECT id FROM room_blocks WHERE ticket_id = $1 AND status = 'active'`, [ticketId])) {
    await releaseBlock(db, actor, bl.id, { resolution: note });
  }
  // releaseBlock marque la panne « résolue » : la clôture validée l'emporte
  await db.query(`UPDATE maintenance_tickets SET status = 'closed' WHERE id = $1 AND status = 'resolved' AND closed_at IS NOT NULL`, [ticketId]);
}

// =====================================================================================================
// Ordres de travail
// =====================================================================================================
export async function createWorkOrder(db: PoolClient, actor: Actor, b: {
  ticket_id?: number | null; equipment_id?: number | null; room_id?: number | null; kind?: string; title?: string | null; description?: string | null; priority?: string;
  technician_id?: number | null; scheduled_at?: string | null; due_at?: string | null; checklist?: string[]; plan_id?: number | null; plan_due?: string | null;
}) {
  let tk: any = null;
  if (b.ticket_id) {
    tk = await one<any>(db, 'SELECT * FROM maintenance_tickets WHERE id = $1 AND hotel_id = $2', [b.ticket_id, actor.hotelId]);
    if (!tk) throw notFound('Panne introuvable');
    if (!OPEN_TICKET.includes(tk.status)) throw conflict('Panne clôturée.');
  }
  const eqId = b.equipment_id ?? tk?.equipment_id ?? null;
  if (eqId && !(await one(db, 'SELECT 1 FROM equipment WHERE id = $1 AND hotel_id = $2', [eqId, actor.hotelId]))) throw notFound('Équipement introuvable');
  const roomId = b.room_id ?? tk?.room_id ?? (eqId ? (await one<any>(db, 'SELECT room_id FROM equipment WHERE id = $1', [eqId]))?.room_id : null) ?? null;
  const title = b.title?.trim() || tk?.title;
  if (!title) throw badRequest('Intitulé obligatoire.');
  if (b.technician_id) await techOf(db, actor.hotelId, b.technician_id);
  const n = await nextNumber(db, `ot-${yr()}`);
  const wo = await one<any>(db,
    `INSERT INTO work_orders (hotel_id, number, kind, ticket_id, plan_id, plan_due, equipment_id, room_id, title, description, priority, technician_id, scheduled_at, due_at, checklist, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING *`,
    [actor.hotelId, `OT${yr()}-${pad(n)}`, b.kind ?? (tk ? 'corrective' : 'improvement'), tk?.id ?? null, b.plan_id ?? null, b.plan_due ?? null, eqId, roomId, title,
      b.description ?? tk?.description ?? null, b.priority ?? tk?.priority ?? 'normal', b.technician_id ?? tk?.technician_id ?? null, b.scheduled_at ?? null, b.due_at ?? tk?.due_at ?? null,
      JSON.stringify((b.checklist ?? []).filter((x) => x.trim()).map((label) => ({ label: label.trim(), done: false }))), actor.userId]);
  if (tk && b.technician_id && tk.status === 'new') await db.query(`UPDATE maintenance_tickets SET status = 'assigned', technician_id = $2, assigned_at = now(), assigned_by = $3 WHERE id = $1`, [tk.id, b.technician_id, actor.userId]);
  await audit(db, actor, 'create', 'work_order', wo.id, null, { number: wo.number, ticket_id: tk?.id ?? null, kind: wo.kind });
  return wo;
}

async function lockWo(db: PoolClient, actor: Actor, id: number) {
  const wo = await one<any>(db, 'SELECT * FROM work_orders WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!wo) throw notFound('Ordre de travail introuvable');
  return wo;
}
/** Le technicien n'agit que sur ses ordres de travail ; le responsable sur tous. */
async function canWork(db: Db, actor: Actor, perms: Set<string>, wo: any) {
  if (perms.has('maintenance.supervise')) return;
  if (!perms.has('maintenance.work')) throw forbidden();
  const me = await myTechnician(db, actor);
  if (!me || (wo.technician_id && wo.technician_id !== me.id)) throw forbidden('Ordre de travail affecté à un autre technicien.');
}
const workable = (wo: any) => { if (!['planned', 'in_progress', 'on_hold'].includes(wo.status)) throw conflict(`Ordre de travail ${WO_STATUS[wo.status].toLowerCase()} : modification impossible.`); };

async function recalcWo(db: PoolClient, id: number) {
  const r = await one<any>(db, `SELECT COALESCE((SELECT sum(minutes) FROM wo_time_logs WHERE wo_id = $1), 0)::int AS minutes, COALESCE((SELECT sum(cost) FROM wo_time_logs WHERE wo_id = $1), 0) AS labor,
      COALESCE((SELECT sum(cost) FROM wo_parts WHERE wo_id = $1), 0) AS parts, COALESCE((SELECT sum(amount) FROM wo_external_costs WHERE wo_id = $1), 0) AS ext`, [id]);
  const total = fromCents(toCents(r.labor) + toCents(r.parts) + toCents(r.ext));
  await db.query('UPDATE work_orders SET labor_minutes = $2, labor_cost = $3, parts_cost = $4, external_cost = $5, total_cost = $6 WHERE id = $1', [id, r.minutes, n2(r.labor), n2(r.parts), n2(r.ext), total]);
}

export async function updateWorkOrder(db: PoolClient, actor: Actor, id: number, b: { technician_id?: number | null; scheduled_at?: string | null; due_at?: string | null; description?: string | null; priority?: string; checklist?: string[]; title?: string }) {
  const wo = await lockWo(db, actor, id);
  workable(wo);
  if (b.technician_id) await techOf(db, actor.hotelId, b.technician_id);
  let checklist = wo.checklist;
  if (b.checklist) checklist = b.checklist.filter((x) => x.trim()).map((label) => ({ label: label.trim(), done: !!(wo.checklist as any[]).find((c) => c.label === label.trim() && c.done) }));
  await db.query(`UPDATE work_orders SET technician_id = CASE WHEN $2::boolean THEN $3 ELSE technician_id END, scheduled_at = CASE WHEN $4::boolean THEN $5::timestamptz ELSE scheduled_at END,
      due_at = CASE WHEN $6::boolean THEN $7::timestamptz ELSE due_at END, description = COALESCE($8, description), priority = COALESCE($9, priority), checklist = $10, title = COALESCE($11, title) WHERE id = $1`,
    [id, b.technician_id !== undefined, b.technician_id ?? null, b.scheduled_at !== undefined, b.scheduled_at ?? null, b.due_at !== undefined, b.due_at ?? null, b.description ?? null, b.priority ?? null, JSON.stringify(checklist), b.title ?? null]);
  if (b.technician_id && wo.ticket_id) await db.query(`UPDATE maintenance_tickets SET technician_id = $2, status = CASE WHEN status = 'new' THEN 'assigned' ELSE status END, assigned_at = now(), assigned_by = $3 WHERE id = $1`, [wo.ticket_id, b.technician_id, actor.userId]);
  await audit(db, actor, 'update', 'work_order', id, { technician_id: wo.technician_id, scheduled_at: wo.scheduled_at }, b);
}

export async function woAction(db: PoolClient, actor: Actor, perms: Set<string>, id: number, b: { action: 'start' | 'hold' | 'resume'; reason?: string | null; parts?: boolean }) {
  const wo = await lockWo(db, actor, id);
  await canWork(db, actor, perms, wo);
  workable(wo);
  if (b.action === 'start' || b.action === 'resume') {
    if (wo.status === 'in_progress') throw conflict('Intervention déjà en cours.');
    let tech = wo.technician_id;
    if (!tech) tech = (await myTechnician(db, actor))?.id ?? null;
    await db.query(`UPDATE work_orders SET status = 'in_progress', started_at = COALESCE(started_at, now()), technician_id = COALESCE(technician_id, $2) WHERE id = $1`, [id, tech]);
    if (wo.ticket_id) await db.query(`UPDATE maintenance_tickets SET status = 'in_progress', started_at = COALESCE(started_at, now()), waiting_reason = NULL, updated_at = now() WHERE id = $1 AND status IN ('new','assigned','waiting_parts')`, [wo.ticket_id]);
  } else {
    if (!b.reason?.trim()) throw badRequest('Motif de mise en attente obligatoire.');
    await db.query(`UPDATE work_orders SET status = 'on_hold' WHERE id = $1`, [id]);
    if (wo.ticket_id && b.parts) await db.query(`UPDATE maintenance_tickets SET status = 'waiting_parts', waiting_reason = $2, updated_at = now() WHERE id = $1 AND status IN ${OPEN_TICKET_SQL}`, [wo.ticket_id, b.reason.trim()]);
    await db.query('INSERT INTO wo_comments (wo_id, text, created_by) VALUES ($1,$2,$3)', [id, `En attente : ${b.reason.trim()}`, actor.userId]);
  }
  await audit(db, actor, `wo_${b.action}`, 'work_order', id, { status: wo.status }, { reason: b.reason ?? null });
}

export async function toggleChecklist(db: PoolClient, actor: Actor, perms: Set<string>, id: number, index: number, done: boolean) {
  const wo = await lockWo(db, actor, id);
  await canWork(db, actor, perms, wo);
  workable(wo);
  const list = wo.checklist as any[];
  if (!list[index]) throw badRequest('Point de checklist inconnu.');
  list[index] = { ...list[index], done, by: done ? actor.userId : null, at: done ? new Date().toISOString() : null };
  await db.query('UPDATE work_orders SET checklist = $2 WHERE id = $1', [id, JSON.stringify(list)]);
}

export async function addTime(db: PoolClient, actor: Actor, perms: Set<string>, id: number, b: { minutes: number; work_date?: string | null; note?: string | null; technician_id?: number | null }) {
  const wo = await lockWo(db, actor, id);
  await canWork(db, actor, perms, wo);
  workable(wo);
  if (!(b.minutes > 0 && b.minutes <= 1440)) throw badRequest('Durée invalide (1 à 1440 minutes).');
  const d = b.work_date ?? today();
  if (d > today()) throw badRequest('Date future.');
  const techId = (perms.has('maintenance.supervise') ? b.technician_id : null) ?? wo.technician_id ?? (await myTechnician(db, actor))?.id;
  if (!techId) throw badRequest('Affectez un technicien avant de saisir du temps.');
  const tech = await one<any>(db, 'SELECT * FROM maintenance_technicians WHERE id = $1 AND hotel_id = $2', [techId, actor.hotelId]);
  if (!tech) throw badRequest('Technicien inconnu.');
  const s = await maintSettings(db, actor.hotelId);
  const rate = Number(tech.hourly_rate) || Number(s.default_hourly_rate) || 0;
  const cost = fromCents(Math.round((toCents(rate) * b.minutes) / 60));
  const r = await one<any>(db, `INSERT INTO wo_time_logs (wo_id, technician_id, work_date, minutes, hourly_rate, cost, note, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [id, tech.id, d, b.minutes, rate, cost, b.note ?? null, actor.userId]);
  await recalcWo(db, id);
  await audit(db, actor, 'time', 'work_order', id, null, { minutes: b.minutes, technician: tech.name, cost });
  return r;
}

/** Pièce utilisée : sortie du stock (département maintenance, rattachée à l'OT). Pièce manquante : demande d'achat possible. */
export async function addPart(db: PoolClient, actor: Actor, perms: Set<string>, id: number, b: { product_id: number; quantity: number; warehouse_id?: number | null; request_purchase?: boolean }) {
  const wo = await lockWo(db, actor, id);
  await canWork(db, actor, perms, wo);
  workable(wo);
  if (!(b.quantity > 0)) throw badRequest('Quantité invalide.');
  const { moveStock } = await import('./stock.js');
  try {
    const mv = await moveStock(db, actor, { product_id: b.product_id, warehouse_id: b.warehouse_id, kind: 'issue', quantity: -b.quantity, department: 'maintenance', reason: `${wo.number} — ${wo.title}`, ref_type: 'work_order', ref_id: id });
    const unit = Number(mv.movement.unit_cost);
    const part = await one<any>(db, `INSERT INTO wo_parts (wo_id, product_id, warehouse_id, quantity, unit_cost, cost, movement_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [id, b.product_id, mv.warehouse.id, b.quantity, unit, n2(-Number(mv.movement.value)), mv.movement.id, actor.userId]);
    await recalcWo(db, id);
    await audit(db, actor, 'part', 'work_order', id, null, { product: mv.product.name, quantity: b.quantity, cost: part.cost });
    return { part, alert: mv.alert };
  } catch (e: any) {
    if (e?.code !== 'insufficient_stock') throw e;
    const p = await one<any>(db, 'SELECT * FROM products WHERE id = $1', [b.product_id]);
    const available = Math.max(0, Number(e.details?.available ?? 0));
    if (!b.request_purchase) throw new AppError(409, 'missing_part', `Pièce indisponible : « ${p.name} » — ${available} ${p.unit} en stock, ${b.quantity} nécessaire(s). Une demande d'achat peut être créée.`, { available, product: p.name });
    if (!perms.has('purchase.request')) throw forbidden('Demande d\'achat : droit « purchase.request » requis.');
    const { createRequest } = await import('./purchase.js');
    const pr = await createRequest(db, actor, { department: 'maintenance', reason: `${wo.number} : pièce manquante (${p.name})`, lines: [{ product_id: p.id, quantity: Math.max(b.quantity - available, 1) }], submit: true });
    await db.query(`UPDATE work_orders SET status = 'on_hold' WHERE id = $1`, [id]);
    if (wo.ticket_id) await db.query(`UPDATE maintenance_tickets SET status = 'waiting_parts', waiting_reason = $2, updated_at = now() WHERE id = $1 AND status IN ${OPEN_TICKET_SQL}`, [wo.ticket_id, `${p.name} × ${b.quantity} (demande ${pr.number})`]);
    await db.query('INSERT INTO wo_comments (wo_id, text, created_by) VALUES ($1,$2,$3)', [id, `Pièce manquante : ${p.name} × ${b.quantity} — demande d'achat ${pr.number}`, actor.userId]);
    await audit(db, actor, 'missing_part', 'work_order', id, null, { product: p.name, quantity: b.quantity, purchase: pr.number });
    return { purchase: { id: pr.id, number: pr.number } };
  }
}

/** Prestataire externe : payé (dépense Facturation & Caisse) ou à payer (facture fournisseur). */
export async function addExternal(db: PoolClient, actor: Actor, perms: Set<string>, id: number, b: {
  description: string; amount: number; supplier_id?: number | null; mode: 'paid' | 'invoice'; method?: 'cash' | 'card' | 'cheque' | 'transfer'; reference?: string | null; invoice_number?: string | null; tax_total?: number | null;
}) {
  const wo = await lockWo(db, actor, id);
  if (!perms.has('maintenance.supervise')) throw forbidden('Coûts externes réservés au responsable maintenance.');
  if (!['planned', 'in_progress', 'on_hold', 'done'].includes(wo.status)) throw conflict('Ordre de travail clôturé.');
  if (!b.description?.trim()) throw badRequest('Description obligatoire.');
  if (!(b.amount > 0)) throw badRequest('Montant invalide.');
  const s = await maintSettings(db, actor.hotelId);
  let expenseId: number | null = null, invoiceId: number | null = null;
  if (b.mode === 'paid') {
    const { addExpense } = await import('./cash.js');
    expenseId = (await addExpense(db, actor, { category: s.expense_category, description: `${wo.number} — ${b.description.trim()}`, amount: b.amount, method: b.method ?? 'cash', supplier_id: b.supplier_id ?? null, reference: b.reference ?? wo.number })).id;
  } else {
    if (!b.supplier_id || !b.invoice_number?.trim()) throw badRequest('Fournisseur et n° de facture obligatoires.');
    const { createInvoice } = await import('./purchase.js');
    const tax = b.tax_total ?? 0;
    invoiceId = (await createInvoice(db, actor, { supplier_id: b.supplier_id, number: b.invoice_number.trim(), invoice_date: today(), subtotal: fromCents(toCents(b.amount) - toCents(tax)), tax_total: tax, category: s.expense_category, notes: `${wo.number} — ${b.description.trim()}` })).id;
  }
  const r = await one<any>(db, `INSERT INTO wo_external_costs (wo_id, supplier_id, description, amount, expense_id, invoice_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [id, b.supplier_id ?? null, b.description.trim(), b.amount, expenseId, invoiceId, actor.userId]);
  await recalcWo(db, id);
  await audit(db, actor, 'external', 'work_order', id, null, { amount: b.amount, mode: b.mode, expense_id: expenseId, invoice_id: invoiceId });
  return r;
}

export async function woComment(db: PoolClient, actor: Actor, perms: Set<string>, id: number, text: string) {
  const wo = await lockWo(db, actor, id);
  await canWork(db, actor, perms, wo);
  if (!text?.trim()) throw badRequest('Commentaire vide.');
  return one<any>(db, 'INSERT INTO wo_comments (wo_id, text, created_by) VALUES ($1,$2,$3) RETURNING *', [id, text.trim(), actor.userId]);
}

/** Fin des travaux par le technicien (résultat obligatoire, checklist complète si réparé). */
export async function completeWorkOrder(db: PoolClient, actor: Actor, perms: Set<string>, id: number, b: { result: string; outcome: 'fixed' | 'partial' | 'not_fixed' | 'no_issue' }) {
  const wo = await lockWo(db, actor, id);
  await canWork(db, actor, perms, wo);
  if (wo.status !== 'in_progress') throw conflict('Démarrez l\'intervention avant de la terminer.');
  if (!b.result?.trim()) throw badRequest('Décrivez le résultat de l\'intervention.');
  if (!wo.labor_minutes) throw badRequest('Enregistrez le temps passé avant de terminer.');
  const undone = (wo.checklist as any[]).filter((c) => !c.done);
  if (b.outcome === 'fixed' && undone.length) throw conflict(`Checklist incomplète : ${undone.map((c) => c.label).join(', ')}`);
  await db.query(`UPDATE work_orders SET status = 'done', completed_at = now(), result = $2, outcome = $3 WHERE id = $1`, [id, b.result.trim(), b.outcome]);
  if (wo.ticket_id && ['fixed', 'no_issue'].includes(b.outcome)) {
    await db.query(`UPDATE maintenance_tickets SET status = 'resolved', resolved_at = now(), resolved_by = $2, resolution = $3, updated_at = now() WHERE id = $1 AND status IN ${OPEN_TICKET_SQL}`, [wo.ticket_id, actor.userId, b.result.trim()]);
  }
  await audit(db, actor, 'complete', 'work_order', id, { status: wo.status }, { status: 'done', outcome: b.outcome });
}

/** Validation par le responsable : évaluation, clôture de la panne, réactivation de la chambre, plan préventif avancé. */
export async function validateWorkOrder(db: PoolClient, actor: Actor, id: number, b: { rating?: number | null; comment?: string | null; close_ticket?: boolean }) {
  const wo = await lockWo(db, actor, id);
  if (wo.status !== 'done') throw conflict('Seule une intervention terminée peut être validée.');
  await db.query(`UPDATE work_orders SET status = 'validated', validated_by = $2, validated_at = now(), rating = $3, rating_comment = $4 WHERE id = $1`, [id, actor.userId, b.rating ?? null, b.comment ?? null]);
  if (wo.ticket_id) {
    const t = await lockTicket(db, actor, wo.ticket_id);
    if (['fixed', 'no_issue'].includes(wo.outcome) && b.close_ticket !== false && ['resolved', ...OPEN_TICKET].includes(t.status)) await closeTicket(db, actor, t, wo.result);
    else if (!['fixed', 'no_issue'].includes(wo.outcome)) await db.query(`UPDATE maintenance_tickets SET status = 'assigned', updated_at = now() WHERE id = $1 AND status IN ${OPEN_TICKET_SQL}`, [t.id]);
  }
  if (wo.plan_id) {
    const p = await one<any>(db, 'SELECT * FROM maintenance_plans WHERE id = $1 FOR UPDATE', [wo.plan_id]);
    const done = new Date(wo.completed_at ?? Date.now()).toLocaleDateString('sv-SE', { timeZone: TZ });
    let next = advance(String(wo.plan_due ?? p.next_due).slice(0, 10), p.frequency, p.interval_count);
    while (next <= done) next = advance(next, p.frequency, p.interval_count);
    if (next < String(p.next_due).slice(0, 10)) next = String(p.next_due).slice(0, 10);
    await db.query('UPDATE maintenance_plans SET last_done = $2, next_due = $3 WHERE id = $1', [p.id, done, next]);
  }
  if (wo.equipment_id) await refreshEquipment(db, actor, wo.equipment_id);
  await audit(db, actor, 'validate', 'work_order', id, { status: 'done' }, { status: 'validated', rating: b.rating ?? null });
}

export async function cancelWorkOrder(db: PoolClient, actor: Actor, id: number, reason: string) {
  const wo = await lockWo(db, actor, id);
  if (['validated', 'cancelled'].includes(wo.status)) throw conflict('Ordre de travail déjà clôturé.');
  if (!reason?.trim()) throw badRequest('Motif obligatoire.');
  if (Number(wo.parts_cost) > 0 || Number(wo.external_cost) > 0) throw conflict('Des pièces ou des coûts sont déjà enregistrés : terminez et validez l\'intervention.');
  await db.query(`UPDATE work_orders SET status = 'cancelled', cancel_reason = $2 WHERE id = $1`, [id, reason.trim()]);
  await audit(db, actor, 'cancel', 'work_order', id, { status: wo.status }, { reason });
}

// =====================================================================================================
// Maintenance préventive
// =====================================================================================================
export function advance(d: string, f: string, n: number) {
  const x = new Date(`${d}T00:00:00Z`);
  if (f === 'daily') x.setUTCDate(x.getUTCDate() + n);
  else if (f === 'weekly') x.setUTCDate(x.getUTCDate() + 7 * n);
  else if (f === 'monthly') x.setUTCMonth(x.getUTCMonth() + n);
  else if (f === 'quarterly') x.setUTCMonth(x.getUTCMonth() + 3 * n);
  else x.setUTCFullYear(x.getUTCFullYear() + n);
  return x.toISOString().slice(0, 10);
}

/** Génère les ordres de travail préventifs arrivant à échéance (dans le délai d'alerte du plan). Idempotent. */
export async function generatePreventive(db: PoolClient, actor: Actor) {
  const t = today();
  const plans = await q<any>(db, `SELECT * FROM maintenance_plans WHERE hotel_id = $1 AND active AND next_due <= ($2::date + alert_days) ORDER BY next_due FOR UPDATE`, [actor.hotelId, t]);
  let created = 0;
  for (const p of plans) {
    const due = String(p.next_due).slice(0, 10);
    if (await one(db, `SELECT 1 FROM work_orders WHERE plan_id = $1 AND plan_due = $2 AND status <> 'cancelled'`, [p.id, due])) continue;
    let tech: number | null = p.technician_id;
    if (tech) { const x = await one<any>(db, 'SELECT active, available FROM maintenance_technicians WHERE id = $1', [tech]); if (!x?.active || !x.available) tech = null; }
    await createWorkOrder(db, actor, { kind: 'preventive', plan_id: p.id, plan_due: due, equipment_id: p.equipment_id, title: `Préventif : ${p.name}`, description: p.instructions,
      technician_id: tech, scheduled_at: `${due}T08:00:00`, due_at: `${due}T23:59:00`, checklist: (p.checklist as any[]).map((c) => (typeof c === 'string' ? c : c.label)) });
    created++;
  }
  if (created) await audit(db, actor, 'generate_preventive', 'maintenance', null, null, { created });
  return { created };
}

// =====================================================================================================
// Tableau de bord, alertes, rapports
// =====================================================================================================
export async function maintAlerts(db: Db, hotelId: number) {
  const s = await maintSettings(db, hotelId);
  const t = today();
  const out: { level: 'danger' | 'warning' | 'info'; code: string; message: string; ref?: any }[] = [];
  const tickets = await q<any>(db, `SELECT m.*, r.number AS room, e.name AS equipment, e.supplier_id, e.install_date, e.purchase_date, e.warranty_months, sp.name AS supplier
      FROM maintenance_tickets m LEFT JOIN rooms r ON r.id = m.room_id LEFT JOIN equipment e ON e.id = m.equipment_id LEFT JOIN suppliers sp ON sp.id = e.supplier_id
     WHERE m.hotel_id = $1 AND m.status IN ${OPEN_TICKET_SQL} ORDER BY array_position(ARRAY['urgent','high','normal','low'], m.priority), m.created_at`, [hotelId]);
  const where = (x: any) => [x.equipment, x.room ? `ch. ${x.room}` : null, x.location].filter(Boolean).join(' · ');
  for (const x of tickets) {
    if (x.priority === 'urgent') out.push({ level: 'danger', code: 'critical', message: `Panne critique ${x.number} : ${x.title} (${where(x)})`, ref: { ticket_id: x.id } });
    else if (x.status === 'new') out.push({ level: 'info', code: 'new_fault', message: `Nouvelle panne ${x.number} : ${x.title} (${where(x)})`, ref: { ticket_id: x.id } });
    if (x.due_at && new Date(x.due_at) < new Date()) out.push({ level: 'warning', code: 'late', message: `Intervention en retard ${x.number} : ${x.title} (échéance dépassée)`, ref: { ticket_id: x.id } });
    if (x.status === 'waiting_parts') out.push({ level: 'warning', code: 'missing_part', message: `Pièce indisponible ${x.number} : ${x.waiting_reason ?? x.title}`, ref: { ticket_id: x.id } });
    if (x.equipment && underWarranty(x)) out.push({ level: 'info', code: 'warranty', message: `${x.equipment} sous garantie jusqu'au ${warrantyUntil(x)} : faire intervenir ${x.supplier ?? 'le fournisseur'} (${x.number})`, ref: { ticket_id: x.id } });
  }
  for (const p of await q<any>(db, `SELECT p.*, e.name AS equipment FROM maintenance_plans p LEFT JOIN equipment e ON e.id = p.equipment_id WHERE p.hotel_id = $1 AND p.active AND p.next_due <= ($2::date + p.alert_days)
      AND NOT EXISTS (SELECT 1 FROM work_orders w WHERE w.plan_id = p.id AND w.plan_due = p.next_due AND w.status = 'validated') ORDER BY p.next_due`, [hotelId, t])) {
    const d = String(p.next_due).slice(0, 10);
    out.push({ level: d < t ? 'warning' : 'info', code: 'preventive', message: `${d < t ? 'Préventif en retard' : 'Préventif à effectuer'} : ${p.name}${p.equipment ? ` (${p.equipment})` : ''} — ${d}`, ref: { plan_id: p.id } });
  }
  for (const w of await q<any>(db, `SELECT id, number, title FROM work_orders WHERE hotel_id = $1 AND status IN ('planned','in_progress','on_hold') AND due_at < now() AND kind <> 'preventive' AND ticket_id IS NULL`, [hotelId])) {
    out.push({ level: 'warning', code: 'late', message: `Ordre de travail en retard ${w.number} : ${w.title}`, ref: { wo_id: w.id } });
  }
  for (const e of await q<any>(db, `SELECT * FROM equipment WHERE hotel_id = $1 AND active AND warranty_months > 0`, [hotelId])) {
    const w = warrantyUntil(e);
    if (w && w >= t && w <= addDays(t, s.warranty_alert_days)) out.push({ level: 'info', code: 'warranty_end', message: `Fin de garantie le ${w} : ${e.name} (${e.code})`, ref: { equipment_id: e.id } });
  }
  for (const b of await q<any>(db, `SELECT b.*, r.number FROM room_blocks b JOIN rooms r ON r.id = b.room_id WHERE r.hotel_id = $1 AND b.status = 'active' AND b.kind = 'out_of_service' AND b.start_date <= $2 AND (b.end_date IS NULL OR b.end_date > $2) ORDER BY r.number`, [hotelId, t])) {
    out.push({ level: 'warning', code: 'room_blocked', message: `Chambre ${b.number} bloquée pour maintenance : ${b.reason}${b.end_date ? ` (jusqu'au ${String(b.end_date).slice(0, 10)})` : ''}`, ref: { room_id: b.room_id } });
  }
  return out;
}

export async function maintDashboard(db: Db, hotelId: number) {
  const t = today(), ms = monthStart(t);
  const eq = await one<any>(db, `SELECT count(*)::int AS total, count(*) FILTER (WHERE status = 'operational')::int AS operational, count(*) FILTER (WHERE status IN ('broken','out_of_service'))::int AS broken,
      count(*) FILTER (WHERE status = 'degraded')::int AS degraded FROM equipment WHERE hotel_id = $1 AND active AND status <> 'retired'`, [hotelId]);
  const tk = await one<any>(db, `SELECT count(*) FILTER (WHERE status IN ('new','assigned'))::int AS pending, count(*) FILTER (WHERE status IN ('in_progress','waiting_parts'))::int AS in_progress,
      count(*) FILTER (WHERE status IN ('resolved','closed') AND (COALESCE(closed_at, resolved_at) AT TIME ZONE '${TZ}')::date >= $2)::int AS done_month,
      count(*) FILTER (WHERE status IN ${OPEN_TICKET_SQL} AND priority = 'urgent')::int AS critical, count(*) FILTER (WHERE status IN ${OPEN_TICKET_SQL} AND due_at < now())::int AS late
     FROM maintenance_tickets WHERE hotel_id = $1`, [hotelId, ms]);
  const wo = await one<any>(db, `SELECT count(*) FILTER (WHERE status = 'planned')::int AS planned, count(*) FILTER (WHERE status IN ('in_progress','on_hold'))::int AS in_progress,
      count(*) FILTER (WHERE status = 'done')::int AS to_validate, count(*) FILTER (WHERE status = 'validated' AND (validated_at AT TIME ZONE '${TZ}')::date >= $2)::int AS validated_month
     FROM work_orders WHERE hotel_id = $1`, [hotelId, ms]);
  const pv = await one<any>(db, `SELECT count(*) FILTER (WHERE next_due BETWEEN $2 AND $2::date + 7)::int AS upcoming, count(*) FILTER (WHERE next_due < $2)::int AS late FROM maintenance_plans WHERE hotel_id = $1 AND active`, [hotelId, t]);
  const cost = await one<any>(db, `SELECT COALESCE(sum(labor_cost),0) AS labor, COALESCE(sum(parts_cost),0) AS parts, COALESCE(sum(external_cost),0) AS external, COALESCE(sum(total_cost),0) AS total
     FROM work_orders WHERE hotel_id = $1 AND status <> 'cancelled' AND (created_at AT TIME ZONE '${TZ}')::date >= $2`, [hotelId, ms]);
  const costYear = await one<any>(db, `SELECT COALESCE(sum(total_cost),0) AS total FROM work_orders WHERE hotel_id = $1 AND status <> 'cancelled' AND (created_at AT TIME ZONE '${TZ}')::date >= $2`, [hotelId, `${t.slice(0, 4)}-01-01`]);
  const rooms = await q<any>(db, `SELECT b.id, b.room_id, r.number, b.reason, b.start_date, b.end_date, b.ticket_id, m.number AS ticket FROM room_blocks b JOIN rooms r ON r.id = b.room_id LEFT JOIN maintenance_tickets m ON m.id = b.ticket_id
      WHERE r.hotel_id = $1 AND b.status = 'active' AND b.kind = 'out_of_service' AND (b.end_date IS NULL OR b.end_date > $2) ORDER BY b.start_date`, [hotelId, t]);
  const alerts = await maintAlerts(db, hotelId);
  return {
    kpi: { equipment: eq, tickets: tk, work_orders: wo, preventive: pv, cost_month: { labor: n2(cost.labor), parts: n2(cost.parts), external: n2(cost.external), total: n2(cost.total) }, cost_year: n2(costYear.total), rooms_blocked: rooms.length },
    rooms, alerts, urgent: alerts.filter((a) => a.level === 'danger'),
  };
}

const c = (key: string, label: string, money = false) => ({ key, label, money });
export const MAINT_REPORTS: Record<string, { title: string; columns: any[] }> = {
  faults: { title: 'Pannes par période', columns: [c('number', 'N°'), c('date', 'Déclarée le'), c('where', 'Équipement / lieu'), c('category', 'Catégorie'), c('priority', 'Priorité'), c('status', 'Statut'), c('reporter', 'Déclarant'), c('technician', 'Technicien'), c('hours', 'Résolution (h)')] },
  technicians: { title: 'Interventions par technicien', columns: [c('technician', 'Technicien'), c('orders', 'Interventions'), c('validated', 'Validées'), c('hours', 'Heures'), c('labor', 'Main-d\'œuvre', true), c('rating', 'Note moyenne /5'), c('late', 'En retard')] },
  resolution: { title: 'Temps moyen de résolution', columns: [c('group', 'Priorité / catégorie'), c('count', 'Pannes résolues'), c('avg_h', 'Moyenne (h)'), c('max_h', 'Maximum (h)'), c('sla', 'Dans le délai (%)')] },
  equipment: { title: 'Équipements les plus souvent en panne', columns: [c('code', 'Réf.'), c('name', 'Équipement'), c('category', 'Catégorie'), c('faults', 'Pannes'), c('cost', 'Coût', true), c('status', 'État')] },
  costs: { title: 'Coût de maintenance par période', columns: [c('month', 'Mois'), c('orders', 'Interventions'), c('labor', 'Main-d\'œuvre', true), c('parts', 'Pièces', true), c('external', 'Prestataires', true), c('total', 'Total', true)] },
  departments: { title: 'Coût par département et par équipement', columns: [c('department', 'Département'), c('equipment', 'Équipement / chambre'), c('orders', 'Interventions'), c('total', 'Coût', true)] },
  preventive: { title: 'Maintenances préventives réalisées et en retard', columns: [c('plan', 'Plan'), c('equipment', 'Équipement'), c('due', 'Échéance'), c('done', 'Réalisée le'), c('technician', 'Technicien'), c('state', 'État')] },
  rooms: { title: 'Chambres indisponibles', columns: [c('room', 'Chambre'), c('reason', 'Motif'), c('start', 'Début'), c('end', 'Fin'), c('days', 'Jours'), c('ticket', 'Panne'), c('state', 'État')] },
  history: { title: 'Historique complet des équipements', columns: [c('code', 'Réf.'), c('equipment', 'Équipement'), c('date', 'Date'), c('type', 'Type'), c('ref', 'N°'), c('detail', 'Détail'), c('technician', 'Technicien'), c('cost', 'Coût', true)] },
};
const fdt = (d: any) => (d ? new Date(d).toLocaleString('fr-FR', { timeZone: TZ, day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }) : '');

export async function maintReport(db: Db, hotelId: number, kind: string, from: string, to: string, opts: { equipment_id?: number | null } = {}) {
  const def = MAINT_REPORTS[kind];
  if (!def) throw notFound('Rapport inconnu');
  const P = [hotelId, from, to];
  const dc = (col: string) => `(${col} AT TIME ZONE '${TZ}')::date`;
  let rows: any[] = [];
  let total: any = null;
  if (kind === 'faults') {
    rows = (await q<any>(db, `SELECT m.*, e.name AS equipment, r.number AS room, u.full_name AS reporter, t.name AS technician FROM maintenance_tickets m LEFT JOIN equipment e ON e.id = m.equipment_id
        LEFT JOIN rooms r ON r.id = m.room_id LEFT JOIN users u ON u.id = m.reported_by LEFT JOIN maintenance_technicians t ON t.id = m.technician_id
       WHERE m.hotel_id = $1 AND ${dc('m.created_at')} BETWEEN $2 AND $3 ORDER BY m.created_at`, P)).map((m) => ({
      number: m.number, date: fdt(m.created_at), where: [m.equipment, m.room ? `Ch. ${m.room}` : null, m.location].filter(Boolean).join(' · '), category: EQ_CATEGORY[m.category] ?? m.category,
      priority: PRIO_LABEL[m.priority], status: TICKET_STATUS[m.status], reporter: m.reporter ?? '', technician: m.technician ?? '',
      hours: m.resolved_at ? Math.round(((new Date(m.resolved_at).getTime() - new Date(m.created_at).getTime()) / 3600000) * 10) / 10 : '' }));
  } else if (kind === 'technicians') {
    rows = (await q<any>(db, `SELECT t.name AS technician, count(w.id)::int AS orders, count(w.id) FILTER (WHERE w.status = 'validated')::int AS validated, COALESCE(sum(w.labor_minutes), 0)::int AS minutes,
        COALESCE(sum(w.labor_cost), 0) AS labor, round(avg(w.rating)::numeric, 1) AS rating, count(w.id) FILTER (WHERE w.due_at IS NOT NULL AND COALESCE(w.completed_at, now()) > w.due_at)::int AS late
       FROM maintenance_technicians t LEFT JOIN work_orders w ON w.technician_id = t.id AND w.status <> 'cancelled' AND ${dc('w.created_at')} BETWEEN $2 AND $3
      WHERE t.hotel_id = $1 GROUP BY t.id ORDER BY orders DESC, t.name`, P)).map((r) => ({ ...r, hours: Math.round((r.minutes / 60) * 10) / 10, labor: n2(r.labor), rating: r.rating === null ? '' : Number(r.rating) }));
  } else if (kind === 'resolution') {
    const base = await q<any>(db, `SELECT priority, category, extract(epoch FROM (resolved_at - created_at)) / 3600 AS h, (resolved_at <= due_at) AS ok FROM maintenance_tickets
       WHERE hotel_id = $1 AND resolved_at IS NOT NULL AND status IN ('resolved','closed') AND ${dc('created_at')} BETWEEN $2 AND $3`, P);
    const group = (key: (x: any) => string) => {
      const m = new Map<string, any[]>();
      for (const x of base) m.set(key(x), [...(m.get(key(x)) ?? []), x]);
      return [...m.entries()].map(([g, xs]) => ({ group: g, count: xs.length, avg_h: Math.round((xs.reduce((a, x) => a + Number(x.h), 0) / xs.length) * 10) / 10,
        max_h: Math.round(Math.max(...xs.map((x) => Number(x.h))) * 10) / 10, sla: Math.round((xs.filter((x) => x.ok).length * 100) / xs.length) }));
    };
    rows = [...group((x) => `Priorité ${PRIO_LABEL[x.priority]}`), ...group((x) => EQ_CATEGORY[x.category] ?? x.category)];
  } else if (kind === 'equipment') {
    rows = (await q<any>(db, `SELECT e.code, e.name, e.category, e.status, (SELECT count(*) FROM maintenance_tickets m WHERE m.equipment_id = e.id AND ${dc('m.created_at')} BETWEEN $2 AND $3)::int AS faults,
        COALESCE((SELECT sum(total_cost) FROM work_orders w WHERE w.equipment_id = e.id AND w.status <> 'cancelled' AND ${dc('w.created_at')} BETWEEN $2 AND $3), 0) AS cost
       FROM equipment e WHERE e.hotel_id = $1 ORDER BY faults DESC, cost DESC LIMIT 50`, P)).filter((r) => r.faults || Number(r.cost))
      .map((r) => ({ ...r, category: EQ_CATEGORY[r.category], cost: n2(r.cost), status: ({ operational: 'Opérationnel', degraded: 'Dégradé', broken: 'En panne', out_of_service: 'Hors service', retired: 'Retiré' } as any)[r.status] }));
  } else if (kind === 'costs') {
    rows = (await q<any>(db, `SELECT to_char(created_at AT TIME ZONE '${TZ}', 'YYYY-MM') AS month, count(*)::int AS orders, sum(labor_cost) AS labor, sum(parts_cost) AS parts, sum(external_cost) AS external, sum(total_cost) AS total
       FROM work_orders WHERE hotel_id = $1 AND status <> 'cancelled' AND ${dc('created_at')} BETWEEN $2 AND $3 GROUP BY 1 ORDER BY 1`, P)).map((r) => ({ ...r, labor: n2(r.labor), parts: n2(r.parts), external: n2(r.external), total: n2(r.total) }));
    total = ['labor', 'parts', 'external', 'total'].reduce((a, k) => ({ ...a, [k]: n2(rows.reduce((s, r) => s + r[k], 0)) }), { orders: rows.reduce((s, r) => s + r.orders, 0) });
  } else if (kind === 'departments') {
    rows = (await q<any>(db, `SELECT COALESCE(e.department, CASE WHEN w.room_id IS NOT NULL THEN 'rooms' ELSE 'other' END) AS department, COALESCE(e.name, 'Chambre ' || r.number, w.title) AS equipment,
        count(*)::int AS orders, sum(w.total_cost) AS total FROM work_orders w LEFT JOIN equipment e ON e.id = w.equipment_id LEFT JOIN rooms r ON r.id = w.room_id
       WHERE w.hotel_id = $1 AND w.status <> 'cancelled' AND ${dc('w.created_at')} BETWEEN $2 AND $3 GROUP BY 1, 2 ORDER BY 1, total DESC`, P)).map((r) => ({ ...r, department: DEPT_LABEL[r.department] ?? r.department, total: n2(r.total) }));
    total = { total: n2(rows.reduce((s, r) => s + r.total, 0)) };
  } else if (kind === 'preventive') {
    const t = today();
    rows = (await q<any>(db, `SELECT w.*, p.name AS plan, e.name AS equipment, tc.name AS technician FROM work_orders w JOIN maintenance_plans p ON p.id = w.plan_id LEFT JOIN equipment e ON e.id = w.equipment_id
        LEFT JOIN maintenance_technicians tc ON tc.id = w.technician_id WHERE w.hotel_id = $1 AND w.plan_due BETWEEN $2 AND $3 ORDER BY w.plan_due`, P)).map((w) => {
      const due = String(w.plan_due).slice(0, 10), done = w.completed_at ? new Date(w.completed_at).toLocaleDateString('sv-SE', { timeZone: TZ }) : null;
      return { plan: w.plan, equipment: w.equipment ?? '', due, done: done ?? '', technician: w.technician ?? '', state: w.status === 'cancelled' ? 'Annulée' : done ? (done <= due ? 'Réalisée à temps' : 'Réalisée en retard') : due < t ? 'En retard' : 'À venir' };
    });
    for (const p of await q<any>(db, `SELECT p.*, e.name AS equipment FROM maintenance_plans p LEFT JOIN equipment e ON e.id = p.equipment_id WHERE p.hotel_id = $1 AND p.active AND p.next_due BETWEEN $2 AND $3
        AND NOT EXISTS (SELECT 1 FROM work_orders w WHERE w.plan_id = p.id AND w.plan_due = p.next_due)`, P)) {
      rows.push({ plan: p.name, equipment: p.equipment ?? '', due: String(p.next_due).slice(0, 10), done: '', technician: '', state: String(p.next_due).slice(0, 10) < today() ? 'En retard (non lancée)' : 'À venir' });
    }
  } else if (kind === 'rooms') {
    rows = (await q<any>(db, `SELECT b.*, r.number AS room, m.number AS ticket FROM room_blocks b JOIN rooms r ON r.id = b.room_id LEFT JOIN maintenance_tickets m ON m.id = b.ticket_id
       WHERE r.hotel_id = $1 AND b.kind = 'out_of_service' AND b.start_date <= $3 AND (b.end_date IS NULL OR b.end_date > $2) ORDER BY b.start_date`, P)).map((b) => {
      const s = String(b.start_date).slice(0, 10), e = b.end_date ? String(b.end_date).slice(0, 10) : null;
      const from2 = s > from ? s : from, to2 = e && e <= to ? e : addDays(to, 1);
      return { room: b.room, reason: b.reason, start: s, end: e ?? '…', days: Math.max(0, Math.round((Date.parse(to2) - Date.parse(from2)) / 86400000)), ticket: b.ticket ?? '', state: b.status === 'active' ? 'Bloquée' : 'Réactivée' };
    });
    total = { days: rows.reduce((a, r) => a + r.days, 0) };
  } else if (kind === 'history') {
    const eqf = opts.equipment_id ?? null;
    const t1 = await q<any>(db, `SELECT e.code, e.name AS equipment, m.created_at AS d, 'Panne' AS type, m.number AS ref, m.title || ' — ' || COALESCE(m.resolution, '') AS detail, t.name AS technician, NULL::numeric AS cost
        FROM maintenance_tickets m JOIN equipment e ON e.id = m.equipment_id LEFT JOIN maintenance_technicians t ON t.id = m.technician_id WHERE e.hotel_id = $1 AND ($4::int IS NULL OR e.id = $4) AND ${dc('m.created_at')} BETWEEN $2 AND $3`, [...P, eqf]);
    const t2 = await q<any>(db, `SELECT e.code, e.name AS equipment, w.created_at AS d, CASE w.kind WHEN 'preventive' THEN 'Préventif' WHEN 'corrective' THEN 'Intervention' ELSE 'Intervention' END AS type, w.number AS ref,
        w.title || COALESCE(' — ' || w.result, '') AS detail, t.name AS technician, w.total_cost AS cost FROM work_orders w JOIN equipment e ON e.id = w.equipment_id LEFT JOIN maintenance_technicians t ON t.id = w.technician_id
       WHERE e.hotel_id = $1 AND ($4::int IS NULL OR e.id = $4) AND w.status <> 'cancelled' AND ${dc('w.created_at')} BETWEEN $2 AND $3`, [...P, eqf]);
    rows = [...t1, ...t2].sort((a, b) => a.code.localeCompare(b.code) || new Date(a.d).getTime() - new Date(b.d).getTime()).map((r) => ({ ...r, date: fdt(r.d), cost: r.cost === null ? '' : n2(r.cost), technician: r.technician ?? '' }));
  }
  return { kind, title: def.title, from, to, columns: def.columns, rows, total };
}
