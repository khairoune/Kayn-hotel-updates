/**
 * Noyau du centre de rapports : types, contexte, conventions de calcul communes.
 *
 * Conventions (documentées dans le README et rappelées dans l'interface) :
 *  - Fuseau : toutes les dates sont ramenées au fuseau de l'hôtel (AT TIME ZONE).
 *  - Nuitée vendue : nuit d'une chambre de réservation « en séjour » ou « terminée » ; pour les nuits à venir (≥ aujourd'hui),
 *    les réservations « en attente » / « confirmées » sont comptées comme prévision (carnet) et signalées à part.
 *    Annulations et no-shows ne sont jamais comptés.
 *  - Chambre disponible : chambre active (ou désactivée après la date) non bloquée ce jour-là (hors service / maintenance).
 *  - Taux d'occupation = nuitées vendues / chambres disponibles × 100 ; ADR = CA hébergement / nuitées vendues ;
 *    RevPAR = CA hébergement / chambres disponibles. CA hébergement = prix net de la nuit (remise déduite), hors taxes.
 *  - CA (activité, HT) ≠ CA facturé (factures − avoirs) ≠ encaissé (paiements + recettes − remboursements) : trois notions distinctes.
 *  - Restaurant : commandes non annulées (HT, remise déduite) ; les prestations au folio issues du restaurant sont exclues des
 *    « services » pour ne jamais compter deux fois la même vente.
 */
import type { Db } from '../../db/pool.js';
import type { Actor } from '../../lib/audit.js';
import { q } from '../../db/pool.js';
import type { Period } from './period.js';

export type Unit = 'money' | 'pct' | 'int' | 'num' | 'days' | 'hours' | 'min' | 'score';
export type Kpi = { key: string; label: string; value: number | null; prev: number | null; unit: Unit; better?: 'up' | 'down' | null; hint?: string; drill?: string };
export type Chart = { key: string; title: string; type: 'line' | 'bar' | 'pie'; unit: Unit; labels: string[]; series: { name: string; values: number[] }[] };
export type Col = { key: string; label: string; money?: boolean; unit?: Unit };
export type Table = { key: string; title: string; columns: Col[]; rows: any[]; total?: Record<string, any> | null; drill?: string };
export type Section = { kpis: Kpi[]; charts: Chart[]; tables: Table[]; notes?: string[] };

export type Filters = { room_type_id?: number | null; floor_id?: number | null; source?: string | null; status?: string | null; outlet?: string | null; category?: string | null; department?: string | null };
export type Ctx = { db: Db; hotelId: number; tz: string; P: Period; F: Filters; perms: Set<string>; actor: Actor; currency: string };

export const r2 = (n: number) => Math.round(n * 100) / 100;
export const n0 = (v: any) => (v === null || v === undefined || v === '' ? 0 : Number(v));
export const pct = (a: number, b: number) => (b ? r2((a / b) * 100) : 0);
export const div = (a: number, b: number) => (b ? r2(a / b) : 0);
export const col = (key: string, label: string, unit?: Unit): Col => ({ key, label, ...(unit ? { unit } : {}), ...(unit === 'money' ? { money: true } : {}) });

export const SOURCE_LBL: Record<string, string> = { walk_in: 'Sur place', phone: 'Téléphone', email: 'E-mail', company: 'Société', agency: 'Agence', website: 'Site web', other: 'Autre' };
export const RES_STATUS_LBL: Record<string, string> = { pending: 'En attente', confirmed: 'Confirmée', checked_in: 'En séjour', checked_out: 'Terminée', cancelled: 'Annulée', no_show: 'No-show' };
export const OUTLET_LBL: Record<string, string> = { restaurant: 'Restaurant', bar: 'Bar', room_service: 'Room service', breakfast: 'Petit-déjeuner' };
export const METHOD_LBL: Record<string, string> = { cash: 'Espèces', card: 'Carte bancaire', cheque: 'Chèque', transfer: 'Virement', company_account: 'Compte société', online: 'Paiement en ligne', room: 'Sur la chambre', invoice: 'Sur facture', open: 'Non réglée' };
export const WEEKDAYS = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];

/** Construit un KPI à partir de deux valeurs (période et comparaison). */
export function kpi(key: string, label: string, unit: Unit, value: number | null, prev: number | null | undefined, o: { better?: 'up' | 'down' | null; hint?: string; drill?: string } = {}): Kpi {
  return { key, label, unit, value: value === null ? null : r2(value), prev: prev === null || prev === undefined ? null : r2(prev), better: o.better === undefined ? 'up' : o.better, ...(o.hint ? { hint: o.hint } : {}), ...(o.drill ? { drill: o.drill } : {}) };
}
/** Exécute un calcul sur la période et, si demandé, sur la période de comparaison. */
export async function both<T>(c: Ctx, fn: (from: string, to: string) => Promise<T>): Promise<[T, T | null]> {
  const cur = await fn(c.P.from, c.P.to);
  const prev = c.P.pfrom && c.P.pto ? await fn(c.P.pfrom, c.P.pto) : null;
  return [cur, prev];
}

// ===================================================== Nuitées et disponibilité =====================================================
/**
 * Paramètres : $1 hôtel, $2 du, $3 au, $4 fuseau, $5 aujourd'hui, $6 type de chambre, $7 étage, $8 canal.
 * exist  : chambre existante ce jour ; avail : existante et non bloquée ; nights : une ligne par nuit vendue.
 */
export const ROOM_CTE = `
  days AS (SELECT gs::date AS d FROM generate_series($2::date, $3::date, '1 day') gs),
  rm AS (SELECT r.id, r.number, r.room_type_id, r.floor_id, r.active, r.deactivated_at FROM rooms r
          WHERE r.hotel_id = $1 AND ($6::int IS NULL OR r.room_type_id = $6) AND ($7::int IS NULL OR r.floor_id = $7)),
  exist AS (SELECT rm.id AS room_id, rm.room_type_id, rm.floor_id, days.d FROM rm CROSS JOIN days
             WHERE rm.active OR (rm.deactivated_at AT TIME ZONE $4)::date > days.d),
  avail AS (SELECT e.* FROM exist e WHERE NOT EXISTS (SELECT 1 FROM room_blocks b WHERE b.room_id = e.room_id AND b.start_date <= e.d
             AND e.d < LEAST(COALESCE(b.end_date, 'infinity'::date), CASE WHEN b.status = 'released' THEN COALESCE((b.released_at AT TIME ZONE $4)::date, 'infinity'::date) ELSE 'infinity'::date END))),
  nights AS (SELECT rr.id AS rr_id, rr.reservation_id, rr.room_id, rr.room_type_id, rr.rate, res.source, res.guest_id, gs::date AS d, (gs::date >= $5::date) AS fc
              FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id
              CROSS JOIN LATERAL generate_series(GREATEST(rr.check_in, $2::date), LEAST(rr.check_out - 1, $3::date), '1 day') gs
             WHERE res.hotel_id = $1 AND rr.check_in <= $3 AND rr.check_out > $2
               AND (rr.status IN ('checked_in','checked_out') OR (rr.status IN ('pending','confirmed') AND gs::date >= $5::date))
               AND ($6::int IS NULL OR rr.room_type_id = $6)
               AND ($7::int IS NULL OR EXISTS (SELECT 1 FROM rooms x WHERE x.id = rr.room_id AND x.floor_id = $7))
               AND ($8::text IS NULL OR res.source = $8))`;
export const roomParams = (c: Ctx, from: string, to: string) => [c.hotelId, from, to, c.tz, c.P.today, c.F.room_type_id ?? null, c.F.floor_id ?? null, c.F.source ?? null];

const NIGHT_AGG = `count(*)::int AS sold, COALESCE(sum(rate),0) AS rev, count(*) FILTER (WHERE fc)::int AS sold_fc, COALESCE(sum(rate) FILTER (WHERE fc),0) AS rev_fc`;
export type RoomRow = { key: string; label?: string; exist: number; avail: number; sold: number; rev: number; sold_fc: number; rev_fc: number; extra?: any };

/** Agrégats chambres par jour, chambre, type, étage ou canal. */
export async function roomAgg(c: Ctx, from: string, to: string, dim: 'day' | 'room' | 'type' | 'floor' | 'total'): Promise<RoomRow[]> {
  const P = roomParams(c, from, to);
  const norm = (x: any): RoomRow => ({ key: String(x.key), label: x.label ?? undefined, exist: n0(x.exist), avail: n0(x.avail), sold: n0(x.sold), rev: n0(x.rev), sold_fc: n0(x.sold_fc), rev_fc: n0(x.rev_fc), extra: x });
  if (dim === 'day' || dim === 'total') {
    const rows = await q<any>(c.db, `WITH ${ROOM_CTE}
      SELECT to_char(days.d, 'YYYY-MM-DD') AS key, COALESCE(e.n,0) AS exist, COALESCE(a.n,0) AS avail, COALESCE(n.sold,0) AS sold, COALESCE(n.rev,0) AS rev, COALESCE(n.sold_fc,0) AS sold_fc, COALESCE(n.rev_fc,0) AS rev_fc
        FROM days LEFT JOIN (SELECT d, count(*)::int AS n FROM exist GROUP BY d) e ON e.d = days.d
        LEFT JOIN (SELECT d, count(*)::int AS n FROM avail GROUP BY d) a ON a.d = days.d
        LEFT JOIN (SELECT d, ${NIGHT_AGG} FROM nights GROUP BY d) n ON n.d = days.d ORDER BY days.d`, P);
    const out = rows.map(norm);
    if (dim === 'day') return out;
    return [out.reduce((s, x) => ({ ...s, exist: s.exist + x.exist, avail: s.avail + x.avail, sold: s.sold + x.sold, rev: s.rev + x.rev, sold_fc: s.sold_fc + x.sold_fc, rev_fc: s.rev_fc + x.rev_fc }), { key: 'total', exist: 0, avail: 0, sold: 0, rev: 0, sold_fc: 0, rev_fc: 0 } as RoomRow)];
  }
  if (dim === 'room') {
    return (await q<any>(c.db, `WITH ${ROOM_CTE}
      SELECT rm.id AS key, rm.number AS label, rt.name AS type, f.number AS floor, rm.active,
             (SELECT count(*) FROM exist e WHERE e.room_id = rm.id)::int AS exist, (SELECT count(*) FROM avail a WHERE a.room_id = rm.id)::int AS avail, n.*
        FROM rm JOIN room_types rt ON rt.id = rm.room_type_id LEFT JOIN floors f ON f.id = rm.floor_id
        LEFT JOIN (SELECT room_id, ${NIGHT_AGG} FROM nights GROUP BY room_id) n ON n.room_id = rm.id
       ORDER BY f.number NULLS LAST, rm.number`, P)).map(norm);
  }
  if (dim === 'type') {
    return (await q<any>(c.db, `WITH ${ROOM_CTE}
      SELECT rt.id AS key, rt.name AS label, (SELECT count(*) FROM rm WHERE rm.room_type_id = rt.id AND rm.active)::int AS rooms,
             (SELECT count(*) FROM exist e WHERE e.room_type_id = rt.id)::int AS exist, (SELECT count(*) FROM avail a WHERE a.room_type_id = rt.id)::int AS avail, n.*
        FROM room_types rt LEFT JOIN (SELECT room_type_id, ${NIGHT_AGG} FROM nights GROUP BY room_type_id) n ON n.room_type_id = rt.id
       WHERE rt.hotel_id = $1 AND ($6::int IS NULL OR rt.id = $6) ORDER BY rt.sort_order, rt.name`, P)).map(norm).filter((x) => x.exist || x.sold);
  }
  return (await q<any>(c.db, `WITH ${ROOM_CTE}, nf AS (SELECT n.*, r.floor_id FROM nights n LEFT JOIN rooms r ON r.id = n.room_id)
    SELECT f.id AS key, COALESCE(f.name, 'Étage ' || f.number) AS label, (SELECT count(*) FROM rm WHERE rm.floor_id = f.id AND rm.active)::int AS rooms,
           (SELECT count(*) FROM exist e WHERE e.floor_id = f.id)::int AS exist, (SELECT count(*) FROM avail a WHERE a.floor_id = f.id)::int AS avail, n.*
      FROM floors f LEFT JOIN (SELECT floor_id, ${NIGHT_AGG} FROM nf GROUP BY floor_id) n ON n.floor_id = f.id
     WHERE f.hotel_id = $1 AND ($7::int IS NULL OR f.id = $7) ORDER BY f.number`, P)).map(norm).filter((x) => x.exist || x.sold);
}
/** Indicateurs dérivés d'un agrégat chambres. */
export const roomKpis = (x: RoomRow) => ({ occ: pct(x.sold, x.avail), adr: div(x.rev, x.sold), revpar: div(x.rev, x.avail), oos: x.exist - x.avail });

// ===================================================== CA d'activité (HT) =====================================================
/** CA restaurant (HT, remise déduite, commandes non annulées) — par jour. */
export async function rsRevenueByDay(c: Ctx, from: string, to: string) {
  return q<any>(c.db, `SELECT to_char((o.created_at AT TIME ZONE $4)::date, 'YYYY-MM-DD') AS d, COALESCE(sum(o.subtotal - o.discount_total),0) AS amount, count(*)::int AS n
     FROM rs_orders o WHERE o.hotel_id = $1 AND o.status <> 'cancelled' AND o.settlement <> 'cancelled' AND (o.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3
       AND ($5::text IS NULL OR o.outlet = $5) GROUP BY 1`, [c.hotelId, from, to, c.tz, c.F.outlet ?? null]);
}
/** Prestations au folio hors restaurant (services, frais d'annulation / no-show, ajustements), HT, non annulées — par jour. */
export async function servicesRevenueByDay(c: Ctx, from: string, to: string) {
  return q<any>(c.db, `SELECT to_char(ch.service_date, 'YYYY-MM-DD') AS d, COALESCE(sum(ch.total),0) AS amount, count(*)::int AS n
     FROM charges ch JOIN reservations res ON res.id = ch.reservation_id
    WHERE res.hotel_id = $1 AND NOT ch.void AND ch.rs_order_line_id IS NULL AND ch.service_date BETWEEN $2 AND $3 GROUP BY 1`, [c.hotelId, from, to]);
}
export const sumOf = (rows: any[], k = 'amount') => r2(rows.reduce((s, r) => s + n0(r[k]), 0));
