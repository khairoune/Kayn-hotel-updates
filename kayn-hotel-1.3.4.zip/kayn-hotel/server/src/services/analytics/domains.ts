/** Calculs des tableaux de bord analytiques par domaine (réelles données des modules, aucune table parallèle). */
import { q, one } from '../../db/pool.js';
import { receivables } from '../finance.js';
import { sessionSummary } from '../cash.js';
import { scopeOf } from '../hr.js';
import {
  both, col, div, kpi, METHOD_LBL, n0, OUTLET_LBL, pct, r2, RES_STATUS_LBL, roomAgg, roomKpis, rsRevenueByDay, servicesRevenueByDay, SOURCE_LBL, sumOf, WEEKDAYS,
  type Chart, type Ctx, type Section, type Table,
} from './core.js';
import { bucketize } from './period.js';
import { fmt } from './export.js';

const line = (key: string, title: string, unit: Chart['unit'], labels: string[], series: Chart['series']): Chart => ({ key, title, type: 'line', unit, labels, series });
const bar = (key: string, title: string, unit: Chart['unit'], labels: string[], series: Chart['series']): Chart => ({ key, title, type: 'bar', unit, labels, series });
const pie = (key: string, title: string, unit: Chart['unit'], rows: { label: string; value: number }[]): Chart => ({ key, title, type: 'pie', unit, labels: rows.map((r) => r.label), series: [{ name: title, values: rows.map((r) => r2(r.value)) }] });
const forecastNote = (c: Ctx) => (c.P.to >= c.P.today ? ['Nuitées à partir d\'aujourd\'hui : réservations en attente / confirmées comptées en prévision (carnet).'] : []);

// ===================================================== Réservations : statistiques communes =====================================================
const RES_WHERE = `res.hotel_id = $1 AND ($5::text IS NULL OR res.source = $5) AND ($6::text IS NULL OR res.status = $6)
  AND ($7::int IS NULL OR EXISTS (SELECT 1 FROM reservation_rooms x WHERE x.reservation_id = res.id AND x.room_type_id = $7))`;
const resParams = (c: Ctx, from: string, to: string) => [c.hotelId, from, to, c.tz, c.F.source ?? null, c.F.status ?? null, c.F.room_type_id ?? null];
const RR_WHERE = `res.hotel_id = $1 AND ($5::text IS NULL OR res.source = $5) AND ($7::int IS NULL OR rr.room_type_id = $7)`;

export async function resStats(c: Ctx, from: string, to: string) {
  const P = resParams(c, from, to);
  const created = await one<any>(c.db, `SELECT count(*)::int AS n, COALESCE(sum(res.check_out - res.check_in),0)::int AS nights,
      COALESCE(avg(res.check_in - (res.created_at AT TIME ZONE $4)::date) FILTER (WHERE res.status NOT IN ('cancelled')),0) AS lead
     FROM reservations res WHERE ${RES_WHERE} AND (res.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`, P);
  const arr = await one<any>(c.db, `SELECT count(*)::int AS total,
      count(*) FILTER (WHERE res.status = 'cancelled')::int AS cancelled, count(*) FILTER (WHERE res.status = 'no_show')::int AS no_show,
      count(*) FILTER (WHERE res.status = 'pending')::int AS pending, count(*) FILTER (WHERE res.status = 'confirmed')::int AS confirmed
     FROM reservations res WHERE ${RES_WHERE} AND res.check_in BETWEEN $2 AND $3 AND $4::text IS NOT NULL`, P);
  const mv = await one<any>(c.db, `SELECT
      count(*) FILTER (WHERE rr.check_in BETWEEN $2 AND $3 AND rr.moved_from_rr_id IS NULL AND rr.status IN ('checked_in','checked_out'))::int AS arrivals,
      count(*) FILTER (WHERE rr.check_out BETWEEN $2 AND $3 AND rr.status = 'checked_out' AND NOT EXISTS (SELECT 1 FROM reservation_rooms nx WHERE nx.moved_from_rr_id = rr.id))::int AS departures,
      COALESCE(sum(rr.check_out - rr.check_in) FILTER (WHERE rr.check_out BETWEEN $2 AND $3 AND rr.status = 'checked_out'),0)::int AS dep_nights
     FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id WHERE ${RR_WHERE} AND (rr.check_in BETWEEN $2 AND $3 OR rr.check_out BETWEEN $2 AND $3) AND $4::text IS NOT NULL AND ($6::text IS NULL OR TRUE)`, P);
  return {
    created: created.n, created_nights: created.nights, lead: r2(n0(created.lead)), arr_total: arr.total, cancelled: arr.cancelled, no_show: arr.no_show, pending: arr.pending, confirmed: arr.confirmed,
    cancel_rate: pct(arr.cancelled, arr.total), no_show_rate: pct(arr.no_show, arr.total), arrivals: mv.arrivals, departures: mv.departures, alos: div(mv.dep_nights, mv.departures),
  };
}

/** Flux de trésorerie (encaissé ≠ facturé) : paiements, recettes diverses, remboursements, dépenses. */
async function cashFlows(c: Ctx, from: string, to: string) {
  const P = [c.hotelId, from, to, c.tz];
  const r = await one<any>(c.db, `SELECT
      (SELECT COALESCE(sum(amount),0) FROM payments WHERE hotel_id = $1 AND NOT void AND (received_at AT TIME ZONE $4)::date BETWEEN $2 AND $3) AS payments,
      (SELECT COALESCE(sum(amount),0) FROM incomes WHERE hotel_id = $1 AND NOT void AND (created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3) AS incomes,
      (SELECT COALESCE(sum(f.amount),0) FROM refunds f LEFT JOIN reservations r ON r.id = f.reservation_id LEFT JOIN invoices i ON i.id = f.invoice_id
        WHERE COALESCE(r.hotel_id, i.hotel_id) = $1 AND (f.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3) AS refunds,
      (SELECT COALESCE(sum(amount),0) FROM expenses WHERE hotel_id = $1 AND NOT void AND expense_date BETWEEN $2 AND $3) AS expenses`, P);
  const payments = n0(r.payments), incomes = n0(r.incomes), refunds = n0(r.refunds), expenses = n0(r.expenses);
  return { payments, incomes, refunds, expenses, collected: r2(payments + incomes - refunds) };
}
async function cashFlowsByDay(c: Ctx) {
  const P = [c.hotelId, c.P.from, c.P.to, c.tz];
  return q<any>(c.db, `SELECT d, sum(inn) AS inn, sum(outt) AS outt FROM (
      SELECT to_char((received_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS d, amount AS inn, 0 AS outt FROM payments WHERE hotel_id = $1 AND NOT void AND (received_at AT TIME ZONE $4)::date BETWEEN $2 AND $3
      UNION ALL SELECT to_char((created_at AT TIME ZONE $4)::date,'YYYY-MM-DD'), amount, 0 FROM incomes WHERE hotel_id = $1 AND NOT void AND (created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3
      UNION ALL SELECT to_char((f.created_at AT TIME ZONE $4)::date,'YYYY-MM-DD'), -f.amount, 0 FROM refunds f LEFT JOIN reservations r ON r.id = f.reservation_id LEFT JOIN invoices i ON i.id = f.invoice_id
        WHERE COALESCE(r.hotel_id, i.hotel_id) = $1 AND (f.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3
      UNION ALL SELECT to_char(expense_date,'YYYY-MM-DD'), 0, amount FROM expenses WHERE hotel_id = $1 AND NOT void AND expense_date BETWEEN $2 AND $3) x GROUP BY d`, P);
}
async function receivablesTotal(c: Ctx) {
  const rows = await receivables(c.db, c.hotelId);
  return { total: r2(rows.reduce((s, x) => s + x.due, 0)), count: rows.length };
}

// ===================================================== 1. Tableau de bord général =====================================================
export async function overview(c: Ctx): Promise<Section> {
  const [cur, prev] = await both(c, async (f, t) => {
    const [room] = await roomAgg(c, f, t, 'total');
    const rs = sumOf(await rsRevenueByDay(c, f, t));
    const sv = sumOf(await servicesRevenueByDay(c, f, t));
    const res = await resStats(c, f, t);
    const cf = await cashFlows(c, f, t);
    const k = roomKpis(room);
    const total = r2(room.rev + rs + sv);
    return { room, k, rs, sv, total, res, cf, result: r2(total - cf.expenses) };
  });
  const rec = await receivablesTotal(c);
  const p = prev;
  const kpis = [
    kpi('occupancy', 'Taux d\'occupation', 'pct', cur.k.occ, p?.k.occ, { drill: 'nights', hint: `${cur.room.sold} nuitées / ${cur.room.avail} disponibles` }),
    kpi('adr', 'ADR (prix moyen)', 'money', cur.k.adr, p?.k.adr, { drill: 'nights' }),
    kpi('revpar', 'RevPAR', 'money', cur.k.revpar, p?.k.revpar, { drill: 'nights' }),
    kpi('revenue_total', 'Chiffre d\'affaires total (HT)', 'money', cur.total, p?.total, { hint: 'Hébergement + restaurant + services' }),
    kpi('revenue_room', 'CA hébergement', 'money', cur.room.rev, p?.room.rev, { drill: 'nights', hint: cur.room.rev_fc ? `dont prévision ${fmt('money', cur.room.rev_fc, c.currency)}` : undefined }),
    kpi('revenue_rs', 'CA restaurant', 'money', cur.rs, p?.rs, { drill: 'rs_orders' }),
    kpi('revenue_services', 'CA services', 'money', cur.sv, p?.sv, { drill: 'charges' }),
    kpi('reservations', 'Réservations enregistrées', 'int', cur.res.created, p?.res.created, { drill: 'reservations' }),
    kpi('arrivals', 'Arrivées', 'int', cur.res.arrivals, p?.res.arrivals, { drill: 'arrivals' }),
    kpi('departures', 'Départs', 'int', cur.res.departures, p?.res.departures, { drill: 'departures' }),
    kpi('alos', 'Durée moyenne de séjour', 'days', cur.res.alos, p?.res.alos),
    kpi('cancellations', 'Annulations', 'int', cur.res.cancelled, p?.res.cancelled, { better: 'down', drill: 'cancellations' }),
    kpi('no_shows', 'No-shows', 'int', cur.res.no_show, p?.res.no_show, { better: 'down', drill: 'no_shows' }),
    kpi('collected', 'Encaissements nets', 'money', cur.cf.collected, p?.cf.collected, { drill: 'payments', hint: 'Paiements + recettes − remboursements' }),
    kpi('expenses', 'Dépenses totales', 'money', cur.cf.expenses, p?.cf.expenses, { better: 'down', drill: 'expenses' }),
    kpi('receivables', 'Créances clients', 'money', rec.total, null, { better: 'down', drill: 'receivables', hint: `${rec.count} dossier(s) — situation à ce jour` }),
    kpi('result', 'Résultat opérationnel', 'money', cur.result, p?.result, { hint: 'CA HT − dépenses enregistrées (hors amortissements)' }),
  ];
  const days = await roomAgg(c, c.P.from, c.P.to, 'day');
  const rsd = await rsRevenueByDay(c, c.P.from, c.P.to);
  const svd = await servicesRevenueByDay(c, c.P.from, c.P.to);
  const merged = [...days.map((d) => ({ d: d.key, room: d.rev, sold: d.sold, avail: d.avail })), ...rsd.map((x) => ({ d: x.d, rs: x.amount })), ...svd.map((x) => ({ d: x.d, sv: x.amount }))];
  const B = bucketize(merged, c.P.from, c.P.to, c.P.group, ['room', 'rs', 'sv', 'sold', 'avail']);
  const cfd = await cashFlowsByDay(c);
  const C = bucketize(cfd, c.P.from, c.P.to, c.P.group, ['inn', 'outt']);
  const types = await roomAgg(c, c.P.from, c.P.to, 'type');
  return {
    kpis,
    charts: [
      line('revenue', 'Évolution du chiffre d\'affaires (HT)', 'money', B.labels, [{ name: 'Hébergement', values: B.values('room') }, { name: 'Restaurant', values: B.values('rs') }, { name: 'Services', values: B.values('sv') }]),
      line('occupancy', 'Taux d\'occupation', 'pct', B.labels, [{ name: 'Occupation', values: B.labels.map((k) => pct(B.raw.get(k)!.sold, B.raw.get(k)!.avail)) }]),
      pie('mix', 'Répartition du chiffre d\'affaires', 'money', [{ label: 'Hébergement', value: cur.room.rev }, { label: 'Restaurant', value: cur.rs }, { label: 'Services', value: cur.sv }]),
      bar('cash', 'Encaissements et dépenses', 'money', C.labels, [{ name: 'Encaissements nets', values: C.values('inn') }, { name: 'Dépenses', values: C.values('outt') }]),
    ],
    tables: [{
      key: 'types', title: 'Performance par type de chambre', columns: [col('label', 'Type'), col('avail', 'Disponibles', 'int'), col('sold', 'Vendues', 'int'), col('occ', 'Occupation', 'pct'), col('rev', 'CA', 'money'), col('adr', 'ADR', 'money'), col('revpar', 'RevPAR', 'money')],
      rows: types.map((x) => ({ label: x.label, avail: x.avail, sold: x.sold, rev: r2(x.rev), ...roomKpis(x) })).sort((a, b) => b.rev - a.rev),
    }],
    notes: forecastNote(c),
  };
}

// ===================================================== 3. Réservations =====================================================
export async function reservations(c: Ctx): Promise<Section> {
  const [cur, prev] = await both(c, (f, t) => resStats(c, f, t));
  const P = resParams(c, c.P.from, c.P.to);
  const kpis = [
    kpi('reservations', 'Réservations enregistrées', 'int', cur.created, prev?.created, { drill: 'reservations' }),
    kpi('booked_nights', 'Nuitées réservées', 'int', cur.created_nights, prev?.created_nights),
    kpi('confirmed', 'Confirmées (arrivée sur la période)', 'int', cur.confirmed, prev?.confirmed, { drill: 'arrivals_all' }),
    kpi('pending', 'En attente', 'int', cur.pending, prev?.pending, { better: null, drill: 'arrivals_all' }),
    kpi('cancellations', 'Annulées', 'int', cur.cancelled, prev?.cancelled, { better: 'down', drill: 'cancellations' }),
    kpi('cancel_rate', 'Taux d\'annulation', 'pct', cur.cancel_rate, prev?.cancel_rate, { better: 'down', hint: 'Annulées / réservations arrivant sur la période' }),
    kpi('no_show_rate', 'Taux de no-show', 'pct', cur.no_show_rate, prev?.no_show_rate, { better: 'down', drill: 'no_shows' }),
    kpi('lead', 'Délai moyen réservation → arrivée', 'days', cur.lead, prev?.lead, { better: null }),
    kpi('alos', 'Durée moyenne de séjour', 'days', cur.alos, prev?.alos, { hint: 'Nuitées / séjours terminés' }),
    kpi('arrivals', 'Arrivées réalisées', 'int', cur.arrivals, prev?.arrivals, { drill: 'arrivals' }),
  ];
  const evo = await q<any>(c.db, `SELECT to_char((res.created_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS d, count(*)::int AS n,
      count(*) FILTER (WHERE res.status = 'cancelled')::int AS cancelled FROM reservations res WHERE ${RES_WHERE} AND (res.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY 1`, P);
  const E = bucketize(evo, c.P.from, c.P.to, c.P.group, ['n', 'cancelled']);
  const byArr = (dim: string) => q<any>(c.db, `SELECT ${dim} AS k, count(*)::int AS n, COALESCE(sum(res.check_out - res.check_in),0)::int AS nights,
      count(*) FILTER (WHERE res.status = 'cancelled')::int AS cancelled, count(*) FILTER (WHERE res.status = 'no_show')::int AS no_show,
      COALESCE(sum((SELECT sum(rr.rate * (rr.check_out - rr.check_in)) FROM reservation_rooms rr WHERE rr.reservation_id = res.id AND rr.status NOT IN ('cancelled','no_show'))),0) AS revenue
     FROM reservations res LEFT JOIN guests g ON g.id = res.guest_id WHERE ${RES_WHERE} AND res.check_in BETWEEN $2 AND $3 AND $4::text IS NOT NULL GROUP BY 1 ORDER BY n DESC`, P);
  const channels = (await byArr('res.source')).map((x) => ({ ...x, label: SOURCE_LBL[x.k] ?? x.k }));
  const statuses = (await byArr('res.status')).map((x) => ({ ...x, label: RES_STATUS_LBL[x.k] ?? x.k }));
  const origins = (await byArr(`COALESCE(NULLIF(g.country,''), NULLIF(g.nationality,''), 'Non renseigné')`)).map((x) => ({ ...x, label: x.k }));
  const types = await q<any>(c.db, `SELECT rt.name AS label, count(*)::int AS n, COALESCE(sum(rr.check_out - rr.check_in),0)::int AS nights,
      count(*) FILTER (WHERE rr.status = 'cancelled')::int AS cancelled, count(*) FILTER (WHERE rr.status = 'no_show')::int AS no_show,
      COALESCE(sum(rr.rate * (rr.check_out - rr.check_in)) FILTER (WHERE rr.status NOT IN ('cancelled','no_show')),0) AS revenue
     FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id JOIN room_types rt ON rt.id = rr.room_type_id
    WHERE ${RR_WHERE} AND ($6::text IS NULL OR res.status = $6) AND rr.check_in BETWEEN $2 AND $3 AND rr.moved_from_rr_id IS NULL AND $4::text IS NOT NULL GROUP BY rt.name, rt.sort_order ORDER BY n DESC`, P);
  const rate = (x: any) => ({ ...x, revenue: r2(n0(x.revenue)), cancel_rate: pct(x.cancelled, x.n), no_show_rate: pct(x.no_show, x.n) });
  const COLS = [col('label', 'Libellé'), col('n', 'Réservations', 'int'), col('nights', 'Nuitées', 'int'), col('cancelled', 'Annulées', 'int'), col('cancel_rate', 'Taux annul.', 'pct'), col('no_show', 'No-show', 'int'), col('revenue', 'CA hébergement', 'money')];
  const tot = (rows: any[]) => ({ label: 'Total', n: rows.reduce((s, x) => s + x.n, 0), nights: rows.reduce((s, x) => s + x.nights, 0), cancelled: rows.reduce((s, x) => s + x.cancelled, 0), no_show: rows.reduce((s, x) => s + x.no_show, 0), revenue: r2(rows.reduce((s, x) => s + n0(x.revenue), 0)), cancel_rate: pct(rows.reduce((s, x) => s + x.cancelled, 0), rows.reduce((s, x) => s + x.n, 0)) });
  // Demande : occupation par jour et par jour de semaine
  const days = await roomAgg(c, c.P.from, c.P.to, 'day');
  const dd = days.map((d) => ({ date: d.key, occ: pct(d.sold, d.avail), sold: d.sold, avail: d.avail, rev: r2(d.rev) }));
  const wk = WEEKDAYS.map((label, i) => { const xs = dd.filter((d) => (new Date(`${d.date}T00:00:00Z`).getUTCDay() + 6) % 7 === i); return { label, occ: pct(xs.reduce((s, x) => s + x.sold, 0), xs.reduce((s, x) => s + x.avail, 0)), sold: xs.reduce((s, x) => s + x.sold, 0) }; });
  const sorted = [...dd].filter((d) => d.avail).sort((a, b) => b.occ - a.occ || b.sold - a.sold);
  const DCOLS = [col('date', 'Date'), col('occ', 'Occupation', 'pct'), col('sold', 'Nuitées', 'int'), col('avail', 'Disponibles', 'int'), col('rev', 'CA hébergement', 'money')];
  return {
    kpis,
    charts: [
      line('evolution', 'Réservations enregistrées', 'int', E.labels, [{ name: 'Réservations', values: E.values('n') }, { name: 'dont annulées', values: E.values('cancelled') }]),
      pie('channels', 'Réservations par canal', 'int', channels.map((x) => ({ label: x.label, value: x.n }))),
      bar('statuses', 'Réservations par statut', 'int', statuses.map((x) => x.label), [{ name: 'Réservations', values: statuses.map((x) => x.n) }]),
      bar('types', 'Réservations par type de chambre', 'int', types.map((x) => x.label), [{ name: 'Chambres réservées', values: types.map((x) => x.n) }]),
      bar('origins', 'Origine des clients (10 premiers)', 'int', origins.slice(0, 10).map((x) => x.label), [{ name: 'Réservations', values: origins.slice(0, 10).map((x) => x.n) }]),
      bar('weekdays', 'Demande par jour de la semaine', 'pct', wk.map((x) => x.label), [{ name: 'Occupation moyenne', values: wk.map((x) => x.occ) }]),
    ],
    tables: [
      { key: 'channels', title: 'Par canal de distribution (arrivées de la période)', columns: COLS, rows: channels.map(rate), total: tot(channels) },
      { key: 'statuses', title: 'Par statut', columns: COLS, rows: statuses.map(rate), total: tot(statuses) },
      { key: 'types', title: 'Par type de chambre', columns: COLS, rows: types.map(rate), total: tot(types) },
      { key: 'origins', title: 'Par origine des clients', columns: COLS, rows: origins.map(rate), total: tot(origins) },
      { key: 'high', title: 'Jours de plus forte demande', columns: DCOLS, rows: sorted.slice(0, 10) },
      { key: 'low', title: 'Jours de plus faible demande', columns: DCOLS, rows: sorted.slice(-10).reverse() },
    ],
    notes: ['Annulations, no-shows, statuts et canaux : réservations dont l\'arrivée tombe dans la période. « Enregistrées » : date de création.', ...forecastNote(c)],
  };
}

// ===================================================== 4. Hébergement =====================================================
export async function rooms(c: Ctx): Promise<Section> {
  const [cur, prev] = await both(c, async (f, t) => (await roomAgg(c, f, t, 'total'))[0]);
  const k = roomKpis(cur), pk = prev ? roomKpis(prev) : null;
  const now = await one<any>(c.db, `SELECT count(*) FILTER (WHERE r.active)::int AS total,
      count(*) FILTER (WHERE r.active AND r.out_of_service)::int AS oos,
      count(*) FILTER (WHERE r.active AND EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL))::int AS occupied,
      count(*) FILTER (WHERE r.active AND EXISTS (SELECT 1 FROM room_blocks b WHERE b.room_id = r.id AND b.status = 'active' AND b.start_date <= $2 AND (b.end_date IS NULL OR b.end_date > $2)))::int AS blocked
     FROM rooms r WHERE r.hotel_id = $1 AND ($3::int IS NULL OR r.room_type_id = $3) AND ($4::int IS NULL OR r.floor_id = $4)`, [c.hotelId, c.P.today, c.F.room_type_id ?? null, c.F.floor_id ?? null]);
  const kpis = [
    kpi('occupancy', 'Taux d\'occupation', 'pct', k.occ, pk?.occ, { drill: 'nights' }),
    kpi('adr', 'ADR', 'money', k.adr, pk?.adr, { drill: 'nights' }),
    kpi('revpar', 'RevPAR', 'money', k.revpar, pk?.revpar),
    kpi('revenue_room', 'CA hébergement (HT)', 'money', cur.rev, prev?.rev, { drill: 'nights' }),
    kpi('sold', 'Nuitées vendues', 'int', cur.sold, prev?.sold, { drill: 'nights' }),
    kpi('avail', 'Chambres disponibles (nuits)', 'int', cur.avail, prev?.avail, { better: null }),
    kpi('oos_nights', 'Nuits hors service / bloquées', 'int', k.oos, pk?.oos, { better: 'down', drill: 'blocks' }),
    kpi('now_free', 'Libres aujourd\'hui', 'int', Math.max(0, now.total - now.oos - now.occupied - now.blocked), null, { better: null }),
    kpi('now_occupied', 'Occupées aujourd\'hui', 'int', now.occupied, null, { better: null }),
    kpi('now_oos', 'Hors service aujourd\'hui', 'int', now.oos, null, { better: 'down' }),
    kpi('now_blocked', 'Bloquées aujourd\'hui', 'int', now.blocked, null, { better: 'down', drill: 'blocks' }),
  ];
  const [types, floors, rms, days] = [await roomAgg(c, c.P.from, c.P.to, 'type'), await roomAgg(c, c.P.from, c.P.to, 'floor'), await roomAgg(c, c.P.from, c.P.to, 'room'), await roomAgg(c, c.P.from, c.P.to, 'day')];
  const B = bucketize(days.map((d) => ({ d: d.key, sold: d.sold, avail: d.avail, rev: d.rev })), c.P.from, c.P.to, c.P.group, ['sold', 'avail', 'rev']);
  const perf = (x: any) => ({ label: x.label, rooms: x.extra?.rooms ?? undefined, avail: x.avail, sold: x.sold, rev: r2(x.rev), ...roomKpis(x) });
  const PC = [col('label', 'Libellé'), col('rooms', 'Chambres', 'int'), col('avail', 'Nuits dispo.', 'int'), col('sold', 'Nuitées', 'int'), col('oos', 'Hors service', 'int'), col('occ', 'Occupation', 'pct'), col('rev', 'CA', 'money'), col('adr', 'ADR', 'money'), col('revpar', 'RevPAR', 'money')];
  const total = (rows: any[]) => { const t = { exist: 0, avail: 0, sold: 0, rev: 0 } as any; rows.forEach((x) => { t.exist += x.exist; t.avail += x.avail; t.sold += x.sold; t.rev += x.rev; }); return perf({ ...t, label: 'Total', extra: { rooms: rows.reduce((s, x) => s + n0(x.extra?.rooms), 0) } }); };
  return {
    kpis,
    charts: [
      line('occupancy', 'Taux d\'occupation', 'pct', B.labels, [{ name: 'Occupation %', values: B.labels.map((x) => pct(B.raw.get(x)!.sold, B.raw.get(x)!.avail)) }]),
      line('adr', 'ADR et RevPAR', 'money', B.labels, [{ name: 'ADR', values: B.labels.map((x) => div(B.raw.get(x)!.rev, B.raw.get(x)!.sold)) }, { name: 'RevPAR', values: B.labels.map((x) => div(B.raw.get(x)!.rev, B.raw.get(x)!.avail)) }]),
      bar('types', 'Occupation par catégorie', 'pct', types.map((x) => x.label!), [{ name: 'Occupation', values: types.map((x) => roomKpis(x).occ) }]),
      bar('floors', 'Occupation par étage', 'pct', floors.map((x) => x.label!), [{ name: 'Occupation', values: floors.map((x) => roomKpis(x).occ) }]),
      pie('revenue_types', 'CA hébergement par catégorie', 'money', types.map((x) => ({ label: x.label!, value: x.rev }))),
      pie('status_now', 'État des chambres aujourd\'hui', 'int', [{ label: 'Occupées', value: now.occupied }, { label: 'Libres', value: Math.max(0, now.total - now.oos - now.occupied - now.blocked) }, { label: 'Hors service', value: now.oos }, { label: 'Bloquées', value: now.blocked }]),
    ],
    tables: [
      { key: 'types', title: 'Performance par catégorie', columns: PC, rows: types.map(perf), total: total(types) },
      { key: 'floors', title: 'Occupation par étage', columns: PC, rows: floors.map(perf), total: total(floors) },
      { key: 'rooms', title: 'Occupation et revenus par chambre', columns: [col('label', 'Chambre'), col('type', 'Type'), col('floor', 'Étage'), col('avail', 'Nuits dispo.', 'int'), col('sold', 'Nuitées', 'int'), col('oos', 'Hors service', 'int'), col('occ', 'Occupation', 'pct'), col('rev', 'CA', 'money'), col('adr', 'ADR', 'money')],
        rows: rms.map((x) => ({ label: x.label, type: x.extra.type, floor: x.extra.floor ?? '', avail: x.avail, sold: x.sold, rev: r2(x.rev), ...roomKpis(x) })) },
    ],
    notes: forecastNote(c),
  };
}

// ===================================================== 5. Finances =====================================================
const DEPT_SQL = `CASE WHEN it.kind = 'room' THEN 'room' WHEN it.kind = 'tourist_tax' THEN 'tax'
  WHEN COALESCE(it.category, it.kind) IN ('restaurant','room_service','breakfast','bar','minibar') THEN 'restaurant' ELSE 'services' END`;
const DEPT_LBL: Record<string, string> = { room: 'Hébergement', restaurant: 'Restauration', services: 'Services', tax: 'Taxe de séjour' };
async function billed(c: Ctx, from: string, to: string) {
  const r = await one<any>(c.db, `SELECT COALESCE(sum(it.total) FILTER (WHERE it.kind <> 'tourist_tax'),0) AS ht, COALESCE(sum(it.tax_amount),0) AS vat,
      COALESCE(sum(it.total) FILTER (WHERE it.kind = 'tourist_tax'),0) AS tourist
     FROM invoices i JOIN invoice_items it ON it.invoice_id = i.id WHERE i.hotel_id = $1 AND i.type IN ('invoice','credit_note') AND (i.issued_at AT TIME ZONE $4)::date BETWEEN $2 AND $3
       AND ($5::text IS NULL OR ${DEPT_SQL} = $5)`, [c.hotelId, from, to, c.tz, c.F.department ?? null]);
  const d = await one<any>(c.db, `SELECT COALESCE(sum(i.discount_total) FILTER (WHERE i.type = 'invoice'),0) AS discounts,
      COALESCE(sum(-i.total) FILTER (WHERE i.type = 'credit_note'),0) AS credits, count(*) FILTER (WHERE i.type = 'credit_note')::int AS credit_n,
      count(*) FILTER (WHERE i.type = 'invoice' AND i.status = 'paid')::int AS paid_n, COALESCE(sum(i.total) FILTER (WHERE i.type = 'invoice' AND i.status = 'paid'),0) AS paid_amt,
      count(*) FILTER (WHERE i.type = 'invoice' AND i.status IN ('issued','partially_paid'))::int AS unpaid_n, COALESCE(sum(i.total) FILTER (WHERE i.type = 'invoice' AND i.status IN ('issued','partially_paid')),0) AS unpaid_amt
     FROM invoices i WHERE i.hotel_id = $1 AND (i.issued_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`, [c.hotelId, from, to, c.tz]);
  const ht = n0(r.ht), vat = n0(r.vat), tourist = n0(r.tourist);
  return { ht: r2(ht), vat: r2(vat), tourist: r2(tourist), ttc: r2(ht + vat + tourist), discounts: r2(n0(d.discounts)), credits: r2(n0(d.credits)), credit_n: d.credit_n, paid_n: d.paid_n, paid_amt: r2(n0(d.paid_amt)), unpaid_n: d.unpaid_n, unpaid_amt: r2(n0(d.unpaid_amt)) };
}
async function cashBalance(c: Ctx) {
  const regs = await q<any>(c.db, `SELECT cr.id, cr.name, s.id AS session_id, s.status, s.declared_amount FROM cash_registers cr
     LEFT JOIN LATERAL (SELECT * FROM cash_sessions cs WHERE cs.cash_register_id = cr.id ORDER BY cs.opened_at DESC LIMIT 1) s ON true WHERE cr.hotel_id = $1 AND cr.active ORDER BY cr.name`, [c.hotelId]);
  const out: { name: string; status: string; amount: number }[] = [];
  for (const r of regs) {
    if (!r.session_id) { out.push({ name: r.name, status: 'Jamais ouverte', amount: 0 }); continue; }
    if (r.status === 'open') { const s = await sessionSummary(c.db, c.hotelId, r.session_id); out.push({ name: r.name, status: 'Ouverte (théorique)', amount: n0(s.totals.expected) }); }
    else out.push({ name: r.name, status: 'Clôturée (compté)', amount: n0(r.declared_amount) });
  }
  return { registers: out, total: r2(out.reduce((s, x) => s + x.amount, 0)) };
}
export async function finance(c: Ctx): Promise<Section> {
  const [cur, prev] = await both(c, async (f, t) => ({ b: await billed(c, f, t), cf: await cashFlows(c, f, t) }));
  const rec = await receivablesTotal(c);
  const cash = await cashBalance(c);
  const kpis = [
    kpi('billed_ttc', 'CA facturé TTC (factures − avoirs)', 'money', cur.b.ttc, prev?.b.ttc, { drill: 'invoices' }),
    kpi('billed_ht', 'CA facturé HT', 'money', cur.b.ht, prev?.b.ht, { drill: 'invoices' }),
    kpi('vat', 'TVA collectée', 'money', cur.b.vat, prev?.b.vat, { better: null }),
    kpi('tourist', 'Taxe de séjour', 'money', cur.b.tourist, prev?.b.tourist, { better: null }),
    kpi('collected', 'Encaissements nets', 'money', cur.cf.collected, prev?.cf.collected, { drill: 'payments' }),
    kpi('refunds', 'Remboursements', 'money', cur.cf.refunds, prev?.cf.refunds, { better: 'down', drill: 'refunds' }),
    kpi('discounts', 'Remises accordées', 'money', cur.b.discounts, prev?.b.discounts, { better: 'down' }),
    kpi('credits', 'Avoirs émis', 'money', cur.b.credits, prev?.b.credits, { better: 'down', drill: 'credit_notes', hint: `${cur.b.credit_n} avoir(s)` }),
    kpi('expenses', 'Dépenses', 'money', cur.cf.expenses, prev?.cf.expenses, { better: 'down', drill: 'expenses' }),
    kpi('net_cash', 'Encaissé − dépensé', 'money', r2(cur.cf.collected - cur.cf.expenses), prev ? r2(prev.cf.collected - prev.cf.expenses) : null),
    kpi('paid', 'Factures payées', 'money', cur.b.paid_amt, prev?.b.paid_amt, { hint: `${cur.b.paid_n} facture(s)`, drill: 'invoices' }),
    kpi('unpaid', 'Factures impayées (période)', 'money', cur.b.unpaid_amt, prev?.b.unpaid_amt, { better: 'down', hint: `${cur.b.unpaid_n} facture(s)`, drill: 'invoices_unpaid' }),
    kpi('receivables', 'Créances clients (à ce jour)', 'money', rec.total, null, { better: 'down', drill: 'receivables', hint: `${rec.count} dossier(s)` }),
    kpi('cash', 'Solde des caisses', 'money', cash.total, null, { better: null, hint: cash.registers.map((x) => `${x.name} : ${x.status}`).join(' · ') }),
  ];
  const P = [c.hotelId, c.P.from, c.P.to, c.tz];
  const depts = await q<any>(c.db, `SELECT ${DEPT_SQL} AS k, COALESCE(sum(it.total),0) AS ht, COALESCE(sum(it.tax_amount),0) AS vat FROM invoices i JOIN invoice_items it ON it.invoice_id = i.id
     WHERE i.hotel_id = $1 AND i.type IN ('invoice','credit_note') AND (i.issued_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY 1 ORDER BY 2 DESC`, P);
  const methods = await q<any>(c.db, `SELECT method, sum(inn) AS received, sum(outt) AS refunded, sum(n)::int AS n FROM (
      SELECT method, amount AS inn, 0 AS outt, 1 AS n FROM payments WHERE hotel_id = $1 AND NOT void AND (received_at AT TIME ZONE $4)::date BETWEEN $2 AND $3
      UNION ALL SELECT method, amount, 0, 1 FROM incomes WHERE hotel_id = $1 AND NOT void AND (created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3
      UNION ALL SELECT f.method, 0, f.amount, 1 FROM refunds f LEFT JOIN reservations r ON r.id = f.reservation_id LEFT JOIN invoices i ON i.id = f.invoice_id
        WHERE COALESCE(r.hotel_id, i.hotel_id) = $1 AND (f.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3) x GROUP BY 1 ORDER BY 2 DESC`, P);
  const expCat = await q<any>(c.db, `SELECT category AS label, count(*)::int AS n, sum(amount) AS amount FROM expenses WHERE hotel_id = $1 AND NOT void AND expense_date BETWEEN $2 AND $3 GROUP BY 1 ORDER BY 3 DESC`, P.slice(0, 3));
  const billedDay = await q<any>(c.db, `SELECT to_char((i.issued_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS d, sum(it.total + it.tax_amount) AS billed FROM invoices i JOIN invoice_items it ON it.invoice_id = i.id
     WHERE i.hotel_id = $1 AND i.type IN ('invoice','credit_note') AND (i.issued_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY 1`, P);
  const cfd = await cashFlowsByDay(c);
  const B = bucketize([...billedDay, ...cfd], c.P.from, c.P.to, c.P.group, ['billed', 'inn', 'outt']);
  const mrows = methods.map((m) => ({ label: METHOD_LBL[m.method] ?? m.method, n: m.n, received: r2(n0(m.received)), refunded: r2(n0(m.refunded)), net: r2(n0(m.received) - n0(m.refunded)) }));
  const drows = depts.map((d) => ({ label: DEPT_LBL[d.k] ?? d.k, ht: r2(n0(d.ht)), vat: r2(n0(d.vat)), ttc: r2(n0(d.ht) + n0(d.vat)) }));
  return {
    kpis,
    charts: [
      line('evolution', 'Facturé, encaissé et dépensé', 'money', B.labels, [{ name: 'Facturé TTC', values: B.values('billed') }, { name: 'Encaissé net', values: B.values('inn') }, { name: 'Dépenses', values: B.values('outt') }]),
      pie('departments', 'CA facturé par département (HT)', 'money', drows.filter((x) => x.label !== DEPT_LBL.tax).map((x) => ({ label: x.label, value: x.ht }))),
      pie('methods', 'Encaissements par mode de paiement', 'money', mrows.map((x) => ({ label: x.label, value: x.net }))),
      bar('expenses', 'Dépenses par catégorie', 'money', expCat.map((x) => x.label), [{ name: 'Dépenses', values: expCat.map((x) => r2(n0(x.amount))) }]),
    ],
    tables: [
      { key: 'departments', title: 'CA facturé par département', columns: [col('label', 'Département'), col('ht', 'HT', 'money'), col('vat', 'TVA', 'money'), col('ttc', 'TTC', 'money')], rows: drows,
        total: { label: 'Total', ht: r2(drows.reduce((s, x) => s + x.ht, 0)), vat: r2(drows.reduce((s, x) => s + x.vat, 0)), ttc: r2(drows.reduce((s, x) => s + x.ttc, 0)) } },
      { key: 'methods', title: 'Encaissements par mode de paiement', columns: [col('label', 'Mode'), col('n', 'Opérations', 'int'), col('received', 'Encaissé', 'money'), col('refunded', 'Remboursé', 'money'), col('net', 'Net', 'money')], rows: mrows,
        total: { label: 'Total', n: mrows.reduce((s, x) => s + x.n, 0), received: r2(mrows.reduce((s, x) => s + x.received, 0)), refunded: r2(mrows.reduce((s, x) => s + x.refunded, 0)), net: r2(mrows.reduce((s, x) => s + x.net, 0)) } },
      { key: 'expenses', title: 'Dépenses par catégorie', columns: [col('label', 'Catégorie'), col('n', 'Opérations', 'int'), col('amount', 'Montant', 'money')], rows: expCat.map((x) => ({ ...x, amount: r2(n0(x.amount)) })),
        total: { label: 'Total', n: expCat.reduce((s, x) => s + x.n, 0), amount: r2(expCat.reduce((s, x) => s + n0(x.amount), 0)) }, drill: 'expenses' },
      { key: 'cash', title: 'Solde des caisses', columns: [col('name', 'Caisse'), col('status', 'État'), col('amount', 'Montant', 'money')], rows: cash.registers, total: { name: 'Total', amount: cash.total } },
    ],
    notes: ['Facturé = factures émises − avoirs (date d\'émission). Encaissé = paiements + recettes diverses − remboursements (date d\'opération). Les pro forma sont exclues.'],
  };
}

// ===================================================== 6. Restaurant & services =====================================================
const RS_LINES = `lines AS (
  SELECT l.id, l.item_id, l.name, l.quantity, o.id AS oid, o.outlet, o.waiter_id, o.covers, o.settlement, o.invoice_id, o.created_at, i.category_id,
         (l.quantity * l.unit_price - COALESCE(l.discount,0)) * (1 - COALESCE(o.discount_total,0) / NULLIF(o.subtotal,0)) AS net
    FROM rs_order_lines l JOIN rs_orders o ON o.id = l.order_id LEFT JOIN rs_items i ON i.id = l.item_id
   WHERE o.hotel_id = $1 AND o.status <> 'cancelled' AND o.settlement <> 'cancelled' AND NOT l.cancelled AND (o.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3
     AND ($5::text IS NULL OR o.outlet = $5) AND ($6::int IS NULL OR i.category_id = $6))`;
const rsP = (c: Ctx, f: string, t: string) => [c.hotelId, f, t, c.tz, c.F.outlet ?? null, c.F.category ? Number(c.F.category) || null : null];
export async function restaurant(c: Ctx): Promise<Section> {
  const stats = async (f: string, t: string) => {
    const s = await one<any>(c.db, `WITH ${RS_LINES} SELECT COALESCE(sum(net),0) AS ca, count(DISTINCT oid)::int AS orders, COALESCE(sum(quantity),0)::int AS items,
        count(DISTINCT oid) FILTER (WHERE outlet = 'room_service')::int AS room_service FROM lines`, rsP(c, f, t));
    const cov = await one<any>(c.db, `SELECT COALESCE(sum(covers),0)::int AS covers FROM rs_orders o WHERE o.hotel_id = $1 AND o.status <> 'cancelled' AND o.settlement <> 'cancelled'
        AND (o.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR o.outlet = $5)`, rsP(c, f, t).slice(0, 5));
    const x = await one<any>(c.db, `SELECT count(*) FILTER (WHERE o.status = 'cancelled')::int AS cancelled,
        (SELECT avg(EXTRACT(EPOCH FROM (l.ready_at - COALESCE(l.started_at, l.sent_at))) / 60) FROM rs_order_lines l JOIN rs_orders o2 ON o2.id = l.order_id
          WHERE o2.hotel_id = $1 AND NOT l.cancelled AND l.ready_at IS NOT NULL AND COALESCE(l.started_at, l.sent_at) IS NOT NULL AND (o2.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR o2.outlet = $5)) AS prep
       FROM rs_orders o WHERE o.hotel_id = $1 AND (o.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR o.outlet = $5)`, rsP(c, f, t).slice(0, 5));
    return { ca: r2(n0(s.ca)), orders: s.orders, items: s.items, room_service: s.room_service, covers: cov.covers, cancelled: x.cancelled, prep: x.prep === null ? null : r2(n0(x.prep)), ticket: div(n0(s.ca), s.orders) };
  };
  const [cur, prev] = await both(c, stats);
  const P = rsP(c, c.P.from, c.P.to);
  const kpis = [
    kpi('ca', 'Ventes restaurant (HT)', 'money', cur.ca, prev?.ca, { drill: 'rs_orders' }),
    kpi('orders', 'Commandes', 'int', cur.orders, prev?.orders, { drill: 'rs_orders' }),
    kpi('covers', 'Couverts', 'int', cur.covers, prev?.covers),
    kpi('ticket', 'Ticket moyen', 'money', cur.ticket, prev?.ticket),
    kpi('items', 'Articles vendus', 'int', cur.items, prev?.items),
    kpi('room_service', 'Commandes room service', 'int', cur.room_service, prev?.room_service, { drill: 'rs_orders' }),
    kpi('cancelled', 'Commandes annulées', 'int', cur.cancelled, prev?.cancelled, { better: 'down', drill: 'rs_cancelled' }),
    kpi('prep', 'Délai moyen de préparation', 'min', cur.prep, prev?.prep, { better: 'down' }),
  ];
  const daily = await q<any>(c.db, `WITH ${RS_LINES} SELECT to_char((created_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS d, sum(net) AS ca, count(DISTINCT oid)::int AS orders FROM lines GROUP BY 1`, P);
  const B = bucketize(daily, c.P.from, c.P.to, c.P.group, ['ca', 'orders']);
  const cats = await q<any>(c.db, `WITH ${RS_LINES} SELECT COALESCE(cat.name,'Sans catégorie') AS label, sum(quantity)::int AS qty, sum(net) AS ca FROM lines LEFT JOIN rs_categories cat ON cat.id = lines.category_id GROUP BY 1 ORDER BY 3 DESC`, P);
  const items = await q<any>(c.db, `WITH ${RS_LINES} SELECT it.id, it.name AS label, COALESCE(cat.name,'') AS category, COALESCE(s.qty,0)::int AS qty, COALESCE(s.ca,0) AS ca
      FROM rs_items it LEFT JOIN rs_categories cat ON cat.id = it.category_id LEFT JOIN (SELECT item_id, sum(quantity) AS qty, sum(net) AS ca FROM lines GROUP BY item_id) s ON s.item_id = it.id
     WHERE it.hotel_id = $1 AND it.active AND ($6::int IS NULL OR it.category_id = $6) ORDER BY qty DESC, it.name`, P);
  const waiters = await q<any>(c.db, `WITH ${RS_LINES} SELECT COALESCE(u.full_name,'Non attribué') AS label, count(DISTINCT oid)::int AS orders, sum(net) AS ca FROM lines LEFT JOIN users u ON u.id = lines.waiter_id GROUP BY 1 ORDER BY 3 DESC`, P);
  const outlets = await q<any>(c.db, `WITH ${RS_LINES} SELECT outlet AS k, count(DISTINCT oid)::int AS orders, sum(net) AS ca FROM lines GROUP BY 1 ORDER BY 3 DESC`, P);
  const pays = await q<any>(c.db, `SELECT COALESCE(p.method, o.settlement) AS k, count(DISTINCT o.id)::int AS orders, COALESCE(sum(p.amount), sum(o.total) FILTER (WHERE p.id IS NULL), 0) AS amount
      FROM rs_orders o LEFT JOIN payments p ON p.invoice_id = o.invoice_id AND NOT p.void AND o.settlement = 'paid'
     WHERE o.hotel_id = $1 AND o.status <> 'cancelled' AND o.settlement <> 'cancelled' AND (o.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR o.outlet = $5)
     GROUP BY 1 ORDER BY 3 DESC`, P.slice(0, 5));
  const it = items.map((x) => ({ label: x.label, category: x.category, qty: x.qty, ca: r2(n0(x.ca)) }));
  const IC = [col('label', 'Article'), col('category', 'Catégorie'), col('qty', 'Quantité', 'int'), col('ca', 'Ventes HT', 'money')];
  return {
    kpis,
    charts: [
      line('sales', 'Ventes par période', 'money', B.labels, [{ name: 'Ventes HT', values: B.values('ca') }]),
      bar('orders', 'Commandes par période', 'int', B.labels, [{ name: 'Commandes', values: B.values('orders') }]),
      pie('categories', 'Ventes par catégorie', 'money', cats.map((x) => ({ label: x.label, value: n0(x.ca) }))),
      bar('top', 'Plats les plus vendus', 'int', it.slice(0, 10).map((x) => x.label), [{ name: 'Quantité', values: it.slice(0, 10).map((x) => x.qty) }]),
      bar('waiters', 'Ventes par serveur', 'money', waiters.map((x) => x.label), [{ name: 'Ventes HT', values: waiters.map((x) => r2(n0(x.ca))) }]),
      pie('payments', 'Règlements (TTC) par mode', 'money', pays.map((x) => ({ label: METHOD_LBL[x.k] ?? x.k, value: n0(x.amount) }))),
    ],
    tables: [
      { key: 'outlets', title: 'Performance des points de vente', columns: [col('label', 'Point de vente'), col('orders', 'Commandes', 'int'), col('ca', 'Ventes HT', 'money'), col('ticket', 'Ticket moyen', 'money')],
        rows: outlets.map((x) => ({ label: OUTLET_LBL[x.k] ?? x.k, orders: x.orders, ca: r2(n0(x.ca)), ticket: div(n0(x.ca), x.orders) })) },
      { key: 'categories', title: 'Chiffre d\'affaires par catégorie', columns: [col('label', 'Catégorie'), col('qty', 'Quantité', 'int'), col('ca', 'Ventes HT', 'money')], rows: cats.map((x) => ({ ...x, ca: r2(n0(x.ca)) })),
        total: { label: 'Total', qty: cats.reduce((s, x) => s + x.qty, 0), ca: r2(cats.reduce((s, x) => s + n0(x.ca), 0)) } },
      { key: 'top', title: 'Plats les plus vendus', columns: IC, rows: it.filter((x) => x.qty > 0).slice(0, 20) },
      { key: 'least', title: 'Produits les moins vendus (carte active)', columns: IC, rows: [...it].sort((a, b) => a.qty - b.qty || a.label.localeCompare(b.label)).slice(0, 20) },
      { key: 'waiters', title: 'Ventes par serveur', columns: [col('label', 'Serveur'), col('orders', 'Commandes', 'int'), col('ca', 'Ventes HT', 'money'), col('ticket', 'Ticket moyen', 'money')],
        rows: waiters.map((x) => ({ label: x.label, orders: x.orders, ca: r2(n0(x.ca)), ticket: div(n0(x.ca), x.orders) })) },
      { key: 'payments', title: 'Ventes par mode de règlement (TTC)', columns: [col('label', 'Mode'), col('orders', 'Commandes', 'int'), col('amount', 'Montant TTC', 'money')],
        rows: pays.map((x) => ({ label: METHOD_LBL[x.k] ?? x.k, orders: x.orders, amount: r2(n0(x.amount)) })) },
    ],
    notes: ['Ventes HT après remises (la remise de commande est répartie au prorata des lignes). Les ventes portées sur la chambre ne sont comptées qu\'une fois (ici, pas dans « services »).'],
  };
}

// ===================================================== 7. Housekeeping =====================================================
export async function housekeeping(c: Ctx): Promise<Section> {
  const P = (f: string, t: string) => [c.hotelId, f, t, c.tz, c.F.category ?? null];
  const W = `r.hotel_id = $1 AND ($5::text IS NULL OR t.kind = $5)`;
  const stats = async (f: string, t: string) => {
    const s = await one<any>(c.db, `SELECT count(*)::int AS done,
        count(DISTINCT (t.room_id, (t.completed_at AT TIME ZONE $4)::date)) FILTER (WHERE t.kind IN ('checkout_clean','stayover','arrival_prep','deep_clean'))::int AS rooms,
        avg(EXTRACT(EPOCH FROM (t.completed_at - t.started_at)) / 60) FILTER (WHERE t.started_at IS NOT NULL AND t.completed_at > t.started_at) AS avg_min,
        count(*) FILTER (WHERE t.due_at IS NOT NULL AND t.completed_at > t.due_at)::int AS late, count(DISTINCT t.completed_by)::int AS staff
       FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id WHERE ${W} AND t.status IN ('done','to_inspect','validated') AND (t.completed_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`, P(f, t));
    const i = await one<any>(c.db, `SELECT count(*)::int AS n, count(*) FILTER (WHERE i.result = 'passed')::int AS passed, count(*) FILTER (WHERE i.result = 'failed')::int AS failed
       FROM hk_inspections i JOIN rooms r ON r.id = i.room_id WHERE r.hotel_id = $1 AND (i.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`, P(f, t).slice(0, 4));
    const open = await one<any>(c.db, `SELECT count(*)::int AS late_open FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id WHERE ${W} AND t.status IN ('todo','in_progress') AND t.task_date BETWEEN $2 AND $3 AND t.due_at < now() AND $4::text IS NOT NULL`, P(f, t));
    const days = Math.max(1, Math.min(c.P.days, 3700));
    return { done: s.done, rooms: s.rooms, avg_min: s.avg_min === null ? null : r2(n0(s.avg_min)), late: s.late + open.late_open, inspected: i.n, passed: i.passed, failed: i.failed, refusal: pct(i.failed, i.n), productivity: div(s.done, Math.max(1, s.staff) * days) };
  };
  const [cur, prev] = await both(c, stats);
  const pending = await one<any>(c.db, `SELECT count(*)::int AS n FROM rooms WHERE hotel_id = $1 AND active AND NOT out_of_service AND hk_status IN ('dirty','to_clean','cleaning')`, [c.hotelId]);
  const kpis = [
    kpi('done', 'Tâches terminées', 'int', cur.done, prev?.done, { drill: 'hk_done' }),
    kpi('rooms', 'Chambres nettoyées', 'int', cur.rooms, prev?.rooms, { drill: 'hk_done' }),
    kpi('inspected', 'Chambres inspectées', 'int', cur.inspected, prev?.inspected, { drill: 'hk_inspections' }),
    kpi('failed', 'Refusées à l\'inspection', 'int', cur.failed, prev?.failed, { better: 'down', drill: 'hk_inspections', hint: `${cur.refusal} % des inspections` }),
    kpi('pending', 'En attente de nettoyage (maintenant)', 'int', pending.n, null, { better: 'down' }),
    kpi('avg_min', 'Durée moyenne de nettoyage', 'min', cur.avg_min, prev?.avg_min, { better: 'down' }),
    kpi('late', 'Tâches en retard', 'int', cur.late, prev?.late, { better: 'down', drill: 'hk_late' }),
    kpi('productivity', 'Tâches / employé / jour', 'num', cur.productivity, prev?.productivity),
  ];
  const daily = await q<any>(c.db, `SELECT to_char((t.completed_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS d, count(*)::int AS done FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id
     WHERE ${W} AND t.status IN ('done','to_inspect','validated') AND (t.completed_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY 1`, P(c.P.from, c.P.to));
  const insp = await q<any>(c.db, `SELECT to_char((i.created_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS d, count(*) FILTER (WHERE result = 'passed')::int AS passed, count(*) FILTER (WHERE result = 'failed')::int AS failed
     FROM hk_inspections i JOIN rooms r ON r.id = i.room_id WHERE r.hotel_id = $1 AND (i.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY 1`, P(c.P.from, c.P.to).slice(0, 4));
  const B = bucketize([...daily, ...insp], c.P.from, c.P.to, c.P.group, ['done', 'passed', 'failed']);
  const staff = await q<any>(c.db, `SELECT COALESCE(u.full_name,'—') AS label, count(*)::int AS done,
      count(*) FILTER (WHERE t.kind IN ('checkout_clean','stayover','arrival_prep','deep_clean'))::int AS rooms,
      avg(EXTRACT(EPOCH FROM (t.completed_at - t.started_at)) / 60) FILTER (WHERE t.started_at IS NOT NULL AND t.completed_at > t.started_at) AS avg_min,
      count(*) FILTER (WHERE t.due_at IS NOT NULL AND t.completed_at > t.due_at)::int AS late, COALESCE(sum(t.refusal_count),0)::int AS refused,
      count(DISTINCT (t.completed_at AT TIME ZONE $4)::date)::int AS days
     FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id LEFT JOIN users u ON u.id = t.completed_by
    WHERE ${W} AND t.status IN ('done','to_inspect','validated') AND (t.completed_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY 1 ORDER BY 2 DESC`, P(c.P.from, c.P.to));
  const KIND: Record<string, string> = { checkout_clean: 'Ménage départ', stayover: 'Recouche', arrival_prep: 'Préparation arrivée', deep_clean: 'Grand ménage', inspection: 'Inspection', turndown: 'Couverture', other: 'Autre' };
  const kinds = await q<any>(c.db, `SELECT t.kind AS k, count(*)::int AS n FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id WHERE ${W} AND t.status IN ('done','to_inspect','validated') AND (t.completed_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY 1 ORDER BY 2 DESC`, P(c.P.from, c.P.to));
  const srows = staff.map((x) => ({ ...x, avg_min: x.avg_min === null ? '' : r2(n0(x.avg_min)), per_day: div(x.done, x.days) }));
  return {
    kpis,
    charts: [
      bar('daily', 'Tâches terminées par période', 'int', B.labels, [{ name: 'Terminées', values: B.values('done') }]),
      line('inspections', 'Inspections', 'int', B.labels, [{ name: 'Validées', values: B.values('passed') }, { name: 'Refusées', values: B.values('failed') }]),
      bar('staff', 'Productivité par employé', 'int', srows.map((x) => x.label), [{ name: 'Tâches', values: srows.map((x) => x.done) }]),
      pie('kinds', 'Tâches par type', 'int', kinds.map((x) => ({ label: KIND[x.k] ?? x.k, value: x.n }))),
    ],
    tables: [{ key: 'staff', title: 'Performance par employé', drill: 'hk_done', columns: [col('label', 'Employé'), col('done', 'Tâches', 'int'), col('rooms', 'Chambres', 'int'), col('per_day', 'Tâches / jour', 'num'), col('avg_min', 'Durée moy. (min)', 'num'), col('late', 'En retard', 'int'), col('refused', 'Refus', 'int')], rows: srows }],
  };
}

// ===================================================== 8. Stocks & achats =====================================================
export async function stock(c: Ctx): Promise<Section> {
  const P = (f: string, t: string) => [c.hotelId, f, t, c.tz, c.F.department ?? null, c.F.category ?? null];
  const MW = `p.hotel_id = $1 AND (m.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR m.department = $5) AND ($6::text IS NULL OR p.category = $6)`;
  const V = `COALESCE(m.value, m.quantity * COALESCE(m.unit_cost, p.avg_cost, 0), 0)`;
  const stats = async (f: string, t: string) => {
    const s = await one<any>(c.db, `SELECT
        COALESCE(sum(${V}) FILTER (WHERE m.quantity > 0 AND m.kind NOT IN ('transfer_in')),0) AS entries,
        COALESCE(-sum(${V}) FILTER (WHERE m.quantity < 0 AND m.kind NOT IN ('transfer_out')),0) AS exits,
        COALESCE(-sum(${V}) FILTER (WHERE m.kind IN ('sale','issue','out')),0) AS consumption,
        COALESCE(-sum(${V}) FILTER (WHERE m.kind IN ('waste','damaged','expired')),0) AS losses
       FROM stock_movements m JOIN products p ON p.id = m.product_id WHERE ${MW}`, P(f, t));
    const pur = await one<any>(c.db, `SELECT COALESCE(sum(pr.value),0) AS v, count(*)::int AS n FROM purchase_receipts pr WHERE pr.hotel_id = $1 AND (pr.received_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`, P(f, t).slice(0, 4));
    return { entries: r2(n0(s.entries)), exits: r2(n0(s.exits)), consumption: r2(n0(s.consumption)), losses: r2(n0(s.losses)), purchases: r2(n0(pur.v)), receipts: pur.n };
  };
  const [cur, prev] = await both(c, stats);
  const snap = await one<any>(c.db, `SELECT COALESCE(sum(sl.qty * COALESCE(p.avg_cost, p.cost_price, 0)),0) AS value,
      (SELECT count(*) FROM products x WHERE x.hotel_id = $1 AND x.active AND x.archived_at IS NULL AND x.stock_qty <= 0 AND ($2::text IS NULL OR x.category = $2))::int AS out_n,
      (SELECT count(*) FROM products x WHERE x.hotel_id = $1 AND x.active AND x.archived_at IS NULL AND x.stock_qty > 0 AND x.stock_qty < x.min_stock AND ($2::text IS NULL OR x.category = $2))::int AS low_n,
      (SELECT count(*) FROM stock_lots l JOIN products x ON x.id = l.product_id WHERE x.hotel_id = $1 AND l.qty > 0 AND l.expiry_date IS NOT NULL AND l.expiry_date <= $3::date + 30)::int AS exp_n
     FROM stock_levels sl JOIN products p ON p.id = sl.product_id WHERE p.hotel_id = $1 AND p.active AND ($2::text IS NULL OR p.category = $2)`, [c.hotelId, c.F.category ?? null, c.P.today]);
  const kpis = [
    kpi('value', 'Valeur totale du stock (à ce jour)', 'money', r2(n0(snap.value)), null, { better: null, hint: 'Valorisation au coût moyen pondéré' }),
    kpi('entries', 'Entrées de stock', 'money', cur.entries, prev?.entries, { better: null, drill: 'stock_in' }),
    kpi('exits', 'Sorties de stock', 'money', cur.exits, prev?.exits, { better: null, drill: 'stock_out' }),
    kpi('consumption', 'Consommation', 'money', cur.consumption, prev?.consumption, { better: null, drill: 'stock_out' }),
    kpi('purchases', 'Coûts d\'approvisionnement', 'money', cur.purchases, prev?.purchases, { better: null, hint: `${cur.receipts} réception(s)` }),
    kpi('losses', 'Pertes et produits détériorés', 'money', cur.losses, prev?.losses, { better: 'down', drill: 'stock_losses' }),
    kpi('out', 'Produits en rupture', 'int', snap.out_n, null, { better: 'down', drill: 'stock_alerts', hint: `${snap.low_n} sous le minimum` }),
    kpi('expiring', 'Lots périmés ou < 30 jours', 'int', snap.exp_n, null, { better: 'down', drill: 'stock_expiring' }),
  ];
  const daily = await q<any>(c.db, `SELECT to_char((m.created_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS d,
      COALESCE(-sum(${V}) FILTER (WHERE m.kind IN ('sale','issue','out')),0) AS consumption, COALESCE(sum(${V}) FILTER (WHERE m.quantity > 0 AND m.kind <> 'transfer_in'),0) AS entries
     FROM stock_movements m JOIN products p ON p.id = m.product_id WHERE ${MW} GROUP BY 1`, P(c.P.from, c.P.to));
  const B = bucketize(daily, c.P.from, c.P.to, c.P.group, ['consumption', 'entries']);
  // Valeur du stock en fin de chaque période = valeur actuelle − mouvements postérieurs
  const after = await q<any>(c.db, `SELECT to_char((m.created_at AT TIME ZONE $3)::date,'YYYY-MM-DD') AS d, sum(${V}) AS v FROM stock_movements m JOIN products p ON p.id = m.product_id
     WHERE p.hotel_id = $1 AND (m.created_at AT TIME ZONE $3)::date >= $2 AND ($4::text IS NULL OR p.category = $4) GROUP BY 1`, [c.hotelId, c.P.from, c.tz, c.F.category ?? null]);
  const valueAt = (endDay: string) => r2(n0(snap.value) - after.filter((x) => x.d > endDay).reduce((s, x) => s + n0(x.v), 0));
  const endOf = (k: string) => (c.P.group === 'day' ? k : c.P.group === 'week' ? addDaysLocal(k, 6) : c.P.group === 'month' ? `${k}-${new Date(Date.UTC(+k.slice(0, 4), +k.slice(5, 7), 0)).getUTCDate()}` : `${k}-12-31`);
  const top = await q<any>(c.db, `SELECT p.name AS label, p.unit, -sum(m.quantity) AS qty, -sum(${V}) AS value FROM stock_movements m JOIN products p ON p.id = m.product_id
     WHERE ${MW} AND m.kind IN ('sale','issue','out') GROUP BY p.id, p.name, p.unit ORDER BY 4 DESC LIMIT 15`, P(c.P.from, c.P.to));
  const sup = await q<any>(c.db, `SELECT COALESCE(s.name,'Sans fournisseur') AS label, count(*)::int AS n, sum(pr.value) AS value FROM purchase_receipts pr LEFT JOIN purchase_orders po ON po.id = pr.po_id LEFT JOIN suppliers s ON s.id = po.supplier_id
     WHERE pr.hotel_id = $1 AND (pr.received_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY 1 ORDER BY 3 DESC`, P(c.P.from, c.P.to).slice(0, 4));
  const kinds = await q<any>(c.db, `SELECT m.kind AS k, count(*)::int AS n, sum(m.quantity) AS qty, sum(${V}) AS value FROM stock_movements m JOIN products p ON p.id = m.product_id WHERE ${MW} GROUP BY 1 ORDER BY 1`, P(c.P.from, c.P.to));
  const KL: Record<string, string> = { in: 'Entrée', out: 'Sortie', adjust: 'Ajustement', sale: 'Vente', waste: 'Perte', receipt: 'Réception achat', issue: 'Sortie service', transfer_out: 'Transfert sortant', transfer_in: 'Transfert entrant', supplier_return: 'Retour fournisseur', inventory: 'Inventaire', damaged: 'Détérioré', expired: 'Périmé' };
  return {
    kpis,
    charts: [
      line('value', 'Évolution de la valeur du stock', 'money', B.labels, [{ name: 'Valeur en fin de période', values: B.labels.map((k) => valueAt(endOf(k) > c.P.to ? c.P.to : endOf(k))) }]),
      bar('flows', 'Entrées et consommation', 'money', B.labels, [{ name: 'Entrées', values: B.values('entries') }, { name: 'Consommation', values: B.values('consumption') }]),
      bar('suppliers', 'Achats par fournisseur', 'money', sup.map((x) => x.label), [{ name: 'Achats', values: sup.map((x) => r2(n0(x.value))) }]),
      bar('top', 'Produits les plus consommés (valeur)', 'money', top.map((x) => x.label), [{ name: 'Consommation', values: top.map((x) => r2(n0(x.value))) }]),
    ],
    tables: [
      { key: 'movements', title: 'Mouvements par type', columns: [col('label', 'Type'), col('n', 'Mouvements', 'int'), col('value', 'Valeur', 'money')], rows: kinds.map((x) => ({ label: KL[x.k] ?? x.k, n: x.n, value: r2(n0(x.value)) })) },
      { key: 'top', title: 'Produits les plus consommés', columns: [col('label', 'Produit'), col('qty', 'Quantité'), col('unit', 'Unité'), col('value', 'Valeur', 'money')], rows: top.map((x) => ({ ...x, qty: r2(n0(x.qty)), value: r2(n0(x.value)) })) },
      { key: 'suppliers', title: 'Achats par fournisseur', columns: [col('label', 'Fournisseur'), col('n', 'Réceptions', 'int'), col('value', 'Montant', 'money')], rows: sup.map((x) => ({ ...x, value: r2(n0(x.value)) })),
        total: { label: 'Total', n: sup.reduce((s, x) => s + x.n, 0), value: r2(sup.reduce((s, x) => s + n0(x.value), 0)) } },
    ],
    notes: ['Transferts entre entrepôts exclus des entrées / sorties (mouvements internes).'],
  };
}
function addDaysLocal(d: string, n: number) { const t = Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10)) + n * 86_400_000; return new Date(t).toISOString().slice(0, 10); }

// ===================================================== 9. Maintenance =====================================================
export async function maintenance(c: Ctx): Promise<Section> {
  const P = (f: string, t: string) => [c.hotelId, f, t, c.tz, c.F.category ?? null];
  const EQ = `($5::text IS NULL OR EXISTS (SELECT 1 FROM equipment e WHERE e.id = w.equipment_id AND e.category = $5))`;
  const stats = async (f: string, t: string) => {
    const w = await one<any>(c.db, `SELECT count(*)::int AS done, COALESCE(sum(w.total_cost),0) AS cost,
        avg(EXTRACT(EPOCH FROM (w.completed_at - w.created_at)) / 3600) FILTER (WHERE w.kind = 'corrective') AS repair_h,
        count(*) FILTER (WHERE w.kind = 'preventive')::int AS preventive, avg(w.rating) AS rating
       FROM work_orders w WHERE w.hotel_id = $1 AND w.status IN ('done','validated') AND (w.completed_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ${EQ}`, P(f, t));
    const tk = await one<any>(c.db, `SELECT count(*)::int AS n FROM maintenance_tickets w WHERE w.hotel_id = $1 AND (w.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ${EQ}`, P(f, t));
    const blk = await one<any>(c.db, `SELECT COALESCE(sum(GREATEST(0, LEAST(COALESCE(b.end_date, $3::date + 1), CASE WHEN b.status = 'released' THEN COALESCE((b.released_at AT TIME ZONE $4)::date, $3::date + 1) ELSE $3::date + 1 END, $3::date + 1) - GREATEST(b.start_date, $2::date))),0)::int AS nights,
        count(DISTINCT b.room_id)::int AS rooms
       FROM room_blocks b JOIN rooms r ON r.id = b.room_id WHERE r.hotel_id = $1 AND b.kind = 'maintenance' AND b.start_date <= $3`, P(f, t).slice(0, 4));
    return { done: w.done, cost: r2(n0(w.cost)), repair_h: w.repair_h === null ? null : r2(n0(w.repair_h)), preventive: w.preventive, rating: w.rating === null ? null : r2(n0(w.rating)), tickets: tk.n, room_nights: blk.nights, rooms: blk.rooms };
  };
  const [cur, prev] = await both(c, stats);
  const open = await one<any>(c.db, `SELECT count(*)::int AS n FROM work_orders w WHERE w.hotel_id = $1 AND w.status IN ('planned','in_progress','on_hold') AND ($2::text IS NULL OR EXISTS (SELECT 1 FROM equipment e WHERE e.id = w.equipment_id AND e.category = $2))`, [c.hotelId, c.F.category ?? null]);
  const kpis = [
    kpi('done', 'Interventions réalisées', 'int', cur.done, prev?.done, { drill: 'wo_done' }),
    kpi('open', 'Interventions en attente (à ce jour)', 'int', open.n, null, { better: 'down', drill: 'wo_open' }),
    kpi('tickets', 'Pannes signalées', 'int', cur.tickets, prev?.tickets, { better: 'down', drill: 'tickets' }),
    kpi('cost', 'Coûts de maintenance', 'money', cur.cost, prev?.cost, { better: 'down', drill: 'wo_done' }),
    kpi('repair_h', 'Délai moyen de réparation', 'hours', cur.repair_h, prev?.repair_h, { better: 'down' }),
    kpi('preventive', 'Préventifs réalisés', 'int', cur.preventive, prev?.preventive),
    kpi('room_nights', 'Nuits-chambre indisponibles (maintenance)', 'int', cur.room_nights, prev?.room_nights, { better: 'down', drill: 'blocks', hint: `${cur.rooms} chambre(s)` }),
    kpi('rating', 'Satisfaction des interventions', 'score', cur.rating, prev?.rating),
  ];
  const CAT: Record<string, string> = { hvac: 'Climatisation', heating: 'Chauffage', plumbing: 'Plomberie', electrical: 'Électricité', elevator: 'Ascenseur', kitchen: 'Cuisine', furniture: 'Mobilier', it: 'Informatique', fire_safety: 'Sécurité incendie', other: 'Autre' };
  const PP = P(c.P.from, c.P.to);
  const cats = await q<any>(c.db, `SELECT COALESCE(e.category, w.category, 'other') AS k, count(*)::int AS n FROM maintenance_tickets w LEFT JOIN equipment e ON e.id = w.equipment_id
     WHERE w.hotel_id = $1 AND (w.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ${EQ} GROUP BY 1 ORDER BY 2 DESC`, PP);
  const eq = await q<any>(c.db, `SELECT e.code || ' · ' || e.name AS label, count(*)::int AS n, COALESCE(sum((SELECT sum(x.total_cost) FROM work_orders x WHERE x.ticket_id = w.id)),0) AS cost
     FROM maintenance_tickets w JOIN equipment e ON e.id = w.equipment_id WHERE w.hotel_id = $1 AND (w.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ${EQ} GROUP BY 1 ORDER BY 2 DESC LIMIT 10`, PP);
  const techs = await q<any>(c.db, `SELECT COALESCE(t.name,'Non affecté') AS label, count(*)::int AS done, COALESCE(sum(w.labor_minutes),0)::int AS minutes, COALESCE(sum(w.total_cost),0) AS cost,
      avg(EXTRACT(EPOCH FROM (w.completed_at - COALESCE(w.started_at, w.created_at))) / 3600) AS hours, avg(w.rating) AS rating
     FROM work_orders w LEFT JOIN maintenance_technicians t ON t.id = w.technician_id
    WHERE w.hotel_id = $1 AND w.status IN ('done','validated') AND (w.completed_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ${EQ} GROUP BY 1 ORDER BY 2 DESC`, PP);
  const costs = await q<any>(c.db, `SELECT to_char((w.completed_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS d, sum(w.total_cost) AS cost, count(*)::int AS done FROM work_orders w
     WHERE w.hotel_id = $1 AND w.status IN ('done','validated') AND (w.completed_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ${EQ} GROUP BY 1`, PP);
  const B = bucketize(costs, c.P.from, c.P.to, c.P.group, ['cost', 'done']);
  return {
    kpis,
    charts: [
      bar('costs', 'Coûts de maintenance par période', 'money', B.labels, [{ name: 'Coût', values: B.values('cost') }]),
      line('done', 'Interventions réalisées', 'int', B.labels, [{ name: 'Interventions', values: B.values('done') }]),
      pie('categories', 'Pannes par catégorie', 'int', cats.map((x) => ({ label: CAT[x.k] ?? x.k, value: x.n }))),
      bar('equipment', 'Équipements les plus souvent en panne', 'int', eq.map((x) => x.label), [{ name: 'Pannes', values: eq.map((x) => x.n) }]),
    ],
    tables: [
      { key: 'technicians', title: 'Performance du service technique', columns: [col('label', 'Technicien'), col('done', 'Interventions', 'int'), col('hours', 'Délai moyen (h)', 'num'), col('minutes', 'Main-d\'œuvre (min)', 'int'), col('cost', 'Coût', 'money'), col('rating', 'Note /5', 'num')],
        rows: techs.map((x) => ({ ...x, cost: r2(n0(x.cost)), hours: x.hours === null ? '' : r2(n0(x.hours)), rating: x.rating === null ? '' : r2(n0(x.rating)) })) },
      { key: 'equipment', title: 'Équipements les plus souvent en panne', columns: [col('label', 'Équipement'), col('n', 'Pannes', 'int'), col('cost', 'Coût', 'money')], rows: eq.map((x) => ({ ...x, cost: r2(n0(x.cost)) })) },
      { key: 'categories', title: 'Pannes par catégorie', columns: [col('label', 'Catégorie'), col('n', 'Pannes', 'int')], rows: cats.map((x) => ({ label: CAT[x.k] ?? x.k, n: x.n })), drill: 'tickets' },
    ],
  };
}

// ===================================================== 10. Ressources humaines =====================================================
export async function hr(c: Ctx): Promise<Section> {
  const s = await scopeOf(c.db, c.actor as any, c.perms);
  const salary = c.perms.has('hr.salary');
  const depts = c.F.department ? [c.F.department] : s.all ? null : s.departments;
  const P = (f: string, t: string) => [c.hotelId, f, t, depts, c.P.today];
  const DW = `($4::text[] IS NULL OR e.department = ANY($4))`;
  const stats = async (f: string, t: string) => {
    const a = await one<any>(c.db, `SELECT count(*) FILTER (WHERE a.clock_in IS NOT NULL)::int AS present, COALESCE(sum(a.worked_minutes),0)::int AS worked,
        count(*) FILTER (WHERE a.late_minutes > 0)::int AS late, COALESCE(sum(a.overtime_minutes),0)::int AS overtime
       FROM hr_attendance a JOIN employees e ON e.id = a.employee_id WHERE a.hotel_id = $1 AND a.work_date BETWEEN $2 AND $3 AND ${DW}`, P(f, t).slice(0, 4));
    const ab = await one<any>(c.db, `SELECT count(*)::int AS n FROM hr_schedule sc JOIN employees e ON e.id = sc.employee_id
       WHERE sc.hotel_id = $1 AND sc.work_date BETWEEN $2 AND $3 AND sc.work_date < $5::date AND NOT sc.rest AND ${DW}
         AND NOT EXISTS (SELECT 1 FROM hr_attendance a WHERE a.employee_id = sc.employee_id AND a.work_date = sc.work_date AND a.clock_in IS NOT NULL)
         AND NOT EXISTS (SELECT 1 FROM hr_leave_requests l WHERE l.employee_id = sc.employee_id AND l.status = 'approved' AND sc.work_date BETWEEN l.start_date AND l.end_date)`, P(f, t));
    const lv = await one<any>(c.db, `SELECT COALESCE(sum(LEAST(l.end_date, $3::date) - GREATEST(l.start_date, $2::date) + 1),0)::int AS days, count(*)::int AS n
       FROM hr_leave_requests l JOIN employees e ON e.id = l.employee_id WHERE l.hotel_id = $1 AND l.status = 'approved' AND l.start_date <= $3 AND l.end_date >= $2 AND ${DW}`, P(f, t).slice(0, 4));
    let payroll: number | null = null;
    if (salary) {
      const pr = await one<any>(c.db, `SELECT COALESCE(sum(ps.gross),0) AS gross FROM hr_payslips ps JOIN hr_payroll_runs r ON r.id = ps.run_id
         WHERE r.hotel_id = $1 AND r.status IN ('validated','paid') AND (r.period || '-01')::date BETWEEN date_trunc('month', $2::date) AND $3 AND ($4::text[] IS NULL OR ps.department = ANY($4))`, P(f, t).slice(0, 4));
      payroll = r2(n0(pr.gross));
    }
    return { present: a.present, hours: r2(a.worked / 60), late: a.late, overtime: r2(a.overtime / 60), absences: ab.n, leave_days: lv.days, leaves: lv.n, payroll };
  };
  const [cur, prev] = await both(c, stats);
  const hc = await one<any>(c.db, `SELECT count(*) FILTER (WHERE e.status <> 'left')::int AS total, count(*) FILTER (WHERE e.status = 'active')::int AS active, count(*) FILTER (WHERE e.status = 'leave')::int AS on_leave
     FROM employees e WHERE e.hotel_id = $1 AND ${DW} AND $2::date IS NULL AND $3::date IS NULL`, [c.hotelId, null, null, depts]);
  const kpis = [
    kpi('employees', 'Nombre d\'employés', 'int', hc.total, null, { better: null, hint: `${hc.active} actifs · ${hc.on_leave} en congé` }),
    kpi('present', 'Présences (jours pointés)', 'int', cur.present, prev?.present),
    kpi('absences', 'Absences non justifiées', 'int', cur.absences, prev?.absences, { better: 'down', drill: 'hr_absences' }),
    kpi('late', 'Retards', 'int', cur.late, prev?.late, { better: 'down', drill: 'hr_late' }),
    kpi('hours', 'Heures travaillées', 'hours', cur.hours, prev?.hours, { better: null }),
    kpi('overtime', 'Heures supplémentaires', 'hours', cur.overtime, prev?.overtime, { better: 'down' }),
    kpi('leave_days', 'Jours de congé', 'int', cur.leave_days, prev?.leave_days, { better: null, drill: 'hr_leaves', hint: `${cur.leaves} demande(s) validée(s)` }),
    ...(salary ? [kpi('payroll', 'Masse salariale brute', 'money', cur.payroll, prev?.payroll, { better: null, hint: 'Bulletins validés / payés des mois de la période' })] : []),
  ];
  const DL = Object.fromEntries((await q<any>(c.db, 'SELECT code, name FROM hr_departments WHERE hotel_id = $1', [c.hotelId])).map((x) => [x.code, x.name]));
  const byDept = await q<any>(c.db, `SELECT COALESCE(e.department,'—') AS k, count(*)::int AS n FROM employees e WHERE e.hotel_id = $1 AND e.status <> 'left' AND ${DW} AND $2::date IS NULL AND $3::date IS NULL GROUP BY 1 ORDER BY 2 DESC`, [c.hotelId, null, null, depts]);
  const PP = P(c.P.from, c.P.to);
  const daily = await q<any>(c.db, `SELECT to_char(a.work_date,'YYYY-MM-DD') AS d, sum(a.worked_minutes) / 60.0 AS hours, count(*) FILTER (WHERE a.late_minutes > 0)::int AS late, sum(a.overtime_minutes) / 60.0 AS overtime
     FROM hr_attendance a JOIN employees e ON e.id = a.employee_id WHERE a.hotel_id = $1 AND a.work_date BETWEEN $2 AND $3 AND ${DW} GROUP BY 1`, PP.slice(0, 4));
  const B = bucketize(daily, c.P.from, c.P.to, c.P.group, ['hours', 'late', 'overtime']);
  const deptStats = await q<any>(c.db, `SELECT COALESCE(e.department,'—') AS k, count(DISTINCT e.id)::int AS employees,
      count(a.id) FILTER (WHERE a.clock_in IS NOT NULL)::int AS present, COALESCE(sum(a.worked_minutes),0) / 60.0 AS hours, count(a.id) FILTER (WHERE a.late_minutes > 0)::int AS late, COALESCE(sum(a.overtime_minutes),0) / 60.0 AS overtime
     FROM employees e LEFT JOIN hr_attendance a ON a.employee_id = e.id AND a.work_date BETWEEN $2 AND $3 WHERE e.hotel_id = $1 AND e.status <> 'left' AND ${DW} GROUP BY 1 ORDER BY 2 DESC`, PP.slice(0, 4));
  const tables: Table[] = [{ key: 'departments', title: 'Répartition et activité par département', columns: [col('label', 'Département'), col('employees', 'Employés', 'int'), col('present', 'Jours présents', 'int'), col('hours', 'Heures', 'num'), col('late', 'Retards', 'int'), col('overtime', 'Heures sup.', 'num')],
    rows: deptStats.map((x) => ({ label: DL[x.k] ?? x.k, employees: x.employees, present: x.present, hours: r2(n0(x.hours)), late: x.late, overtime: r2(n0(x.overtime)) })) }];
  if (salary) {
    const runs = await q<any>(c.db, `SELECT r.period, r.status, count(ps.id)::int AS n, COALESCE(sum(ps.gross),0) AS gross, COALESCE(sum(ps.net),0) AS net, COALESCE(sum(ps.employer_contrib),0) AS employer
       FROM hr_payroll_runs r JOIN hr_payslips ps ON ps.run_id = r.id WHERE r.hotel_id = $1 AND r.status IN ('validated','paid') AND (r.period || '-01')::date BETWEEN date_trunc('month', $2::date) AND $3
         AND ($4::text[] IS NULL OR ps.department = ANY($4)) GROUP BY r.period, r.status ORDER BY r.period`, PP.slice(0, 4));
    tables.push({ key: 'payroll', title: 'Masse salariale (accès restreint)', columns: [col('period', 'Mois'), col('n', 'Salariés', 'int'), col('gross', 'Brut', 'money'), col('net', 'Net', 'money'), col('employer', 'Charges patronales', 'money')],
      rows: runs.map((x) => ({ ...x, gross: r2(n0(x.gross)), net: r2(n0(x.net)), employer: r2(n0(x.employer)) })) });
  }
  return {
    kpis,
    charts: [
      pie('departments', 'Répartition du personnel par département', 'int', byDept.map((x) => ({ label: DL[x.k] ?? x.k, value: x.n }))),
      line('hours', 'Heures travaillées et supplémentaires', 'hours', B.labels, [{ name: 'Heures travaillées', values: B.values('hours') }, { name: 'Heures sup.', values: B.values('overtime') }]),
      bar('late', 'Retards par période', 'int', B.labels, [{ name: 'Retards', values: B.values('late') }]),
    ],
    tables,
    notes: salary ? [] : ['Les données salariales ne sont pas affichées : droit « salaires » requis.'],
  };
}

// ===================================================== 11. CRM & clients =====================================================
export async function crm(c: Ctx): Promise<Section> {
  const stats = async (f: string, t: string) => {
    const g = await one<any>(c.db, `SELECT count(*)::int AS n FROM guests g WHERE g.hotel_id = $1 AND g.merged_into_id IS NULL AND g.anonymized_at IS NULL AND (g.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`, [c.hotelId, f, t, c.tz]);
    const st = await one<any>(c.db, `WITH cl AS (SELECT DISTINCT s.guest_id FROM stays s JOIN rooms r ON r.id = s.room_id WHERE r.hotel_id = $1 AND (s.checked_in_at AT TIME ZONE $4)::date <= $3
          AND COALESCE((s.checked_out_at AT TIME ZONE $4)::date, $3::date) >= $2)
      SELECT count(*)::int AS clients, count(*) FILTER (WHERE EXISTS (SELECT 1 FROM stays s2 WHERE s2.guest_id = cl.guest_id AND (s2.checked_in_at AT TIME ZONE $4)::date < $2))::int AS returning FROM cl`, [c.hotelId, f, t, c.tz]);
    const sv = await one<any>(c.db, `SELECT avg(score) AS score, count(*)::int AS n FROM crm_survey_responses WHERE hotel_id = $1 AND completed_at IS NOT NULL AND (completed_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`, [c.hotelId, f, t, c.tz]);
    const cp = await one<any>(c.db, `SELECT count(*)::int AS n FROM crm_complaints WHERE hotel_id = $1 AND kind = 'complaint' AND (created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`, [c.hotelId, f, t, c.tz]);
    return { new: g.n, clients: st.clients, returning: st.returning, retention: pct(st.returning, st.clients), score: sv.score === null ? null : r2(n0(sv.score)), surveys: sv.n, complaints: cp.n };
  };
  const [cur, prev] = await both(c, stats);
  const snap = await one<any>(c.db, `SELECT count(*) FILTER (WHERE crm_status = 'vip')::int AS vip, count(*) FILTER (WHERE crm_status = 'loyal')::int AS loyal, count(*) FILTER (WHERE loyalty_number IS NOT NULL)::int AS members
     FROM guests WHERE hotel_id = $1 AND merged_into_id IS NULL AND anonymized_at IS NULL`, [c.hotelId]);
  // CA hébergement généré par client (nuitées de la période)
  const { ROOM_CTE, roomParams } = await import('./core.js');
  const top = await q<any>(c.db, `WITH ${ROOM_CTE} SELECT g.id, g.code, g.kind, g.last_name, g.first_name, g.company_name, g.crm_status, COALESCE(g.country, g.nationality, '') AS country, count(*)::int AS nights, sum(n.rate) AS revenue
     FROM nights n JOIN guests g ON g.id = n.guest_id GROUP BY g.id ORDER BY revenue DESC`, roomParams(c, c.P.from, c.P.to));
  const revenue = r2(top.reduce((s, x) => s + n0(x.revenue), 0));
  const kpis = [
    kpi('new', 'Nouveaux clients', 'int', cur.new, prev?.new, { drill: 'new_clients' }),
    kpi('clients', 'Clients ayant séjourné', 'int', cur.clients, prev?.clients),
    kpi('returning', 'Clients récurrents', 'int', cur.returning, prev?.returning),
    kpi('retention', 'Taux de fidélisation', 'pct', cur.retention, prev?.retention, { hint: 'Clients de la période déjà venus auparavant' }),
    kpi('vip', 'Clients VIP', 'int', snap.vip, null, { better: null }),
    kpi('loyal', 'Clients fidèles', 'int', snap.loyal, null, { better: null, hint: `${snap.members} membres du programme` }),
    kpi('score', 'Satisfaction client', 'score', cur.score, prev?.score, { hint: `${cur.surveys} réponse(s)` }),
    kpi('complaints', 'Réclamations', 'int', cur.complaints, prev?.complaints, { better: 'down', drill: 'complaints' }),
    kpi('revenue', 'CA hébergement généré', 'money', revenue, null, { hint: `${top.length} client(s) · moyenne ${fmt('money', div(revenue, top.length), c.currency)}` }),
  ];
  const P = [c.hotelId, c.P.from, c.P.to, c.tz];
  const newDaily = await q<any>(c.db, `SELECT to_char((created_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS d, count(*)::int AS n FROM guests WHERE hotel_id = $1 AND merged_into_id IS NULL AND (created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY 1`, P);
  const svDaily = await q<any>(c.db, `SELECT to_char((completed_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS d, sum(score) AS s, count(score)::int AS k FROM crm_survey_responses WHERE hotel_id = $1 AND completed_at IS NOT NULL AND (completed_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY 1`, P);
  const B = bucketize([...newDaily, ...svDaily], c.P.from, c.P.to, c.P.group, ['n', 's', 'k']);
  const origins = top.reduce((m: Record<string, number>, x) => { const k = x.country || 'Non renseigné'; m[k] = (m[k] ?? 0) + 1; return m; }, {});
  const orows = Object.entries(origins).map(([label, n]) => ({ label, n })).sort((a, b) => b.n - a.n);
  const cats = await q<any>(c.db, `SELECT category AS k, count(*)::int AS n FROM crm_complaints WHERE hotel_id = $1 AND kind = 'complaint' AND (created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 GROUP BY 1 ORDER BY 2 DESC`, P);
  const prefs = await q<any>(c.db, `SELECT p.category, p.value AS label, count(DISTINCT p.guest_id)::int AS n FROM guest_preferences p JOIN guests g ON g.id = p.guest_id
     WHERE g.hotel_id = $1 AND g.merged_into_id IS NULL AND g.anonymized_at IS NULL GROUP BY 1, 2 ORDER BY 3 DESC, 2 LIMIT 20`, [c.hotelId]);
  const PC: Record<string, string> = { room: 'Chambre', dietary: 'Alimentation', service: 'Services', request: 'Demandes', occasion: 'Occasions', habit: 'Habitudes', communication: 'Communication' };
  const CC: Record<string, string> = { room: 'Chambre', cleanliness: 'Propreté', noise: 'Bruit', staff: 'Personnel', food: 'Restauration', billing: 'Facturation', maintenance: 'Équipement', reservation: 'Réservation', wifi: 'Wi-Fi / TV', other: 'Autre' };
  const name = (g: any) => (g.kind !== 'person' ? g.company_name : `${g.last_name ?? ''} ${g.first_name ?? ''}`.trim());
  return {
    kpis,
    charts: [
      line('new', 'Nouveaux clients', 'int', B.labels, [{ name: 'Nouveaux clients', values: B.values('n') }]),
      line('satisfaction', 'Satisfaction moyenne (/5)', 'score', B.labels, [{ name: 'Note', values: B.labels.map((k) => div(B.raw.get(k)!.s, B.raw.get(k)!.k)) }]),
      pie('origins', 'Clients par origine', 'int', orows.slice(0, 8).map((x) => ({ label: x.label, value: x.n }))),
      bar('complaints', 'Réclamations par catégorie', 'int', cats.map((x) => CC[x.k] ?? x.k), [{ name: 'Réclamations', values: cats.map((x) => x.n) }]),
    ],
    tables: [
      { key: 'top', title: 'Chiffre d\'affaires généré par client (hébergement)', columns: [col('code', 'Code'), col('name', 'Client'), col('status', 'Statut'), col('country', 'Origine'), col('nights', 'Nuitées', 'int'), col('revenue', 'CA', 'money')],
        rows: top.slice(0, 50).map((x) => ({ code: x.code, name: name(x), status: ({ standard: 'Standard', loyal: 'Fidèle', vip: 'VIP', company: 'Entreprise' } as any)[x.crm_status], country: x.country, nights: x.nights, revenue: r2(n0(x.revenue)) })),
        total: { name: 'Total', nights: top.reduce((s, x) => s + x.nights, 0), revenue } },
      { key: 'origins', title: 'Clients par origine', columns: [col('label', 'Origine'), col('n', 'Clients', 'int')], rows: orows },
      { key: 'preferences', title: 'Préférences les plus fréquentes', columns: [col('category', 'Catégorie'), col('label', 'Préférence'), col('n', 'Clients', 'int')], rows: prefs.map((x) => ({ ...x, category: PC[x.category] ?? x.category })) },
    ],
    notes: ['Statuts VIP / fidèles et membres : situation à ce jour. Les clients anonymisés sont exclus.'],
  };
}

export const DOMAIN_FN = { overview, reservations, rooms, finance, restaurant, housekeeping, stock, maintenance, hr, crm };
