/** Exports PDF / Excel / CSV des rapports : logo, établissement, titre, période, date de génération, devise, indicateurs, graphiques, tableaux, totaux. */
import ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';
import type { Chart, Col, Kpi, Section, Unit } from './core.js';

export type Meta = { hotel: string; title: string; period: string; compare: string | null; currency: string; filters: string[]; generatedBy: string; tz: string };
const PALETTE = ['#7A1F2B', '#C9A227', '#0E7490', '#1E40AF', '#15803D', '#B45309', '#7C3AED', '#DB2777', '#52525B', '#0F766E'];
const curLabel = (c: string) => (['DZD', 'DA', ''].includes(c) ? 'DA' : c);
const num = (n: number, d = 2) => (Math.round(n * 10 ** d) / 10 ** d).toFixed(d).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
export function fmt(unit: Unit | undefined, v: any, cur = 'DA'): string {
  if (v === null || v === undefined || v === '') return '—';
  if (typeof v === 'string' && Number.isNaN(Number(v))) return v;
  const n = Number(v);
  switch (unit) {
    case 'money': return `${num(n)} ${curLabel(cur)}`;
    case 'pct': return `${num(n, 1)} %`;
    case 'int': return num(n, 0);
    case 'days': return `${num(n, 1)} j`;
    case 'hours': return `${num(n, 1)} h`;
    case 'min': return `${num(n, 0)} min`;
    case 'score': return `${num(n, 2)} / 5`;
    default: return Number.isInteger(n) ? num(n, 0) : num(n);
  }
}
export function variation(k: Kpi) {
  if (k.prev === null || k.value === null) return null;
  const diff = k.value - k.prev;
  const rate = k.prev !== 0 ? (diff / Math.abs(k.prev)) * 100 : null;
  const good = k.better === null || k.better === undefined || diff === 0 ? null : (diff > 0) === (k.better === 'up');
  return { diff, rate, good };
}
const varText = (k: Kpi) => { const v = variation(k); if (!v) return ''; return v.rate === null ? (v.diff > 0 ? 'Hausse (n.s.)' : v.diff < 0 ? 'Baisse (n.s.)' : 'Stable') : `${v.rate > 0 ? '+' : ''}${num(v.rate, 1)} %`; };
const cellOf = (c: Col, v: any, cur: string) => (c.unit || c.money ? fmt(c.money ? 'money' : c.unit, v, cur) : v === null || v === undefined ? '' : String(v));

// ===================================================== PDF =====================================================
function logo(doc: PDFKit.PDFDocument, x: number, y: number) {
  doc.save().roundedRect(x, y, 30, 30, 7).fill('#7A1F2B');
  doc.fillColor('#fff').font('Helvetica-Bold').fontSize(18).text('K', x, y + 7, { width: 30, align: 'center' });
  doc.circle(x + 25, y + 6, 3.2).fill('#C9A227').restore();
}
function drawChart(doc: PDFKit.PDFDocument, ch: Chart, x: number, y: number, w: number, h: number, cur: string) {
  doc.fillColor('#111').font('Helvetica-Bold').fontSize(9).text(ch.title, x, y, { width: w });
  const top = y + 16, H = h - 34, left = x + 46, W = w - 52;
  if (ch.type === 'pie') {
    const vals = ch.series[0]?.values ?? [];
    const sum = vals.reduce((a, b) => a + Math.max(0, b), 0);
    if (!sum) { doc.fillColor('#888').font('Helvetica').fontSize(8).text('Aucune donnée sur la période.', x, top + 10); return; }
    const r = Math.min(H, W / 2) / 2 - 2, cx = x + r + 6, cy = top + r + 4;
    let a = -Math.PI / 2;
    vals.forEach((v, i) => {
      if (v <= 0) return;
      const b = a + (v / sum) * Math.PI * 2;
      doc.save().moveTo(cx, cy).lineTo(cx + r * Math.cos(a), cy + r * Math.sin(a));
      const steps = Math.max(2, Math.ceil(((b - a) / (Math.PI * 2)) * 60));
      for (let s = 1; s <= steps; s++) { const t = a + ((b - a) * s) / steps; doc.lineTo(cx + r * Math.cos(t), cy + r * Math.sin(t)); }
      doc.closePath().fill(PALETTE[i % PALETTE.length]).restore();
      a = b;
    });
    let ly = top;
    ch.labels.forEach((l, i) => {
      if (ly > top + H) return;
      doc.rect(cx + r + 14, ly + 1, 7, 7).fill(PALETTE[i % PALETTE.length]);
      doc.fillColor('#333').font('Helvetica').fontSize(6.5).text(`${l} — ${fmt(ch.unit, vals[i], cur)} (${num((vals[i] / sum) * 100, 1)} %)`, cx + r + 25, ly, { width: x + w - (cx + r + 25), height: 9, lineBreak: false, ellipsis: true });
      ly += 11;
    });
    return;
  }
  const all = ch.series.flatMap((s) => s.values);
  const max = Math.max(0, ...all), min = Math.min(0, ...all);
  if (!all.length || (max === 0 && min === 0)) { doc.fillColor('#888').font('Helvetica').fontSize(8).text('Aucune donnée sur la période.', x, top + 10); return; }
  const span = max - min || 1;
  const Y = (v: number) => top + H - ((v - min) / span) * H;
  doc.strokeColor('#ddd').lineWidth(0.5);
  for (let i = 0; i <= 4; i++) {
    const v = min + (span * i) / 4, yy = Y(v);
    doc.moveTo(left, yy).lineTo(left + W, yy).stroke();
    doc.fillColor('#777').font('Helvetica').fontSize(6).text(fmt(ch.unit === 'money' ? 'num' : ch.unit, v, cur).replace(' DA', ''), x, yy - 3, { width: 44, align: 'right', lineBreak: false });
  }
  const n = ch.labels.length, step = W / Math.max(1, n);
  const lab = (l: string) => (/^\d{4}-\d{2}-\d{2}$/.test(l) ? `${l.slice(8, 10)}/${l.slice(5, 7)}` : /^\d{4}-\d{2}$/.test(l) ? `${l.slice(5, 7)}/${l.slice(2, 4)}` : l.length > 12 ? `${l.slice(0, 11)}…` : l);
  const every = Math.max(1, Math.ceil(n / Math.max(2, Math.floor(W / 34))));
  ch.labels.forEach((l, i) => { if (i % every === 0) doc.fillColor('#777').fontSize(5.5).text(lab(l), left + i * step, top + H + 3, { width: Math.max(step * every - 2, 20), height: 8, lineBreak: false, ellipsis: true }); });
  if (ch.type === 'bar') {
    const bw = (step * 0.75) / ch.series.length;
    ch.series.forEach((s, si) => s.values.forEach((v, i) => { const y0 = Y(Math.max(0, v)), y1 = Y(Math.min(0, v)); doc.rect(left + i * step + step * 0.125 + si * bw, y0, Math.max(1, bw - 1), Math.max(0.5, y1 - y0)).fill(PALETTE[si % PALETTE.length]); }));
  } else {
    ch.series.forEach((s, si) => {
      doc.save().strokeColor(PALETTE[si % PALETTE.length]).lineWidth(1.4);
      s.values.forEach((v, i) => { const px = left + i * step + step / 2; if (i === 0) doc.moveTo(px, Y(v)); else doc.lineTo(px, Y(v)); });
      doc.stroke().restore();
    });
  }
  let lx = left;
  ch.series.forEach((s, si) => { doc.rect(lx, y + h - 9, 7, 7).fill(PALETTE[si % PALETTE.length]); doc.fillColor('#333').fontSize(7).text(s.name, lx + 10, y + h - 9, { lineBreak: false }); lx += 14 + doc.widthOfString(s.name) + 8; });
}
export function sectionPdf(m: Meta, s: Section, extra?: { title: string; columns: Col[]; rows: any[]; total?: any }[]): Promise<Buffer> {
  return new Promise((resolve) => {
    const doc = new PDFDocument({ size: 'A4', margin: 36, bufferPages: true });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    const W = doc.page.width - 72, B = doc.page.height - 50;
    // En-tête
    logo(doc, 36, 30);
    doc.fillColor('#7A1F2B').font('Helvetica-Bold').fontSize(15).text(m.hotel, 74, 30, { width: W - 38 });
    doc.fillColor('#111').fontSize(12).text(m.title, 74, 48, { width: W - 38 });
    doc.fillColor('#555').font('Helvetica').fontSize(8)
      .text(`Période : ${m.period}${m.compare ? ` · comparée à la période ${m.compare}` : ''} · Devise : ${curLabel(m.currency)}`, 36, 70, { width: W })
      .text(`Généré le ${new Date().toLocaleString('fr-FR', { timeZone: m.tz })} par ${m.generatedBy}${m.filters.length ? ` · Filtres : ${m.filters.join(', ')}` : ''}`, 36, 81, { width: W });
    doc.moveTo(36, 96).lineTo(36 + W, 96).strokeColor('#C9A227').lineWidth(1.2).stroke();
    let y = 106;
    const need = (h: number) => { if (y + h > B) { doc.addPage(); y = 40; } };
    // Indicateurs : grille 3 colonnes
    if (s.kpis.length) {
      doc.fillColor('#7A1F2B').font('Helvetica-Bold').fontSize(10).text('Indicateurs clés', 36, y); y += 16;
      const cw = W / 3;
      s.kpis.forEach((k, i) => {
        const cx = 36 + (i % 3) * cw;
        if (i % 3 === 0) need(46);
        const v = variation(k);
        doc.roundedRect(cx + 2, y, cw - 6, 40, 4).strokeColor('#e5e5e5').lineWidth(0.8).stroke();
        doc.fillColor('#666').font('Helvetica').fontSize(7).text(k.label, cx + 8, y + 5, { width: cw - 18, lineBreak: false, ellipsis: true });
        doc.fillColor('#111').font('Helvetica-Bold').fontSize(11).text(fmt(k.unit, k.value, m.currency), cx + 8, y + 15, { width: cw - 18, lineBreak: false });
        const t = varText(k);
        if (t) doc.fillColor(v?.good === null ? '#555' : v?.good ? '#15803D' : '#B91C1C').font('Helvetica').fontSize(7).text(`${t} (préc. ${fmt(k.unit, k.prev, m.currency)})`, cx + 8, y + 30, { width: cw - 18, lineBreak: false, ellipsis: true });
        else if (k.hint) doc.fillColor('#888').font('Helvetica').fontSize(6.5).text(k.hint, cx + 8, y + 30, { width: cw - 18, lineBreak: false, ellipsis: true });
        if (i % 3 === 2 || i === s.kpis.length - 1) y += 46;
      });
      y += 4;
    }
    // Graphiques : 2 par ligne
    if (s.charts.length) {
      need(30);
      doc.fillColor('#7A1F2B').font('Helvetica-Bold').fontSize(10).text('Graphiques', 36, y); y += 16;
      const cw = (W - 12) / 2, ch = 150;
      s.charts.forEach((c, i) => {
        if (i % 2 === 0) need(ch + 8);
        drawChart(doc, c, 36 + (i % 2) * (cw + 12), y, cw, ch, m.currency);
        if (i % 2 === 1 || i === s.charts.length - 1) y += ch + 12;
      });
    }
    // Tableaux
    const table = (t: { title: string; columns: Col[]; rows: any[]; total?: any }) => {
      need(40);
      doc.fillColor('#7A1F2B').font('Helvetica-Bold').fontSize(10).text(t.title, 36, y, { width: W }); y += 15;
      const widths = t.columns.map((c) => (c.unit || c.money ? 1 : 1.5));
      const sw = widths.reduce((a, b) => a + b, 0);
      const xs: number[] = []; let acc = 36; widths.forEach((w) => { xs.push(acc); acc += (w / sw) * W; });
      const cwf = (i: number) => (widths[i] / sw) * W - 4;
      const head = () => {
        doc.rect(36, y, W, 14).fill('#7A1F2B');
        doc.fillColor('#fff').font('Helvetica-Bold').fontSize(7);
        t.columns.forEach((c, i) => doc.text(c.label, xs[i] + 2, y + 4, { width: cwf(i), height: 9, align: c.unit || c.money ? 'right' : 'left', lineBreak: false, ellipsis: true }));
        y += 16;
      };
      head();
      const row = (r: any, bold = false) => {
        if (y + 12 > B) { doc.addPage(); y = 40; head(); }
        if (bold) doc.rect(36, y - 2, W, 12).fill('#F5F0E6');
        doc.fillColor('#111').font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(7);
        t.columns.forEach((c, i) => doc.text(cellOf(c, r[c.key], m.currency), xs[i] + 2, y, { width: cwf(i), height: 9, align: c.unit || c.money ? 'right' : 'left', lineBreak: false, ellipsis: true }));
        y += 12;
        doc.moveTo(36, y - 2).lineTo(36 + W, y - 2).strokeColor('#eee').lineWidth(0.4).stroke();
      };
      if (!t.rows.length) { doc.fillColor('#888').font('Helvetica').fontSize(8).text('Aucune donnée sur la période.', 36, y); y += 12; }
      t.rows.forEach((r) => row(r));
      if (t.total && t.rows.length) row(t.total, true);
      y += 10;
    };
    s.tables.forEach(table);
    (extra ?? []).forEach(table);
    if (s.notes?.length) { need(20 + s.notes.length * 10); doc.fillColor('#666').font('Helvetica-Oblique').fontSize(7); s.notes.forEach((n) => { doc.text(`• ${n}`, 36, y, { width: W }); y = doc.y + 2; }); }
    // Pied de page numéroté
    const range = doc.bufferedPageRange();
    for (let i = range.start; i < range.start + range.count; i++) {
      doc.switchToPage(i);
      doc.page.margins.bottom = 0;
      doc.fillColor('#999').font('Helvetica').fontSize(7).text(`KAYN Hotel · ${m.hotel} · ${m.title} · page ${i + 1} / ${range.count}`, 36, doc.page.height - 30, { width: W, align: 'center', lineBreak: false });
    }
    doc.end();
  });
}

// ===================================================== Excel =====================================================
export async function sectionXlsx(m: Meta, s: Section, extra?: { title: string; columns: Col[]; rows: any[]; total?: any }[]): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'KAYN Hotel';
  const header = (ws: ExcelJS.Worksheet, title: string) => {
    ws.addRow([`KAYN Hotel — ${m.hotel}`]).font = { bold: true, size: 14, color: { argb: 'FF7A1F2B' } };
    ws.addRow([title]).font = { bold: true, size: 12 };
    ws.addRow([`Période : ${m.period}${m.compare ? ` · comparée à la période ${m.compare}` : ''} · Devise : ${curLabel(m.currency)}`]);
    ws.addRow([`Généré le ${new Date().toLocaleString('fr-FR', { timeZone: m.tz })} par ${m.generatedBy}${m.filters.length ? ` · Filtres : ${m.filters.join(', ')}` : ''}`]);
    ws.addRow([]);
  };
  const headRow = (r: ExcelJS.Row) => { r.font = { bold: true, color: { argb: 'FFFFFFFF' } }; r.eachCell((c) => { c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF7A1F2B' } }; }); };
  const fmtOf = (u?: Unit, money?: boolean) => (money || u === 'money' ? '#,##0.00' : u === 'pct' ? '0.0" %"' : u === 'int' ? '#,##0' : u ? '#,##0.00' : undefined);
  const used = new Set<string>();
  const sheetName = (t: string) => { let n = t.replace(/[\\/?*[\]:]/g, ' ').slice(0, 28); let i = 2; while (used.has(n)) n = `${n.slice(0, 25)} ${i++}`; used.add(n); return n; };
  const ws = wb.addWorksheet(sheetName('Synthèse'));
  header(ws, m.title);
  headRow(ws.addRow(['Indicateur', 'Valeur', 'Période de comparaison', 'Écart', 'Variation %', 'Unité', 'Remarque']));
  for (const k of s.kpis) {
    const v = variation(k);
    const r = ws.addRow([k.label, k.value, k.prev, v ? Math.round(v.diff * 100) / 100 : null, v?.rate === null || !v ? null : Math.round(v.rate * 10) / 10, k.unit === 'money' ? curLabel(m.currency) : k.unit, k.hint ?? '']);
    const f = fmtOf(k.unit); if (f) [2, 3, 4].forEach((i) => { r.getCell(i).numFmt = f; });
  }
  [38, 18, 22, 16, 12, 10, 50].forEach((w, i) => { ws.getColumn(i + 1).width = w; });
  if (s.notes?.length) { ws.addRow([]); s.notes.forEach((n) => { ws.addRow([n]).font = { italic: true, color: { argb: 'FF666666' } }; }); }
  for (const t of [...s.tables, ...(extra ?? [])]) {
    const sh = wb.addWorksheet(sheetName(t.title));
    header(sh, t.title);
    headRow(sh.addRow(t.columns.map((c) => c.label)));
    const val = (c: Col, v: any) => (c.unit || c.money ? (v === '' || v === null || v === undefined || Number.isNaN(Number(v)) ? v ?? null : Number(v)) : v ?? '');
    for (const r of t.rows) sh.addRow(t.columns.map((c) => val(c, r[c.key])));
    if (t.total) sh.addRow(t.columns.map((c) => val(c, t.total[c.key]))).font = { bold: true };
    t.columns.forEach((c, i) => { sh.getColumn(i + 1).width = c.unit || c.money ? 16 : 24; const f = fmtOf(c.unit, c.money); if (f) sh.getColumn(i + 1).numFmt = f; });
  }
  for (const c of s.charts) {
    const sh = wb.addWorksheet(sheetName(`Graph. ${c.title}`));
    header(sh, `${c.title} (données du graphique)`);
    headRow(sh.addRow(['', ...c.series.map((x) => x.name)]));
    c.labels.forEach((l, i) => sh.addRow([l, ...c.series.map((x) => x.values[i])]));
    sh.getColumn(1).width = 28; c.series.forEach((_, i) => { sh.getColumn(i + 2).width = 18; const f = fmtOf(c.unit); if (f) sh.getColumn(i + 2).numFmt = f; });
  }
  return Buffer.from(await wb.xlsx.writeBuffer());
}

// ===================================================== CSV =====================================================
export function sectionCsv(m: Meta, s: Section, extra?: { title: string; columns: Col[]; rows: any[]; total?: any }[]): string {
  const esc = (v: any) => { const x = v === null || v === undefined ? '' : String(v); return /[";\n\r]/.test(x) ? `"${x.replace(/"/g, '""')}"` : x; };
  const nb = (v: any) => (typeof v === 'number' ? String(Math.round(v * 100) / 100).replace('.', ',') : v);
  const L: string[] = [];
  L.push(esc(`KAYN Hotel — ${m.hotel}`), esc(m.title), esc(`Période : ${m.period}${m.compare ? ` · comparée à la période ${m.compare}` : ''}`), esc(`Devise : ${curLabel(m.currency)}`),
    esc(`Généré le ${new Date().toLocaleString('fr-FR', { timeZone: m.tz })} par ${m.generatedBy}`), ...(m.filters.length ? [esc(`Filtres : ${m.filters.join(', ')}`)] : []), '');
  if (s.kpis.length) {
    L.push('Indicateur;Valeur;Comparaison;Variation %;Unité');
    s.kpis.forEach((k) => { const v = variation(k); L.push([k.label, nb(k.value), nb(k.prev), v?.rate === null || !v ? '' : nb(v.rate), k.unit === 'money' ? curLabel(m.currency) : k.unit].map(esc).join(';')); });
    L.push('');
  }
  for (const t of [...s.tables, ...(extra ?? [])]) {
    L.push(esc(t.title), t.columns.map((c) => esc(c.label)).join(';'));
    t.rows.forEach((r) => L.push(t.columns.map((c) => esc(nb(r[c.key]))).join(';')));
    if (t.total) L.push(t.columns.map((c) => esc(nb(t.total[c.key]))).join(';'));
    L.push('');
  }
  return '﻿' + L.join('\r\n');
}
