/** Centre de rapports : domaines, droits, rapports détaillés des modules, cache court. */
import { forbidden, notFound } from '../../lib/errors.js';
import { CRM_REPORTS, crmReport } from '../crm.js';
import { FIN_REPORTS, finReport } from '../finance.js';
import { REPORTS as FO_REPORTS, report as foReport } from '../frontoffice.js';
import { HK_REPORTS, hkReport } from '../housekeeping.js';
import { HR_REPORTS, hrReport, scopeOf } from '../hr.js';
import { MAINT_REPORTS, maintReport } from '../maintenance.js';
import { RS_REPORTS, rsReport } from '../restaurant.js';
import { STOCK_REPORTS, stockReport } from '../stock.js';
import type { Col, Ctx, Section } from './core.js';
import { DOMAIN_FN } from './domains.js';
import { DRILLS } from './drill.js';

export const DOMAINS: Record<string, { title: string; perms: string[]; filters: string[] }> = {
  overview: { title: 'Tableau de bord général', perms: ['reports.global'], filters: ['room_type_id', 'floor_id', 'source'] },
  reservations: { title: 'Réservations', perms: ['reports.global', 'reports.reservations'], filters: ['source', 'status', 'room_type_id'] },
  rooms: { title: 'Hébergement', perms: ['reports.global', 'reports.reservations'], filters: ['room_type_id', 'floor_id', 'source'] },
  finance: { title: 'Finances & comptabilité', perms: ['finance.reports'], filters: ['department'] },
  restaurant: { title: 'Restaurant & services', perms: ['restaurant.reports'], filters: ['outlet', 'category'] },
  housekeeping: { title: 'Housekeeping', perms: ['housekeeping.reports'], filters: ['category'] },
  stock: { title: 'Stocks & achats', perms: ['purchase.reports'], filters: ['department', 'category'] },
  maintenance: { title: 'Maintenance', perms: ['maintenance.reports'], filters: ['category'] },
  hr: { title: 'Ressources humaines', perms: ['hr.reports'], filters: ['department'] },
  crm: { title: 'CRM & clients', perms: ['crm.reports'], filters: [] },
};
export const canDomain = (perms: Set<string>, d: string) => !!DOMAINS[d] && DOMAINS[d].perms.some((p) => perms.has(p));
export function assertDomain(perms: Set<string>, d: string) {
  if (!DOMAINS[d]) throw notFound('Module de rapport inconnu');
  if (!canDomain(perms, d)) throw forbidden(`Accès refusé aux rapports « ${DOMAINS[d].title} ».`);
}

// ===================================================== Cache court (30 s) =====================================================
const CACHE = new Map<string, { at: number; v: Section }>();
const TTL = 30_000;
export async function runDomain(c: Ctx, domain: string, fresh = false): Promise<Section> {
  assertDomain(c.perms, domain);
  // la clé inclut les droits sensibles (salaires, périmètre RH) pour ne jamais servir un résultat d'un autre profil
  const key = JSON.stringify([c.hotelId, domain, c.P, c.F, domain === 'hr' ? [c.actor.userId, c.perms.has('hr.salary')] : 0]);
  const hit = CACHE.get(key);
  if (!fresh && hit && Date.now() - hit.at < TTL) return hit.v;
  const v = await (DOMAIN_FN as any)[domain](c) as Section;
  CACHE.set(key, { at: Date.now(), v });
  if (CACHE.size > 300) for (const [k, x] of CACHE) if (Date.now() - x.at > TTL) CACHE.delete(k);
  return v;
}
export const clearAnalyticsCache = () => CACHE.clear();

// ===================================================== Rapports détaillés des modules =====================================================
type Cat = { title: string; run: (c: Ctx) => Promise<{ title: string; columns: Col[]; rows: any[]; total?: any }>; salary?: boolean };
const norm = (cols: any[]): Col[] => cols.map((x) => (Array.isArray(x) ? { key: x[0], label: x[1] } : x));
const mod = (defs: Record<string, any>, fn: (c: Ctx, k: string) => Promise<any>, only?: string[]) =>
  Object.fromEntries(Object.entries(defs).filter(([k]) => !only || only.includes(k)).map(([k, d]) => [k, { title: d.title, salary: !!d.salary, run: async (c: Ctx) => { const r = await fn(c, k); return { ...r, title: r.title ?? d.title, columns: norm(r.columns ?? d.columns) }; } } as Cat]));
export const CATALOG: Record<string, Record<string, Cat>> = {
  overview: {},
  reservations: mod(FO_REPORTS, (c, k) => foReport(c.db, c.hotelId, k, c.P.from, c.P.to), ['checkins', 'checkouts', 'in_house', 'overdue', 'arrivals', 'departures']),
  rooms: { ...mod(FO_REPORTS, (c, k) => foReport(c.db, c.hotelId, k, c.P.from, c.P.to), ['available', 'dirty']), ...mod(MAINT_REPORTS, (c, k) => maintReport(c.db, c.hotelId, k, c.P.from, c.P.to), ['rooms']) },
  finance: mod(FIN_REPORTS, (c, k) => finReport(c.db, c.hotelId, k, c.P.from, c.P.to)),
  restaurant: mod(RS_REPORTS, (c, k) => rsReport(c.db, c.hotelId, k, c.P.from, c.P.to)),
  housekeeping: mod(HK_REPORTS, (c, k) => hkReport(c.db, c.hotelId, k, c.P.from, c.P.to, c.tz)),
  stock: mod(STOCK_REPORTS, (c, k) => stockReport(c.db, c.hotelId, k, c.P.from, c.P.to)),
  maintenance: mod(MAINT_REPORTS, (c, k) => maintReport(c.db, c.hotelId, k, c.P.from, c.P.to)),
  hr: mod(HR_REPORTS, async (c, k) => hrReport(c.db, c.hotelId, await scopeOf(c.db, c.actor as any, c.perms), k, c.P.from, c.P.to)),
  crm: mod(CRM_REPORTS, (c, k) => crmReport(c.db, c.hotelId, k, c.P.from, c.P.to)),
};
export function catalogList(perms: Set<string>, domain: string) {
  return Object.entries(CATALOG[domain] ?? {}).filter(([, x]) => !x.salary || perms.has('hr.salary')).map(([key, x]) => ({ key, title: x.title }));
}
export async function runCatalog(c: Ctx, domain: string, kind: string) {
  assertDomain(c.perms, domain);
  const def = CATALOG[domain]?.[kind];
  if (!def) throw notFound('Rapport inconnu');
  if (def.salary && !c.perms.has('hr.salary')) throw forbidden('Rapport réservé aux personnes habilitées à voir les salaires.');
  return def.run(c);
}

// ===================================================== Drill-down =====================================================
export async function runDrill(c: Ctx, key: string, page = 1, size = 50) {
  const d = DRILLS[key];
  if (!d) throw notFound('Détail inconnu');
  if (!d.domain.some((x) => canDomain(c.perms, x))) throw forbidden('Accès refusé à ce détail.');
  const lim = Math.min(Math.max(size, 1), 5000);
  const r = await d.run(c, lim, (Math.max(page, 1) - 1) * lim);
  return { key, title: d.title, columns: d.columns, rows: r.rows, count: r.count, page, page_size: lim, total: r.total ?? null };
}
export const drillList = () => Object.entries(DRILLS).map(([k, d]) => ({ key: k, title: d.title, domain: d.domain }));
