/** Périodes de rapport : préréglages, période de comparaison, regroupement (jour / semaine / mois / année). */
import { addDays, diffDays, today as todayTz } from '../../lib/dates.js';

export const PRESETS = ['today', 'yesterday', 'week', 'month', 'last_month', 'year', 'last_year', 'custom'] as const;
export type Preset = (typeof PRESETS)[number];
export type Compare = 'prev' | 'year' | 'none';
export type Group = 'day' | 'week' | 'month' | 'year';

const pad = (n: number) => String(n).padStart(2, '0');
const lastDay = (y: number, m: number) => new Date(Date.UTC(y, m, 0)).getUTCDate(); // m : 1..12
/** Décale une date de n mois en conservant le jour (borné à la fin du mois). */
export function shiftMonths(d: string, n: number): string {
  let y = +d.slice(0, 4), m = +d.slice(5, 7) + n;
  while (m < 1) { m += 12; y--; }
  while (m > 12) { m -= 12; y++; }
  return `${y}-${pad(m)}-${pad(Math.min(+d.slice(8, 10), lastDay(y, m)))}`;
}
/** Lundi de la semaine (ISO). */
export function mondayOf(d: string): string {
  const wd = new Date(Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10))).getUTCDay();
  return addDays(d, -((wd + 6) % 7));
}

export type Period = { preset: Preset; from: string; to: string; pfrom: string | null; pto: string | null; compare: Compare; days: number; today: string; group: Group };

/**
 * « Cette semaine / ce mois / cette année » s'arrêtent à aujourd'hui (convention hôtelière : à date).
 * Comparaison « période précédente » : même nombre de jours juste avant, ou mêmes jours du mois / de l'année précédents
 * pour les préréglages mensuels / annuels ; « année précédente » : mêmes dates l'an dernier.
 */
export function resolvePeriod(o: { preset?: string; from?: string; to?: string; compare?: string; group?: string }, tz?: string): Period {
  const t = todayTz(tz);
  const preset = (PRESETS as readonly string[]).includes(o.preset ?? '') ? (o.preset as Preset) : o.from && o.to ? 'custom' : 'month';
  let from = t, to = t;
  const y = +t.slice(0, 4);
  switch (preset) {
    case 'today': break;
    case 'yesterday': from = to = addDays(t, -1); break;
    case 'week': from = mondayOf(t); break;
    case 'month': from = t.slice(0, 8) + '01'; break;
    case 'last_month': { const p = shiftMonths(t.slice(0, 8) + '01', -1); from = p; to = `${p.slice(0, 8)}${pad(lastDay(+p.slice(0, 4), +p.slice(5, 7)))}`; break; }
    case 'year': from = `${y}-01-01`; break;
    case 'last_year': from = `${y - 1}-01-01`; to = `${y - 1}-12-31`; break;
    case 'custom': from = o.from!; to = o.to!; break;
  }
  if (from > to) [from, to] = [to, from];
  const days = diffDays(from, to) + 1;
  if (days > 3700) throw Object.assign(new Error('Période trop longue (10 ans maximum).'), { statusCode: 400 });
  const compare: Compare = o.compare === 'year' || o.compare === 'none' ? o.compare : 'prev';
  let pfrom: string | null = null, pto: string | null = null;
  if (compare === 'year') { pfrom = shiftMonths(from, -12); pto = shiftMonths(to, -12); }
  else if (compare === 'prev') {
    if (preset === 'month' || preset === 'last_month') { pfrom = shiftMonths(from, -1); pto = preset === 'last_month' ? `${pfrom.slice(0, 8)}${pad(lastDay(+pfrom.slice(0, 4), +pfrom.slice(5, 7)))}` : shiftMonths(to, -1); }
    else if (preset === 'year' || preset === 'last_year') { pfrom = shiftMonths(from, -12); pto = shiftMonths(to, -12); }
    else { pto = addDays(from, -1); pfrom = addDays(pto, -(days - 1)); }
  }
  const g = o.group as Group;
  const group: Group = ['day', 'week', 'month', 'year'].includes(g) ? g : days <= 45 ? 'day' : days <= 190 ? 'week' : days <= 1100 ? 'month' : 'year';
  return { preset, from, to, pfrom, pto, compare, days, today: t, group };
}

/** Clé de regroupement d'une date selon la granularité. */
export function bucketOf(d: string, g: Group): string {
  return g === 'day' ? d : g === 'week' ? mondayOf(d) : g === 'month' ? d.slice(0, 7) : d.slice(0, 4);
}
/** Liste ordonnée des clés de regroupement couvrant la période (périodes sans données incluses). */
export function buckets(from: string, to: string, g: Group): string[] {
  const out: string[] = [];
  for (let d = from; d <= to; d = addDays(d, 1)) { const k = bucketOf(d, g); if (out[out.length - 1] !== k) out.push(k); }
  return out;
}
/** Répartit des lignes { d, ...valeurs } dans les clés de la période (somme). */
export function bucketize<T extends Record<string, any>>(rows: T[], from: string, to: string, g: Group, keys: string[], dateKey = 'd') {
  const ks = buckets(from, to, g);
  const map = new Map(ks.map((k) => [k, Object.fromEntries(keys.map((x) => [x, 0])) as Record<string, number>]));
  for (const r of rows) { const b = map.get(bucketOf(String(r[dateKey]).slice(0, 10), g)); if (b) for (const k of keys) b[k] += Number(r[k] ?? 0); }
  return { labels: ks, values: (k: string) => ks.map((x) => Math.round(map.get(x)![k] * 100) / 100), raw: map };
}
