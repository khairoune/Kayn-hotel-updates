/** Détail (drill-down) des indicateurs : lignes réelles qui composent chaque chiffre, paginées, avec les mêmes filtres. */
import { q } from '../../db/pool.js';
import { receivables } from '../finance.js';
import { scopeOf } from '../hr.js';
import { col, METHOD_LBL, n0, OUTLET_LBL, r2, RES_STATUS_LBL, ROOM_CTE, roomParams, SOURCE_LBL, type Col, type Ctx } from './core.js';

type Drill = { title: string; domain: string[]; columns: Col[]; money?: string[]; run: (c: Ctx, lim: number, off: number) => Promise<{ rows: any[]; count: number; total?: any }> };
const gname = (x: any) => (x.kind && x.kind !== 'person' ? x.company_name : `${x.last_name ?? ''} ${x.first_name ?? ''}`.trim());
const dt = (c: Ctx, d: any) => (d ? new Date(d).toLocaleString('fr-FR', { timeZone: c.tz, day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '');
const d10 = (d: any) => (d ? (d instanceof Date ? d.toISOString() : String(d)).slice(0, 10) : '');
/** Exécute une requête paginée (la requête doit sélectionner count(*) OVER() AS _n). */
async function page(c: Ctx, sql: string, params: any[], lim: number, off: number, map: (x: any) => any, totalSql?: { sql: string; params: any[] }) {
  const rows = await q<any>(c.db, `${sql} LIMIT ${lim} OFFSET ${off}`, params);
  const total = totalSql ? (await q<any>(c.db, totalSql.sql, totalSql.params))[0] : undefined;
  return { rows: rows.map(map), count: rows[0] ? Number(rows[0]._n) : 0, total };
}
const RES_F = `($5::text IS NULL OR res.source = $5) AND ($6::text IS NULL OR res.status = $6) AND ($7::int IS NULL OR EXISTS (SELECT 1 FROM reservation_rooms x WHERE x.reservation_id = res.id AND x.room_type_id = $7))`;
const resP = (c: Ctx) => [c.hotelId, c.P.from, c.P.to, c.tz, c.F.source ?? null, c.F.status ?? null, c.F.room_type_id ?? null];
const RES_COLS = [col('code', 'Réservation'), col('client', 'Client'), col('source', 'Canal'), col('status', 'Statut'), col('check_in', 'Arrivée'), col('check_out', 'Départ'), col('nights', 'Nuits', 'int'), col('created', 'Créée le'), col('reason', 'Motif')];
const resList = (where: string, order = 'res.check_in'): Drill['run'] => (c, lim, off) => page(c,
  `SELECT res.*, g.kind, g.last_name, g.first_name, g.company_name, count(*) OVER() AS _n FROM reservations res JOIN guests g ON g.id = res.guest_id WHERE res.hotel_id = $1 AND ${RES_F} AND ${where} AND $4::text IS NOT NULL ORDER BY ${order}`,
  resP(c), lim, off, (x) => ({ code: x.code, client: gname(x), source: SOURCE_LBL[x.source] ?? x.source, status: RES_STATUS_LBL[x.status] ?? x.status, check_in: d10(x.check_in), check_out: d10(x.check_out), nights: Math.round((Date.parse(d10(x.check_out)) - Date.parse(d10(x.check_in))) / 864e5), created: dt(c, x.created_at), reason: x.cancel_reason ?? '' }));
const RES = ['overview', 'reservations', 'rooms'];

export const DRILLS: Record<string, Drill> = {
  nights: {
    title: 'Nuitées vendues (détail par chambre de réservation)', domain: [...RES, 'crm'],
    columns: [col('code', 'Réservation'), col('client', 'Client'), col('room', 'Chambre'), col('type', 'Type'), col('source', 'Canal'), col('first', 'Première nuit'), col('nights', 'Nuitées', 'int'), col('forecast', 'dont prévision', 'int'), col('revenue', 'CA HT', 'money')],
    run: (c, lim, off) => page(c, `WITH ${ROOM_CTE}
      SELECT res.code, g.kind, g.last_name, g.first_name, g.company_name, r.number AS room, rt.name AS type, res.source, min(n.d) AS first, count(*)::int AS nights, count(*) FILTER (WHERE n.fc)::int AS forecast, sum(n.rate) AS revenue, count(*) OVER() AS _n
        FROM nights n JOIN reservations res ON res.id = n.reservation_id JOIN guests g ON g.id = res.guest_id LEFT JOIN rooms r ON r.id = n.room_id JOIN room_types rt ON rt.id = n.room_type_id
       GROUP BY n.rr_id, res.code, g.kind, g.last_name, g.first_name, g.company_name, r.number, rt.name, res.source ORDER BY min(n.d), res.code`, roomParams(c, c.P.from, c.P.to), lim, off,
      (x) => ({ code: x.code, client: gname(x), room: x.room ?? '—', type: x.type, source: SOURCE_LBL[x.source] ?? x.source, first: d10(x.first), nights: x.nights, forecast: x.forecast, revenue: r2(n0(x.revenue)) }),
      { sql: `WITH ${ROOM_CTE} SELECT 'Total' AS code, count(*)::int AS nights, count(*) FILTER (WHERE fc)::int AS forecast, COALESCE(sum(rate),0) AS revenue FROM nights`, params: roomParams(c, c.P.from, c.P.to) }),
  },
  reservations: { title: 'Réservations enregistrées sur la période', domain: RES, columns: RES_COLS, run: resList(`(res.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`, 'res.created_at') },
  arrivals_all: { title: 'Réservations dont l\'arrivée tombe dans la période', domain: RES, columns: RES_COLS, run: resList(`res.check_in BETWEEN $2 AND $3`) },
  arrivals: { title: 'Arrivées réalisées', domain: RES, columns: RES_COLS, run: resList(`res.status IN ('checked_in','checked_out') AND EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.reservation_id = res.id AND rr.check_in BETWEEN $2 AND $3 AND rr.status IN ('checked_in','checked_out'))`) },
  departures: { title: 'Départs réalisés', domain: RES, columns: RES_COLS, run: resList(`EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.reservation_id = res.id AND rr.check_out BETWEEN $2 AND $3 AND rr.status = 'checked_out')`, 'res.check_out') },
  cancellations: { title: 'Réservations annulées (arrivée prévue sur la période)', domain: RES, columns: RES_COLS, run: resList(`res.status = 'cancelled' AND res.check_in BETWEEN $2 AND $3`) },
  no_shows: { title: 'No-shows (arrivée prévue sur la période)', domain: RES, columns: RES_COLS, run: resList(`res.status = 'no_show' AND res.check_in BETWEEN $2 AND $3`) },
  blocks: {
    title: 'Chambres bloquées / hors service sur la période', domain: ['rooms', 'maintenance'],
    columns: [col('room', 'Chambre'), col('kind', 'Type'), col('start', 'Du'), col('end', 'Au'), col('status', 'État'), col('reason', 'Motif')],
    run: (c, lim, off) => page(c, `SELECT b.*, r.number, count(*) OVER() AS _n FROM room_blocks b JOIN rooms r ON r.id = b.room_id WHERE r.hotel_id = $1 AND b.start_date <= $3 AND (b.end_date IS NULL OR b.end_date > $2)
        AND ($4::int IS NULL OR r.room_type_id = $4) ORDER BY b.start_date DESC`, [c.hotelId, c.P.from, c.P.to, c.F.room_type_id ?? null], lim, off,
      (x) => ({ room: x.number, kind: x.kind === 'maintenance' ? 'Maintenance' : 'Hors service', start: d10(x.start_date), end: x.end_date ? d10(x.end_date) : 'ouvert', status: x.status === 'active' ? 'Actif' : `Levé le ${dt(c, x.released_at)}`, reason: x.reason ?? '' })),
  },
  rs_orders: {
    title: 'Commandes restaurant', domain: ['overview', 'restaurant'],
    columns: [col('number', 'N°'), col('date', 'Date'), col('outlet', 'Point de vente'), col('table', 'Table / chambre'), col('waiter', 'Serveur'), col('covers', 'Couverts', 'int'), col('settlement', 'Règlement'), col('net', 'Ventes HT', 'money'), col('total', 'TTC', 'money')],
    run: (c, lim, off) => page(c, `SELECT o.*, t.name AS table_name, r.number AS room, u.full_name AS waiter, count(*) OVER() AS _n FROM rs_orders o LEFT JOIN rs_tables t ON t.id = o.table_id LEFT JOIN rooms r ON r.id = o.room_id LEFT JOIN users u ON u.id = o.waiter_id
        WHERE o.hotel_id = $1 AND o.status <> 'cancelled' AND o.settlement <> 'cancelled' AND (o.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR o.outlet = $5) ORDER BY o.created_at DESC`,
      [c.hotelId, c.P.from, c.P.to, c.tz, c.F.outlet ?? null], lim, off,
      (x) => ({ number: x.number, date: dt(c, x.created_at), outlet: OUTLET_LBL[x.outlet] ?? x.outlet, table: x.table_name ?? (x.room ? `Ch. ${x.room}` : ''), waiter: x.waiter ?? '', covers: x.covers, settlement: METHOD_LBL[x.settlement] ?? x.settlement, net: r2(n0(x.subtotal) - n0(x.discount_total)), total: n0(x.total) }),
      { sql: `SELECT 'Total' AS number, COALESCE(sum(subtotal - discount_total),0) AS net, COALESCE(sum(total),0) AS total, COALESCE(sum(covers),0)::int AS covers FROM rs_orders o WHERE o.hotel_id = $1 AND o.status <> 'cancelled' AND o.settlement <> 'cancelled' AND (o.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR o.outlet = $5)`, params: [c.hotelId, c.P.from, c.P.to, c.tz, c.F.outlet ?? null] }),
  },
  rs_cancelled: {
    title: 'Commandes annulées', domain: ['restaurant'],
    columns: [col('number', 'N°'), col('date', 'Date'), col('outlet', 'Point de vente'), col('by', 'Annulée par'), col('reason', 'Motif'), col('total', 'Montant', 'money')],
    run: (c, lim, off) => page(c, `SELECT o.*, u.full_name AS by, count(*) OVER() AS _n FROM rs_orders o LEFT JOIN users u ON u.id = o.cancelled_by WHERE o.hotel_id = $1 AND o.status = 'cancelled' AND (o.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR o.outlet = $5) ORDER BY o.created_at DESC`,
      [c.hotelId, c.P.from, c.P.to, c.tz, c.F.outlet ?? null], lim, off, (x) => ({ number: x.number, date: dt(c, x.created_at), outlet: OUTLET_LBL[x.outlet] ?? x.outlet, by: x.by ?? '', reason: x.cancel_reason ?? '', total: n0(x.total) })),
  },
  charges: {
    title: 'Prestations facturées au folio (hors restaurant)', domain: ['overview'],
    columns: [col('date', 'Date'), col('code', 'Réservation'), col('kind', 'Type'), col('description', 'Libellé'), col('quantity', 'Qté'), col('total', 'Montant HT', 'money')],
    run: (c, lim, off) => page(c, `SELECT ch.*, res.code, count(*) OVER() AS _n FROM charges ch JOIN reservations res ON res.id = ch.reservation_id WHERE res.hotel_id = $1 AND NOT ch.void AND ch.rs_order_line_id IS NULL AND ch.service_date BETWEEN $2 AND $3 ORDER BY ch.service_date DESC, ch.id DESC`,
      [c.hotelId, c.P.from, c.P.to], lim, off, (x) => ({ date: d10(x.service_date), code: x.code, kind: x.kind, description: x.description, quantity: n0(x.quantity), total: n0(x.total) }),
      { sql: `SELECT 'Total' AS date, COALESCE(sum(ch.total),0) AS total FROM charges ch JOIN reservations res ON res.id = ch.reservation_id WHERE res.hotel_id = $1 AND NOT ch.void AND ch.rs_order_line_id IS NULL AND ch.service_date BETWEEN $2 AND $3`, params: [c.hotelId, c.P.from, c.P.to] }),
  },
  payments: {
    title: 'Encaissements, recettes et remboursements', domain: ['overview', 'finance'],
    columns: [col('date', 'Date'), col('type', 'Type'), col('ref', 'Référence'), col('method', 'Mode'), col('amount', 'Montant', 'money')],
    run: (c, lim, off) => {
      const U = `SELECT received_at AS at, 'Paiement' AS type, COALESCE((SELECT code FROM reservations r WHERE r.id = p.reservation_id), (SELECT number FROM invoices i WHERE i.id = p.invoice_id), '') AS ref, method, amount FROM payments p WHERE hotel_id = $1 AND NOT void AND (received_at AT TIME ZONE $4)::date BETWEEN $2 AND $3
        UNION ALL SELECT created_at, 'Recette', description, method, amount FROM incomes WHERE hotel_id = $1 AND NOT void AND (created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3
        UNION ALL SELECT f.created_at, 'Remboursement', COALESCE(r.code, i.number, ''), f.method, -f.amount FROM refunds f LEFT JOIN reservations r ON r.id = f.reservation_id LEFT JOIN invoices i ON i.id = f.invoice_id WHERE COALESCE(r.hotel_id, i.hotel_id) = $1 AND (f.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`;
      const P = [c.hotelId, c.P.from, c.P.to, c.tz];
      return page(c, `SELECT u.*, count(*) OVER() AS _n FROM (${U}) u ORDER BY at DESC`, P, lim, off, (x) => ({ date: dt(c, x.at), type: x.type, ref: x.ref, method: METHOD_LBL[x.method] ?? x.method, amount: n0(x.amount) }),
        { sql: `SELECT 'Total net' AS date, COALESCE(sum(amount),0) AS amount FROM (${U}) u`, params: P });
    },
  },
  refunds: {
    title: 'Remboursements', domain: ['finance'],
    columns: [col('date', 'Date'), col('ref', 'Dossier'), col('method', 'Mode'), col('reason', 'Motif'), col('amount', 'Montant', 'money')],
    run: (c, lim, off) => page(c, `SELECT f.*, COALESCE(r.code, i.number) AS ref, count(*) OVER() AS _n FROM refunds f LEFT JOIN reservations r ON r.id = f.reservation_id LEFT JOIN invoices i ON i.id = f.invoice_id
        WHERE COALESCE(r.hotel_id, i.hotel_id) = $1 AND (f.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 ORDER BY f.created_at DESC`, [c.hotelId, c.P.from, c.P.to, c.tz], lim, off,
      (x) => ({ date: dt(c, x.created_at), ref: x.ref ?? '', method: METHOD_LBL[x.method] ?? x.method, reason: x.reason ?? '', amount: n0(x.amount) })),
  },
  expenses: {
    title: 'Dépenses', domain: ['overview', 'finance'],
    columns: [col('date', 'Date'), col('category', 'Catégorie'), col('description', 'Libellé'), col('supplier', 'Fournisseur'), col('method', 'Mode'), col('amount', 'Montant', 'money')],
    run: (c, lim, off) => page(c, `SELECT e.*, s.name AS supplier, count(*) OVER() AS _n FROM expenses e LEFT JOIN suppliers s ON s.id = e.supplier_id WHERE e.hotel_id = $1 AND NOT e.void AND e.expense_date BETWEEN $2 AND $3 ORDER BY e.expense_date DESC, e.id DESC`,
      [c.hotelId, c.P.from, c.P.to], lim, off, (x) => ({ date: d10(x.expense_date), category: x.category, description: x.description, supplier: x.supplier ?? '', method: METHOD_LBL[x.method] ?? x.method, amount: n0(x.amount) }),
      { sql: `SELECT 'Total' AS date, COALESCE(sum(amount),0) AS amount FROM expenses WHERE hotel_id = $1 AND NOT void AND expense_date BETWEEN $2 AND $3`, params: [c.hotelId, c.P.from, c.P.to] }),
  },
  receivables: {
    title: 'Créances clients (à ce jour)', domain: ['overview', 'finance'],
    columns: [col('ref', 'Dossier / facture'), col('client', 'Client'), col('payer', 'Payeur'), col('date', 'Date'), col('age', 'Âge (j)', 'int'), col('total', 'Montant', 'money'), col('paid', 'Encaissé', 'money'), col('due', 'Reste dû', 'money')],
    run: async (c, lim, off) => { const all = await receivables(c.db, c.hotelId); return { rows: all.slice(off, off + lim), count: all.length, total: { ref: 'Total', total: r2(all.reduce((s, x) => s + x.total, 0)), paid: r2(all.reduce((s, x) => s + x.paid, 0)), due: r2(all.reduce((s, x) => s + x.due, 0)) } }; },
  },
  invoices: {
    title: 'Factures et avoirs émis', domain: ['finance'],
    columns: [col('number', 'N°'), col('date', 'Date'), col('type', 'Type'), col('client', 'Client'), col('ref', 'Séjour'), col('status', 'Statut'), col('total', 'TTC', 'money')],
    run: (c, lim, off) => invList(c, lim, off, `i.type IN ('invoice','credit_note')`),
  },
  invoices_unpaid: { title: 'Factures impayées émises sur la période', domain: ['finance'], columns: [], run: (c, lim, off) => invList(c, lim, off, `i.type = 'invoice' AND i.status IN ('issued','partially_paid')`) },
  credit_notes: { title: 'Avoirs émis', domain: ['finance'], columns: [], run: (c, lim, off) => invList(c, lim, off, `i.type = 'credit_note'`) },
  hk_done: {
    title: 'Tâches housekeeping terminées', domain: ['housekeeping'],
    columns: [col('date', 'Terminée le'), col('room', 'Chambre'), col('kind', 'Type'), col('by', 'Par'), col('minutes', 'Durée (min)', 'int'), col('status', 'Statut'), col('late', 'En retard')],
    run: (c, lim, off) => page(c, `SELECT t.*, r.number, u.full_name AS by, count(*) OVER() AS _n FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id LEFT JOIN users u ON u.id = t.completed_by
        WHERE r.hotel_id = $1 AND t.status IN ('done','to_inspect','validated') AND (t.completed_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR t.kind = $5) ORDER BY t.completed_at DESC`,
      [c.hotelId, c.P.from, c.P.to, c.tz, c.F.category ?? null], lim, off, (x) => ({ date: dt(c, x.completed_at), room: x.number, kind: x.kind, by: x.by ?? '', minutes: x.started_at ? Math.round((+new Date(x.completed_at) - +new Date(x.started_at)) / 60000) : '', status: x.status, late: x.due_at && new Date(x.completed_at) > new Date(x.due_at) ? 'Oui' : '' })),
  },
  hk_late: {
    title: 'Tâches housekeeping en retard', domain: ['housekeeping'],
    columns: [col('date', 'Date'), col('room', 'Chambre'), col('kind', 'Type'), col('due', 'Échéance'), col('done', 'Terminée'), col('by', 'Assignée à')],
    run: (c, lim, off) => page(c, `SELECT t.*, r.number, u.full_name AS by, count(*) OVER() AS _n FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id LEFT JOIN users u ON u.id = COALESCE(t.completed_by, t.assigned_to)
        WHERE r.hotel_id = $1 AND t.task_date BETWEEN $2 AND $3 AND t.due_at IS NOT NULL AND ((t.completed_at > t.due_at) OR (t.status IN ('todo','in_progress') AND t.due_at < now())) ORDER BY t.due_at DESC`,
      [c.hotelId, c.P.from, c.P.to], lim, off, (x) => ({ date: d10(x.task_date), room: x.number, kind: x.kind, due: dt(c, x.due_at), done: x.completed_at ? dt(c, x.completed_at) : 'Non terminée', by: x.by ?? '' })),
  },
  hk_inspections: {
    title: 'Inspections', domain: ['housekeeping'],
    columns: [col('date', 'Date'), col('room', 'Chambre'), col('result', 'Résultat'), col('score', 'Note', 'int'), col('by', 'Inspecteur'), col('remarks', 'Remarques')],
    run: (c, lim, off) => page(c, `SELECT i.*, r.number, u.full_name AS by, count(*) OVER() AS _n FROM hk_inspections i JOIN rooms r ON r.id = i.room_id LEFT JOIN users u ON u.id = i.inspector_id
        WHERE r.hotel_id = $1 AND (i.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 ORDER BY i.created_at DESC`, [c.hotelId, c.P.from, c.P.to, c.tz], lim, off,
      (x) => ({ date: dt(c, x.created_at), room: x.number, result: x.result === 'passed' ? 'Validée' : 'Refusée', score: x.score ?? '', by: x.by ?? '', remarks: x.remarks ?? '' })),
  },
  stock_in: { title: 'Entrées de stock', domain: ['stock'], columns: [], run: (c, lim, off) => moves(c, lim, off, `m.quantity > 0 AND m.kind <> 'transfer_in'`) },
  stock_out: { title: 'Sorties et consommations de stock', domain: ['stock'], columns: [], run: (c, lim, off) => moves(c, lim, off, `m.quantity < 0 AND m.kind <> 'transfer_out'`) },
  stock_losses: { title: 'Pertes, produits détériorés et périmés', domain: ['stock'], columns: [], run: (c, lim, off) => moves(c, lim, off, `m.kind IN ('waste','damaged','expired')`) },
  stock_alerts: {
    title: 'Produits en rupture ou sous le minimum', domain: ['stock'],
    columns: [col('code', 'Code'), col('name', 'Produit'), col('category', 'Catégorie'), col('qty', 'Stock'), col('min', 'Minimum'), col('unit', 'Unité'), col('state', 'État')],
    run: (c, lim, off) => page(c, `SELECT p.*, count(*) OVER() AS _n FROM products p WHERE p.hotel_id = $1 AND p.active AND p.archived_at IS NULL AND (p.stock_qty <= 0 OR p.stock_qty < p.min_stock) AND ($2::text IS NULL OR p.category = $2) ORDER BY p.stock_qty <= 0 DESC, p.name`,
      [c.hotelId, c.F.category ?? null], lim, off, (x) => ({ code: x.code ?? '', name: x.name, category: x.category ?? '', qty: n0(x.stock_qty), min: n0(x.min_stock), unit: x.unit, state: n0(x.stock_qty) <= 0 ? 'Rupture' : 'Sous le minimum' })),
  },
  stock_expiring: {
    title: 'Lots périmés ou à péremption proche (30 jours)', domain: ['stock'],
    columns: [col('name', 'Produit'), col('lot', 'Lot'), col('warehouse', 'Entrepôt'), col('qty', 'Quantité'), col('expiry', 'Péremption'), col('state', 'État')],
    run: (c, lim, off) => page(c, `SELECT l.*, p.name, w.name AS warehouse, count(*) OVER() AS _n FROM stock_lots l JOIN products p ON p.id = l.product_id LEFT JOIN warehouses w ON w.id = l.warehouse_id
        WHERE p.hotel_id = $1 AND l.qty > 0 AND l.expiry_date IS NOT NULL AND l.expiry_date <= $2::date + 30 ORDER BY l.expiry_date`, [c.hotelId, c.P.today], lim, off,
      (x) => ({ name: x.name, lot: x.lot_no ?? '', warehouse: x.warehouse ?? '', qty: n0(x.qty), expiry: d10(x.expiry_date), state: d10(x.expiry_date) < c.P.today ? 'Périmé' : 'Proche' })),
  },
  wo_done: { title: 'Interventions réalisées', domain: ['maintenance'], columns: [], run: (c, lim, off) => wos(c, lim, off, `w.status IN ('done','validated') AND (w.completed_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`) },
  wo_open: { title: 'Interventions en attente', domain: ['maintenance'], columns: [], run: (c, lim, off) => wos(c, lim, off, `w.status IN ('planned','in_progress','on_hold') AND $2::date IS NOT NULL AND $3::date IS NOT NULL AND $4::text IS NOT NULL`) },
  tickets: {
    title: 'Pannes signalées', domain: ['maintenance'],
    columns: [col('number', 'N°'), col('date', 'Signalée le'), col('title', 'Objet'), col('equipment', 'Équipement'), col('room', 'Chambre'), col('priority', 'Priorité'), col('status', 'Statut')],
    run: (c, lim, off) => page(c, `SELECT t.*, e.name AS equipment, r.number AS room, count(*) OVER() AS _n FROM maintenance_tickets t LEFT JOIN equipment e ON e.id = t.equipment_id LEFT JOIN rooms r ON r.id = t.room_id
        WHERE t.hotel_id = $1 AND (t.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR e.category = $5) ORDER BY t.created_at DESC`, [c.hotelId, c.P.from, c.P.to, c.tz, c.F.category ?? null], lim, off,
      (x) => ({ number: x.number ?? x.id, date: dt(c, x.created_at), title: x.title, equipment: x.equipment ?? '', room: x.room ?? '', priority: x.priority, status: x.status })),
  },
  hr_late: {
    title: 'Retards', domain: ['hr'],
    columns: [col('date', 'Date'), col('matricule', 'Matricule'), col('name', 'Employé'), col('department', 'Département'), col('late', 'Retard (min)', 'int')],
    run: async (c, lim, off) => { const d = await hrDepts(c); return page(c, `SELECT a.*, e.matricule, e.last_name, e.first_name, e.department, count(*) OVER() AS _n FROM hr_attendance a JOIN employees e ON e.id = a.employee_id
        WHERE a.hotel_id = $1 AND a.work_date BETWEEN $2 AND $3 AND a.late_minutes > 0 AND ($4::text[] IS NULL OR e.department = ANY($4)) ORDER BY a.work_date DESC`, [c.hotelId, c.P.from, c.P.to, d], lim, off,
      (x) => ({ date: d10(x.work_date), matricule: x.matricule ?? '', name: `${x.last_name} ${x.first_name}`, department: x.department ?? '', late: x.late_minutes })); },
  },
  hr_absences: {
    title: 'Absences non justifiées (poste planifié sans pointage ni congé)', domain: ['hr'],
    columns: [col('date', 'Date'), col('matricule', 'Matricule'), col('name', 'Employé'), col('department', 'Département'), col('shift', 'Horaire prévu')],
    run: async (c, lim, off) => { const d = await hrDepts(c); return page(c, `SELECT sc.*, e.matricule, e.last_name, e.first_name, e.department, count(*) OVER() AS _n FROM hr_schedule sc JOIN employees e ON e.id = sc.employee_id
        WHERE sc.hotel_id = $1 AND sc.work_date BETWEEN $2 AND $3 AND sc.work_date < $5::date AND NOT sc.rest AND ($4::text[] IS NULL OR e.department = ANY($4))
          AND NOT EXISTS (SELECT 1 FROM hr_attendance a WHERE a.employee_id = sc.employee_id AND a.work_date = sc.work_date AND a.clock_in IS NOT NULL)
          AND NOT EXISTS (SELECT 1 FROM hr_leave_requests l WHERE l.employee_id = sc.employee_id AND l.status = 'approved' AND sc.work_date BETWEEN l.start_date AND l.end_date) ORDER BY sc.work_date DESC`,
      [c.hotelId, c.P.from, c.P.to, d, c.P.today], lim, off, (x) => ({ date: d10(x.work_date), matricule: x.matricule ?? '', name: `${x.last_name} ${x.first_name}`, department: x.department ?? '', shift: `${String(x.start_time ?? '').slice(0, 5)}–${String(x.end_time ?? '').slice(0, 5)}` })); },
  },
  hr_leaves: {
    title: 'Congés validés sur la période', domain: ['hr'],
    columns: [col('number', 'N°'), col('name', 'Employé'), col('type', 'Type'), col('from', 'Du'), col('to', 'Au'), col('days', 'Jours')],
    run: async (c, lim, off) => { const d = await hrDepts(c); return page(c, `SELECT l.*, t.name AS type, e.last_name, e.first_name, count(*) OVER() AS _n FROM hr_leave_requests l JOIN employees e ON e.id = l.employee_id JOIN hr_leave_types t ON t.id = l.type_id
        WHERE l.hotel_id = $1 AND l.status = 'approved' AND l.start_date <= $3 AND l.end_date >= $2 AND ($4::text[] IS NULL OR e.department = ANY($4)) ORDER BY l.start_date DESC`, [c.hotelId, c.P.from, c.P.to, d], lim, off,
      (x) => ({ number: x.number, name: `${x.last_name} ${x.first_name}`, type: x.type, from: d10(x.start_date), to: d10(x.end_date), days: n0(x.days) })); },
  },
  new_clients: {
    title: 'Nouveaux clients', domain: ['crm'],
    columns: [col('code', 'Code'), col('name', 'Client'), col('country', 'Origine'), col('status', 'Statut'), col('created', 'Créé le')],
    run: (c, lim, off) => page(c, `SELECT g.*, count(*) OVER() AS _n FROM guests g WHERE g.hotel_id = $1 AND g.merged_into_id IS NULL AND g.anonymized_at IS NULL AND (g.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 ORDER BY g.created_at DESC`,
      [c.hotelId, c.P.from, c.P.to, c.tz], lim, off, (x) => ({ code: x.code, name: gname(x), country: x.country ?? x.nationality ?? '', status: x.crm_status, created: dt(c, x.created_at) })),
  },
  complaints: {
    title: 'Réclamations', domain: ['crm'],
    columns: [col('number', 'N°'), col('date', 'Date'), col('client', 'Client'), col('category', 'Catégorie'), col('title', 'Objet'), col('priority', 'Priorité'), col('status', 'Statut')],
    run: (c, lim, off) => page(c, `SELECT cp.*, g.kind, g.last_name, g.first_name, g.company_name, count(*) OVER() AS _n FROM crm_complaints cp JOIN guests g ON g.id = cp.guest_id
        WHERE cp.hotel_id = $1 AND cp.kind = 'complaint' AND (cp.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 ORDER BY cp.created_at DESC`, [c.hotelId, c.P.from, c.P.to, c.tz], lim, off,
      (x) => ({ number: x.number, date: dt(c, x.created_at), client: gname(x), category: x.category, title: x.title, priority: x.priority, status: x.status })),
  },
};
const INV_COLS = DRILLS.invoices.columns;
DRILLS.invoices_unpaid.columns = INV_COLS;
DRILLS.credit_notes.columns = INV_COLS;
const TYPE_LBL: Record<string, string> = { invoice: 'Facture', credit_note: 'Avoir' };
const ST_LBL: Record<string, string> = { issued: 'Impayée', partially_paid: 'Partiellement payée', paid: 'Payée', credited: 'Annulée par avoir', cancelled: 'Annulée' };
function invList(c: Ctx, lim: number, off: number, where: string) {
  const P = [c.hotelId, c.P.from, c.P.to, c.tz];
  const W = `i.hotel_id = $1 AND ${where} AND (i.issued_at AT TIME ZONE $4)::date BETWEEN $2 AND $3`;
  return page(c, `SELECT i.*, r.code, count(*) OVER() AS _n FROM invoices i LEFT JOIN reservations r ON r.id = i.reservation_id WHERE ${W} ORDER BY i.issued_at DESC`, P, lim, off,
    (x) => ({ number: x.number, date: dt(c, x.issued_at), type: TYPE_LBL[x.type] ?? x.type, client: x.bill_to?.name ?? '', ref: x.code ?? '', status: ST_LBL[x.status] ?? x.status, total: n0(x.total) }),
    { sql: `SELECT 'Total' AS number, COALESCE(sum(i.total),0) AS total FROM invoices i WHERE ${W}`, params: P });
}
const KL: Record<string, string> = { in: 'Entrée', out: 'Sortie', adjust: 'Ajustement', sale: 'Vente', waste: 'Perte', receipt: 'Réception achat', issue: 'Sortie service', supplier_return: 'Retour fournisseur', inventory: 'Inventaire', damaged: 'Détérioré', expired: 'Périmé' };
const MV_COLS = [col('date', 'Date'), col('product', 'Produit'), col('kind', 'Mouvement'), col('department', 'Service'), col('qty', 'Quantité'), col('value', 'Valeur', 'money'), col('reason', 'Motif')];
DRILLS.stock_in.columns = MV_COLS; DRILLS.stock_out.columns = MV_COLS; DRILLS.stock_losses.columns = MV_COLS;
function moves(c: Ctx, lim: number, off: number, where: string) {
  const P = [c.hotelId, c.P.from, c.P.to, c.tz, c.F.department ?? null, c.F.category ?? null];
  const W = `p.hotel_id = $1 AND (m.created_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR m.department = $5) AND ($6::text IS NULL OR p.category = $6) AND ${where}`;
  const V = `COALESCE(m.value, m.quantity * COALESCE(m.unit_cost, p.avg_cost, 0), 0)`;
  return page(c, `SELECT m.*, p.name, ${V} AS v, count(*) OVER() AS _n FROM stock_movements m JOIN products p ON p.id = m.product_id WHERE ${W} ORDER BY m.created_at DESC`, P, lim, off,
    (x) => ({ date: dt(c, x.created_at), product: x.name, kind: KL[x.kind] ?? x.kind, department: x.department ?? '', qty: n0(x.quantity), value: r2(n0(x.v)), reason: x.reason ?? '' }),
    { sql: `SELECT 'Total' AS date, COALESCE(sum(${V}),0) AS value FROM stock_movements m JOIN products p ON p.id = m.product_id WHERE ${W}`, params: P });
}
const WO_COLS = [col('number', 'N°'), col('title', 'Objet'), col('kind', 'Type'), col('equipment', 'Équipement'), col('technician', 'Technicien'), col('status', 'Statut'), col('created', 'Créée'), col('completed', 'Terminée'), col('cost', 'Coût', 'money')];
DRILLS.wo_done.columns = WO_COLS; DRILLS.wo_open.columns = WO_COLS;
function wos(c: Ctx, lim: number, off: number, where: string) {
  const P = [c.hotelId, c.P.from, c.P.to, c.tz, c.F.category ?? null];
  const W = `w.hotel_id = $1 AND ${where} AND ($5::text IS NULL OR e.category = $5)`;
  return page(c, `SELECT w.*, e.name AS equipment, t.name AS technician, count(*) OVER() AS _n FROM work_orders w LEFT JOIN equipment e ON e.id = w.equipment_id LEFT JOIN maintenance_technicians t ON t.id = w.technician_id
      WHERE ${W} ORDER BY COALESCE(w.completed_at, w.created_at) DESC`, P, lim, off,
    (x) => ({ number: x.number, title: x.title, kind: x.kind, equipment: x.equipment ?? '', technician: x.technician ?? '', status: x.status, created: dt(c, x.created_at), completed: dt(c, x.completed_at), cost: n0(x.total_cost) }),
    { sql: `SELECT 'Total' AS number, COALESCE(sum(w.total_cost),0) AS cost FROM work_orders w LEFT JOIN equipment e ON e.id = w.equipment_id WHERE ${W}`, params: P });
}
async function hrDepts(c: Ctx) {
  const s = await scopeOf(c.db, c.actor as any, c.perms);
  return c.F.department ? [c.F.department] : s.all ? null : s.departments;
}
export const fmtResStatus = RES_STATUS_LBL;
