import type { PoolClient } from 'pg';
import type { Db } from '../db/pool.js';
import { one, q } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { addDays, today } from '../lib/dates.js';
import { badRequest, conflict, notFound } from '../lib/errors.js';
import { guestDisplayName } from './common.js';
import { markRoomDirty } from './reservations.js';
import { loadPricing, nightPrice } from './pricing.js';

const clean = (v: unknown) => (typeof v === 'string' ? (v.trim() === '' ? null : v.trim()) : v ?? null);

// ======================= Statuts =======================

/**
 * Statut d'occupation (Disponible / Occupée / Réservée / En maintenance / Hors service)
 * calculé à partir des séjours, réservations, blocages et tickets — distinct de l'état de propreté (hk_status).
 */
export const ROOM_STATUS_SQL = `
  CASE
    WHEN NOT r.active THEN 'inactive'
    WHEN EXISTS (SELECT 1 FROM room_blocks b WHERE b.room_id = r.id AND b.status = 'active' AND b.kind = 'out_of_service'
                  AND b.start_date <= $D::date AND (b.end_date IS NULL OR b.end_date > $D::date)) THEN 'out_of_service'
    WHEN EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL) THEN 'occupied'
    WHEN EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.room_id = r.id AND rr.status IN ('pending','confirmed')
                  AND rr.check_in <= $D::date AND rr.check_out > $D::date) THEN 'reserved'
    WHEN EXISTS (SELECT 1 FROM maintenance_tickets m WHERE m.room_id = r.id AND m.status IN ('new','assigned','in_progress','waiting_parts'))
      OR EXISTS (SELECT 1 FROM room_blocks b WHERE b.room_id = r.id AND b.status = 'active' AND b.kind = 'maintenance'
                  AND b.start_date <= $D::date AND (b.end_date IS NULL OR b.end_date > $D::date)) THEN 'maintenance'
    ELSE 'available'
  END`;

/** Aligne l'indicateur « hors service aujourd'hui » des chambres sur les blocages datés. */
export async function syncOutOfService(db: Db, hotelId: number, roomId?: number) {
  const t = today();
  await db.query(
    `UPDATE rooms r SET
        out_of_service = b.id IS NOT NULL,
        oos_reason = b.reason
       FROM (SELECT r2.id AS room_id, (SELECT x.id FROM room_blocks x WHERE x.room_id = r2.id AND x.status = 'active' AND x.kind = 'out_of_service'
                                         AND x.start_date <= $2::date AND (x.end_date IS NULL OR x.end_date > $2::date) ORDER BY x.start_date LIMIT 1) AS id
               FROM rooms r2 WHERE r2.hotel_id = $1 AND ($3::int IS NULL OR r2.id = $3)) sel
       LEFT JOIN room_blocks b ON b.id = sel.id
      WHERE r.id = sel.room_id AND (r.out_of_service IS DISTINCT FROM (b.id IS NOT NULL) OR r.oos_reason IS DISTINCT FROM b.reason)`,
    [hotelId, t, roomId ?? null],
  );
}

// ======================= Blocages (hors service / maintenance) =======================

export async function createBlock(
  db: PoolClient, actor: Actor, roomId: number,
  b: { start_date: string; end_date?: string | null; reason: string; kind?: 'out_of_service' | 'maintenance'; ticket_id?: number | null; priority?: string },
) {
  const room = await one<any>(db, 'SELECT * FROM rooms WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [roomId, actor.hotelId]);
  if (!room) throw notFound('Chambre introuvable');
  if (!clean(b.reason)) throw badRequest('Le motif est obligatoire.');
  const t = today();
  if (b.start_date < t) throw badRequest('La date de début ne peut pas être passée.');
  if (b.end_date && b.end_date <= b.start_date) throw badRequest('La date de fin doit être après la date de début.');
  const kind = b.kind ?? 'out_of_service';
  if (kind === 'out_of_service') {
    if (b.start_date <= t) {
      const occ = await one(db, `SELECT 1 FROM stays WHERE room_id = $1 AND checked_out_at IS NULL`, [roomId]);
      if (occ) throw conflict(`Chambre ${room.number} occupée : changez d'abord le client de chambre ou faites son check-out.`);
    }
    const clash = await q<any>(
      db,
      `SELECT r.code, rr.check_in, rr.check_out FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id
        WHERE rr.room_id = $1 AND rr.status IN ('pending','confirmed','checked_in')
          AND rr.check_in < COALESCE($3::date, 'infinity'::date) AND rr.check_out > $2::date ORDER BY rr.check_in LIMIT 10`,
      [roomId, b.start_date, b.end_date ?? null],
    );
    if (clash.length) {
      throw conflict(`Réservations à déplacer avant de bloquer la chambre ${room.number} : ${clash.map((c) => `${c.code} (${c.check_in} → ${c.check_out})`).join(', ')}.`, { reservations: clash });
    }
  }
  let ticketId = b.ticket_id ?? null;
  if (!ticketId) {
    const tk = await one<any>(
      db,
      `INSERT INTO maintenance_tickets (room_id, title, priority, puts_out_of_service, reported_by, category, source) VALUES ($1,$2,$3,$4,$5,'block','block') RETURNING id`,
      [roomId, b.reason.trim(), b.priority ?? (kind === 'out_of_service' ? 'high' : 'normal'), kind === 'out_of_service', actor.userId],
    );
    ticketId = tk.id;
  }
  const block = await one<any>(
    db,
    `INSERT INTO room_blocks (room_id, kind, start_date, end_date, reason, ticket_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [roomId, kind, b.start_date, b.end_date ?? null, b.reason.trim(), ticketId, actor.userId],
  );
  await syncOutOfService(db, actor.hotelId, roomId);
  await audit(db, actor, kind === 'out_of_service' ? 'out_of_service' : 'maintenance', 'room', roomId, null, { block_id: block.id, start: b.start_date, end: b.end_date ?? null, reason: b.reason });
  return block;
}

export async function releaseBlock(db: PoolClient, actor: Actor, blockId: number, opts: { resolution?: string | null; needs_cleaning?: boolean } = {}) {
  const b = await one<any>(db, `SELECT b.*, r.hotel_id, r.number FROM room_blocks b JOIN rooms r ON r.id = b.room_id WHERE b.id = $1 FOR UPDATE OF b`, [blockId]);
  if (!b || b.hotel_id !== actor.hotelId) throw notFound('Blocage introuvable');
  if (b.status !== 'active') throw conflict('Ce blocage est déjà levé.');
  const t = today();
  // période réelle conservée dans l'historique
  let end = b.end_date;
  if (b.start_date > t) end = null; // blocage futur annulé : on le marque levé sans période
  else if (!end || end > t) end = t > b.start_date ? t : addDays(b.start_date, 1);
  await db.query(`UPDATE room_blocks SET status = 'released', end_date = COALESCE($2, end_date), released_by = $3, released_at = now() WHERE id = $1`, [blockId, end, actor.userId]);
  if (b.ticket_id) {
    await db.query(`UPDATE maintenance_tickets SET status = 'resolved', resolved_at = now(), resolved_by = $2, resolution = COALESCE($3, resolution) WHERE id = $1 AND status IN ('new','assigned','in_progress','waiting_parts')`,
      [b.ticket_id, actor.userId, clean(opts.resolution)]);
  }
  if (opts.needs_cleaning !== false && b.start_date <= t) await markRoomDirty(db, actor, b.room_id, null, 'checkout_clean');
  await syncOutOfService(db, actor.hotelId, b.room_id);
  await audit(db, actor, 'back_in_service', 'room', b.room_id, { block_id: blockId, status: 'active' }, { status: 'released', resolution: opts.resolution ?? null });
}

/** Compatibilité : bascule « hors service » immédiat (sans date de fin). */
export async function setRoomOutOfServiceNow(db: PoolClient, actor: Actor, roomId: number, oos: boolean, reason: string | null) {
  if (oos) return createBlock(db, actor, roomId, { start_date: today(), end_date: null, reason: reason ?? '' });
  const t = today();
  const blocks = await q<any>(db, `SELECT id FROM room_blocks WHERE room_id = $1 AND status = 'active' AND kind = 'out_of_service' AND start_date <= $2 AND (end_date IS NULL OR end_date > $2)`, [roomId, t]);
  if (!blocks.length) throw conflict('Aucun blocage en cours pour cette chambre.');
  for (const b of blocks) await releaseBlock(db, actor, b.id, {});
  return null;
}

// ======================= Chambres =======================

export interface RoomInput {
  number?: string;
  floor_id?: number;
  room_type_id?: number;
  capacity?: number | null;
  beds?: number | null;
  description?: string | null;
  features?: string[];
  amenity_ids?: number[];
  rate_supplement?: number;
  sort_order?: number;
  notes?: string | null;
}

async function checkFloorType(db: Db, hotelId: number, r: RoomInput) {
  if (r.floor_id && !(await one(db, 'SELECT 1 FROM floors WHERE id = $1 AND hotel_id = $2', [r.floor_id, hotelId]))) throw badRequest('Étage inconnu.');
  if (r.room_type_id && !(await one(db, 'SELECT 1 FROM room_types WHERE id = $1 AND hotel_id = $2 AND active', [r.room_type_id, hotelId]))) throw badRequest('Type de chambre inconnu ou désactivé.');
}

async function setAmenities(db: Db, table: 'room_amenities' | 'room_type_amenities', col: string, id: number, ids: number[], hotelId: number) {
  await db.query(`DELETE FROM ${table} WHERE ${col} = $1`, [id]);
  if (ids.length) await db.query(`INSERT INTO ${table} (${col}, amenity_id) SELECT $1, id FROM amenities WHERE hotel_id = $2 AND id = ANY($3::int[])`, [id, hotelId, ids]);
}

export async function createRoom(db: PoolClient, actor: Actor, r: RoomInput) {
  if (!clean(r.number)) throw badRequest('Le numéro de chambre est obligatoire.');
  if (!r.floor_id || !r.room_type_id) throw badRequest('Étage et type obligatoires.');
  await checkFloorType(db, actor.hotelId, r);
  const exists = await one<any>(db, 'SELECT active FROM rooms WHERE hotel_id = $1 AND lower(number) = lower($2)', [actor.hotelId, r.number!.trim()]);
  if (exists) throw conflict(`Le numéro ${r.number} existe déjà${exists.active ? '' : ' (chambre désactivée : réactivez-la)'}.`);
  const row = await one<any>(
    db,
    `INSERT INTO rooms (hotel_id, floor_id, room_type_id, number, capacity, beds, description, features, rate_supplement, sort_order, notes)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [actor.hotelId, r.floor_id, r.room_type_id, r.number!.trim(), r.capacity ?? null, r.beds ?? null, clean(r.description),
      JSON.stringify(r.features ?? []), r.rate_supplement ?? 0, r.sort_order ?? 0, clean(r.notes)],
  );
  if (r.amenity_ids) await setAmenities(db, 'room_amenities', 'room_id', row.id, r.amenity_ids, actor.hotelId);
  else await db.query(`INSERT INTO room_amenities (room_id, amenity_id) SELECT $1, amenity_id FROM room_type_amenities WHERE room_type_id = $2`, [row.id, r.room_type_id]);
  await audit(db, actor, 'create', 'room', row.id, null, row);
  return row;
}

/** Réservations futures ou en cours dont l'occupation dépasse une capacité donnée. */
async function overCapacity(db: Db, roomId: number, capacity: number) {
  return q<any>(
    db,
    `SELECT r.code, rr.adults, rr.children FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id
      WHERE rr.room_id = $1 AND rr.status IN ('pending','confirmed','checked_in') AND rr.check_out > $2 AND rr.adults + rr.children > $3`,
    [roomId, today(), capacity],
  );
}

export async function updateRoom(db: PoolClient, actor: Actor, id: number, r: RoomInput) {
  const before = await one<any>(db, 'SELECT * FROM rooms WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!before) throw notFound('Chambre introuvable');
  await checkFloorType(db, actor.hotelId, r);
  if (r.number !== undefined) {
    if (!clean(r.number)) throw badRequest('Le numéro de chambre est obligatoire.');
    const dup = await one(db, 'SELECT 1 FROM rooms WHERE hotel_id = $1 AND lower(number) = lower($2) AND id <> $3', [actor.hotelId, r.number.trim(), id]);
    if (dup) throw conflict(`Le numéro ${r.number} est déjà utilisé.`);
  }
  const typeId = r.room_type_id ?? before.room_type_id;
  const type = await one<any>(db, 'SELECT capacity FROM room_types WHERE id = $1', [typeId]);
  const newCap = r.capacity !== undefined ? r.capacity ?? type.capacity : before.capacity ?? type.capacity;
  const over = await overCapacity(db, id, newCap);
  if (over.length) throw conflict(`Capacité ${newCap} insuffisante pour des réservations à venir : ${over.map((x) => x.code).join(', ')}.`);
  const fields: [string, unknown][] = [];
  if (r.number !== undefined) fields.push(['number', r.number.trim()]);
  if (r.floor_id !== undefined) fields.push(['floor_id', r.floor_id]);
  if (r.room_type_id !== undefined) fields.push(['room_type_id', r.room_type_id]);
  if (r.capacity !== undefined) fields.push(['capacity', r.capacity]);
  if (r.beds !== undefined) fields.push(['beds', r.beds]);
  if (r.description !== undefined) fields.push(['description', clean(r.description)]);
  if (r.features !== undefined) fields.push(['features', JSON.stringify(r.features)]);
  if (r.rate_supplement !== undefined) fields.push(['rate_supplement', r.rate_supplement]);
  if (r.sort_order !== undefined) fields.push(['sort_order', r.sort_order]);
  if (r.notes !== undefined) fields.push(['notes', clean(r.notes)]);
  if (fields.length) {
    await db.query(`UPDATE rooms SET ${fields.map(([k], i) => `${k} = $${i + 2}`).join(', ')}, updated_at = now() WHERE id = $1`, [id, ...fields.map(([, v]) => v)]);
  }
  // changement de catégorie : répercuté sur les réservations en cours et à venir (prix conservés)
  if (r.room_type_id && r.room_type_id !== before.room_type_id) {
    await db.query(`UPDATE reservation_rooms SET room_type_id = $2, updated_at = now() WHERE room_id = $1 AND status IN ('pending','confirmed','checked_in')`, [id, r.room_type_id]);
  }
  if (r.amenity_ids) await setAmenities(db, 'room_amenities', 'room_id', id, r.amenity_ids, actor.hotelId);
  const after = await one<any>(db, 'SELECT * FROM rooms WHERE id = $1', [id]);
  await audit(db, actor, 'update', 'room', id, before, { ...after, amenity_ids: r.amenity_ids });
  return after;
}

export async function deactivateRoom(db: PoolClient, actor: Actor, id: number, reason: string) {
  const room = await one<any>(db, 'SELECT * FROM rooms WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!room) throw notFound('Chambre introuvable');
  if (!room.active) throw conflict('Chambre déjà désactivée.');
  if (!clean(reason)) throw badRequest('Le motif est obligatoire.');
  if (await one(db, `SELECT 1 FROM stays WHERE room_id = $1 AND checked_out_at IS NULL`, [id])) throw conflict('Chambre occupée : impossible de la désactiver.');
  const future = await q<any>(db, `SELECT r.code FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id
                                     WHERE rr.room_id = $1 AND rr.status IN ('pending','confirmed') AND rr.check_out > $2`, [id, today()]);
  if (future.length) throw conflict(`Réservations à déplacer d'abord : ${future.map((x) => x.code).join(', ')}.`, { reservations: future });
  await db.query(`UPDATE rooms SET active = false, deactivated_at = now(), deactivation_reason = $2, updated_at = now() WHERE id = $1`, [id, reason.trim()]);
  await audit(db, actor, 'deactivate', 'room', id, { active: true }, { active: false, reason });
}

export async function reactivateRoom(db: PoolClient, actor: Actor, id: number) {
  const room = await one<any>(db, 'SELECT * FROM rooms WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!room) throw notFound('Chambre introuvable');
  if (room.active) throw conflict('Chambre déjà active.');
  await db.query(`UPDATE rooms SET active = true, deactivated_at = NULL, deactivation_reason = NULL, hk_status = 'to_clean', updated_at = now() WHERE id = $1`, [id]);
  await audit(db, actor, 'reactivate', 'room', id, { active: false }, { active: true });
}

/** Fiche complète d'une chambre. */
export async function roomDetail(db: Db, hotelId: number, id: number) {
  const t = today();
  const room = await one<any>(
    db,
    `SELECT r.*, ${ROOM_STATUS_SQL.replaceAll('$D', '$3')} AS status,
            COALESCE(r.capacity, t.capacity) AS eff_capacity, COALESCE(r.beds, t.beds) AS eff_beds,
            row_to_json(t.*) AS type, f.number AS floor_number, f.name AS floor_name, b.id AS building_id, b.name AS building_name
       FROM rooms r JOIN room_types t ON t.id = r.room_type_id JOIN floors f ON f.id = r.floor_id JOIN buildings b ON b.id = f.building_id
      WHERE r.id = $1 AND r.hotel_id = $2`,
    [id, hotelId, t],
  );
  if (!room) throw notFound('Chambre introuvable');
  const amenities = await q<any>(db, `SELECT a.* FROM room_amenities ra JOIN amenities a ON a.id = ra.amenity_id WHERE ra.room_id = $1 ORDER BY a.name_fr`, [id]);
  const photos = await q<any>(db, `SELECT id, caption, sort_order FROM photos WHERE (owner_type = 'room' AND owner_id = $1) ORDER BY sort_order, id`, [id]);
  const typePhotos = await q<any>(db, `SELECT id, caption FROM photos WHERE owner_type = 'room_type' AND owner_id = $1 ORDER BY sort_order, id`, [room.room_type_id]);
  const guestCols = `g.kind, g.last_name, g.first_name, g.company_name, og.kind AS o_kind, og.last_name AS o_last, og.first_name AS o_first, og.company_name AS o_company`;
  const mapG = (x: any) => ({ ...x, guest_name: x.o_kind ? guestDisplayName({ kind: x.o_kind, last_name: x.o_last, first_name: x.o_first, company_name: x.o_company }) : guestDisplayName(x) });
  const current = await one<any>(
    db,
    `SELECT rr.id AS rr_id, rr.reservation_id, rr.check_in, rr.check_out, r.code, s.checked_in_at, ${guestCols}
       FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN reservations r ON r.id = rr.reservation_id
       JOIN guests g ON g.id = r.guest_id LEFT JOIN guests og ON og.id = rr.guest_id
      WHERE s.room_id = $1 AND s.checked_out_at IS NULL`,
    [id],
  );
  const upcoming = await q<any>(
    db,
    `SELECT rr.id AS rr_id, rr.reservation_id, rr.check_in, rr.check_out, rr.status, r.code, ${guestCols}
       FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id JOIN guests g ON g.id = r.guest_id LEFT JOIN guests og ON og.id = rr.guest_id
      WHERE rr.room_id = $1 AND rr.status IN ('pending','confirmed') AND rr.check_out > $2 ORDER BY rr.check_in LIMIT 30`,
    [id, t],
  );
  const history = await q<any>(
    db,
    `SELECT rr.id AS rr_id, rr.reservation_id, rr.check_in, rr.check_out, rr.rate, r.code, s.checked_in_at, s.checked_out_at, ${guestCols}
       FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN reservations r ON r.id = rr.reservation_id
       JOIN guests g ON g.id = r.guest_id LEFT JOIN guests og ON og.id = rr.guest_id
      WHERE s.room_id = $1 AND s.checked_out_at IS NOT NULL ORDER BY s.checked_out_at DESC LIMIT 50`,
    [id],
  );
  const tickets = await q<any>(
    db,
    `SELECT m.*, u.full_name AS reported_by_name, u2.full_name AS resolved_by_name FROM maintenance_tickets m
       LEFT JOIN users u ON u.id = m.reported_by LEFT JOIN users u2 ON u2.id = m.resolved_by WHERE m.room_id = $1 ORDER BY m.created_at DESC LIMIT 50`,
    [id],
  );
  const blocks = await q<any>(
    db,
    `SELECT b.*, u.full_name AS created_by_name, u2.full_name AS released_by_name FROM room_blocks b
       LEFT JOIN users u ON u.id = b.created_by LEFT JOIN users u2 ON u2.id = b.released_by WHERE b.room_id = $1 ORDER BY b.start_date DESC, b.id DESC LIMIT 50`,
    [id],
  );
  const cleaning = await q<any>(
    db,
    `SELECT h.*, u.full_name AS completed_by_name FROM housekeeping_tasks h LEFT JOIN users u ON u.id = h.completed_by
      WHERE h.room_id = $1 ORDER BY h.created_at DESC LIMIT 50`,
    [id],
  );
  const changes = await q<any>(
    db,
    `SELECT a.action, a.before, a.after, a.created_at, u.full_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
      WHERE a.entity = 'room' AND a.entity_id = $1 ORDER BY a.created_at DESC LIMIT 50`,
    [String(id)],
  );
  const ctx = await loadPricing(db, hotelId);
  const tonight = nightPrice(ctx, room.type, room, t, 'RO', 1, 0, null);
  return {
    ...room, amenities, photos, type_photos: typePhotos, price_tonight: tonight,
    current: current ? mapG(current) : null, upcoming: upcoming.map(mapG), history: history.map(mapG),
    tickets, blocks, cleaning, changes,
  };
}
