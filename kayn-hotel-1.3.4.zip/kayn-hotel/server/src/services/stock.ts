/**
 * Stocks : service central de tous les mouvements (multi-entrepôts, lots / péremption FEFO, prix moyen pondéré),
 * transferts, inventaires, alertes, tableau de bord, rapports.
 * Toute modification de stock passe par moveStock() — dans la transaction de l'appelant — : produit et niveau
 * d'entrepôt verrouillés, contrôle du disponible, mouvement immuable avec valeur, total produit tenu à jour.
 */
import { currency } from './exports.js';
import type { PoolClient } from 'pg';
import { one, q, type Db } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { addDays, monthStart, today } from '../lib/dates.js';
import { AppError, badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { fromCents, toCents } from '../lib/money.js';
import { getSettings, nextNumber } from './common.js';
import { config } from '../config.js';

const TZ = config.timezone ?? 'Africa/Algiers';
export const STOCK_CATEGORIES = ['Alimentation', 'Boissons', 'Produits de nettoyage', 'Linge et textile', 'Produits d\'accueil', 'Fournitures administratives', 'Matériel et équipements', 'Autres consommables'];
export const UNITS = ['pièce', 'kg', 'g', 'L', 'cL', 'carton', 'paquet', 'bouteille', 'boîte', 'rouleau', 'sachet', 'unité'];
export const DEPARTMENTS = ['restaurant', 'bar', 'housekeeping', 'maintenance', 'reception', 'admin', 'other'] as const;
export const KIND_LABEL: Record<string, string> = {
  in: 'Entrée', out: 'Sortie', adjust: 'Ajustement', sale: 'Vente (restaurant)', waste: 'Perte', receipt: 'Réception fournisseur', issue: 'Sortie consommation',
  transfer_out: 'Transfert (sortie)', transfer_in: 'Transfert (entrée)', supplier_return: 'Retour fournisseur', inventory: 'Ajustement d\'inventaire', damaged: 'Produit endommagé', expired: 'Produit périmé',
};
export const DEPT_LABEL: Record<string, string> = { restaurant: 'Restaurant', bar: 'Bar', housekeeping: 'Housekeeping', maintenance: 'Maintenance', reception: 'Réception', admin: 'Administration', other: 'Autre' };
const ENTRY_COST = new Set(['receipt', 'in']);        // entrées qui recalculent le prix moyen pondéré
const n3 = (v: any) => Math.round(Number(v ?? 0) * 1000) / 1000;
const n2 = (v: any) => Math.round(Number(v ?? 0) * 100) / 100;

export async function stockSettings(db: Db, hotelId: number) {
  return (await getSettings(db, hotelId)).stock as {
    expiry_alert_days: number; inventory_gap_percent: number; inventory_gap_value: number; restaurant_warehouse_id: number | null; purchase_category: string; late_po_days: number;
  };
}

export async function defaultWarehouse(db: Db, hotelId: number) {
  const w = await one<any>(db, 'SELECT * FROM warehouses WHERE hotel_id = $1 AND is_default', [hotelId]);
  if (!w) throw conflict('Aucun entrepôt par défaut : créez un magasin.');
  return w;
}
async function warehouseOf(db: Db, hotelId: number, id: number | null | undefined) {
  if (!id) return defaultWarehouse(db, hotelId);
  const w = await one<any>(db, 'SELECT * FROM warehouses WHERE id = $1 AND hotel_id = $2', [id, hotelId]);
  if (!w) throw notFound('Entrepôt introuvable');
  if (!w.active) throw conflict(`Entrepôt « ${w.name} » archivé.`);
  return w;
}
/** Entrepôt dont le restaurant consomme les ingrédients. */
export async function restaurantWarehouse(db: Db, hotelId: number) {
  const s = await stockSettings(db, hotelId);
  return s.restaurant_warehouse_id ? warehouseOf(db, hotelId, s.restaurant_warehouse_id).catch(() => defaultWarehouse(db, hotelId)) : defaultWarehouse(db, hotelId);
}

export interface MoveIn {
  product_id: number; warehouse_id?: number | null; kind: string; quantity: number; reason?: string | null; department?: string | null;
  unit_cost?: number | null; lot_no?: string | null; expiry_date?: string | null; lot_id?: number | null;
  ref_type?: string | null; ref_id?: number | null; rs_order_id?: number | null;
  force?: boolean;          // l'appelant a vérifié le droit stock.force
  allowNegative?: boolean;  // opération système (vente déjà validée)
}

/** Mouvement de stock unique (signe = sens). Retourne le mouvement, les lots consommés et une éventuelle alerte. */
export async function moveStock(db: PoolClient, actor: Actor, m: MoveIn) {
  const qty = n3(m.quantity);
  if (!qty) throw badRequest('Quantité nulle.');
  const p = await one<any>(db, 'SELECT * FROM products WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [m.product_id, actor.hotelId]);
  if (!p) throw notFound('Article introuvable');
  if (qty > 0 && p.archived_at && m.kind !== 'inventory') throw conflict(`« ${p.name} » est archivé : réactivez-le avant une entrée.`);
  const w = await warehouseOf(db, actor.hotelId, m.warehouse_id ?? p.default_warehouse_id);
  await db.query('INSERT INTO stock_levels (product_id, warehouse_id, qty) VALUES ($1,$2,0) ON CONFLICT DO NOTHING', [p.id, w.id]);
  const lvl = await one<any>(db, 'SELECT qty FROM stock_levels WHERE product_id = $1 AND warehouse_id = $2 FOR UPDATE', [p.id, w.id]);
  const avail = Number(lvl.qty);
  let forced = false;
  if (qty < 0 && avail + qty < -1e-9) {
    if (m.force) forced = true;
    else if (!m.allowNegative) throw new AppError(409, 'insufficient_stock', `Stock insuffisant : « ${p.name} » — ${n3(avail)} ${p.unit} disponible(s) dans « ${w.name} », ${n3(-qty)} demandé(s).`, { available: avail });
  }
  // prix moyen pondéré : recalculé sur les entrées valorisées (réceptions, entrées manuelles avec prix)
  const total = Number(p.stock_qty);
  let avg = Number(p.avg_cost);
  // entrée sans prix : coût moyen actuel, à défaut dernier prix d'achat connu
  let cost = m.unit_cost != null ? Number(m.unit_cost) : avg || Number(p.cost_price) || 0;
  if (qty > 0 && ENTRY_COST.has(m.kind) && m.unit_cost == null && !avg) avg = cost;
  if (qty > 0 && ENTRY_COST.has(m.kind) && m.unit_cost != null) {
    const base = Math.max(total, 0);
    avg = base + qty > 0 ? (base * avg + qty * cost) / (base + qty) : cost;
  }
  if (qty < 0) cost = avg;
  // lots
  let lotId: number | null = null;
  const consumed: { lot_id: number; lot_no: string | null; expiry_date: string | null; qty: number }[] = [];
  if (p.track_lots) {
    if (qty > 0) {
      if (m.kind === 'receipt' && !m.expiry_date && !m.lot_no) throw badRequest(`« ${p.name} » : n° de lot ou date de péremption obligatoire.`);
      lotId = (await one<any>(db, 'INSERT INTO stock_lots (product_id, warehouse_id, lot_no, expiry_date, qty) VALUES ($1,$2,$3,$4,$5) RETURNING id',
        [p.id, w.id, m.lot_no?.trim() || null, m.expiry_date || null, qty])).id;
    } else {
      let left = -qty;
      const lots = await q<any>(db, `SELECT * FROM stock_lots WHERE product_id = $1 AND warehouse_id = $2 AND qty > 0
          ORDER BY (id = $3) DESC, expiry_date NULLS LAST, id FOR UPDATE`, [p.id, w.id, m.lot_id ?? 0]);
      if (m.lot_id && !lots.some((l) => l.id === m.lot_id)) throw badRequest('Lot introuvable dans cet entrepôt.');
      for (const l of lots) {
        if (left <= 1e-9) break;
        const take = Math.min(left, Number(l.qty));
        await db.query('UPDATE stock_lots SET qty = qty - $2 WHERE id = $1', [l.id, take]);
        consumed.push({ lot_id: l.id, lot_no: l.lot_no, expiry_date: l.expiry_date ? String(l.expiry_date).slice(0, 10) : null, qty: n3(take) });
        left = n3(left - take);
      }
      if (consumed.length === 1) lotId = consumed[0].lot_id;
    }
  }
  await db.query('UPDATE stock_levels SET qty = qty + $3 WHERE product_id = $1 AND warehouse_id = $2', [p.id, w.id, qty]);
  const up = await one<any>(db, `UPDATE products SET stock_qty = stock_qty + $2, avg_cost = $3, cost_price = CASE WHEN $4::boolean THEN $5 ELSE cost_price END, updated_at = now()
      WHERE id = $1 RETURNING stock_qty, min_stock`, [p.id, qty, Math.round(avg * 10000) / 10000, m.kind === 'receipt' && m.unit_cost != null, m.unit_cost ?? 0]);
  const mv = await one<any>(db,
    `INSERT INTO stock_movements (product_id, kind, quantity, reason, created_by, rs_order_id, stock_after, warehouse_id, unit_cost, value, department, lot_id, ref_type, ref_id, forced)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) RETURNING *`,
    [p.id, m.kind, qty, m.reason?.trim() || null, actor.userId, m.rs_order_id ?? null, up.stock_qty, w.id, Math.round(cost * 10000) / 10000, n2(qty * cost),
      m.department ?? null, lotId, m.ref_type ?? null, m.ref_id ?? null, forced]);
  if (forced) await audit(db, actor, 'forced_out', 'product', p.id, { available: avail }, { quantity: qty, warehouse: w.name, reason: m.reason ?? null });
  // Housekeeping : un article relié au linge alimente le stock propre du linge à la réception
  if (qty > 0 && m.kind === 'receipt' && p.linen_item_id) {
    const { linenMove } = await import('./housekeeping.js');
    await linenMove(db, actor, { item_id: p.linen_item_id, kind: 'purchase', quantity: Math.round(qty), reason: `Réception ${m.reason ?? ''}`.trim() });
    // le linge est géré par le module Housekeeping : mise en service immédiate (pas de double stock)
    await moveStock(db, actor, { product_id: p.id, warehouse_id: w.id, kind: 'issue', quantity: -qty, department: 'housekeeping', reason: 'Mise en service — stock du linge', ref_type: m.ref_type, ref_id: m.ref_id });
  }
  const after = Number(up.stock_qty);
  const alert = after <= 0 ? `Rupture : ${p.name}` : Number(up.min_stock) > 0 && after <= Number(up.min_stock) ? `${p.name} : ${n3(after)} ${p.unit} (minimum ${n3(up.min_stock)})` : null;
  return { movement: mv, consumed, warehouse: w, alert, product: p };
}

// =====================================================================================================
// Opérations
// =====================================================================================================
const OUT_KINDS = ['issue', 'waste', 'damaged', 'expired', 'supplier_return', 'out'];
export async function stockOut(db: PoolClient, actor: Actor, perms: Set<string>, b: {
  product_id: number; warehouse_id?: number | null; kind: string; quantity: number; reason?: string | null; department?: string | null; lot_id?: number | null;
  ticket_id?: number | null; supplier_id?: number | null; force?: boolean;
}) {
  if (!OUT_KINDS.includes(b.kind)) throw badRequest('Type de sortie invalide.');
  if (!(b.quantity > 0)) throw badRequest('Quantité invalide.');
  if (b.kind === 'issue' && !b.department) throw badRequest('Indiquez le département consommateur.');
  if (b.kind !== 'issue' && !b.reason?.trim()) throw badRequest('Motif obligatoire.');
  if (b.force && !perms.has('stock.force')) throw forbidden('Sortie au-delà du stock disponible : autorisation « stock.force » requise.');
  if (b.force && !b.reason?.trim()) throw badRequest('Motif obligatoire pour une sortie forcée.');
  let ref: { ref_type: string | null; ref_id: number | null } = { ref_type: null, ref_id: null };
  if (b.ticket_id) {
    const t = await one(db, `SELECT 1 FROM maintenance_tickets t WHERE t.id = $1 AND t.hotel_id = $2`, [b.ticket_id, actor.hotelId]);
    if (!t) throw notFound('Ticket de maintenance introuvable');
    ref = { ref_type: 'maintenance_ticket', ref_id: b.ticket_id };
  }
  if (b.kind === 'supplier_return') {
    if (!b.supplier_id) throw badRequest('Fournisseur obligatoire pour un retour.');
    ref = { ref_type: 'supplier', ref_id: b.supplier_id };
  }
  const r = await moveStock(db, actor, { product_id: b.product_id, warehouse_id: b.warehouse_id, kind: b.kind, quantity: -b.quantity, reason: b.reason, department: b.kind === 'issue' ? b.department : b.department ?? null,
    lot_id: b.lot_id, force: b.force, ...ref });
  await audit(db, actor, b.kind, 'product', b.product_id, null, { quantity: b.quantity, warehouse_id: r.warehouse.id, department: b.department ?? null, reason: b.reason ?? null, forced: r.movement.forced });
  return r;
}

export async function stockIn(db: PoolClient, actor: Actor, b: { product_id: number; warehouse_id?: number | null; quantity: number; unit_cost?: number | null; reason?: string | null; lot_no?: string | null; expiry_date?: string | null }) {
  if (!(b.quantity > 0)) throw badRequest('Quantité invalide.');
  return moveStock(db, actor, { ...b, kind: 'in' });
}

export async function adjustStock(db: PoolClient, actor: Actor, b: { product_id: number; warehouse_id?: number | null; quantity: number; reason: string }) {
  if (!b.reason?.trim()) throw badRequest('Motif obligatoire pour un ajustement.');
  return moveStock(db, actor, { ...b, kind: 'adjust' });
}

export async function transfer(db: PoolClient, actor: Actor, b: { product_id: number; from_id: number; to_id: number; quantity: number; reason?: string | null }) {
  if (b.from_id === b.to_id) throw badRequest('Entrepôts de départ et d\'arrivée identiques.');
  if (!(b.quantity > 0)) throw badRequest('Quantité invalide.');
  const to = await warehouseOf(db, actor.hotelId, b.to_id);
  const out = await moveStock(db, actor, { product_id: b.product_id, warehouse_id: b.from_id, kind: 'transfer_out', quantity: -b.quantity, reason: b.reason ?? `Vers ${to.name}`, ref_type: 'transfer' });
  // les lots suivent la marchandise (n° et date de péremption conservés)
  const parts = out.consumed.length ? out.consumed : [{ lot_no: null, expiry_date: null, qty: b.quantity }];
  const ins = [];
  let rest = b.quantity;
  for (const [i, c] of parts.entries()) {
    const qn = i === parts.length - 1 ? n3(rest) : c.qty;
    rest = n3(rest - qn);
    if (qn <= 0) continue;
    ins.push(await moveStock(db, actor, { product_id: b.product_id, warehouse_id: to.id, kind: 'transfer_in', quantity: qn, reason: b.reason ?? `De ${out.warehouse.name}`, lot_no: c.lot_no, expiry_date: c.expiry_date,
      ref_type: 'transfer', ref_id: out.movement.id }));
  }
  await audit(db, actor, 'transfer', 'product', b.product_id, null, { from: out.warehouse.name, to: to.name, quantity: b.quantity, movement: out.movement.id });
  return { out: out.movement, in: ins.map((x) => x.movement) };
}

// =====================================================================================================
// Inventaires
// =====================================================================================================
export async function createInventory(db: PoolClient, actor: Actor, b: { scope: 'full' | 'category' | 'warehouse'; warehouse_id?: number | null; category?: string | null; notes?: string | null }) {
  if (b.scope === 'warehouse' && !b.warehouse_id) throw badRequest('Choisissez l\'entrepôt.');
  if (b.scope === 'category' && !b.category?.trim()) throw badRequest('Choisissez la catégorie.');
  const year = today().slice(0, 4);
  const n = await nextNumber(db, `inv-${year}`);
  let inv: any;
  try {
    inv = await one<any>(db, `INSERT INTO inventories (hotel_id, number, scope, warehouse_id, category, notes, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [actor.hotelId, `INV${year}-${String(n).padStart(4, '0')}`, b.scope, b.scope === 'warehouse' ? b.warehouse_id : null, b.scope === 'category' ? b.category!.trim() : null, b.notes ?? null, actor.userId]);
  } catch (e: any) {
    if (e.code === '23505') throw conflict('Un inventaire est déjà ouvert sur ce périmètre : terminez-le d\'abord.');
    throw e;
  }
  // photo du stock théorique : chaque article actif × entrepôt où il a du stock ou qui est son entrepôt par défaut
  const r = await db.query(`INSERT INTO inventory_lines (inventory_id, product_id, warehouse_id, theoretical, unit_cost)
      SELECT $1, p.id, w.id, COALESCE(sl.qty, 0), p.avg_cost FROM products p CROSS JOIN warehouses w LEFT JOIN stock_levels sl ON sl.product_id = p.id AND sl.warehouse_id = w.id
       WHERE p.hotel_id = $2 AND w.hotel_id = $2 AND w.active AND p.active AND p.archived_at IS NULL
         AND ($3::int IS NULL OR w.id = $3) AND ($4::text IS NULL OR p.category = $4)
         AND (sl.qty <> 0 OR w.id = p.default_warehouse_id OR ($3::int IS NOT NULL AND sl.product_id IS NOT NULL))`,
    [inv.id, actor.hotelId, inv.warehouse_id, inv.category]);
  if (!r.rowCount) throw conflict('Aucun article dans ce périmètre.');
  await audit(db, actor, 'create', 'inventory', inv.id, null, { number: inv.number, scope: b.scope, lines: r.rowCount });
  return inv;
}

export async function countInventory(db: PoolClient, actor: Actor, id: number, lines: { line_id: number; counted: number | null; note?: string | null }[]) {
  const inv = await one<any>(db, 'SELECT * FROM inventories WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!inv) throw notFound('Inventaire introuvable');
  if (inv.status !== 'open') throw conflict('Inventaire clôturé.');
  for (const l of lines) {
    if (l.counted !== null && !(l.counted >= 0)) throw badRequest('Quantité comptée invalide.');
    const r = await db.query(`UPDATE inventory_lines SET counted = $3, note = COALESCE($4, note), counted_by = $5, counted_at = now() WHERE id = $1 AND inventory_id = $2`,
      [l.line_id, id, l.counted === null ? null : n3(l.counted), l.note ?? null, actor.userId]);
    if (!r.rowCount) throw badRequest('Ligne d\'inventaire inconnue.');
  }
}

export async function validateInventory(db: PoolClient, actor: Actor, perms: Set<string>, id: number) {
  const inv = await one<any>(db, 'SELECT * FROM inventories WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!inv) throw notFound('Inventaire introuvable');
  if (inv.status !== 'open') throw conflict('Inventaire déjà clôturé.');
  const lines = await q<any>(db, 'SELECT l.*, p.name FROM inventory_lines l JOIN products p ON p.id = l.product_id WHERE l.inventory_id = $1 ORDER BY l.id', [id]);
  const missing = lines.filter((l) => l.counted === null);
  if (missing.length) throw conflict(`${missing.length} article(s) non compté(s) : ${missing.slice(0, 5).map((l) => l.name).join(', ')}${missing.length > 5 ? '…' : ''}`);
  const s = await stockSettings(db, actor.hotelId);
  const gapValue = lines.reduce((a, l) => a + (Number(l.counted) - Number(l.theoretical)) * Number(l.unit_cost), 0);
  const bigLine = lines.find((l) => Number(l.theoretical) > 0 && (Math.abs(Number(l.counted) - Number(l.theoretical)) * 100) / Number(l.theoretical) >= s.inventory_gap_percent);
  const big = Math.abs(gapValue) >= s.inventory_gap_value || !!bigLine;
  if (big && !perms.has('stock.approve')) throw forbidden(`Écart important (${n2(gapValue)} ${currency.symbol}${bigLine ? `, ${bigLine.name}` : ''}) : validation réservée au responsable (stock.approve).`);
  for (const l of lines) {
    // écart appliqué par rapport au stock actuel (les mouvements survenus pendant le comptage sont respectés)
    const cur = await one<any>(db, 'SELECT qty FROM stock_levels WHERE product_id = $1 AND warehouse_id = $2', [l.product_id, l.warehouse_id]);
    const delta = n3(Number(l.counted) - Number(l.theoretical));
    const target = n3(Number(cur?.qty ?? 0) + delta);
    const applied = n3(Math.max(0, target) - Number(cur?.qty ?? 0));
    if (applied) await moveStock(db, actor, { product_id: l.product_id, warehouse_id: l.warehouse_id, kind: 'inventory', quantity: applied, reason: `Inventaire ${inv.number}`, ref_type: 'inventory', ref_id: id, allowNegative: true });
    await db.query('UPDATE inventory_lines SET adjusted = $2 WHERE id = $1', [l.id, applied]);
  }
  await db.query(`UPDATE inventories SET status = 'validated', validated_by = $2, validated_at = now(), gap_value = $3 WHERE id = $1`, [id, actor.userId, n2(gapValue)]);
  await audit(db, actor, 'validate', 'inventory', id, null, { number: inv.number, gap_value: n2(gapValue), big });
  return { gap_value: n2(gapValue), big };
}

// =====================================================================================================
// Alertes & tableau de bord
// =====================================================================================================
export async function stockAlerts(db: Db, hotelId: number) {
  const s = await stockSettings(db, hotelId);
  const t = today();
  const out: { level: 'danger' | 'warning' | 'info'; code: string; message: string; ref?: any }[] = [];
  for (const p of await q<any>(db, `SELECT id, name, unit, stock_qty, min_stock FROM products WHERE hotel_id = $1 AND active AND archived_at IS NULL AND linen_item_id IS NULL AND (stock_qty <= 0 OR (min_stock > 0 AND stock_qty <= min_stock)) ORDER BY stock_qty <= 0 DESC, name`, [hotelId])) {
    out.push(Number(p.stock_qty) <= 0
      ? { level: 'danger', code: 'out_of_stock', message: `Rupture : ${p.name}`, ref: { product_id: p.id } }
      : { level: 'warning', code: 'low_stock', message: `Stock minimum atteint : ${p.name} — ${n3(p.stock_qty)} ${p.unit} (min ${n3(p.min_stock)})`, ref: { product_id: p.id } });
  }
  for (const l of await q<any>(db, `SELECT l.*, p.name, p.unit, w.name AS warehouse FROM stock_lots l JOIN products p ON p.id = l.product_id JOIN warehouses w ON w.id = l.warehouse_id
      WHERE p.hotel_id = $1 AND l.qty > 0 AND l.expiry_date IS NOT NULL AND l.expiry_date <= $2 ORDER BY l.expiry_date`, [hotelId, addDays(t, s.expiry_alert_days)])) {
    const d = String(l.expiry_date).slice(0, 10);
    out.push(d < t
      ? { level: 'danger', code: 'expired', message: `Périmé depuis le ${d} : ${p(l)}`, ref: { product_id: l.product_id, lot_id: l.id } }
      : { level: 'warning', code: 'expiring', message: `Péremption le ${d} : ${p(l)}`, ref: { product_id: l.product_id, lot_id: l.id } });
  }
  function p(l: any) { return `${l.name} — ${n3(l.qty)} ${l.unit}${l.lot_no ? ` (lot ${l.lot_no})` : ''}, ${l.warehouse}`; }
  for (const o of await q<any>(db, `SELECT po.id, po.po_number, po.expected_date, s.name AS supplier FROM purchase_orders po LEFT JOIN suppliers s ON s.id = po.supplier_id
      WHERE po.hotel_id = $1 AND po.status IN ('ordered','partial') AND po.expected_date < $2 ORDER BY po.expected_date`, [hotelId, t])) {
    out.push({ level: 'warning', code: 'late_po', message: `Commande ${o.po_number} en retard (${o.supplier ?? '—'}, attendue le ${String(o.expected_date).slice(0, 10)})`, ref: { po_id: o.id } });
  }
  for (const i of await q<any>(db, `SELECT id, number, gap_value FROM inventories WHERE hotel_id = $1 AND status = 'validated' AND validated_at > now() - interval '30 days' AND abs(gap_value) >= $2`, [hotelId, s.inventory_gap_value])) {
    out.push({ level: 'warning', code: 'inventory_gap', message: `Écart d'inventaire important ${i.number} : ${n2(i.gap_value)} ${currency.symbol}`, ref: { inventory_id: i.id } });
  }
  for (const f of await q<any>(db, `SELECT f.id, f.ref, f.number, f.due_date, f.total - f.paid AS due, s.name FROM supplier_invoices f JOIN suppliers s ON s.id = f.supplier_id
      WHERE f.hotel_id = $1 AND f.status IN ('unpaid','partial') AND f.due_date < $2 ORDER BY f.due_date`, [hotelId, t])) {
    out.push({ level: 'warning', code: 'invoice_overdue', message: `Facture fournisseur échue : ${f.name} n° ${f.number} — ${n2(f.due)} ${currency.symbol} (échéance ${String(f.due_date).slice(0, 10)})`, ref: { invoice_id: f.id } });
  }
  return out;
}

export async function stockDashboard(db: Db, hotelId: number) {
  const t = today(), ms = monthStart(t);
  const k = await one<any>(db, `SELECT COALESCE(sum(stock_qty * avg_cost) FILTER (WHERE stock_qty > 0), 0) AS value, count(*) FILTER (WHERE stock_qty > 0)::int AS available,
      count(*) FILTER (WHERE stock_qty <= 0 AND linen_item_id IS NULL)::int AS out_of_stock, count(*) FILTER (WHERE min_stock > 0 AND stock_qty > 0 AND stock_qty <= min_stock)::int AS low, count(*)::int AS products
     FROM products WHERE hotel_id = $1 AND active AND archived_at IS NULL`, [hotelId]);
  const po = await one<any>(db, `SELECT count(*) FILTER (WHERE status = 'pending')::int AS to_approve, count(*) FILTER (WHERE status IN ('approved'))::int AS to_order,
      count(*) FILTER (WHERE status IN ('ordered','partial'))::int AS to_receive, count(*) FILTER (WHERE status IN ('ordered','partial') AND expected_date < $2)::int AS late
     FROM purchase_orders WHERE hotel_id = $1`, [hotelId, t]);
  const buy = await one<any>(db, `SELECT COALESCE((SELECT sum(value) FROM purchase_receipts WHERE hotel_id = $1 AND (received_at AT TIME ZONE '${TZ}')::date >= $2), 0) AS received_month,
      COALESCE((SELECT sum(total) FROM supplier_invoices WHERE hotel_id = $1 AND status <> 'cancelled' AND invoice_date >= $2), 0) AS invoiced_month,
      COALESCE((SELECT sum(total - paid) FROM supplier_invoices WHERE hotel_id = $1 AND status IN ('unpaid','partial')), 0) AS due,
      COALESCE((SELECT sum(total - paid) FROM supplier_invoices WHERE hotel_id = $1 AND status IN ('unpaid','partial') AND due_date < $3), 0) AS overdue`, [hotelId, ms, t]);
  const bySupplier = await q<any>(db, `SELECT s.name, sum(r.value) AS value FROM purchase_receipts r JOIN purchase_orders po ON po.id = r.po_id JOIN suppliers s ON s.id = po.supplier_id
      WHERE r.hotel_id = $1 AND (r.received_at AT TIME ZONE '${TZ}')::date >= $2 GROUP BY s.name ORDER BY value DESC LIMIT 5`, [hotelId, addDays(t, -89)]);
  const byCategory = await q<any>(db, `SELECT p.category, sum(stock_qty * avg_cost) AS value FROM products p WHERE p.hotel_id = $1 AND active AND stock_qty > 0 GROUP BY p.category ORDER BY value DESC`, [hotelId]);
  const recent = await q<any>(db, `SELECT m.id, m.kind, m.quantity, m.created_at, m.reason, m.department, p.name, p.unit, w.name AS warehouse, u.full_name AS user_name FROM stock_movements m
      JOIN products p ON p.id = m.product_id LEFT JOIN warehouses w ON w.id = m.warehouse_id LEFT JOIN users u ON u.id = m.created_by WHERE p.hotel_id = $1 ORDER BY m.id DESC LIMIT 12`, [hotelId]);
  const alerts = await stockAlerts(db, hotelId);
  return {
    kpi: { ...k, value: n2(k.value), ...po, received_month: n2(buy.received_month), invoiced_month: n2(buy.invoiced_month), due: n2(buy.due), overdue: n2(buy.overdue),
      expiring: alerts.filter((a) => a.code === 'expiring' || a.code === 'expired').length },
    by_supplier: bySupplier.map((x) => ({ ...x, value: n2(x.value) })), by_category: byCategory.map((x) => ({ ...x, value: n2(x.value) })),
    recent: recent.map((r) => ({ ...r, kind_label: KIND_LABEL[r.kind] ?? r.kind })), alerts,
  };
}

// =====================================================================================================
// Rapports
// =====================================================================================================
const c = (key: string, label: string, money = false) => ({ key, label, money });
export const STOCK_REPORTS: Record<string, { title: string; columns: any[] }> = {
  state: { title: 'État du stock', columns: [c('code', 'Réf.'), c('name', 'Article'), c('category', 'Catégorie'), c('detail', 'Par entrepôt'), c('qty', 'Quantité'), c('unit', 'Unité'), c('min', 'Min'), c('max', 'Max'), c('status', 'État')] },
  value: { title: 'Valeur du stock', columns: [c('category', 'Catégorie'), c('name', 'Article'), c('qty', 'Quantité'), c('avg_cost', 'PMP', true), c('last_cost', 'Dernier prix', true), c('value', 'Valeur', true)] },
  movements: { title: 'Mouvements d\'entrée et de sortie', columns: [c('date', 'Date'), c('name', 'Article'), c('kind', 'Type'), c('warehouse', 'Entrepôt'), c('department', 'Département'), c('qty', 'Quantité'), c('value', 'Valeur', true), c('reason', 'Motif'), c('user', 'Utilisateur')] },
  suppliers: { title: 'Achats par fournisseur', columns: [c('supplier', 'Fournisseur'), c('orders', 'Commandes'), c('received', 'Réceptionné HT', true), c('invoiced', 'Facturé TTC', true), c('paid', 'Payé', true), c('due', 'Reste dû', true)] },
  departments: { title: 'Consommation par département', columns: [c('department', 'Département'), c('category', 'Catégorie'), c('qty', 'Quantités'), c('value', 'Valeur', true)] },
  expired: { title: 'Produits périmés et à péremption proche', columns: [c('name', 'Article'), c('lot', 'Lot'), c('expiry', 'Péremption'), c('warehouse', 'Entrepôt'), c('qty', 'Quantité'), c('value', 'Valeur', true), c('state', 'État')] },
  inventory: { title: 'Écarts d\'inventaire', columns: [c('number', 'Inventaire'), c('date', 'Validé le'), c('name', 'Article'), c('warehouse', 'Entrepôt'), c('theoretical', 'Théorique'), c('counted', 'Compté'), c('gap', 'Écart'), c('value', 'Valeur écart', true)] },
  debts: { title: 'Dettes fournisseurs', columns: [c('supplier', 'Fournisseur'), c('invoices', 'Factures'), c('due', 'Total dû', true), c('not_due', 'Non échu', true), c('d30', 'Échu 0-30 j', true), c('d60', 'Échu 31-60 j', true), c('d90', 'Échu > 60 j', true)] },
  expenses: { title: 'Dépenses d\'achat par fournisseur et catégorie', columns: [c('supplier', 'Fournisseur'), c('category', 'Catégorie'), c('invoices', 'Factures'), c('ht', 'HT', true), c('tax', 'TVA', true), c('total', 'TTC', true)] },
  journal: { title: 'Journal comptable des achats (export)', columns: [c('date', 'Date'), c('journal', 'Journal'), c('piece', 'Pièce'), c('account', 'Compte'), c('label', 'Libellé'), c('debit', 'Débit', true), c('credit', 'Crédit', true)] },
};

export async function stockReport(db: Db, hotelId: number, kind: string, from: string, to: string) {
  const def = STOCK_REPORTS[kind];
  if (!def) throw notFound('Rapport inconnu');
  const P = [hotelId, from, to];
  const dm = `(m.created_at AT TIME ZONE '${TZ}')::date`;
  let rows: any[] = [];
  let total: any = null;
  if (kind === 'state') {
    rows = (await q<any>(db, `SELECT p.*, (SELECT string_agg(w.name || ' : ' || trim(to_char(sl.qty, 'FM999999990.###')), ' · ' ORDER BY w.name) FROM stock_levels sl JOIN warehouses w ON w.id = sl.warehouse_id WHERE sl.product_id = p.id AND sl.qty <> 0) AS detail
        FROM products p WHERE p.hotel_id = $1 AND p.archived_at IS NULL ORDER BY p.category, p.name`, [hotelId]))
      .map((p) => ({ code: p.code ?? '', name: p.name, category: p.category, detail: p.detail ?? '', qty: n3(p.stock_qty), unit: p.unit, min: n3(p.min_stock), max: p.max_stock === null ? '' : n3(p.max_stock),
        status: Number(p.stock_qty) <= 0 ? 'Rupture' : Number(p.min_stock) > 0 && Number(p.stock_qty) <= Number(p.min_stock) ? 'Sous le minimum' : p.max_stock !== null && Number(p.stock_qty) > Number(p.max_stock) ? 'Au-dessus du maximum' : 'OK' }));
  } else if (kind === 'value') {
    rows = (await q<any>(db, `SELECT category, name, stock_qty, avg_cost, cost_price FROM products WHERE hotel_id = $1 AND archived_at IS NULL AND stock_qty > 0 ORDER BY category, name`, [hotelId]))
      .map((p) => ({ category: p.category, name: p.name, qty: n3(p.stock_qty), avg_cost: n2(p.avg_cost), last_cost: n2(p.cost_price), value: n2(Number(p.stock_qty) * Number(p.avg_cost)) }));
    total = { value: n2(rows.reduce((a, r) => a + r.value, 0)) };
  } else if (kind === 'movements') {
    rows = (await q<any>(db, `SELECT m.*, p.name, w.name AS warehouse, u.full_name AS user_name FROM stock_movements m JOIN products p ON p.id = m.product_id LEFT JOIN warehouses w ON w.id = m.warehouse_id
        LEFT JOIN users u ON u.id = m.created_by WHERE p.hotel_id = $1 AND ${dm} BETWEEN $2 AND $3 ORDER BY m.id`, P))
      .map((m) => ({ date: new Date(m.created_at).toLocaleString('fr-FR', { timeZone: TZ, day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }), name: m.name, kind: KIND_LABEL[m.kind] ?? m.kind,
        warehouse: m.warehouse ?? '', department: m.department ? DEPT_LABEL[m.department] : '', qty: n3(m.quantity), value: n2(m.value), reason: m.reason ?? '', user: m.user_name ?? '' }));
    total = { value: n2(rows.reduce((a, r) => a + r.value, 0)) };
  } else if (kind === 'suppliers') {
    rows = (await q<any>(db, `SELECT s.name AS supplier,
        (SELECT count(*) FROM purchase_orders po WHERE po.supplier_id = s.id AND po.status IN ('ordered','partial','received') AND (po.ordered_at AT TIME ZONE '${TZ}')::date BETWEEN $2 AND $3)::int AS orders,
        COALESCE((SELECT sum(r.value) FROM purchase_receipts r JOIN purchase_orders po ON po.id = r.po_id WHERE po.supplier_id = s.id AND (r.received_at AT TIME ZONE '${TZ}')::date BETWEEN $2 AND $3), 0) AS received,
        COALESCE((SELECT sum(f.total) FROM supplier_invoices f WHERE f.supplier_id = s.id AND f.status <> 'cancelled' AND f.invoice_date BETWEEN $2 AND $3), 0) AS invoiced,
        COALESCE((SELECT sum(sp.amount) FROM supplier_payments sp JOIN supplier_invoices f ON f.id = sp.invoice_id WHERE f.supplier_id = s.id AND sp.paid_at BETWEEN $2 AND $3), 0) AS paid,
        COALESCE((SELECT sum(f.total - f.paid) FROM supplier_invoices f WHERE f.supplier_id = s.id AND f.status IN ('unpaid','partial')), 0) AS due
       FROM suppliers s WHERE s.hotel_id = $1 ORDER BY received DESC, s.name`, P)).filter((r) => Number(r.received) || Number(r.invoiced) || Number(r.due) || r.orders)
      .map((r) => ({ ...r, received: n2(r.received), invoiced: n2(r.invoiced), paid: n2(r.paid), due: n2(r.due) }));
    total = ['received', 'invoiced', 'paid', 'due'].reduce((a, k) => ({ ...a, [k]: n2(rows.reduce((s, r) => s + r[k], 0)) }), {});
  } else if (kind === 'departments') {
    rows = (await q<any>(db, `SELECT COALESCE(m.department, CASE WHEN m.kind = 'sale' THEN 'restaurant' ELSE 'other' END) AS department, p.category, sum(-m.quantity) AS qty, sum(-m.value) AS value
        FROM stock_movements m JOIN products p ON p.id = m.product_id WHERE p.hotel_id = $1 AND ${dm} BETWEEN $2 AND $3 AND m.kind IN ('issue','sale') GROUP BY 1, 2 ORDER BY 1, value DESC`, P))
      .map((r) => ({ department: DEPT_LABEL[r.department] ?? r.department, category: r.category, qty: n3(r.qty), value: n2(r.value) }));
    total = { value: n2(rows.reduce((a, r) => a + r.value, 0)) };
  } else if (kind === 'expired') {
    const s = await stockSettings(db, hotelId);
    rows = (await q<any>(db, `SELECT l.*, p.name, p.avg_cost, w.name AS warehouse FROM stock_lots l JOIN products p ON p.id = l.product_id JOIN warehouses w ON w.id = l.warehouse_id
        WHERE p.hotel_id = $1 AND l.qty > 0 AND l.expiry_date IS NOT NULL AND l.expiry_date <= $2 ORDER BY l.expiry_date`, [hotelId, addDays(today(), s.expiry_alert_days)]))
      .map((l) => ({ name: l.name, lot: l.lot_no ?? '', expiry: String(l.expiry_date).slice(0, 10), warehouse: l.warehouse, qty: n3(l.qty), value: n2(Number(l.qty) * Number(l.avg_cost)), state: String(l.expiry_date).slice(0, 10) < today() ? 'Périmé' : 'À surveiller' }));
    const destroyed = await q<any>(db, `SELECT m.*, p.name, w.name AS warehouse FROM stock_movements m JOIN products p ON p.id = m.product_id LEFT JOIN warehouses w ON w.id = m.warehouse_id
        WHERE p.hotel_id = $1 AND m.kind = 'expired' AND ${dm} BETWEEN $2 AND $3`, P);
    rows.push(...destroyed.map((m) => ({ name: m.name, lot: '', expiry: '', warehouse: m.warehouse ?? '', qty: n3(-m.quantity), value: n2(-m.value), state: `Sorti le ${new Date(m.created_at).toLocaleDateString('fr-FR', { timeZone: TZ })}` })));
  } else if (kind === 'inventory') {
    rows = (await q<any>(db, `SELECT i.number, i.validated_at, p.name, w.name AS warehouse, l.theoretical, l.counted, l.unit_cost FROM inventory_lines l JOIN inventories i ON i.id = l.inventory_id
        JOIN products p ON p.id = l.product_id JOIN warehouses w ON w.id = l.warehouse_id
       WHERE i.hotel_id = $1 AND i.status = 'validated' AND (i.validated_at AT TIME ZONE '${TZ}')::date BETWEEN $2 AND $3 AND l.counted <> l.theoretical ORDER BY i.validated_at, p.name`, P))
      .map((r) => ({ number: r.number, date: new Date(r.validated_at).toLocaleDateString('fr-FR', { timeZone: TZ }), name: r.name, warehouse: r.warehouse, theoretical: n3(r.theoretical), counted: n3(r.counted),
        gap: n3(Number(r.counted) - Number(r.theoretical)), value: n2((Number(r.counted) - Number(r.theoretical)) * Number(r.unit_cost)) }));
    total = { value: n2(rows.reduce((a, r) => a + r.value, 0)) };
  } else if (kind === 'debts') {
    const t = today();
    const inv = await q<any>(db, `SELECT f.*, s.name FROM supplier_invoices f JOIN suppliers s ON s.id = f.supplier_id WHERE f.hotel_id = $1 AND f.status IN ('unpaid','partial') ORDER BY s.name`, [hotelId]);
    const m = new Map<string, any>();
    for (const f of inv) {
      const r = m.get(f.name) ?? { supplier: f.name, invoices: 0, due: 0, not_due: 0, d30: 0, d60: 0, d90: 0 };
      const due = Number(f.total) - Number(f.paid);
      const late = Math.floor((Date.parse(t) - Date.parse(String(f.due_date).slice(0, 10))) / 86400000);
      r.invoices++; r.due += due;
      if (late <= 0) r.not_due += due; else if (late <= 30) r.d30 += due; else if (late <= 60) r.d60 += due; else r.d90 += due;
      m.set(f.name, r);
    }
    rows = [...m.values()].map((r) => ({ ...r, due: n2(r.due), not_due: n2(r.not_due), d30: n2(r.d30), d60: n2(r.d60), d90: n2(r.d90) }));
    total = ['due', 'not_due', 'd30', 'd60', 'd90'].reduce((a, k) => ({ ...a, [k]: n2(rows.reduce((s, r) => s + r[k], 0)) }), {});
  } else if (kind === 'expenses') {
    rows = (await q<any>(db, `SELECT s.name AS supplier, f.category, count(*)::int AS invoices, sum(f.subtotal) AS ht, sum(f.tax_total) AS tax, sum(f.total) AS total FROM supplier_invoices f JOIN suppliers s ON s.id = f.supplier_id
        WHERE f.hotel_id = $1 AND f.status <> 'cancelled' AND f.invoice_date BETWEEN $2 AND $3 GROUP BY s.name, f.category ORDER BY total DESC`, P))
      .map((r) => ({ ...r, ht: n2(r.ht), tax: n2(r.tax), total: n2(r.total) }));
    total = ['ht', 'tax', 'total'].reduce((a, k) => ({ ...a, [k]: n2(rows.reduce((s, r) => s + r[k], 0)) }), {});
  } else if (kind === 'journal') {
    // Schéma SCF : achat = 60 (HT) + 4456 (TVA) / 401 (TTC) ; règlement = 401 / 512 banque ou 53 caisse
    for (const f of await q<any>(db, `SELECT f.*, s.name, s.code FROM supplier_invoices f JOIN suppliers s ON s.id = f.supplier_id WHERE f.hotel_id = $1 AND f.status <> 'cancelled' AND f.invoice_date BETWEEN $2 AND $3 ORDER BY f.invoice_date, f.id`, P)) {
      const d = String(f.invoice_date).slice(0, 10), lbl = `${f.name} — fact. ${f.number}`;
      rows.push({ date: d, journal: 'ACH', piece: f.ref, account: '60', label: lbl, debit: n2(Number(f.subtotal) + Number(f.stamp_duty)), credit: 0 });
      if (Number(f.tax_total)) rows.push({ date: d, journal: 'ACH', piece: f.ref, account: '4456', label: lbl, debit: n2(f.tax_total), credit: 0 });
      rows.push({ date: d, journal: 'ACH', piece: f.ref, account: `401${f.code ? `-${f.code}` : ''}`, label: lbl, debit: 0, credit: n2(f.total) });
    }
    for (const p of await q<any>(db, `SELECT sp.*, f.ref, f.number, s.name, s.code FROM supplier_payments sp JOIN supplier_invoices f ON f.id = sp.invoice_id JOIN suppliers s ON s.id = f.supplier_id
        WHERE f.hotel_id = $1 AND sp.paid_at BETWEEN $2 AND $3 ORDER BY sp.paid_at, sp.id`, P)) {
      const d = String(p.paid_at).slice(0, 10), j = p.method === 'cash' ? 'CAI' : 'BQ', lbl = `Règlement ${p.name} — fact. ${p.number}`;
      rows.push({ date: d, journal: j, piece: p.ref, account: `401${p.code ? `-${p.code}` : ''}`, label: lbl, debit: n2(p.amount), credit: 0 });
      rows.push({ date: d, journal: j, piece: p.ref, account: p.method === 'cash' ? '53' : '512', label: lbl, debit: 0, credit: n2(p.amount) });
    }
    total = { debit: n2(rows.reduce((a, r) => a + r.debit, 0)), credit: n2(rows.reduce((a, r) => a + r.credit, 0)) };
  }
  return { kind, title: def.title, from, to, columns: def.columns, rows, total };
}

export { toCents, fromCents };
