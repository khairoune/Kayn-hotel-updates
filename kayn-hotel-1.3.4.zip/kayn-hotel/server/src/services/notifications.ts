import nodemailer from 'nodemailer';
import type { Db } from '../db/pool.js';
import { getPool, one, q } from '../db/pool.js';
import type { Actor } from '../lib/audit.js';
import { addDays } from '../lib/dates.js';
import { FIN_SQL, getSettings, guestDisplayName, withBalance } from './common.js';

export type NotifKind = 'confirmation' | 'modification' | 'cancellation' | 'reminder';

export type Lang = 'fr' | 'en' | 'ar';
export const LANGS: Lang[] = ['fr', 'en', 'ar'];

const L = {
  fr: {
    months: ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'],
    meal: { RO: 'Chambre seule', BB: 'Petit-déjeuner', HB: 'Demi-pension', FB: 'Pension complète' } as Record<string, string>,
    cur: 'DA', night: (n: number) => `${n} nuit${n > 1 ? 's' : ''}`,
    lines: {
      code: 'Réservation n°', arrival: 'Arrivée', from: 'à partir de', departure: 'Départ', before: 'avant', rooms: 'Chambre(s)', meal: 'Formule',
      total: 'Montant total', paid: 'Déjà réglé', due: 'Reste à payer', special: 'Demandes particulières', depositDue: 'Acompte demandé pour confirmer',
      fee: 'Frais d\'annulation', regards: 'Cordialement,',
    },
    subj: {
      confirmation: (c: string, h: string) => `Confirmation de réservation ${c} — ${h}`,
      modification: (c: string, h: string) => `Modification de votre réservation ${c} — ${h}`,
      cancellation: (c: string, h: string) => `Annulation de votre réservation ${c} — ${h}`,
      reminder: (d: string, h: string) => `Rappel : votre arrivée le ${d} — ${h}`,
    },
    intro: {
      confirmation: (n: string, h: string) => `Bonjour ${n},\n\nNous avons le plaisir de confirmer votre réservation à ${h}.`,
      modification: (n: string) => `Bonjour ${n},\n\nVotre réservation a été modifiée. Voici les informations à jour :`,
      cancellation: (n: string) => `Bonjour ${n},\n\nNous vous confirmons l'annulation de votre réservation.`,
      reminder: (n: string) => `Bonjour ${n},\n\nNous avons hâte de vous accueillir. Rappel de votre réservation :`,
    },
    cancelLine: (c: string, a: string, b: string) => `Réservation n° ${c} du ${a} au ${b}.`,
    date: (d: string, m: string[]) => `${Number(d.slice(8, 10))} ${m[Number(d.slice(5, 7)) - 1]} ${d.slice(0, 4)}`,
  },
  en: {
    months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    meal: { RO: 'Room only', BB: 'Bed & breakfast', HB: 'Half board', FB: 'Full board' } as Record<string, string>,
    cur: 'DZD', night: (n: number) => `${n} night${n > 1 ? 's' : ''}`,
    lines: {
      code: 'Booking no.', arrival: 'Arrival', from: 'from', departure: 'Departure', before: 'before', rooms: 'Room(s)', meal: 'Board',
      total: 'Total amount', paid: 'Already paid', due: 'Balance due', special: 'Special requests', depositDue: 'Deposit required to confirm',
      fee: 'Cancellation fee', regards: 'Kind regards,',
    },
    subj: {
      confirmation: (c: string, h: string) => `Booking confirmation ${c} — ${h}`,
      modification: (c: string, h: string) => `Your booking ${c} has been updated — ${h}`,
      cancellation: (c: string, h: string) => `Cancellation of your booking ${c} — ${h}`,
      reminder: (d: string, h: string) => `Reminder: your arrival on ${d} — ${h}`,
    },
    intro: {
      confirmation: (n: string, h: string) => `Dear ${n},\n\nWe are pleased to confirm your booking at ${h}.`,
      modification: (n: string) => `Dear ${n},\n\nYour booking has been updated. Here are the current details:`,
      cancellation: (n: string) => `Dear ${n},\n\nWe confirm that your booking has been cancelled.`,
      reminder: (n: string) => `Dear ${n},\n\nWe look forward to welcoming you. Your booking details:`,
    },
    cancelLine: (c: string, a: string, b: string) => `Booking no. ${c} from ${a} to ${b}.`,
    date: (d: string, m: string[]) => `${m[Number(d.slice(5, 7)) - 1]} ${Number(d.slice(8, 10))}, ${d.slice(0, 4)}`,
  },
  ar: {
    months: ['جانفي', 'فيفري', 'مارس', 'أفريل', 'ماي', 'جوان', 'جويلية', 'أوت', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
    meal: { RO: 'غرفة فقط', BB: 'مع فطور الصباح', HB: 'نصف إقامة', FB: 'إقامة كاملة' } as Record<string, string>,
    cur: 'دج', night: (n: number) => (n === 1 ? 'ليلة واحدة' : n === 2 ? 'ليلتان' : `${n} ليالٍ`),
    lines: {
      code: 'حجز رقم', arrival: 'الوصول', from: 'ابتداءً من', departure: 'المغادرة', before: 'قبل', rooms: 'الغرف', meal: 'الصيغة',
      total: 'المبلغ الإجمالي', paid: 'المدفوع', due: 'الباقي للدفع', special: 'طلبات خاصة', depositDue: 'العربون المطلوب للتأكيد',
      fee: 'رسوم الإلغاء', regards: 'مع أطيب التحيات،',
    },
    subj: {
      confirmation: (c: string, h: string) => `تأكيد الحجز ${c} — ${h}`,
      modification: (c: string, h: string) => `تعديل حجزكم ${c} — ${h}`,
      cancellation: (c: string, h: string) => `إلغاء حجزكم ${c} — ${h}`,
      reminder: (d: string, h: string) => `تذكير: وصولكم يوم ${d} — ${h}`,
    },
    intro: {
      confirmation: (n: string, h: string) => `السلام عليكم ${n}،\n\nيسعدنا تأكيد حجزكم في ${h}.`,
      modification: (n: string) => `السلام عليكم ${n}،\n\nتم تعديل حجزكم. إليكم المعلومات المحدّثة:`,
      cancellation: (n: string) => `السلام عليكم ${n}،\n\nنؤكد لكم إلغاء حجزكم.`,
      reminder: (n: string) => `السلام عليكم ${n}،\n\nنحن في انتظاركم. تذكير بحجزكم:`,
    },
    cancelLine: (c: string, a: string, b: string) => `الحجز رقم ${c} من ${a} إلى ${b}.`,
    date: (d: string, m: string[]) => `${Number(d.slice(8, 10))} ${m[Number(d.slice(5, 7)) - 1]} ${d.slice(0, 4)}`,
  },
};
const amount = (n: number, cur: string) => `${Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} ${cur}`;

/** Numéro algérien 05xx… / 06xx… / 07xx… → format international pour WhatsApp */
export function waNumber(phone: string | null | undefined): string | null {
  if (!phone) return null;
  let p = phone.replace(/[^\d+]/g, '');
  if (p.startsWith('+')) p = p.slice(1);
  else if (p.startsWith('00')) p = p.slice(2);
  else if (p.startsWith('0') && p.length === 10) p = '213' + p.slice(1);
  return p.length >= 9 ? p : null;
}

export async function buildMessage(db: Db, resId: number, kind: NotifKind, langOverride?: Lang) {
  const r = await one<any>(
    db,
    `SELECT r.*, ${FIN_SQL}, row_to_json(g.*) AS guest, h.name AS hotel_name, h.phone AS hotel_phone
       FROM reservations r JOIN guests g ON g.id = r.guest_id JOIN hotels h ON h.id = r.hotel_id WHERE r.id = $1`,
    [resId],
  );
  const f = withBalance(r);
  const lang: Lang = langOverride ?? (LANGS.includes(r.guest.language) ? r.guest.language : 'fr');
  const T = L[lang];
  const settings = await getSettings(db, r.hotel_id);
  const rooms = await q<any>(
    db,
    `SELECT rm.number, rt.name AS type FROM reservation_rooms rr JOIN rooms rm ON rm.id = rr.room_id JOIN room_types rt ON rt.id = rr.room_type_id
      WHERE rr.reservation_id = $1 AND rr.status NOT IN ('cancelled','no_show') ORDER BY rm.number`,
    [resId],
  );
  const name = guestDisplayName(r.guest);
  const d = (x: string) => T.date(x, T.months);
  const nights = Math.round((Date.parse(r.check_out) - Date.parse(r.check_in)) / 86400000);
  const paid = Number(f.paid) - Number(f.refunded);
  const details = [
    `${T.lines.code} ${r.code}`,
    `${T.lines.arrival} : ${d(r.check_in)} (${T.lines.from} ${settings.check_in_time})`,
    `${T.lines.departure} : ${d(r.check_out)} (${T.lines.before} ${settings.check_out_time})`,
    rooms.length ? `${T.lines.rooms} : ${rooms.map((x) => `${x.number} (${x.type})`).join(', ')}` : null,
    `${T.lines.meal} : ${T.meal[r.meal_plan]} · ${T.night(nights)}`,
    `${T.lines.total} : ${amount(f.total, T.cur)} · ${T.lines.paid} : ${amount(paid, T.cur)} · ${T.lines.due} : ${amount(Math.max(0, f.balance), T.cur)}`,
    r.status === 'pending' && Number(r.deposit_required) > paid ? `${T.lines.depositDue} : ${amount(Number(r.deposit_required) - paid, T.cur)}` : null,
    r.special_requests ? `${T.lines.special} : ${r.special_requests}` : null,
  ].filter(Boolean).join('\n');
  const sign = `\n\n${T.lines.regards}\n${r.hotel_name}${r.hotel_phone ? ` · ${r.hotel_phone}` : ''}`;
  const subject = kind === 'reminder' ? T.subj.reminder(d(r.check_in), r.hotel_name) : T.subj[kind](r.code, r.hotel_name);
  let body: string;
  if (kind === 'cancellation') {
    const fee = Number(r.cancellation_fee ?? 0);
    body = `${T.intro.cancellation(name)}\n${T.cancelLine(r.code, d(r.check_in), d(r.check_out))}` +
      (fee > 0 ? `\n${T.lines.fee} : ${amount(fee, T.cur)} · ${T.lines.paid} : ${amount(paid, T.cur)} · ${T.lines.due} : ${amount(Math.max(0, f.balance), T.cur)}` : '') + sign;
  } else {
    body = `${T.intro[kind](name, r.hotel_name)}\n\n${details}${sign}`;
  }
  return { r, subject, body, lang };
}

/**
 * Met en file les notifications au client (e-mail si adresse, WhatsApp si téléphone).
 * Une modification non encore envoyée est mise à jour au lieu d'être dupliquée.
 */
export async function queueNotification(db: Db, actor: Actor | null, resId: number, kind: NotifKind) {
  const { r, subject, body, lang } = await buildMessage(db, resId, kind);
  const channels: { channel: 'email' | 'whatsapp'; recipient: string }[] = [];
  if (r.guest.email) channels.push({ channel: 'email', recipient: r.guest.email });
  const wa = waNumber(r.guest.phone);
  if (wa) channels.push({ channel: 'whatsapp', recipient: wa });
  for (const c of channels) {
    if (kind === 'modification' || kind === 'cancellation') {
      // remplace les messages encore non envoyés devenus obsolètes
      await db.query(
        `UPDATE notifications SET status = 'cancelled', last_error = 'Remplacé par un message plus récent'
          WHERE reservation_id = $1 AND channel = $2 AND status = 'pending' AND kind IN ('modification','confirmation','reminder')`,
        [resId, c.channel],
      );
    }
    if (kind === 'reminder') {
      await db.query(
        `INSERT INTO notifications (hotel_id, reservation_id, kind, channel, recipient, subject, body, created_by, language)
         VALUES ($1,$2,'reminder',$3,$4,$5,$6,$7,$8) ON CONFLICT (reservation_id, channel) WHERE kind = 'reminder' DO NOTHING`,
        [r.hotel_id, resId, c.channel, c.recipient, subject, body, actor?.userId ?? null, lang],
      );
    } else {
      await db.query(
        `INSERT INTO notifications (hotel_id, reservation_id, kind, channel, recipient, subject, body, created_by, language) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [r.hotel_id, resId, kind, c.channel, c.recipient, subject, body, actor?.userId ?? null, lang],
      );
    }
  }
  return channels.length;
}

/** Programme les rappels J-n pour les arrivées à venir. */
export async function queueReminders(hotelId: number, today: string) {
  const pool = getPool();
  const settings = await getSettings(pool, hotelId);
  const days = Number(settings.reminder_days_before ?? 1);
  const target = addDays(today, days);
  const rows = await q<any>(
    pool,
    `SELECT id FROM reservations WHERE hotel_id = $1 AND status IN ('pending','confirmed') AND check_in = $2`,
    [hotelId, target],
  );
  for (const r of rows) await queueNotification(pool, null, r.id, 'reminder');
  return rows.length;
}

/** Transport SMTP (Gmail : smtp.gmail.com, port 587, mot de passe d'application). */
export function smtpTransport(smtp: any) {
  return smtp.host === 'json'
    ? nodemailer.createTransport({ jsonTransport: true })
    : nodemailer.createTransport({ host: smtp.host, port: Number(smtp.port ?? 587), secure: Number(smtp.port) === 465, auth: smtp.user ? { user: smtp.user, pass: String(smtp.pass ?? '').replace(/\s/g, smtp.host === 'smtp.gmail.com' ? '' : ' ').trim() } : undefined, connectionTimeout: 10000, greetingTimeout: 10000 });
}
/** Message d'erreur compréhensible (les cas Gmail les plus fréquents). */
export function smtpError(e: any): string {
  const m = String(e?.message ?? e);
  if (/535|Username and Password not accepted|BadCredentials|Invalid login/i.test(m)) return 'Identifiants refusés : pour Gmail, utilisez un « mot de passe d\'application » (16 caractères, compte Google avec validation en deux étapes), pas le mot de passe habituel.';
  if (/ENOTFOUND|EAI_AGAIN|getaddrinfo/i.test(m)) return 'Serveur e-mail injoignable : vérifiez la connexion Internet du serveur et l\'adresse du serveur SMTP.';
  if (/ETIMEDOUT|timeout|ECONNREFUSED|ECONNRESET/i.test(m)) return 'Connexion au serveur e-mail impossible (pare-feu, port 587 bloqué ou pas d\'Internet).';
  if (/550|5\.1\.1|recipient/i.test(m)) return `Adresse du destinataire refusée : ${m.slice(0, 120)}`;
  return m;
}

/** Envoie les e-mails en attente si le serveur SMTP est configuré et joignable. */
export async function processEmailOutbox(hotelId: number) {
  const pool = getPool();
  const settings = await getSettings(pool, hotelId);
  const pending = await q<any>(pool, `SELECT * FROM notifications WHERE hotel_id = $1 AND channel = 'email' AND status = 'pending' AND attempts < 5 AND (scheduled_for IS NULL OR scheduled_for <= now()) ORDER BY id LIMIT 50`, [hotelId]);
  if (!pending.length) return { sent: 0, failed: 0, skipped: 0 };
  const smtp = settings.smtp;
  if (!smtp?.host) {
    await pool.query(`UPDATE notifications SET last_error = 'Serveur e-mail (SMTP) non configuré' WHERE id = ANY($1::int[])`, [pending.map((p) => p.id)]);
    return { sent: 0, failed: 0, skipped: pending.length };
  }
  const transport = smtpTransport(smtp);
  let sent = 0, failed = 0;
  for (const n of pending) {
    try {
      await transport.sendMail({ from: smtp.from ?? smtp.user, to: n.recipient, subject: n.subject, text: n.body });
      await pool.query(`UPDATE notifications SET status = 'sent', sent_at = now(), attempts = attempts + 1, last_error = NULL WHERE id = $1`, [n.id]);
      sent++;
    } catch (e: any) {
      await pool.query(
        `UPDATE notifications SET attempts = attempts + 1, last_error = $2, status = CASE WHEN attempts + 1 >= 5 THEN 'failed' ELSE 'pending' END WHERE id = $1`,
        [n.id, smtpError(e).slice(0, 300)],
      );
      failed++;
    }
  }
  return { sent, failed, skipped: 0 };
}
