/** Caisse : ouverture, mouvements, solde théorique, clôture avec écart justifié, validation superviseur, dépenses et recettes. */
import { currency } from './exports.js';
import type { PoolClient } from 'pg';
import { one, q, type Db } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { today } from '../lib/dates.js';
import { AppError, badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { fromCents, toCents } from '../lib/money.js';
import { findOpenSession } from './billing.js';
import { getSettings } from './common.js';

export async function openSession(db: PoolClient, actor: Actor, o: { register_id?: number | null; opening_amount: number; note?: string | null }) {
  if (toCents(o.opening_amount) < 0) throw badRequest('Fond de caisse invalide.');
  const reg = o.register_id
    ? await one<any>(db, 'SELECT * FROM cash_registers WHERE id = $1 AND hotel_id = $2 AND active', [o.register_id, actor.hotelId])
    : await one<any>(db, 'SELECT * FROM cash_registers WHERE hotel_id = $1 AND active ORDER BY id LIMIT 1', [actor.hotelId]);
  if (!reg) throw notFound('Caisse introuvable');
  const open = await one(db, `SELECT 1 FROM cash_sessions WHERE cash_register_id = $1 AND status = 'open'`, [reg.id]);
  if (open) throw conflict(`La caisse « ${reg.name} » est déjà ouverte.`);
  const s = await one<any>(db, `INSERT INTO cash_sessions (cash_register_id, opened_by, opening_amount, notes) VALUES ($1,$2,$3,$4) RETURNING *`,
    [reg.id, actor.userId, o.opening_amount, o.note ?? null]);
  await audit(db, actor, 'open', 'cash_session', s.id, null, { register: reg.name, opening_amount: o.opening_amount });
  return s;
}

/** Détail d'une session : opérations et solde théorique des espèces. */
export async function sessionSummary(db: Db, hotelId: number, id: number) {
  const s = await one<any>(db,
    `SELECT cs.*, cr.name AS register_name, cr.hotel_id, u.full_name AS opened_by_name, u2.full_name AS closed_by_name, u3.full_name AS validated_by_name
       FROM cash_sessions cs JOIN cash_registers cr ON cr.id = cs.cash_register_id JOIN users u ON u.id = cs.opened_by
       LEFT JOIN users u2 ON u2.id = cs.closed_by LEFT JOIN users u3 ON u3.id = cs.validated_by WHERE cs.id = $1`, [id]);
  if (!s || s.hotel_id !== hotelId) throw notFound('Session de caisse introuvable');
  const ops = await q<any>(db,
    `SELECT * FROM (
       SELECT 'payment' AS type, p.id, p.received_at AS at, p.method, p.amount AS amount, p.void,
              COALESCE(r.code, i.number) AS ref, CASE WHEN p.kind = 'deposit' THEN 'Acompte' ELSE 'Encaissement' END AS label, u.full_name AS by_name
         FROM payments p LEFT JOIN reservations r ON r.id = p.reservation_id LEFT JOIN invoices i ON i.id = p.invoice_id LEFT JOIN users u ON u.id = p.received_by
        WHERE p.cash_session_id = $1
       UNION ALL
       SELECT 'refund', f.id, f.created_at, f.method, -f.amount, false, r.code, 'Remboursement : ' || f.reason, u.full_name
         FROM refunds f LEFT JOIN reservations r ON r.id = f.reservation_id LEFT JOIN users u ON u.id = f.created_by WHERE f.cash_session_id = $1
       UNION ALL
       SELECT 'movement', m.id, m.created_at, 'cash', CASE WHEN m.direction = 'in' THEN m.amount ELSE -m.amount END, false, m.reference, m.description, u.full_name
         FROM cash_movements m LEFT JOIN users u ON u.id = m.created_by WHERE m.session_id = $1
       UNION ALL
       SELECT 'expense', e.id, e.created_at, e.method, -e.amount, e.void, e.reference, 'Dépense : ' || e.category || ' — ' || e.description, u.full_name
         FROM expenses e LEFT JOIN users u ON u.id = e.created_by WHERE e.cash_session_id = $1
       UNION ALL
       SELECT 'income', x.id, x.created_at, x.method, x.amount, x.void, x.reference, 'Recette : ' || x.category || ' — ' || x.description, u.full_name
         FROM incomes x LEFT JOIN users u ON u.id = x.created_by WHERE x.cash_session_id = $1
     ) o ORDER BY at`, [id]);
  const live = ops.filter((o) => !o.void);
  const cash = live.filter((o) => o.method === 'cash');
  const sum = (arr: any[]) => arr.reduce((a, o) => a + toCents(o.amount), 0);
  const byMethod: Record<string, number> = {};
  for (const o of live.filter((x) => x.type === 'payment' || x.type === 'refund' || x.type === 'income')) byMethod[o.method] = (byMethod[o.method] ?? 0) + toCents(o.amount);
  const expected = toCents(s.opening_amount) + sum(cash);
  return {
    ...s, operations: ops,
    totals: {
      opening: Number(s.opening_amount),
      cash_in: fromCents(sum(cash.filter((o) => toCents(o.amount) > 0))), cash_out: fromCents(-sum(cash.filter((o) => toCents(o.amount) < 0))),
      expected: fromCents(expected),
      by_method: Object.fromEntries(Object.entries(byMethod).map(([k, v]) => [k, fromCents(v)])),
      payments_count: live.filter((o) => o.type === 'payment').length,
    },
  };
}

export async function addMovement(db: PoolClient, actor: Actor, perms: Set<string>, sessionId: number, m: { direction: 'in' | 'out'; category: string; amount: number; description: string; reference?: string | null }) {
  const s = await lockOpen(db, actor, sessionId, perms);
  if (!(toCents(m.amount) > 0)) throw badRequest('Montant invalide.');
  if (!m.description?.trim()) throw badRequest('Libellé obligatoire.');
  if (m.direction === 'out') {
    const sum = await sessionSummary(db, actor.hotelId, s.id);
    if (toCents(m.amount) > toCents(sum.totals.expected)) throw conflict(`Sortie supérieure aux espèces en caisse (${sum.totals.expected} ${currency.symbol}).`);
  }
  const r = await one<any>(db, `INSERT INTO cash_movements (session_id, direction, category, amount, description, reference, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [s.id, m.direction, m.category, m.amount, m.description.trim(), m.reference ?? null, actor.userId]);
  await audit(db, actor, `cash_${m.direction}`, 'cash_session', s.id, null, { amount: m.amount, category: m.category, description: m.description });
  return r;
}

async function lockOpen(db: PoolClient, actor: Actor, id: number, perms: Set<string>) {
  const s = await one<any>(db, `SELECT cs.*, cr.hotel_id FROM cash_sessions cs JOIN cash_registers cr ON cr.id = cs.cash_register_id WHERE cs.id = $1 FOR UPDATE OF cs`, [id]);
  if (!s || s.hotel_id !== actor.hotelId) throw notFound('Session de caisse introuvable');
  if (s.status !== 'open') throw conflict('Caisse déjà clôturée.');
  if (s.opened_by !== actor.userId && !perms.has('cash.manage')) throw forbidden('Seul le caissier de cette session ou un superviseur peut l\'utiliser.');
  return s;
}

/** Clôture : solde réel compté, écart calculé, justification obligatoire si écart. */
export async function closeSession(db: PoolClient, actor: Actor, perms: Set<string>, id: number, o: { counted_amount: number; justification?: string | null }) {
  const s = await lockOpen(db, actor, id, perms);
  if (toCents(o.counted_amount) < 0) throw badRequest('Montant compté invalide.');
  const sum = await sessionSummary(db, actor.hotelId, id);
  const diff = toCents(o.counted_amount) - toCents(sum.totals.expected);
  if (diff !== 0 && (!o.justification?.trim() || o.justification.trim().length < 5)) {
    throw new AppError(409, 'cash_difference', `Écart de caisse de ${fromCents(diff)} ${currency.symbol} : justification obligatoire.`, { expected: sum.totals.expected, difference: fromCents(diff) });
  }
  await db.query(`UPDATE cash_sessions SET status = 'closed', closed_by = $2, closed_at = now(), expected_amount = $3, declared_amount = $4, difference = $5, justification = $6 WHERE id = $1`,
    [id, actor.userId, sum.totals.expected, o.counted_amount, fromCents(diff), o.justification?.trim() || null]);
  await audit(db, actor, 'close', 'cash_session', id, { status: 'open' }, { expected: sum.totals.expected, counted: o.counted_amount, difference: fromCents(diff), justification: o.justification ?? null });
  return sessionSummary(db, actor.hotelId, id);
}

/** Validation par un superviseur (contrôle de la clôture et de l'écart). */
export async function validateSession(db: PoolClient, actor: Actor, id: number, note: string | null) {
  const s = await one<any>(db, `SELECT cs.*, cr.hotel_id FROM cash_sessions cs JOIN cash_registers cr ON cr.id = cs.cash_register_id WHERE cs.id = $1 FOR UPDATE OF cs`, [id]);
  if (!s || s.hotel_id !== actor.hotelId) throw notFound('Session introuvable');
  if (s.status !== 'closed') throw conflict('Clôturez la caisse avant la validation.');
  if (s.validated_at) throw conflict('Session déjà validée.');
  if (s.closed_by === actor.userId && Number(s.difference) !== 0) throw forbidden('Un écart doit être validé par une autre personne que le caissier.');
  await db.query('UPDATE cash_sessions SET validated_by = $2, validated_at = now(), validation_note = $3 WHERE id = $1', [id, actor.userId, note]);
  await audit(db, actor, 'validate', 'cash_session', id, null, { note });
}

// ---------- Dépenses & recettes ----------
export async function addExpense(db: PoolClient, actor: Actor, e: { category: string; description: string; amount: number; method: 'cash' | 'card' | 'cheque' | 'transfer'; supplier?: string | null; supplier_id?: number | null; expense_date?: string | null; reference?: string | null }) {
  if (!(toCents(e.amount) > 0)) throw badRequest('Montant invalide.');
  if (e.expense_date && e.expense_date > today()) throw badRequest('Date de dépense dans le futur.');
  let sessionId: number | null = null;
  if (e.method === 'cash') {
    const s = await findOpenSession(db, actor);
    if (!s) throw new AppError(409, 'cash_closed', 'Caisse fermée : ouvrez la caisse pour une dépense en espèces.');
    const sum = await sessionSummary(db, actor.hotelId, s.id);
    if (toCents(e.amount) > toCents(sum.totals.expected)) throw conflict(`Dépense supérieure aux espèces en caisse (${sum.totals.expected} ${currency.symbol}).`);
    sessionId = s.id;
  }
  let supplierId: number | null = e.supplier_id ?? null;
  if (!supplierId && e.supplier?.trim()) {
    const sp = await one<any>(db, 'SELECT id FROM suppliers WHERE hotel_id = $1 AND lower(name) = lower($2)', [actor.hotelId, e.supplier.trim()]);
    supplierId = sp ? sp.id : (await one<any>(db, 'INSERT INTO suppliers (hotel_id, name) VALUES ($1,$2) RETURNING id', [actor.hotelId, e.supplier.trim()])).id;
  }
  await db.query('INSERT INTO expense_categories (hotel_id, name) VALUES ($1,$2) ON CONFLICT DO NOTHING', [actor.hotelId, e.category.trim()]);
  const r = await one<any>(db,
    `INSERT INTO expenses (hotel_id, category, description, amount, method, supplier_id, cash_session_id, expense_date, created_by, reference) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [actor.hotelId, e.category.trim(), e.description.trim(), e.amount, e.method, supplierId, sessionId, e.expense_date ?? today(), actor.userId, e.reference ?? null]);
  await audit(db, actor, 'create', 'expense', r.id, null, { amount: e.amount, category: e.category, method: e.method });
  return r;
}

export async function addIncome(db: PoolClient, actor: Actor, e: { category: string; description: string; amount: number; method: 'cash' | 'card' | 'cheque' | 'transfer' | 'online'; income_date?: string | null; reference?: string | null }) {
  if (!(toCents(e.amount) > 0)) throw badRequest('Montant invalide.');
  let sessionId: number | null = null;
  if (e.method === 'cash') {
    const s = await findOpenSession(db, actor);
    if (!s) throw new AppError(409, 'cash_closed', 'Caisse fermée : ouvrez la caisse pour une recette en espèces.');
    sessionId = s.id;
  }
  if (e.method === 'online' && !(await getSettings(db, actor.hotelId)).payment_gateway?.enabled) throw badRequest('Aucune passerelle de paiement en ligne n\'est configurée.');
  const r = await one<any>(db,
    `INSERT INTO incomes (hotel_id, category, description, amount, method, cash_session_id, income_date, created_by, reference) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [actor.hotelId, e.category.trim(), e.description.trim(), e.amount, e.method, sessionId, e.income_date ?? today(), actor.userId, e.reference ?? null]);
  await audit(db, actor, 'create', 'income', r.id, null, { amount: e.amount, category: e.category, method: e.method });
  return r;
}

/** Annulation tracée d'une dépense / recette (refusée si sa caisse est clôturée). */
export async function voidEntry(db: PoolClient, actor: Actor, table: 'expenses' | 'incomes', id: number, reason: string) {
  const e = await one<any>(db, `SELECT * FROM ${table} WHERE id = $1 AND hotel_id = $2 FOR UPDATE`, [id, actor.hotelId]);
  if (!e) throw notFound('Opération introuvable');
  if (e.void) throw conflict('Déjà annulée.');
  if (!reason?.trim()) throw badRequest('Motif obligatoire.');
  if (e.cash_session_id) {
    const cs = await one<any>(db, 'SELECT status FROM cash_sessions WHERE id = $1', [e.cash_session_id]);
    if (cs?.status === 'closed') throw conflict('Caisse clôturée : saisissez une opération inverse dans la caisse du jour.');
  }
  await db.query(`UPDATE ${table} SET void = true, void_reason = $2, voided_by = $3, voided_at = now() WHERE id = $1`, [id, reason.trim(), actor.userId]);
  await audit(db, actor, 'void', table === 'expenses' ? 'expense' : 'income', id, { void: false }, { void: true, reason });
}
