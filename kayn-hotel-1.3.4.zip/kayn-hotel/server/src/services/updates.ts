/**
 * Mises à jour en un clic.
 * 1) Vérification périodique d'un manifeste (latest.json : version, fichier, sha256, notes) — Internet requis.
 * 2) Nouvelle version → notification dans la cloche des administrateurs (une seule fois par version).
 * 3) « Installer » : téléchargement, contrôle d'empreinte SHA-256, sauvegarde VÉRIFIÉE de la base,
 *    puis redémarrage ; le superviseur (server/start.cjs) remplace les fichiers avant de relancer
 *    (retour automatique à l'ancienne version en cas d'échec). Les données (server/data, .env) ne sont jamais touchées.
 */
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getPool, one } from '../db/pool.js';
import { AppError, badRequest } from '../lib/errors.js';
import { getSettings } from './common.js';

export const APP_VERSION: string = (() => { try { return JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8')).version ?? '0.0.0'; } catch { return '0.0.0'; } })();
export const DEFAULT_UPDATE_URL = 'https://api.github.com/repos/khairoune/kayn-hotel-updates/contents/latest.json';
export const updatesDir = () => {
  const d = process.env.UPDATES_DIR ?? fileURLToPath(new URL('../../data/updates', import.meta.url));
  if (!existsSync(d)) mkdirSync(d, { recursive: true });
  return d;
};
export const supervised = () => process.env.KAYN_SUPERVISED === '1';

/** Compare deux versions « 1.2.3 » : >0 si a plus récente que b. */
export function cmpVersion(a: string, b: string) {
  const pa = a.split(/[.-]/).map((x) => parseInt(x, 10) || 0); const pb = b.split(/[.-]/).map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] ?? 0) - (pb[i] ?? 0); if (d) return d; }
  return 0;
}

type Manifest = { version: string; file: string; sha256: string; size?: number; notes?: string; date?: string };
async function cfg(hotelId: number) {
  const s = (await getSettings(getPool(), hotelId)).updates ?? {};
  return { url: (s.url ?? process.env.KAYN_UPDATE_URL ?? DEFAULT_UPDATE_URL) as string, token: (s.token ?? process.env.KAYN_UPDATE_TOKEN ?? '') as string, auto: s.auto_check !== false, autoInstall: s.auto_install === true };
}
const headers = (url: string, token: string) => {
  const h: Record<string, string> = { 'User-Agent': `KAYN-Hotel/${APP_VERSION}` };
  if (/api\.github\.com/.test(url)) h.Accept = 'application/vnd.github.raw';
  if (token) h.Authorization = `Bearer ${token}`;
  return h;
};
function netError(e: any, status?: number) {
  if (status === 401 || status === 403) return 'Accès refusé au serveur de mises à jour : vérifiez le jeton d\'accès (Administration → Mises à jour).';
  if (status === 404) return 'Aucune mise à jour publiée à cette adresse (ou jeton d\'accès manquant).';
  if (status) return `Serveur de mises à jour : erreur ${status}.`;
  const c = e?.cause?.code ?? e?.code ?? '';
  if (c === 'ENOTFOUND' || c === 'EAI_AGAIN' || c === 'ECONNREFUSED' || c === 'ENETUNREACH') return 'Pas de connexion Internet : la vérification se refera plus tard.';
  if (e?.name === 'TimeoutError' || e?.name === 'AbortError') return 'Le serveur de mises à jour ne répond pas (délai dépassé).';
  return `Vérification impossible : ${e?.message ?? e}`;
}

async function saveState(hotelId: number, patch: Record<string, unknown>) {
  const cur = (await one<any>(getPool(), `SELECT value FROM settings WHERE hotel_id = $1 AND key = 'update_state'`, [hotelId]))?.value ?? {};
  const v = { ...cur, ...patch };
  await getPool().query(`INSERT INTO settings (hotel_id, key, value) VALUES ($1,'update_state',$2) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`, [hotelId, JSON.stringify(v)]);
  return v;
}
export async function updateState(hotelId: number) {
  return (await one<any>(getPool(), `SELECT value FROM settings WHERE hotel_id = $1 AND key = 'update_state'`, [hotelId]))?.value ?? {};
}

/** Notifie (cloche) tous les comptes ayant le droit de gérer les sauvegardes — une seule fois par version. */
async function notifyAdmins(hotelId: number, m: Manifest) {
  await getPool().query(
    `INSERT INTO user_notifications (hotel_id, user_id, kind, severity, title, body, link, dedupe_key)
     SELECT DISTINCT $1::int, u.id, 'important', 'info', $2::text, $3::text, '/admin?s=updates', $4::text
       FROM users u JOIN role_permissions rp ON rp.role_id = u.role_id JOIN permissions p ON p.id = rp.permission_id
      WHERE u.hotel_id = $1 AND u.active AND p.code = 'backups.manage'
     ON CONFLICT (user_id, dedupe_key) DO NOTHING`,
    [hotelId, `Mise à jour disponible : version ${m.version}`, (m.notes ?? 'Cliquez pour l\'installer en un clic (sauvegarde automatique avant installation).').slice(0, 400), `update:${m.version}`],
  );
}

export async function checkForUpdate(hotelId: number) {
  const c = await cfg(hotelId);
  if (!c.url) return saveState(hotelId, { checked_at: new Date().toISOString(), error: 'Adresse de mise à jour non configurée.' });
  let m: Manifest;
  try {
    const r = await fetch(c.url, { headers: headers(c.url, c.token), signal: AbortSignal.timeout(15_000) });
    if (!r.ok) return saveState(hotelId, { checked_at: new Date().toISOString(), error: netError(null, r.status) });
    m = (await r.json()) as Manifest;
    if (!m?.version || !m?.file || !/^[a-f0-9]{64}$/i.test(m.sha256 ?? '')) throw new Error('manifeste invalide');
  } catch (e: any) {
    return saveState(hotelId, { checked_at: new Date().toISOString(), error: netError(e) });
  }
  const newer = cmpVersion(m.version, APP_VERSION) > 0;
  if (newer) await notifyAdmins(hotelId, m);
  return saveState(hotelId, { checked_at: new Date().toISOString(), error: null, latest: newer ? m : null, latest_seen: m.version });
}

/** Vérification automatique (planificateur) : au plus toutes les 6 heures. */
export async function autoCheckIfDue(hotelId: number) {
  const c = await cfg(hotelId);
  if (!c.auto || !c.url) return;
  const s = await updateState(hotelId);
  if (s.checked_at && Date.now() - new Date(s.checked_at).getTime() < 6 * 3600_000) return;
  await checkForUpdate(hotelId);
}

let installing = false;
/** Télécharge + vérifie + sauvegarde la base, puis prépare l'installation (appliquée par le superviseur au redémarrage). */
export async function prepareInstall(hotelId: number, by: { id: number | null; name: string }, backup: (note: string) => Promise<{ file_name: string }>) {
  if (installing) throw new AppError(409, 'update_busy', 'Une installation est déjà en cours.');
  const st = await updateState(hotelId);
  const m: Manifest | null = st.latest;
  if (!m || cmpVersion(m.version, APP_VERSION) <= 0) throw badRequest('Aucune nouvelle version à installer. Cliquez sur « Vérifier maintenant ».');
  installing = true;
  try {
    const c = await cfg(hotelId);
    const fileUrl = new URL(m.file, c.url).toString();
    let buf: Buffer;
    try {
      const r = await fetch(fileUrl, { headers: headers(fileUrl, c.token), signal: AbortSignal.timeout(10 * 60_000) });
      if (!r.ok) throw new AppError(502, 'update_download', netError(null, r.status));
      buf = Buffer.from(await r.arrayBuffer());
    } catch (e: any) { if (e instanceof AppError) throw e; throw new AppError(502, 'update_download', netError(e)); }
    const sha = createHash('sha256').update(buf).digest('hex');
    if (sha.toLowerCase() !== m.sha256.toLowerCase() || (m.size && buf.length !== m.size)) throw new AppError(422, 'update_corrupt', 'Fichier de mise à jour corrompu (empreinte différente) : rien n\'a été installé. Réessayez plus tard.');
    const dir = updatesDir();
    const zip = path.join(dir, `kayn-hotel-${m.version}.zip`);
    writeFileSync(`${zip}.tmp`, buf); renameSync(`${zip}.tmp`, zip);
    // sauvegarde vérifiée AVANT de toucher quoi que ce soit (sinon on s'arrête là)
    const b = await backup(`Avant mise à jour ${APP_VERSION} → ${m.version}`);
    writeFileSync(path.join(dir, 'pending.json'), JSON.stringify({ version: m.version, from: APP_VERSION, zip, sha256: sha, backup: b.file_name, by: by.name, at: new Date().toISOString() }, null, 1));
    await getPool().query(`INSERT INTO audit_logs (hotel_id, user_id, action, entity, entity_id, after, result) VALUES ($1,$2,'update_install','system',$3,$4,'success')`,
      [hotelId, by.id, m.version, JSON.stringify({ from: APP_VERSION, backup: b.file_name, sha256: sha })]).catch(() => {});
    // redémarrage : le superviseur applique la mise à jour puis relance (≈ 30 s à 2 min)
    setTimeout(() => process.exit(75), 1500).unref();
    return { version: m.version, backup: b.file_name };
  } finally { installing = false; }
}

/** Résultat de la dernière installation (écrit par le superviseur). */
export function lastResult() {
  try { return JSON.parse(readFileSync(path.join(updatesDir(), 'last.json'), 'utf8')); } catch { return null; }
}
/** Démarrage réussi : la nouvelle version est confirmée (le superviseur ne fera pas de retour arrière). */
export function confirmBoot() {
  const f = path.join(updatesDir(), 'boot.json');
  if (existsSync(f)) try { unlinkSync(f); } catch { /* */ }
}

/**
 * Installation automatique la nuit (entre 3 h et 5 h, heure de l'hôtel) quand une nouvelle version est disponible
 * (réglage « auto_install », désactivé par défaut). Même sécurité que le bouton : sauvegarde vérifiée, retour arrière.
 */
export async function autoInstallIfDue(hotelId: number, backup: (note: string) => Promise<{ file_name: string }>) {
  const c = await cfg(hotelId);
  if (!c.autoInstall || !c.url) return;
  const tz = (await one<any>(getPool(), 'SELECT timezone FROM hotels WHERE id = $1', [hotelId]))?.timezone ?? process.env.TZ ?? 'Africa/Algiers';
  const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', hour12: false }).format(new Date())) % 24;
  if (hour < 3 || hour >= 5) return;
  const st = await updateState(hotelId);
  if (!st.latest || cmpVersion(st.latest.version, APP_VERSION) <= 0) return;
  // une version déjà essayée et revenue en arrière n'est pas réinstallée automatiquement
  const last = lastResult();
  if (last && !last.ok && last.version === st.latest.version) return;
  await prepareInstall(hotelId, { id: null, name: 'Installation automatique (nuit)' }, backup);
}
