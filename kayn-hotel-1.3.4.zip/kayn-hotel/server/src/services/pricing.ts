import type { Db } from '../db/pool.js';
import { one, q } from '../db/pool.js';
import { addDays, diffDays } from '../lib/dates.js';
import { badRequest } from '../lib/errors.js';
import { getSettings } from './common.js';

const r2 = (n: number) => Math.round(n * 100) / 100;

export interface PricingContext {
  settings: Record<string, any>;
  seasons: any[];
  plans: Map<number, any>;
  planPrices: Map<string, number>;
}

export async function loadPricing(db: Db, hotelId: number): Promise<PricingContext> {
  const settings = await getSettings(db, hotelId);
  const seasons = await q<any>(db, `SELECT * FROM rate_seasons WHERE hotel_id = $1 AND active ORDER BY (room_type_id IS NULL), start_date DESC, id DESC`, [hotelId]);
  const plans = await q<any>(db, `SELECT * FROM rate_plans WHERE hotel_id = $1`, [hotelId]);
  const prices = await q<any>(db, `SELECT p.* FROM rate_plan_prices p JOIN rate_plans rp ON rp.id = p.rate_plan_id WHERE rp.hotel_id = $1`, [hotelId]);
  return {
    settings,
    seasons,
    plans: new Map(plans.map((p) => [p.id, p])),
    planPrices: new Map(prices.map((p) => [`${p.rate_plan_id}:${p.room_type_id}`, Number(p.price)])),
  };
}

/** Nuits de week-end (0 = dimanche … 6 = samedi). Par défaut : jeudi et vendredi soir. */
const weekendNights = (s: Record<string, any>): number[] => (Array.isArray(s.weekend_nights) ? s.weekend_nights : [4, 5]);
const dow = (d: string) => new Date(d + 'T00:00:00Z').getUTCDay();

/**
 * Prix d'une nuit : base (semaine / week-end) → prix fixe du plan → saison → ajustement du plan,
 * puis supplément chambre, formule repas par adulte et supplément enfant.
 */
export function nightPrice(ctx: PricingContext, type: any, room: any, date: string, meal: string, adults: number, children: number, planId: number | null) {
  const plan = planId ? ctx.plans.get(planId) : null;
  const isWeekend = weekendNights(ctx.settings).includes(dow(date));
  let base = isWeekend && type.weekend_rate !== null && type.weekend_rate !== undefined ? Number(type.weekend_rate) : Number(type.base_rate);
  const fixed = plan ? ctx.planPrices.get(`${plan.id}:${type.id}`) : undefined;
  if (fixed !== undefined) base = fixed;
  const season = ctx.seasons.find((s) => s.start_date <= date && s.end_date >= date && (!s.room_type_id || s.room_type_id === type.id));
  if (season) {
    const v = Number(season.adjustment_value);
    if (season.adjustment_type === 'percent') base = base * (1 + v / 100);
    else if (season.adjustment_type === 'amount') base = base + v;
    else base = v;
  }
  if (plan && fixed === undefined && plan.adjustment_type !== 'none') {
    const v = Number(plan.adjustment_value);
    base = plan.adjustment_type === 'percent' ? base * (1 + v / 100) : base + v;
  }
  base = Math.max(0, r2(base));
  const extras = Number(room?.rate_supplement ?? 0) + Number(ctx.settings.meal_supplements?.[meal] ?? 0) * adults + Number(type.child_rate ?? 0) * children;
  return { date, price: r2(base + extras), base, season: season?.name ?? null, weekend: isWeekend };
}

export function checkPlan(ctx: PricingContext, planId: number | null, ci: string, co: string, payerId: number | null, guestId: number | null) {
  if (!planId) return null;
  const plan = ctx.plans.get(planId);
  if (!plan || !plan.active) throw badRequest('Tarif inconnu ou désactivé.');
  const nights = diffDays(ci, co);
  if (nights < plan.min_nights) throw badRequest(`Le tarif « ${plan.name} » exige au moins ${plan.min_nights} nuit(s).`);
  if (plan.valid_from && ci < plan.valid_from) throw badRequest(`Le tarif « ${plan.name} » n'est valable qu'à partir du ${plan.valid_from}.`);
  if (plan.valid_to && ci > plan.valid_to) throw badRequest(`Le tarif « ${plan.name} » a expiré le ${plan.valid_to}.`);
  if (plan.guest_id && plan.guest_id !== payerId && plan.guest_id !== guestId) throw badRequest(`Le tarif négocié « ${plan.name} » est réservé à un client précis.`);
  return plan;
}

/** Prix d'un séjour pour une chambre : détail nuit par nuit et prix moyen. */
export function priceStay(ctx: PricingContext, type: any, room: any, ci: string, co: string, meal: string, adults: number, children: number, planId: number | null) {
  const nights = [];
  for (let d = ci; d < co; d = addDays(d, 1)) nights.push(nightPrice(ctx, type, room, d, meal, adults, children, planId));
  const total = r2(nights.reduce((s, n) => s + n.price, 0));
  return { nights, total, avg: nights.length ? r2(total / nights.length) : 0 };
}

/** Raccourci : charge le contexte, la chambre et son type puis calcule. */
export async function quoteRoom(db: Db, hotelId: number, roomId: number, ci: string, co: string, meal: string, adults: number, children: number, planId: number | null, ctx?: PricingContext) {
  const c = ctx ?? (await loadPricing(db, hotelId));
  const room = await one<any>(db, 'SELECT id, room_type_id, rate_supplement FROM rooms WHERE id = $1 AND hotel_id = $2', [roomId, hotelId]);
  if (!room) throw badRequest('Chambre inconnue.');
  const type = await one<any>(db, 'SELECT * FROM room_types WHERE id = $1', [room.room_type_id]);
  return priceStay(c, type, room, ci, co, meal, adults, children, planId);
}
