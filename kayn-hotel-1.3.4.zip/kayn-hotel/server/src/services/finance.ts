/** Rapports financiers (période), créances, transactions. Montants agrégés en SQL (numeric exact). */
import { q, type Db } from '../db/pool.js';
import { config } from '../config.js';
import { notFound } from '../lib/errors.js';
import { BALANCE_EXPR, FIN_SQL, guestDisplayName, withBalance } from './common.js';

type Col = { key: string; label: string; money?: boolean };
export const FIN_REPORTS: Record<string, { title: string; dated: boolean; columns: Col[] }> = {
  revenue: { title: 'Chiffre d\'affaires facturé', dated: true, columns: [
    { key: 'day', label: 'Date' }, { key: 'room', label: 'Hébergement HT', money: true }, { key: 'extras', label: 'Prestations HT', money: true },
    { key: 'vat', label: 'TVA', money: true }, { key: 'tourist', label: 'Taxe de séjour', money: true }, { key: 'ttc', label: 'Total TTC', money: true }, { key: 'docs', label: 'Factures / avoirs' }] },
  payments: { title: 'Recettes par mode de paiement', dated: true, columns: [
    { key: 'method_label', label: 'Mode' }, { key: 'count', label: 'Opérations' }, { key: 'received', label: 'Encaissé', money: true }, { key: 'refunded', label: 'Remboursé', money: true }, { key: 'net', label: 'Net', money: true }] },
  expenses: { title: 'Dépenses', dated: true, columns: [
    { key: 'expense_date', label: 'Date' }, { key: 'category', label: 'Catégorie' }, { key: 'description', label: 'Libellé' }, { key: 'supplier', label: 'Fournisseur' },
    { key: 'method_label', label: 'Mode' }, { key: 'amount', label: 'Montant', money: true }, { key: 'by', label: 'Saisi par' }] },
  vat: { title: 'TVA collectée', dated: true, columns: [{ key: 'rate_label', label: 'Taux' }, { key: 'base', label: 'Base HT', money: true }, { key: 'tax', label: 'TVA', money: true }, { key: 'ttc', label: 'TTC', money: true }] },
  invoices: { title: 'Factures payées et impayées', dated: true, columns: [
    { key: 'number', label: 'N°' }, { key: 'date', label: 'Date' }, { key: 'type_label', label: 'Type' }, { key: 'client', label: 'Client' }, { key: 'ref', label: 'Séjour' },
    { key: 'total', label: 'Total TTC', money: true }, { key: 'status_label', label: 'Statut' }] },
  refunds: { title: 'Remboursements', dated: true, columns: [
    { key: 'date', label: 'Date' }, { key: 'ref', label: 'Dossier' }, { key: 'client', label: 'Client' }, { key: 'method_label', label: 'Mode' }, { key: 'reason', label: 'Motif' }, { key: 'amount', label: 'Montant', money: true }, { key: 'by', label: 'Par' }] },
  receivables: { title: 'Créances clients', dated: false, columns: [
    { key: 'ref', label: 'Dossier / facture' }, { key: 'client', label: 'Client' }, { key: 'payer', label: 'Payeur' }, { key: 'date', label: 'Date' }, { key: 'age', label: 'Âge (j)' },
    { key: 'total', label: 'Montant', money: true }, { key: 'paid', label: 'Encaissé', money: true }, { key: 'due', label: 'Reste à payer', money: true }] },
  cash: { title: 'Rapports de caisse', dated: true, columns: [
    { key: 'id', label: 'Session' }, { key: 'register', label: 'Caisse' }, { key: 'opened', label: 'Ouverture' }, { key: 'closed', label: 'Clôture' }, { key: 'cashier', label: 'Caissier' },
    { key: 'opening', label: 'Fond', money: true }, { key: 'expected', label: 'Théorique', money: true }, { key: 'counted', label: 'Compté', money: true }, { key: 'difference', label: 'Écart', money: true }, { key: 'validated', label: 'Validée par' }] },
};
export const METHOD_LBL: Record<string, string> = { cash: 'Espèces', card: 'Carte bancaire', cheque: 'Chèque', transfer: 'Virement', company_account: 'Compte société', online: 'Paiement en ligne' };
const TYPE_LBL: Record<string, string> = { invoice: 'Facture', credit_note: 'Avoir', proforma: 'Pro forma' };
const ST_LBL: Record<string, string> = { issued: 'Impayée', partially_paid: 'Partiellement payée', paid: 'Payée', credited: 'Annulée par avoir', proforma: 'Pro forma', cancelled: 'Annulée' };
const TZ = () => config.timezone;
const dt = (d: any) => (d ? new Date(d).toLocaleString('fr-FR', { timeZone: TZ(), day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '');

export async function receivables(db: Db, hotelId: number) {
  const t = new Date();
  const res = await q<any>(db,
    `SELECT * FROM (SELECT r.id, r.code, r.check_in, r.check_out, r.status, g.kind, g.last_name, g.first_name, g.company_name, pg.company_name AS payer, ${FIN_SQL}
        FROM reservations r JOIN guests g ON g.id = r.guest_id LEFT JOIN guests pg ON pg.id = r.payer_guest_id WHERE r.hotel_id = $1) x
      WHERE ${BALANCE_EXPR} > 0.004 AND x.status IN ('checked_in','checked_out','cancelled','no_show')
      ORDER BY x.check_out`, [hotelId]);
  const man = await q<any>(db,
    `SELECT i.id, i.number, i.issued_at, i.total, i.bill_to, i.due_date,
            (SELECT COALESCE(sum(p.amount),0) FROM payments p WHERE p.invoice_id = i.id AND NOT p.void) - (SELECT COALESCE(sum(f.amount),0) FROM refunds f WHERE f.invoice_id = i.id) AS paid,
            (SELECT COALESCE(sum(-c.total),0) FROM invoices c WHERE c.credit_of_invoice_id = i.id AND c.type = 'credit_note') AS credited
       FROM invoices i WHERE i.hotel_id = $1 AND i.type = 'invoice' AND i.reservation_id IS NULL AND i.status IN ('issued','partially_paid')`, [hotelId]);
  const age = (d: string) => Math.max(0, Math.floor((t.getTime() - Date.parse(d)) / 86_400_000));
  return [
    ...res.map((x) => { const f = withBalance(x); return { kind: 'reservation', id: x.id, ref: x.code, client: guestDisplayName(x), payer: x.payer ?? '', date: x.check_out, age: age(x.check_out), status: x.status, total: f.total, paid: Math.round((Number(x.paid) - Number(x.refunded)) * 100) / 100, due: f.balance }; }),
    ...man.map((x) => { const due = Math.round((Number(x.total) - Number(x.credited) - Number(x.paid)) * 100) / 100; return { kind: 'invoice', id: x.id, ref: x.number, client: x.bill_to?.name ?? '', payer: '', date: String(x.issued_at.toISOString?.() ?? x.issued_at).slice(0, 10), age: age(x.issued_at), status: 'invoice', total: Number(x.total) - Number(x.credited), paid: Number(x.paid), due }; }),
  ].filter((x) => x.due > 0.004).sort((a, b) => b.age - a.age);
}

export async function finReport(db: Db, hotelId: number, kind: string, from: string, to: string) {
  const def = FIN_REPORTS[kind];
  if (!def) throw notFound('Rapport inconnu');
  const P = [hotelId, from, to, TZ()];
  const inPeriod = (col: string) => `(${col} AT TIME ZONE $4)::date BETWEEN $2 AND $3`;
  let rows: any[] = [];
  let total: Record<string, any> | null = null;
  if (kind === 'revenue') {
    rows = (await q<any>(db,
      `SELECT (i.issued_at AT TIME ZONE $4)::date AS day,
              COALESCE(sum(it.total) FILTER (WHERE it.kind = 'room'), 0) AS room,
              COALESCE(sum(it.total) FILTER (WHERE it.kind NOT IN ('room','tourist_tax')), 0) AS extras,
              COALESCE(sum(it.tax_amount), 0) AS vat,
              COALESCE(sum(it.total) FILTER (WHERE it.kind = 'tourist_tax'), 0) AS tourist,
              count(DISTINCT i.id)::int AS docs
         FROM invoices i JOIN invoice_items it ON it.invoice_id = i.id
        WHERE i.hotel_id = $1 AND i.type IN ('invoice','credit_note') AND ${inPeriod('i.issued_at')}
        GROUP BY 1 ORDER BY 1`, P)).map((x) => ({ ...x, day: String(x.day), room: Number(x.room), extras: Number(x.extras), vat: Number(x.vat), tourist: Number(x.tourist), ttc: Math.round((Number(x.room) + Number(x.extras) + Number(x.vat) + Number(x.tourist)) * 100) / 100 }));
    total = sumCols(rows, ['room', 'extras', 'vat', 'tourist', 'ttc', 'docs'], { day: 'Total' });
  } else if (kind === 'payments') {
    const pay = await q<any>(db, `SELECT method, count(*)::int AS n, sum(amount) AS amt FROM payments WHERE hotel_id = $1 AND NOT void AND ${inPeriod('received_at')} GROUP BY 1`, P);
    const ref = await q<any>(db, `SELECT f.method, count(*)::int AS n, sum(f.amount) AS amt FROM refunds f LEFT JOIN reservations r ON r.id = f.reservation_id LEFT JOIN invoices i ON i.id = f.invoice_id
       WHERE COALESCE(r.hotel_id, i.hotel_id) = $1 AND ${inPeriod('f.created_at')} GROUP BY 1`, P);
    const inc = await q<any>(db, `SELECT method, count(*)::int AS n, sum(amount) AS amt FROM incomes WHERE hotel_id = $1 AND NOT void AND ${inPeriod('created_at')} GROUP BY 1`, P);
    const methods = [...new Set([...pay, ...ref, ...inc].map((x) => x.method))];
    rows = methods.map((m) => {
      const p = pay.find((x) => x.method === m); const r = ref.find((x) => x.method === m); const i = inc.find((x) => x.method === m);
      const received = Number(p?.amt ?? 0) + Number(i?.amt ?? 0); const refunded = Number(r?.amt ?? 0);
      return { method: m, method_label: METHOD_LBL[m] ?? m, count: (p?.n ?? 0) + (r?.n ?? 0) + (i?.n ?? 0), received, refunded, net: Math.round((received - refunded) * 100) / 100 };
    });
    total = sumCols(rows, ['count', 'received', 'refunded', 'net'], { method_label: 'Total' });
  } else if (kind === 'expenses') {
    rows = (await q<any>(db, `SELECT e.*, s.name AS supplier, u.full_name AS by FROM expenses e LEFT JOIN suppliers s ON s.id = e.supplier_id LEFT JOIN users u ON u.id = e.created_by
        WHERE e.hotel_id = $1 AND NOT e.void AND e.expense_date BETWEEN $2 AND $3 ORDER BY e.expense_date, e.id`, P.slice(0, 3)))
      .map((x) => ({ ...x, expense_date: String(x.expense_date), amount: Number(x.amount), method_label: METHOD_LBL[x.method] }));
    total = sumCols(rows, ['amount'], { expense_date: 'Total' });
  } else if (kind === 'vat') {
    rows = (await q<any>(db, `SELECT it.tax_rate AS rate, sum(it.total) AS base, sum(it.tax_amount) AS tax FROM invoices i JOIN invoice_items it ON it.invoice_id = i.id
        WHERE i.hotel_id = $1 AND i.type IN ('invoice','credit_note') AND it.kind <> 'tourist_tax' AND ${inPeriod('i.issued_at')} GROUP BY 1 ORDER BY 1`, P))
      .map((x) => ({ rate: Number(x.rate), rate_label: `${Number(x.rate)} %`, base: Number(x.base), tax: Number(x.tax), ttc: Math.round((Number(x.base) + Number(x.tax)) * 100) / 100 }));
    total = sumCols(rows, ['base', 'tax', 'ttc'], { rate_label: 'Total' });
  } else if (kind === 'invoices') {
    rows = (await q<any>(db, `SELECT i.id, i.number, i.issued_at, i.type, i.status, i.total, i.bill_to, r.code FROM invoices i LEFT JOIN reservations r ON r.id = i.reservation_id
        WHERE i.hotel_id = $1 AND ${inPeriod('i.issued_at')} ORDER BY i.issued_at`, P))
      .map((x) => ({ id: x.id, number: x.number, date: dt(x.issued_at), type: x.type, type_label: TYPE_LBL[x.type], client: x.bill_to?.name ?? '', ref: x.code ?? '', total: Number(x.total), status: x.status, status_label: ST_LBL[x.status] ?? x.status }));
    total = sumCols(rows.filter((x) => x.type !== 'proforma'), ['total'], { number: 'Total (hors pro forma)' });
  } else if (kind === 'refunds') {
    rows = (await q<any>(db, `SELECT f.*, r.code, g.kind, g.last_name, g.first_name, g.company_name, u.full_name AS by FROM refunds f
        LEFT JOIN reservations r ON r.id = f.reservation_id LEFT JOIN guests g ON g.id = r.guest_id LEFT JOIN invoices i ON i.id = f.invoice_id LEFT JOIN users u ON u.id = f.created_by
        WHERE COALESCE(r.hotel_id, i.hotel_id) = $1 AND ${inPeriod('f.created_at')} ORDER BY f.created_at`, P))
      .map((x) => ({ date: dt(x.created_at), ref: x.code ?? '', client: x.kind ? guestDisplayName(x) : '', method_label: METHOD_LBL[x.method], reason: x.reason, amount: Number(x.amount), by: x.by }));
    total = sumCols(rows, ['amount'], { date: 'Total' });
  } else if (kind === 'receivables') {
    rows = await receivables(db, hotelId);
    total = sumCols(rows, ['total', 'paid', 'due'], { ref: 'Total' });
  } else if (kind === 'cash') {
    rows = (await q<any>(db, `SELECT cs.*, cr.name AS register, u.full_name AS cashier, v.full_name AS validator FROM cash_sessions cs JOIN cash_registers cr ON cr.id = cs.cash_register_id
        JOIN users u ON u.id = cs.opened_by LEFT JOIN users v ON v.id = cs.validated_by WHERE cr.hotel_id = $1 AND ${inPeriod('cs.opened_at')} ORDER BY cs.opened_at`, P))
      .map((x) => ({ id: x.id, register: x.register, opened: dt(x.opened_at), closed: x.closed_at ? dt(x.closed_at) : 'Ouverte', cashier: x.cashier, opening: Number(x.opening_amount),
        expected: x.expected_amount === null ? null : Number(x.expected_amount), counted: x.declared_amount === null ? null : Number(x.declared_amount),
        difference: x.difference === null ? null : Number(x.difference), validated: x.validator ?? '' }));
    total = sumCols(rows, ['difference'], { id: 'Total écarts' });
  }
  return { kind, title: def.title, from, to, columns: def.columns, rows, total };
}

function sumCols(rows: any[], keys: string[], label: Record<string, string>) {
  const t: Record<string, any> = { ...label };
  for (const k of keys) t[k] = Math.round(rows.reduce((s, r) => s + Number(r[k] ?? 0), 0) * 100) / 100;
  return t;
}

/** Historique détaillé des transactions (encaissements, remboursements, mouvements de caisse, dépenses, recettes). */
export async function transactions(db: Db, hotelId: number, from: string, to: string, type?: string, method?: string) {
  const rows = await q<any>(db,
    `SELECT * FROM (
       SELECT 'payment' AS type, p.id, p.received_at AS at, p.method, p.amount, p.void, p.reference, p.card_last4, COALESCE(r.code, i.number) AS ref,
              CASE WHEN p.kind = 'deposit' THEN 'Acompte' ELSE 'Paiement' END AS label, u.full_name AS by_name, p.cash_session_id, p.reservation_id, p.invoice_id
         FROM payments p LEFT JOIN reservations r ON r.id = p.reservation_id LEFT JOIN invoices i ON i.id = p.invoice_id LEFT JOIN users u ON u.id = p.received_by WHERE p.hotel_id = $1
       UNION ALL
       SELECT 'refund', f.id, f.created_at, f.method, -f.amount, false, NULL, NULL, COALESCE(r.code, i.number), 'Remboursement : ' || f.reason, u.full_name, f.cash_session_id, f.reservation_id, f.invoice_id
         FROM refunds f LEFT JOIN reservations r ON r.id = f.reservation_id LEFT JOIN invoices i ON i.id = f.invoice_id LEFT JOIN users u ON u.id = f.created_by WHERE COALESCE(r.hotel_id, i.hotel_id) = $1
       UNION ALL
       SELECT 'movement', m.id, m.created_at, 'cash', CASE WHEN m.direction = 'in' THEN m.amount ELSE -m.amount END, false, m.reference, NULL, 'Caisse #' || m.session_id, m.description, u.full_name, m.session_id, NULL, NULL
         FROM cash_movements m JOIN cash_sessions cs ON cs.id = m.session_id JOIN cash_registers cr ON cr.id = cs.cash_register_id LEFT JOIN users u ON u.id = m.created_by WHERE cr.hotel_id = $1
       UNION ALL
       SELECT 'expense', e.id, e.created_at, e.method, -e.amount, e.void, e.reference, NULL, e.category, e.description, u.full_name, e.cash_session_id, NULL, NULL
         FROM expenses e LEFT JOIN users u ON u.id = e.created_by WHERE e.hotel_id = $1
       UNION ALL
       SELECT 'income', x.id, x.created_at, x.method, x.amount, x.void, x.reference, NULL, x.category, x.description, u.full_name, x.cash_session_id, NULL, NULL
         FROM incomes x LEFT JOIN users u ON u.id = x.created_by WHERE x.hotel_id = $1
     ) t WHERE (t.at AT TIME ZONE $4)::date BETWEEN $2 AND $3 AND ($5::text IS NULL OR t.type = $5) AND ($6::text IS NULL OR t.method = $6)
     ORDER BY t.at DESC LIMIT 2000`, [hotelId, from, to, TZ(), type ?? null, method ?? null]);
  return rows.map((x) => ({ ...x, amount: Number(x.amount), method_label: METHOD_LBL[x.method] ?? x.method }));
}

/** Indicateurs de la période pour l'écran Facturation. */
export async function financeSummary(db: Db, hotelId: number, from: string, to: string) {
  const rev = await finReport(db, hotelId, 'revenue', from, to);
  const pay = await finReport(db, hotelId, 'payments', from, to);
  const exp = await finReport(db, hotelId, 'expenses', from, to);
  const rec = await receivables(db, hotelId);
  return {
    revenue_ttc: rev.total?.ttc ?? 0, revenue_ht: Math.round(((rev.total?.room ?? 0) + (rev.total?.extras ?? 0)) * 100) / 100, vat: rev.total?.vat ?? 0,
    collected: pay.total?.net ?? 0, expenses: exp.total?.amount ?? 0, receivables: Math.round(rec.reduce((s, x) => s + x.due, 0) * 100) / 100, receivables_count: rec.length,
    by_method: pay.rows,
  };
}
