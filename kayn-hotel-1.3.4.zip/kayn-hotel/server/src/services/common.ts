import type { Db } from '../db/pool.js';
import { one, q } from '../db/pool.js';

export async function nextNumber(db: Db, key: string): Promise<number> {
  const r = await one<{ value: number }>(
    db,
    `INSERT INTO counters(key, value) VALUES ($1, 1)
     ON CONFLICT (key) DO UPDATE SET value = counters.value + 1 RETURNING value`,
    [key],
  );
  return r!.value;
}

export async function getSettings(db: Db, hotelId: number): Promise<Record<string, any>> {
  const rows = await q<{ key: string; value: any }>(db, 'SELECT key, value FROM settings WHERE hotel_id = $1', [hotelId]);
  const s: Record<string, any> = {
    meal_supplements: { RO: 0, BB: 0, HB: 0, FB: 0 },
    vat_rate: 0,
    tourist_tax_per_adult_night: 0,
    check_in_time: '14:00',
    check_out_time: '12:00',
    reminder_days_before: 1,
    smtp: null,
    default_guest_language: 'fr',
    /** TVA par type de prestation (%), à défaut vat_rate ; figée sur chaque ligne au moment de la saisie */
    tax_rates: {},
    /** Caisse : un paiement en espèces exige une caisse ouverte */
    cash_session_required: true,
    /** Paiement en ligne : actif seulement si une passerelle est configurée */
    payment_gateway: { enabled: false, provider: '' },
    /** Housekeeping : inspection obligatoire avant remise en vente, recouche quotidienne, durées standard (min) */
    housekeeping: { inspection_required: true, stayover_daily: true, min_score: 80, minutes: { checkout_clean: 40, stayover: 20, arrival_prep: 15, deep_clean: 90, inspection: 10, turndown: 10, other: 30 } },
    /** Restaurant : horaires du petit-déjeuner, prestation facturée pour un petit-déjeuner supplémentaire, blocage si stock insuffisant, remise max */
    restaurant: { breakfast_start: '06:30', breakfast_end: '10:30', breakfast_service_code: 'PDJ', stock_block: true, table_to_clean: true, max_discount_percent: 30 },
    /** Stocks & achats : alerte de péremption (jours), seuils d'écart d'inventaire nécessitant un responsable, entrepôt du restaurant, catégorie de dépense */
    stock: { expiry_alert_days: 30, inventory_gap_percent: 10, inventory_gap_value: 5000, restaurant_warehouse_id: null, purchase_category: 'Achats fournisseurs', late_po_days: 0 },
    /** Maintenance : délai d'intervention par priorité (heures), horizon préventif, alerte fin de garantie (jours), catégorie de dépense, taux horaire par défaut */
    maintenance: { sla_hours: { urgent: 4, high: 24, normal: 72, low: 168 }, preventive_horizon_days: 7, warranty_alert_days: 60, expense_category: 'Maintenance', default_hourly_rate: 600 },
    /** Ressources humaines. Les taux légaux (cotisations, impôt) ne sont PAS préremplis : à saisir selon la législation en vigueur.
     *  leave_days_per_month, monthly_hours, day_divisor, overtime_rate_percent, min_rest_hours : valeurs usuelles à vérifier par l'établissement. */
    hr: {
      late_tolerance_minutes: 5, overtime_threshold_minutes: 15, min_rest_hours: 11, weekly_rest_days: [5, 6], leave_days_per_month: 2.5, leave_year_start_month: 7,
      monthly_hours: 173.33, day_divisor: 30, overtime_rate_percent: 50, contributions: [], tax_brackets: [], contract_alert_days: 30, document_alert_days: 30,
      payroll_category: 'Salaires', advance_category: 'Avances sur salaire',
    },
    /** CRM : seuil « fidèle », inactivité, programme de fidélité, délais de traitement des réclamations, automatisations, adresse publique (liens d'enquête / désabonnement) */
    crm: {
      loyal_min_stays: 3, inactive_days: 365,
      loyalty: { enabled: true, amount_per_point: 100, min_nights: 1, expiry_months: 24, enrollment_bonus: 0, restaurant: true },
      complaint_sla_hours: { urgent: 2, high: 12, normal: 48, low: 120 },
      automations: { thanks: true, pre_arrival_days: 2, post_stay_survey: true, birthday: false },
      public_url: '',
    },
    /** Night audit : tolérance d'écart de caisse sans justification, seuil d'écart exigeant une autorisation d'un second responsable,
     *  comptage de caisse obligatoire, clôture permise avant minuit (déconseillé : les opérations de la soirée seraient datées de la journée clôturée). */
    night_audit: { cash_tolerance: 0, approval_threshold: 1000, require_cash_count: true, allow_early_close: false },
    /** Administration (Phase 14) */
    security: { session_idle_minutes: 480, max_failed_logins: 5, lock_minutes: 15, password_min_length: 8, reset_code_minutes: 30 },
    /** Moyens de paiement acceptés (contrôlés par la base pour tous les modules) */
    payment_methods: ['cash', 'card', 'cheque', 'transfer', 'company_account', 'online'],
    /** Arrondi d'affichage des montants (documents, écrans) : 2 = centimes, 0 = dinar entier */
    rounding: { decimals: 2 },
    /** Documents imprimés : format par défaut des factures, logo, mentions fiscales, nombre de copies */
    documents: { invoice_paper: 'A4', show_logo: true, show_fiscal: true, receipt_header: '', copies: 1 },
    /** Notifications internes : par type, activation et destinataires (rôles et utilisateurs) */
    notifications_config: {
      security: { enabled: true, roles: ['admin', 'tech_admin'], users: [] },
      important: { enabled: true, roles: ['admin', 'manager'], users: [] },
      low_stock: { enabled: true, roles: ['storekeeper', 'purchaser', 'stock_manager'], users: [] },
      maintenance: { enabled: true, roles: ['maintenance_manager'], users: [] },
      task_reminder: { enabled: true, roles: ['hk_supervisor'], users: [] },
      backup: { enabled: true, roles: ['admin', 'tech_admin'], users: [] },
    },
    /** Sauvegardes automatiques */
    backups: { enabled: true, frequency: 'daily', time: '03:00', weekday: 1, monthday: 1, keep: 14 },
    id_scans: { keep_days: 30 },
    /** Mentions légales en pied de facture */
    invoice_footer: '',
    /** nuits facturées au tarif week-end (0 = dimanche … 6 = samedi) : jeudi et vendredi soir */
    weekend_nights: [4, 5],
    /** Acompte : none = libre ; auto_pending = réservation en attente jusqu'au paiement ; block = confirmation refusée */
    deposit_policy: { mode: 'none', percent: 30, exempt_sources: ['walk_in'] },
    /** Annulation tardive et non-présentation */
    cancellation_policy: {
      enabled: false, hours_before: 48, fee_type: 'nights', fee_value: 1,
      no_show_enabled: false, no_show_fee_type: 'nights', no_show_fee_value: 1,
    },
  };
  for (const r of rows) {
    s[r.key] = r.value && typeof r.value === 'object' && !Array.isArray(r.value) && s[r.key] && typeof s[r.key] === 'object'
      ? { ...s[r.key], ...r.value } : r.value;
  }
  return s;
}

const ACTIVE_RR = `rr.reservation_id = r.id AND rr.status NOT IN ('cancelled','no_show')`;

/**
 * Résumé financier d'une réservation (alias de table : r).
 * room_total est déjà net de remise (rate = rack_rate − remise par nuit).
 */
export const FIN_SQL = `
  COALESCE((SELECT sum(rr.rate * (rr.check_out - rr.check_in)) FROM reservation_rooms rr WHERE ${ACTIVE_RR}), 0) AS room_total,
  COALESCE((SELECT sum(rr.rack_rate * (rr.check_out - rr.check_in)) FROM reservation_rooms rr WHERE ${ACTIVE_RR}), 0) AS rack_total,
  COALESCE((SELECT sum(rr.adults * (rr.check_out - rr.check_in)) FROM reservation_rooms rr WHERE ${ACTIVE_RR}), 0) AS adult_nights,
  COALESCE((SELECT sum(c.total) FROM charges c WHERE c.reservation_id = r.id AND NOT c.void), 0) AS extras_total,
  COALESCE((SELECT sum(round(rr.rate * (rr.check_out - rr.check_in) * r.vat_rate / 100, 2)) FROM reservation_rooms rr WHERE ${ACTIVE_RR}), 0) AS room_vat,
  COALESCE((SELECT sum(round(c.total * c.tax_rate / 100, 2)) FROM charges c WHERE c.reservation_id = r.id AND NOT c.void), 0) AS extras_vat,
  COALESCE((SELECT sum(p.amount) FROM payments p WHERE p.reservation_id = r.id AND NOT p.void), 0) AS paid,
  COALESCE((SELECT sum(p.amount) FROM payments p WHERE p.reservation_id = r.id AND NOT p.void AND p.kind = 'deposit'), 0) AS deposits,
  COALESCE((SELECT sum(f.amount) FROM refunds f WHERE f.reservation_id = r.id), 0) AS refunded,
  r.vat_rate AS fin_vat, r.tourist_tax AS fin_tt`;

/** Expression SQL du solde, sur une sous-requête x construite avec FIN_SQL. */
export const BALANCE_EXPR = `(x.room_total + x.extras_total + x.room_vat + x.extras_vat + round(x.fin_tt * x.adult_nights, 2) - x.paid + x.refunded)`;

const r2 = (n: number) => Math.round(n * 100) / 100;

export function withBalance<T extends Record<string, any>>(r: T) {
  const base = Number(r.room_total) + Number(r.extras_total);
  // TVA calculée ligne par ligne (chambre, prestation) au taux figé de chaque ligne
  const vat = r.room_vat !== undefined ? r2(Number(r.room_vat) + Number(r.extras_vat ?? 0)) : r2((base * Number(r.fin_vat ?? 0)) / 100);
  const tourist = r2(Number(r.fin_tt ?? 0) * Number(r.adult_nights ?? 0));
  const discount = r2(Number(r.rack_total ?? r.room_total) - Number(r.room_total));
  const total = r2(base + vat + tourist);
  const net = Number(r.paid) - Number(r.refunded);
  return { ...r, discount_total: discount, vat_amount: vat, tourist_tax_amount: tourist, tax_total: r2(vat + tourist), total, balance: r2(total - net) };
}

export function guestDisplayName(g: { kind?: string; last_name?: string | null; first_name?: string | null; company_name?: string | null } | null | undefined) {
  if (!g) return '';
  if (g.kind && g.kind !== 'person') return g.company_name ?? '';
  return [g.last_name, g.first_name].filter(Boolean).join(' ');
}

/** Catégories fiscales des prestations */
export const TAX_CATEGORIES = ['room', 'breakfast', 'restaurant', 'room_service', 'minibar', 'laundry', 'transfer', 'parking', 'service', 'fees', 'other'] as const;
const KIND_TO_CAT: Record<string, string> = {
  breakfast: 'breakfast', restaurant: 'restaurant', room_service: 'room_service', minibar: 'minibar', laundry: 'laundry', transfer: 'transfer',
  parking: 'parking', service: 'service', cancellation_fee: 'fees', no_show_fee: 'fees', other: 'other',
};
/** Taux de TVA applicable à un type de prestation (paramètres de l'hôtel). */
export function taxRateFor(settings: Record<string, any>, kindOrCategory: string): number {
  const cat = kindOrCategory === 'room' ? 'room' : KIND_TO_CAT[kindOrCategory] ?? kindOrCategory;
  const v = settings.tax_rates?.[cat];
  return v === undefined || v === null || v === '' ? Number(settings.vat_rate ?? 0) : Number(v);
}
/** Client ou payeur exonéré de TVA (ambassade, organisme exonéré…) */
export async function isTaxExempt(db: Db, ids: (number | null | undefined)[]): Promise<boolean> {
  const list = ids.filter((x): x is number => !!x);
  if (!list.length) return false;
  const r = await one<any>(db, 'SELECT bool_or(tax_exempt) AS ex FROM guests WHERE id = ANY($1::int[])', [list]);
  return !!r?.ex;
}
