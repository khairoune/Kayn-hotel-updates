/**
 * CRM : fiche client unique (doublons, fusion), statut, préférences, fidélité (points, niveaux, récompenses, expiration),
 * entreprises (contacts, contrats, créances), réclamations, enquêtes, communication (modèles, consentement, automatisations),
 * segments et campagnes, confidentialité (export, anonymisation), tableau de bord et rapports.
 */
import { randomBytes } from 'node:crypto';
import type { PoolClient } from 'pg';
import { one, q, type Db } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { addDays, monthStart, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { fromCents, toCents } from '../lib/money.js';
import { config } from '../config.js';
import { BALANCE_EXPR, FIN_SQL, getSettings, guestDisplayName, nextNumber, withBalance } from './common.js';

export const TZ = config.timezone ?? 'Africa/Algiers';
const yr = () => today().slice(0, 4);
const pad = (n: number) => String(n).padStart(4, '0');
const n2 = (v: any) => Math.round(Number(v ?? 0) * 100) / 100;
export const STATUS_LABEL: Record<string, string> = { standard: 'Standard', loyal: 'Fidèle', vip: 'VIP', company: 'Entreprise' };
export const COMPLAINT_CAT: Record<string, string> = { room: 'Chambre', cleanliness: 'Propreté', noise: 'Bruit', staff: 'Personnel', food: 'Restauration', billing: 'Facturation', maintenance: 'Équipement / panne', reservation: 'Réservation', wifi: 'Wi-Fi / TV', other: 'Autre' };
export const COMPLAINT_STATUS: Record<string, string> = { new: 'Nouvelle', in_progress: 'En cours', resolved: 'Résolue', closed: 'Clôturée' };

export interface CrmSettings {
  loyal_min_stays: number; inactive_days: number;
  loyalty: { enabled: boolean; amount_per_point: number; min_nights: number; expiry_months: number; enrollment_bonus: number; restaurant: boolean };
  complaint_sla_hours: Record<string, number>;
  automations: { thanks: boolean; pre_arrival_days: number; post_stay_survey: boolean; birthday: boolean };
  public_url: string;
}
export async function crmSettings(db: Db, hotelId: number): Promise<CrmSettings> {
  return (await getSettings(db, hotelId)).crm;
}
const digits = (s: string | null | undefined) => String(s ?? '').replace(/\D/g, '').slice(-9);
/** Identifiants de la fiche et des fiches fusionnées dans celle-ci. */
export async function idsOf(db: Db, id: number) {
  return (await q<any>(db, `WITH RECURSIVE m(id) AS (SELECT $1::int UNION SELECT g.id FROM guests g JOIN m ON g.merged_into_id = m.id) SELECT id FROM m`, [id])).map((x) => x.id as number);
}

// =====================================================================================================
// Doublons et fusion
// =====================================================================================================
export async function findDuplicates(db: Db, hotelId: number, g: { last_name?: string | null; first_name?: string | null; phone?: string | null; email?: string | null; id_doc_number?: string | null; birth_date?: string | null; company_name?: string | null; exclude_id?: number | null }) {
  const ph = digits(g.phone), em = (g.email ?? '').trim().toLowerCase(), doc = (g.id_doc_number ?? '').trim().toUpperCase();
  const ln = (g.last_name ?? '').trim().toLowerCase(), fn = (g.first_name ?? '').trim().toLowerCase(), cn = (g.company_name ?? '').trim().toLowerCase();
  if (!ph && !em && !doc && !ln && !cn) return [];
  const rows = await q<any>(db, `SELECT g.id, g.code, g.kind, g.last_name, g.first_name, g.company_name, g.phone, g.email, g.birth_date, g.id_doc_number, g.crm_status,
      (SELECT max(s.checked_in_at) FROM stays s WHERE s.guest_id = g.id) AS last_stay
     FROM guests g WHERE g.hotel_id = $1 AND g.merged_into_id IS NULL AND g.anonymized_at IS NULL AND g.id <> COALESCE($7, 0) AND (
       ($2 <> '' AND right(regexp_replace(coalesce(g.phone,''), '\\D', '', 'g'), 9) = $2) OR ($2 <> '' AND right(regexp_replace(coalesce(g.mobile,''), '\\D', '', 'g'), 9) = $2)
       OR ($3 <> '' AND lower(g.email) = $3) OR ($4 <> '' AND upper(g.id_doc_number) = $4)
       OR ($5 <> '' AND lower(g.last_name) = $5 AND ($6 = '' OR lower(coalesce(g.first_name,'')) = $6))
       OR ($8 <> '' AND lower(g.company_name) = $8)) LIMIT 20`, [hotelId, ph, em, doc, ln, fn, g.exclude_id ?? null, cn]);
  return rows.map((r) => {
    const reasons: string[] = [];
    let score = 0;
    if (doc && String(r.id_doc_number ?? '').toUpperCase() === doc) { reasons.push('Même pièce d\'identité'); score += 60; }
    if (em && String(r.email ?? '').toLowerCase() === em) { reasons.push('Même e-mail'); score += 40; }
    if (ph && digits(r.phone) === ph) { reasons.push('Même téléphone'); score += 35; }
    if (ln && String(r.last_name ?? '').toLowerCase() === ln) { reasons.push(fn && String(r.first_name ?? '').toLowerCase() === fn ? 'Même nom et prénom' : 'Même nom'); score += fn && String(r.first_name ?? '').toLowerCase() === fn ? 25 : 10; }
    if (g.birth_date && r.birth_date && String(r.birth_date).slice(0, 10) === g.birth_date) { reasons.push('Même date de naissance'); score += 25; }
    if (cn && String(r.company_name ?? '').toLowerCase() === cn) { reasons.push('Même raison sociale'); score += 60; }
    return { ...r, name: guestDisplayName(r), score: Math.min(100, score), reasons };
  }).filter((r) => r.score >= 25).sort((a, b) => b.score - a.score);
}
/** Correspondance forte (même pièce, même e-mail, ou même téléphone + même nom) : la fiche existante est réutilisée. */
export async function strongMatch(db: Db, hotelId: number, g: any): Promise<number | null> {
  if ((g.kind ?? 'person') !== 'person') return null;
  const d = await findDuplicates(db, hotelId, g);
  const best = d.find((x) => x.kind === 'person' && (x.reasons.includes('Même pièce d\'identité') || x.reasons.includes('Même e-mail')
    || (x.reasons.includes('Même téléphone') && x.reasons.some((r: string) => r.startsWith('Même nom')))));
  return best?.id ?? null;
}
/** Fusion : toutes les références sont reportées sur la fiche conservée (sauf documents légaux figés, rattachés par l'historique). */
export async function mergeGuests(db: PoolClient, actor: Actor, keepId: number, dupId: number) {
  if (keepId === dupId) throw badRequest('Choisissez deux fiches différentes.');
  const [keep, dup] = await Promise.all([one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [keepId, actor.hotelId]), one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [dupId, actor.hotelId])]);
  if (!keep || !dup) throw notFound('Client introuvable');
  if (keep.merged_into_id || dup.merged_into_id) throw conflict('Fiche déjà fusionnée.');
  if (keep.kind !== dup.kind) throw conflict('Impossible de fusionner une personne et une entreprise.');
  const refs = await q<any>(db, `SELECT c.conrelid::regclass::text AS tbl, a.attname AS col FROM pg_constraint c JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = ANY(c.conkey)
      WHERE c.contype = 'f' AND c.confrelid = 'guests'::regclass AND NOT (c.conrelid = 'guests'::regclass AND a.attname = 'merged_into_id')`);
  const moved: Record<string, number> = {}, kept: string[] = [];
  for (const r of refs) {
    await db.query('SAVEPOINT mg');
    try {
      const res = await db.query(`UPDATE ${r.tbl} SET ${r.col} = $1 WHERE ${r.col} = $2`, [keepId, dupId]);
      await db.query('RELEASE SAVEPOINT mg');
      if (res.rowCount) moved[`${r.tbl}.${r.col}`] = res.rowCount;
    } catch {
      await db.query('ROLLBACK TO SAVEPOINT mg');
      kept.push(`${r.tbl}.${r.col}`);
    }
  }
  // champs vides de la fiche conservée complétés par le doublon
  const fill = ['first_name', 'phone', 'mobile', 'email', 'address', 'city', 'country', 'nationality', 'birth_date', 'birth_place', 'id_doc_type', 'id_doc_number', 'id_doc_expiry', 'profession', 'company_id', 'job_title', 'preferred_room_type_id', 'loyalty_number', 'loyalty_joined_at', 'loyalty_tier_id'];
  const sets = fill.filter((f) => keep[f] === null && dup[f] !== null);
  if (sets.length) {
    const dupLoyalty = sets.includes('loyalty_number') ? dup.loyalty_number : null;
    if (dupLoyalty) await db.query('UPDATE guests SET loyalty_number = NULL WHERE id = $1', [dupId]);
    await db.query(`UPDATE guests SET ${sets.map((f, i) => `${f} = $${i + 2}`).join(', ')}, updated_at = now() WHERE id = $1`, [keepId, ...sets.map((f) => dup[f])]);
  }
  await db.query(`UPDATE guests SET consent_email = consent_email AND $2, consent_sms = consent_sms AND $3 WHERE id = $1`, [keepId, dup.consent_email || !dup.consent_updated_at, dup.consent_sms || !dup.consent_updated_at]);
  await db.query(`UPDATE guests SET merged_into_id = $2, loyalty_number = NULL, updated_at = now() WHERE id = $1`, [dupId, keepId]);
  await refreshStatus(db, keepId);
  await refreshTier(db, keepId);
  await audit(db, actor, 'merge', 'guest', keepId, { merged: dup.code }, { moved, kept_on_old_record: kept });
  return { moved, kept };
}

// =====================================================================================================
// Statut et fidélité
// =====================================================================================================
export async function refreshStatus(db: Db, guestId: number) {
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1', [guestId]);
  if (!g || g.status_locked || g.anonymized_at) return;
  if (g.kind !== 'person') { if (g.crm_status !== 'company') await db.query(`UPDATE guests SET crm_status = 'company' WHERE id = $1`, [guestId]); return; }
  const s = await crmSettings(db, g.hotel_id);
  const ids = await idsOf(db, guestId);
  const st = await one<any>(db, `SELECT count(*)::int AS n FROM stays WHERE guest_id = ANY($1::int[]) AND checked_out_at IS NOT NULL`, [ids]);
  const next = st.n >= s.loyal_min_stays ? 'loyal' : 'standard';
  if (next !== g.crm_status) await db.query('UPDATE guests SET crm_status = $2 WHERE id = $1', [guestId, next]);
}
export async function setStatus(db: PoolClient, actor: Actor, guestId: number, status: string, locked: boolean) {
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2', [guestId, actor.hotelId]);
  if (!g) throw notFound('Client introuvable');
  if (g.kind === 'person' && status === 'company') throw badRequest('Statut « Entreprise » réservé aux fiches entreprise.');
  if (g.kind !== 'person' && status !== 'company') throw badRequest('Une entreprise garde le statut « Entreprise ».');
  await db.query('UPDATE guests SET crm_status = $2, status_locked = $3, updated_at = now() WHERE id = $1', [guestId, status, locked]);
  if (!locked) await refreshStatus(db, guestId);
  await audit(db, actor, 'crm_status', 'guest', guestId, { status: g.crm_status }, { status, locked });
}
export async function loyaltyBalance(db: Db, guestId: number) {
  const ids = await idsOf(db, guestId);
  const r = await one<any>(db, `SELECT COALESCE(sum(points),0)::int AS balance,
      COALESCE(sum(points) FILTER (WHERE kind IN ('earn','bonus') AND created_at > now() - interval '12 months'),0)::int AS qualifying,
      COALESCE(sum(points) FILTER (WHERE kind IN ('earn','bonus')),0)::int AS earned, COALESCE(-sum(points) FILTER (WHERE kind = 'redeem'),0)::int AS redeemed,
      COALESCE(-sum(points) FILTER (WHERE kind = 'expire'),0)::int AS expired,
      (SELECT min(expires_at) FROM loyalty_transactions WHERE guest_id = ANY($1::int[]) AND remaining > 0 AND expires_at IS NOT NULL) AS next_expiry,
      (SELECT COALESCE(sum(remaining),0) FROM loyalty_transactions WHERE guest_id = ANY($1::int[]) AND remaining > 0 AND expires_at <= CURRENT_DATE + 30)::int AS expiring_soon
     FROM loyalty_transactions WHERE guest_id = ANY($1::int[])`, [ids]);
  return r;
}
export async function refreshTier(db: Db, guestId: number) {
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1', [guestId]);
  if (!g?.loyalty_number) return null;
  const b = await loyaltyBalance(db, guestId);
  const t = await one<any>(db, `SELECT * FROM loyalty_tiers WHERE hotel_id = $1 AND active AND min_points <= $2 ORDER BY min_points DESC LIMIT 1`, [g.hotel_id, b.qualifying]);
  if ((t?.id ?? null) !== g.loyalty_tier_id) await db.query('UPDATE guests SET loyalty_tier_id = $2 WHERE id = $1', [guestId, t?.id ?? null]);
  return t;
}
async function credit(db: PoolClient, actor: Actor, guestId: number, kind: 'earn' | 'bonus' | 'adjust', points: number, desc: string, extra: { stay_id?: number | null; rs_order_id?: number | null; reservation_id?: number | null; basis?: number | null } = {}) {
  const s = await crmSettings(db, actor.hotelId);
  const exp = s.loyalty.expiry_months ? (() => { const d = new Date(`${today()}T00:00:00Z`); d.setUTCMonth(d.getUTCMonth() + s.loyalty.expiry_months); return d.toISOString().slice(0, 10); })() : null;
  return one<any>(db, `INSERT INTO loyalty_transactions (hotel_id, guest_id, kind, points, remaining, basis_amount, stay_id, rs_order_id, reservation_id, description, expires_at, created_by) VALUES ($1,$2,$3,$4,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [actor.hotelId, guestId, kind, points, extra.basis ?? null, extra.stay_id ?? null, extra.rs_order_id ?? null, extra.reservation_id ?? null, desc, exp, actor.userId]);
}
/** Débit FIFO sur les crédits les plus anciens encore valides. */
async function debit(db: PoolClient, actor: Actor, guestId: number, kind: 'redeem' | 'adjust' | 'expire', points: number, desc: string, extra: { reservation_id?: number | null; redemption_id?: number | null } = {}) {
  const ids = await idsOf(db, guestId);
  let left = points;
  for (const c of await q<any>(db, `SELECT id, remaining FROM loyalty_transactions WHERE guest_id = ANY($1::int[]) AND remaining > 0 AND (expires_at IS NULL OR expires_at >= CURRENT_DATE) ORDER BY expires_at NULLS LAST, id FOR UPDATE`, [ids])) {
    if (!left) break;
    const take = Math.min(left, c.remaining);
    await db.query('UPDATE loyalty_transactions SET remaining = remaining - $2 WHERE id = $1', [c.id, take]);
    left -= take;
  }
  if (left > 0) throw conflict('Solde de points insuffisant.');
  return one<any>(db, `INSERT INTO loyalty_transactions (hotel_id, guest_id, kind, points, reservation_id, redemption_id, description, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [actor.hotelId, guestId, kind, -points, extra.reservation_id ?? null, extra.redemption_id ?? null, desc, actor.userId]);
}
export async function enroll(db: PoolClient, actor: Actor, guestId: number) {
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [guestId, actor.hotelId]);
  if (!g) throw notFound('Client introuvable');
  if (g.kind !== 'person') throw badRequest('Le programme de fidélité concerne les clients particuliers.');
  if (g.anonymized_at || g.merged_into_id) throw conflict('Fiche inactive.');
  if (g.loyalty_number) throw conflict('Client déjà membre.');
  const s = await crmSettings(db, actor.hotelId);
  if (!s.loyalty.enabled) throw conflict('Programme de fidélité désactivé.');
  const n = await nextNumber(db, 'loyalty');
  const num = `FID${String(n).padStart(6, '0')}`;
  await db.query('UPDATE guests SET loyalty_number = $2, loyalty_joined_at = now() WHERE id = $1', [guestId, num]);
  if (s.loyalty.enrollment_bonus > 0) await credit(db, actor, guestId, 'bonus', s.loyalty.enrollment_bonus, 'Bonus d\'adhésion');
  await refreshTier(db, guestId);
  await audit(db, actor, 'loyalty_enroll', 'guest', guestId, null, { number: num });
  return num;
}
/** Points du séjour au départ : hébergement + prestations de la chambre (HT), une seule fois par séjour. */
export async function earnForStay(db: PoolClient, actor: Actor, rrId: number) {
  const s = await crmSettings(db, actor.hotelId);
  if (!s.loyalty.enabled) return null;
  const x = await one<any>(db, `SELECT rr.*, st.id AS stay_id, COALESCE(rr.guest_id, r.guest_id) AS gid, r.code FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id
      JOIN stays st ON st.reservation_room_id = rr.id WHERE rr.id = $1`, [rrId]);
  if (!x) return null;
  const g = await one<any>(db, 'SELECT g.*, t.earn_multiplier FROM guests g LEFT JOIN loyalty_tiers t ON t.id = g.loyalty_tier_id WHERE g.id = $1', [x.gid]);
  if (!g?.loyalty_number || g.kind !== 'person') return null;
  if (await one(db, `SELECT 1 FROM loyalty_transactions WHERE stay_id = $1 AND kind = 'earn'`, [x.stay_id])) return null;
  const nights = Math.round((Date.parse(String(x.check_out).slice(0, 10)) - Date.parse(String(x.check_in).slice(0, 10))) / 86400000);
  if (nights < s.loyalty.min_nights) return null;
  const ch = await one<any>(db, `SELECT COALESCE(sum(total),0) AS t FROM charges WHERE reservation_room_id = $1 AND NOT void`, [rrId]);
  const basis = n2(Number(x.rate) * nights + Number(ch.t));
  const pts = Math.floor((basis / s.loyalty.amount_per_point) * Number(g.earn_multiplier ?? 1));
  if (pts <= 0) return null;
  const tx = await credit(db, actor, g.id, 'earn', pts, `Séjour ${x.code} (${nights} nuit${nights > 1 ? 's' : ''})`, { stay_id: x.stay_id, reservation_id: x.reservation_id, basis });
  await refreshTier(db, g.id);
  await audit(db, actor, 'loyalty_earn', 'guest', g.id, null, { points: pts, stay_id: x.stay_id, basis });
  return tx;
}
/** Points d'une commande restaurant réglée directement (pas portée sur la chambre : déjà comptée au séjour). */
export async function earnForOrder(db: PoolClient, actor: Actor, orderId: number) {
  const s = await crmSettings(db, actor.hotelId);
  if (!s.loyalty.enabled || !s.loyalty.restaurant) return null;
  const o = await one<any>(db, 'SELECT * FROM rs_orders WHERE id = $1', [orderId]);
  if (!o?.guest_id || !['paid', 'invoice'].includes(o.settlement)) return null;
  const g = await one<any>(db, 'SELECT g.*, t.earn_multiplier FROM guests g LEFT JOIN loyalty_tiers t ON t.id = g.loyalty_tier_id WHERE g.id = $1', [o.guest_id]);
  if (!g?.loyalty_number) return null;
  if (await one(db, `SELECT 1 FROM loyalty_transactions WHERE rs_order_id = $1 AND kind = 'earn'`, [orderId])) return null;
  const basis = n2(Number(o.subtotal) - Number(o.discount_total ?? 0));
  const pts = Math.floor((basis / s.loyalty.amount_per_point) * Number(g.earn_multiplier ?? 1));
  if (pts <= 0) return null;
  const tx = await credit(db, actor, g.id, 'earn', pts, `Restaurant ${o.number}`, { rs_order_id: orderId, basis });
  await refreshTier(db, g.id);
  return tx;
}
export async function adjustPoints(db: PoolClient, actor: Actor, guestId: number, points: number, reason: string) {
  if (!reason?.trim() || reason.trim().length < 5) throw badRequest('Motif obligatoire.');
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2', [guestId, actor.hotelId]);
  if (!g?.loyalty_number) throw conflict('Client non membre du programme.');
  const r = points > 0 ? await credit(db, actor, guestId, 'adjust', points, `Ajustement : ${reason.trim()}`) : await debit(db, actor, guestId, 'adjust', -points, `Ajustement : ${reason.trim()}`);
  await refreshTier(db, guestId);
  await audit(db, actor, 'loyalty_adjust', 'guest', guestId, null, { points, reason });
  return r;
}
export async function expirePoints(db: PoolClient, actor: Actor) {
  let n = 0;
  for (const c of await q<any>(db, `SELECT * FROM loyalty_transactions WHERE hotel_id = $1 AND remaining > 0 AND expires_at < CURRENT_DATE FOR UPDATE`, [actor.hotelId])) {
    await db.query('UPDATE loyalty_transactions SET remaining = 0 WHERE id = $1', [c.id]);
    await db.query(`INSERT INTO loyalty_transactions (hotel_id, guest_id, kind, points, description, created_by) VALUES ($1,$2,'expire',$3,$4,$5)`,
      [actor.hotelId, c.guest_id, -c.remaining, `Points expirés (crédit du ${new Date(c.created_at).toLocaleDateString('fr-FR', { timeZone: TZ })})`, actor.userId]);
    await refreshTier(db, c.guest_id);
    n++;
  }
  return { expired: n };
}
/** Applique une remise à la réservation (pas de cumul avec une remise d'une autre origine). */
async function reservationDiscount(db: PoolClient, resId: number, type: 'amount' | 'percent', value: number, source: string) {
  const r = await one<any>(db, 'SELECT * FROM reservations WHERE id = $1 FOR UPDATE', [resId]);
  if (['cancelled', 'no_show', 'checked_out'].includes(r.status)) throw conflict('Réservation clôturée.');
  const cur = Number(r.discount_value ?? 0);
  if (cur > 0 && (r.discount_type !== type || (r.discount_source ?? 'manual') !== source || type === 'percent')) throw conflict('Une remise est déjà appliquée à cette réservation : non cumulable.');
  const next = type === 'amount' ? n2(cur + value) : value;
  await db.query(`UPDATE reservations SET discount_type = $2, discount_value = $3, discount_source = $4, updated_at = now() WHERE id = $1`, [resId, type, next, source]);
  const { applyDiscount, refreshReservation } = await import('./reservations.js');
  await applyDiscount(db, resId);
  await refreshReservation(db, resId);
}
export async function redeem(db: PoolClient, actor: Actor, guestId: number, rewardId: number, reservationId?: number | null) {
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [guestId, actor.hotelId]);
  if (!g?.loyalty_number) throw conflict('Client non membre du programme.');
  const rw = await one<any>(db, 'SELECT r.*, t.min_points AS tier_min, t.name AS tier_name FROM loyalty_rewards r LEFT JOIN loyalty_tiers t ON t.id = r.min_tier_id WHERE r.id = $1 AND r.hotel_id = $2', [rewardId, actor.hotelId]);
  if (!rw || !rw.active) throw notFound('Récompense indisponible');
  if (rw.min_tier_id) {
    const cur = await one<any>(db, 'SELECT min_points FROM loyalty_tiers WHERE id = $1', [g.loyalty_tier_id]);
    if (!cur || cur.min_points < rw.tier_min) throw forbidden(`Récompense réservée au niveau ${rw.tier_name}.`);
  }
  const bal = await loyaltyBalance(db, guestId);
  if (bal.balance < rw.points_cost) throw conflict(`Solde insuffisant : ${bal.balance} point(s), ${rw.points_cost} nécessaires.`);
  if (['discount_amount', 'discount_percent'].includes(rw.kind) && !reservationId) throw badRequest('Choisissez la réservation sur laquelle appliquer la remise.');
  if (reservationId) {
    const ids = await idsOf(db, guestId);
    const r = await one<any>(db, `SELECT * FROM reservations WHERE id = $1 AND hotel_id = $2 AND (guest_id = ANY($3::int[]) OR EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.reservation_id = reservations.id AND rr.guest_id = ANY($3::int[])))`, [reservationId, actor.hotelId, ids]);
    if (!r) throw badRequest('Réservation inconnue pour ce client.');
  }
  const n = await nextNumber(db, `rw-${yr()}`);
  const red = await one<any>(db, `INSERT INTO loyalty_redemptions (hotel_id, number, guest_id, reward_id, points, reservation_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [actor.hotelId, `RW${yr()}-${pad(n)}`, guestId, rewardId, rw.points_cost, reservationId ?? null, actor.userId]);
  await debit(db, actor, guestId, 'redeem', rw.points_cost, `Récompense : ${rw.name}`, { reservation_id: reservationId ?? null, redemption_id: red.id });
  if (reservationId && ['discount_amount', 'discount_percent'].includes(rw.kind)) {
    await reservationDiscount(db, reservationId, rw.kind === 'discount_amount' ? 'amount' : 'percent', Number(rw.value), 'loyalty');
    await db.query(`UPDATE loyalty_redemptions SET status = 'used', used_at = now(), applied_amount = $2 WHERE id = $1`, [red.id, rw.value]);
  }
  await refreshTier(db, guestId);
  await audit(db, actor, 'loyalty_redeem', 'guest', guestId, null, { reward: rw.name, points: rw.points_cost, reservation_id: reservationId ?? null, number: red.number });
  return one<any>(db, 'SELECT * FROM loyalty_redemptions WHERE id = $1', [red.id]);
}
export async function useRedemption(db: PoolClient, actor: Actor, id: number) {
  const r = await one<any>(db, 'SELECT * FROM loyalty_redemptions WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!r) throw notFound('Récompense introuvable');
  if (r.status !== 'issued') throw conflict('Récompense déjà utilisée ou annulée.');
  await db.query(`UPDATE loyalty_redemptions SET status = 'used', used_at = now() WHERE id = $1`, [id]);
  await audit(db, actor, 'loyalty_reward_used', 'guest', r.guest_id, null, { number: r.number });
}
export async function cancelRedemption(db: PoolClient, actor: Actor, id: number, reason: string) {
  const r = await one<any>(db, 'SELECT * FROM loyalty_redemptions WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!r) throw notFound('Récompense introuvable');
  if (r.status !== 'issued') throw conflict('Seule une récompense non utilisée peut être annulée.');
  if (!reason?.trim()) throw badRequest('Motif obligatoire.');
  await db.query(`UPDATE loyalty_redemptions SET status = 'cancelled', notes = $2 WHERE id = $1`, [id, reason.trim()]);
  await credit(db, actor, r.guest_id, 'adjust', r.points, `Annulation de la récompense ${r.number}`);
  await audit(db, actor, 'loyalty_reward_cancelled', 'guest', r.guest_id, null, { number: r.number, reason });
}
export async function applyMemberDiscount(db: PoolClient, actor: Actor, reservationId: number) {
  const r = await one<any>(db, 'SELECT * FROM reservations WHERE id = $1 AND hotel_id = $2', [reservationId, actor.hotelId]);
  if (!r) throw notFound('Réservation introuvable');
  const g = await one<any>(db, 'SELECT g.*, t.discount_percent, t.name AS tier FROM guests g LEFT JOIN loyalty_tiers t ON t.id = g.loyalty_tier_id WHERE g.id = $1', [r.guest_id]);
  if (!g?.loyalty_number || !Number(g.discount_percent)) throw conflict('Aucune réduction membre pour ce client.');
  await reservationDiscount(db, reservationId, 'percent', Number(g.discount_percent), 'member');
  await audit(db, actor, 'member_discount', 'reservation', reservationId, null, { tier: g.tier, percent: g.discount_percent });
  return { percent: Number(g.discount_percent), tier: g.tier };
}

// =====================================================================================================
// Réclamations
// =====================================================================================================
export async function createComplaint(db: PoolClient, actor: Actor, b: {
  guest_id: number; reservation_id?: number | null; category: string; priority?: string; channel?: string; kind?: string; title: string; description?: string | null; assigned_to?: number | null; note_id?: number | null;
}) {
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2', [b.guest_id, actor.hotelId]);
  if (!g) throw notFound('Client introuvable');
  let stayId: number | null = null;
  if (b.reservation_id) {
    const r = await one<any>(db, 'SELECT * FROM reservations WHERE id = $1 AND hotel_id = $2', [b.reservation_id, actor.hotelId]);
    if (!r) throw badRequest('Réservation inconnue.');
    stayId = (await one<any>(db, `SELECT s.id FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id WHERE rr.reservation_id = $1 ORDER BY s.id DESC LIMIT 1`, [b.reservation_id]))?.id ?? null;
  }
  if (b.assigned_to && !(await one(db, 'SELECT 1 FROM users WHERE id = $1 AND hotel_id = $2 AND active', [b.assigned_to, actor.hotelId]))) throw badRequest('Responsable inconnu.');
  const s = await crmSettings(db, actor.hotelId);
  const prio = b.priority ?? 'normal';
  const n = await nextNumber(db, `rc-${yr()}`);
  const c = await one<any>(db, `INSERT INTO crm_complaints (hotel_id, number, guest_id, reservation_id, stay_id, note_id, category, priority, channel, kind, title, description, assigned_to, due_at, created_by, status)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13, now() + make_interval(hours => $14), $15, $16) RETURNING *`,
  [actor.hotelId, `RC${yr()}-${pad(n)}`, b.guest_id, b.reservation_id ?? null, stayId, b.note_id ?? null, b.category, prio, b.channel ?? 'in_person', b.kind ?? 'complaint', b.title.trim(), b.description?.trim() || null,
    b.assigned_to ?? null, s.complaint_sla_hours?.[prio] ?? 48, actor.userId, (b.kind ?? 'complaint') === 'compliment' ? 'closed' : b.assigned_to ? 'in_progress' : 'new']);
  await audit(db, actor, 'complaint', 'guest', b.guest_id, null, { number: c.number, category: b.category, priority: prio });
  return c;
}
export async function complaintAction(db: PoolClient, actor: Actor, id: number, b: { action: 'assign' | 'comment' | 'response' | 'corrective' | 'resolve' | 'close' | 'reopen'; text?: string | null; assigned_to?: number | null; satisfaction?: number | null; compensation?: string | null }) {
  const c = await one<any>(db, 'SELECT * FROM crm_complaints WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!c) throw notFound('Réclamation introuvable');
  const log = (kind: string, text: string) => db.query('INSERT INTO crm_complaint_updates (complaint_id, kind, text, created_by) VALUES ($1,$2,$3,$4)', [id, kind, text, actor.userId]);
  if (b.action !== 'reopen' && c.status === 'closed') throw conflict('Réclamation clôturée.');
  if (b.action === 'assign') {
    if (!b.assigned_to) throw badRequest('Responsable obligatoire.');
    const u = await one<any>(db, 'SELECT full_name FROM users WHERE id = $1 AND hotel_id = $2 AND active', [b.assigned_to, actor.hotelId]);
    if (!u) throw badRequest('Responsable inconnu.');
    await db.query(`UPDATE crm_complaints SET assigned_to = $2, status = CASE WHEN status = 'new' THEN 'in_progress' ELSE status END WHERE id = $1`, [id, b.assigned_to]);
    await log('status', `Affectée à ${u.full_name}`);
  } else if (['comment', 'response', 'corrective'].includes(b.action)) {
    if (!b.text?.trim()) throw badRequest('Texte obligatoire.');
    await log(b.action === 'corrective' ? 'action' : b.action, b.text.trim());
    if (c.status === 'new') await db.query(`UPDATE crm_complaints SET status = 'in_progress' WHERE id = $1`, [id]);
  } else if (b.action === 'resolve') {
    if (!b.text?.trim()) throw badRequest('Décrivez la résolution.');
    if (c.status === 'resolved') throw conflict('Déjà résolue.');
    await db.query(`UPDATE crm_complaints SET status = 'resolved', resolution = $2, compensation = COALESCE($3, compensation), resolved_at = now(), resolved_by = $4 WHERE id = $1`, [id, b.text.trim(), b.compensation ?? null, actor.userId]);
    await log('status', `Résolue : ${b.text.trim()}`);
    if (c.note_id) await db.query(`UPDATE guest_notes SET status = 'resolved', resolution = $2, resolved_by = $3, resolved_at = now() WHERE id = $1 AND status = 'open'`, [c.note_id, b.text.trim(), actor.userId]);
  } else if (b.action === 'close') {
    if (c.status !== 'resolved') throw conflict('Résolvez la réclamation avant de la clôturer.');
    if (b.satisfaction != null && (b.satisfaction < 1 || b.satisfaction > 5)) throw badRequest('Satisfaction de 1 à 5.');
    await db.query(`UPDATE crm_complaints SET status = 'closed', closed_at = now(), satisfaction = COALESCE($2, satisfaction) WHERE id = $1`, [id, b.satisfaction ?? null]);
    await log('status', `Clôturée${b.satisfaction ? ` — satisfaction du client ${b.satisfaction}/5` : ''}`);
  } else {
    if (!['resolved', 'closed'].includes(c.status)) throw conflict('Réclamation encore ouverte.');
    if (!b.text?.trim()) throw badRequest('Motif de réouverture obligatoire.');
    await db.query(`UPDATE crm_complaints SET status = 'in_progress', closed_at = NULL, resolved_at = NULL WHERE id = $1`, [id]);
    await log('status', `Rouverte : ${b.text.trim()}`);
  }
  await audit(db, actor, `complaint_${b.action}`, 'guest', c.guest_id, { status: c.status }, { number: c.number, action: b.action });
}

// =====================================================================================================
// Communication
// =====================================================================================================
export function render(text: string, vars: Record<string, any>) {
  return text.replace(/\{\{\s*([a-z_]+)\s*\}\}/g, (_, k) => (vars[k] ?? '') + '');
}
export async function varsFor(db: Db, hotelId: number, g: any, reservationId?: number | null, extra: Record<string, any> = {}) {
  const s = await crmSettings(db, hotelId);
  const hotel = await one<any>(db, 'SELECT name, phone, email FROM hotels WHERE id = $1', [hotelId]);
  const r = reservationId ? await one<any>(db, 'SELECT code, check_in, check_out FROM reservations WHERE id = $1', [reservationId]) : null;
  const bal = g.loyalty_number ? await loyaltyBalance(db, g.id) : null;
  const tier = g.loyalty_tier_id ? (await one<any>(db, 'SELECT name FROM loyalty_tiers WHERE id = $1', [g.loyalty_tier_id]))?.name : '';
  const base = s.public_url?.replace(/\/$/, '') ?? '';
  return {
    first_name: g.first_name ?? '', last_name: g.last_name ?? '', name: guestDisplayName(g), hotel: hotel?.name ?? '', hotel_phone: hotel?.phone ?? '', hotel_email: hotel?.email ?? '',
    code: r?.code ?? '', check_in: r ? String(r.check_in).slice(0, 10) : '', check_out: r ? String(r.check_out).slice(0, 10) : '', points: bal?.balance ?? 0, tier: tier ?? '', loyalty_number: g.loyalty_number ?? '',
    unsubscribe_url: base ? `${base}/p/unsubscribe/${g.unsubscribe_token}` : 'Répondez « STOP » à ce message pour ne plus recevoir nos offres.', ...extra,
  };
}
/** Envoi d'un message : le consentement est exigé pour toute communication commerciale ; rien n'est envoyé à une fiche anonymisée. */
export async function queueMessage(db: PoolClient, actor: Actor, b: { guest_id: number; purpose: 'transactional' | 'marketing'; kind: string; subject: string; body: string; reservation_id?: number | null; campaign_id?: number | null; scheduled_for?: string | null }) {
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2', [b.guest_id, actor.hotelId]);
  if (!g) throw notFound('Client introuvable');
  if (g.anonymized_at || g.merged_into_id) return { skipped: 'contact' as const };
  if (!g.email) return { skipped: 'contact' as const };
  if (b.purpose === 'marketing' && (!g.consent_email || g.unsubscribed_at)) return { skipped: 'consent' as const };
  const n = await one<any>(db, `INSERT INTO notifications (hotel_id, reservation_id, kind, channel, recipient, subject, body, created_by, language, guest_id, campaign_id, scheduled_for)
      VALUES ($1,$2,$3,'email',$4,$5,$6,$7,$8,$9,$10,$11) ON CONFLICT DO NOTHING RETURNING id`,
  [actor.hotelId, b.reservation_id ?? null, b.kind, g.email, b.subject.slice(0, 200), b.body, actor.userId, g.language ?? 'fr', g.id, b.campaign_id ?? null, b.scheduled_for ?? null]);
  if (!n) return { skipped: 'duplicate' as const };
  await db.query(`INSERT INTO crm_interactions (hotel_id, guest_id, channel, direction, subject, body, reservation_id, notification_id, campaign_id, created_by) VALUES ($1,$2,'email','out',$3,$4,$5,$6,$7,$8)`,
    [actor.hotelId, g.id, b.subject.slice(0, 200), b.body, b.reservation_id ?? null, n.id, b.campaign_id ?? null, actor.userId]);
  return { notification_id: n.id as number };
}
export async function templateFor(db: Db, hotelId: number, code: string, lang: string) {
  return (await one<any>(db, 'SELECT * FROM crm_templates WHERE hotel_id = $1 AND code = $2 AND language = $3 AND active', [hotelId, code, lang]))
    ?? one<any>(db, `SELECT * FROM crm_templates WHERE hotel_id = $1 AND code = $2 AND active ORDER BY language = 'fr' DESC LIMIT 1`, [hotelId, code]);
}
/** Automatisations : remerciement + enquête après le départ, message avant l'arrivée, anniversaire (consentement requis). Idempotent. */
export async function runAutomations(db: PoolClient, actor: Actor) {
  const s = await crmSettings(db, actor.hotelId);
  const out = { thanks: 0, pre_arrival: 0, birthday: 0 };
  const send = async (g: any, code: string, kind: string, purpose: 'transactional' | 'marketing', resId: number | null, extra: Record<string, any> = {}) => {
    const tpl = await templateFor(db, actor.hotelId, code, g.language ?? 'fr');
    if (!tpl) return false;
    const v = await varsFor(db, actor.hotelId, g, resId, extra);
    const r = await queueMessage(db, actor, { guest_id: g.id, purpose, kind, subject: render(tpl.subject, v), body: render(tpl.body, v), reservation_id: resId });
    return 'notification_id' in r;
  };
  if (s.automations.thanks) {
    for (const r of await q<any>(db, `SELECT r.id AS res_id, g.* FROM reservations r JOIN guests g ON g.id = r.guest_id WHERE r.hotel_id = $1 AND r.status = 'checked_out' AND r.check_out >= CURRENT_DATE - 3
        AND g.kind = 'person' AND NOT EXISTS (SELECT 1 FROM notifications n WHERE n.reservation_id = r.id AND n.kind = 'thanks')`, [actor.hotelId])) {
      let survey = '';
      if (s.automations.post_stay_survey) {
        const sv = await one<any>(db, `SELECT * FROM crm_surveys WHERE hotel_id = $1 AND active AND trigger = 'after_stay' ORDER BY id LIMIT 1`, [actor.hotelId]);
        if (sv) survey = (await ensureSurvey(db, actor, sv.id, r.res_id, r.id)).url;
      }
      if (await send(r, 'thanks', 'thanks', 'transactional', r.res_id, { survey_url: survey })) out.thanks++;
    }
  }
  if (s.automations.pre_arrival_days > 0) {
    for (const r of await q<any>(db, `SELECT r.id AS res_id, g.* FROM reservations r JOIN guests g ON g.id = r.guest_id WHERE r.hotel_id = $1 AND r.status = 'confirmed' AND r.check_in = CURRENT_DATE + $2::int
        AND g.kind = 'person' AND NOT EXISTS (SELECT 1 FROM notifications n WHERE n.reservation_id = r.id AND n.kind = 'pre_arrival')`, [actor.hotelId, s.automations.pre_arrival_days])) {
      if (await send(r, 'pre_arrival', 'pre_arrival', 'transactional', r.res_id)) out.pre_arrival++;
    }
  }
  if (s.automations.birthday) {
    for (const g of await q<any>(db, `SELECT * FROM guests WHERE hotel_id = $1 AND kind = 'person' AND merged_into_id IS NULL AND anonymized_at IS NULL AND birth_date IS NOT NULL
        AND to_char(birth_date, 'MM-DD') = to_char(CURRENT_DATE, 'MM-DD') AND consent_email AND unsubscribed_at IS NULL`, [actor.hotelId])) {
      if (await send(g, 'birthday', 'birthday', 'marketing', null)) out.birthday++;
    }
  }
  return out;
}

// =====================================================================================================
// Enquêtes
// =====================================================================================================
export async function ensureSurvey(db: PoolClient, actor: Actor, surveyId: number, reservationId: number | null, guestId: number | null, complaintId: number | null = null) {
  const ex = reservationId ? await one<any>(db, 'SELECT * FROM crm_survey_responses WHERE survey_id = $1 AND reservation_id = $2', [surveyId, reservationId]) : null;
  const s = await crmSettings(db, actor.hotelId);
  const base = s.public_url?.replace(/\/$/, '') ?? '';
  if (ex) return { ...ex, url: base ? `${base}/p/survey/${ex.token}` : '' };
  const token = randomBytes(18).toString('base64url');
  const r = await one<any>(db, `INSERT INTO crm_survey_responses (hotel_id, survey_id, guest_id, reservation_id, complaint_id, token, sent_at) VALUES ($1,$2,$3,$4,$5,$6,now()) RETURNING *`,
    [actor.hotelId, surveyId, guestId, reservationId, complaintId, token]);
  return { ...r, url: base ? `${base}/p/survey/${token}` : '' };
}
export async function submitSurvey(db: Db, token: string, answers: Record<string, any>, comment: string | null, enteredBy: number | null) {
  const r = await one<any>(db, 'SELECT r.*, s.questions FROM crm_survey_responses r JOIN crm_surveys s ON s.id = r.survey_id WHERE r.token = $1', [token]);
  if (!r) throw notFound('Questionnaire introuvable');
  if (r.completed_at) throw conflict('Questionnaire déjà rempli : merci !');
  const qs = r.questions as any[];
  const clean: Record<string, any> = {};
  const ratings: number[] = [];
  let nps: number | null = null;
  for (const qq of qs) {
    const v = answers?.[qq.id];
    if (v === undefined || v === null || v === '') continue;
    if (qq.type === 'rating') { const n = Number(v); if (!(n >= 1 && n <= 5)) throw badRequest(`Note invalide : ${qq.label}`); clean[qq.id] = n; ratings.push(n); }
    else if (qq.type === 'nps') { const n = Number(v); if (!(n >= 0 && n <= 10)) throw badRequest(`Note invalide : ${qq.label}`); clean[qq.id] = n; nps = n; }
    else if (qq.type === 'yesno') clean[qq.id] = !!v && v !== 'false';
    else clean[qq.id] = String(v).slice(0, 2000);
  }
  if (!Object.keys(clean).length) throw badRequest('Répondez au moins à une question.');
  const score = ratings.length ? Math.round((ratings.reduce((a, b) => a + b, 0) / ratings.length) * 100) / 100 : null;
  await db.query('UPDATE crm_survey_responses SET answers = $2, score = $3, nps = $4, comment = $5, completed_at = now(), entered_by = $6 WHERE id = $1', [r.id, JSON.stringify(clean), score, nps, comment?.slice(0, 2000) ?? null, enteredBy]);
  // mauvaise note : une réclamation est ouverte automatiquement pour suivi
  if (r.guest_id && ((score !== null && score <= 2) || (nps !== null && nps <= 4))) {
    const g = await one<any>(db, 'SELECT hotel_id FROM guests WHERE id = $1', [r.guest_id]);
    const n = await nextNumber(db, `rc-${yr()}`);
    await db.query(`INSERT INTO crm_complaints (hotel_id, number, guest_id, reservation_id, category, priority, channel, title, description, due_at) VALUES ($1,$2,$3,$4,'other','high','survey',$5,$6, now() + interval '24 hours')`,
      [g.hotel_id, `RC${yr()}-${pad(n)}`, r.guest_id, r.reservation_id, `Enquête de satisfaction défavorable (${score ?? '—'}/5${nps !== null ? `, recommandation ${nps}/10` : ''})`, comment ?? null]);
  }
  return { score, nps };
}

// =====================================================================================================
// Segments et campagnes
// =====================================================================================================
export interface Criteria {
  kinds?: string[]; statuses?: string[]; min_stays?: number; max_stays?: number; min_spent?: number; max_spent?: number; countries?: string[]; languages?: string[];
  tiers?: number[]; members_only?: boolean; inactive_days?: number; active_days?: number; preference?: string; has_email?: boolean; marketing_consent?: boolean; birthday_month?: number;
}
export async function segmentMembers(db: Db, hotelId: number, c: Criteria, limit = 5000) {
  const P: any[] = [hotelId];
  const w: string[] = ['g.hotel_id = $1', 'g.merged_into_id IS NULL', 'g.anonymized_at IS NULL'];
  const p = (v: any) => { P.push(v); return `$${P.length}`; };
  if (c.kinds?.length) w.push(`g.kind = ANY(${p(c.kinds)}::text[])`);
  if (c.statuses?.length) w.push(`g.crm_status = ANY(${p(c.statuses)}::text[])`);
  if (c.countries?.length) w.push(`upper(coalesce(g.country, g.nationality, '')) = ANY(${p(c.countries.map((x) => x.toUpperCase()))}::text[])`);
  if (c.languages?.length) w.push(`g.language = ANY(${p(c.languages)}::text[])`);
  if (c.tiers?.length) w.push(`g.loyalty_tier_id = ANY(${p(c.tiers)}::int[])`);
  if (c.members_only) w.push('g.loyalty_number IS NOT NULL');
  if (c.has_email) w.push(`coalesce(g.email, '') <> ''`);
  if (c.marketing_consent) w.push('g.consent_email AND g.unsubscribed_at IS NULL');
  if (c.birthday_month) w.push(`extract(month FROM g.birth_date) = ${p(c.birthday_month)}`);
  if (c.preference?.trim()) w.push(`(EXISTS (SELECT 1 FROM guest_preferences gp WHERE gp.guest_id = g.id AND gp.value ILIKE ${p(`%${c.preference.trim()}%`)}) OR g.preferences ILIKE $${P.length})`);
  const h: string[] = [];
  if (c.min_stays != null) h.push(`x.stays >= ${p(c.min_stays)}`);
  if (c.max_stays != null) h.push(`x.stays <= ${p(c.max_stays)}`);
  if (c.min_spent != null) h.push(`x.spent >= ${p(c.min_spent)}`);
  if (c.max_spent != null) h.push(`x.spent <= ${p(c.max_spent)}`);
  if (c.inactive_days != null) h.push(`(x.last_stay IS NULL OR x.last_stay < now() - make_interval(days => ${p(c.inactive_days)}))`);
  if (c.active_days != null) h.push(`x.last_stay >= now() - make_interval(days => ${p(c.active_days)})`);
  return q<any>(db, `SELECT * FROM (SELECT g.id, g.code, g.kind, g.last_name, g.first_name, g.company_name, g.crm_status, g.country, g.nationality, g.language, g.loyalty_tier_id, g.consent_email, g.unsubscribed_at, (coalesce(g.email,'') <> '') AS has_email,
        (SELECT count(*) FROM stays s WHERE s.guest_id = g.id AND s.checked_out_at IS NOT NULL)::int AS stays, (SELECT max(s.checked_in_at) FROM stays s WHERE s.guest_id = g.id) AS last_stay,
        COALESCE((SELECT sum(CASE WHEN py.void THEN 0 ELSE py.amount END) FROM payments py WHERE py.guest_id = g.id), 0) AS spent
       FROM guests g WHERE ${w.join(' AND ')}) x ${h.length ? `WHERE ${h.join(' AND ')}` : ''} ORDER BY x.spent DESC LIMIT ${limit}`, P);
}
export async function sendCampaign(db: PoolClient, actor: Actor, id: number) {
  const c = await one<any>(db, 'SELECT * FROM crm_campaigns WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!c) throw notFound('Campagne introuvable');
  if (!['draft', 'scheduled'].includes(c.status)) throw conflict('Campagne déjà envoyée ou annulée.');
  const seg = await one<any>(db, 'SELECT * FROM crm_segments WHERE id = $1', [c.segment_id]);
  const tpl = await one<any>(db, 'SELECT * FROM crm_templates WHERE id = $1', [c.template_id]);
  if (tpl.purpose !== 'marketing') throw badRequest('Une campagne utilise un modèle de type « marketing ».');
  if (!/\{\{\s*unsubscribe_url\s*\}\}/.test(tpl.body)) throw badRequest('Le modèle doit contenir le lien de désabonnement {{unsubscribe_url}}.');
  const members = await segmentMembers(db, actor.hotelId, seg.criteria);
  let queued = 0, skipped = 0;
  for (const m of members) {
    const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1', [m.id]);
    const v = await varsFor(db, actor.hotelId, g, null);
    const r = await queueMessage(db, actor, { guest_id: g.id, purpose: 'marketing', kind: 'campaign', subject: render(tpl.subject, v), body: render(tpl.body, v), campaign_id: id });
    const status = 'notification_id' in r ? 'queued' : r.skipped === 'consent' ? 'skipped_consent' : 'skipped_contact';
    if (status === 'queued') queued++; else skipped++;
    await db.query(`INSERT INTO crm_campaign_recipients (campaign_id, guest_id, status, notification_id) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING`, [id, g.id, status, 'notification_id' in r ? r.notification_id : null]);
  }
  await db.query(`UPDATE crm_campaigns SET status = 'sent', sent_at = now(), recipients = $2, skipped = $3 WHERE id = $1`, [id, queued, skipped]);
  await audit(db, actor, 'campaign_send', 'crm_campaign', id, null, { queued, skipped, segment: seg.name });
  return { queued, skipped };
}
export async function campaignStats(db: Db, id: number) {
  const c = await one<any>(db, 'SELECT * FROM crm_campaigns WHERE id = $1', [id]);
  const st = await one<any>(db, `SELECT count(*) FILTER (WHERE r.status IN ('queued','sent','failed','unsubscribed'))::int AS targeted,
      count(*) FILTER (WHERE n.status = 'sent')::int AS sent, count(*) FILTER (WHERE n.status = 'failed')::int AS failed, count(*) FILTER (WHERE n.status = 'pending')::int AS pending,
      count(*) FILTER (WHERE r.status = 'skipped_consent')::int AS no_consent, count(*) FILTER (WHERE r.status = 'skipped_contact')::int AS no_contact,
      count(*) FILTER (WHERE g.unsubscribed_at >= $2)::int AS unsubscribed
     FROM crm_campaign_recipients r JOIN guests g ON g.id = r.guest_id LEFT JOIN notifications n ON n.id = r.notification_id WHERE r.campaign_id = $1`, [id, c.sent_at ?? '2999-01-01']);
  // réservations créées par les destinataires dans les 30 jours suivant l'envoi
  const conv = c.sent_at ? await one<any>(db, `SELECT count(*)::int AS n FROM reservations r
      WHERE r.guest_id IN (SELECT guest_id FROM crm_campaign_recipients WHERE campaign_id = $1 AND status IN ('queued','sent','unsubscribed')) AND r.created_at BETWEEN $2 AND $2::timestamptz + interval '30 days' AND r.status NOT IN ('cancelled','no_show')`, [id, c.sent_at]) : { n: 0 };
  const revenue = conv.n ? n2((await q<any>(db, `SELECT r.id, ${FIN_SQL} FROM reservations r WHERE r.guest_id IN (SELECT guest_id FROM crm_campaign_recipients WHERE campaign_id = $1 AND status IN ('queued','sent','unsubscribed'))
      AND r.created_at BETWEEN $2 AND $2::timestamptz + interval '30 days' AND r.status NOT IN ('cancelled','no_show')`, [id, c.sent_at])).reduce((a, x) => a + withBalance(x).total, 0)) : 0;
  return { ...st, bookings: conv.n, revenue, conversion: st.targeted ? Math.round((conv.n * 1000) / st.targeted) / 10 : 0 };
}

// =====================================================================================================
// Confidentialité
// =====================================================================================================
export async function exportGuestData(db: Db, hotelId: number, id: number) {
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2', [id, hotelId]);
  if (!g) throw notFound('Client introuvable');
  const ids = await idsOf(db, id);
  const { unsubscribe_token, ...profile } = g;
  void unsubscribe_token;
  return {
    exported_at: new Date().toISOString(), profile,
    preferences: await q(db, 'SELECT category, value, event_date, created_at FROM guest_preferences WHERE guest_id = ANY($1::int[])', [ids]),
    reservations: await q(db, 'SELECT code, check_in, check_out, status, created_at FROM reservations WHERE guest_id = ANY($1::int[]) ORDER BY check_in', [ids]),
    stays: await q(db, `SELECT s.checked_in_at, s.checked_out_at, rm.number AS room FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN rooms rm ON rm.id = rr.room_id WHERE s.guest_id = ANY($1::int[])`, [ids]),
    invoices: await q(db, 'SELECT number, issued_at, total, status FROM invoices WHERE guest_id = ANY($1::int[]) ORDER BY issued_at', [ids]),
    loyalty: await q(db, 'SELECT kind, points, description, created_at FROM loyalty_transactions WHERE guest_id = ANY($1::int[]) ORDER BY id', [ids]),
    complaints: await q(db, 'SELECT number, category, title, status, created_at FROM crm_complaints WHERE guest_id = ANY($1::int[])', [ids]),
    communications: await q(db, 'SELECT channel, direction, subject, created_at FROM crm_interactions WHERE guest_id = ANY($1::int[])', [ids]),
    consents: { email: g.consent_email, sms: g.consent_sms, updated_at: g.consent_updated_at, unsubscribed_at: g.unsubscribed_at, data_processing: g.data_consent_at },
  };
}
/** Effacement : les données personnelles sont anonymisées ; les pièces comptables (factures, paiements) sont conservées sans identité. */
export async function anonymize(db: PoolClient, actor: Actor, id: number, reason: string) {
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!g) throw notFound('Client introuvable');
  if (g.anonymized_at) throw conflict('Fiche déjà anonymisée.');
  if (!reason?.trim()) throw badRequest('Motif obligatoire.');
  const ids = await idsOf(db, id);
  if (await one(db, `SELECT 1 FROM stays WHERE guest_id = ANY($1::int[]) AND checked_out_at IS NULL`, [ids])) throw conflict('Client en séjour : anonymisation impossible avant le départ.');
  if (await one(db, `SELECT 1 FROM reservations WHERE guest_id = ANY($1::int[]) AND status IN ('pending','confirmed','checked_in')`, [ids])) throw conflict('Réservations à venir : annulez-les ou attendez la fin du séjour.');
  const open = await one<any>(db, `SELECT count(*)::int AS n FROM (SELECT r.id, ${FIN_SQL} FROM reservations r WHERE COALESCE(r.payer_guest_id, r.guest_id) = ANY($1::int[])) x WHERE ${BALANCE_EXPR} > 0.004`, [ids]);
  if (open.n) throw conflict('Solde impayé : régularisez avant l\'anonymisation (obligation comptable).');
  for (const gid of ids) {
    await db.query(`UPDATE guests SET last_name = CASE WHEN kind = 'person' THEN 'Client anonymisé' ELSE last_name END, first_name = NULL, company_name = CASE WHEN kind = 'person' THEN NULL ELSE company_name END,
        birth_date = NULL, birth_place = NULL, father_name = NULL, mother_name = NULL, id_doc_type = NULL, id_doc_number = NULL, id_doc_expiry = NULL, id_doc_issued_on = NULL, id_doc_issued_place = NULL,
        profession = NULL, address = NULL, city = NULL, phone = NULL, mobile = NULL, email = NULL, notes = NULL, preferences = NULL, job_title = NULL, consent_email = false, consent_sms = false,
        unsubscribed_at = COALESCE(unsubscribed_at, now()), anonymized_at = now(), status_locked = true, updated_at = now() WHERE id = $1`, [gid]);
    await db.query('DELETE FROM guest_preferences WHERE guest_id = $1', [gid]);
    await db.query(`UPDATE guest_notes SET text = '[supprimé à la demande du client]' WHERE guest_id = $1`, [gid]);
    await db.query(`UPDATE crm_interactions SET body = NULL WHERE guest_id = $1`, [gid]);
  }
  await db.query(`DELETE FROM photos WHERE owner_type = 'guest' AND owner_id = ANY($1::int[])`, [ids]);
  await db.query(`INSERT INTO crm_privacy_requests (hotel_id, guest_id, kind, details, status, outcome, handled_by) VALUES ($1,$2,'erasure',$3,'done','Données personnelles anonymisées ; pièces comptables conservées',$4)`, [actor.hotelId, id, reason.trim(), actor.userId]);
  await audit(db, actor, 'anonymize', 'guest', id, { code: g.code }, { reason });
}

// =====================================================================================================
// Tableau de bord et rapports
// =====================================================================================================
const PERSON = `g.hotel_id = $1 AND g.kind = 'person' AND g.merged_into_id IS NULL AND g.anonymized_at IS NULL`;
export async function crmDashboard(db: Db, hotelId: number) {
  const s = await crmSettings(db, hotelId);
  const t = today(), ms = monthStart(t);
  const k = await one<any>(db, `SELECT count(*)::int AS total, count(*) FILTER (WHERE (g.created_at AT TIME ZONE '${TZ}')::date >= $2)::int AS new_month,
      count(*) FILTER (WHERE g.crm_status = 'loyal')::int AS loyal, count(*) FILTER (WHERE g.crm_status = 'vip')::int AS vip, count(*) FILTER (WHERE g.loyalty_number IS NOT NULL)::int AS members,
      count(*) FILTER (WHERE EXISTS (SELECT 1 FROM stays st WHERE st.guest_id = g.id AND st.checked_in_at > now() - make_interval(days => $3)))::int AS active
     FROM guests g WHERE ${PERSON}`, [hotelId, ms, s.inactive_days]);
  const companies = await one<any>(db, `SELECT count(*)::int AS n FROM guests g WHERE g.hotel_id = $1 AND g.kind <> 'person' AND g.merged_into_id IS NULL`, [hotelId]);
  // fidélisation : part des clients ayant séjourné sur 12 mois qui avaient déjà séjourné auparavant
  const ret = await one<any>(db, `WITH c AS (SELECT DISTINCT s.guest_id FROM stays s JOIN guests g ON g.id = s.guest_id WHERE ${PERSON} AND s.checked_in_at > now() - interval '12 months')
      SELECT count(*)::int AS n, count(*) FILTER (WHERE (SELECT count(*) FROM stays s2 WHERE s2.guest_id = c.guest_id) >= 2)::int AS returning FROM c`, [hotelId]);
  const sat = await one<any>(db, `SELECT round(avg(score), 2) AS score, count(*)::int AS n, round(avg(nps), 1) AS nps,
      (count(*) FILTER (WHERE nps >= 9) - count(*) FILTER (WHERE nps <= 6))::int AS nps_net, count(*) FILTER (WHERE nps IS NOT NULL)::int AS nps_n
     FROM crm_survey_responses WHERE hotel_id = $1 AND completed_at > now() - interval '12 months'`, [hotelId]);
  const cs = await one<any>(db, `SELECT round(avg(satisfaction), 2) AS s FROM crm_complaints WHERE hotel_id = $1 AND satisfaction IS NOT NULL AND created_at > now() - interval '12 months'`, [hotelId]);
  const cp = await one<any>(db, `SELECT count(*) FILTER (WHERE status IN ('new','in_progress') AND kind = 'complaint')::int AS pending, count(*) FILTER (WHERE status IN ('new','in_progress') AND due_at < now())::int AS late,
      count(*) FILTER (WHERE status = 'new')::int AS unassigned FROM crm_complaints WHERE hotel_id = $1`, [hotelId]);
  const birthdays = await q<any>(db, `SELECT g.id, g.code, g.first_name, g.last_name, g.crm_status, to_char(g.birth_date, 'DD/MM') AS day,
      ((date_trunc('year', CURRENT_DATE) + (g.birth_date - date_trunc('year', g.birth_date)))::date + CASE WHEN (date_trunc('year', CURRENT_DATE) + (g.birth_date - date_trunc('year', g.birth_date)))::date < CURRENT_DATE THEN interval '1 year' ELSE interval '0' END)::date AS next
     FROM guests g WHERE ${PERSON} AND g.birth_date IS NOT NULL ORDER BY next LIMIT 400`, [hotelId]);
  const upcoming = birthdays.filter((b) => String(b.next).slice(0, 10) <= addDays(t, 30)).slice(0, 15);
  const inhouse = await q<any>(db, `SELECT g.id, g.code, g.first_name, g.last_name, g.crm_status, rm.number AS room, t.name AS tier,
      (SELECT count(*) FROM guest_preferences p WHERE p.guest_id = g.id)::int AS prefs FROM stays s JOIN guests g ON g.id = s.guest_id JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN rooms rm ON rm.id = rr.room_id
      LEFT JOIN loyalty_tiers t ON t.id = g.loyalty_tier_id WHERE g.hotel_id = $1 AND s.checked_out_at IS NULL AND (g.crm_status IN ('vip','loyal') OR g.loyalty_number IS NOT NULL) ORDER BY g.crm_status = 'vip' DESC, rm.number`, [hotelId]);
  const arrivals = await q<any>(db, `SELECT DISTINCT g.id, g.code, g.first_name, g.last_name, g.crm_status, r.code AS res FROM reservations r JOIN guests g ON g.id = r.guest_id
      WHERE r.hotel_id = $1 AND r.check_in = CURRENT_DATE AND r.status IN ('pending','confirmed') AND g.crm_status IN ('vip','loyal')`, [hotelId]);
  const scoreAll = [sat.score, cs.s].filter((x) => x !== null).map(Number);
  return {
    kpi: {
      ...k, inactive: k.total - k.active, companies: companies.n, retention: ret.n ? Math.round((ret.returning * 1000) / ret.n) / 10 : 0,
      satisfaction: scoreAll.length ? Math.round((scoreAll.reduce((a, b) => a + b, 0) / scoreAll.length) * 100) / 100 : null, surveys: sat.n,
      nps: sat.nps_n ? Math.round((sat.nps_net * 100) / sat.nps_n) : null, complaints_pending: cp.pending, complaints_late: cp.late, birthdays: upcoming.length,
    },
    birthdays: upcoming, inhouse, arrivals,
  };
}
const c = (key: string, label: string, money = false) => ({ key, label, money });
export const CRM_REPORTS: Record<string, { title: string; columns: any[] }> = {
  new_clients: { title: 'Nouveaux clients', columns: [c('month', 'Mois'), c('new', 'Nouveaux clients'), c('with_stay', 'Ayant séjourné'), c('members', 'Inscrits au programme')] },
  returning: { title: 'Clients récurrents', columns: [c('code', 'Client'), c('name', 'Nom'), c('status', 'Statut'), c('stays', 'Séjours'), c('nights', 'Nuits'), c('last_stay', 'Dernier séjour'), c('spent', 'Montant réglé', true)] },
  value: { title: 'Valeur par client', columns: [c('segment', 'Statut'), c('clients', 'Clients'), c('spent', 'Montant réglé', true), c('avg', 'Valeur moyenne / client', true), c('avg_stay', 'Panier moyen / séjour', true)] },
  frequency: { title: 'Fréquence des séjours', columns: [c('bucket', 'Séjours'), c('clients', 'Clients'), c('share', 'Part (%)')] },
  distribution: { title: 'Répartition des clients', columns: [c('dimension', 'Critère'), c('value', 'Valeur'), c('clients', 'Clients'), c('share', 'Part (%)')] },
  retention: { title: 'Taux de fidélisation', columns: [c('month', 'Mois'), c('guests', 'Clients en séjour'), c('returning', 'Clients revenus'), c('rate', 'Taux (%)')] },
  satisfaction: { title: 'Satisfaction', columns: [c('month', 'Mois'), c('responses', 'Réponses'), c('score', 'Note moyenne /5'), c('nps', 'NPS'), c('complaint_sat', 'Satisfaction après réclamation /5')] },
  complaints: { title: 'Réclamations', columns: [c('category', 'Catégorie'), c('total', 'Total'), c('open', 'Ouvertes'), c('resolved', 'Résolues / clôturées'), c('avg_h', 'Délai moyen de résolution (h)'), c('late', 'Hors délai')] },
  loyalty: { title: 'Performance du programme de fidélité', columns: [c('tier', 'Niveau'), c('members', 'Membres'), c('earned', 'Points gagnés'), c('redeemed', 'Points utilisés'), c('expired', 'Points expirés'), c('rewards', 'Récompenses'), c('spent', 'CA des membres', true)] },
};
export async function crmReport(db: Db, hotelId: number, kind: string, from: string, to: string) {
  const def = CRM_REPORTS[kind];
  if (!def) throw notFound('Rapport inconnu');
  const P = [hotelId, from, to];
  const dc = (col: string) => `(${col} AT TIME ZONE '${TZ}')::date`;
  let rows: any[] = [];
  let total: any = null;
  const spentSql = `COALESCE((SELECT sum(CASE WHEN py.void THEN 0 ELSE py.amount END) FROM payments py WHERE py.guest_id = g.id AND ${dc('py.received_at')} BETWEEN $2 AND $3), 0)`;
  if (kind === 'new_clients') {
    rows = await q<any>(db, `SELECT to_char(g.created_at AT TIME ZONE '${TZ}', 'YYYY-MM') AS month, count(*)::int AS new, count(*) FILTER (WHERE EXISTS (SELECT 1 FROM stays s WHERE s.guest_id = g.id))::int AS with_stay,
        count(*) FILTER (WHERE g.loyalty_number IS NOT NULL)::int AS members FROM guests g WHERE ${PERSON} AND ${dc('g.created_at')} BETWEEN $2 AND $3 GROUP BY 1 ORDER BY 1`, P);
    total = ['new', 'with_stay', 'members'].reduce((a, k) => ({ ...a, [k]: rows.reduce((s, r) => s + r[k], 0) }), { month: 'Total' });
  } else if (kind === 'returning') {
    rows = (await q<any>(db, `SELECT g.code, g.kind, g.last_name, g.first_name, g.company_name, g.crm_status, count(s.id)::int AS stays,
        COALESCE(sum(rr.check_out - rr.check_in), 0)::int AS nights, max(s.checked_in_at) AS last_stay, ${spentSql} AS spent
       FROM guests g JOIN stays s ON s.guest_id = g.id JOIN reservation_rooms rr ON rr.id = s.reservation_room_id WHERE ${PERSON} GROUP BY g.id HAVING count(s.id) >= 2
        AND max(${dc('s.checked_in_at')}) >= $2 ORDER BY stays DESC, spent DESC LIMIT 200`, P)).map((r) => ({ code: r.code, name: guestDisplayName(r), status: STATUS_LABEL[r.crm_status], stays: r.stays, nights: r.nights, last_stay: new Date(r.last_stay).toLocaleDateString('sv-SE', { timeZone: TZ }), spent: n2(r.spent) }));
  } else if (kind === 'value') {
    rows = (await q<any>(db, `SELECT g.crm_status, count(DISTINCT g.id)::int AS clients, COALESCE(sum(x.spent),0) AS spent, COALESCE(sum(x.stays),0)::int AS stays FROM guests g
        CROSS JOIN LATERAL (SELECT ${spentSql} AS spent, (SELECT count(*) FROM stays s WHERE s.guest_id = g.id AND ${dc('s.checked_in_at')} BETWEEN $2 AND $3) AS stays) x
       WHERE g.hotel_id = $1 AND g.merged_into_id IS NULL AND (x.spent > 0 OR x.stays > 0) GROUP BY 1 ORDER BY 1`, P)).map((r) => ({
      segment: STATUS_LABEL[r.crm_status], clients: r.clients, spent: n2(r.spent), avg: r.clients ? n2(Number(r.spent) / r.clients) : 0, avg_stay: r.stays ? n2(Number(r.spent) / r.stays) : 0 }));
    const cl = rows.reduce((a, r) => a + r.clients, 0), sp = rows.reduce((a, r) => a + r.spent, 0);
    total = { segment: 'Total', clients: cl, spent: n2(sp), avg: cl ? n2(sp / cl) : 0 };
  } else if (kind === 'frequency') {
    const r = await q<any>(db, `SELECT CASE WHEN n = 1 THEN '1 séjour' WHEN n = 2 THEN '2 séjours' WHEN n BETWEEN 3 AND 5 THEN '3 à 5 séjours' ELSE '6 séjours et plus' END AS bucket, min(n) AS o, count(*)::int AS clients
       FROM (SELECT g.id, count(s.id) AS n FROM guests g JOIN stays s ON s.guest_id = g.id WHERE ${PERSON} AND ${dc('s.checked_in_at')} <= $3 GROUP BY g.id) x WHERE $2::date IS NOT NULL GROUP BY 1 ORDER BY 2`, P);
    const tot = r.reduce((a, x) => a + x.clients, 0);
    rows = r.map((x) => ({ bucket: x.bucket, clients: x.clients, share: tot ? Math.round((x.clients * 1000) / tot) / 10 : 0 }));
  } else if (kind === 'distribution') {
    const tot = (await one<any>(db, `SELECT count(*)::int AS n FROM guests g WHERE ${PERSON} AND $2::date IS NOT NULL AND $3::date IS NOT NULL`, P)).n || 1;
    for (const [dim, expr] of [['Statut', 'g.crm_status'], ['Pays', `COALESCE(NULLIF(g.country, ''), NULLIF(g.nationality, ''), 'Non renseigné')`], ['Langue', 'g.language'], ['Niveau de fidélité', `COALESCE(t.name, 'Non membre')`]] as const) {
      for (const x of await q<any>(db, `SELECT ${expr} AS value, count(*)::int AS clients FROM guests g LEFT JOIN loyalty_tiers t ON t.id = g.loyalty_tier_id WHERE ${PERSON} AND $2::date IS NOT NULL AND $3::date IS NOT NULL GROUP BY 1 ORDER BY 2 DESC LIMIT 15`, P)) {
        rows.push({ dimension: dim, value: dim === 'Statut' ? STATUS_LABEL[x.value] : dim === 'Langue' ? ({ fr: 'Français', ar: 'Arabe', en: 'Anglais' } as any)[x.value] ?? x.value : x.value, clients: x.clients, share: Math.round((x.clients * 1000) / tot) / 10 });
      }
    }
  } else if (kind === 'retention') {
    rows = (await q<any>(db, `SELECT to_char(s.checked_in_at AT TIME ZONE '${TZ}', 'YYYY-MM') AS month, count(DISTINCT s.guest_id)::int AS guests,
        count(DISTINCT s.guest_id) FILTER (WHERE EXISTS (SELECT 1 FROM stays p WHERE p.guest_id = s.guest_id AND p.checked_in_at < date_trunc('month', s.checked_in_at)))::int AS returning
       FROM stays s JOIN guests g ON g.id = s.guest_id WHERE ${PERSON} AND ${dc('s.checked_in_at')} BETWEEN $2 AND $3 GROUP BY 1 ORDER BY 1`, P)).map((r) => ({ ...r, rate: r.guests ? Math.round((r.returning * 1000) / r.guests) / 10 : 0 }));
  } else if (kind === 'satisfaction') {
    rows = (await q<any>(db, `SELECT m.month, COALESCE(sv.n, 0) AS responses, sv.score, sv.nps, cp.s AS complaint_sat FROM
        (SELECT to_char(d, 'YYYY-MM') AS month FROM generate_series(date_trunc('month', $2::date), $3::date, interval '1 month') d) m
        LEFT JOIN (SELECT to_char(completed_at AT TIME ZONE '${TZ}', 'YYYY-MM') AS month, count(*)::int AS n, round(avg(score), 2) AS score,
            CASE WHEN count(nps) > 0 THEN round(((count(*) FILTER (WHERE nps >= 9) - count(*) FILTER (WHERE nps <= 6)) * 100.0) / count(nps)) END AS nps
          FROM crm_survey_responses WHERE hotel_id = $1 AND completed_at IS NOT NULL GROUP BY 1) sv ON sv.month = m.month
        LEFT JOIN (SELECT to_char(closed_at AT TIME ZONE '${TZ}', 'YYYY-MM') AS month, round(avg(satisfaction), 2) AS s FROM crm_complaints WHERE hotel_id = $1 AND satisfaction IS NOT NULL GROUP BY 1) cp ON cp.month = m.month
       ORDER BY 1`, P)).map((r) => ({ ...r, score: r.score === null ? '' : Number(r.score), nps: r.nps === null ? '' : Number(r.nps), complaint_sat: r.complaint_sat === null ? '' : Number(r.complaint_sat) }));
  } else if (kind === 'complaints') {
    rows = (await q<any>(db, `SELECT category, count(*)::int AS total, count(*) FILTER (WHERE status IN ('new','in_progress'))::int AS open, count(*) FILTER (WHERE status IN ('resolved','closed'))::int AS resolved,
        round(avg(extract(epoch FROM resolved_at - created_at) / 3600) FILTER (WHERE resolved_at IS NOT NULL)::numeric, 1) AS avg_h,
        count(*) FILTER (WHERE due_at < COALESCE(resolved_at, now()))::int AS late FROM crm_complaints WHERE hotel_id = $1 AND kind = 'complaint' AND ${dc('created_at')} BETWEEN $2 AND $3 GROUP BY 1 ORDER BY 2 DESC`, P))
      .map((r) => ({ ...r, category: COMPLAINT_CAT[r.category] ?? r.category, avg_h: r.avg_h === null ? '' : Number(r.avg_h) }));
    total = ['total', 'open', 'resolved', 'late'].reduce((a, k) => ({ ...a, [k]: rows.reduce((s, r) => s + r[k], 0) }), { category: 'Total' });
  } else if (kind === 'loyalty') {
    rows = (await q<any>(db, `SELECT COALESCE(t.name, 'Sans niveau') AS tier, count(DISTINCT g.id)::int AS members,
        COALESCE((SELECT sum(points) FROM loyalty_transactions x WHERE x.guest_id = ANY(array_agg(g.id)) AND x.kind IN ('earn','bonus') AND ${dc('x.created_at')} BETWEEN $2 AND $3), 0)::int AS earned,
        COALESCE((SELECT -sum(points) FROM loyalty_transactions x WHERE x.guest_id = ANY(array_agg(g.id)) AND x.kind = 'redeem' AND ${dc('x.created_at')} BETWEEN $2 AND $3), 0)::int AS redeemed,
        COALESCE((SELECT -sum(points) FROM loyalty_transactions x WHERE x.guest_id = ANY(array_agg(g.id)) AND x.kind = 'expire' AND ${dc('x.created_at')} BETWEEN $2 AND $3), 0)::int AS expired,
        COALESCE((SELECT count(*) FROM loyalty_redemptions x WHERE x.guest_id = ANY(array_agg(g.id)) AND x.status <> 'cancelled' AND ${dc('x.created_at')} BETWEEN $2 AND $3), 0)::int AS rewards,
        COALESCE((SELECT sum(CASE WHEN py.void THEN 0 ELSE py.amount END) FROM payments py WHERE py.guest_id = ANY(array_agg(g.id)) AND ${dc('py.received_at')} BETWEEN $2 AND $3), 0) AS spent
       FROM guests g LEFT JOIN loyalty_tiers t ON t.id = g.loyalty_tier_id WHERE g.hotel_id = $1 AND g.loyalty_number IS NOT NULL GROUP BY 1, t.min_points ORDER BY t.min_points NULLS FIRST`, P)).map((r) => ({ ...r, spent: n2(r.spent) }));
    total = ['members', 'earned', 'redeemed', 'expired', 'rewards', 'spent'].reduce((a, k) => ({ ...a, [k]: n2(rows.reduce((s, r) => s + Number(r[k]), 0)) }), { tier: 'Total' });
  }
  return { kind, title: def.title, from, to, columns: def.columns, rows, total };
}
export { toCents, fromCents };
