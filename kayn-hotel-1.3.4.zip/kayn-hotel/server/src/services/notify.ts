/**
 * Notifications internes (cloche de l'application) : uniquement à partir d'événements réels de la base,
 * activées par type et adressées aux rôles / utilisateurs choisis dans Administration → Notifications.
 * Chaque notification a une clé de dédoublonnage : jamais deux fois la même alerte pour le même utilisateur.
 */
import { one, q, type Db } from '../db/pool.js';
import { getSettings } from './common.js';

export type NotifKind = 'security' | 'important' | 'low_stock' | 'maintenance' | 'task_reminder' | 'backup';
export const NOTIF_KINDS: NotifKind[] = ['security', 'important', 'low_stock', 'maintenance', 'task_reminder', 'backup'];

export async function notify(db: Db, hotelId: number, kind: NotifKind, n: { title: string; body?: string; link?: string; severity?: 'info' | 'warning' | 'danger'; dedupe: string }) {
  const cfg = (await getSettings(db, hotelId)).notifications_config?.[kind];
  if (!cfg?.enabled) return 0;
  const r = await db.query(
    `INSERT INTO user_notifications (hotel_id, user_id, kind, severity, title, body, link, dedupe_key)
     SELECT $1, u.id, $2, $3, $4, $5, $6, $7 FROM users u JOIN roles r ON r.id = u.role_id
      WHERE u.hotel_id = $1 AND u.active AND (r.code = ANY($8::text[]) OR u.id = ANY($9::int[]))
     ON CONFLICT (user_id, dedupe_key) DO NOTHING`,
    [hotelId, kind, n.severity ?? 'info', n.title, n.body ?? null, n.link ?? null, `${kind}:${n.dedupe}`, cfg.roles ?? [], (cfg.users ?? []).map(Number)],
  );
  return r.rowCount ?? 0;
}

/** Contrôles périodiques (planificateur) : stock bas, maintenance urgente, tâches en retard, sécurité, journée non clôturée, sauvegarde. */
export async function runNotificationChecks(db: Db, hotelId: number) {
  const tz = (await one<any>(db, 'SELECT timezone FROM hotels WHERE id = $1', [hotelId]))?.timezone ?? 'Africa/Algiers';
  const day = new Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(new Date());
  let n = 0;
  for (const p of await q<any>(db, `SELECT id, name, stock_qty, min_stock, unit FROM products WHERE hotel_id = $1 AND active AND archived_at IS NULL AND min_stock > 0 AND stock_qty < min_stock`, [hotelId]))
    n += await notify(db, hotelId, 'low_stock', { title: `Stock bas : ${p.name}`, body: `${Number(p.stock_qty)} ${p.unit} (minimum ${Number(p.min_stock)})`, link: '/stock', severity: Number(p.stock_qty) <= 0 ? 'danger' : 'warning', dedupe: `${p.id}:${day}` });
  for (const t of await q<any>(db, `SELECT t.id, t.number, t.title, t.priority FROM maintenance_tickets t WHERE t.hotel_id = $1 AND t.status IN ('new','assigned') AND t.priority IN ('urgent','high')`, [hotelId]))
    n += await notify(db, hotelId, 'maintenance', { title: `Panne ${t.priority === 'urgent' ? 'urgente' : 'prioritaire'} : ${t.title}`, body: t.number ?? undefined, link: '/maintenance', severity: t.priority === 'urgent' ? 'danger' : 'warning', dedupe: `ticket:${t.id}` });
  for (const w of await q<any>(db, `SELECT w.id, w.number, w.title FROM work_orders w WHERE w.hotel_id = $1 AND w.status IN ('planned','in_progress','on_hold') AND w.due_at < now()`, [hotelId]))
    n += await notify(db, hotelId, 'maintenance', { title: `Intervention en retard : ${w.title}`, body: w.number ?? undefined, link: '/maintenance', severity: 'warning', dedupe: `wo:${w.id}:${day}` });
  const late = await one<any>(db, `SELECT count(*)::int AS n FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id WHERE r.hotel_id = $1 AND t.status IN ('todo','in_progress') AND t.due_at < now() AND t.task_date = $2`, [hotelId, day]);
  if (late.n) n += await notify(db, hotelId, 'task_reminder', { title: `${late.n} tâche(s) de ménage en retard`, link: '/housekeeping', severity: 'warning', dedupe: `hk:${day}:${new Date().getHours()}` });
  const sec = await one<any>(db, `SELECT count(*) FILTER (WHERE action = 'login_failed')::int AS failed, count(*) FILTER (WHERE action = 'permission_denied')::int AS denied
     FROM audit_logs WHERE (hotel_id = $1 OR hotel_id IS NULL) AND created_at > now() - interval '1 hour'`, [hotelId]);
  const hour = new Date().toISOString().slice(0, 13);
  if (sec.failed >= 10) n += await notify(db, hotelId, 'security', { title: `${sec.failed} échecs de connexion en 1 heure`, link: '/admin?s=audit', severity: 'danger', dedupe: `failed:${hour}` });
  if (sec.denied >= 10) n += await notify(db, hotelId, 'security', { title: `${sec.denied} accès refusés en 1 heure`, link: '/admin?s=audit', severity: 'warning', dedupe: `denied:${hour}` });
  const dev = await one<any>(db, `SELECT count(*)::int AS n FROM devices WHERE hotel_id = $1 AND status = 'pending'`, [hotelId]);
  if (dev.n) n += await notify(db, hotelId, 'security', { title: `${dev.n} appareil(s) en attente d'approbation`, link: '/admin?s=security', severity: 'info', dedupe: `devices:${day}:${dev.n}` });
  const bd = await one<any>(db, `SELECT business_date FROM audit_days WHERE hotel_id = $1 AND status IN ('open','checking','ready','reopened') LIMIT 1`, [hotelId]);
  if (bd && String(bd.business_date).slice(0, 10) < day && new Date().getHours() >= 6)
    n += await notify(db, hotelId, 'important', { title: 'Night audit non clôturé', body: `Date opérationnelle : ${String(bd.business_date).slice(0, 10)}`, link: '/night-audit', severity: 'warning', dedupe: `audit:${day}` });
  return n;
}
