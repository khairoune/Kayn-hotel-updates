/**
 * Front Office : check-in complet, walk-in, check-out avec facture / paiement / remboursement,
 * changement de chambre (avec historique par segment), prolongation, prestations, main courante, rapports.
 */
import { currency } from './exports.js';
import type { PoolClient } from 'pg';
import { one, q, type Db } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { config } from '../config.js';
import { fromCents, taxCents, toCents } from '../lib/money.js';
import { addDays, diffDays, today } from '../lib/dates.js';
import { AppError, badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { FIN_SQL, getSettings, guestDisplayName, isTaxExempt, taxRateFor, withBalance } from './common.js';
import { queueNotification } from './notifications.js';
import { findOpenSession } from './billing.js';
import { loadPricing, priceStay } from './pricing.js';
import {
  addPayment, applyDiscount, assertNotBlocked, assertRoomFree, checkIn, checkOccupancy, checkOut, clean, createReservation, getReservation,
  lockRoom, markRoomDirty, moveReservationRoom, OPEN, r2, refreshInvoiceStatus, refreshReservation, segmentChain, upsertGuest,
  type GuestInput, type MealPlan, type PayMethod,
} from './reservations.js';

export interface PaymentIn { amount: number; method: PayMethod; reference?: string | null; kind?: 'deposit' | 'payment' }
export interface Companion { last_name: string; first_name?: string | null; birth_date?: string | null; relation?: string | null; nationality?: string | null; id_doc_type?: 'cni' | 'passport' | 'permis' | 'other' | null; id_doc_number?: string | null }
export interface CheckInInput {
  rr_id: number;
  room_id?: number | null;               // attribution d'une autre chambre à l'arrivée
  rate_policy?: 'keep' | 'new';          // si la chambre attribuée est d'une autre catégorie
  guest?: GuestInput;                    // identité / coordonnées de l'occupant principal
  adults?: number;
  children?: number;
  companions?: Companion[];
  coming_from?: string | null;
  going_to?: string | null;
  id_checked?: boolean;
  signed?: boolean;
  signature?: string | null;             // image PNG (data URL)
  data_consent?: boolean;
  payment?: PaymentIn | null;
  notes?: string | null;
  walk_in?: boolean;
}

const nightsList = (rr: any): { date: string; price: number }[] => {
  if (Array.isArray(rr.nightly) && rr.nightly.length === diffDays(rr.check_in, rr.check_out)) return rr.nightly.map((n: any) => ({ ...n, price: Number(n.price) }));
  const out = [];
  for (let d = rr.check_in; d < rr.check_out; d = addDays(d, 1)) out.push({ date: d, price: Number(rr.rack_rate) });
  return out;
};
const avg = (ns: { price: number }[]) => (ns.length ? r2(ns.reduce((s, n) => s + n.price, 0) / ns.length) : 0);

async function lockRr(db: PoolClient, actor: Actor, rrId: number) {
  const rr = await one<any>(
    db,
    `SELECT rr.*, r.hotel_id, r.code, r.meal_plan, r.rate_plan_id, r.guest_id AS res_guest_id, r.payer_guest_id, r.billing_mode, r.status AS res_status
       FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id WHERE rr.id = $1 FOR UPDATE OF rr`,
    [rrId],
  );
  if (!rr || rr.hotel_id !== actor.hotelId) throw notFound('Séjour introuvable');
  return rr;
}

// =====================================================================================================
// Check-in
// =====================================================================================================

/** Identité obligatoire pour la fiche de police (occupant principal). */
function assertIdentity(g: any) {
  const miss: string[] = [];
  if (!g.last_name) miss.push('nom');
  if (!g.first_name) miss.push('prénom');
  if (!g.birth_date) miss.push('date de naissance');
  if (!g.nationality) miss.push('nationalité');
  if (!g.id_doc_type || !g.id_doc_number) miss.push('pièce d\'identité');
  if (miss.length) throw badRequest(`Fiche de police incomplète : ${miss.join(', ')}.`, { missing: miss });
}

export async function frontCheckIn(db: PoolClient, actor: Actor, perms: Set<string>, input: CheckInInput) {
  let rr = await lockRr(db, actor, input.rr_id);
  if (!['pending', 'confirmed'].includes(rr.status)) throw conflict(rr.status === 'checked_in' ? 'Client déjà enregistré (check-in déjà effectué).' : 'Check-in impossible pour ce statut.');
  const t = today();
  if (rr.check_in > t) throw conflict(`Arrivée prévue le ${rr.check_in} : check-in impossible avant cette date (modifiez la réservation).`);
  if (rr.check_out <= t) throw conflict('Date de départ dépassée : prolongez le séjour avant le check-in.');

  // 1) Attribution de la chambre (si différente)
  if (input.room_id && input.room_id !== rr.room_id) {
    await changeRoom(db, actor, { rr_id: rr.id, room_id: input.room_id, reason: 'Attribution à l\'arrivée', rate_policy: input.rate_policy ?? 'keep', silent: true });
    rr = await lockRr(db, actor, input.rr_id);
  }
  // 2) Nombre de personnes
  if ((input.adults !== undefined && input.adults !== rr.adults) || (input.children !== undefined && input.children !== rr.children)) {
    await moveReservationRoom(db, actor, rr.id, { adults: input.adults ?? rr.adults, children: input.children ?? rr.children }, { silent: true });
    rr = await lockRr(db, actor, input.rr_id);
  }
  const room = await lockRoom(db, rr.room_id, actor.hotelId);
  const companions = input.companions ?? [];
  if (companions.length > Math.max(0, rr.adults + rr.children - 1)) throw badRequest(`Trop d'accompagnants : ${rr.adults + rr.children} personne(s) prévue(s) dans la chambre ${room.number}.`);

  // 3) Identité et coordonnées de l'occupant principal
  const guestId = rr.guest_id ?? rr.res_guest_id;
  if (input.guest) await upsertGuest(db, actor, { ...input.guest, id: guestId, kind: undefined });
  const g = await one<any>(db, 'SELECT * FROM guests WHERE id = $1', [guestId]);
  if (g.kind !== 'person') throw badRequest('L\'occupant doit être une personne : indiquez l\'occupant de la chambre.');
  assertIdentity(g);
  if (g.id_doc_expiry && g.id_doc_expiry < t) throw badRequest('Pièce d\'identité expirée.');
  if (input.data_consent) await db.query('UPDATE guests SET data_consent_at = COALESCE(data_consent_at, now()) WHERE id = $1', [guestId]);

  // 4) Paiement / acompte
  if (input.payment && input.payment.amount > 0) {
    if (!perms.has('payments.create')) throw forbidden('Vous n\'êtes pas autorisé à encaisser.');
    await addPayment(db, actor, { reservation_id: rr.reservation_id, reservation_room_id: rr.id, kind: input.payment.kind ?? 'payment', amount: input.payment.amount, method: input.payment.method, reference: input.payment.reference });
  }

  // 5) Check-in (chambre prête, non occupée, statut séjour « en cours »)
  if (input.signature && (input.signature.length > 400_000 || !input.signature.startsWith('data:image/png;base64,'))) throw badRequest('Signature invalide.');
  await checkIn(db, actor, rr.id, { id_scanned: !!input.id_checked, notes: input.notes ?? null });
  const stay = await one<any>(db, 'SELECT * FROM stays WHERE reservation_room_id = $1', [rr.id]);
  await db.query(
    `UPDATE check_ins SET coming_from = $2, going_to = $3, id_checked = $4, signed = $5, signature = $6, walk_in = $7 WHERE stay_id = $1`,
    [stay.id, clean(input.coming_from), clean(input.going_to), !!input.id_checked, !!input.signed || !!input.signature, input.signature ?? null, !!input.walk_in],
  );
  // 6) Accompagnants
  for (const c of companions) {
    if (!clean(c.last_name)) throw badRequest('Nom de l\'accompagnant obligatoire.');
    const id = await upsertGuest(db, actor, { kind: 'person', last_name: c.last_name, first_name: c.first_name ?? null, birth_date: c.birth_date ?? null, nationality: c.nationality ?? null, id_doc_type: c.id_doc_type ?? null, id_doc_number: c.id_doc_number ?? null });
    await db.query('INSERT INTO stay_guests (stay_id, guest_id, relation) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING', [stay.id, id, clean(c.relation)]);
  }
  await audit(db, actor, 'front_check_in', 'reservation_room', rr.id, null, { room: room.number, companions: companions.length, walk_in: !!input.walk_in, payment: input.payment?.amount ?? 0 });
  return { reservation: await getReservation(db, actor.hotelId, rr.reservation_id), stay_id: stay.id, rr_id: rr.id };
}

// =====================================================================================================
// Walk-in : client sans réservation → réservation + séjour + check-in en une seule opération
// =====================================================================================================
export interface WalkInInput extends Omit<CheckInInput, 'rr_id' | 'room_id' | 'walk_in'> {
  guest: GuestInput;
  room_id: number;
  check_out: string;
  adults: number;
  children?: number;
  meal_plan?: MealPlan;
  rate_plan_id?: number | null;
  rate?: number | null;                 // prix par nuit négocié au comptoir
  payer_company?: string | null;
}

export async function walkIn(db: PoolClient, actor: Actor, perms: Set<string>, input: WalkInInput) {
  const t = today();
  if (input.check_out <= t) throw badRequest('La date de départ doit être postérieure à aujourd\'hui.');
  if (input.rate != null && !perms.has('reservations.edit')) throw forbidden('Prix personnalisé non autorisé.');
  const g = input.guest;
  assertIdentity({ ...g });
  const res = await createReservation(db, actor, {
    guest: { ...g, kind: 'person' }, booker_type: input.payer_company ? 'company' : 'individual', source: 'walk_in', status: 'confirmed',
    payer: input.payer_company ? { kind: 'company', company_name: input.payer_company } : null,
    check_in: t, check_out: input.check_out, meal_plan: input.meal_plan ?? 'RO', rate_mode: input.rate != null ? 'custom' : 'standard', rate_plan_id: input.rate_plan_id ?? null,
    rooms: [{ room_id: input.room_id, adults: input.adults, children: input.children ?? 0, rate: input.rate ?? undefined }],
  }, { silent: true, overridePolicy: true });
  const rrId = res.rooms[0].id;
  return frontCheckIn(db, actor, perms, { ...input, guest: undefined, rr_id: rrId, room_id: null, walk_in: true });
}

// =====================================================================================================
// Folio : consommations, paiements et solde d'un séjour
// =====================================================================================================
export async function folio(db: Db, hotelId: number, rrId: number) {
  const rr = await one<any>(
    db,
    `SELECT rr.*, r.code, r.billing_mode, r.payer_guest_id, r.vat_rate, r.tourist_tax, r.meal_plan, rm.number AS room_number, rt.name AS room_type,
            r.hotel_id, s.id AS stay_id, s.checked_in_at, s.checked_out_at
       FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id JOIN rooms rm ON rm.id = rr.room_id JOIN room_types rt ON rt.id = rr.room_type_id
       LEFT JOIN stays s ON s.reservation_room_id = rr.id WHERE rr.id = $1`,
    [rrId],
  );
  if (!rr || rr.hotel_id !== hotelId) throw notFound('Séjour introuvable');
  const res = await getReservation(db as any, hotelId, rr.reservation_id);
  const active = res.rooms.filter((x: any) => !['cancelled', 'no_show'].includes(x.status));
  // Portée : la chambre seule si facturation individuelle d'un groupe, sinon tout le dossier
  const roomScope = res.billing_mode === 'individual' && active.length > 1;
  const chain = await segmentChain(db, rrId);
  const ids = roomScope ? chain : active.map((x: any) => x.id);
  const segs = res.rooms.filter((x: any) => ids.includes(x.id));
  const nights = segs.flatMap((s: any) => nightsList(s).map((n) => ({ ...n, room: s.room_number, rr_id: s.id, discount: Number(s.discount_per_night) })));
  const charges = res.charges.filter((c: any) => (roomScope ? ids.includes(c.reservation_room_id) : true));
  const payments = res.payments.filter((p: any) => (roomScope ? ids.includes(p.reservation_room_id) : true));
  const refunds = await q<any>(db, `SELECT f.*, u.full_name AS created_by_name FROM refunds f LEFT JOIN users u ON u.id = f.created_by WHERE f.reservation_id = $1 ${roomScope ? 'AND f.reservation_room_id = ANY($2::int[])' : ''} ORDER BY f.created_at`, roomScope ? [rr.reservation_id, ids] : [rr.reservation_id]);
  let totals;
  if (roomScope) {
    const room = r2(segs.reduce((s: number, x: any) => s + Number(x.rate) * Number(x.nights), 0));
    const rack = r2(segs.reduce((s: number, x: any) => s + Number(x.rack_rate) * Number(x.nights), 0));
    const extras = r2(charges.filter((c: any) => !c.void).reduce((s: number, c: any) => s + Number(c.total), 0));
    const vat = fromCents(segs.reduce((s: number, x: any) => s + taxCents(toCents(Number(x.rate) * Number(x.nights)), Number(res.vat_rate)), 0)
      + charges.filter((c: any) => !c.void).reduce((s: number, c: any) => s + taxCents(toCents(c.total), Number(c.tax_rate)), 0));
    const tourist = r2(Number(res.tourist_tax) * segs.reduce((s: number, x: any) => s + x.adults * Number(x.nights), 0));
    const paid = r2(payments.filter((p: any) => !p.void).reduce((s: number, p: any) => s + Number(p.amount), 0));
    const refunded = r2(refunds.reduce((s: number, f: any) => s + Number(f.amount), 0));
    const total = r2(room + extras + vat + tourist);
    totals = { room_total: room, discount_total: r2(rack - room), extras_total: extras, vat_amount: vat, tourist_tax_amount: tourist, total, paid, refunded, balance: r2(total - paid + refunded) };
  } else {
    totals = {
      room_total: Number(res.room_total), discount_total: res.discount_total, extras_total: Number(res.extras_total), vat_amount: res.vat_amount,
      tourist_tax_amount: res.tourist_tax_amount, total: res.total, paid: Number(res.paid), refunded: Number(res.refunded), balance: res.balance,
    };
  }
  // autres chambres du dossier encore ouvertes (arrivées à venir ou en séjour)
  const others = active.filter((x: any) => !chain.includes(x.id) && OPEN.includes(x.status)).length;
  return {
    rr_id: rrId, reservation_id: rr.reservation_id, code: rr.code, room_number: rr.room_number, room_type: rr.room_type, status: rr.status,
    check_in: rr.check_in, check_out: rr.check_out, adults: rr.adults, children: rr.children, meal_plan: rr.meal_plan,
    scope: roomScope ? 'room' : 'reservation', billing_mode: res.billing_mode, room_count: active.length, others_in_house: others,
    guest_name: rr.guest_id ? res.rooms.find((x: any) => x.id === rrId)?.occupant_name : res.guest_name, booker_name: res.guest_name,
    payer: res.payer ? { id: res.payer.id, name: guestDisplayName(res.payer) } : null,
    nights, charges, payments, refunds, invoices: res.invoices, ...totals, vat_rate: Number(res.vat_rate),
  };
}

// =====================================================================================================
// Check-out
// =====================================================================================================
export interface CheckOutInput {
  rr_id: number;
  payment?: PaymentIn | null;
  refund?: { amount: number; method: 'cash' | 'card' | 'cheque' | 'transfer'; reason: string } | null;
  balance_action?: 'company' | 'override' | null;   // solde restant : facturé à la société, ou validé par un responsable
  override_reason?: string | null;
  notes?: string | null;
}

export async function frontCheckOut(db: PoolClient, actor: Actor, perms: Set<string>, input: CheckOutInput) {
  const rr = await lockRr(db, actor, input.rr_id);
  if (rr.status === 'checked_out') throw conflict('Départ déjà enregistré pour ce séjour.');
  if (rr.status !== 'checked_in') throw conflict('Check-out possible uniquement pour un client en chambre.');
  // Paiement final (avant la facture, pour que la facture soit soldée)
  if (input.payment && input.payment.amount > 0) {
    if (!perms.has('payments.create')) throw forbidden('Vous n\'êtes pas autorisé à encaisser.');
    await addPayment(db, actor, { reservation_id: rr.reservation_id, reservation_room_id: rr.id, kind: 'payment', amount: input.payment.amount, method: input.payment.method, reference: input.payment.reference });
  }
  const out = await checkOut(db, actor, rr.id, { notes: input.notes ?? null });
  let f = await folio(db, actor.hotelId, rr.id);
  // Le solde n'est exigible qu'au départ de la dernière chambre d'un dossier commun (ou pour une chambre facturée seule)
  const enforce = f.scope === 'room' || f.others_in_house === 0;

  if (input.refund && input.refund.amount > 0) {
    if (!perms.has('frontoffice.refund')) throw forbidden('Vous n\'êtes pas autorisé à rembourser.');
    if (!clean(input.refund.reason)) throw badRequest('Motif du remboursement obligatoire.');
    if (input.refund.amount > -f.balance + 0.005) throw badRequest(`Remboursement supérieur au trop-perçu (${r2(Math.max(0, -f.balance))} ${currency.symbol}).`);
    const session = await findOpenSession(db, actor);
    if (input.refund.method === 'cash' && !session) throw new AppError(409, 'cash_closed', 'Caisse fermée : ouvrez la caisse avant de rembourser en espèces.');
    const ref = await one<any>(db, `INSERT INTO refunds (reservation_id, reservation_room_id, amount, method, reason, cash_session_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [rr.reservation_id, f.scope === 'room' ? rr.id : null, r2(input.refund.amount), input.refund.method, input.refund.reason.trim(), session?.id ?? null, actor.userId]);
    await refreshInvoiceStatus(db, rr.reservation_id);
    await audit(db, actor, 'refund', 'reservation', rr.reservation_id, null, { refund_id: ref.id, amount: input.refund.amount, method: input.refund.method, reason: input.refund.reason });
    f = await folio(db, actor.hotelId, rr.id);
  }

  let action: string | null = null;
  if (enforce && f.balance > 0.005) {
    if (input.balance_action === 'company') {
      if (!f.payer) throw conflict('Aucune société / agence payeuse sur ce dossier : le solde ne peut pas lui être facturé.');
      action = `Solde ${f.balance} ${currency.symbol} facturé à ${f.payer.name}`;
    } else if (input.balance_action === 'override') {
      if (!perms.has('frontoffice.checkout_with_balance')) throw forbidden(`Solde impayé de ${f.balance} ${currency.symbol} : départ refusé. Un responsable doit valider.`);
      if (!clean(input.override_reason) || String(input.override_reason).trim().length < 3) throw badRequest('Motif obligatoire pour un départ avec solde impayé.');
      action = `Départ avec solde impayé ${f.balance} ${currency.symbol} validé : ${String(input.override_reason).trim()}`;
    } else {
      throw new AppError(409, 'balance_due', `Solde impayé de ${f.balance} ${currency.symbol} : encaissez le solde avant le départ.`, { balance: f.balance, payer: f.payer, can_override: perms.has('frontoffice.checkout_with_balance') });
    }
    await audit(db, actor, 'checkout_with_balance', 'reservation_room', rr.id, null, { balance: f.balance, action: input.balance_action, reason: input.override_reason ?? null });
  }
  if (action) {
    const stay = await one<any>(db, 'SELECT id FROM stays WHERE reservation_room_id = $1', [rr.id]);
    await db.query(`UPDATE check_outs SET notes = trim(both ' ' FROM coalesce(notes, '') || ' ' || $2) WHERE stay_id = $1`, [stay.id, action]);
  }
  return { reservation: await getReservation(db, actor.hotelId, rr.reservation_id), invoice: out.invoice, folio: f };
}

// =====================================================================================================
// Changement de chambre
// =====================================================================================================
export interface RoomChangeIn { rr_id: number; room_id: number; reason: string; rate_policy: 'keep' | 'new'; silent?: boolean }

/** Prix des nuits [from, to) dans une chambre, selon la politique tarifaire. */
async function priceNights(db: PoolClient, actor: Actor, rr: any, room: any, from: string, to: string, policy: 'keep' | 'new') {
  if (from >= to) return [];
  if (policy === 'keep') {
    const base = nightsList(rr);
    const fallback = avg(base);
    const out = [];
    for (let d = from; d < to; d = addDays(d, 1)) out.push({ date: d, price: base.find((n) => n.date === d)?.price ?? fallback });
    return out;
  }
  const ctx = await loadPricing(db, actor.hotelId);
  return priceStay(ctx, room.type, room, from, to, rr.meal_plan, rr.adults, rr.children, rr.rate_plan_id).nights.map((n: any) => ({ ...n, price: Number(n.price) }));
}

export async function roomChangeQuote(db: PoolClient, actor: Actor, rrId: number, roomId: number, policy: 'keep' | 'new') {
  const rr = await lockRr(db, actor, rrId);
  const room = await lockRoom(db, roomId, actor.hotelId);
  const t = today();
  const from = rr.status === 'checked_in' && rr.check_in < t ? t : rr.check_in;
  const before = nightsList(rr).filter((n) => n.date >= from);
  const after = await priceNights(db, actor, rr, room, from, rr.check_out, policy);
  const sum = (a: { price: number }[]) => r2(a.reduce((s, n) => s + n.price, 0));
  return { from, nights: after.length, before_total: sum(before), after_total: sum(after), difference: r2(sum(after) - sum(before)), room: room.number, room_type: room.type_name };
}

export async function changeRoom(db: PoolClient, actor: Actor, input: RoomChangeIn) {
  const rr = await lockRr(db, actor, input.rr_id);
  if (!OPEN.includes(rr.status)) throw conflict('Changement de chambre impossible pour ce statut.');
  if (input.room_id === rr.room_id) throw badRequest('Choisissez une chambre différente.');
  if (!clean(input.reason)) throw badRequest('Indiquez la raison du changement.');
  const t = today();
  const oldRoom = await lockRoom(db, rr.room_id, actor.hotelId);
  const room = await lockRoom(db, input.room_id, actor.hotelId);
  checkOccupancy(room, rr.adults, rr.children);
  const inHouse = rr.status === 'checked_in';
  const from = inHouse && rr.check_in < t ? t : rr.check_in;
  if (inHouse) {
    if (!['clean', 'inspected'].includes(room.hk_status)) throw conflict(`La chambre ${room.number} n'est pas prête (ménage).`);
    if (await one(db, 'SELECT 1 FROM stays WHERE room_id = $1 AND checked_out_at IS NULL', [room.id])) throw conflict(`La chambre ${room.number} est occupée.`);
  }
  await assertNotBlocked(db, room.id, from, rr.check_out);
  await assertRoomFree(db, room.id, from, rr.check_out, rr.id);
  const before = nightsList(rr);
  const newNights = await priceNights(db, actor, rr, room, from, rr.check_out, input.rate_policy);
  const rateBefore = avg(before.filter((n) => n.date >= from));
  const rateAfter = avg(newNights);
  let newRrId = rr.id;

  if (inHouse && from > rr.check_in) {
    // Séjour découpé : segment passé dans l'ancienne chambre, segment à venir dans la nouvelle
    const past = before.filter((n) => n.date < from);
    await db.query(
      `UPDATE reservation_rooms SET check_out = $2, nightly = $3, rack_rate = $4, rate = $4 - discount_per_night, status = 'checked_out', updated_at = now() WHERE id = $1`,
      [rr.id, from, JSON.stringify(past), avg(past)],
    );
    const seg = await one<any>(
      db,
      `INSERT INTO reservation_rooms (reservation_id, room_id, room_type_id, check_in, check_out, rack_rate, rate, discount_per_night, custom_rate, adults, children, status, guest_id, nightly, moved_from_rr_id)
       VALUES ($1,$2,$3,$4,$5,$6::numeric,$6::numeric - $7::numeric,$7,$8,$9,$10,'checked_in',$11,$12,$13) RETURNING id`,
      [rr.reservation_id, room.id, room.room_type_id, from, rr.check_out, rateAfter, Number(rr.discount_per_night), rr.custom_rate, rr.adults, rr.children, rr.guest_id, JSON.stringify(newNights), rr.id],
    );
    newRrId = seg.id;
    const oldStay = await one<any>(db, `UPDATE stays SET checked_out_at = now() WHERE reservation_room_id = $1 RETURNING *`, [rr.id]);
    const stay = await one<any>(db, `INSERT INTO stays (reservation_room_id, room_id, guest_id) VALUES ($1,$2,$3) RETURNING id`, [seg.id, room.id, oldStay.guest_id]);
    await db.query(`INSERT INTO stay_guests (stay_id, guest_id, relation) SELECT $2, guest_id, relation FROM stay_guests WHERE stay_id = $1`, [oldStay.id, stay.id]);
    // les paiements / prestations déjà rattachés restent sur le segment d'origine (même dossier, même chaîne)
    await markRoomDirty(db, actor, oldRoom.id, rr.id, 'checkout_clean');
    await applyDiscount(db, rr.reservation_id);
    await refreshReservation(db, rr.reservation_id);
  } else {
    await moveReservationRoom(db, actor, rr.id, { room_id: room.id, rate: input.rate_policy === 'keep' ? Number(rr.rack_rate) : undefined }, { silent: true });
    if (input.rate_policy === 'new' && rr.custom_rate) {
      await db.query(`UPDATE reservation_rooms SET rack_rate = $2, rate = $2 - discount_per_night, nightly = $3, custom_rate = false WHERE id = $1`, [rr.id, rateAfter, JSON.stringify(newNights)]);
    } else if (input.rate_policy === 'keep') {
      await db.query(`UPDATE reservation_rooms SET nightly = $2, custom_rate = $3 WHERE id = $1`, [rr.id, JSON.stringify(before), rr.custom_rate]);
    }
    await applyDiscount(db, rr.reservation_id);
    await refreshReservation(db, rr.reservation_id);
  }
  await db.query(
    `INSERT INTO room_changes (reservation_room_id, from_room_id, to_room_id, change_date, reason, rate_policy, rate_before, rate_after, in_house, done_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [newRrId, oldRoom.id, room.id, from, input.reason.trim(), input.rate_policy, rateBefore, rateAfter, inHouse, actor.userId],
  );
  await audit(db, actor, 'room_change', 'reservation_room', newRrId, { room: oldRoom.number, rate: rateBefore }, { room: room.number, rate: rateAfter, reason: input.reason, policy: input.rate_policy, from });
  if (!input.silent && !inHouse) await queueNotification(db, actor, rr.reservation_id, 'modification');
  return { reservation: await getReservation(db, actor.hotelId, rr.reservation_id), rr_id: newRrId };
}

// =====================================================================================================
// Prolongation
// =====================================================================================================
export async function extensionQuote(db: PoolClient, actor: Actor, rrId: number, checkOutNew: string, policy: 'keep' | 'new') {
  const rr = await lockRr(db, actor, rrId);
  if (!OPEN.includes(rr.status)) throw conflict('Prolongation impossible pour ce statut.');
  if (checkOutNew <= rr.check_out) throw badRequest('La nouvelle date de départ doit être après la date actuelle.');
  if (diffDays(rr.check_out, checkOutNew) > 90) throw badRequest('Prolongation limitée à 90 nuits à la fois.');
  const room = await lockRoom(db, rr.room_id, actor.hotelId);
  await assertNotBlocked(db, room.id, rr.check_out, checkOutNew);
  await assertRoomFree(db, room.id, rr.check_out, checkOutNew, rr.id);
  const added = await priceNights(db, actor, rr, room, rr.check_out, checkOutNew, policy);
  const total = r2(added.reduce((s, n) => s + n.price, 0));
  return { rr, room, added, added_total: total, added_net: r2(total - added.length * Number(rr.discount_per_night)), nights: added.length };
}

export async function extendStay(db: PoolClient, actor: Actor, rrId: number, checkOutNew: string, policy: 'keep' | 'new') {
  const qt = await extensionQuote(db, actor, rrId, checkOutNew, policy);
  const rr = qt.rr;
  const all = [...nightsList(rr), ...qt.added];
  await db.query(`UPDATE reservation_rooms SET check_out = $2, nightly = $3, rack_rate = $4, rate = $4 - discount_per_night, updated_at = now() WHERE id = $1`,
    [rr.id, checkOutNew, JSON.stringify(all), avg(all)]);
  await applyDiscount(db, rr.reservation_id);
  await refreshReservation(db, rr.reservation_id);
  await audit(db, actor, 'extend', 'reservation_room', rr.id, { check_out: rr.check_out }, { check_out: checkOutNew, nights_added: qt.nights, amount: qt.added_total, policy });
  await queueNotification(db, actor, rr.reservation_id, 'modification');
  return getReservation(db, actor.hotelId, rr.reservation_id);
}

// =====================================================================================================
// Prestations
// =====================================================================================================
const CAT_KIND: Record<string, string> = { breakfast: 'breakfast', restaurant: 'restaurant', laundry: 'laundry', room_service: 'room_service', transfer: 'transfer', parking: 'parking', minibar: 'minibar', other: 'service' };

export async function addCharge(db: PoolClient, actor: Actor, c: { reservation_id: number; reservation_room_id?: number | null; service_id?: number | null; kind?: string; description?: string | null; quantity: number; unit_price?: number | null; service_date?: string | null }) {
  const res = await one<any>(db, 'SELECT id, status, guest_id, payer_guest_id FROM reservations WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [c.reservation_id, actor.hotelId]);
  if (!res) throw notFound('Réservation introuvable');
  if (['cancelled', 'no_show', 'checked_out'].includes(res.status)) throw conflict('Dossier clôturé : impossible d\'ajouter une prestation.');
  if (c.reservation_room_id) {
    const rr = await one<any>(db, 'SELECT status FROM reservation_rooms WHERE id = $1 AND reservation_id = $2', [c.reservation_room_id, c.reservation_id]);
    if (!rr) throw badRequest('Chambre inconnue pour cette réservation.');
    if (['checked_out', 'cancelled', 'no_show'].includes(rr.status)) throw conflict('Cette chambre est clôturée : ajoutez la prestation à une chambre en cours.');
  }
  let kind = c.kind ?? 'service';
  let description = clean(c.description) as string | null;
  let price = c.unit_price;
  if (c.service_id) {
    const s = await one<any>(db, 'SELECT * FROM services WHERE id = $1 AND hotel_id = $2', [c.service_id, actor.hotelId]);
    if (!s || !s.active) throw notFound('Prestation introuvable ou désactivée');
    kind = CAT_KIND[s.category] ?? 'service';
    description = description ?? s.name;
    price = price ?? Number(s.price);
  }
  if (!description) throw badRequest('Description de la prestation obligatoire.');
  if (price == null || price < 0) throw badRequest('Prix invalide.');
  if (!(c.quantity > 0) || c.quantity > 1000) throw badRequest('Quantité invalide.');
  const total = fromCents(Math.round(toCents(price) * c.quantity));
  // taux de TVA figé sur la ligne (paramètres du jour), 0 si le client ou le payeur est exonéré
  const taxRate = (await isTaxExempt(db, [res.guest_id, res.payer_guest_id])) ? 0 : taxRateFor(await getSettings(db, actor.hotelId), kind);
  const row = await one<any>(
    db,
    `INSERT INTO charges (reservation_id, reservation_room_id, service_date, kind, description, quantity, unit_price, total, created_by, service_id, tax_rate)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [c.reservation_id, c.reservation_room_id ?? null, c.service_date ?? today(), kind, description, c.quantity, price, total, actor.userId, c.service_id ?? null, taxRate],
  );
  await audit(db, actor, 'create', 'charge', row.id, null, { reservation_id: c.reservation_id, description, quantity: c.quantity, unit_price: price, total });
  return row;
}

export async function voidCharge(db: PoolClient, actor: Actor, id: number, reason: string) {
  const c = await one<any>(db, `SELECT c.*, r.status AS res_status FROM charges c JOIN reservations r ON r.id = c.reservation_id WHERE c.id = $1 AND r.hotel_id = $2 FOR UPDATE OF c`, [id, actor.hotelId]);
  if (!c) throw notFound('Prestation introuvable');
  if (c.void) throw conflict('Prestation déjà annulée.');
  if (c.res_status === 'checked_out') throw conflict('Facture émise : la prestation ne peut plus être annulée (faire un avoir).');
  if (!clean(reason)) throw badRequest('Motif obligatoire.');
  await db.query('UPDATE charges SET void = true, void_reason = $2, voided_by = $3, voided_at = now() WHERE id = $1', [id, reason.trim(), actor.userId]);
  await audit(db, actor, 'void', 'charge', id, { void: false, total: Number(c.total) }, { void: true, reason });
}

// =====================================================================================================
// Main courante & rapports
// =====================================================================================================
async function overdueLimit(db: Db, hotelId: number) {
  const s = await getSettings(db as any, hotelId);
  return String(s.check_out_time ?? '12:00');
}
const nowHHMM = () => new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: config.timezone }).format(new Date());

export async function inHouse(db: Db, hotelId: number) {
  const t = today();
  const limit = await overdueLimit(db, hotelId);
  const late = nowHHMM() > limit;
  const rows = await q<any>(
    db,
    `SELECT s.id AS stay_id, s.checked_in_at, rr.id AS rr_id, rr.reservation_id, rr.check_in, rr.check_out, rr.adults, rr.children, rr.room_id,
            (rr.check_out - rr.check_in) AS nights, rm.number AS room_number, rt.name AS room_type, r.code, r.billing_mode, r.group_name, r.meal_plan,
            g.id AS guest_id, g.kind, g.last_name, g.first_name, g.company_name, g.phone, g.nationality, g.vip,
            og.id AS o_id, og.last_name AS o_last, og.first_name AS o_first, og.vip AS o_vip, pg.company_name AS payer_name,
            (SELECT count(*) FROM stay_guests sg WHERE sg.stay_id = s.id)::int AS companions,
            (SELECT count(*) FROM reservation_rooms x WHERE x.reservation_id = r.id AND x.status NOT IN ('cancelled','no_show'))::int AS room_count,
            (SELECT min(x.check_in) FROM reservation_rooms x WHERE x.id = ANY(ARRAY(WITH RECURSIVE c AS (SELECT id, moved_from_rr_id FROM reservation_rooms WHERE id = rr.id
               UNION ALL SELECT y.id, y.moved_from_rr_id FROM reservation_rooms y JOIN c ON y.id = c.moved_from_rr_id) SELECT id FROM c))) AS arrival,
            ${FIN_SQL}
       FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN reservations r ON r.id = rr.reservation_id
       JOIN rooms rm ON rm.id = s.room_id JOIN room_types rt ON rt.id = rr.room_type_id JOIN guests g ON g.id = r.guest_id
       LEFT JOIN guests og ON og.id = rr.guest_id LEFT JOIN guests pg ON pg.id = r.payer_guest_id
      WHERE s.checked_out_at IS NULL AND r.hotel_id = $1
      ORDER BY length(rm.number), rm.number`,
    [hotelId],
  );
  return rows.map((x) => {
    const f = withBalance(x);
    const status = x.check_out < t || (x.check_out === t && late) ? 'overdue' : x.check_out === t ? 'departure_today' : x.arrival === t ? 'arrived_today' : 'in_house';
    return {
      stay_id: x.stay_id, rr_id: x.rr_id, reservation_id: x.reservation_id, code: x.code, room_id: x.room_id, room_number: x.room_number, room_type: x.room_type,
      guest_id: x.o_id ?? x.guest_id, guest_name: x.o_id ? guestDisplayName({ kind: 'person', last_name: x.o_last, first_name: x.o_first }) : guestDisplayName(x),
      vip: !!(x.o_id ? x.o_vip : x.vip), phone: x.phone, nationality: x.nationality, payer_name: x.payer_name, group_name: x.group_name, room_count: x.room_count,
      arrival: x.arrival, check_in: x.check_in, check_out: x.check_out, nights: diffDays(x.arrival ?? x.check_in, x.check_out), persons: x.adults + x.children,
      adults: x.adults, children: x.children, companions: x.companions, meal_plan: x.meal_plan, checked_in_at: x.checked_in_at,
      total: f.total, paid: r2(Number(x.paid) - Number(x.refunded)), balance: f.balance, status,
    };
  });
}

export const REPORTS: Record<string, { title: string; dated: boolean; range?: boolean; columns: [string, string][] }> = {
  arrivals: { title: 'Arrivées du jour', dated: true, columns: [['room_number', 'Chambre'], ['guest_name', 'Client'], ['code', 'Réservation'], ['check_in', 'Arrivée'], ['check_out', 'Départ'], ['persons', 'Pers.'], ['status_label', 'Statut'], ['balance', 'Solde']] },
  departures: { title: 'Départs du jour', dated: true, columns: [['room_number', 'Chambre'], ['guest_name', 'Client'], ['code', 'Réservation'], ['check_in', 'Arrivée'], ['check_out', 'Départ'], ['status_label', 'Statut'], ['balance', 'Solde']] },
  in_house: { title: 'Clients présents', dated: false, columns: [['room_number', 'Chambre'], ['guest_name', 'Client'], ['code', 'Réservation'], ['arrival', 'Arrivée'], ['check_out', 'Départ prévu'], ['nights', 'Nuits'], ['persons', 'Pers.'], ['total', 'Montant'], ['paid', 'Payé'], ['balance', 'Solde']] },
  overdue: { title: 'Clients en retard de départ', dated: false, columns: [['room_number', 'Chambre'], ['guest_name', 'Client'], ['code', 'Réservation'], ['check_out', 'Départ prévu'], ['phone', 'Téléphone'], ['balance', 'Solde']] },
  available: { title: 'Chambres disponibles', dated: true, columns: [['room_number', 'Chambre'], ['room_type', 'Catégorie'], ['floor', 'Étage'], ['capacity', 'Capacité'], ['hk_label', 'Propreté'], ['base_rate', 'Tarif']] },
  dirty: { title: 'Chambres à nettoyer', dated: false, columns: [['room_number', 'Chambre'], ['room_type', 'Catégorie'], ['floor', 'Étage'], ['hk_label', 'État'], ['occupancy', 'Occupation'], ['arrival_today', 'Arrivée aujourd\'hui']] },
  checkins: { title: 'Historique des check-in', dated: true, range: true, columns: [['done_at', 'Date / heure'], ['room_number', 'Chambre'], ['guest_name', 'Client'], ['code', 'Réservation'], ['walk_in', 'Walk-in'], ['done_by', 'Par']] },
  checkouts: { title: 'Historique des check-out', dated: true, range: true, columns: [['done_at', 'Date / heure'], ['room_number', 'Chambre'], ['guest_name', 'Client'], ['code', 'Réservation'], ['invoice', 'Facture'], ['balance', 'Solde au départ'], ['done_by', 'Par'], ['notes', 'Observations']] },
};
const ST_LBL: Record<string, string> = { pending: 'En attente', confirmed: 'Confirmée', checked_in: 'Arrivé', checked_out: 'Parti', in_house: 'En séjour', departure_today: 'Départ du jour', overdue: 'En retard', arrived_today: 'Arrivé ce jour' };
const HK_LBL: Record<string, string> = { dirty: 'Sale', to_clean: 'À nettoyer', cleaning: 'En cours de nettoyage', to_inspect: 'À inspecter', clean: 'Nettoyée', inspected: 'Propre et disponible' };
const nameOf = (x: any) => (x.o_last ? guestDisplayName({ kind: 'person', last_name: x.o_last, first_name: x.o_first }) : guestDisplayName(x));

export async function report(db: Db, hotelId: number, kind: string, from: string, to: string) {
  const def = REPORTS[kind];
  if (!def) throw notFound('Rapport inconnu');
  let rows: any[] = [];
  const gcols = `g.kind, g.last_name, g.first_name, g.company_name, g.phone, og.last_name AS o_last, og.first_name AS o_first`;
  if (kind === 'in_house') rows = await inHouse(db, hotelId);
  else if (kind === 'overdue') rows = (await inHouse(db, hotelId)).filter((x) => x.status === 'overdue');
  else if (kind === 'arrivals' || kind === 'departures') {
    const col = kind === 'arrivals' ? 'check_in' : 'check_out';
    const st = kind === 'arrivals' ? `('pending','confirmed','checked_in')` : `('checked_in','checked_out')`;
    rows = (await q<any>(db,
      `SELECT rr.id AS rr_id, rr.reservation_id, rr.check_in, rr.check_out, rr.status, rr.adults + rr.children AS persons, rm.number AS room_number, r.code, ${gcols}, ${FIN_SQL}
         FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id JOIN rooms rm ON rm.id = rr.room_id JOIN guests g ON g.id = r.guest_id
         LEFT JOIN guests og ON og.id = rr.guest_id
        WHERE r.hotel_id = $1 AND rr.${col} = $2 AND rr.status IN ${st} AND rr.moved_from_rr_id IS NULL ${kind === 'departures' ? `AND NOT EXISTS (SELECT 1 FROM reservation_rooms n WHERE n.moved_from_rr_id = rr.id)` : ''}
        ORDER BY length(rm.number), rm.number`, [hotelId, from]))
      .map((x) => ({ ...x, guest_name: nameOf(x), status_label: ST_LBL[x.status], balance: withBalance(x).balance }));
  } else if (kind === 'available') {
    rows = (await q<any>(db,
      `SELECT r.id, r.number AS room_number, t.name AS room_type, f.name AS floor, COALESCE(r.capacity, t.capacity) AS capacity, r.hk_status, t.base_rate + r.rate_supplement AS base_rate
         FROM rooms r JOIN room_types t ON t.id = r.room_type_id JOIN floors f ON f.id = r.floor_id
        WHERE r.hotel_id = $1 AND r.active
          AND NOT EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.room_id = r.id AND rr.status IN ('pending','confirmed','checked_in') AND rr.check_in <= $2 AND rr.check_out > $2)
          AND NOT EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL)
          AND NOT EXISTS (SELECT 1 FROM room_blocks b WHERE b.room_id = r.id AND b.status = 'active' AND b.kind = 'out_of_service' AND b.start_date <= $2 AND (b.end_date IS NULL OR b.end_date > $2))
        ORDER BY f.number, length(r.number), r.number`, [hotelId, from])).map((x) => ({ ...x, hk_label: HK_LBL[x.hk_status] }));
  } else if (kind === 'dirty') {
    const t = today();
    rows = (await q<any>(db,
      `SELECT r.id, r.number AS room_number, t.name AS room_type, f.name AS floor, r.hk_status,
              EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL) AS occupied,
              EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.room_id = r.id AND rr.status IN ('pending','confirmed') AND rr.check_in = $2) AS arrival_today
         FROM rooms r JOIN room_types t ON t.id = r.room_type_id JOIN floors f ON f.id = r.floor_id
        WHERE r.hotel_id = $1 AND r.active AND r.hk_status NOT IN ('clean','inspected') ORDER BY arrival_today DESC, f.number, length(r.number), r.number`, [hotelId, t]))
      .map((x) => ({ ...x, hk_label: HK_LBL[x.hk_status], occupancy: x.occupied ? 'Occupée (recouche)' : 'Libre', arrival_today: x.arrival_today ? 'Oui — prioritaire' : '' }));
  } else if (kind === 'checkins') {
    rows = (await q<any>(db,
      `SELECT ci.done_at, ci.walk_in, rm.number AS room_number, r.code, rr.reservation_id, rr.id AS rr_id, u.full_name AS done_by, ${gcols}
         FROM check_ins ci JOIN stays s ON s.id = ci.stay_id JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN reservations r ON r.id = rr.reservation_id
         JOIN rooms rm ON rm.id = s.room_id JOIN guests g ON g.id = r.guest_id LEFT JOIN guests og ON og.id = rr.guest_id LEFT JOIN users u ON u.id = ci.done_by
        WHERE r.hotel_id = $1 AND (ci.done_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 ORDER BY ci.done_at DESC`, [hotelId, from, to, config.timezone]))
      .map((x) => ({ ...x, guest_name: nameOf(x), walk_in: x.walk_in ? 'Oui' : '' }));
  } else if (kind === 'checkouts') {
    rows = (await q<any>(db,
      `SELECT co.done_at, co.balance, co.notes, rm.number AS room_number, r.code, rr.reservation_id, rr.id AS rr_id, u.full_name AS done_by, i.number AS invoice, i.id AS invoice_id, ${gcols}
         FROM check_outs co JOIN stays s ON s.id = co.stay_id JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN reservations r ON r.id = rr.reservation_id
         JOIN rooms rm ON rm.id = s.room_id JOIN guests g ON g.id = r.guest_id LEFT JOIN guests og ON og.id = rr.guest_id LEFT JOIN users u ON u.id = co.done_by
         LEFT JOIN invoices i ON i.id = co.invoice_id
        WHERE r.hotel_id = $1 AND (co.done_at AT TIME ZONE $4)::date BETWEEN $2 AND $3 ORDER BY co.done_at DESC`, [hotelId, from, to, config.timezone]))
      .map((x) => ({ ...x, guest_name: nameOf(x), balance: Number(x.balance) }));
  }
  return { kind, title: def.title, from, to, columns: def.columns.map(([key, label]) => ({ key, label })), rows };
}

/** Fiche d'enregistrement (fiche de police) d'un séjour. */
export async function registrationCard(db: Db, hotelId: number, rrId: number) {
  const chain = await segmentChain(db, rrId);
  const first = chain[chain.length - 1];
  const x = await one<any>(
    db,
    `SELECT rr.*, r.code, r.hotel_id, rm.number AS room_number, rt.name AS room_type, s.id AS stay_id, s.checked_in_at, ci.coming_from, ci.going_to, ci.signature, ci.signed, ci.id_checked,
            ci.walk_in, u.full_name AS done_by, row_to_json(g.*) AS guest, row_to_json(h.*) AS hotel
       FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id JOIN rooms rm ON rm.id = rr.room_id JOIN room_types rt ON rt.id = rr.room_type_id
       JOIN guests g ON g.id = COALESCE(rr.guest_id, r.guest_id) JOIN hotels h ON h.id = r.hotel_id
       LEFT JOIN stays s ON s.reservation_room_id = rr.id LEFT JOIN check_ins ci ON ci.stay_id = s.id LEFT JOIN users u ON u.id = ci.done_by
      WHERE rr.id = $1`,
    [first],
  );
  if (!x || x.hotel_id !== hotelId) throw notFound('Séjour introuvable');
  const last = chain[0] === first ? x : await one<any>(db, `SELECT rr.check_out, rm.number AS room_number FROM reservation_rooms rr JOIN rooms rm ON rm.id = rr.room_id WHERE rr.id = $1`, [chain[0]]);
  const companions = x.stay_id ? await q<any>(db, `SELECT g.last_name, g.first_name, g.birth_date, g.nationality, g.id_doc_type, g.id_doc_number, sg.relation FROM stay_guests sg JOIN guests g ON g.id = sg.guest_id WHERE sg.stay_id = $1`, [x.stay_id]) : [];
  const { signature, ...rest } = x;
  return { ...rest, check_out: last.check_out, current_room: last.room_number, signature_image: signature ?? null, companions };
}
