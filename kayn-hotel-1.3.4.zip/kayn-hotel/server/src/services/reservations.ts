import { currency } from './exports.js';
import type { PoolClient } from 'pg';
import { one, q } from '../db/pool.js';
import { audit, type Actor } from '../lib/audit.js';
import { addDays, diffDays, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { FIN_SQL, getSettings, guestDisplayName, isTaxExempt, nextNumber, taxRateFor, withBalance } from './common.js';
import { queueNotification } from './notifications.js';
import { checkPlan, loadPricing, priceStay, type PricingContext } from './pricing.js';
import { paymentRules, refreshInvoiceStatus as refreshInvoices, stayInvoice } from './billing.js';

export type MealPlan = 'RO' | 'BB' | 'HB' | 'FB';
export type PayMethod = 'cash' | 'card' | 'cheque' | 'transfer' | 'company_account' | 'online';

export interface GuestInput {
  id?: number;
  kind?: 'person' | 'company' | 'agency';
  last_name?: string | null;
  first_name?: string | null;
  company_name?: string | null;
  phone?: string | null;
  email?: string | null;
  nationality?: string | null;
  gender?: 'M' | 'F' | null;
  birth_date?: string | null;
  birth_place?: string | null;
  id_doc_type?: 'cni' | 'passport' | 'permis' | 'other' | null;
  id_doc_number?: string | null;
  id_doc_expiry?: string | null;
  address?: string | null;
  city?: string | null;
  country?: string | null;
  profession?: string | null;
  father_name?: string | null;
  mother_name?: string | null;
  nif?: string | null;
  notes?: string | null;
  language?: 'fr' | 'en' | 'ar';
  id_doc_issued_on?: string | null;
  id_doc_issued_place?: string | null;
  preferences?: string | null;
  vip?: boolean;
  tax_exempt?: boolean;
  tax_exempt_reason?: string | null;
}

export interface RoomRequest {
  room_id: number;
  adults?: number;
  children?: number;
  rate?: number;                 // prix par nuit manuel (tarif personnalisé)
  guest?: GuestInput | null;     // occupant (réservation de groupe)
  check_in?: string;
  check_out?: string;
}

export interface CreateReservationInput {
  guest: GuestInput;
  payer?: GuestInput | null;
  booker_type?: 'individual' | 'group' | 'company' | 'agency';
  group_name?: string | null;
  source?: 'walk_in' | 'phone' | 'email' | 'company' | 'agency' | 'website' | 'other';
  status?: 'pending' | 'confirmed';
  check_in: string;
  check_out: string;
  meal_plan?: MealPlan;
  rate_mode?: 'standard' | 'custom';
  rate_plan_id?: number | null;
  discount?: { type: 'percent' | 'amount'; value: number } | null;
  billing_mode?: 'common' | 'individual';
  notes?: string | null;
  special_requests?: string | null;
  deposit_required?: number;
  rooms: RoomRequest[];
  deposit?: { amount: number; method: PayMethod; reference?: string | null } | null;
}

const GUEST_FIELDS = [
  'kind', 'last_name', 'first_name', 'company_name', 'phone', 'email', 'nationality', 'gender', 'birth_date', 'birth_place',
  'id_doc_type', 'id_doc_number', 'id_doc_expiry', 'address', 'city', 'country', 'profession', 'father_name', 'mother_name', 'nif', 'notes', 'language',
  'id_doc_issued_on', 'id_doc_issued_place', 'preferences', 'vip', 'tax_exempt', 'tax_exempt_reason',
] as const;

export const r2 = (n: number) => Math.round(n * 100) / 100;
export const OPEN = ['pending', 'confirmed', 'checked_in'];

export function clean(v: unknown) {
  if (typeof v === 'string') {
    const t = v.trim();
    return t === '' ? null : t;
  }
  return v ?? null;
}

export async function upsertGuest(db: PoolClient, actor: Actor, gIn: GuestInput): Promise<number> {
  let g = gIn;
  if (g.id) {
    const existing = await one<any>(db, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2', [g.id, actor.hotelId]);
    if (!existing) throw notFound('Client introuvable');
    const sets: string[] = [];
    const vals: unknown[] = [];
    for (const f of GUEST_FIELDS) {
      if (f in g && (g as any)[f] !== undefined && f !== 'kind') {
        vals.push(clean((g as any)[f]));
        sets.push(`${f} = $${vals.length}`);
      }
    }
    if (sets.length) {
      vals.push(g.id);
      const after = await one(db, `UPDATE guests SET ${sets.join(', ')}, updated_at = now() WHERE id = $${vals.length} RETURNING *`, vals);
      await audit(db, actor, 'update', 'guest', g.id, existing, after);
    }
    return g.id;
  }
  const kind = g.kind ?? 'person';
  if (kind === 'person' && !clean(g.last_name)) throw badRequest('Le nom du client est obligatoire.');
  if (kind !== 'person' && !clean(g.company_name)) throw badRequest('La raison sociale est obligatoire.');
  if (kind === 'person') {
    // CRM : une fiche existante (même pièce d'identité, même e-mail, ou même téléphone + même nom) est réutilisée — pas de doublon
    const { strongMatch } = await import('./crm.js');
    const ex = await strongMatch(db, actor.hotelId, g);
    if (ex) {
      const cur = await one<any>(db, 'SELECT * FROM guests WHERE id = $1', [ex]);
      const fill = GUEST_FIELDS.filter((f) => f !== 'kind' && (g as any)[f] !== undefined && clean((g as any)[f]) !== null && (cur[f] === null || cur[f] === ''));
      if (fill.length) await db.query(`UPDATE guests SET ${fill.map((f, i) => `${f} = $${i + 2}`).join(', ')}, updated_at = now() WHERE id = $1`, [ex, ...fill.map((f) => clean((g as any)[f]))]);
      await audit(db, actor, 'dedup_reuse', 'guest', ex, null, { completed: fill });
      return ex;
    }
  }
  if (kind !== 'person') {
    // réutilise la fiche société / agence existante
    const ex = await one<any>(db, `SELECT id FROM guests WHERE hotel_id = $1 AND kind = $2 AND lower(company_name) = lower($3) LIMIT 1`, [actor.hotelId, kind, clean(g.company_name)]);
    if (ex) return ex.id;
  }
  const cols = ['hotel_id', 'kind'];
  const vals: unknown[] = [actor.hotelId, kind];
  if (!g.language) g = { ...g, language: (await getSettings(db, actor.hotelId)).default_guest_language ?? 'fr' };
  for (const f of GUEST_FIELDS) {
    if (f !== 'kind' && (g as any)[f] !== undefined) {
      cols.push(f);
      vals.push(clean((g as any)[f]));
    }
  }
  const row = await one<any>(db, `INSERT INTO guests (${cols.join(',')}) VALUES (${vals.map((_, i) => `$${i + 1}`).join(',')}) RETURNING *`, vals);
  await audit(db, actor, 'create', 'guest', row.id, null, row);
  return row.id;
}

export async function lockRoom(db: PoolClient, roomId: number, hotelId: number) {
  const room = await one<any>(
    db,
    `SELECT r.*, COALESCE(r.capacity, t.capacity) AS capacity, t.name AS type_name, row_to_json(t.*) AS type
       FROM rooms r JOIN room_types t ON t.id = r.room_type_id
      WHERE r.id = $1 AND r.hotel_id = $2 FOR UPDATE OF r`,
    [roomId, hotelId],
  );
  if (!room || !room.active) throw notFound('Chambre introuvable ou désactivée');
  return room;
}

/** Refuse une chambre hors service (blocage daté) sur la période [ci, co). */
export async function assertNotBlocked(db: PoolClient, roomId: number, ci: string, co: string) {
  const b = await one<any>(
    db,
    `SELECT b.*, r.number FROM room_blocks b JOIN rooms r ON r.id = b.room_id
      WHERE b.room_id = $1 AND b.status = 'active' AND b.kind = 'out_of_service'
        AND b.start_date < $3::date AND (b.end_date IS NULL OR b.end_date > $2::date) LIMIT 1`,
    [roomId, ci, co],
  );
  if (b) throw conflict(`La chambre ${b.number} est hors service du ${b.start_date}${b.end_date ? ` au ${b.end_date}` : ' (sans date de fin)'} : ${b.reason}.`);
}

/** Vérifie qu'aucune autre réservation n'occupe la chambre sur [ci, co). */
export async function assertRoomFree(db: PoolClient, roomId: number, ci: string, co: string, excludeRrId?: number) {
  const clash = await one<any>(
    db,
    `SELECT rr.id, rr.check_in, rr.check_out, res.code, g.kind, g.last_name, g.first_name, g.company_name, rm.number
       FROM reservation_rooms rr
       JOIN reservations res ON res.id = rr.reservation_id
       JOIN guests g ON g.id = res.guest_id
       JOIN rooms rm ON rm.id = rr.room_id
      WHERE rr.room_id = $1 AND rr.status IN ('pending','confirmed','checked_in','checked_out')
        AND daterange(rr.check_in, rr.check_out, '[)') && daterange($2::date, $3::date, '[)')
        AND ($4::int IS NULL OR rr.id <> $4)
      LIMIT 1`,
    [roomId, ci, co, excludeRrId ?? null],
  );
  if (clash) {
    throw conflict(
      `Chambre ${clash.number} déjà réservée du ${clash.check_in} au ${clash.check_out} (${guestDisplayName(clash)}, ${clash.code}).`,
      { reservation_room_id: clash.id },
    );
  }
}

/** Capacité de la chambre (adultes max du type, total max de la chambre). */
export function checkOccupancy(room: any, adults: number, children: number) {
  if (adults < 1) throw badRequest('Au moins un adulte par chambre.');
  if (adults + children > room.capacity) throw badRequest(`Capacité dépassée pour la chambre ${room.number} (${room.capacity} pers. max).`);
  const maxA = room.type?.max_adults;
  if (maxA && adults > maxA) throw badRequest(`Chambre ${room.number} : ${maxA} adulte(s) maximum.`);
}

/**
 * Répartit la remise de la réservation sur les nuits des chambres encore modifiables.
 * Pourcentage : appliqué au prix de chaque nuit. Montant : réparti également par nuit.
 */
export async function applyDiscount(db: PoolClient, resId: number) {
  const res = await one<any>(db, 'SELECT discount_type, discount_value FROM reservations WHERE id = $1', [resId]);
  const rrs = await q<any>(db, `SELECT id, rack_rate, discount_per_night, (check_out - check_in) AS nights, status FROM reservation_rooms WHERE reservation_id = $1 AND status NOT IN ('cancelled','no_show')`, [resId]);
  const editable = rrs.filter((x) => x.status !== 'checked_out');
  const value = Number(res.discount_value ?? 0);
  let perNight: (x: any) => number = () => 0;
  if (res.discount_type === 'percent' && value > 0) {
    if (value > 100) throw badRequest('Remise supérieure à 100 %.');
    perNight = (x) => r2((Number(x.rack_rate) * value) / 100);
  } else if (res.discount_type === 'amount' && value > 0) {
    const used = rrs.filter((x) => x.status === 'checked_out').reduce((s, x) => s + Number(x.discount_per_night) * Number(x.nights), 0);
    const nights = editable.reduce((s, x) => s + Number(x.nights), 0);
    const rackTotal = editable.reduce((s, x) => s + Number(x.rack_rate) * Number(x.nights), 0);
    if (editable.length && value - used > rackTotal + 0.01) throw badRequest('La remise dépasse le montant du séjour.');
    const each = nights ? Math.max(0, r2((value - used) / nights)) : 0;
    perNight = (x) => Math.min(Number(x.rack_rate), each);
  }
  for (const x of editable) {
    const d = perNight(x);
    await db.query(`UPDATE reservation_rooms SET discount_per_night = $2, rate = rack_rate - $2, updated_at = now() WHERE id = $1`, [x.id, d]);
  }
}

export async function refreshReservation(db: PoolClient, resId: number) {
  const agg = await one<any>(
    db,
    `SELECT min(check_in) AS ci, max(check_out) AS co, sum(rate * (check_out - check_in)) AS total,
            sum(adults) AS adults, sum(children) AS children, array_agg(DISTINCT status) AS statuses
       FROM reservation_rooms WHERE reservation_id = $1 AND status NOT IN ('cancelled','no_show')`,
    [resId],
  );
  if (agg?.ci) {
    const st: string[] = agg.statuses;
    let status: string | null = null;
    if (st.every((s) => s === 'checked_out')) status = 'checked_out';
    else if (st.includes('checked_in') || st.includes('checked_out')) status = 'checked_in';
    await db.query(
      `UPDATE reservations SET check_in = $2, check_out = $3, total_amount = $4, adults = $6, children = $7,
              status = COALESCE($5, status), updated_at = now() WHERE id = $1`,
      [resId, agg.ci, agg.co, agg.total ?? 0, status, agg.adults ?? 0, agg.children ?? 0],
    );
  } else {
    await db.query(`UPDATE reservations SET total_amount = 0, updated_at = now() WHERE id = $1`, [resId]);
  }
}

export async function createReservation(db: PoolClient, actor: Actor, input: CreateReservationInput, opts: { allowPast?: boolean; silent?: boolean; overridePolicy?: boolean } = {}) {
  const t = today();
  if (diffDays(input.check_in, input.check_out) < 1) throw badRequest('La date de départ doit être après la date d\'arrivée.');
  if (!opts.allowPast && input.check_in < t) throw badRequest('La date d\'arrivée ne peut pas être dans le passé.');
  if (!input.rooms?.length) throw badRequest('Choisissez au moins une chambre.');
  const ids = input.rooms.map((r) => r.room_id);
  if (new Set(ids).size !== ids.length) throw badRequest('Une même chambre est sélectionnée deux fois.');
  const rateMode = input.rate_mode ?? 'standard';
  if (rateMode === 'custom' && input.rooms.some((r) => r.rate === undefined || r.rate === null)) throw badRequest('Tarif personnalisé : indiquez le prix par nuit de chaque chambre.');

  const settings = await getSettings(db, actor.hotelId);
  const meal: MealPlan = input.meal_plan ?? 'RO';
  const guestId = await upsertGuest(db, actor, input.guest);
  const payerId = input.payer ? await upsertGuest(db, actor, input.payer) : null;

  const ctx = await loadPricing(db, actor.hotelId);
  const planId = rateMode === 'custom' ? null : input.rate_plan_id ?? null;
  checkPlan(ctx, planId, input.check_in, input.check_out, payerId, guestId);
  const prepared: { room: any; adults: number; children: number; rack: number; custom: boolean; guestId: number | null; ci: string; co: string; nightly: any }[] = [];
  for (const r of input.rooms) {
    const room = await lockRoom(db, r.room_id, actor.hotelId);
    const ci = r.check_in ?? input.check_in;
    const co = r.check_out ?? input.check_out;
    if (co <= ci) throw badRequest(`Dates invalides pour la chambre ${room.number}.`);
    await assertNotBlocked(db, room.id, ci, co);
    const adults = r.adults ?? 1;
    const children = r.children ?? 0;
    checkOccupancy(room, adults, children);
    await assertRoomFree(db, room.id, ci, co);
    const custom = rateMode === 'custom' || (r.rate !== undefined && r.rate !== null);
    const stay = custom ? null : priceStay(ctx, room.type, room, ci, co, meal, adults, children, planId);
    const rack = custom ? r2(Number(r.rate)) : stay!.avg;
    const occupant = r.guest && (r.guest.id || clean(r.guest.last_name)) ? await upsertGuest(db, actor, r.guest) : null;
    prepared.push({ room, adults, children, rack, custom, guestId: occupant, ci, co, nightly: stay?.nights ?? null });
  }

  const seq = await nextNumber(db, `res-${t.slice(0, 4)}`);
  const code = `R${t.slice(2, 4)}-${String(seq).padStart(5, '0')}`;
  const disc = input.discount && input.discount.value > 0 ? input.discount : null;
  const res = await one<any>(
    db,
    `INSERT INTO reservations (hotel_id, code, guest_id, payer_guest_id, booker_type, group_name, source, status, check_in, check_out,
                               adults, children, meal_plan, deposit_required, notes, created_by, rate_mode, discount_type, discount_value,
                               vat_rate, tourist_tax, special_requests, billing_mode, rate_plan_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24) RETURNING *`,
    [
      actor.hotelId, code, guestId, payerId, input.booker_type ?? (input.rooms.length > 1 ? 'group' : 'individual'), clean(input.group_name),
      input.source ?? 'phone', input.status ?? 'confirmed', input.check_in, input.check_out,
      prepared.reduce((s, p) => s + p.adults, 0), prepared.reduce((s, p) => s + p.children, 0),
      meal, input.deposit_required ?? 0, clean(input.notes), actor.userId, rateMode, disc?.type ?? null, disc?.value ?? 0,
      (await isTaxExempt(db, [guestId, payerId])) ? 0 : taxRateFor(settings, 'room'), Number(settings.tourist_tax_per_adult_night ?? 0), clean(input.special_requests), input.billing_mode ?? 'common', planId,
    ],
  );
  for (const p of prepared) {
    await db.query(
      `INSERT INTO reservation_rooms (reservation_id, room_id, room_type_id, check_in, check_out, rack_rate, rate, custom_rate, adults, children, status, guest_id, nightly)
       VALUES ($1,$2,$3,$4,$5,$6,$6,$7,$8,$9,$10,$11,$12)`,
      [res.id, p.room.id, p.room.room_type_id, p.ci, p.co, p.rack, p.custom, p.adults, p.children, res.status, p.guestId, p.nightly ? JSON.stringify(p.nightly) : null],
    );
  }
  await applyDiscount(db, res.id);
  await refreshReservation(db, res.id);
  if (input.deposit && input.deposit.amount > 0) {
    await addPayment(db, actor, { reservation_id: res.id, amount: input.deposit.amount, method: input.deposit.method, kind: 'deposit', reference: input.deposit.reference ?? null });
  }
  // ===== Politique d'acompte =====
  const finalStatus = await applyDepositPolicy(db, actor, res.id, settings, input.source ?? 'phone', opts.overridePolicy ?? false);
  await audit(db, actor, 'create', 'reservation', res.id, null, { code, check_in: input.check_in, check_out: input.check_out, rooms: ids, status: finalStatus, discount: disc });
  if (!opts.silent && finalStatus === 'confirmed') await queueNotification(db, actor, res.id, 'confirmation');
  return getReservation(db, actor.hotelId, res.id);
}

/**
 * Calcule l'acompte requis et applique la politique :
 *  - none : aucune exigence ;
 *  - auto_pending : réservation « en attente » tant que l'acompte n'est pas atteint (confirmée automatiquement ensuite) ;
 *  - block : confirmation refusée sans l'acompte (sauf dérogation autorisée).
 */
async function applyDepositPolicy(db: PoolClient, actor: Actor, resId: number, settings: Record<string, any>, source: string, override: boolean) {
  const pol = settings.deposit_policy ?? { mode: 'none' };
  const res = await getReservation(db, actor.hotelId, resId);
  const exempt = (pol.exempt_sources ?? []).includes(source);
  const required = pol.mode === 'none' || exempt ? 0 : r2((res.total * Number(pol.percent ?? 0)) / 100);
  await db.query(`UPDATE reservations SET deposit_required = $2 WHERE id = $1`, [resId, required]);
  const paid = Number(res.paid) - Number(res.refunded);
  if (res.status !== 'confirmed' || required <= 0 || paid >= required - 0.005 || override) return res.status;
  if (pol.mode === 'block') {
    throw badRequest(`Acompte minimum de ${required.toLocaleString('fr-FR')} ${currency.symbol} (${pol.percent} %) requis pour confirmer. Encaissez l'acompte ou enregistrez la réservation « En attente ».`);
  }
  await db.query(`UPDATE reservations SET status = 'pending', confirm_on_deposit = true WHERE id = $1`, [resId]);
  await db.query(`UPDATE reservation_rooms SET status = 'pending' WHERE reservation_id = $1 AND status = 'confirmed'`, [resId]);
  return 'pending';
}

export async function getReservation(db: PoolClient | any, hotelId: number, id: number) {
  const r = await one<any>(
    db,
    `SELECT r.*, ${FIN_SQL},
            row_to_json(g.*) AS guest, row_to_json(pg.*) AS payer, u.full_name AS created_by_name
       FROM reservations r
       JOIN guests g ON g.id = r.guest_id
       LEFT JOIN guests pg ON pg.id = r.payer_guest_id
       LEFT JOIN users u ON u.id = r.created_by
      WHERE r.id = $1 AND r.hotel_id = $2`,
    [id, hotelId],
  );
  if (!r) throw notFound('Réservation introuvable');
  const rooms = await q<any>(
    db,
    `SELECT rr.*, rm.number AS room_number, rt.name AS room_type, rt.code AS room_type_code, rt.capacity,
            (rr.check_out - rr.check_in) AS nights, s.id AS stay_id, s.checked_in_at, s.checked_out_at,
            row_to_json(og.*) AS occupant
       FROM reservation_rooms rr JOIN rooms rm ON rm.id = rr.room_id JOIN room_types rt ON rt.id = rr.room_type_id
       LEFT JOIN stays s ON s.reservation_room_id = rr.id
       LEFT JOIN guests og ON og.id = rr.guest_id
      WHERE rr.reservation_id = $1 ORDER BY length(rm.number), rm.number`,
    [id],
  );
  const payments = await q<any>(
    db,
    `SELECT p.*, u.full_name AS received_by_name, rm.number AS room_number FROM payments p
       LEFT JOIN users u ON u.id = p.received_by
       LEFT JOIN reservation_rooms rr ON rr.id = p.reservation_room_id LEFT JOIN rooms rm ON rm.id = rr.room_id
      WHERE p.reservation_id = $1 ORDER BY p.received_at`,
    [id],
  );
  const charges = await q<any>(db, `SELECT * FROM charges WHERE reservation_id = $1 ORDER BY service_date, id`, [id]);
  const invoices = await q<any>(db, `SELECT id, number, total, status, issued_at, reservation_room_id FROM invoices WHERE reservation_id = $1 ORDER BY id`, [id]);
  return {
    ...withBalance(r),
    guest_name: guestDisplayName(r.guest),
    rooms: rooms.map((x) => ({ ...x, occupant_name: guestDisplayName(x.occupant) || null })),
    payments, charges, invoices,
  };
}

export interface RoomChangeInput {
  room_id?: number;
  check_in?: string;
  check_out?: string;
  adults?: number;
  children?: number;
  rate?: number;
}

/** Changement de chambre, de dates (prolonger / réduire), de nombre de personnes ou de prix. */
export async function moveReservationRoom(db: PoolClient, actor: Actor, rrId: number, m: RoomChangeInput, opts: { silent?: boolean } = {}) {
  const rr = await one<any>(
    db,
    `SELECT rr.*, r.hotel_id, r.code, r.meal_plan, r.rate_plan_id FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id
      WHERE rr.id = $1 FOR UPDATE OF rr`,
    [rrId],
  );
  if (!rr || rr.hotel_id !== actor.hotelId) throw notFound('Réservation introuvable');
  if (!OPEN.includes(rr.status)) throw conflict('Cette réservation ne peut plus être modifiée.');
  const t = today();
  const ci = m.check_in ?? rr.check_in;
  const co = m.check_out ?? rr.check_out;
  const roomId = m.room_id ?? rr.room_id;
  const adults = m.adults ?? rr.adults;
  const children = m.children ?? rr.children;
  if (diffDays(ci, co) < 1) throw badRequest('Le séjour doit durer au moins une nuit.');
  if (rr.status === 'checked_in') {
    if (ci !== rr.check_in) throw conflict('Client déjà arrivé : la date d\'arrivée ne peut plus changer.');
    if (co <= t && co !== rr.check_out) throw badRequest('Pour un départ aujourd\'hui, utilisez le check-out.');
  } else if (ci < t && ci !== rr.check_in) {
    throw badRequest('Impossible de déplacer une arrivée dans le passé.');
  }
  const room = await lockRoom(db, roomId, actor.hotelId);
  // blocage : seulement pour les nuits nouvellement occupées (une chambre déjà occupée garde son client)
  if (roomId !== rr.room_id) await assertNotBlocked(db, roomId, ci < t ? t : ci, co <= t ? addDays(t, 1) : co);
  else if (co > rr.check_out) await assertNotBlocked(db, roomId, rr.check_out, co);
  else if (ci < rr.check_in) await assertNotBlocked(db, roomId, ci, rr.check_in);
  checkOccupancy(room, adults, children);
  await assertRoomFree(db, roomId, ci, co, rrId);

  let rack = Number(rr.rack_rate);
  let custom = rr.custom_rate;
  let nightly = rr.nightly;
  if (m.rate !== undefined && m.rate !== null) {
    rack = r2(m.rate);
    custom = true;
    nightly = null;
  } else if (!rr.custom_rate && (roomId !== rr.room_id || adults !== rr.adults || children !== rr.children || ci !== rr.check_in || co !== rr.check_out)) {
    const stay = priceStay(await loadPricing(db, actor.hotelId), room.type, room, ci, co, rr.meal_plan, adults, children, rr.rate_plan_id);
    rack = stay.avg;
    nightly = stay.nights;
  }
  await db.query(
    `UPDATE reservation_rooms SET room_id = $2, room_type_id = $3, check_in = $4, check_out = $5, rack_rate = $6, rate = $6 - discount_per_night,
            custom_rate = $7, adults = $8, children = $9, nightly = $10, updated_at = now() WHERE id = $1`,
    [rrId, roomId, room.room_type_id, ci, co, rack, custom, adults, children, nightly ? JSON.stringify(nightly) : null],
  );
  if (rr.status === 'checked_in' && roomId !== rr.room_id) {
    await db.query(`UPDATE stays SET room_id = $2 WHERE reservation_room_id = $1`, [rrId, roomId]);
    await markRoomDirty(db, actor, rr.room_id, rrId, 'checkout_clean');
  }
  await applyDiscount(db, rr.reservation_id);
  await refreshReservation(db, rr.reservation_id);
  await audit(db, actor, 'move', 'reservation_room', rrId,
    { room_id: rr.room_id, check_in: rr.check_in, check_out: rr.check_out, rack_rate: Number(rr.rack_rate), adults: rr.adults },
    { room_id: roomId, room: room.number, check_in: ci, check_out: co, rack_rate: rack, adults });
  if (!opts.silent) await queueNotification(db, actor, rr.reservation_id, 'modification');
  return getReservation(db, actor.hotelId, rr.reservation_id);
}

/** Ajoute une chambre à une réservation existante (groupe). */
export async function addRoomToReservation(db: PoolClient, actor: Actor, resId: number, r: RoomRequest) {
  const res = await loadResForUpdate(db, actor, resId);
  if (!OPEN.includes(res.status)) throw conflict('Réservation clôturée : impossible d\'ajouter une chambre.');
  const ci = r.check_in ?? (res.status === 'checked_in' ? today() : res.check_in);
  const co = r.check_out ?? res.check_out;
  if (co <= ci) throw badRequest('Dates invalides.');
  if (ci < today()) throw badRequest('La date d\'arrivée de la chambre ajoutée ne peut pas être passée.');
  const room = await lockRoom(db, r.room_id, actor.hotelId);
  await assertNotBlocked(db, room.id, ci, co);
  const adults = r.adults ?? 1;
  const children = r.children ?? 0;
  checkOccupancy(room, adults, children);
  await assertRoomFree(db, room.id, ci, co);
  const custom = r.rate !== undefined && r.rate !== null;
  const stay = custom ? null : priceStay(await loadPricing(db, actor.hotelId), room.type, room, ci, co, res.meal_plan, adults, children, res.rate_plan_id);
  const rack = custom ? r2(Number(r.rate)) : stay!.avg;
  const occupant = r.guest && (r.guest.id || clean(r.guest.last_name)) ? await upsertGuest(db, actor, r.guest) : null;
  const st = res.status === 'pending' ? 'pending' : 'confirmed';
  const row = await one<any>(
    db,
    `INSERT INTO reservation_rooms (reservation_id, room_id, room_type_id, check_in, check_out, rack_rate, rate, custom_rate, adults, children, status, guest_id, nightly)
     VALUES ($1,$2,$3,$4,$5,$6,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
    [resId, room.id, room.room_type_id, ci, co, rack, custom, adults, children, st, occupant, stay ? JSON.stringify(stay.nights) : null],
  );
  if (res.booker_type === 'individual') await db.query(`UPDATE reservations SET booker_type = 'group' WHERE id = $1`, [resId]);
  await applyDiscount(db, resId);
  await refreshReservation(db, resId);
  await audit(db, actor, 'add_room', 'reservation', resId, null, { reservation_room_id: row.id, room: room.number, check_in: ci, check_out: co });
  await queueNotification(db, actor, resId, 'modification');
  return getReservation(db, actor.hotelId, resId);
}

/** Annule une seule chambre d'une réservation de groupe. */
export async function cancelReservationRoom(db: PoolClient, actor: Actor, rrId: number, reason: string) {
  if (!reason?.trim()) throw badRequest('Le motif est obligatoire.');
  const rr = await one<any>(db, `SELECT rr.*, r.hotel_id, rm.number FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id JOIN rooms rm ON rm.id = rr.room_id WHERE rr.id = $1 FOR UPDATE OF rr`, [rrId]);
  if (!rr || rr.hotel_id !== actor.hotelId) throw notFound('Réservation introuvable');
  if (!['pending', 'confirmed'].includes(rr.status)) throw conflict('Seule une chambre non arrivée peut être annulée.');
  const others = await one<any>(db, `SELECT count(*)::int AS n FROM reservation_rooms WHERE reservation_id = $1 AND id <> $2 AND status NOT IN ('cancelled','no_show')`, [rr.reservation_id, rrId]);
  if (others.n === 0) throw conflict('C\'est la dernière chambre : annulez la réservation entière.');
  await db.query(`UPDATE reservation_rooms SET status = 'cancelled', updated_at = now() WHERE id = $1`, [rrId]);
  await applyDiscount(db, rr.reservation_id);
  await refreshReservation(db, rr.reservation_id);
  await audit(db, actor, 'cancel_room', 'reservation_room', rrId, { status: rr.status }, { status: 'cancelled', room: rr.number, reason: reason.trim() });
  await queueNotification(db, actor, rr.reservation_id, 'modification');
  return getReservation(db, actor.hotelId, rr.reservation_id);
}

/** Associe un occupant (client) à une chambre du groupe. */
export async function setRoomOccupant(db: PoolClient, actor: Actor, rrId: number, guest: GuestInput | null) {
  const rr = await one<any>(db, `SELECT rr.*, r.hotel_id FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id WHERE rr.id = $1 FOR UPDATE OF rr`, [rrId]);
  if (!rr || rr.hotel_id !== actor.hotelId) throw notFound('Réservation introuvable');
  const gid = guest && (guest.id || clean(guest.last_name)) ? await upsertGuest(db, actor, guest) : null;
  await db.query(`UPDATE reservation_rooms SET guest_id = $2, updated_at = now() WHERE id = $1`, [rrId, gid]);
  if (gid && rr.status === 'checked_in') {
    await db.query(`INSERT INTO stay_guests (stay_id, guest_id) SELECT id, $2 FROM stays WHERE reservation_room_id = $1 ON CONFLICT DO NOTHING`, [rrId, gid]);
  }
  await audit(db, actor, 'set_occupant', 'reservation_room', rrId, { guest_id: rr.guest_id }, { guest_id: gid });
  return getReservation(db, actor.hotelId, rr.reservation_id);
}

async function loadResForUpdate(db: PoolClient, actor: Actor, id: number) {
  const r = await one<any>(db, 'SELECT * FROM reservations WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, actor.hotelId]);
  if (!r) throw notFound('Réservation introuvable');
  return r;
}

export async function confirmReservation(db: PoolClient, actor: Actor, id: number, opts: { override?: boolean; auto?: boolean } = {}) {
  const r = await loadResForUpdate(db, actor, id);
  if (r.status !== 'pending') throw conflict('Seule une réservation en attente peut être confirmée.');
  const pol = (await getSettings(db, actor.hotelId)).deposit_policy ?? { mode: 'none' };
  if (!opts.override && pol.mode !== 'none' && Number(r.deposit_required) > 0) {
    const fin = await getReservation(db, actor.hotelId, id);
    const paid = Number(fin.paid) - Number(fin.refunded);
    if (paid < Number(r.deposit_required) - 0.005) {
      throw conflict(`Acompte insuffisant : ${paid.toLocaleString('fr-FR')} ${currency.symbol} reçus sur ${Number(r.deposit_required).toLocaleString('fr-FR')} ${currency.symbol} requis.`);
    }
  }
  await db.query(`UPDATE reservations SET confirm_on_deposit = false WHERE id = $1`, [id]);
  await db.query(`UPDATE reservations SET status = 'confirmed', updated_at = now() WHERE id = $1`, [id]);
  await db.query(`UPDATE reservation_rooms SET status = 'confirmed', updated_at = now() WHERE reservation_id = $1 AND status = 'pending'`, [id]);
  await audit(db, actor, opts.auto ? 'auto_confirm' : 'confirm', 'reservation', id, { status: r.status }, { status: 'confirmed', override: !!opts.override });
  await queueNotification(db, actor, id, 'confirmation');
  return getReservation(db, actor.hotelId, id);
}

/** Calcule les frais d'annulation tardive / de non-présentation selon la politique de l'hôtel. */
export async function cancellationQuote(db: PoolClient | any, hotelId: number, id: number, noShow = false) {
  const settings = await getSettings(db, hotelId);
  const pol = settings.cancellation_policy ?? {};
  const r = await getReservation(db, hotelId, id);
  const h = await one<any>(
    db,
    `SELECT extract(epoch FROM (($1::date + $2::time) AT TIME ZONE $3) - now()) / 3600 AS hours`,
    [r.check_in, settings.check_in_time ?? '14:00', (await one<any>(db, 'SELECT timezone FROM hotels WHERE id = $1', [hotelId])).timezone],
  );
  const hours = Math.round(Number(h.hours) * 10) / 10;
  const enabled = noShow ? !!pol.no_show_enabled : !!pol.enabled;
  const applies = enabled && (noShow || hours < Number(pol.hours_before ?? 48));
  const type = noShow ? pol.no_show_fee_type : pol.fee_type;
  const value = Number(noShow ? pol.no_show_fee_value : pol.fee_value) || 0;
  let fee = 0;
  if (applies) {
    const active = r.rooms.filter((x: any) => !['cancelled', 'no_show', 'checked_out'].includes(x.status));
    if (type === 'nights') fee = active.reduce((s: number, x: any) => s + Number(x.rate) * Math.min(value, Number(x.nights)), 0);
    else if (type === 'percent') fee = (r.total * value) / 100;
    else fee = value;
    fee = r2(Math.min(fee, r.total));
  }
  const paid = Number(r.paid) - Number(r.refunded);
  return {
    applies: applies && fee > 0, fee, hours_before_arrival: hours, policy_hours: Number(pol.hours_before ?? 48), fee_type: type, fee_value: value,
    paid, refund_due: r2(Math.max(0, paid - fee)), balance_after: r2(fee - paid),
  };
}

export async function cancelReservation(db: PoolClient, actor: Actor, id: number, reason: string, noShow = false, opts: { waive_fee?: boolean } = {}) {
  const r = await loadResForUpdate(db, actor, id);
  if (!['pending', 'confirmed'].includes(r.status)) throw conflict('Seule une réservation non arrivée peut être annulée.');
  if (noShow && r.check_in > today()) throw conflict('Non-présentation possible seulement à partir du jour d\'arrivée.');
  if (!reason?.trim()) throw badRequest('Le motif est obligatoire.');
  const quote = await cancellationQuote(db, actor.hotelId, id, noShow);
  const st = noShow ? 'no_show' : 'cancelled';
  const fee = quote.applies && !opts.waive_fee ? quote.fee : 0;
  await db.query(`UPDATE reservations SET status = $2, cancel_reason = $3, cancellation_fee = $4, confirm_on_deposit = false, updated_at = now() WHERE id = $1`, [id, st, reason.trim(), fee]);
  await db.query(`UPDATE reservation_rooms SET status = $2, updated_at = now() WHERE reservation_id = $1 AND status IN ('pending','confirmed')`, [id, st]);
  if (fee > 0) {
    const label = noShow ? 'Frais de non-présentation' : `Frais d'annulation tardive (moins de ${quote.policy_hours} h avant l'arrivée)`;
    await db.query(
      `INSERT INTO charges (reservation_id, service_date, kind, description, quantity, unit_price, total, created_by, tax_rate) VALUES ($1,$2,$3,$4,1,$5,$5,$6,$7)`,
      [id, today(), noShow ? 'no_show_fee' : 'cancellation_fee', label, fee, actor.userId, Number(r.vat_rate ?? 0)],
    );
  }
  await refreshReservation(db, id);
  await audit(db, actor, noShow ? 'no_show' : 'cancel', 'reservation', id, { status: r.status },
    { status: st, reason, fee, fee_waived: quote.applies && !!opts.waive_fee ? quote.fee : 0 });
  if (!noShow) await queueNotification(db, actor, id, 'cancellation');
  return getReservation(db, actor.hotelId, id);
}

export interface ReservationPatch {
  source?: string;
  booker_type?: string;
  group_name?: string | null;
  notes?: string | null;
  special_requests?: string | null;
  deposit_required?: number;
  billing_mode?: 'common' | 'individual';
  meal_plan?: MealPlan;
  rate_plan_id?: number | null;
  discount?: { type: 'percent' | 'amount'; value: number } | null;
  guest?: GuestInput;
  payer?: GuestInput | null;
}

export async function updateReservationInfo(db: PoolClient, actor: Actor, id: number, patch: ReservationPatch) {
  const r = await loadResForUpdate(db, actor, id);
  if (['cancelled', 'no_show', 'checked_out'].includes(r.status)) throw conflict('Réservation clôturée : modification impossible.');
  const allowed = ['source', 'booker_type', 'group_name', 'notes', 'special_requests', 'deposit_required', 'billing_mode'] as const;
  const sets: string[] = [];
  const vals: unknown[] = [];
  const before: Record<string, unknown> = {};
  const after: Record<string, unknown> = {};
  for (const k of allowed) {
    if (patch[k] !== undefined && patch[k] !== r[k]) {
      before[k] = r[k];
      after[k] = patch[k];
      vals.push(clean(patch[k]));
      sets.push(`${k} = $${vals.length}`);
    }
  }
  if (patch.payer !== undefined) {
    const payerId = patch.payer ? await upsertGuest(db, actor, patch.payer) : null;
    if (payerId !== r.payer_guest_id) {
      before.payer_guest_id = r.payer_guest_id;
      after.payer_guest_id = payerId;
      vals.push(payerId);
      sets.push(`payer_guest_id = $${vals.length}`);
    }
  }
  let ratesChanged = false;
  let repriced = false;
  if (patch.meal_plan && patch.meal_plan !== r.meal_plan) {
    before.meal_plan = r.meal_plan;
    after.meal_plan = patch.meal_plan;
    vals.push(patch.meal_plan);
    sets.push(`meal_plan = $${vals.length}`);
    ratesChanged = true;
    repriced = true;
  }
  if (patch.rate_plan_id !== undefined && (patch.rate_plan_id ?? null) !== (r.rate_plan_id ?? null)) {
    const ctx0 = await loadPricing(db, actor.hotelId);
    checkPlan(ctx0, patch.rate_plan_id ?? null, r.check_in, r.check_out, r.payer_guest_id, r.guest_id);
    before.rate_plan_id = r.rate_plan_id;
    after.rate_plan_id = patch.rate_plan_id;
    vals.push(patch.rate_plan_id ?? null);
    sets.push(`rate_plan_id = $${vals.length}`);
    ratesChanged = true;
    repriced = true;
  }
  if (patch.discount !== undefined) {
    const d = patch.discount && patch.discount.value > 0 ? patch.discount : null;
    if ((d?.type ?? null) !== r.discount_type || Number(d?.value ?? 0) !== Number(r.discount_value)) {
      before.discount = { type: r.discount_type, value: Number(r.discount_value) };
      after.discount = d;
      vals.push(d?.type ?? null, d?.value ?? 0);
      sets.push(`discount_type = $${vals.length - 1}`, `discount_value = $${vals.length}`);
      ratesChanged = true;
    }
  }
  if (patch.guest) await upsertGuest(db, actor, { ...patch.guest, id: r.guest_id });
  if (sets.length) {
    vals.push(id);
    await db.query(`UPDATE reservations SET ${sets.join(', ')}, updated_at = now() WHERE id = $${vals.length}`, vals);
  }
  if (repriced) {
    const ctx = await loadPricing(db, actor.hotelId);
    const cur = await one<any>(db, 'SELECT meal_plan, rate_plan_id FROM reservations WHERE id = $1', [id]);
    const rrs = await q<any>(db, `SELECT rr.*, row_to_json(t.*) AS type, rm.rate_supplement FROM reservation_rooms rr JOIN room_types t ON t.id = rr.room_type_id JOIN rooms rm ON rm.id = rr.room_id
                                   WHERE rr.reservation_id = $1 AND rr.status IN ('pending','confirmed','checked_in') AND NOT rr.custom_rate`, [id]);
    for (const x of rrs) {
      const stay = priceStay(ctx, x.type, x, x.check_in, x.check_out, cur.meal_plan, x.adults, x.children, cur.rate_plan_id);
      await db.query(`UPDATE reservation_rooms SET rack_rate = $2, rate = $2 - discount_per_night, nightly = $3 WHERE id = $1`, [x.id, stay.avg, JSON.stringify(stay.nights)]);
    }
  }
  if (ratesChanged) {
    await applyDiscount(db, id);
    await refreshReservation(db, id);
  }
  if (sets.length || patch.guest) {
    await audit(db, actor, 'update', 'reservation', id, before, { ...after, guest: patch.guest ? 'mis à jour' : undefined });
    if (ratesChanged || patch.guest?.email || patch.guest?.phone) await queueNotification(db, actor, id, 'modification');
  }
  return getReservation(db, actor.hotelId, id);
}

// ================= Front office =================

export type { PricingContext };

export async function checkIn(db: PoolClient, actor: Actor, rrId: number, opts: { id_scanned?: boolean; notes?: string | null } = {}) {
  const rr = await one<any>(
    db,
    `SELECT rr.*, r.hotel_id, r.guest_id AS res_guest_id, r.status AS res_status FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id
      WHERE rr.id = $1 FOR UPDATE OF rr`,
    [rrId],
  );
  if (!rr || rr.hotel_id !== actor.hotelId) throw notFound('Réservation introuvable');
  if (!['pending', 'confirmed'].includes(rr.status)) throw conflict('Check-in impossible pour ce statut.');
  const t = today();
  if (rr.check_in > t) throw conflict(`Arrivée prévue le ${rr.check_in} : check-in impossible avant cette date.`);
  if (rr.check_out <= t) throw conflict('Séjour déjà terminé : modifiez les dates avant le check-in.');
  const room = await lockRoom(db, rr.room_id, actor.hotelId);
  if (room.out_of_service) throw conflict(`La chambre ${room.number} est hors service.`);
  if (!['clean', 'inspected'].includes(room.hk_status)) throw conflict(`La chambre ${room.number} n'est pas prête (ménage : ${room.hk_status}).`);
  const occupied = await one(db, `SELECT 1 FROM stays WHERE room_id = $1 AND checked_out_at IS NULL`, [rr.room_id]);
  if (occupied) throw conflict(`La chambre ${room.number} est encore occupée.`);

  await db.query(`UPDATE reservation_rooms SET status = 'checked_in', updated_at = now() WHERE id = $1`, [rrId]);
  if (rr.res_status === 'pending') await db.query(`UPDATE reservations SET status = 'confirmed' WHERE id = $1`, [rr.reservation_id]);
  const stay = await one<any>(db, `INSERT INTO stays (reservation_room_id, room_id, guest_id) VALUES ($1,$2,$3) RETURNING *`, [rrId, rr.room_id, rr.guest_id ?? rr.res_guest_id]);
  await db.query(`INSERT INTO check_ins (stay_id, done_by, id_scanned, notes) VALUES ($1,$2,$3,$4)`, [stay.id, actor.userId, !!opts.id_scanned, clean(opts.notes)]);
  await refreshReservation(db, rr.reservation_id);
  await audit(db, actor, 'check_in', 'reservation_room', rrId, { status: rr.status }, { status: 'checked_in', room: room.number });
  return getReservation(db, actor.hotelId, rr.reservation_id);
}

export async function markRoomDirty(db: PoolClient, actor: Actor, roomId: number, rrId: number | null, kind: 'checkout_clean' | 'stayover') {
  const { roomVacated } = await import('./housekeeping.js');
  await roomVacated(db, actor, roomId, rrId, kind);
}

const MEAL_LBL: Record<string, string> = { RO: 'chambre seule', BB: 'petit-déjeuner', HB: 'demi-pension', FB: 'pension complète' };

/**
 * Facture de séjour. rrIds = chambres couvertes (facture individuelle) ; vide = toute la réservation (facture commune).
 * includeUnassigned : ajoute les extras non rattachés à une chambre.
 */
export async function createStayInvoice(db: PoolClient, actor: Actor, resId: number, rrIds: number[] | null, includeUnassigned: boolean) {
  return stayInvoice(db, actor, resId, rrIds, includeUnassigned);
}

/** Segments d'un même séjour (changements de chambre en cours de séjour), du plus récent au plus ancien. */
export async function segmentChain(db: PoolClient | any, rrId: number): Promise<number[]> {
  const rows = await q<any>(db, `WITH RECURSIVE c AS (SELECT id, moved_from_rr_id FROM reservation_rooms WHERE id = $1
      UNION ALL SELECT x.id, x.moved_from_rr_id FROM reservation_rooms x JOIN c ON x.id = c.moved_from_rr_id) SELECT id FROM c`, [rrId]);
  return rows.map((r) => r.id);
}

export async function checkOut(db: PoolClient, actor: Actor, rrId: number, opts: { notes?: string | null } = {}) {
  const rr = await one<any>(
    db,
    `SELECT rr.*, r.hotel_id, r.billing_mode FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id WHERE rr.id = $1 FOR UPDATE OF rr`,
    [rrId],
  );
  if (!rr || rr.hotel_id !== actor.hotelId) throw notFound('Réservation introuvable');
  if (rr.status !== 'checked_in') throw conflict('Check-out possible uniquement pour un client en chambre.');
  // Restaurant / room service : une commande non réglée rattachée au séjour doit être portée au folio ou encaissée avant le départ
  const rsOpen = await one<any>(db, `SELECT number FROM rs_orders WHERE reservation_room_id = $1 AND settlement = 'open' AND status <> 'cancelled' LIMIT 1`, [rrId]);
  if (rsOpen) throw conflict(`Commande restaurant ${rsOpen.number} non réglée : portez-la sur la chambre ou encaissez-la avant le départ.`);
  const t = today();
  let co = rr.check_out;
  if (co > t) co = t > rr.check_in ? t : addDays(rr.check_in, 1); // départ anticipé (au minimum une nuit)
  await db.query(`UPDATE reservation_rooms SET status = 'checked_out', check_out = $2, updated_at = now() WHERE id = $1`, [rrId, co]);
  const stay = await one<any>(db, `UPDATE stays SET checked_out_at = now() WHERE reservation_room_id = $1 RETURNING *`, [rrId]);
  await markRoomDirty(db, actor, rr.room_id, rrId, 'checkout_clean');
  await applyDiscount(db, rr.reservation_id);
  await refreshReservation(db, rr.reservation_id);

  const remaining = await one<any>(db, `SELECT count(*)::int AS n FROM reservation_rooms WHERE reservation_id = $1 AND status IN ('pending','confirmed','checked_in')`, [rr.reservation_id]);
  let invoice = null;
  if (rr.billing_mode === 'individual') {
    invoice = await createStayInvoice(db, actor, rr.reservation_id, await segmentChain(db, rrId), remaining.n === 0);
  } else if (remaining.n === 0) {
    invoice = await createStayInvoice(db, actor, rr.reservation_id, null, true);
  }
  if (remaining.n === 0) await db.query(`UPDATE reservations SET status = 'checked_out', updated_at = now() WHERE id = $1`, [rr.reservation_id]);
  const res = await getReservation(db, actor.hotelId, rr.reservation_id);
  await db.query(`INSERT INTO check_outs (stay_id, invoice_id, done_by, balance, notes) VALUES ($1,$2,$3,$4,$5)`, [stay.id, invoice?.id ?? null, actor.userId, res.balance, clean(opts.notes)]);
  await audit(db, actor, 'check_out', 'reservation_room', rrId, { status: 'checked_in', check_out: rr.check_out }, { status: 'checked_out', check_out: co, balance: res.balance });
  // CRM : points de fidélité du séjour (une seule fois) et statut « fidèle »
  const crm = await import('./crm.js');
  const loyalty = await crm.earnForStay(db, actor, rrId);
  await crm.refreshStatus(db, stay.guest_id);
  return { reservation: res, invoice, loyalty_points: loyalty?.points ?? 0 };
}

// ================= Paiements =================

export async function addPayment(
  db: PoolClient,
  actor: Actor,
  p: { reservation_id: number; amount: number; method: PayMethod; kind?: 'deposit' | 'payment'; reference?: string | null; reservation_room_id?: number | null; card_last4?: string | null; card_brand?: string | null },
) {
  if (!(p.amount > 0)) throw badRequest('Montant invalide.');
  const res = await one<any>(db, 'SELECT id, guest_id, status FROM reservations WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [p.reservation_id, actor.hotelId]);
  if (!res) throw notFound('Réservation introuvable');
  if (res.status === 'cancelled' || res.status === 'no_show') {
    if ((p.kind ?? 'payment') === 'deposit') throw conflict('Réservation annulée : aucun acompte possible.');
  }
  if (p.reservation_room_id) {
    const ok = await one(db, 'SELECT 1 FROM reservation_rooms WHERE id = $1 AND reservation_id = $2', [p.reservation_room_id, p.reservation_id]);
    if (!ok) throw badRequest('Chambre inconnue pour cette réservation.');
  }
  const sessionId = await paymentRules(db, actor, { method: p.method, amount: p.amount, reference: clean(p.reference) as string | null, card_last4: p.card_last4 ?? null });
  const pay = await one<any>(
    db,
    `INSERT INTO payments (hotel_id, reservation_id, guest_id, kind, method, amount, reference, cash_session_id, received_by, reservation_room_id, card_last4, card_brand)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
    [actor.hotelId, p.reservation_id, res.guest_id, p.kind ?? 'payment', p.method, p.amount, clean(p.reference), sessionId, actor.userId, p.reservation_room_id ?? null, p.card_last4 ?? null, clean(p.card_brand)],
  );
  await refreshInvoiceStatus(db, p.reservation_id);
  await audit(db, actor, 'create', 'payment', pay.id, null, { reservation_id: p.reservation_id, amount: p.amount, method: p.method, kind: pay.kind, room: p.reservation_room_id ?? null });
  // confirmation automatique quand l'acompte requis est atteint
  const st = await one<any>(db, 'SELECT status, confirm_on_deposit, deposit_required FROM reservations WHERE id = $1', [p.reservation_id]);
  if (st.status === 'pending' && st.confirm_on_deposit) {
    const fin = await getReservation(db, actor.hotelId, p.reservation_id);
    if (Number(fin.paid) - Number(fin.refunded) >= Number(st.deposit_required) - 0.005) await confirmReservation(db, actor, p.reservation_id, { auto: true });
  }
  return pay;
}

export async function voidPayment(db: PoolClient, actor: Actor, paymentId: number, reason: string) {
  if (!reason?.trim()) throw badRequest('Le motif d\'annulation est obligatoire.');
  const p = await one<any>(db, 'SELECT * FROM payments WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [paymentId, actor.hotelId]);
  if (!p) throw notFound('Paiement introuvable');
  if (p.void) throw conflict('Paiement déjà annulé.');
  if (p.cash_session_id) {
    const cs = await one<any>(db, 'SELECT status FROM cash_sessions WHERE id = $1', [p.cash_session_id]);
    if (cs?.status === 'closed') throw conflict('Caisse déjà clôturée pour ce paiement : effectuez un remboursement.');
  }
  await db.query(`UPDATE payments SET void = true, void_reason = $2, voided_by = $3, voided_at = now() WHERE id = $1`, [paymentId, reason.trim(), actor.userId]);
  if (p.reservation_id) await refreshInvoiceStatus(db, p.reservation_id);
  else if (p.invoice_id) await (await import('./billing.js')).refreshManualInvoice(db, p.invoice_id);
  await audit(db, actor, 'void', 'payment', paymentId, { void: false, amount: Number(p.amount) }, { void: true, reason });
}

/** Statut des factures : paiements rattachés à la chambre d'abord, puis paiements communs dans l'ordre des factures. */
export async function refreshInvoiceStatus(db: PoolClient, resId: number) {
  return refreshInvoices(db, resId);
}

// ================= Housekeeping =================

/**
 * Changement manuel de l'état de propreté (écran Chambres / Housekeeping). Les transitions incohérentes sont refusées,
 * sauf pour un superviseur (housekeeping.manage) qui peut forcer — la modification est tracée.
 */
export async function setRoomHousekeeping(db: PoolClient, actor: Actor, roomId: number, status: string, perms?: Set<string>) {
  const hk = await import('./housekeeping.js');
  const room = await one<any>(db, `SELECT r.*, EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL) AS occupied
                                     FROM rooms r WHERE r.id = $1 AND r.hotel_id = $2 FOR UPDATE OF r`, [roomId, actor.hotelId]);
  if (!room) throw notFound('Chambre introuvable');
  const force = !perms || perms.has('housekeeping.manage');
  if (status === 'inspected' && perms && !perms.has('housekeeping.inspect') && !force) throw forbidden('Seul un contrôleur peut déclarer une chambre « Propre et disponible ».');
  if (room.hk_status === status) return;
  await hk.setHk(db, actor, roomId, status as any, { force, room, reason: 'Changement manuel' });
  if (status === 'cleaning') {
    const t = await one<any>(db, `SELECT id FROM housekeeping_tasks WHERE room_id = $1 AND status = 'todo' ORDER BY id LIMIT 1`, [roomId]);
    if (t) await db.query(`UPDATE housekeeping_tasks SET status = 'in_progress', started_at = now() WHERE id = $1`, [t.id]);
    else await hk.ensureTask(db, actor, roomId, room.occupied ? 'stayover' : 'checkout_clean', { source: 'manual' }).then((x: any) => db.query(`UPDATE housekeeping_tasks SET status = 'in_progress', started_at = now() WHERE id = $1`, [x.id]));
  }
  if (status === 'to_inspect') {
    await db.query(`UPDATE housekeeping_tasks SET status = 'to_inspect', completed_at = now(), completed_by = $2, started_at = COALESCE(started_at, now())
                     WHERE room_id = $1 AND status IN ('todo','in_progress')`, [roomId, actor.userId]);
  }
  if (status === 'clean' || status === 'inspected') {
    await db.query(
      `UPDATE housekeeping_tasks SET status = $3, completed_at = COALESCE(completed_at, now()), completed_by = COALESCE(completed_by, $2),
              started_at = COALESCE(started_at, now()), inspected_by = CASE WHEN $3 = 'validated' THEN $2::int END, inspected_at = CASE WHEN $3 = 'validated' THEN now() END
        WHERE room_id = $1 AND status IN ('todo','in_progress','to_inspect')`,
      [roomId, actor.userId, status === 'inspected' ? 'validated' : 'done'],
    );
  }
  if (status === 'dirty' || status === 'to_clean') await hk.ensureTask(db, actor, roomId, room.occupied ? 'stayover' : 'checkout_clean', { source: 'manual' });
}

export function ensurePerm(perms: Set<string>, p: string) {
  if (!perms.has(p)) throw forbidden(`Permission requise : ${p}`);
}
