/** Rapport mensuel de direction : configuration, aperçu PDF, envoi manuel, historique. */
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { getPool, q } from '../db/pool.js';
import { actorOf, requirePerm } from '../lib/auth.js';
import { audit } from '../lib/audit.js';
import { getSettings } from '../services/common.js';
import { monthFigures, prevMonth, reportPdf, sendMonthlyReport } from '../services/monthlyReport.js';
import { today } from '../lib/dates.js';

const Month = z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, 'Mois au format AAAA-MM');

export async function monthlyReportRoutes(app: FastifyInstance) {
  // comptabilité par mois (12 derniers mois, mois en cours inclus)
  app.get('/api/monthly-accounts', { preHandler: requirePerm('finance.reports') }, async (req) => {
    let m = today().slice(0, 7);
    const months: string[] = [];
    for (let i = 0; i < 12; i++) { months.unshift(m); m = prevMonth(m); }
    const rows = [];
    for (const x of months) {
      const f = await monthFigures(req.user!.hotelId, x);
      rows.push({ month: x, revenue: f.revenue, payments: f.payments, expenses: f.expenses, gap: f.gap, occupancy: f.occupancy, adr: f.adr });
    }
    return { months: rows };
  });

  app.get('/api/monthly-report', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const s = await getSettings(getPool(), req.user!.hotelId);
    const history = await q<any>(getPool(), `SELECT id, month, status, recipients, attempts, last_error, trigger, created_at, sent_at FROM monthly_reports WHERE hotel_id = $1 ORDER BY created_at DESC LIMIT 24`, [req.user!.hotelId]);
    return { config: { enabled: false, recipients: [], ...(s.monthly_report ?? {}) }, smtp_ready: !!s.smtp?.host, last_month: prevMonth(today().slice(0, 7)), history };
  });
  app.put('/api/monthly-report', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const b = z.object({ enabled: z.boolean(), recipients: z.array(z.string().trim().email('Adresse e-mail invalide')).max(10) }).parse(req.body);
    const before = (await getSettings(getPool(), req.user!.hotelId)).monthly_report ?? null;
    await getPool().query(`INSERT INTO settings (hotel_id, key, value, updated_at) VALUES ($1,'monthly_report',$2,now()) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`, [req.user!.hotelId, JSON.stringify(b)]);
    await audit(getPool(), actorOf(req), 'update', 'setting', 'monthly_report', before, b);
    return { ok: true };
  });
  app.get('/api/monthly-report/pdf', { preHandler: requirePerm('finance.reports') }, async (req, rep) => {
    const { month } = z.object({ month: Month }).parse(req.query);
    const { pdf } = await reportPdf(req.user!.hotelId, month);
    rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="rapport-${month}.pdf"`);
    return rep.send(pdf);
  });
  app.post('/api/monthly-report/send', { preHandler: requirePerm('settings.manage'), config: { rateLimit: { max: 5, timeWindow: '1 minute' } } }, async (req) => {
    const b = z.object({ month: Month }).parse(req.body);
    const r = await sendMonthlyReport(req.user!.hotelId, b.month, { trigger: 'manual', userId: req.user!.id });
    await audit(getPool(), actorOf(req), 'monthly_report_send', 'monthly_report', b.month, null, { to: r.to });
    return r;
  });
}
