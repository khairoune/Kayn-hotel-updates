import { assertRoleGrantable } from '../services/admin.js';
import type { FastifyInstance, FastifyReply } from 'fastify';
import { z } from 'zod';
import { getPool, one, q, tx } from '../db/pool.js';
import { audit } from '../lib/audit.js';
import { actorOf, hashPassword, requireAuth, requirePerm, validatePasswordStrength } from '../lib/auth.js';
import { isDate, monthStart, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { getSettings } from '../services/common.js';
import { tableCsv, tablePdf, tableXlsx } from '../services/exports.js';
import {
  assignTask, autoAssign, batchDetail, board, cancelTask, comment, createTask, finishTask, generateTasks, hkReport, HK_REPORTS, inspect,
  linenMove, listTasks, minibar, recordLost, returnLaundry, sendLaundry, setDnd, staffDay, startTask, updateLost,
} from '../services/housekeeping.js';

const Id = z.object({ id: z.coerce.number().int().positive() });
const zDate = z.string().refine(isDate, 'Date invalide (AAAA-MM-JJ)');
const s = (n = 500) => z.string().trim().max(n).nullish();
const Prio = z.enum(['low', 'normal', 'high', 'urgent']);
const Kind = z.enum(['checkout_clean', 'stayover', 'arrival_prep', 'deep_clean', 'inspection', 'turndown', 'other']);
const Time = z.string().regex(/^\d{2}:\d{2}$/, 'Heure invalide (HH:MM)');
const hotelName = async (id: number) => (await one<any>(getPool(), 'SELECT name FROM hotels WHERE id = $1', [id]))?.name ?? 'Hôtel';

async function sendTable(rep: FastifyReply, format: string, name: string, title: string, sub: string, cols: any[], rows: any[], hotel: string) {
  if (format === 'xlsx') {
    rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('content-disposition', `attachment; filename="${name}.xlsx"`);
    return rep.send(await tableXlsx(title, sub, cols, rows, null));
  }
  if (format === 'csv') {
    rep.header('content-type', 'text/csv; charset=utf-8').header('content-disposition', `attachment; filename="${name}.csv"`);
    return rep.send(tableCsv(cols, rows, null));
  }
  rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${name}.pdf"`);
  return rep.send(await tablePdf(hotel, title, sub, cols, rows, null));
}

export async function housekeepingRoutes(app: FastifyInstance) {
  // ===================================================== Tableau =====================================================
  app.get('/api/housekeeping/board', { preHandler: requirePerm('housekeeping.view') }, async (req) => {
    const qs = z.object({ date: zDate.optional() }).parse(req.query);
    return board(getPool(), req.user!.hotelId, qs.date ?? today());
  });

  app.post('/api/housekeeping/generate', { preHandler: requirePerm('housekeeping.manage') }, async (req) => {
    const b = z.object({ date: zDate.optional() }).parse(req.body ?? {});
    return tx((c) => generateTasks(c, actorOf(req), b.date ?? today()));
  });

  app.post('/api/housekeeping/auto-assign', { preHandler: requirePerm('housekeeping.manage') }, async (req) => {
    const b = z.object({ date: zDate.optional() }).parse(req.body ?? {});
    return tx((c) => autoAssign(c, actorOf(req), b.date ?? today()));
  });

  // ===================================================== Tâches =====================================================
  app.get('/api/housekeeping/tasks', { preHandler: requirePerm('housekeeping.view') }, async (req) => {
    const qs = z.object({
      date: zDate.optional(), status: z.enum(['todo', 'in_progress', 'done', 'to_inspect', 'validated', 'cancelled']).optional(),
      employee_id: z.coerce.number().int().positive().optional(), mine: z.enum(['1', 'true']).optional(), unassigned: z.enum(['1', 'true']).optional(),
    }).parse(req.query);
    // une femme de chambre (sans droit de supervision) ne voit que ses propres tâches
    const onlyMine = !!qs.mine || !req.user!.perms.has('housekeeping.manage') && !req.user!.perms.has('housekeeping.inspect');
    return listTasks(getPool(), req.user!.hotelId, { date: qs.date, status: qs.status, employee_id: qs.employee_id ?? null, mine_user: onlyMine ? req.user!.id : null, unassigned: !!qs.unassigned });
  });

  app.get('/api/housekeeping/tasks/:id', { preHandler: requirePerm('housekeeping.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    const t = await one<any>(getPool(), `SELECT t.*, r.number AS room_number, r.hk_status, r.dnd, e.first_name || ' ' || e.last_name AS assignee
        FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id LEFT JOIN employees e ON e.id = t.assigned_to WHERE t.id = $1 AND r.hotel_id = $2`, [id, req.user!.hotelId]);
    if (!t) throw notFound('Tâche introuvable');
    const comments = await q(getPool(), `SELECT c.*, u.full_name AS author FROM hk_task_comments c LEFT JOIN users u ON u.id = c.created_by WHERE c.task_id = $1 ORDER BY c.id`, [id]);
    const inspections = await q(getPool(), `SELECT i.*, u.full_name AS inspector, (SELECT array_agg(p.id) FROM photos p WHERE p.owner_type = 'inspection' AND p.owner_id = i.id) AS photos
        FROM hk_inspections i JOIN users u ON u.id = i.inspector_id WHERE i.task_id = $1 ORDER BY i.id`, [id]);
    const history = await q(getPool(), `SELECT a.created_at, a.action, a.before, a.after, u.full_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
        WHERE a.entity = 'hk_task' AND a.entity_id = $1 ORDER BY a.id`, [String(id)]);
    return { ...t, comments, inspections, history };
  });

  app.post('/api/housekeeping/tasks', { preHandler: requirePerm('housekeeping.manage') }, async (req, rep) => {
    const b = z.object({ room_id: z.number().int().positive(), kind: Kind, priority: Prio.optional(), due_at: z.string().max(40).nullish(), employee_id: z.number().int().positive().nullish(), notes: s(1000), task_date: zDate.nullish() }).parse(req.body);
    const t = await tx((c) => createTask(c, actorOf(req), b));
    rep.code(201);
    return t;
  });

  app.post('/api/housekeeping/tasks/:id/assign', { preHandler: requirePerm('housekeeping.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ employee_id: z.number().int().positive().nullable() }).parse(req.body);
    await tx((c) => assignTask(c, actorOf(req), id, b.employee_id));
    return { ok: true };
  });

  app.patch('/api/housekeeping/tasks/:id', { preHandler: requirePerm('housekeeping.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ priority: Prio.optional(), due_at: z.string().max(40).nullish(), notes: s(1000) }).parse(req.body);
    return tx(async (c) => {
      const t = await one<any>(c, `SELECT t.* FROM housekeeping_tasks t JOIN rooms r ON r.id = t.room_id WHERE t.id = $1 AND r.hotel_id = $2 FOR UPDATE OF t`, [id, req.user!.hotelId]);
      if (!t) throw notFound('Tâche introuvable');
      if (!['todo', 'in_progress'].includes(t.status)) throw conflict('Tâche terminée : modification impossible.');
      await c.query(`UPDATE housekeeping_tasks SET priority = COALESCE($2, priority), due_at = CASE WHEN $3::boolean THEN $4::timestamptz ELSE due_at END, notes = COALESCE($5, notes) WHERE id = $1`,
        [id, b.priority ?? null, b.due_at !== undefined, b.due_at ?? null, b.notes ?? null]);
      await audit(c, actorOf(req), 'update', 'hk_task', id, { priority: t.priority, due_at: t.due_at }, b);
      return { ok: true };
    });
  });

  for (const action of ['start', 'finish'] as const) {
    app.post(`/api/housekeeping/tasks/:id/${action}`, { preHandler: requirePerm('housekeeping.update') }, async (req) => {
      const { id } = Id.parse(req.params);
      const b = z.object({ note: s(1000) }).parse(req.body ?? {});
      return tx<any>((c) => (action === 'start' ? startTask(c, actorOf(req), req.user!.perms, id) : finishTask(c, actorOf(req), req.user!.perms, id, b.note)));
    });
  }

  app.post('/api/housekeeping/tasks/:id/cancel', { preHandler: requirePerm('housekeeping.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(3).max(300) }).parse(req.body);
    await tx((c) => cancelTask(c, actorOf(req), id, b.reason));
    return { ok: true };
  });

  app.post('/api/housekeeping/tasks/:id/comments', { preHandler: requirePerm('housekeeping.update') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ kind: z.enum(['comment', 'issue']), text: z.string().trim().min(2).max(1000), priority: Prio.optional() }).parse(req.body);
    const r = await tx((c) => comment(c, actorOf(req), req.user!.perms, id, b));
    rep.code(201);
    return r;
  });

  app.post('/api/housekeeping/tasks/:id/minibar', { preHandler: requirePerm('housekeeping.minibar') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ lines: z.array(z.object({ service_id: z.number().int().positive(), quantity: z.number().int().min(0).max(50) })).min(1).max(30) }).parse(req.body);
    const r = await tx((c) => minibar(c, actorOf(req), id, b.lines));
    rep.code(201);
    return r;
  });

  app.get('/api/housekeeping/minibar-items', { preHandler: requirePerm('housekeeping.minibar') }, async (req) =>
    q(getPool(), `SELECT id, code, name, price FROM services WHERE hotel_id = $1 AND active AND category = 'minibar' ORDER BY sort_order, name`, [req.user!.hotelId]));

  app.post('/api/rooms/:id/dnd', { preHandler: requirePerm('housekeeping.dnd') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ on: z.boolean() }).parse(req.body);
    await tx((c) => setDnd(c, actorOf(req), id, b.on));
    return { ok: true };
  });

  // ===================================================== Inspection =====================================================
  app.get('/api/housekeeping/checklist', { preHandler: requirePerm('housekeeping.view') }, async (req) => {
    const qs = z.object({ all: z.enum(['1']).optional() }).parse(req.query);
    return q(getPool(), `SELECT * FROM hk_checklist_items WHERE hotel_id = $1 ${qs.all ? '' : 'AND active'} ORDER BY sort_order, id`, [req.user!.hotelId]);
  });

  const Item = z.object({ category: z.string().trim().min(1).max(60), label: z.string().trim().min(2).max(200), critical: z.boolean().default(false), active: z.boolean().default(true), sort_order: z.number().int().min(0).max(999).optional() });
  app.post('/api/housekeeping/checklist', { preHandler: requirePerm('housekeeping.manage') }, async (req, rep) => {
    const b = Item.parse(req.body);
    const r = await one<any>(getPool(), `INSERT INTO hk_checklist_items (hotel_id, category, label, critical, active, sort_order)
        VALUES ($1,$2,$3,$4,$5,COALESCE($6,(SELECT COALESCE(max(sort_order),0)+1 FROM hk_checklist_items WHERE hotel_id = $1))) RETURNING *`,
      [req.user!.hotelId, b.category, b.label, b.critical, b.active, b.sort_order ?? null]);
    await audit(getPool(), actorOf(req), 'create', 'hk_checklist', r.id, null, b);
    rep.code(201);
    return r;
  });
  app.patch('/api/housekeeping/checklist/:id', { preHandler: requirePerm('housekeeping.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = Item.partial().parse(req.body);
    const before = await one<any>(getPool(), 'SELECT * FROM hk_checklist_items WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!before) throw notFound('Point de contrôle introuvable');
    const r = await one<any>(getPool(), `UPDATE hk_checklist_items SET category = COALESCE($2, category), label = COALESCE($3, label), critical = COALESCE($4, critical),
        active = COALESCE($5, active), sort_order = COALESCE($6, sort_order) WHERE id = $1 RETURNING *`, [id, b.category ?? null, b.label ?? null, b.critical ?? null, b.active ?? null, b.sort_order ?? null]);
    await audit(getPool(), actorOf(req), 'update', 'hk_checklist', id, before, r);
    return r;
  });

  app.post('/api/housekeeping/inspections', { preHandler: requirePerm('housekeeping.inspect') }, async (req, rep) => {
    const b = z.object({
      room_id: z.number().int().positive(), decision: z.enum(['pass', 'fail']), remarks: s(2000), create_ticket: z.boolean().optional(),
      items: z.array(z.object({ item_id: z.number().int().positive(), ok: z.boolean(), comment: s(300) })).max(100),
    }).parse(req.body);
    const r = await tx((c) => inspect(c, actorOf(req), b));
    rep.code(201);
    return r;
  });

  app.get('/api/housekeeping/inspections', { preHandler: requirePerm('housekeeping.view') }, async (req) => {
    const qs = z.object({ room_id: z.coerce.number().int().positive().optional(), from: zDate.optional(), to: zDate.optional() }).parse(req.query);
    return q(getPool(), `SELECT i.*, r.number AS room, u.full_name AS inspector, uc.full_name AS cleaner,
        (SELECT array_agg(p.id ORDER BY p.id) FROM photos p WHERE p.owner_type = 'inspection' AND p.owner_id = i.id) AS photos
       FROM hk_inspections i JOIN rooms r ON r.id = i.room_id JOIN users u ON u.id = i.inspector_id
       LEFT JOIN housekeeping_tasks t ON t.id = i.task_id LEFT JOIN users uc ON uc.id = t.completed_by
      WHERE r.hotel_id = $1 AND ($2::int IS NULL OR i.room_id = $2) AND (i.created_at AT TIME ZONE 'Africa/Algiers')::date BETWEEN $3 AND $4
      ORDER BY i.created_at DESC LIMIT 300`, [req.user!.hotelId, qs.room_id ?? null, qs.from ?? today(), qs.to ?? today()]);
  });

  // ===================================================== Personnel =====================================================
  app.get('/api/housekeeping/staff', { preHandler: requirePerm('housekeeping.view') }, async (req) => {
    const qs = z.object({ date: zDate.optional() }).parse(req.query);
    return staffDay(getPool(), req.user!.hotelId, qs.date ?? today());
  });

  const Emp = z.object({ first_name: z.string().trim().min(1).max(60), last_name: z.string().trim().min(1).max(60), position: s(80), phone: s(40), max_rooms: z.number().int().min(1).max(40).optional(), active: z.boolean().optional() });
  app.post('/api/housekeeping/staff', { preHandler: requirePerm('housekeeping.manage') }, async (req, rep) => {
    const b = Emp.extend({
      access: z.object({ username: z.string().trim().min(3).max(40).regex(/^[a-z0-9._-]+$/i, 'Identifiant : lettres, chiffres, . _ -'), password: z.string().min(8).max(100), role: z.enum(['housekeeping', 'hk_supervisor']).default('housekeeping') }).nullish(),
    }).parse(req.body);
    if (b.access && !req.user!.perms.has('users.manage')) throw forbidden('Créer un accès au logiciel nécessite le droit « Gérer les utilisateurs ».');
    const r = await tx(async (c) => {
      const e = await one<any>(c, `INSERT INTO employees (hotel_id, first_name, last_name, position, department, phone, hire_date, max_rooms) VALUES ($1,$2,$3,$4,'housekeeping',$5,CURRENT_DATE,COALESCE($6,14)) RETURNING *`,
        [req.user!.hotelId, b.first_name, b.last_name, b.position ?? 'Femme de chambre', b.phone ?? null, b.max_rooms ?? null]);
      if (b.access) {
        const weak = validatePasswordStrength(b.access.password);
        if (weak) throw badRequest(weak);
        if (await one(c, 'SELECT 1 FROM users WHERE lower(username) = lower($1)', [b.access.username])) throw conflict('Identifiant déjà utilisé.');
        const role = await assertRoleGrantable(c, req.user!, b.access.role);
        await c.query(`INSERT INTO users (hotel_id, username, full_name, password_hash, role_id, employee_id, must_change_password) VALUES ($1,$2,$3,$4,$5,$6,true)`,
          [req.user!.hotelId, b.access.username, `${b.first_name} ${b.last_name}`, await hashPassword(b.access.password), role.id, e.id]);
      }
      await audit(c, actorOf(req), 'create', 'employee', e.id, null, { name: `${b.first_name} ${b.last_name}`, access: b.access?.username ?? null });
      return e;
    });
    rep.code(201);
    return r;
  });

  app.patch('/api/housekeeping/staff/:id', { preHandler: requirePerm('housekeeping.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = Emp.partial().parse(req.body);
    const before = await one<any>(getPool(), `SELECT * FROM employees WHERE id = $1 AND hotel_id = $2 AND department = 'housekeeping'`, [id, req.user!.hotelId]);
    if (!before) throw notFound('Employé introuvable');
    const r = await one<any>(getPool(), `UPDATE employees SET first_name = COALESCE($2, first_name), last_name = COALESCE($3, last_name), position = COALESCE($4, position),
        phone = COALESCE($5, phone), max_rooms = COALESCE($6, max_rooms), active = COALESCE($7, active) WHERE id = $1 RETURNING *`,
      [id, b.first_name ?? null, b.last_name ?? null, b.position ?? null, b.phone ?? null, b.max_rooms ?? null, b.active ?? null]);
    await audit(getPool(), actorOf(req), 'update', 'employee', id, before, r);
    return r;
  });

  /** Planning du jour : horaires, zone. Pointage (début/fin réels). */
  app.put('/api/housekeeping/shifts', { preHandler: requirePerm('housekeeping.manage') }, async (req) => {
    const b = z.object({ employee_id: z.number().int().positive(), work_date: zDate, start_time: Time.nullish(), end_time: Time.nullish(), zone: s(80), notes: s(300), off: z.boolean().optional() }).parse(req.body);
    const e = await one(getPool(), `SELECT 1 FROM employees WHERE id = $1 AND hotel_id = $2`, [b.employee_id, req.user!.hotelId]);
    if (!e) throw notFound('Employé introuvable');
    if (b.start_time && b.end_time && b.end_time <= b.start_time) throw badRequest('L\'heure de fin doit être après l\'heure de début.');
    if (b.off) {
      const open = await one(getPool(), `SELECT 1 FROM housekeeping_tasks WHERE assigned_to = $1 AND task_date = $2 AND status IN ('todo','in_progress')`, [b.employee_id, b.work_date]);
      if (open) throw conflict('Réaffectez d\'abord les tâches de cet employé.');
      await getPool().query('DELETE FROM hk_shifts WHERE employee_id = $1 AND work_date = $2 AND started_at IS NULL', [b.employee_id, b.work_date]);
      return { ok: true };
    }
    const r = await one(getPool(), `INSERT INTO hk_shifts (employee_id, work_date, start_time, end_time, zone, notes) VALUES ($1,$2,$3,$4,$5,$6)
        ON CONFLICT (employee_id, work_date) DO UPDATE SET start_time = EXCLUDED.start_time, end_time = EXCLUDED.end_time, zone = EXCLUDED.zone, notes = EXCLUDED.notes RETURNING *`,
      [b.employee_id, b.work_date, b.start_time ?? '08:00', b.end_time ?? '16:00', b.zone ?? null, b.notes ?? null]);
    await audit(getPool(), actorOf(req), 'shift', 'employee', b.employee_id, null, b);
    return r;
  });

  app.post('/api/housekeeping/shifts/clock', { preHandler: requirePerm('housekeeping.update') }, async (req) => {
    const b = z.object({ employee_id: z.number().int().positive().optional(), action: z.enum(['in', 'out']) }).parse(req.body);
    const own = (await one<any>(getPool(), 'SELECT employee_id FROM users WHERE id = $1', [req.user!.id]))?.employee_id;
    const emp = b.employee_id ?? own;
    if (!emp) throw badRequest('Aucun employé associé à cet utilisateur.');
    if (emp !== own && !req.user!.perms.has('housekeeping.manage')) throw forbidden();
    const d = today();
    const sh = await one<any>(getPool(), `INSERT INTO hk_shifts (employee_id, work_date, start_time, end_time) SELECT $1, $2, '08:00', '16:00' WHERE EXISTS (SELECT 1 FROM employees WHERE id = $1 AND hotel_id = $3)
        ON CONFLICT (employee_id, work_date) DO UPDATE SET employee_id = EXCLUDED.employee_id RETURNING *`, [emp, d, req.user!.hotelId]);
    if (!sh) throw notFound('Employé introuvable');
    if (b.action === 'in' && sh.started_at) throw conflict('Arrivée déjà pointée.');
    if (b.action === 'out' && !sh.started_at) throw conflict('Pointez d\'abord l\'arrivée.');
    if (b.action === 'out' && sh.ended_at) throw conflict('Départ déjà pointé.');
    await getPool().query(`UPDATE hk_shifts SET ${b.action === 'in' ? 'started_at' : 'ended_at'} = now() WHERE id = $1`, [sh.id]);
    await audit(getPool(), actorOf(req), `clock_${b.action}`, 'employee', emp, null, { date: d });
    return { ok: true };
  });

  // ===================================================== Linge =====================================================
  app.get('/api/linen', { preHandler: requirePerm('housekeeping.view') }, async (req) =>
    q(getPool(), `SELECT *, (qty_clean < par_level) AS below_par FROM linen_items WHERE hotel_id = $1 ORDER BY active DESC, category, name`, [req.user!.hotelId]));

  const Linen = z.object({ code: z.string().trim().min(1).max(20), name: z.string().trim().min(2).max(80), category: z.enum(['bed', 'bath', 'table', 'other']).default('bed'), par_level: z.number().int().min(0).max(100000).default(0), unit_cost: z.number().min(0).max(1_000_000).default(0), active: z.boolean().optional() });
  app.post('/api/linen', { preHandler: requirePerm('linen.manage') }, async (req, rep) => {
    const b = Linen.parse(req.body);
    const r = await one<any>(getPool(), `INSERT INTO linen_items (hotel_id, code, name, category, par_level, unit_cost) VALUES ($1,upper($2),$3,$4,$5,$6) RETURNING *`,
      [req.user!.hotelId, b.code, b.name, b.category, b.par_level, b.unit_cost]);
    await audit(getPool(), actorOf(req), 'create', 'linen_item', r.id, null, b);
    rep.code(201);
    return r;
  });
  app.patch('/api/linen/:id', { preHandler: requirePerm('linen.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = Linen.partial().parse(req.body);
    const before = await one<any>(getPool(), 'SELECT * FROM linen_items WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!before) throw notFound('Article introuvable');
    const r = await one<any>(getPool(), `UPDATE linen_items SET name = COALESCE($2, name), category = COALESCE($3, category), par_level = COALESCE($4, par_level),
        unit_cost = COALESCE($5, unit_cost), active = COALESCE($6, active) WHERE id = $1 RETURNING *`, [id, b.name ?? null, b.category ?? null, b.par_level ?? null, b.unit_cost ?? null, b.active ?? null]);
    await audit(getPool(), actorOf(req), 'update', 'linen_item', id, before, r);
    return r;
  });

  app.post('/api/linen/movements', { preHandler: requirePerm('linen.manage') }, async (req, rep) => {
    const b = z.object({
      item_id: z.number().int().positive(), kind: z.enum(['purchase', 'issue', 'collect', 'discard', 'adjust']), quantity: z.number().int().min(-100000).max(100000),
      room_id: z.number().int().positive().nullish(), reason: s(300), from: z.enum(['clean', 'dirty', 'in_use', 'laundry']).optional(),
    }).parse(req.body);
    const r = await tx((c) => linenMove(c, actorOf(req), b));
    rep.code(201);
    return r;
  });

  app.get('/api/linen/movements', { preHandler: requirePerm('housekeeping.view') }, async (req) => {
    const qs = z.object({ item_id: z.coerce.number().int().positive().optional(), from: zDate.optional(), to: zDate.optional() }).parse(req.query);
    return q(getPool(), `SELECT m.*, i.name AS item, r.number AS room, b.ref AS batch, u.full_name AS user_name FROM linen_movements m JOIN linen_items i ON i.id = m.item_id
        LEFT JOIN rooms r ON r.id = m.room_id LEFT JOIN linen_batches b ON b.id = m.batch_id LEFT JOIN users u ON u.id = m.created_by
       WHERE i.hotel_id = $1 AND ($2::int IS NULL OR m.item_id = $2) AND (m.created_at AT TIME ZONE 'Africa/Algiers')::date BETWEEN $3 AND $4 ORDER BY m.id DESC LIMIT 500`,
      [req.user!.hotelId, qs.item_id ?? null, qs.from ?? monthStart(today()), qs.to ?? today()]);
  });

  app.get('/api/linen/batches', { preHandler: requirePerm('housekeeping.view') }, async (req) =>
    q(getPool(), `SELECT b.*, u.full_name AS sent_by_name,
        (SELECT COALESCE(sum(quantity),0) FROM linen_movements m WHERE m.batch_id = b.id AND m.kind = 'send_laundry')::int AS sent,
        (SELECT COALESCE(sum(quantity),0) FROM linen_movements m WHERE m.batch_id = b.id AND m.kind = 'return_laundry')::int AS returned
       FROM linen_batches b LEFT JOIN users u ON u.id = b.sent_by WHERE b.hotel_id = $1 ORDER BY b.status <> 'returned' DESC, b.sent_at DESC LIMIT 200`, [req.user!.hotelId]));

  app.get('/api/linen/batches/:id', { preHandler: requirePerm('housekeeping.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    return batchDetail(getPool(), req.user!.hotelId, id);
  });

  app.post('/api/linen/batches', { preHandler: requirePerm('linen.manage') }, async (req, rep) => {
    const b = z.object({ provider: s(120), notes: s(300), lines: z.array(z.object({ item_id: z.number().int().positive(), quantity: z.number().int().min(0).max(100000) })).min(1).max(50) }).parse(req.body);
    const r = await tx((c) => sendLaundry(c, actorOf(req), b));
    rep.code(201);
    return r;
  });

  app.post('/api/linen/batches/:id/return', { preHandler: requirePerm('linen.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({
      lines: z.array(z.object({ item_id: z.number().int().positive(), quantity: z.number().int().min(0).max(100000) })).max(50), close: z.boolean().optional(),
      cost: z.number().min(0).max(100_000_000).nullish(), method: z.enum(['cash', 'card', 'cheque', 'transfer']).optional(),
    }).parse(req.body);
    return tx((c) => returnLaundry(c, actorOf(req), id, b));
  });

  // ===================================================== Objets trouvés =====================================================
  app.get('/api/lost-found', { preHandler: requireAuth }, async (req) => {
    if (!req.user!.perms.has('lostfound.record') && !req.user!.perms.has('lostfound.manage')) throw forbidden();
    const qs = z.object({ status: z.enum(['pending', 'stored', 'returned', 'archived']).optional(), search: z.string().max(80).default('') }).parse(req.query);
    return q(getPool(), `SELECT l.*, r.number AS room, u.full_name AS recorded_by_name, ur.full_name AS returned_by_name,
        g.kind AS g_kind, g.last_name AS g_last, g.first_name AS g_first, g.company_name AS g_company, g.phone AS g_phone,
        (SELECT array_agg(p.id ORDER BY p.id) FROM photos p WHERE p.owner_type = 'lost_item' AND p.owner_id = l.id) AS photos
       FROM lost_items l LEFT JOIN rooms r ON r.id = l.room_id LEFT JOIN users u ON u.id = l.recorded_by LEFT JOIN users ur ON ur.id = l.returned_by LEFT JOIN guests g ON g.id = l.guest_id
      WHERE l.hotel_id = $1 AND ($2::text IS NULL OR l.status = $2)
        AND ($3 = '' OR lower(l.ref || ' ' || l.description || ' ' || coalesce(r.number,'') || ' ' || coalesce(l.location,'')) LIKE $4)
      ORDER BY l.found_at DESC LIMIT 300`, [req.user!.hotelId, qs.status ?? null, qs.search.trim(), `%${qs.search.trim().toLowerCase()}%`]);
  });

  app.post('/api/lost-found', { preHandler: requirePerm('lostfound.record') }, async (req, rep) => {
    const b = z.object({
      room_id: z.number().int().positive().nullish(), location: s(120), category: z.enum(['clothing', 'electronics', 'documents', 'jewelry', 'money', 'keys', 'bag', 'other']),
      description: z.string().trim().min(3).max(500), found_by_name: z.string().trim().min(2).max(100), found_at: z.string().max(40).nullish(), value_note: s(200),
    }).parse(req.body);
    if (!b.room_id && !b.location) throw badRequest('Indiquez la chambre ou le lieu.');
    const r = await tx((c) => recordLost(c, actorOf(req), b));
    rep.code(201);
    return r;
  });

  app.post('/api/lost-found/:id/status', { preHandler: requirePerm('lostfound.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ status: z.enum(['stored', 'returned', 'archived']), storage_location: s(120), returned_to: s(200), reason: s(300), notes: s(500) }).parse(req.body);
    await tx((c) => updateLost(c, actorOf(req), id, b));
    return { ok: true };
  });

  // ===================================================== Rapports & réglages =====================================================
  app.get('/api/housekeeping/reports/:kind', { preHandler: requirePerm('housekeeping.reports') }, async (req, rep) => {
    const { kind } = z.object({ kind: z.enum(Object.keys(HK_REPORTS) as [string, ...string[]]) }).parse(req.params);
    const qs = z.object({ from: zDate.optional(), to: zDate.optional(), format: z.enum(['json', 'pdf', 'xlsx', 'csv']).default('json') }).parse(req.query);
    const from = qs.from ?? monthStart(today()), to = qs.to ?? today();
    if (from > to) throw badRequest('Période invalide.');
    const r = await hkReport(getPool(), req.user!.hotelId, kind, from, to);
    if (qs.format === 'json') return r;
    return sendTable(rep, qs.format, `menage-${kind}-${from}-${to}`, r.title, `Du ${from} au ${to}`, r.columns, r.rows, await hotelName(req.user!.hotelId));
  });

  app.get('/api/housekeeping/settings', { preHandler: requirePerm('housekeeping.view') }, async (req) => (await getSettings(getPool(), req.user!.hotelId)).housekeeping);

  app.put('/api/housekeeping/settings', { preHandler: requirePerm('housekeeping.manage') }, async (req) => {
    const b = z.object({
      inspection_required: z.boolean(), stayover_daily: z.boolean(), min_score: z.number().int().min(0).max(100),
      minutes: z.record(Kind, z.number().int().min(1).max(600)),
    }).parse(req.body);
    const cur = (await getSettings(getPool(), req.user!.hotelId)).housekeeping;
    const v = { ...cur, ...b, minutes: { ...cur.minutes, ...b.minutes } };
    await getPool().query(`INSERT INTO settings (hotel_id, key, value) VALUES ($1,'housekeeping',$2) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value`, [req.user!.hotelId, JSON.stringify(v)]);
    await audit(getPool(), actorOf(req), 'update', 'settings', 'housekeeping', cur, v);
    return v;
  });
}
