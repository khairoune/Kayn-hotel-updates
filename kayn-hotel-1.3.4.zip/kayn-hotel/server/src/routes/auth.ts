import { getSettings } from '../services/common.js';
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { config } from '../config.js';
import { getPool, one, q, tx } from '../db/pool.js';
import { audit } from '../lib/audit.js';
import {
  DEVICE_COOKIE, SESSION_COOKIE, actorOf, cookieOpts, createSession, hashPassword, loadUserFromRequest, newToken, requireAuth, requirePerm,
  securityOf, sha256, validatePasswordStrength, verifyPassword,
} from '../lib/auth.js';
import { notify } from '../services/notify.js';
import { AppError, badRequest, notFound, unauthorized } from '../lib/errors.js';

const LoginBody = z.object({ username: z.string().min(1).max(60), password: z.string().min(1).max(200), device_name: z.string().max(60).optional() });

export async function authRoutes(app: FastifyInstance) {
  app.post('/api/auth/login', { config: { rateLimit: { max: 10, timeWindow: '1 minute', hook: 'preHandler', keyGenerator: (req: any) => `${req.ip}|${String(req.body?.username ?? '').toLowerCase().slice(0, 60)}` } } }, async (req, rep) => {
    const body = LoginBody.parse(req.body);
    const pool = getPool();
    const user = await one<any>(pool, `SELECT u.*, r.code AS role FROM users u JOIN roles r ON r.id = u.role_id WHERE lower(u.username) = lower($1)`, [body.username.trim()]);
    const ua = String(req.headers['user-agent'] ?? '');
    if (!user) {
      await audit(pool, null, 'login_failed', 'user', null, null, { username: body.username, reason: 'unknown_user', ip: req.ip }, { result: 'failure', userAgent: ua });
      throw unauthorized('Identifiant ou mot de passe incorrect.');
    }
    if (!user.active) {
      // compte désactivé : refus, sans révéler l'existence du compte au-delà du message générique
      await audit(pool, { userId: user.id, hotelId: user.hotel_id, ip: req.ip }, 'login_failed', 'user', user.id, null, { reason: 'disabled' }, { result: 'failure', userAgent: ua });
      throw unauthorized('Identifiant ou mot de passe incorrect.');
    }
    const sec = await securityOf(user.hotel_id);
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      await audit(pool, { userId: user.id, hotelId: user.hotel_id, ip: req.ip }, 'login_failed', 'user', user.id, null, { reason: 'locked' }, { result: 'failure', userAgent: ua });
      throw new AppError(423, 'locked', `Compte verrouillé temporairement après plusieurs échecs. Réessayez dans ${sec.lock_minutes} minutes ou demandez un code de réinitialisation.`);
    }
    if (!(await verifyPassword(body.password, user.password_hash))) {
      const fails = user.failed_logins + 1;
      const lock = fails >= Number(sec.max_failed_logins);
      await pool.query(
        `UPDATE users SET failed_logins = $2, locked_until = CASE WHEN $3 THEN now() + ($4 || ' minutes')::interval ELSE NULL END WHERE id = $1`,
        [user.id, lock ? 0 : fails, lock, String(sec.lock_minutes)],
      );
      await audit(pool, { userId: user.id, hotelId: user.hotel_id, ip: req.ip }, 'login_failed', 'user', user.id, null, { reason: lock ? 'locked_now' : 'bad_password', attempts: fails }, { result: 'failure', userAgent: ua });
      if (lock) await notify(pool, user.hotel_id, 'security', { title: `Compte verrouillé : ${user.username}`, body: `${fails} échecs de connexion (poste ${req.ip})`, link: '/admin?s=users', severity: 'danger', dedupe: `lock:${user.id}:${Date.now()}` });
      throw unauthorized('Identifiant ou mot de passe incorrect.');
    }

    // ===== Appareil =====
    let deviceToken = req.cookies[DEVICE_COOKIE];
    let device = deviceToken ? await one<any>(pool, 'SELECT * FROM devices WHERE fingerprint = $1', [sha256(deviceToken)]) : null;
    if (!device) {
      deviceToken = newToken();
      const anyApproved = await one(pool, `SELECT 1 FROM devices WHERE hotel_id = $1 AND status = 'approved'`, [user.hotel_id]);
      const autoApprove = !config.requireDeviceApproval || !anyApproved || ['admin', 'tech_admin'].includes(user.role);
      device = await one<any>(
        pool,
        `INSERT INTO devices (hotel_id, name, fingerprint, status, approved_by, approved_at) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
        [user.hotel_id, body.device_name?.trim() || `Poste ${String(req.headers['user-agent'] ?? '').slice(0, 40)}`, sha256(deviceToken),
          autoApprove ? 'approved' : 'pending', autoApprove ? user.id : null, autoApprove ? new Date() : null],
      );
      rep.setCookie(DEVICE_COOKIE, deviceToken, cookieOpts(10 * 365 * 24 * 3600));
    } else if (device.status === 'pending' && ['admin', 'tech_admin'].includes(user.role)) {
      device = await one<any>(pool, `UPDATE devices SET status = 'approved', approved_by = $2, approved_at = now() WHERE id = $1 RETURNING *`, [device.id, user.id]);
    }
    if (device.status === 'revoked') throw new AppError(403, 'device_revoked', 'Cet appareil a été bloqué par l\'administrateur.');
    if (device.status === 'pending') {
      throw new AppError(403, 'device_pending', `Appareil en attente d'approbation (n° ${device.id}). Demandez à l'administrateur de l'approuver.`);
    }
    await pool.query(`UPDATE devices SET last_seen_at = now() WHERE id = $1`, [device.id]);
    await pool.query(`UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = now() WHERE id = $1`, [user.id]);
    const token = await createSession(user.id, device.id, req);
    rep.setCookie(SESSION_COOKIE, token, cookieOpts(config.sessionHours * 3600));
    await audit(pool, { userId: user.id, hotelId: user.hotel_id, deviceId: device.id, ip: req.ip }, 'login', 'user', user.id, null, null, { userAgent: ua });
    return { ok: true, must_change_password: user.must_change_password };
  });

  app.post('/api/auth/logout', async (req, rep) => {
    const token = req.cookies[SESSION_COOKIE];
    const u = token ? await loadUserFromRequest(req).catch(() => null) : null;
    if (u) await audit(getPool(), { userId: u.id, hotelId: u.hotelId, deviceId: u.deviceId, ip: req.ip }, 'logout', 'user', u.id);
    if (token) await getPool().query('UPDATE sessions SET revoked = true WHERE id = $1', [sha256(token)]);
    rep.clearCookie(SESSION_COOKIE, { path: '/' });
    return { ok: true };
  });

  app.get('/api/auth/me', { preHandler: requireAuth }, async (req) => {
    const u = req.user!;
    const hotel = await one<any>(getPool(), 'SELECT id, name, commercial_name, city, currency, currency_symbol, logo_id, primary_language, languages, date_format, time_format, timezone FROM hotels WHERE id = $1', [u.hotelId]);
    const device = u.deviceId ? await one<any>(getPool(), 'SELECT id, name FROM devices WHERE id = $1', [u.deviceId]) : null;
    return {
      id: u.id, username: u.username, full_name: u.fullName, role: u.role, role_name: u.roleName, language: u.language,
      must_change_password: u.mustChangePassword, permissions: [...u.perms], hotel: { ...hotel, decimals: (await getSettings(getPool(), u.hotelId)).rounding?.decimals ?? 2 }, device,
    };
  });

  app.post('/api/auth/change-password', { preHandler: requireAuth }, async (req) => {
    const b = z.object({ current: z.string(), next: z.string().max(200) }).parse(req.body);
    const err = validatePasswordStrength(b.next, (await securityOf(req.user!.hotelId)).password_min_length);
    if (err) throw badRequest(err);
    const u = await one<any>(getPool(), 'SELECT password_hash FROM users WHERE id = $1', [req.user!.id]);
    if (!(await verifyPassword(b.current, u.password_hash))) throw badRequest('Mot de passe actuel incorrect.');
    if (await verifyPassword(b.next, u.password_hash)) throw badRequest('Le nouveau mot de passe doit être différent de l\'actuel.');
    await getPool().query('UPDATE users SET password_hash = $2, must_change_password = false, password_changed_at = now() WHERE id = $1', [req.user!.id, await hashPassword(b.next)]);
    // déconnecte les autres sessions
    await getPool().query('UPDATE sessions SET revoked = true WHERE user_id = $1 AND id <> $2', [req.user!.id, sha256(req.cookies[SESSION_COOKIE]!)]);
    await audit(getPool(), actorOf(req), 'change_password', 'user', req.user!.id);
    return { ok: true };
  });

  /**
   * Réinitialisation sécurisée sans Internet : l'administrateur génère un code à usage unique (valable quelques minutes,
   * stocké haché) qu'il remet à l'utilisateur ; celui-ci choisit lui-même son nouveau mot de passe (l'administrateur ne le connaît jamais).
   */
  app.post('/api/auth/reset-password', { config: { rateLimit: { max: 10, timeWindow: '15 minutes' } } }, async (req) => {
    const b = z.object({ username: z.string().min(1).max(60), code: z.string().min(6).max(20), password: z.string().max(200) }).parse(req.body);
    const pool = getPool();
    const u = await one<any>(pool, `SELECT * FROM users WHERE lower(username) = lower($1)`, [b.username.trim()]);
    const fail = async (reason: string) => {
      if (u) {
        await pool.query('UPDATE users SET reset_attempts = reset_attempts + 1, reset_code_hash = CASE WHEN reset_attempts + 1 >= 5 THEN NULL ELSE reset_code_hash END WHERE id = $1', [u.id]);
        await audit(pool, { userId: u.id, hotelId: u.hotel_id, ip: req.ip }, 'password_reset_failed', 'user', u.id, null, { reason }, { result: 'failure' });
      }
      throw badRequest('Code de réinitialisation invalide ou expiré.');
    };
    if (!u || !u.active || !u.reset_code_hash || !u.reset_expires_at || new Date(u.reset_expires_at) < new Date()) return fail('expired_or_missing');
    if (sha256(b.code.trim().toUpperCase()) !== u.reset_code_hash) return fail('bad_code');
    const err = validatePasswordStrength(b.password, (await securityOf(u.hotel_id)).password_min_length);
    if (err) throw badRequest(err);
    await tx(async (c) => {
      await c.query(`UPDATE users SET password_hash = $2, must_change_password = false, password_changed_at = now(), reset_code_hash = NULL, reset_expires_at = NULL, reset_attempts = 0,
          failed_logins = 0, locked_until = NULL WHERE id = $1`, [u.id, await hashPassword(b.password)]);
      await c.query('UPDATE sessions SET revoked = true WHERE user_id = $1', [u.id]);
      await audit(c, { userId: u.id, hotelId: u.hotel_id, ip: req.ip }, 'password_reset', 'user', u.id);
    });
    return { ok: true };
  });

  app.patch('/api/auth/language', { preHandler: requireAuth }, async (req) => {
    const b = z.object({ language: z.enum(['fr', 'ar', 'en']) }).parse(req.body);
    await getPool().query('UPDATE users SET language = $2 WHERE id = $1', [req.user!.id, b.language]);
    return { ok: true };
  });

  // ===== Appareils =====
  app.get('/api/devices', { preHandler: requirePerm('devices.manage') }, async (req) =>
    q(getPool(), `SELECT d.id, d.name, d.status, d.created_at, d.last_seen_at, u.full_name AS approved_by
                    FROM devices d LEFT JOIN users u ON u.id = d.approved_by WHERE d.hotel_id = $1 ORDER BY d.created_at DESC`, [req.user!.hotelId]));

  app.post('/api/devices/:id/:action', { preHandler: requirePerm('devices.manage') }, async (req) => {
    const { id, action } = z.object({ id: z.coerce.number().int(), action: z.enum(['approve', 'revoke']) }).parse(req.params);
    return tx(async (c) => {
      const d = await one<any>(c, 'SELECT * FROM devices WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!d) throw notFound('Appareil introuvable');
      const st = action === 'approve' ? 'approved' : 'revoked';
      await c.query(`UPDATE devices SET status = $2, approved_by = $3, approved_at = now() WHERE id = $1`, [id, st, req.user!.id]);
      if (st === 'revoked') await c.query('UPDATE sessions SET revoked = true WHERE device_id = $1', [id]);
      await audit(c, actorOf(req), action, 'device', id, { status: d.status }, { status: st });
      return { ok: true };
    });
  });
}
