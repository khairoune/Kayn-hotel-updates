/** Phase 13 — Night audit : API (tableau de bord, contrôles, anomalies, checklist, caisse, comptabilisation, validation, clôture, réouverture, historique, rapports). */
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { getPool, one, q, tx } from '../db/pool.js';
import { actorOf, requireAuth, requirePerm } from '../lib/auth.js';
import { forbidden, notFound } from '../lib/errors.js';
import { config } from '../config.js';
import { getSettings } from '../services/common.js';
import type { Section } from '../services/analytics/core.js';
import { sectionCsv, sectionPdf, sectionXlsx } from '../services/analytics/export.js';
import {
  ANOMALY_LABEL, anomalyAction, approveCash, buildReport, cashStatus, checklist, closeDay, countCash, currentDay, dayById, dayFacts, DEPT_LBL, history, postings, postRevenue,
  reopenDay, revenuePreview, runChecks, validateDay, validateItem,
} from '../services/nightaudit.js';

const Id = z.object({ id: z.coerce.number().int().positive() });
const d10 = (d: any) => (d instanceof Date ? d.toISOString() : String(d ?? '')).slice(0, 10);
const fr = (d: string) => `${d.slice(8, 10)}/${d.slice(5, 7)}/${d.slice(0, 4)}`;
const needAny = (...ps: string[]) => async (req: FastifyRequest) => { await requireAuth(req, null as any); if (!ps.some((p) => req.user!.perms.has(p))) throw forbidden(`Permission requise : ${ps.join(' ou ')}`); };
const SEV_LBL: Record<string, string> = { info: 'Information', warning: 'Avertissement', critical: 'Critique' };
const ST_LBL: Record<string, string> = { open: 'À traiter', corrected: 'Corrigée', accepted: 'Justifiée / validée' };
const DAY_ST: Record<string, string> = { open: 'Ouverte', checking: 'En cours de vérification', ready: 'Prête à clôturer', closed: 'Clôturée', reopened: 'Réouverte', suspended: 'En attente (réouverture)' };

/** Rapport de night audit → section exportable (PDF / Excel / CSV). */
function reportSection(r: any): Section {
  const f = r.facts;
  const k = (key: string, label: string, unit: any, value: any, hint?: string) => ({ key, label, unit, value, prev: null, better: null, ...(hint ? { hint } : {}) });
  const an = r.anomalies as any[];
  const anCols = [{ key: 'label', label: 'Type' }, { key: 'severity', label: 'Gravité' }, { key: 'ref_label', label: 'Référence' }, { key: 'description', label: 'Description' }, { key: 'status', label: 'Statut' }, { key: 'resolution', label: 'Résolution / justification' }, { key: 'resolved_by_name', label: 'Par' }];
  const anRows = (xs: any[]) => xs.map((a) => ({ ...a, severity: SEV_LBL[a.severity], status: ST_LBL[a.status] }));
  return {
    kpis: [
      k('occupancy', 'Taux d\'occupation', 'pct', f.rooms.occupancy, `${f.rooms.sold} chambre(s) vendue(s) / ${f.rooms.total - f.rooms.oos} disponibles`),
      k('arrivals', 'Arrivées', 'int', f.arrivals), k('departures', 'Départs', 'int', f.departures), k('guests', 'Clients présents', 'int', f.in_house_guests),
      k('oos', 'Chambres hors service', 'int', f.rooms.oos), k('revenue', 'Chiffre d\'affaires du jour (HT)', 'money', f.revenue_total),
      k('collected', 'Encaissements nets', 'money', f.collected), k('expenses', 'Dépenses', 'money', f.expenses_total), k('unpaid', 'Factures non réglées', 'money', f.unpaid_invoices.due, `${f.unpaid_invoices.n} facture(s)`),
      k('anomalies', 'Anomalies détectées', 'int', an.filter((a) => a.severity !== 'info').length), k('resolved', 'Anomalies corrigées', 'int', an.filter((a) => a.status === 'corrected').length),
      k('accepted', 'Anomalies justifiées', 'int', an.filter((a) => a.status === 'accepted').length),
    ],
    charts: [],
    tables: [
      { key: 'revenue', title: 'Chiffre d\'affaires par département (HT)', columns: [{ key: 'label', label: 'Département' }, { key: 'amount', label: 'Montant', money: true }, { key: 'posted', label: 'Comptabilisé', money: true }],
        rows: f.revenue, total: { label: 'Total', amount: f.revenue_total, posted: f.revenue_posted } },
      { key: 'postings', title: 'Écritures de revenus comptabilisées', columns: [{ key: 'label', label: 'Département' }, { key: 'kind', label: 'Type' }, { key: 'n', label: 'Écritures', unit: 'int' }, { key: 'amount', label: 'Montant HT', money: true }, { key: 'tax', label: 'Taxes', money: true }],
        rows: r.postings.map((p: any) => ({ ...p, kind: p.kind === 'adjustment' ? 'Ajustement' : 'Écriture' })) },
      { key: 'payments', title: 'Encaissements par moyen de paiement', columns: [{ key: 'label', label: 'Moyen' }, { key: 'n', label: 'Opérations', unit: 'int' }, { key: 'amount', label: 'Montant', money: true }],
        rows: [...f.payments, ...(f.incomes ? [{ label: 'Recettes diverses', n: '', amount: f.incomes }] : []), ...(f.refunds ? [{ label: 'Remboursements', n: f.refunds_n, amount: -f.refunds }] : [])], total: { label: 'Total net', amount: f.collected } },
      { key: 'expenses', title: 'Dépenses', columns: [{ key: 'category', label: 'Catégorie' }, { key: 'n', label: 'Opérations', unit: 'int' }, { key: 'amount', label: 'Montant', money: true }], rows: f.expenses, total: { category: 'Total', amount: f.expenses_total } },
      { key: 'cash', title: 'Résultat de caisse', columns: [{ key: 'name', label: 'Caisse' }, { key: 'opening', label: 'Solde initial', money: true }, { key: 'receipts', label: 'Encaissements', money: true }, { key: 'outflows', label: 'Sorties', money: true },
        { key: 'refunds', label: 'Remboursements', money: true }, { key: 'expected', label: 'Théorique', money: true }, { key: 'counted', label: 'Compté', money: true }, { key: 'difference', label: 'Écart', money: true }, { key: 'who', label: 'Compté / autorisé par' }],
        rows: r.cash.filter((c: any) => c.required).map((c: any) => ({ ...c, counted: c.count?.counted ?? null, difference: c.count?.difference ?? null, who: c.count ? `${c.count.counted_by}${c.count.approved_by ? ` / ${c.count.approved_by}` : ''}${c.count.justification ? ` — ${c.count.justification}` : ''}` : 'Non compté' })) },
      { key: 'unpaid', title: 'Factures non réglées', columns: [{ key: 'number', label: 'N°' }, { key: 'date', label: 'Date' }, { key: 'client', label: 'Client' }, { key: 'total', label: 'Total', money: true }, { key: 'due', label: 'Reste dû', money: true }],
        rows: r.unpaid_invoices, total: { number: 'Total', due: Math.round(r.unpaid_invoices.reduce((s: number, x: any) => s + x.due, 0) * 100) / 100 } },
      { key: 'anomalies', title: 'Anomalies détectées', columns: anCols, rows: anRows(an.filter((a) => a.status === 'open' || a.severity === 'info')) },
      { key: 'resolved', title: 'Anomalies résolues (corrigées ou justifiées)', columns: anCols, rows: anRows(an.filter((a) => a.status !== 'open' && a.severity !== 'info')) },
    ],
    notes: [
      `Date opérationnelle : ${fr(r.business_date)}.${r.closed_by ? ` Clôture effectuée par ${r.closed_by}` : ''}${r.closed_at ? ` le ${new Date(r.closed_at).toLocaleString('fr-FR', { timeZone: config.timezone })}` : ''}.`,
      'Chiffre d\'affaires : nuitées consommées, commandes restaurant et prestations de la journée (hors taxes). Encaissements : paiements + recettes − remboursements enregistrés sur la journée opérationnelle.',
    ],
  };
}

export async function nightAuditRoutes(app: FastifyInstance) {
  const H = (req: FastifyRequest) => req.user!.hotelId;
  const cur = (req: FastifyRequest) => currentDay(getPool(), H(req), req.user!.id);

  // ----------------------------------------------------- Tableau de bord
  app.get('/api/night-audit/current', { preHandler: requirePerm('nightaudit.view') }, async (req) => {
    const db = getPool();
    const day = await cur(req);
    const D = d10(day.business_date);
    const facts = await dayFacts(db, H(req), D, true);
    const cl = await checklist(db, day);
    const counts = await one<any>(db, `SELECT count(*) FILTER (WHERE status = 'open' AND severity <> 'info')::int AS blocking, count(*) FILTER (WHERE status = 'open' AND severity = 'critical')::int AS critical,
        count(*) FILTER (WHERE status = 'open' AND severity = 'warning')::int AS warning, count(*) FILTER (WHERE severity = 'info')::int AS info,
        count(*) FILTER (WHERE status = 'corrected')::int AS corrected, count(*) FILTER (WHERE status = 'accepted')::int AS accepted, count(*)::int AS total FROM audit_anomalies WHERE audit_day_id = $1`, [day.id]);
    const last = await one<any>(db, `SELECT c.closed_at, c.business_date, u.full_name AS closed_by FROM audit_closures c JOIN users u ON u.id = c.closed_by WHERE c.hotel_id = $1 ORDER BY c.closed_at DESC LIMIT 1`, [H(req)]);
    const actions = await q<any>(db, `SELECT a.id, a.code, a.item, a.severity, a.ref_type, a.ref_id, a.ref_label, a.description FROM audit_anomalies a WHERE a.audit_day_id = $1 AND a.status = 'open' AND a.severity <> 'info'
       ORDER BY a.severity = 'critical' DESC, a.id LIMIT 12`, [day.id]);
    const settings = await getSettings(db, H(req));
    const cal = new Intl.DateTimeFormat('en-CA', { timeZone: config.timezone }).format(new Date());
    return {
      day: { ...day, business_date: D, status_label: DAY_ST[day.status] }, calendar_date: cal, last_closure: last, facts, checklist: cl, anomalies: counts,
      actions: actions.map((a) => ({ ...a, label: ANOMALY_LABEL[a.code] ?? a.code })), settings: settings.night_audit,
      early: !settings.night_audit.allow_early_close && D >= cal,
    };
  });
  app.post('/api/night-audit/check', { preHandler: requirePerm('nightaudit.check') }, async (req) => {
    const r = await tx(async (c) => runChecks(c, actorOf(req), await currentDay(c, H(req), req.user!.id)));
    return r;
  });

  // ----------------------------------------------------- Anomalies
  app.get('/api/night-audit/anomalies', { preHandler: requirePerm('nightaudit.view') }, async (req) => {
    const f = z.object({ day_id: z.coerce.number().int().positive().optional(), status: z.string().max(40).optional(), severity: z.string().max(40).optional(), item: z.string().max(30).optional() }).parse(req.query);
    const day = f.day_id ? await dayById(getPool(), H(req), f.day_id) : await cur(req);
    const rows = await q<any>(getPool(), `SELECT a.*, r.full_name AS responsible, u.full_name AS resolved_by_name, (SELECT count(*) FROM audit_anomaly_history h WHERE h.anomaly_id = a.id)::int AS events
       FROM audit_anomalies a LEFT JOIN users r ON r.id = a.responsible_user_id LEFT JOIN users u ON u.id = a.resolved_by
      WHERE a.audit_day_id = $1 AND ($2::text[] IS NULL OR a.status = ANY($2)) AND ($3::text[] IS NULL OR a.severity = ANY($3)) AND ($4::text IS NULL OR a.item = $4)
      ORDER BY (a.status = 'open') DESC, CASE a.severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 END, a.id`,
      [day.id, f.status ? f.status.split(',') : null, f.severity ? f.severity.split(',') : null, f.item ?? null]);
    return rows.map((a) => ({ ...a, label: ANOMALY_LABEL[a.code] ?? a.code }));
  });
  app.get('/api/night-audit/anomalies/:id', { preHandler: requirePerm('nightaudit.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    const a = await one<any>(getPool(), `SELECT a.*, r.full_name AS responsible, u.full_name AS resolved_by_name FROM audit_anomalies a LEFT JOIN users r ON r.id = a.responsible_user_id LEFT JOIN users u ON u.id = a.resolved_by WHERE a.id = $1 AND a.hotel_id = $2`, [id, H(req)]);
    if (!a) throw notFound('Anomalie introuvable');
    const hist = await q<any>(getPool(), `SELECT h.*, u.full_name AS by_name FROM audit_anomaly_history h LEFT JOIN users u ON u.id = h.user_id WHERE h.anomaly_id = $1 ORDER BY h.id`, [id]);
    return { ...a, label: ANOMALY_LABEL[a.code] ?? a.code, history: hist };
  });
  app.post('/api/night-audit/anomalies/:id/action', { preHandler: needAny('nightaudit.check', 'nightaudit.correct') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ action: z.enum(['comment', 'accept', 'reopen']), text: z.string().max(1000).default('') }).parse(req.body);
    await tx(async (c) => anomalyAction(c, actorOf(req), req.user!.perms, null, id, b));
    return { ok: true };
  });
  app.post('/api/night-audit/anomalies/accept', { preHandler: requirePerm('nightaudit.correct') }, async (req) => {
    const b = z.object({ ids: z.array(z.number().int().positive()).min(1).max(200), text: z.string().max(1000) }).parse(req.body);
    const res = await tx(async (c) => { let n = 0; const refused: number[] = []; for (const id of b.ids) { try { await c.query('SAVEPOINT a'); await anomalyAction(c, actorOf(req), req.user!.perms, null, id, { action: 'accept', text: b.text }); n++; } catch (e) { await c.query('ROLLBACK TO SAVEPOINT a'); refused.push(id); if (b.ids.length === 1) throw e; } } return { accepted: n, refused }; });
    return res;
  });

  // ----------------------------------------------------- Checklist
  app.get('/api/night-audit/checklist', { preHandler: requirePerm('nightaudit.view') }, async (req) => checklist(getPool(), await cur(req)));
  app.post('/api/night-audit/checklist/:item/validate', { preHandler: requirePerm('nightaudit.check') }, async (req) => {
    const { item } = z.object({ item: z.string().max(30) }).parse(req.params);
    const b = z.object({ note: z.string().max(500).nullish() }).parse(req.body ?? {});
    await tx(async (c) => validateItem(c, actorOf(req), await currentDay(c, H(req)), item, b.note?.trim() || null));
    return { ok: true };
  });

  // ----------------------------------------------------- Caisse
  app.get('/api/night-audit/cash', { preHandler: requirePerm('nightaudit.view') }, async (req) => {
    const day = await cur(req);
    const s = await getSettings(getPool(), H(req));
    const hist = await q<any>(getPool(), `SELECT c.*, r.name AS register, u.full_name AS counted_by_name, a.full_name AS approved_by_name FROM audit_cash_counts c JOIN cash_registers r ON r.id = c.register_id
        JOIN users u ON u.id = c.counted_by LEFT JOIN users a ON a.id = c.approved_by WHERE c.audit_day_id = $1 ORDER BY c.id DESC`, [day.id]);
    return { registers: await cashStatus(getPool(), H(req), day), counts: hist, tolerance: s.night_audit.cash_tolerance, approval_threshold: s.night_audit.approval_threshold };
  });
  app.post('/api/night-audit/cash/count', { preHandler: requirePerm('nightaudit.cash') }, async (req) => {
    const b = z.object({ register_id: z.number().int().positive(), counted: z.number().min(0).max(1e10), justification: z.string().max(500).nullish() }).parse(req.body);
    return tx(async (c) => countCash(c, actorOf(req), await currentDay(c, H(req)), b));
  });
  app.post('/api/night-audit/cash/:id/approve', { preHandler: requirePerm('nightaudit.cash') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ note: z.string().max(500).nullish() }).parse(req.body ?? {});
    await tx(async (c) => approveCash(c, actorOf(req), await currentDay(c, H(req)), id, b.note?.trim() || null));
    return { ok: true };
  });

  // ----------------------------------------------------- Comptabilisation des revenus
  app.get('/api/night-audit/postings', { preHandler: requirePerm('nightaudit.view') }, async (req) => {
    const f = z.object({ day_id: z.coerce.number().int().positive().optional() }).parse(req.query);
    const day = f.day_id ? await dayById(getPool(), H(req), f.day_id) : await cur(req);
    const D = d10(day.business_date);
    return { business_date: D, preview: await revenuePreview(getPool(), H(req), D), postings: (await postings(getPool(), H(req), D)).map((p) => ({ ...p, department_label: DEPT_LBL[p.department] })) };
  });
  app.post('/api/night-audit/post', { preHandler: requirePerm('nightaudit.post') }, async (req) => tx(async (c) => postRevenue(c, actorOf(req), await currentDay(c, H(req)))));

  // ----------------------------------------------------- Validation et clôture
  app.post('/api/night-audit/validate', { preHandler: requirePerm('nightaudit.close') }, async (req) => {
    const b = z.object({ note: z.string().max(500).nullish() }).parse(req.body ?? {});
    await tx(async (c) => validateDay(c, actorOf(req), await currentDay(c, H(req)), b.note?.trim() || null));
    return { ok: true };
  });
  app.post('/api/night-audit/close', { preHandler: requirePerm('nightaudit.close') }, async (req) => {
    const b = z.object({ confirm: z.string().max(20) }).parse(req.body);
    const r = await tx((c) => closeDay(c, actorOf(req), b, (app as any).nightAuditHooks ?? {}));
    return { closed: r.closed, version: r.version, posted: r.posted, next_business_date: r.next_business_date };
  });
  app.post('/api/night-audit/days/:id/reopen', { preHandler: requirePerm('nightaudit.reopen') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().max(1000) }).parse(req.body);
    await tx((c) => reopenDay(c, actorOf(req), id, b.reason));
    return { ok: true };
  });

  // ----------------------------------------------------- Historique et rapports
  app.get('/api/night-audit/history', { preHandler: requirePerm('nightaudit.history') }, async (req) =>
    (await history(getPool(), H(req))).map((x) => ({ ...x, business_date: d10(x.business_date), status_label: DAY_ST[x.status] })));
  app.get('/api/night-audit/days/:id/events', { preHandler: needAny('nightaudit.history', 'nightaudit.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    await dayById(getPool(), H(req), id);
    return q<any>(getPool(), `SELECT e.*, u.full_name AS by_name FROM audit_day_events e LEFT JOIN users u ON u.id = e.user_id WHERE e.audit_day_id = $1 ORDER BY e.id`, [id]);
  });
  app.get('/api/night-audit/days/:id/report', { preHandler: needAny('nightaudit.history', 'nightaudit.view') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const f = z.object({ format: z.enum(['json', 'pdf', 'xlsx', 'csv']).default('json'), version: z.coerce.number().int().positive().optional() }).parse(req.query);
    const day = await dayById(getPool(), H(req), id);
    const closure = await one<any>(getPool(), `SELECT * FROM audit_closures WHERE audit_day_id = $1 ${f.version ? 'AND version = $2' : ''} ORDER BY version DESC LIMIT 1`, f.version ? [id, f.version] : [id]);
    // journée clôturée : rapport figé au moment de la clôture ; sinon rapport provisoire calculé en direct
    const report = closure && day.status === 'closed' || (closure && f.version) ? { ...closure.report, closed_at: closure.closed_at, version: closure.version } : await buildReport(getPool(), H(req), day, null);
    if (f.format === 'json') return { ...report, status: day.status, provisional: !(closure && (day.status === 'closed' || f.version)) };
    const h = await one<any>(getPool(), 'SELECT name, currency FROM hotels WHERE id = $1', [H(req)]);
    const D = d10(day.business_date);
    const meta = { hotel: h?.name ?? 'Hôtel', title: `Rapport de night audit${report.version ? ` (clôture n° ${report.version})` : ' (provisoire)'}`, period: `journée du ${fr(D)}`, compare: null,
      currency: h?.currency ?? 'DA', filters: [], generatedBy: req.user!.fullName, tz: config.timezone };
    const s = reportSection(report);
    const name = `night-audit-${D}`;
    if (f.format === 'xlsx') return rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('content-disposition', `attachment; filename="${name}.xlsx"`).send(await sectionXlsx(meta, s));
    if (f.format === 'csv') return rep.header('content-type', 'text/csv; charset=utf-8').header('content-disposition', `attachment; filename="${name}.csv"`).send(sectionCsv(meta, s));
    return rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${name}.pdf"`).send(await sectionPdf(meta, s));
  });
}
export type { FastifyReply };
