import type { FastifyInstance } from 'fastify';
import ExcelJS from 'exceljs';
import { z } from 'zod';
import { dryRun, getPool, one, q, tx } from '../db/pool.js';
import { actorOf, requirePerm } from '../lib/auth.js';
import { audit } from '../lib/audit.js';
import { isDate, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { guestDisplayName, withBalance, FIN_SQL } from '../services/common.js';
import {
  addCharge, changeRoom, extendStay, extensionQuote, folio, frontCheckIn, frontCheckOut, inHouse, registrationCard, report, REPORTS, roomChangeQuote, voidCharge, walkIn,
} from '../services/frontoffice.js';
import { upsertGuest } from '../services/reservations.js';

const Id = z.object({ id: z.coerce.number().int().positive() });
const zDate = z.string().refine(isDate, 'Date invalide (AAAA-MM-JJ)');
const s = (n = 500) => z.string().trim().max(n).nullish();
const Method = z.enum(['cash', 'card', 'cheque', 'transfer', 'company_account']);
const Payment = z.object({ amount: z.number().min(0).max(100_000_000), method: Method, reference: s(120), kind: z.enum(['deposit', 'payment']).optional() }).nullish();
const DocType = z.enum(['cni', 'passport', 'permis', 'other']);
export const GuestFields = z.object({
  last_name: s(80), first_name: s(80), phone: s(40), email: z.string().trim().max(120).email('E-mail invalide').or(z.literal('')).nullish(),
  nationality: s(60), gender: z.enum(['M', 'F']).nullish(), birth_date: zDate.nullish(), birth_place: s(80),
  id_doc_type: DocType.nullish(), id_doc_number: s(40), id_doc_expiry: zDate.nullish(), id_doc_issued_on: zDate.nullish(), id_doc_issued_place: s(80),
  address: s(200), city: s(80), country: s(60), profession: s(80), father_name: s(80), mother_name: s(80), nif: s(40),
  notes: s(1000), preferences: s(1000), language: z.enum(['fr', 'en', 'ar']).optional(), vip: z.boolean().optional(),
  tax_exempt: z.boolean().optional(), tax_exempt_reason: s(200),
});
const Companion = z.object({ last_name: z.string().trim().min(1).max(80), first_name: s(80), birth_date: zDate.nullish(), relation: s(40), nationality: s(60), id_doc_type: DocType.nullish(), id_doc_number: s(40) });
const CheckInCommon = {
  guest: GuestFields.optional(), adults: z.number().int().min(1).max(20).optional(), children: z.number().int().min(0).max(20).optional(),
  companions: z.array(Companion).max(19).optional(), coming_from: s(120), going_to: s(120), id_checked: z.boolean().optional(),
  signed: z.boolean().optional(), signature: z.string().max(400_000).nullish(), data_consent: z.boolean().optional(), payment: Payment, notes: s(1000),
};

export async function frontOfficeRoutes(app: FastifyInstance) {
  // ============ Main courante ============
  app.get('/api/frontoffice/in-house', { preHandler: requirePerm('reservations.view') }, async (req) => inHouse(getPool(), req.user!.hotelId));

  app.get('/api/frontoffice/summary', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const t = today();
    const h = req.user!.hotelId;
    const ih = await inHouse(getPool(), h);
    const c = await one<any>(getPool(), `SELECT
        count(*) FILTER (WHERE rr.check_in = $2 AND rr.status IN ('pending','confirmed') AND rr.moved_from_rr_id IS NULL)::int AS arrivals_pending,
        count(*) FILTER (WHERE rr.check_in = $2 AND rr.status = 'checked_in' AND rr.moved_from_rr_id IS NULL)::int AS arrivals_done,
        count(*) FILTER (WHERE rr.check_out = $2 AND rr.status = 'checked_out' AND NOT EXISTS (SELECT 1 FROM reservation_rooms n WHERE n.moved_from_rr_id = rr.id))::int AS departures_done
      FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id WHERE r.hotel_id = $1`, [h, t]);
    const free = await one<any>(getPool(), `SELECT count(*)::int AS n FROM rooms r WHERE r.hotel_id = $1 AND r.active AND r.hk_status IN ('clean','inspected')
        AND NOT EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL)
        AND NOT EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.room_id = r.id AND rr.status IN ('pending','confirmed') AND rr.check_in <= $2 AND rr.check_out > $2)
        AND NOT EXISTS (SELECT 1 FROM room_blocks b WHERE b.room_id = r.id AND b.status = 'active' AND b.kind = 'out_of_service' AND b.start_date <= $2 AND (b.end_date IS NULL OR b.end_date > $2))`, [h, t]);
    return {
      in_house: ih.length, guests: ih.reduce((a, x) => a + x.persons, 0), departures_pending: ih.filter((x) => x.status === 'departure_today' || x.status === 'overdue').length,
      overdue: ih.filter((x) => x.status === 'overdue').length, balance_due: ih.filter((x) => x.balance > 0.005).length, ready_rooms: free.n, ...c,
    };
  });

  // ============ Check-in ============
  app.post('/api/frontoffice/check-in', { preHandler: requirePerm('frontoffice.checkin') }, async (req) => {
    const b = z.object({ rr_id: z.number().int().positive(), room_id: z.number().int().positive().nullish(), rate_policy: z.enum(['keep', 'new']).optional(), ...CheckInCommon }).parse(req.body);
    if (b.room_id && !req.user!.perms.has('reservations.edit')) throw forbidden('Changement de chambre non autorisé.');
    return tx((c) => frontCheckIn(c, actorOf(req), req.user!.perms, b as any));
  });

  app.post('/api/frontoffice/walk-in', { preHandler: requirePerm('frontoffice.checkin', 'reservations.create') }, async (req, rep) => {
    const b = z.object({
      ...CheckInCommon, guest: GuestFields, room_id: z.number().int().positive(), check_out: zDate, adults: z.number().int().min(1).max(20),
      meal_plan: z.enum(['RO', 'BB', 'HB', 'FB']).optional(), rate_plan_id: z.number().int().positive().nullish(), rate: z.number().min(0).max(10_000_000).nullish(),
      payer_company: s(120),
    }).parse(req.body);
    const r = await tx((c) => walkIn(c, actorOf(req), req.user!.perms, b as any));
    rep.code(201);
    return r;
  });

  // ============ Folio & check-out ============
  app.get('/api/frontoffice/folio/:id', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    return folio(getPool(), req.user!.hotelId, id);
  });

  /** Aperçu exact du départ (départ anticipé recalculé, taxes, solde) : simulé puis annulé. */
  app.post('/api/frontoffice/check-out/preview', { preHandler: requirePerm('frontoffice.checkout') }, async (req) => {
    const b = z.object({ rr_id: z.number().int().positive() }).parse(req.body);
    return dryRun(async (c) => {
      const before = await folio(c, req.user!.hotelId, b.rr_id);
      const all = new Set([...req.user!.perms, 'frontoffice.checkout_with_balance']);
      const r = await frontCheckOut(c, actorOf(req), all, { rr_id: b.rr_id, balance_action: 'override', override_reason: 'aperçu' });
      return { ...r.folio, planned_check_out: before.check_out, early: r.folio.check_out < before.check_out, planned_total: before.total };
    });
  });

  app.post('/api/frontoffice/check-out', { preHandler: requirePerm('frontoffice.checkout') }, async (req) => {
    const b = z.object({
      rr_id: z.number().int().positive(), payment: Payment,
      refund: z.object({ amount: z.number().positive().max(100_000_000), method: z.enum(['cash', 'card', 'cheque', 'transfer']), reason: z.string().trim().min(2).max(300) }).nullish(),
      balance_action: z.enum(['company', 'override']).nullish(), override_reason: s(300), notes: s(1000),
    }).parse(req.body);
    return tx((c) => frontCheckOut(c, actorOf(req), req.user!.perms, b as any));
  });

  // ============ Changement de chambre ============
  app.post('/api/frontoffice/room-change/quote', { preHandler: requirePerm('reservations.edit') }, async (req) => {
    const b = z.object({ rr_id: z.number().int().positive(), room_id: z.number().int().positive(), rate_policy: z.enum(['keep', 'new']) }).parse(req.body);
    return tx((c) => roomChangeQuote(c, actorOf(req), b.rr_id, b.room_id, b.rate_policy));
  });
  app.post('/api/frontoffice/room-change', { preHandler: requirePerm('reservations.edit') }, async (req) => {
    const b = z.object({ rr_id: z.number().int().positive(), room_id: z.number().int().positive(), rate_policy: z.enum(['keep', 'new']), reason: z.string().trim().min(2).max(300) }).parse(req.body);
    return tx((c) => changeRoom(c, actorOf(req), b));
  });
  app.get('/api/frontoffice/room-changes/:id', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const { id } = Id.parse(req.params); // id de réservation
    return q(getPool(), `SELECT rc.*, f.number AS from_room, t.number AS to_room, u.full_name AS done_by_name
        FROM room_changes rc JOIN reservation_rooms rr ON rr.id = rc.reservation_room_id JOIN reservations r ON r.id = rr.reservation_id
        JOIN rooms f ON f.id = rc.from_room_id JOIN rooms t ON t.id = rc.to_room_id LEFT JOIN users u ON u.id = rc.done_by
       WHERE rr.reservation_id = $1 AND r.hotel_id = $2 ORDER BY rc.done_at`, [id, req.user!.hotelId]);
  });

  // ============ Prolongation ============
  app.post('/api/frontoffice/extend/quote', { preHandler: requirePerm('reservations.edit') }, async (req) => {
    const b = z.object({ rr_id: z.number().int().positive(), check_out: zDate, rate_policy: z.enum(['keep', 'new']).default('new') }).parse(req.body);
    return tx(async (c) => {
      const x = await extensionQuote(c, actorOf(req), b.rr_id, b.check_out, b.rate_policy);
      return { nights: x.nights, added: x.added, added_total: x.added_total, added_net: x.added_net, room: x.room.number };
    });
  });
  app.post('/api/frontoffice/extend', { preHandler: requirePerm('reservations.edit') }, async (req) => {
    const b = z.object({ rr_id: z.number().int().positive(), check_out: zDate, rate_policy: z.enum(['keep', 'new']).default('new') }).parse(req.body);
    return tx((c) => extendStay(c, actorOf(req), b.rr_id, b.check_out, b.rate_policy));
  });

  // ============ Prestations ============
  app.get('/api/services', { preHandler: requirePerm('reservations.view') }, async (req) =>
    q(getPool(), 'SELECT * FROM services WHERE hotel_id = $1 ORDER BY active DESC, sort_order, name', [req.user!.hotelId]));
  const ServiceBody = z.object({
    code: z.string().trim().regex(/^[A-Za-z0-9_-]{1,12}$/, 'Code : 12 lettres ou chiffres max'), name: z.string().trim().min(2).max(80),
    category: z.enum(['breakfast', 'restaurant', 'laundry', 'room_service', 'transfer', 'parking', 'minibar', 'other']),
    price: z.number().min(0).max(10_000_000), unit: z.enum(['unit', 'person', 'night', 'kg', 'trip', 'day']), active: z.boolean().optional(),
  });
  app.post('/api/services', { preHandler: requirePerm('services.manage') }, async (req, rep) => {
    const b = ServiceBody.parse(req.body);
    const r = await one<any>(getPool(), `INSERT INTO services (hotel_id, code, name, category, price, unit) VALUES ($1,upper($2),$3,$4,$5,$6) RETURNING *`, [req.user!.hotelId, b.code, b.name, b.category, b.price, b.unit]);
    await audit(getPool(), actorOf(req), 'create', 'service', r.id, null, r);
    rep.code(201);
    return r;
  });
  app.patch('/api/services/:id', { preHandler: requirePerm('services.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = ServiceBody.partial().parse(req.body);
    return tx(async (c) => {
      const before = await one<any>(c, 'SELECT * FROM services WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!before) throw notFound('Prestation introuvable');
      const m = { ...before, ...b };
      const r = await one<any>(c, 'UPDATE services SET code = upper($2), name = $3, category = $4, price = $5, unit = $6, active = $7 WHERE id = $1 RETURNING *', [id, m.code, m.name, m.category, m.price, m.unit, m.active]);
      await audit(c, actorOf(req), 'update', 'service', id, before, r);
      return r;
    });
  });

  app.post('/api/reservations/:id/charges', { preHandler: requirePerm('frontoffice.charges') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({
      reservation_room_id: z.number().int().positive().nullish(), service_id: z.number().int().positive().nullish(),
      kind: z.enum(['service', 'breakfast', 'restaurant', 'room_service', 'minibar', 'laundry', 'transfer', 'parking', 'other']).optional(),
      description: s(200), quantity: z.number().positive().max(1000), unit_price: z.number().min(0).max(10_000_000).nullish(), service_date: zDate.nullish(),
    }).parse(req.body);
    if (b.unit_price != null && b.service_id && !req.user!.perms.has('services.manage')) {
      const sv = await one<any>(getPool(), 'SELECT price FROM services WHERE id = $1', [b.service_id]);
      if (sv && Number(sv.price) !== b.unit_price) throw forbidden('Modification du prix catalogue non autorisée.');
    }
    const r = await tx((c) => addCharge(c, actorOf(req), { ...b, reservation_id: id }));
    rep.code(201);
    return r;
  });
  app.post('/api/charges/:id/void', { preHandler: requirePerm('payments.void') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(2).max(300) }).parse(req.body);
    await tx((c) => voidCharge(c, actorOf(req), id, b.reason));
    return { ok: true };
  });

  // ============ Fiche d'enregistrement ============
  app.get('/api/frontoffice/registration/:id', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    return registrationCard(getPool(), req.user!.hotelId, id);
  });

  // ============ Rapports ============
  const ReportQ = z.object({ from: zDate.optional(), to: zDate.optional() });
  app.get('/api/frontoffice/reports', { preHandler: requirePerm('reservations.view') }, async () =>
    Object.entries(REPORTS).map(([kind, d]) => ({ kind, title: d.title, dated: d.dated, range: !!d.range })));
  app.get('/api/frontoffice/reports/:kind', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const { kind } = z.object({ kind: z.string().max(30) }).parse(req.params);
    const qs = ReportQ.parse(req.query);
    const from = qs.from ?? today();
    return report(getPool(), req.user!.hotelId, kind, from, qs.to ?? from);
  });
  app.get('/api/frontoffice/reports/:kind/xlsx', { preHandler: requirePerm('reservations.view') }, async (req, rep) => {
    const { kind } = z.object({ kind: z.string().max(30) }).parse(req.params);
    const qs = ReportQ.parse(req.query);
    const from = qs.from ?? today();
    const r = await report(getPool(), req.user!.hotelId, kind, from, qs.to ?? from);
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet(r.title.slice(0, 30));
    ws.addRow([`${r.title} — ${from}${qs.to && qs.to !== from ? ` → ${qs.to}` : ''}`]).font = { bold: true, size: 13 };
    ws.addRow([]);
    const head = ws.addRow(r.columns.map((c) => c.label));
    head.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    head.eachCell((c) => { c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF7A1F2B' } }; });
    for (const row of r.rows) ws.addRow(r.columns.map((c) => { const v = (row as any)[c.key]; return v instanceof Date ? v.toISOString().slice(0, 16).replace('T', ' ') : v ?? ''; }));
    ws.columns.forEach((c) => { c.width = 18; });
    const buf = await wb.xlsx.writeBuffer();
    rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    rep.header('content-disposition', `attachment; filename="${kind}-${from}.xlsx"`);
    return rep.send(Buffer.from(buf as ArrayBuffer));
  });

  // ============ Clients ============
  const mask = (v: string | null) => (v ? `•••${v.slice(-4)}` : null);
  app.get('/api/guests/directory', { preHandler: requirePerm('guests.view') }, async (req) => {
    const qs = z.object({ search: z.string().max(80).default(''), kind: z.enum(['person', 'company', 'agency', 'all']).default('person'), page: z.coerce.number().int().min(1).default(1), vip: z.enum(['true']).optional() }).parse(req.query);
    const term = `%${qs.search.trim().toLowerCase()}%`;
    const size = 50;
    const rows = await q<any>(getPool(),
      `SELECT g.id, g.kind, g.last_name, g.first_name, g.company_name, g.phone, g.email, g.nationality, g.id_doc_type, g.id_doc_number, g.vip, g.language,
              (SELECT count(*) FROM stays s WHERE s.guest_id = g.id)::int AS stays,
              (SELECT max(s.checked_in_at) FROM stays s WHERE s.guest_id = g.id) AS last_stay,
              EXISTS (SELECT 1 FROM stays s WHERE s.guest_id = g.id AND s.checked_out_at IS NULL) AS in_house,
              (SELECT count(*) FROM guest_notes n WHERE n.guest_id = g.id AND n.kind = 'complaint' AND n.status = 'open')::int AS open_complaints,
              count(*) OVER() AS total_count
         FROM guests g WHERE g.hotel_id = $1 AND ($3 = 'all' OR g.kind = $3) AND ($5::boolean IS NULL OR g.vip)
          AND (lower(coalesce(g.last_name,'') || ' ' || coalesce(g.first_name,'') || ' ' || coalesce(g.company_name,'')) LIKE $2
               OR coalesce(g.phone,'') LIKE $2 OR lower(coalesce(g.id_doc_number,'')) LIKE $2 OR lower(coalesce(g.email,'')) LIKE $2)
        ORDER BY g.updated_at DESC LIMIT ${size} OFFSET $4`,
      [req.user!.hotelId, term, qs.kind, (qs.page - 1) * size, qs.vip ? true : null]);
    const full = req.user!.perms.has('guests.edit');
    return {
      total: Number(rows[0]?.total_count ?? 0), page: qs.page, page_size: size,
      rows: rows.map(({ total_count, ...g }) => ({ ...g, name: guestDisplayName(g), id_doc_number: full ? g.id_doc_number : mask(g.id_doc_number) })),
    };
  });

  app.get('/api/guests/:id', { preHandler: requirePerm('guests.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    const h = req.user!.hotelId;
    const g = await one<any>(getPool(), 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2', [id, h]);
    if (!g) throw notFound('Client introuvable');
    if (!req.user!.perms.has('guests.edit')) { g.id_doc_number = mask(g.id_doc_number); g.father_name = null; g.mother_name = null; }
    const stays = await q<any>(getPool(),
      `SELECT rr.id AS rr_id, rr.reservation_id, rr.check_in, rr.check_out, rr.status, rr.rate, rm.number AS room_number, rt.name AS room_type, r.code, s.checked_in_at, s.checked_out_at,
              (SELECT count(*) FROM stay_guests sg WHERE sg.stay_id = s.id)::int AS companions
         FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id JOIN rooms rm ON rm.id = rr.room_id JOIN room_types rt ON rt.id = rr.room_type_id
         LEFT JOIN stays s ON s.reservation_room_id = rr.id
        WHERE r.hotel_id = $2 AND (rr.guest_id = $1 OR (rr.guest_id IS NULL AND r.guest_id = $1) OR r.payer_guest_id = $1)
        ORDER BY rr.check_in DESC LIMIT 100`, [id, h]);
    const reservations = await q<any>(getPool(),
      `SELECT x.* FROM (SELECT r.id, r.code, r.check_in, r.check_out, r.status, ${FIN_SQL} FROM reservations r
         WHERE r.hotel_id = $2 AND (r.guest_id = $1 OR r.payer_guest_id = $1 OR EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.reservation_id = r.id AND rr.guest_id = $1))) x
        ORDER BY x.check_in DESC LIMIT 100`, [id, h]);
    const payments = await q<any>(getPool(),
      `SELECT p.id, p.received_at, p.amount, p.method, p.kind, p.reference, p.void, r.code, u.full_name AS received_by_name FROM payments p
         JOIN reservations r ON r.id = p.reservation_id LEFT JOIN users u ON u.id = p.received_by
        WHERE r.hotel_id = $1 AND p.reservation_id = ANY($2::int[]) ORDER BY p.received_at DESC LIMIT 200`, [h, reservations.map((x) => x.id)]);
    const notes = await q<any>(getPool(),
      `SELECT n.*, u.full_name AS created_by_name, u2.full_name AS resolved_by_name, r.code FROM guest_notes n LEFT JOIN users u ON u.id = n.created_by
         LEFT JOIN users u2 ON u2.id = n.resolved_by LEFT JOIN reservations r ON r.id = n.reservation_id WHERE n.guest_id = $1 ORDER BY n.created_at DESC`, [id]);
    const fin = reservations.map(withBalance).filter((x) => !['cancelled', 'no_show'].includes(x.status));
    const nights = stays.filter((x) => ['checked_in', 'checked_out'].includes(x.status)).reduce((a, x) => a + Math.round((Date.parse(x.check_out) - Date.parse(x.check_in)) / 86_400_000), 0);
    return {
      ...g, name: guestDisplayName(g), stays, reservations: reservations.map((x) => { const f = withBalance(x); return { id: x.id, code: x.code, check_in: x.check_in, check_out: x.check_out, status: x.status, total: f.total, balance: f.balance }; }),
      payments, notes,
      stats: { stays: stays.filter((x) => x.checked_in_at).length, nights, spent: fin.reduce((a, x) => a + Number(x.paid) - Number(x.refunded), 0), balance: fin.reduce((a, x) => a + x.balance, 0) },
    };
  });

  app.patch('/api/guests/:id', { preHandler: requirePerm('guests.edit') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = GuestFields.extend({ company_name: s(120) }).parse(req.body);
    if ((b.tax_exempt !== undefined || b.tax_exempt_reason !== undefined) && !req.user!.perms.has('settings.manage')) throw forbidden('Exonération fiscale : réservée à l\'administrateur.');
    await tx((c) => upsertGuest(c, actorOf(req), { ...(b as any), id }));
    return one(getPool(), 'SELECT * FROM guests WHERE id = $1', [id]);
  });

  // Suppression d'un client : uniquement s'il n'a AUCUN historique (séjour, facture, paiement, commande…).
  // Sinon la loi (conservation des fiches de police, comptabilité) l'interdit : on propose l'anonymisation.
  app.delete('/api/guests/:id', { preHandler: requirePerm('guests.edit') }, async (req) => {
    const { id } = Id.parse(req.params);
    const g = await one<any>(getPool(), 'SELECT id, code, kind, last_name, first_name, company_name FROM guests WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!g) throw notFound('Client introuvable.');
    try {
      await tx(async (c) => {
        await c.query('DELETE FROM guest_notes WHERE guest_id = $1', [id]);
        await c.query('UPDATE id_scans SET guest_id = NULL WHERE guest_id = $1', [id]);
        await c.query('DELETE FROM guests WHERE id = $1', [id]);
        await audit(c, actorOf(req), 'delete', 'guest', id, g, null);
      });
    } catch (e: any) {
      if (e?.code === '23503') throw conflict('Ce client a un historique (séjour, facture, paiement…) : la loi impose de le conserver. Vous pouvez l\'anonymiser à la place (ses données personnelles sont effacées, les montants restent).');
      throw e;
    }
    return { ok: true };
  });

  app.post('/api/guests/:id/notes', { preHandler: requirePerm('guests.view') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ kind: z.enum(['note', 'preference', 'request', 'complaint']), text: z.string().trim().min(2).max(2000), reservation_id: z.number().int().positive().nullish() }).parse(req.body);
    const g = await one(getPool(), 'SELECT 1 FROM guests WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!g) throw notFound('Client introuvable');
    if (b.reservation_id && !(await one(getPool(), 'SELECT 1 FROM reservations WHERE id = $1 AND hotel_id = $2', [b.reservation_id, req.user!.hotelId]))) throw badRequest('Réservation inconnue');
    const r = await one<any>(getPool(), `INSERT INTO guest_notes (guest_id, reservation_id, kind, text, status, created_by) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [id, b.reservation_id ?? null, b.kind, b.text, b.kind === 'complaint' || b.kind === 'request' ? 'open' : 'resolved', req.user!.id]);
    await audit(getPool(), actorOf(req), 'create', 'guest_note', r.id, null, { guest_id: id, kind: b.kind });
    // CRM : une réclamation saisie en réception est suivie dans le module Réclamations
    if (b.kind === 'complaint') {
      const { createComplaint } = await import('../services/crm.js');
      await tx((c) => createComplaint(c, actorOf(req), { guest_id: id, reservation_id: b.reservation_id ?? null, category: 'other', title: b.text.slice(0, 120), description: b.text, channel: 'in_person', note_id: r.id }));
    }
    rep.code(201);
    return r;
  });
  app.post('/api/guest-notes/:id/resolve', { preHandler: requirePerm('guests.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ resolution: z.string().trim().min(2).max(1000) }).parse(req.body);
    const r = await one<any>(getPool(), `UPDATE guest_notes n SET status = 'resolved', resolution = $2, resolved_by = $3, resolved_at = now()
       FROM guests g WHERE g.id = n.guest_id AND g.hotel_id = $4 AND n.id = $1 AND n.status = 'open' RETURNING n.*`, [id, b.resolution, req.user!.id, req.user!.hotelId]);
    if (!r) throw notFound('Élément introuvable ou déjà traité');
    await audit(getPool(), actorOf(req), 'resolve', 'guest_note', id, null, { resolution: b.resolution });
    await getPool().query(`INSERT INTO crm_complaint_updates (complaint_id, kind, text, created_by) SELECT id, 'status', $2, $3 FROM crm_complaints WHERE note_id = $1 AND status IN ('new','in_progress')`, [id, `Résolue en réception : ${b.resolution}`, req.user!.id]);
    await getPool().query(`UPDATE crm_complaints SET status = 'resolved', resolution = $2, resolved_at = now(), resolved_by = $3 WHERE note_id = $1 AND status IN ('new','in_progress')`, [id, b.resolution, req.user!.id]);
    return r;
  });
}
