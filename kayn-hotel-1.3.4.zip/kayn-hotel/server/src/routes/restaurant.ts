import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { getPool, one, q, tx } from '../db/pool.js';
import { audit } from '../lib/audit.js';
import { actorOf, requireAuth, requirePerm } from '../lib/auth.js';
import { isDate, monthStart, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { getSettings, guestDisplayName } from '../services/common.js';
import { tableCsv, tablePdf, tableXlsx } from '../services/exports.js';
import {
  addLines, bookingStatus, bookTable, breakfastList, cancelLine, cancelOrder, confirmOrder, createOrder, currentMenu, floorPlan, kitchenAction, listItems, mergeTables,
  moveOrder, recordBreakfast, roomServiceAction, rsDashboard, rsReport, RS_REPORTS, serveOrder, setDiscount, settle, splitTable, updateLine, OUTLET_LABEL, STATUS_LABEL,
} from '../services/restaurant.js';

const Id = z.object({ id: z.coerce.number().int().positive() });
const zDate = z.string().refine(isDate, 'Date invalide (AAAA-MM-JJ)');
const s = (n = 500) => z.string().trim().max(n).nullish();
const Outlet = z.enum(['restaurant', 'bar', 'room_service', 'breakfast']);
const Station = z.enum(['kitchen', 'bar', 'pastry', 'none']);
const Time = z.string().regex(/^\d{2}:\d{2}$/, 'Heure invalide (HH:MM)');
const Line = z.object({ item_id: z.number().int().positive(), quantity: z.number().int().min(1).max(100), option_ids: z.array(z.number().int().positive()).max(20).optional(), comment: s(300) });
const ALLERGENS = ['gluten', 'crustaceans', 'eggs', 'fish', 'peanuts', 'soy', 'milk', 'nuts', 'celery', 'mustard', 'sesame', 'sulphites', 'lupin', 'molluscs'] as const;
const needAny = (...ps: string[]) => async (req: FastifyRequest) => {
  await requireAuth(req, null as any);
  if (!ps.some((p) => req.user!.perms.has(p))) throw forbidden(`Permission requise : ${ps.join(' ou ')}`);
};
const hotelName = async (id: number) => (await one<any>(getPool(), 'SELECT name FROM hotels WHERE id = $1', [id]))?.name ?? 'Hôtel';
async function sendTable(rep: FastifyReply, format: string, name: string, title: string, sub: string, cols: any[], rows: any[], total: any, hotel: string) {
  if (format === 'xlsx') {
    rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('content-disposition', `attachment; filename="${name}.xlsx"`);
    return rep.send(await tableXlsx(title, sub, cols, rows, total));
  }
  if (format === 'csv') {
    rep.header('content-type', 'text/csv; charset=utf-8').header('content-disposition', `attachment; filename="${name}.csv"`);
    return rep.send(tableCsv(cols, rows, total));
  }
  rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${name}.pdf"`);
  return rep.send(await tablePdf(hotel, title, sub, cols, rows, total));
}

async function orderDetail(hotelId: number, id: number) {
  const o = await one<any>(getPool(), `SELECT o.*, t.number AS table_number, r.number AS room_number, u.full_name AS waiter, ua.full_name AS assignee, i.number AS invoice_number, res.code AS reservation_code
      FROM rs_orders o LEFT JOIN rs_tables t ON t.id = o.table_id LEFT JOIN rooms r ON r.id = o.room_id LEFT JOIN users u ON u.id = o.waiter_id LEFT JOIN users ua ON ua.id = o.assigned_to
      LEFT JOIN invoices i ON i.id = o.invoice_id LEFT JOIN reservations res ON res.id = o.reservation_id WHERE o.id = $1 AND o.hotel_id = $2`, [id, hotelId]);
  if (!o) throw notFound('Commande introuvable');
  const lines = await q<any>(getPool(), `SELECT l.*, u.full_name AS cancelled_by_name FROM rs_order_lines l LEFT JOIN users u ON u.id = l.cancelled_by WHERE l.order_id = $1 ORDER BY l.id`, [id]);
  const history = await q<any>(getPool(), `SELECT a.created_at, a.action, a.after, u.full_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE a.entity = 'rs_order' AND a.entity_id = $1 ORDER BY a.id`, [String(id)]);
  const charges = await q<any>(getPool(), `SELECT c.id, c.description, c.total, c.void FROM charges c JOIN rs_order_lines l ON l.id = c.rs_order_line_id WHERE l.order_id = $1 ORDER BY c.id`, [id]);
  return { ...o, outlet_label: OUTLET_LABEL[o.outlet], status_label: STATUS_LABEL[o.status], lines, history, charges };
}

export async function restaurantRoutes(app: FastifyInstance) {
  // ===================================================== Carte =====================================================
  app.get('/api/rs/categories', { preHandler: requirePerm('restaurant.view') }, async (req) =>
    q(getPool(), 'SELECT * FROM rs_categories WHERE hotel_id = $1 ORDER BY sort_order, name', [req.user!.hotelId]));
  const Cat = z.object({ name: z.string().trim().min(2).max(60), kind: z.enum(['starter', 'main', 'dessert', 'drink', 'breakfast']), station: Station.default('kitchen'), sort_order: z.number().int().min(0).max(999).optional(), active: z.boolean().optional() });
  app.post('/api/rs/categories', { preHandler: requirePerm('restaurant.menu') }, async (req, rep) => {
    const b = Cat.parse(req.body);
    const r = await one(getPool(), `INSERT INTO rs_categories (hotel_id, name, kind, station, sort_order) VALUES ($1,$2,$3,$4,COALESCE($5,99)) RETURNING *`, [req.user!.hotelId, b.name, b.kind, b.station, b.sort_order ?? null]);
    rep.code(201);
    return r;
  });
  app.patch('/api/rs/categories/:id', { preHandler: requirePerm('restaurant.menu') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = Cat.partial().parse(req.body);
    const r = await one(getPool(), `UPDATE rs_categories SET name = COALESCE($3, name), kind = COALESCE($4, kind), station = COALESCE($5, station), sort_order = COALESCE($6, sort_order), active = COALESCE($7, active)
        WHERE id = $1 AND hotel_id = $2 RETURNING *`, [id, req.user!.hotelId, b.name ?? null, b.kind ?? null, b.station ?? null, b.sort_order ?? null, b.active ?? null]);
    if (!r) throw notFound('Catégorie introuvable');
    return r;
  });

  app.get('/api/rs/items', { preHandler: requirePerm('restaurant.view') }, async (req) => {
    const qs = z.object({ all: z.enum(['1']).optional() }).parse(req.query);
    return listItems(getPool(), req.user!.hotelId, { all: !!qs.all });
  });
  const Item = z.object({
    category_id: z.number().int().positive(), name: z.string().trim().min(2).max(100), description: s(600), price: z.number().min(0).max(1_000_000),
    station: Station.nullish(), prep_minutes: z.number().int().min(0).max(240).optional(), ingredients: s(600), allergens: z.array(z.enum(ALLERGENS)).max(14).optional(),
    available: z.boolean().optional(), active: z.boolean().optional(), sort_order: z.number().int().min(0).max(9999).optional(),
  });
  app.post('/api/rs/items', { preHandler: requirePerm('restaurant.menu') }, async (req, rep) => {
    const b = Item.parse(req.body);
    if (!(await one(getPool(), 'SELECT 1 FROM rs_categories WHERE id = $1 AND hotel_id = $2', [b.category_id, req.user!.hotelId]))) throw badRequest('Catégorie inconnue.');
    const r = await one<any>(getPool(), `INSERT INTO rs_items (hotel_id, category_id, name, description, price, station, prep_minutes, ingredients, allergens, available, sort_order)
        VALUES ($1,$2,$3,$4,$5,$6,COALESCE($7,10),$8,$9,COALESCE($10,true),COALESCE($11,0)) RETURNING *`,
      [req.user!.hotelId, b.category_id, b.name, b.description ?? null, b.price, b.station ?? null, b.prep_minutes ?? null, b.ingredients ?? null, b.allergens ?? [], b.available ?? null, b.sort_order ?? null]);
    await audit(getPool(), actorOf(req), 'create', 'rs_item', r.id, null, b);
    rep.code(201);
    return r;
  });
  app.patch('/api/rs/items/:id', { preHandler: requirePerm('restaurant.menu') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = Item.partial().parse(req.body);
    const before = await one<any>(getPool(), 'SELECT * FROM rs_items WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!before) throw notFound('Plat introuvable');
    const r = await one<any>(getPool(), `UPDATE rs_items SET category_id = COALESCE($2, category_id), name = COALESCE($3, name), description = CASE WHEN $4::boolean THEN $5 ELSE description END,
        price = COALESCE($6, price), station = CASE WHEN $7::boolean THEN $8 ELSE station END, prep_minutes = COALESCE($9, prep_minutes), ingredients = CASE WHEN $10::boolean THEN $11 ELSE ingredients END,
        allergens = COALESCE($12, allergens), available = COALESCE($13, available), active = COALESCE($14, active), sort_order = COALESCE($15, sort_order), updated_at = now() WHERE id = $1 RETURNING *`,
      [id, b.category_id ?? null, b.name ?? null, b.description !== undefined, b.description ?? null, b.price ?? null, b.station !== undefined, b.station ?? null, b.prep_minutes ?? null,
        b.ingredients !== undefined, b.ingredients ?? null, b.allergens ?? null, b.available ?? null, b.active ?? null, b.sort_order ?? null]);
    await audit(getPool(), actorOf(req), 'update', 'rs_item', id, { price: Number(before.price), available: before.available, active: before.active }, b);
    return r;
  });
  app.put('/api/rs/items/:id/options', { preHandler: requirePerm('restaurant.menu') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ options: z.array(z.object({ id: z.number().int().positive().optional(), kind: z.enum(['variant', 'supplement']), name: z.string().trim().min(1).max(60), price_delta: z.number().min(-100000).max(100000), active: z.boolean().default(true) })).max(30) }).parse(req.body);
    return tx(async (c) => {
      if (!(await one(c, 'SELECT 1 FROM rs_items WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]))) throw notFound('Plat introuvable');
      const keep: number[] = [];
      for (const [i, o] of b.options.entries()) {
        if (o.id) {
          const r = await c.query('UPDATE rs_item_options SET kind = $3, name = $4, price_delta = $5, active = $6, sort_order = $7 WHERE id = $1 AND item_id = $2', [o.id, id, o.kind, o.name, o.price_delta, o.active, i]);
          if (!r.rowCount) throw badRequest('Option inconnue.');
          keep.push(o.id);
        } else keep.push((await one<any>(c, 'INSERT INTO rs_item_options (item_id, kind, name, price_delta, active, sort_order) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id', [id, o.kind, o.name, o.price_delta, o.active, i])).id);
      }
      // les options retirées sont désactivées (les commandes passées les conservent)
      await c.query('UPDATE rs_item_options SET active = false WHERE item_id = $1 AND NOT (id = ANY($2::int[]))', [id, keep]);
      await audit(c, actorOf(req), 'options', 'rs_item', id, null, b);
      return q(c, 'SELECT * FROM rs_item_options WHERE item_id = $1 ORDER BY kind DESC, sort_order', [id]);
    });
  });
  app.put('/api/rs/items/:id/recipe', { preHandler: requirePerm('restaurant.menu') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ lines: z.array(z.object({ product_id: z.number().int().positive(), quantity: z.number().positive().max(100000) })).max(40) }).parse(req.body);
    return tx(async (c) => {
      if (!(await one(c, 'SELECT 1 FROM rs_items WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]))) throw notFound('Plat introuvable');
      if (new Set(b.lines.map((l) => l.product_id)).size !== b.lines.length) throw badRequest('Ingrédient en double.');
      await c.query('DELETE FROM rs_recipes WHERE item_id = $1', [id]);
      for (const l of b.lines) {
        if (!(await one(c, 'SELECT 1 FROM products WHERE id = $1 AND hotel_id = $2', [l.product_id, req.user!.hotelId]))) throw badRequest('Ingrédient inconnu.');
        await c.query('INSERT INTO rs_recipes (item_id, product_id, quantity) VALUES ($1,$2,$3)', [id, l.product_id, l.quantity]);
      }
      await audit(c, actorOf(req), 'recipe', 'rs_item', id, null, b);
      return { ok: true };
    });
  });

  // Menus par service / horaires ; menu du jour
  app.get('/api/rs/menus', { preHandler: requirePerm('restaurant.view') }, async (req) =>
    q(getPool(), `SELECT m.*, COALESCE(array_agg(mi.item_id) FILTER (WHERE mi.item_id IS NOT NULL), '{}') AS item_ids FROM rs_menus m LEFT JOIN rs_menu_items mi ON mi.menu_id = m.id
      WHERE m.hotel_id = $1 GROUP BY m.id ORDER BY m.active DESC, m.menu_date DESC NULLS LAST, m.name`, [req.user!.hotelId]));
  const Menu = z.object({
    name: z.string().trim().min(2).max(80), outlets: z.array(Outlet).min(1), days: z.array(z.number().int().min(0).max(6)).min(1).default([0, 1, 2, 3, 4, 5, 6]),
    start_time: Time.default('00:00'), end_time: Time.default('23:59'), menu_date: zDate.nullish(), set_price: z.number().min(0).max(1_000_000).nullish(), active: z.boolean().default(true),
    item_ids: z.array(z.number().int().positive()).max(300),
  });
  const saveMenu = async (req: any, id: number | null) => {
    const b = Menu.parse(req.body);
    if (b.end_time <= b.start_time) throw badRequest('L\'heure de fin doit être après l\'heure de début.');
    return tx(async (c) => {
      let m: any;
      if (id) {
        m = await one(c, `UPDATE rs_menus SET name = $3, outlets = $4, days = $5, start_time = $6, end_time = $7, menu_date = $8, set_price = $9, active = $10 WHERE id = $1 AND hotel_id = $2 RETURNING *`,
          [id, req.user.hotelId, b.name, b.outlets, b.days, b.start_time, b.end_time, b.menu_date ?? null, b.set_price ?? null, b.active]);
        if (!m) throw notFound('Menu introuvable');
        await c.query('DELETE FROM rs_menu_items WHERE menu_id = $1', [id]);
      } else {
        m = await one(c, `INSERT INTO rs_menus (hotel_id, name, outlets, days, start_time, end_time, menu_date, set_price, active) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
          [req.user.hotelId, b.name, b.outlets, b.days, b.start_time, b.end_time, b.menu_date ?? null, b.set_price ?? null, b.active]);
      }
      const ok = await q<any>(c, 'SELECT id FROM rs_items WHERE hotel_id = $1 AND id = ANY($2::int[])', [req.user.hotelId, b.item_ids]);
      if (ok.length !== new Set(b.item_ids).size) throw badRequest('Plat inconnu dans le menu.');
      for (const it of ok) await c.query('INSERT INTO rs_menu_items (menu_id, item_id) VALUES ($1,$2)', [m.id, it.id]);
      await audit(c, actorOf(req), id ? 'update' : 'create', 'rs_menu', m.id, null, b);
      return m;
    });
  };
  app.post('/api/rs/menus', { preHandler: requirePerm('restaurant.menu') }, async (req, rep) => { const r = await saveMenu(req, null); rep.code(201); return r; });
  app.put('/api/rs/menus/:id', { preHandler: requirePerm('restaurant.menu') }, async (req) => saveMenu(req, Id.parse(req.params).id));
  app.get('/api/rs/menu/current', { preHandler: requirePerm('restaurant.view') }, async (req) => {
    const qs = z.object({ outlet: Outlet.default('restaurant') }).parse(req.query);
    return currentMenu(getPool(), req.user!.hotelId, qs.outlet);
  });

  // ===================================================== Salle =====================================================
  app.get('/api/rs/tables', { preHandler: requirePerm('restaurant.view') }, async (req) => floorPlan(getPool(), req.user!.hotelId));
  const Tbl = z.object({ number: z.string().trim().min(1).max(10), area: z.string().trim().min(1).max(40).default('Salle'), capacity: z.number().int().min(1).max(40), pos_x: z.number().int().min(0).max(2000).optional(), pos_y: z.number().int().min(0).max(2000).optional(), shape: z.enum(['square', 'round', 'long']).optional(), active: z.boolean().optional() });
  app.post('/api/rs/tables', { preHandler: requirePerm('restaurant.menu') }, async (req, rep) => {
    const b = Tbl.parse(req.body);
    const r = await one(getPool(), `INSERT INTO rs_tables (hotel_id, number, area, capacity, pos_x, pos_y, shape) VALUES ($1,$2,$3,$4,COALESCE($5,0),COALESCE($6,0),COALESCE($7,'square')) RETURNING *`,
      [req.user!.hotelId, b.number, b.area, b.capacity, b.pos_x ?? null, b.pos_y ?? null, b.shape ?? null]);
    rep.code(201);
    return r;
  });
  app.patch('/api/rs/tables/:id', { preHandler: requirePerm('restaurant.menu') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = Tbl.partial().parse(req.body);
    if (b.active === false && (await one(getPool(), `SELECT 1 FROM rs_orders WHERE table_id = $1 AND settlement = 'open' AND status <> 'cancelled'`, [id]))) throw conflict('Commande en cours sur cette table.');
    const r = await one(getPool(), `UPDATE rs_tables SET number = COALESCE($3, number), area = COALESCE($4, area), capacity = COALESCE($5, capacity), pos_x = COALESCE($6, pos_x), pos_y = COALESCE($7, pos_y),
        shape = COALESCE($8, shape), active = COALESCE($9, active) WHERE id = $1 AND hotel_id = $2 RETURNING *`,
      [id, req.user!.hotelId, b.number ?? null, b.area ?? null, b.capacity ?? null, b.pos_x ?? null, b.pos_y ?? null, b.shape ?? null, b.active ?? null]);
    if (!r) throw notFound('Table introuvable');
    return r;
  });
  app.post('/api/rs/tables/:id/merge', { preHandler: requirePerm('restaurant.order') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ table_ids: z.array(z.number().int().positive()).min(1).max(10) }).parse(req.body);
    await tx((c) => mergeTables(c, actorOf(req), id, b.table_ids));
    return { ok: true };
  });
  app.post('/api/rs/tables/:id/split', { preHandler: requirePerm('restaurant.order') }, async (req) => {
    await tx((c) => splitTable(c, actorOf(req), Id.parse(req.params).id));
    return { ok: true };
  });
  app.post('/api/rs/tables/:id/status', { preHandler: requirePerm('restaurant.order') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ status: z.enum(['available', 'to_clean']) }).parse(req.body);
    if (b.status === 'available' && (await one(getPool(), `SELECT 1 FROM rs_orders WHERE table_id = $1 AND status <> 'cancelled' AND (settlement = 'open' OR status <> 'served')`, [id]))) throw conflict('Commande en cours sur cette table.');
    const r = await one(getPool(), 'UPDATE rs_tables SET status = $3 WHERE id = $1 AND hotel_id = $2 RETURNING id', [id, req.user!.hotelId, b.status]);
    if (!r) throw notFound('Table introuvable');
    return { ok: true };
  });
  app.get('/api/rs/bookings', { preHandler: requirePerm('restaurant.view') }, async (req) => {
    const qs = z.object({ date: zDate.optional() }).parse(req.query);
    return q(getPool(), `SELECT b.*, t.number AS table_number, r.number AS room_number FROM rs_table_bookings b JOIN rs_tables t ON t.id = b.table_id LEFT JOIN rooms r ON r.id = b.room_id
        WHERE b.hotel_id = $1 AND (b.starts_at AT TIME ZONE 'Africa/Algiers')::date = $2 ORDER BY b.starts_at`, [req.user!.hotelId, qs.date ?? today()]);
  });
  app.post('/api/rs/bookings', { preHandler: requirePerm('restaurant.order') }, async (req, rep) => {
    const b = z.object({ table_id: z.number().int().positive(), guest_name: z.string().trim().min(2).max(100), phone: s(40), room_id: z.number().int().positive().nullish(), party_size: z.number().int().min(1).max(60),
      starts_at: z.string().min(16).max(40), duration_min: z.number().int().min(15).max(480).optional(), notes: s(300) }).parse(req.body);
    const r = await tx((c) => bookTable(c, actorOf(req), b));
    rep.code(201);
    return r;
  });
  app.post('/api/rs/bookings/:id/status', { preHandler: requirePerm('restaurant.order') }, async (req) => {
    const b = z.object({ status: z.enum(['seated', 'cancelled', 'no_show']) }).parse(req.body);
    await tx((c) => bookingStatus(c, actorOf(req), Id.parse(req.params).id, b.status));
    return { ok: true };
  });

  // ===================================================== Commandes =====================================================
  app.get('/api/rs/orders', { preHandler: requirePerm('restaurant.view') }, async (req) => {
    const qs = z.object({ outlet: Outlet.optional(), status: z.string().max(20).optional(), date: zDate.optional(), open: z.enum(['1']).optional(), search: z.string().max(60).default('') }).parse(req.query);
    return q(getPool(), `SELECT o.*, t.number AS table_number, r.number AS room_number, u.full_name AS waiter, ua.full_name AS assignee,
        (SELECT count(*) FROM rs_order_lines l WHERE l.order_id = o.id AND NOT l.cancelled)::int AS lines
       FROM rs_orders o LEFT JOIN rs_tables t ON t.id = o.table_id LEFT JOIN rooms r ON r.id = o.room_id LEFT JOIN users u ON u.id = o.waiter_id LEFT JOIN users ua ON ua.id = o.assigned_to
      WHERE o.hotel_id = $1 AND ($2::text IS NULL OR o.outlet = $2) AND ($3::text IS NULL OR o.status = $3)
        AND (CASE WHEN $4 THEN o.status <> 'cancelled' AND (o.settlement = 'open' OR o.status <> 'served') ELSE (o.created_at AT TIME ZONE 'Africa/Algiers')::date = $5 END)
        AND ($6 = '' OR lower(o.number || ' ' || coalesce(o.guest_name,'') || ' ' || coalesce(t.number,'') || ' ' || coalesce(r.number,'')) LIKE $7)
      ORDER BY o.created_at DESC LIMIT 300`,
      [req.user!.hotelId, qs.outlet ?? null, qs.status ?? null, !!qs.open, qs.date ?? today(), qs.search.trim(), `%${qs.search.trim().toLowerCase()}%`]);
  });
  app.get('/api/rs/orders/:id', { preHandler: requirePerm('restaurant.view') }, async (req) => orderDetail(req.user!.hotelId, Id.parse(req.params).id));

  app.post('/api/rs/orders', { preHandler: needAny('restaurant.order', 'restaurant.bar') }, async (req, rep) => {
    const b = z.object({ outlet: Outlet, table_id: z.number().int().positive().nullish(), room_id: z.number().int().positive().nullish(), covers: z.number().int().min(1).max(60).optional(),
      guest_name: s(100), notes: s(500), priority: z.enum(['normal', 'high', 'urgent']).optional(), lines: z.array(Line).max(60).optional(), send: z.boolean().optional() }).parse(req.body);
    const o = await tx(async (c) => {
      const r = await createOrder(c, actorOf(req), req.user!.perms, b);
      if (b.send && b.lines?.length) await confirmOrder(c, actorOf(req), r.id);
      return r;
    });
    rep.code(201);
    return orderDetail(req.user!.hotelId, o.id);
  });
  app.post('/api/rs/orders/:id/lines', { preHandler: needAny('restaurant.order', 'restaurant.bar') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ lines: z.array(Line).min(1).max(60), send: z.boolean().optional() }).parse(req.body);
    const r = await tx(async (c) => {
      const x = await addLines(c, actorOf(req), req.user!.perms, id, b.lines);
      if (b.send) await confirmOrder(c, actorOf(req), id);
      return x;
    });
    return { ...(await orderDetail(req.user!.hotelId, id)), warnings: r.warnings };
  });
  app.patch('/api/rs/lines/:id', { preHandler: needAny('restaurant.order', 'restaurant.bar') }, async (req) => {
    const b = z.object({ quantity: z.number().int().min(1).max(100).optional(), comment: s(300) }).parse(req.body);
    await tx((c) => updateLine(c, actorOf(req), Id.parse(req.params).id, b));
    return { ok: true };
  });
  app.post('/api/rs/lines/:id/cancel', { preHandler: needAny('restaurant.order', 'restaurant.bar') }, async (req) => {
    const b = z.object({ reason: s(300) }).parse(req.body ?? {});
    await tx((c) => cancelLine(c, actorOf(req), req.user!.perms, Id.parse(req.params).id, b.reason ?? ''));
    return { ok: true };
  });
  app.patch('/api/rs/orders/:id', { preHandler: needAny('restaurant.order', 'restaurant.bar') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ covers: z.number().int().min(1).max(60).optional(), notes: s(500), priority: z.enum(['normal', 'high', 'urgent']).optional(), guest_name: s(100) }).parse(req.body);
    const r = await one(getPool(), `UPDATE rs_orders SET covers = COALESCE($3, covers), notes = CASE WHEN $4::boolean THEN $5 ELSE notes END, priority = COALESCE($6, priority), guest_name = COALESCE($7, guest_name)
        WHERE id = $1 AND hotel_id = $2 AND status <> 'cancelled' RETURNING id`, [id, req.user!.hotelId, b.covers ?? null, b.notes !== undefined, b.notes ?? null, b.priority ?? null, b.guest_name ?? null]);
    if (!r) throw notFound('Commande introuvable');
    await audit(getPool(), actorOf(req), 'update', 'rs_order', id, null, b);
    return { ok: true };
  });
  app.post('/api/rs/orders/:id/confirm', { preHandler: needAny('restaurant.order', 'restaurant.bar') }, async (req) => tx((c) => confirmOrder(c, actorOf(req), Id.parse(req.params).id)));
  app.post('/api/rs/orders/:id/kitchen', { preHandler: needAny('restaurant.kitchen', 'restaurant.bar') }, async (req) => {
    const b = z.object({ action: z.enum(['start', 'ready']), station: Station.nullish() }).parse(req.body);
    const p = req.user!.perms;
    // le bar ne touche qu'aux boissons, la cuisine qu'aux plats ; sans poste précisé il faut les deux droits
    if (b.station === 'bar' ? !p.has('restaurant.bar') : b.station ? !p.has('restaurant.kitchen') : !(p.has('restaurant.kitchen') && p.has('restaurant.bar'))) throw forbidden('Ce poste ne vous est pas attribué.');
    return tx((c) => kitchenAction(c, actorOf(req), Id.parse(req.params).id, b.action, b.station ?? null));
  });
  app.post('/api/rs/orders/:id/serve', { preHandler: needAny('restaurant.order', 'roomservice.deliver', 'restaurant.bar') }, async (req) =>
    tx((c) => serveOrder(c, actorOf(req), req.user!.perms, Id.parse(req.params).id)));
  app.post('/api/rs/orders/:id/room-service', { preHandler: needAny('roomservice.deliver', 'restaurant.order') }, async (req) => {
    const b = z.object({ action: z.enum(['assign', 'out']), user_id: z.number().int().positive().nullish() }).parse(req.body);
    await tx((c) => roomServiceAction(c, actorOf(req), Id.parse(req.params).id, b));
    return { ok: true };
  });
  app.post('/api/rs/orders/:id/move', { preHandler: requirePerm('restaurant.order') }, async (req) => {
    const b = z.object({ table_id: z.number().int().positive() }).parse(req.body);
    await tx((c) => moveOrder(c, actorOf(req), Id.parse(req.params).id, b.table_id));
    return { ok: true };
  });
  app.post('/api/rs/orders/:id/discount', { preHandler: requirePerm('restaurant.discount') }, async (req) => {
    const b = z.object({ type: z.enum(['percent', 'amount']).nullable(), value: z.number().min(0).max(1_000_000).default(0), reason: s(300) }).parse(req.body);
    await tx((c) => setDiscount(c, actorOf(req), Id.parse(req.params).id, b));
    return orderDetail(req.user!.hotelId, Id.parse(req.params).id);
  });
  app.post('/api/rs/orders/:id/cancel', { preHandler: needAny('restaurant.order', 'restaurant.bar') }, async (req) => {
    const b = z.object({ reason: z.string().trim().min(3).max(300) }).parse(req.body);
    await tx((c) => cancelOrder(c, actorOf(req), req.user!.perms, Id.parse(req.params).id, b.reason));
    return { ok: true };
  });
  app.post('/api/rs/orders/:id/settle', { preHandler: requirePerm('restaurant.settle') }, async (req) => {
    const b = z.object({
      mode: z.enum(['pay', 'room', 'invoice']), room_id: z.number().int().positive().nullish(),
      payments: z.array(z.object({ method: z.enum(['cash', 'card', 'cheque', 'transfer']), amount: z.number().positive().max(100_000_000), reference: s(80), card_last4: z.string().regex(/^\d{4}$/).nullish() })).max(4).optional(),
      bill_to: z.object({ id: z.number().int().positive().optional(), kind: z.enum(['person', 'company']).optional(), last_name: s(80), first_name: s(80), company_name: s(120), nif: s(40), address: s(200) }).nullish(),
    }).parse(req.body);
    if (b.mode === 'invoice' && b.bill_to && !b.bill_to.id && !b.bill_to.last_name && !b.bill_to.company_name) throw badRequest('Nom ou raison sociale du client à facturer obligatoire.');
    const r = await tx((c) => settle(c, actorOf(req), Id.parse(req.params).id, b));
    return { ...r, order: await orderDetail(req.user!.hotelId, Id.parse(req.params).id) };
  });

  // Cuisine / bar (KDS)
  app.get('/api/rs/kitchen', { preHandler: needAny('restaurant.kitchen', 'restaurant.bar') }, async (req) => {
    const qs = z.object({ station: Station.optional(), kind: z.string().max(20).optional() }).parse(req.query);
    const orders = await q<any>(getPool(), `SELECT o.id, o.number, o.outlet, o.priority, o.covers, o.notes, o.status, o.confirmed_at, o.created_at, o.guest_name, t.number AS table_number, r.number AS room_number, u.full_name AS waiter
        FROM rs_orders o LEFT JOIN rs_tables t ON t.id = o.table_id LEFT JOIN rooms r ON r.id = o.room_id LEFT JOIN users u ON u.id = o.waiter_id
       WHERE o.hotel_id = $1 AND o.status IN ('confirmed','preparing','ready') AND EXISTS (SELECT 1 FROM rs_order_lines l WHERE l.order_id = o.id AND NOT l.cancelled AND l.kitchen_status IN ('sent','preparing','ready')
         AND ($2::text IS NULL OR l.station = $2) AND ($3::text IS NULL OR l.category_kind = $3))
       ORDER BY array_position(ARRAY['urgent','high','normal'], o.priority), o.confirmed_at`, [req.user!.hotelId, qs.station ?? null, qs.kind ?? null]);
    const lines = orders.length ? await q<any>(getPool(), `SELECT * FROM rs_order_lines WHERE order_id = ANY($1::int[]) AND NOT cancelled AND kitchen_status IN ('sent','preparing','ready')
        AND ($2::text IS NULL OR station = $2) AND ($3::text IS NULL OR category_kind = $3) ORDER BY id`, [orders.map((o) => o.id), qs.station ?? null, qs.kind ?? null]) : [];
    const cancelled = orders.length ? await q<any>(getPool(), `SELECT order_id, name, quantity FROM rs_order_lines WHERE order_id = ANY($1::int[]) AND cancelled AND sent_at IS NOT NULL`, [orders.map((o) => o.id)]) : [];
    return orders.map((o) => ({ ...o, lines: lines.filter((l) => l.order_id === o.id), cancelled: cancelled.filter((l) => l.order_id === o.id),
      waiting_min: Math.round((Date.now() - new Date(o.confirmed_at ?? o.created_at).getTime()) / 60000) }));
  });

  // Room service : chambres occupées + personnel livreur
  app.get('/api/rs/in-house', { preHandler: requirePerm('restaurant.view') }, async (req) => {
    const rows = await q<any>(getPool(), `SELECT rm.id AS room_id, rm.number AS room, rr.id AS rr_id, res.code, res.meal_plan, rr.adults, rr.children, g.kind, g.last_name, g.first_name, g.company_name, g.vip, rm.dnd,
        EXISTS (SELECT 1 FROM rs_orders o WHERE o.room_id = rm.id AND o.outlet = 'room_service' AND o.status NOT IN ('served','cancelled')) AS has_open
       FROM stays s JOIN rooms rm ON rm.id = s.room_id JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN reservations res ON res.id = rr.reservation_id JOIN guests g ON g.id = COALESCE(rr.guest_id, res.guest_id)
      WHERE rm.hotel_id = $1 AND s.checked_out_at IS NULL ORDER BY length(rm.number), rm.number`, [req.user!.hotelId]);
    return rows.map((r) => ({ ...r, guest: guestDisplayName(r) }));
  });
  app.get('/api/rs/staff', { preHandler: requirePerm('restaurant.view') }, async (req) =>
    q(getPool(), `SELECT DISTINCT u.id, u.full_name, ro.name AS role FROM users u JOIN roles ro ON ro.id = u.role_id JOIN role_permissions rp ON rp.role_id = ro.id JOIN permissions p ON p.id = rp.permission_id
      WHERE u.hotel_id = $1 AND u.active AND p.code IN ('roomservice.deliver') ORDER BY u.full_name`, [req.user!.hotelId]));

  // ===================================================== Petit-déjeuner =====================================================
  app.get('/api/rs/breakfast', { preHandler: needAny('breakfast.manage', 'restaurant.view') }, async (req) => {
    const qs = z.object({ date: zDate.optional() }).parse(req.query);
    const d = qs.date ?? today();
    const list = await breakfastList(getPool(), req.user!.hotelId, d);
    const log = await q(getPool(), `SELECT b.*, u.full_name AS recorded_by_name, r.number AS room FROM rs_breakfasts b LEFT JOIN users u ON u.id = b.recorded_by LEFT JOIN rooms r ON r.id = b.room_id
        WHERE b.hotel_id = $1 AND b.service_date = $2 ORDER BY b.created_at DESC`, [req.user!.hotelId, d]);
    const s = (await getSettings(getPool(), req.user!.hotelId)).restaurant;
    const price = (await one<any>(getPool(), 'SELECT price FROM services WHERE hotel_id = $1 AND code = $2', [req.user!.hotelId, s.breakfast_service_code]))?.price ?? null;
    return { date: d, hours: { start: s.breakfast_start, end: s.breakfast_end }, extra_price: price === null ? null : Number(price), rows: list, log,
      totals: { entitled: list.reduce((a, r) => a + r.entitled, 0), used: list.reduce((a, r) => a + r.used, 0), extra: list.reduce((a, r) => a + r.extra, 0) } };
  });
  app.post('/api/rs/breakfast', { preHandler: requirePerm('breakfast.manage') }, async (req, rep) => {
    const b = z.object({ rr_id: z.number().int().positive(), included: z.number().int().min(0).max(30), extra: z.number().int().min(0).max(30), date: zDate.optional() }).parse(req.body);
    const r = await tx((c) => recordBreakfast(c, actorOf(req), b));
    rep.code(201);
    return r;
  });

  // ===================================================== Tableau de bord, rapports, réglages =====================================================
  app.get('/api/rs/dashboard', { preHandler: requirePerm('restaurant.view') }, async (req) => {
    const qs = z.object({ from: zDate.optional(), to: zDate.optional() }).parse(req.query);
    const from = qs.from ?? today(), to = qs.to ?? today();
    if (from > to) throw badRequest('Période invalide.');
    const d = await rsDashboard(getPool(), req.user!.hotelId, from, to);
    return req.user!.perms.has('restaurant.reports') || req.user!.perms.has('restaurant.settle') ? d : { ...d, kpi: { ...d.kpi, revenue: null, avg_ticket: null }, series: [], outlets: [] };
  });
  app.get('/api/rs/reports/:kind', { preHandler: requirePerm('restaurant.reports') }, async (req, rep) => {
    const { kind } = z.object({ kind: z.enum(Object.keys(RS_REPORTS) as [string, ...string[]]) }).parse(req.params);
    const qs = z.object({ from: zDate.optional(), to: zDate.optional(), format: z.enum(['json', 'pdf', 'xlsx', 'csv']).default('json') }).parse(req.query);
    const from = qs.from ?? monthStart(today()), to = qs.to ?? today();
    if (from > to) throw badRequest('Période invalide.');
    const r = await rsReport(getPool(), req.user!.hotelId, kind, from, to);
    if (qs.format === 'json') return r;
    return sendTable(rep, qs.format, `restaurant-${kind}-${from}-${to}`, r.title, `Du ${from} au ${to}`, r.columns, r.rows, r.total, await hotelName(req.user!.hotelId));
  });
  app.get('/api/rs/settings', { preHandler: requirePerm('restaurant.view') }, async (req) => (await getSettings(getPool(), req.user!.hotelId)).restaurant);
  app.put('/api/rs/settings', { preHandler: requirePerm('restaurant.menu') }, async (req) => {
    const b = z.object({ breakfast_start: Time, breakfast_end: Time, breakfast_service_code: z.string().trim().min(1).max(20), stock_block: z.boolean(), table_to_clean: z.boolean(), max_discount_percent: z.number().min(0).max(100) }).parse(req.body);
    if (b.breakfast_end <= b.breakfast_start) throw badRequest('Horaires du petit-déjeuner invalides.');
    const cur = (await getSettings(getPool(), req.user!.hotelId)).restaurant;
    await getPool().query(`INSERT INTO settings (hotel_id, key, value) VALUES ($1,'restaurant',$2) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value`, [req.user!.hotelId, JSON.stringify(b)]);
    await audit(getPool(), actorOf(req), 'update', 'settings', 'restaurant', cur, b);
    return b;
  });
}
