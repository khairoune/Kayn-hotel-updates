/**
 * Scan de pièce d'identité — deux voies, en plus de la saisie manuelle :
 *  1. « Avec mon téléphone » : le poste affiche un QR code ; le téléphone (même réseau Wi-Fi) ouvre une page de prise
 *     de vue protégée par un jeton à usage limité (15 min), sans compte ni application à installer.
 *  2. « Importer une photo » : image venant d'un scanner, d'une webcam ou d'un fichier.
 * La photo est lue localement (MRZ), le résultat est proposé dans le formulaire : l'agent vérifie puis enregistre.
 */
import type { FastifyInstance } from 'fastify';
import { createHash, randomBytes } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import QRCode from 'qrcode';
import { z } from 'zod';
import { config } from '../config.js';
import { getPool, one, q } from '../db/pool.js';
import { actorOf, requireAuth } from '../lib/auth.js';
import { audit } from '../lib/audit.js';
import { AppError, badRequest, forbidden, notFound } from '../lib/errors.js';
import { lanAddresses } from '../services/admin.js';
import { getSettings } from '../services/common.js';
import { readMrz } from '../services/idscan.js';

const DIR = () => { const d = process.env.ID_SCAN_DIR ?? fileURLToPath(new URL('../../data/id-scans', import.meta.url)); mkdirSync(d, { recursive: true }); return d; };
const sha = (s: string) => createHash('sha256').update(s).digest('hex');
const PERMS = ['reservations.create', 'reservations.edit', 'frontoffice.checkin', 'guests.edit'];
const MAX = 10 * 1024 * 1024;
const kind = (b: Buffer) => (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff ? 'image/jpeg' : b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) ? 'image/png' : null);
const needScan = async (req: any) => { await requireAuth(req, null as any); if (!PERMS.some((p) => req.user!.perms.has(p))) throw forbidden('Permission requise : réservations, arrivées ou fiches clients.'); };

/** Adresses réseau du poste, les adresses domestiques (192.168 / 10 / 172.16-31) en premier. */
function lanUrls(token: string) {
  const ips = lanAddresses().sort((a, b) => Number(!/^(192\.168|10\.|172\.(1[6-9]|2\d|3[01]))/.test(a)) - Number(!/^(192\.168|10\.|172\.(1[6-9]|2\d|3[01]))/.test(b)));
  return ips.map((ip) => `http://${ip}:${config.port}/scan/${token}`);
}

async function storeAndRead(scan: any, buf: Buffer, source: 'phone' | 'upload') {
  const mime = kind(buf);
  if (!mime) throw badRequest('Format refusé : photo JPEG ou PNG uniquement.');
  if (scan.file_path) { try { unlinkSync(scan.file_path); } catch { /* */ } }
  const file = path.join(DIR(), `scan-${scan.id}-${Date.now()}.${mime === 'image/png' ? 'png' : 'jpg'}`);
  writeFileSync(file, buf, { mode: 0o600 });
  await getPool().query(`UPDATE id_scans SET status = 'uploaded', file_path = $2, mime = $3, size_bytes = $4, uploads = uploads + 1, source = $5, uploaded_at = now(), mrz = NULL WHERE id = $1`,
    [scan.id, file, mime, buf.length, source]);
  let res;
  try { res = await readMrz(buf); } catch (e: any) { res = { read: false, valid: false, format: null, lines: [], checks: [], fields: null, ms: 0, error: String(e?.message ?? e).slice(0, 200) }; }
  await getPool().query(`UPDATE id_scans SET status = $2, mrz = $3 WHERE id = $1`, [scan.id, res.read ? 'read' : 'unreadable', JSON.stringify(res)]);
  return res;
}

const view = (s: any) => ({ id: Number(s.id), status: s.status, source: s.source, uploads: s.uploads, has_image: !!s.file_path && !s.image_deleted_at, result: s.mrz, expires_at: s.expires_at, uploaded_at: s.uploaded_at });

export async function idScanRoutes(app: FastifyInstance) {
  // ------------------------------------------------------------ côté poste (connecté)
  app.post('/api/id-scans', { preHandler: needScan }, async (req, rep) => {
    const b = z.object({ context: z.enum(['reservation', 'checkin', 'guest']).default('reservation') }).parse(req.body ?? {});
    const token = randomBytes(18).toString('base64url');
    const s = await one<any>(getPool(), `INSERT INTO id_scans (hotel_id, token_hash, created_by, context, expires_at) VALUES ($1,$2,$3,$4, now() + interval '15 minutes') RETURNING *`,
      [req.user!.hotelId, sha(token), req.user!.id, b.context]);
    const urls = lanUrls(token);
    await audit(getPool(), actorOf(req), 'create', 'id_scan', s.id, null, { context: b.context });
    rep.code(201);
    return { ...view(s), urls, qr: urls[0] ? await QRCode.toString(urls[0], { type: 'svg', margin: 1, width: 220, errorCorrectionLevel: 'M' }) : null, qrs: await Promise.all(urls.map((u) => QRCode.toString(u, { type: 'svg', margin: 1, width: 220 }))) };
  });
  const own = async (req: any) => {
    const { id } = z.object({ id: z.coerce.number().int().positive() }).parse(req.params);
    const s = await one<any>(getPool(), 'SELECT * FROM id_scans WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!s) throw notFound('Scan introuvable');
    return s;
  };
  app.get('/api/id-scans/:id', { preHandler: needScan }, async (req) => view(await own(req)));
  app.get('/api/id-scans/:id/image', { preHandler: needScan }, async (req, rep) => {
    const s = await own(req);
    if (!s.file_path || s.image_deleted_at || !existsSync(s.file_path)) throw notFound('Photo non disponible (effacée ou pas encore reçue).');
    rep.header('content-type', s.mime).header('cache-control', 'no-store');
    return rep.send(readFileSync(s.file_path));
  });
  /** Import depuis le poste (scanner, webcam, fichier). */
  app.post('/api/id-scans/:id/upload', { preHandler: needScan }, async (req) => {
    const s = await own(req);
    if (['used', 'expired'].includes(s.status)) throw new AppError(409, 'scan_closed', 'Ce scan est terminé : relancez un nouveau scan.');
    const file = await (req as any).file({ limits: { fileSize: MAX } });
    if (!file) throw badRequest('Aucune image reçue.');
    const buf: Buffer = await file.toBuffer().catch(() => { throw badRequest('Image trop lourde (10 Mo maximum).'); });
    const res = await storeAndRead(s, buf, 'upload');
    await audit(getPool(), actorOf(req), 'upload', 'id_scan', s.id, null, { source: 'upload', read: res.read, valid: res.valid });
    return view(await one<any>(getPool(), 'SELECT * FROM id_scans WHERE id = $1', [s.id]));
  });
  /** Données utilisées pour le client : la photo est rattachée à sa fiche jusqu'à son effacement automatique. */
  app.post('/api/id-scans/:id/use', { preHandler: needScan }, async (req) => {
    const s = await own(req);
    const b = z.object({ guest_id: z.number().int().positive().nullish() }).parse(req.body ?? {});
    if (b.guest_id && !(await one(getPool(), 'SELECT 1 FROM guests WHERE id = $1 AND hotel_id = $2', [b.guest_id, req.user!.hotelId]))) throw notFound('Client introuvable');
    const keep = Number((await getSettings(getPool(), req.user!.hotelId)).id_scans?.keep_days ?? 30);
    await getPool().query(`UPDATE id_scans SET status = 'used', used_at = now(), guest_id = COALESCE($2, guest_id) WHERE id = $1`, [s.id, b.guest_id ?? null]);
    if (keep <= 0 && s.file_path) { try { unlinkSync(s.file_path); } catch { /* */ } await getPool().query('UPDATE id_scans SET image_deleted_at = now() WHERE id = $1', [s.id]); }
    await audit(getPool(), actorOf(req), 'use', 'id_scan', s.id, null, { guest_id: b.guest_id ?? null });
    return { ok: true };
  });
  app.get('/api/guests/:id/id-scans', { preHandler: needScan }, async (req) => {
    const { id } = z.object({ id: z.coerce.number().int().positive() }).parse(req.params);
    return q(getPool(), `SELECT id, source, created_at, used_at, (file_path IS NOT NULL AND image_deleted_at IS NULL) AS has_image FROM id_scans WHERE guest_id = $1 AND hotel_id = $2 ORDER BY id DESC`, [id, req.user!.hotelId]);
  });

  // ------------------------------------------------------------ côté téléphone (public, jeton)
  const byToken = async (token: string) => {
    if (!/^[A-Za-z0-9_-]{20,40}$/.test(token)) return null;
    return one<any>(getPool(), `SELECT * FROM id_scans WHERE token_hash = $1`, [sha(token)]);
  };
  app.get('/scan/:token', async (req, rep) => {
    const { token } = req.params as any;
    const s = await byToken(token);
    const open = s && s.status !== 'used' && s.status !== 'expired' && new Date(s.expires_at) > new Date();
    rep.header('content-type', 'text/html; charset=utf-8').header('cache-control', 'no-store').header('referrer-policy', 'no-referrer');
    return rep.send(phonePage(open ? token : null));
  });
  app.post('/api/scan/:token', { config: { rateLimit: { max: 12, timeWindow: '1 minute' } } }, async (req) => {
    const { token } = req.params as any;
    const s = await byToken(token);
    if (!s || s.status === 'used' || s.status === 'expired' || new Date(s.expires_at) < new Date()) throw new AppError(410, 'scan_expired', 'Lien expiré : affichez un nouveau QR code sur le poste.');
    if (s.uploads >= 8) throw new AppError(429, 'scan_limit', 'Trop d\'envois pour ce scan : relancez un nouveau scan sur le poste.');
    const file = await (req as any).file({ limits: { fileSize: MAX } });
    if (!file) throw badRequest('Aucune photo reçue.');
    const buf: Buffer = await file.toBuffer().catch(() => { throw badRequest('Photo trop lourde (10 Mo maximum).'); });
    const res = await storeAndRead(s, buf, 'phone');
    await getPool().query(`INSERT INTO audit_logs (hotel_id, user_id, action, entity, entity_id, after, ip, user_agent) VALUES ($1,$2,'upload','id_scan',$3,$4,$5,$6)`,
      [s.hotel_id, s.created_by, String(s.id), JSON.stringify({ source: 'phone', read: res.read, valid: res.valid }), req.ip, String(req.headers['user-agent'] ?? '').slice(0, 200)]).catch(() => {});
    return { ok: true, read: res.read, valid: res.valid, name: res.fields ? [res.fields.last_name, res.fields.first_name].filter(Boolean).join(' ') : null };
  });
}

/** Expiration des jetons et effacement des photos (planificateur). */
export async function purgeIdScans(hotelId: number) {
  const keep = Number((await getSettings(getPool(), hotelId)).id_scans?.keep_days ?? 30);
  await getPool().query(`UPDATE id_scans SET status = 'expired' WHERE hotel_id = $1 AND status IN ('pending','uploaded','read','unreadable') AND expires_at < now() - interval '1 day'`, [hotelId]);
  const old = await q<any>(getPool(), `SELECT id, file_path FROM id_scans WHERE hotel_id = $1 AND file_path IS NOT NULL AND image_deleted_at IS NULL
      AND (created_at < now() - ($2 || ' days')::interval OR (status = 'expired' AND guest_id IS NULL))`, [hotelId, String(Math.max(0, keep))]);
  for (const o of old) { try { unlinkSync(o.file_path); } catch { /* déjà absent */ } await getPool().query('UPDATE id_scans SET image_deleted_at = now() WHERE id = $1', [o.id]); }
  return old.length;
}

/** Page mobile autonome (aucune dépendance) : guide de cadrage, compression locale, envoi, résultat. */
function phonePage(token: string | null) {
  return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>KAYN Hotel — Scan de pièce</title><style>
body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#1a1416;color:#fff;min-height:100vh;display:flex;flex-direction:column;align-items:center}
.top{width:100%;background:#7A1F2B;padding:14px 18px;font-weight:700;box-sizing:border-box}.top span{color:#C9A227}
.c{width:min(460px,92vw);padding:18px 0}.card{background:#fff;color:#222;border-radius:14px;padding:16px;margin-bottom:12px}
.frame{border:3px dashed #C9A227;border-radius:12px;aspect-ratio:1.58;display:flex;align-items:flex-end;justify-content:center;padding:8px;box-sizing:border-box;background:#f6f1e7;color:#555;font-size:13px}
.mrz{font-family:monospace;background:#e8e2d5;border-radius:6px;padding:4px 8px;letter-spacing:1px}
.btn{display:block;width:100%;border:0;border-radius:12px;padding:16px;font-size:17px;font-weight:700;margin-top:10px;cursor:pointer}
.p{background:#7A1F2B;color:#fff}.s{background:#eee;color:#222}ol{padding-left:20px;margin:6px 0}li{margin:4px 0;font-size:14px}
img{max-width:100%;border-radius:10px;margin-top:8px}.ok{color:#15803D;font-weight:700}.ko{color:#B45309;font-weight:700}.err{color:#B91C1C;font-weight:700}
.ar{direction:rtl;text-align:right;font-size:14px;color:#444;margin-top:8px}
</style></head><body><div class="top">KAYN <span>Hotel</span> · Scan de pièce d'identité</div><div class="c">
${token ? `<div class="card"><div class="frame"><div><div style="text-align:center;margin-bottom:6px">Cadrez toute la carte, bien droite</div><div class="mrz">P&lt;DZA… / IDDZA…&lt;&lt;&lt;</div></div></div>
<ol><li><b>Passeport</b> : page photo. <b>CNI biométrique</b> : le <b>dos</b> (lignes « &lt;&lt;&lt; »).</li><li>Posez la pièce à plat, sans reflet, bien éclairée.</li><li>Les lignes &lt;&lt;&lt; doivent être nettes et entières.</li></ol>
<div class="ar">صوّر جواز السفر (صفحة الصورة) أو ظهر بطاقة التعريف البيومترية. ضع الوثيقة مستوية، بدون انعكاس، وبإضاءة جيدة.</div>
<input id="f" type="file" accept="image/*" capture="environment" hidden>
<button class="btn p" id="go">📷 Prendre la photo · التقاط الصورة</button>
<button class="btn s" id="pick">Choisir une photo existante</button></div>
<div class="card" id="st" hidden></div>
<script>
const f=document.getElementById('f'),st=document.getElementById('st');
document.getElementById('go').onclick=()=>{f.setAttribute('capture','environment');f.click()};
document.getElementById('pick').onclick=()=>{f.removeAttribute('capture');f.click()};
function shrink(file){return new Promise((ok,ko)=>{const u=URL.createObjectURL(file),i=new Image();i.onload=()=>{const m=2000,r=Math.min(1,m/Math.max(i.width,i.height));const c=document.createElement('canvas');c.width=Math.round(i.width*r);c.height=Math.round(i.height*r);c.getContext('2d').drawImage(i,0,0,c.width,c.height);c.toBlob(b=>{URL.revokeObjectURL(u);b?ok(b):ko(new Error('image'))},'image/jpeg',0.9)};i.onerror=()=>ko(new Error('Photo illisible'));i.src=u})}
f.onchange=async()=>{const file=f.files[0];if(!file)return;st.hidden=false;st.innerHTML='<b>Envoi et lecture en cours…</b> · جارٍ الإرسال';
try{const b=await shrink(file);const fd=new FormData();fd.append('file',b,'piece.jpg');
const r=await fetch('/api/scan/${token}',{method:'POST',headers:{'x-kayn-client':'web'},body:fd});const j=await r.json();
if(!r.ok)throw new Error(j.message||'Erreur');
st.innerHTML=(j.valid?'<div class="ok">✓ Pièce lue'+(j.name?' : '+j.name.replace(/[<>&]/g,''):'')+'</div>':j.read?'<div class="ko">Lecture partielle : vérifiez les champs à l\\'écran du poste.</div>':'<div class="ko">Photo reçue, mais les lignes &lt;&lt;&lt; n\\'ont pas pu être lues. Reprenez la photo plus nette, ou saisissez à la main sur le poste.</div>')+'<p>Retournez au poste : les informations s\\'y affichent.</p><img src="'+URL.createObjectURL(b)+'">';
}catch(e){st.innerHTML='<div class="err">'+String(e.message).replace(/[<>&]/g,'')+'</div>'}f.value=''};
</script>` : `<div class="card"><b>Lien expiré ou déjà utilisé.</b><p>Sur le poste, cliquez à nouveau sur « Scanner avec mon téléphone » pour afficher un nouveau QR code.</p><div class="ar">انتهت صلاحية الرابط. أعد المسح من الحاسوب.</div></div>`}
</div></body></html>`;
}
