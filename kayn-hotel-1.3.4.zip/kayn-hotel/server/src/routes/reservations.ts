import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { getPool, one, q, tx } from '../db/pool.js';
import { actorOf, requirePerm } from '../lib/auth.js';
import { addDays, isDate, today } from '../lib/dates.js';
import { badRequest, forbidden, notFound } from '../lib/errors.js';
import { BALANCE_EXPR, FIN_SQL, getSettings, guestDisplayName, withBalance } from '../services/common.js';
import { reservationsPdf, reservationsXlsx, voucherPdf } from '../services/exports.js';
import { buildMessage, processEmailOutbox, queueReminders, waNumber } from '../services/notifications.js';
import {
  addPayment, addRoomToReservation, cancelReservation, cancellationQuote, cancelReservationRoom, checkIn, checkOut, confirmReservation, createReservation,
  getReservation, moveReservationRoom, setRoomOccupant, updateReservationInfo, voidPayment,
} from '../services/reservations.js';

const zDate = z.string().refine(isDate, 'Date invalide (AAAA-MM-JJ)');
const zOptStr = z.string().max(500).nullish();
const Guest = z.object({
  id: z.number().int().positive().optional(),
  kind: z.enum(['person', 'company', 'agency']).optional(),
  last_name: zOptStr, first_name: zOptStr, company_name: zOptStr,
  phone: z.string().max(40).nullish(), email: z.string().max(120).nullish(),
  nationality: zOptStr, gender: z.enum(['M', 'F']).nullish(), birth_date: zDate.nullish(), birth_place: zOptStr,
  id_doc_type: z.enum(['cni', 'passport', 'permis', 'other']).nullish(), id_doc_number: zOptStr, id_doc_expiry: zDate.nullish(),
  address: zOptStr, city: zOptStr, country: zOptStr, profession: zOptStr, father_name: zOptStr, mother_name: zOptStr,
  nif: zOptStr, notes: zOptStr, language: z.enum(['fr', 'en', 'ar']).optional(),
});
const Method = z.enum(['cash', 'card', 'cheque', 'transfer', 'company_account', 'online']);
const Discount = z.object({ type: z.enum(['percent', 'amount']), value: z.number().min(0).max(100_000_000) }).nullish();
const RoomReq = z.object({
  room_id: z.number().int().positive(),
  adults: z.number().int().min(1).max(12).optional(),
  children: z.number().int().min(0).max(12).optional(),
  rate: z.number().min(0).max(10_000_000).nullish(),
  guest: Guest.nullish(),
  check_in: zDate.optional(),
  check_out: zDate.optional(),
});
const CreateBody = z.object({
  guest: Guest,
  payer: Guest.nullish(),
  booker_type: z.enum(['individual', 'group', 'company', 'agency']).optional(),
  group_name: zOptStr,
  source: z.enum(['walk_in', 'phone', 'email', 'company', 'agency', 'website', 'other']).optional(),
  status: z.enum(['pending', 'confirmed']).optional(),
  check_in: zDate,
  check_out: zDate,
  meal_plan: z.enum(['RO', 'BB', 'HB', 'FB']).optional(),
  rate_mode: z.enum(['standard', 'custom']).optional(),
  rate_plan_id: z.number().int().positive().nullish(),
  discount: Discount,
  billing_mode: z.enum(['common', 'individual']).optional(),
  notes: z.string().max(2000).nullish(),
  special_requests: z.string().max(2000).nullish(),
  deposit_required: z.number().min(0).optional(),
  rooms: z.array(RoomReq).min(1).max(60),
  deposit: z.object({ amount: z.number().positive(), method: Method, reference: zOptStr }).nullish(),
  override_policy: z.boolean().optional(),
});
const Id = z.object({ id: z.coerce.number().int().positive() });

const STATUSES = ['pending', 'confirmed', 'checked_in', 'checked_out', 'cancelled', 'no_show'] as const;
const ListQuery = z.object({
  search: z.string().max(80).optional(),
  status: z.string().max(120).optional(),                     // liste séparée par des virgules
  booker_type: z.enum(['individual', 'group', 'company', 'agency']).optional(),
  source: z.enum(['walk_in', 'phone', 'email', 'company', 'agency', 'website', 'other']).optional(),
  room_type_id: z.coerce.number().int().positive().optional(),
  arrival_from: zDate.optional(),
  arrival_to: zDate.optional(),
  stay_on: zDate.optional(),
  created_from: zDate.optional(),
  balance_due: z.enum(['true', 'false']).optional(),
  sort: z.enum(['arrival_asc', 'arrival_desc', 'departure_asc', 'created_desc', 'balance_desc']).default('arrival_desc'),
  page: z.coerce.number().int().min(1).default(1),
  page_size: z.coerce.number().int().min(10).max(200).default(25),
});

const ORDER: Record<string, string> = {
  arrival_asc: 'x.check_in ASC, x.id ASC',
  arrival_desc: 'x.check_in DESC, x.id DESC',
  departure_asc: 'x.check_out ASC, x.id ASC',
  created_desc: 'x.created_at DESC, x.id DESC',
  balance_desc: 'x_balance DESC, x.id DESC',
};

/** Requête de liste partagée (écran, export Excel, export PDF). */
async function listReservations(hotelId: number, qs: z.infer<typeof ListQuery>, limit: number | null) {
  const params: unknown[] = [hotelId];
  const where = ['r.hotel_id = $1'];
  const add = (sql: string, v: unknown) => { params.push(v); where.push(sql.replace('$?', `$${params.length}`)); };
  if (qs.search?.trim()) {
    params.push(`%${qs.search.trim().toLowerCase()}%`);
    const p = `$${params.length}`;
    params.push(qs.search.trim());
    const p2 = `$${params.length}`;
    where.push(`(lower(r.code) LIKE ${p}
      OR lower(coalesce(g.last_name,'') || ' ' || coalesce(g.first_name,'') || ' ' || coalesce(g.company_name,'') || ' ' || coalesce(r.group_name,'') || ' ' || coalesce(pg.company_name,'')) LIKE ${p}
      OR coalesce(g.phone,'') LIKE ${p}
      OR EXISTS (SELECT 1 FROM reservation_rooms rr JOIN rooms rm ON rm.id = rr.room_id WHERE rr.reservation_id = r.id AND rm.number = ${p2})
      OR EXISTS (SELECT 1 FROM reservation_rooms rr JOIN guests og ON og.id = rr.guest_id WHERE rr.reservation_id = r.id
                 AND lower(coalesce(og.last_name,'') || ' ' || coalesce(og.first_name,'')) LIKE ${p}))`);
  }
  if (qs.status) {
    const st = qs.status.split(',').filter((s) => (STATUSES as readonly string[]).includes(s));
    if (st.length) add('r.status = ANY($?::text[])', st);
  }
  if (qs.booker_type) add('r.booker_type = $?', qs.booker_type);
  if (qs.source) add('r.source = $?', qs.source);
  if (qs.room_type_id) add(`EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.reservation_id = r.id AND rr.room_type_id = $?)`, qs.room_type_id);
  if (qs.arrival_from) add('r.check_in >= $?', qs.arrival_from);
  if (qs.arrival_to) add('r.check_in <= $?', qs.arrival_to);
  if (qs.stay_on) {
    params.push(qs.stay_on);
    where.push(`r.check_in <= $${params.length} AND r.check_out > $${params.length}`);
  }
  if (qs.created_from) add(`r.created_at >= $?::date`, qs.created_from);

  const base = `
    SELECT r.id, r.code, r.status, r.check_in, r.check_out, (r.check_out - r.check_in) AS nights, r.booker_type, r.group_name, r.source,
           r.meal_plan, r.adults, r.children, r.adults + r.children AS persons, r.created_at,
           g.kind, g.last_name, g.first_name, g.company_name, g.phone, g.email, pg.company_name AS payer_name,
           (SELECT string_agg(rm.number, ', ' ORDER BY rm.number) FROM reservation_rooms rr JOIN rooms rm ON rm.id = rr.room_id
             WHERE rr.reservation_id = r.id AND rr.status NOT IN ('cancelled','no_show')) AS rooms,
           (SELECT string_agg(DISTINCT rt.name, ', ') FROM reservation_rooms rr JOIN room_types rt ON rt.id = rr.room_type_id
             WHERE rr.reservation_id = r.id AND rr.status NOT IN ('cancelled','no_show')) AS room_types,
           (SELECT count(*) FROM reservation_rooms rr WHERE rr.reservation_id = r.id AND rr.status NOT IN ('cancelled','no_show'))::int AS room_count,
           ${FIN_SQL}
      FROM reservations r JOIN guests g ON g.id = r.guest_id LEFT JOIN guests pg ON pg.id = r.payer_guest_id
     WHERE ${where.join(' AND ')}`;
  const balanceSql = BALANCE_EXPR;
  const filtered = `SELECT x.*, ${balanceSql} AS x_balance FROM (${base}) x ${qs.balance_due === 'true' ? `WHERE ${balanceSql} > 0` : ''}`;
  const pool = getPool();
  const totals = await one<any>(pool, `SELECT count(*)::int AS n, COALESCE(sum(GREATEST(y.x_balance, 0)), 0) AS due FROM (${filtered}) y`, params);
  let sql = `SELECT * FROM (${filtered}) x ORDER BY ${ORDER[qs.sort]}`;
  if (limit !== null) {
    params.push(limit, (qs.page - 1) * limit);
    sql += ` LIMIT $${params.length - 1} OFFSET $${params.length}`;
  }
  const rows = await q<any>(pool, sql, params);
  return {
    total: totals.n,
    total_due: Number(totals.due),
    rows: rows.map((r) => {
      const f = withBalance(r);
      return { ...f, guest_name: guestDisplayName(r), paid_net: Number(r.paid) - Number(r.refunded), deposits: Number(r.deposits) };
    }),
  };
}

export async function reservationRoutes(app: FastifyInstance) {
  // ===== Planning =====
  app.get('/api/planning', { preHandler: requirePerm('planning.view') }, async (req) => {
    const qs = z.object({
      from: zDate.optional(),
      days: z.coerce.number().int().min(1).max(62).default(14),
      include_cancelled: z.coerce.boolean().optional(),
    }).parse(req.query);
    const from = qs.from ?? today();
    const to = addDays(from, qs.days);
    const hotelId = req.user!.hotelId;
    const pool = getPool();
    const rooms = await q<any>(
      pool,
      `SELECT r.id, r.number, r.hk_status, r.out_of_service, r.oos_reason, f.number AS floor, f.name AS floor_name,
              t.id AS type_id, t.code AS type_code, t.name AS type_name, COALESCE(r.capacity, t.capacity) AS capacity, t.base_rate,
              b.name AS building_name, (SELECT count(*) FROM buildings bb WHERE bb.hotel_id = r.hotel_id)::int AS building_count,
              EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL) AS occupied
         FROM rooms r JOIN floors f ON f.id = r.floor_id JOIN buildings b ON b.id = f.building_id JOIN room_types t ON t.id = r.room_type_id
        WHERE r.hotel_id = $1 AND r.active ORDER BY b.name, f.number, length(r.number), r.number`,
      [hotelId],
    );
    const blocks = await q<any>(
      pool,
      `SELECT bl.id, bl.room_id, bl.kind, bl.start_date, bl.end_date, bl.reason FROM room_blocks bl JOIN rooms r ON r.id = bl.room_id
        WHERE r.hotel_id = $1 AND bl.status = 'active' AND bl.start_date < $3 AND (bl.end_date IS NULL OR bl.end_date > $2)`,
      [hotelId, from, to],
    );
    const statuses = qs.include_cancelled ? [...STATUSES] : ['pending', 'confirmed', 'checked_in', 'checked_out'];
    const bars = await q<any>(
      pool,
      `SELECT rr.id AS rr_id, rr.reservation_id, rr.room_id, rr.check_in, rr.check_out, rr.status, rr.rate, rr.adults, rr.children,
              r.code, r.booker_type, r.group_name, r.source, r.meal_plan, r.status AS reservation_status,
              g.kind, g.last_name, g.first_name, g.company_name, g.phone,
              og.kind AS o_kind, og.last_name AS o_last, og.first_name AS o_first, og.company_name AS o_company,
              (SELECT count(*) FROM reservation_rooms x WHERE x.reservation_id = r.id AND x.status NOT IN ('cancelled','no_show'))::int AS room_count,
              ${FIN_SQL}
         FROM reservation_rooms rr
         JOIN reservations r ON r.id = rr.reservation_id
         JOIN guests g ON g.id = r.guest_id
         LEFT JOIN guests og ON og.id = rr.guest_id
        WHERE r.hotel_id = $1 AND rr.status = ANY($4::text[])
          AND rr.check_in < $3 AND rr.check_out > $2
        ORDER BY rr.check_in`,
      [hotelId, from, to, statuses],
    );
    return {
      from, to, days: qs.days, today: today(),
      rooms, blocks,
      bars: bars.map((b) => {
        const f = withBalance(b);
        const occupant = b.o_kind ? guestDisplayName({ kind: b.o_kind, last_name: b.o_last, first_name: b.o_first, company_name: b.o_company }) : null;
        return {
          rr_id: b.rr_id, reservation_id: b.reservation_id, room_id: b.room_id, check_in: b.check_in, check_out: b.check_out,
          status: b.status, rate: Number(b.rate), adults: b.adults, children: b.children, code: b.code, booker_type: b.booker_type,
          group_name: b.group_name, source: b.source, meal_plan: b.meal_plan, guest_name: occupant ?? guestDisplayName(b), booker_name: guestDisplayName(b),
          phone: b.phone, room_count: b.room_count, total: f.total, paid: Number(b.paid) - Number(b.refunded), balance: f.balance,
        };
      }),
    };
  });

  // ===== Disponibilités =====
  app.get('/api/availability', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const qs = z.object({ check_in: zDate, check_out: zDate, exclude_rr: z.coerce.number().int().optional() }).parse(req.query);
    if (qs.check_out <= qs.check_in) throw badRequest('Dates invalides.');
    return q(
      getPool(),
      `SELECT r.id, r.number, r.hk_status, r.out_of_service, f.number AS floor, t.id AS type_id, t.name AS type_name,
              COALESCE(r.capacity, t.capacity) AS capacity, t.max_adults, t.base_rate, r.rate_supplement
         FROM rooms r JOIN floors f ON f.id = r.floor_id JOIN room_types t ON t.id = r.room_type_id
        WHERE r.hotel_id = $1 AND r.active
          AND NOT EXISTS (SELECT 1 FROM room_blocks b WHERE b.room_id = r.id AND b.status = 'active' AND b.kind = 'out_of_service'
                           AND b.start_date < $3::date AND (b.end_date IS NULL OR b.end_date > $2::date))
          AND NOT EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.room_id = r.id
                           AND rr.status IN ('pending','confirmed','checked_in','checked_out')
                           AND daterange(rr.check_in, rr.check_out, '[)') && daterange($2::date, $3::date, '[)')
                           AND ($4::int IS NULL OR rr.id <> $4))
          -- client encore physiquement en chambre (départ en retard) : la chambre n'est pas libre aujourd'hui
          AND NOT ($2::date <= $5::date AND EXISTS (SELECT 1 FROM stays s WHERE s.room_id = r.id AND s.checked_out_at IS NULL
                                                    AND ($4::int IS NULL OR s.reservation_room_id <> $4)))
        ORDER BY f.number, length(r.number), r.number`,
      [req.user!.hotelId, qs.check_in, qs.check_out, qs.exclude_rr ?? null, today()],
    );
  });

  // ===== Clients (autocomplétion) =====
  app.get('/api/guests', { preHandler: requirePerm('guests.view') }, async (req) => {
    const qs = z.object({ search: z.string().max(80).default(''), kind: z.enum(['person', 'company', 'agency']).optional() }).parse(req.query);
    const s = `%${qs.search.trim().toLowerCase()}%`;
    return q(
      getPool(),
      `SELECT id, kind, last_name, first_name, company_name, phone, email, nationality, address, id_doc_type, id_doc_number
         FROM guests WHERE hotel_id = $1 AND ($3::text IS NULL OR kind = $3)
          AND (lower(coalesce(last_name,'') || ' ' || coalesce(first_name,'') || ' ' || coalesce(company_name,'')) LIKE $2
               OR coalesce(phone,'') LIKE $2 OR lower(coalesce(id_doc_number,'')) LIKE $2)
        ORDER BY updated_at DESC LIMIT 20`,
      [req.user!.hotelId, s, qs.kind ?? null],
    );
  });

  // ===== Réservations =====
  app.get('/api/reservations', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const qs = ListQuery.parse(req.query);
    const res = await listReservations(req.user!.hotelId, qs, qs.page_size);
    return { ...res, page: qs.page, page_size: qs.page_size };
  });

  app.get('/api/reservations/export', { preHandler: requirePerm('reservations.view') }, async (req, rep) => {
    const qs = ListQuery.extend({ format: z.enum(['xlsx', 'pdf']) }).parse(req.query);
    const { rows } = await listReservations(req.user!.hotelId, qs, 5000);
    const hotel = await one<any>(getPool(), 'SELECT name FROM hotels WHERE id = $1', [req.user!.hotelId]);
    const title = `Liste des réservations — ${today()}`;
    const stamp = today();
    if (qs.format === 'xlsx') {
      const buf = await reservationsXlsx(rows, `${hotel.name} — ${title}`);
      rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      rep.header('content-disposition', `attachment; filename="reservations-${stamp}.xlsx"`);
      return rep.send(buf);
    }
    const buf = await reservationsPdf(rows, title, hotel.name);
    rep.header('content-type', 'application/pdf');
    rep.header('content-disposition', `attachment; filename="reservations-${stamp}.pdf"`);
    return rep.send(buf);
  });

  app.get('/api/reservations/:id', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    return getReservation(getPool(), req.user!.hotelId, id);
  });

  app.get('/api/reservations/:id/voucher.pdf', { preHandler: requirePerm('reservations.view') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const r = await getReservation(getPool(), req.user!.hotelId, id);
    const hotel = await one<any>(getPool(), 'SELECT * FROM hotels WHERE id = $1', [req.user!.hotelId]);
    const buf = await voucherPdf(r, hotel, await getSettings(getPool(), req.user!.hotelId));
    rep.header('content-type', 'application/pdf');
    rep.header('content-disposition', `inline; filename="voucher-${r.code}.pdf"`);
    return rep.send(buf);
  });

  app.get('/api/reservations/:id/history', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    await getReservation(getPool(), req.user!.hotelId, id);
    return q(
      getPool(),
      `SELECT a.id, a.action, a.entity, a.entity_id, a.before, a.after, a.created_at, u.full_name AS user_name
         FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
        WHERE (a.entity = 'reservation' AND a.entity_id = $1)
           OR (a.entity = 'reservation_room' AND a.entity_id IN (SELECT id::text FROM reservation_rooms WHERE reservation_id = $2))
           OR (a.entity = 'payment' AND a.entity_id IN (SELECT id::text FROM payments WHERE reservation_id = $2))
           OR (a.entity = 'invoice' AND a.entity_id IN (SELECT id::text FROM invoices WHERE reservation_id = $2))
        ORDER BY a.created_at, a.id`,
      [String(id), id],
    );
  });

  app.post('/api/reservations', { preHandler: requirePerm('reservations.create') }, async (req, rep) => {
    const body = CreateBody.parse(req.body);
    if (body.deposit && !req.user!.perms.has('payments.create')) throw badRequest('Vous n\'avez pas le droit d\'encaisser un acompte.');
    if (body.override_policy && !req.user!.perms.has('reservations.override_policy')) throw forbidden('Dérogation à la politique d\'acompte non autorisée.');
    const res = await tx((c) => createReservation(c, actorOf(req), body as any, { overridePolicy: !!body.override_policy }));
    rep.code(201);
    return res;
  });

  app.patch('/api/reservations/:id', { preHandler: requirePerm('reservations.edit') }, async (req) => {
    const { id } = Id.parse(req.params);
    const body = z.object({
      source: CreateBody.shape.source, booker_type: CreateBody.shape.booker_type, group_name: zOptStr,
      notes: z.string().max(2000).nullish(), special_requests: z.string().max(2000).nullish(), deposit_required: z.number().min(0).optional(),
      billing_mode: z.enum(['common', 'individual']).optional(), meal_plan: z.enum(['RO', 'BB', 'HB', 'FB']).optional(),
      rate_plan_id: z.number().int().positive().nullable().optional(),
      discount: Discount, guest: Guest.omit({ id: true, kind: true }).partial().optional(), payer: Guest.nullish(),
    }).parse(req.body);
    return tx((c) => updateReservationInfo(c, actorOf(req), id, body as any));
  });

  app.post('/api/reservations/:id/confirm', { preHandler: requirePerm('reservations.edit') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ override: z.boolean().optional() }).parse(req.body ?? {});
    if (b.override && !req.user!.perms.has('reservations.override_policy')) throw forbidden('Dérogation à la politique d\'acompte non autorisée.');
    return tx((c) => confirmReservation(c, actorOf(req), id, { override: b.override }));
  });

  app.post('/api/reservations/:id/cancel', { preHandler: requirePerm('reservations.cancel') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(2).max(500), waive_fee: z.boolean().optional() }).parse(req.body);
    if (b.waive_fee && !req.user!.perms.has('reservations.override_policy')) throw forbidden('Annulation des frais non autorisée.');
    return tx((c) => cancelReservation(c, actorOf(req), id, b.reason, false, { waive_fee: b.waive_fee }));
  });

  app.post('/api/reservations/:id/no-show', { preHandler: requirePerm('reservations.cancel') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(2).max(500).default('Client non présenté'), waive_fee: z.boolean().optional() }).parse(req.body ?? {});
    if (b.waive_fee && !req.user!.perms.has('reservations.override_policy')) throw forbidden('Annulation des frais non autorisée.');
    return tx((c) => cancelReservation(c, actorOf(req), id, b.reason, true, { waive_fee: b.waive_fee }));
  });

  app.get('/api/reservations/:id/cancellation-quote', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    const qs = z.object({ no_show: z.enum(['true', 'false']).optional() }).parse(req.query);
    return cancellationQuote(getPool(), req.user!.hotelId, id, qs.no_show === 'true');
  });

  app.post('/api/reservations/:id/rooms', { preHandler: requirePerm('reservations.edit') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = RoomReq.parse(req.body);
    const r = await tx((c) => addRoomToReservation(c, actorOf(req), id, b as any));
    rep.code(201);
    return r;
  });

  // ===== Chambre d'une réservation =====
  app.patch('/api/reservation-rooms/:id', { preHandler: requirePerm('reservations.edit') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({
      room_id: z.number().int().positive().optional(), check_in: zDate.optional(), check_out: zDate.optional(),
      adults: z.number().int().min(1).max(12).optional(), children: z.number().int().min(0).max(12).optional(), rate: z.number().min(0).nullish(),
    }).parse(req.body);
    return tx((c) => moveReservationRoom(c, actorOf(req), id, { ...b, rate: b.rate ?? undefined }));
  });

  app.post('/api/reservation-rooms/:id/cancel', { preHandler: requirePerm('reservations.cancel') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(2).max(500) }).parse(req.body);
    return tx((c) => cancelReservationRoom(c, actorOf(req), id, b.reason));
  });

  app.put('/api/reservation-rooms/:id/occupant', { preHandler: requirePerm('reservations.edit') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ guest: Guest.nullable() }).parse(req.body);
    return tx((c) => setRoomOccupant(c, actorOf(req), id, b.guest as any));
  });

  app.post('/api/reservation-rooms/:id/check-in', { preHandler: requirePerm('frontoffice.checkin') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ id_scanned: z.boolean().optional(), notes: zOptStr }).parse(req.body ?? {});
    return tx((c) => checkIn(c, actorOf(req), id, b));
  });

  app.post('/api/reservation-rooms/:id/check-out', { preHandler: requirePerm('frontoffice.checkout') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ notes: zOptStr }).parse(req.body ?? {});
    return tx((c) => checkOut(c, actorOf(req), id, b));
  });

  // ===== Paiements =====
  app.post('/api/reservations/:id/payments', { preHandler: requirePerm('payments.create') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({
      amount: z.number().positive().max(100_000_000), method: Method, kind: z.enum(['deposit', 'payment']).optional(), reference: zOptStr,
      card_last4: z.string().regex(/^\d{4}$/, '4 derniers chiffres de la carte').nullish(), card_brand: z.string().max(30).nullish(),
      reservation_room_id: z.number().int().positive().nullish(),
    }).parse(req.body);
    const res = await tx(async (c) => {
      await addPayment(c, actorOf(req), { reservation_id: id, ...b });
      return getReservation(c, req.user!.hotelId, id);
    });
    rep.code(201);
    return res;
  });

  app.post('/api/payments/:id/void', { preHandler: requirePerm('payments.void') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(2).max(500) }).parse(req.body);
    await tx((c) => voidPayment(c, actorOf(req), id, b.reason));
    return { ok: true };
  });

  // ===== Factures =====


  // ===== Notifications =====
  app.get('/api/notifications', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const qs = z.object({ status: z.enum(['pending', 'sent', 'failed', 'cancelled']).optional(), reservation_id: z.coerce.number().int().optional() }).parse(req.query);
    const rows = await q<any>(
      getPool(),
      `SELECT n.*, r.code, g.kind AS g_kind, g.last_name, g.first_name, g.company_name
         FROM notifications n LEFT JOIN reservations r ON r.id = n.reservation_id LEFT JOIN guests g ON g.id = r.guest_id
        WHERE n.hotel_id = $1 AND ($2::text IS NULL OR n.status = $2) AND ($3::int IS NULL OR n.reservation_id = $3)
        ORDER BY n.created_at DESC LIMIT 200`,
      [req.user!.hotelId, qs.status ?? null, qs.reservation_id ?? null],
    );
    return rows.map((n) => ({
      ...n, guest_name: guestDisplayName({ kind: n.g_kind, last_name: n.last_name, first_name: n.first_name, company_name: n.company_name }),
      whatsapp_url: n.channel === 'whatsapp' ? `https://wa.me/${waNumber(n.recipient)}?text=${encodeURIComponent(n.body)}` : null,
    }));
  });

  app.get('/api/notifications/:id/preview', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    const qs = z.object({ lang: z.enum(['fr', 'en', 'ar']) }).parse(req.query);
    const n = await one<any>(getPool(), 'SELECT * FROM notifications WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!n || !n.reservation_id) throw notFound('Notification introuvable');
    const m = await buildMessage(getPool(), n.reservation_id, n.kind, qs.lang);
    return {
      subject: m.subject, body: m.body, language: qs.lang,
      whatsapp_url: n.channel === 'whatsapp' ? `https://wa.me/${waNumber(n.recipient)}?text=${encodeURIComponent(m.body)}` : null,
    };
  });

  app.post('/api/notifications/:id/:action', { preHandler: requirePerm('reservations.edit') }, async (req) => {
    const { id, action } = z.object({ id: z.coerce.number().int(), action: z.enum(['mark-sent', 'cancel', 'retry']) }).parse(req.params);
    const st = action === 'mark-sent' ? 'sent' : action === 'cancel' ? 'cancelled' : 'pending';
    const r = await one(
      getPool(),
      `UPDATE notifications SET status = $3, sent_at = CASE WHEN $3 = 'sent' THEN now() ELSE sent_at END, sent_by = CASE WHEN $3 = 'sent' THEN $4 ELSE sent_by END,
              attempts = CASE WHEN $3 = 'pending' THEN 0 ELSE attempts END
        WHERE id = $1 AND hotel_id = $2 RETURNING id`,
      [id, req.user!.hotelId, st, req.user!.id],
    );
    if (!r) throw notFound('Notification introuvable');
    return { ok: true };
  });

  app.post('/api/notifications/run', { preHandler: requirePerm('reservations.edit') }, async (req) => {
    const reminders = await queueReminders(req.user!.hotelId, today());
    const email = await processEmailOutbox(req.user!.hotelId);
    return { reminders, ...email };
  });
}
