import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { getPool, one, q, tx } from '../db/pool.js';
import { audit } from '../lib/audit.js';
import { actorOf, requireAuth, requirePerm } from '../lib/auth.js';
import { isDate, monthStart, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { getSettings } from '../services/common.js';
import { tableCsv, tablePdf, tableXlsx } from '../services/exports.js';
import {
  adjustStock, countInventory, createInventory, DEPARTMENTS, DEPT_LABEL, KIND_LABEL, moveStock, STOCK_CATEGORIES, STOCK_REPORTS, stockAlerts, stockDashboard, stockIn, stockOut, stockReport, transfer, UNITS, validateInventory,
} from '../services/stock.js';
import {
  approve, cancelInvoice, cancelPo, compareQuotes, createInvoice, createRequest, payInvoice, placeOrder, poDetail, PO_STATUS, receive, saveQuote, selectQuote, submit, updateRequest,
} from '../services/purchase.js';
import { stockMove } from '../services/restaurant.js';

const Id = z.object({ id: z.coerce.number().int().positive() });
const zDate = z.string().refine(isDate, 'Date invalide (AAAA-MM-JJ)');
const s = (n = 500) => z.string().trim().max(n).nullish();
const Qty = z.number().min(-1_000_000).max(1_000_000);
const Dept = z.enum(DEPARTMENTS);
const needAny = (...ps: string[]) => async (req: FastifyRequest) => {
  await requireAuth(req, null as any);
  if (!ps.some((p) => req.user!.perms.has(p))) throw forbidden(`Permission requise : ${ps.join(' ou ')}`);
};
const hotelName = async (id: number) => (await one<any>(getPool(), 'SELECT name FROM hotels WHERE id = $1', [id]))?.name ?? 'Hôtel';
async function sendTable(rep: FastifyReply, format: string, name: string, title: string, sub: string, cols: any[], rows: any[], total: any, hotel: string) {
  if (format === 'xlsx') {
    rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('content-disposition', `attachment; filename="${name}.xlsx"`);
    return rep.send(await tableXlsx(title, sub, cols, rows, total));
  }
  if (format === 'csv') {
    rep.header('content-type', 'text/csv; charset=utf-8').header('content-disposition', `attachment; filename="${name}.csv"`);
    return rep.send(tableCsv(cols, rows, total));
  }
  rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${name}.pdf"`);
  return rep.send(await tablePdf(hotel, title, sub, cols, rows, total));
}
const VIEW = ['stock.view', 'stock.manage', 'restaurant.menu', 'purchase.request', 'purchase.order', 'purchase.pay', 'purchase.reports'];

export async function stockRoutes(app: FastifyInstance) {
  // ===================================================== Référentiels =====================================================
  app.get('/api/stock/meta', { preHandler: needAny(...VIEW) }, async (req) => {
    const used = await q<any>(getPool(), 'SELECT DISTINCT category FROM products WHERE hotel_id = $1 ORDER BY category', [req.user!.hotelId]);
    return {
      categories: [...new Set([...STOCK_CATEGORIES, ...used.map((x) => x.category)])], units: UNITS, departments: DEPARTMENTS.map((d) => ({ code: d, label: DEPT_LABEL[d] })),
      kinds: KIND_LABEL, po_status: PO_STATUS,
      warehouses: await q(getPool(), 'SELECT id, code, name, kind, is_default, active FROM warehouses WHERE hotel_id = $1 ORDER BY is_default DESC, name', [req.user!.hotelId]),
    };
  });

  app.get('/api/warehouses', { preHandler: needAny(...VIEW) }, async (req) =>
    q(getPool(), `SELECT w.*, COALESCE((SELECT count(*) FROM stock_levels sl WHERE sl.warehouse_id = w.id AND sl.qty > 0), 0)::int AS products,
        COALESCE((SELECT sum(sl.qty * p.avg_cost) FROM stock_levels sl JOIN products p ON p.id = sl.product_id WHERE sl.warehouse_id = w.id AND sl.qty > 0), 0) AS value
       FROM warehouses w WHERE w.hotel_id = $1 ORDER BY w.active DESC, w.is_default DESC, w.name`, [req.user!.hotelId]));
  const Wh = z.object({ code: z.string().trim().min(1).max(12), name: z.string().trim().min(2).max(60), kind: z.enum(['store', 'reserve', 'kitchen', 'bar', 'housekeeping', 'maintenance', 'other']).default('store'), active: z.boolean().optional(), is_default: z.boolean().optional() });
  app.post('/api/warehouses', { preHandler: requirePerm('stock.manage') }, async (req, rep) => {
    const b = Wh.parse(req.body);
    const r = await one(getPool(), 'INSERT INTO warehouses (hotel_id, code, name, kind) VALUES ($1,upper($2),$3,$4) RETURNING *', [req.user!.hotelId, b.code, b.name, b.kind]);
    await audit(getPool(), actorOf(req), 'create', 'warehouse', (r as any).id, null, b);
    rep.code(201);
    return r;
  });
  app.patch('/api/warehouses/:id', { preHandler: requirePerm('stock.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = Wh.partial().parse(req.body);
    return tx(async (c) => {
      const w = await one<any>(c, 'SELECT * FROM warehouses WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!w) throw notFound('Entrepôt introuvable');
      if (b.active === false) {
        if (w.is_default) throw conflict('Entrepôt par défaut : désignez-en un autre avant de l\'archiver.');
        if (await one(c, 'SELECT 1 FROM stock_levels WHERE warehouse_id = $1 AND qty <> 0', [id])) throw conflict('Entrepôt non vide : transférez le stock avant de l\'archiver.');
      }
      if (b.is_default) await c.query('UPDATE warehouses SET is_default = false WHERE hotel_id = $1 AND id <> $2', [req.user!.hotelId, id]);
      const r = await one(c, `UPDATE warehouses SET name = COALESCE($2, name), kind = COALESCE($3, kind), active = COALESCE($4, active), is_default = COALESCE($5, is_default) WHERE id = $1 RETURNING *`,
        [id, b.name ?? null, b.kind ?? null, b.active ?? null, b.is_default ?? null]);
      await audit(c, actorOf(req), 'update', 'warehouse', id, w, b);
      return r;
    });
  });

  // ===================================================== Produits =====================================================
  app.get('/api/stock/products', { preHandler: needAny(...VIEW) }, async (req) => {
    const qs = z.object({ warehouse_id: z.coerce.number().int().positive().optional(), archived: z.enum(['1']).optional(), search: z.string().max(80).default('') }).parse(req.query);
    return q(getPool(), `SELECT p.*, (p.stock_qty <= p.min_stock AND p.min_stock > 0) AS low, (p.stock_qty * p.avg_cost) AS value, w.name AS default_warehouse,
        (SELECT string_agg(i.name, ', ' ORDER BY i.name) FROM rs_recipes r JOIN rs_items i ON i.id = r.item_id WHERE r.product_id = p.id) AS used_in,
        COALESCE((SELECT json_agg(json_build_object('warehouse_id', sl.warehouse_id, 'warehouse', w2.name, 'qty', sl.qty) ORDER BY w2.name) FROM stock_levels sl JOIN warehouses w2 ON w2.id = sl.warehouse_id WHERE sl.product_id = p.id AND sl.qty <> 0), '[]') AS levels,
        (SELECT min(l.expiry_date) FROM stock_lots l WHERE l.product_id = p.id AND l.qty > 0) AS next_expiry,
        ${qs.warehouse_id ? `COALESCE((SELECT qty FROM stock_levels WHERE product_id = p.id AND warehouse_id = ${Number(qs.warehouse_id)}), 0)` : 'NULL'} AS wh_qty
       FROM products p LEFT JOIN warehouses w ON w.id = p.default_warehouse_id
      WHERE p.hotel_id = $1 AND ${qs.archived ? 'p.archived_at IS NOT NULL' : 'p.archived_at IS NULL'}
        AND ($2 = '' OR lower(p.name || ' ' || coalesce(p.code,'') || ' ' || coalesce(p.barcode,'') || ' ' || p.category) LIKE $3)
      ORDER BY p.active DESC, p.category, p.name`, [req.user!.hotelId, qs.search.trim(), `%${qs.search.trim().toLowerCase()}%`]);
  });
  app.get('/api/stock/products/:id', { preHandler: needAny(...VIEW) }, async (req) => {
    const { id } = Id.parse(req.params);
    const p = await one<any>(getPool(), 'SELECT p.*, w.name AS default_warehouse FROM products p LEFT JOIN warehouses w ON w.id = p.default_warehouse_id WHERE p.id = $1 AND p.hotel_id = $2', [id, req.user!.hotelId]);
    if (!p) throw notFound('Article introuvable');
    const levels = await q(getPool(), 'SELECT sl.*, w.name AS warehouse FROM stock_levels sl JOIN warehouses w ON w.id = sl.warehouse_id WHERE sl.product_id = $1 ORDER BY w.name', [id]);
    const lots = await q(getPool(), 'SELECT l.*, w.name AS warehouse FROM stock_lots l JOIN warehouses w ON w.id = l.warehouse_id WHERE l.product_id = $1 AND l.qty > 0 ORDER BY l.expiry_date NULLS LAST, l.id', [id]);
    const movements = await q(getPool(), `SELECT m.*, w.name AS warehouse, u.full_name AS user_name FROM stock_movements m LEFT JOIN warehouses w ON w.id = m.warehouse_id LEFT JOIN users u ON u.id = m.created_by
        WHERE m.product_id = $1 ORDER BY m.id DESC LIMIT 100`, [id]);
    const suppliers = await q(getPool(), 'SELECT sp.*, s.name FROM supplier_products sp JOIN suppliers s ON s.id = sp.supplier_id WHERE sp.product_id = $1 ORDER BY sp.last_price NULLS LAST', [id]);
    return { ...p, levels, lots, movements: movements.map((m: any) => ({ ...m, kind_label: KIND_LABEL[m.kind] ?? m.kind })), suppliers };
  });
  const Prod = z.object({
    code: s(30), name: z.string().trim().min(2).max(120), description: s(500), category: z.string().trim().min(2).max(60), unit: z.string().trim().min(1).max(20), barcode: s(40),
    cost_price: z.number().min(0).max(10_000_000).optional(), sale_price: z.number().min(0).max(10_000_000).optional(), tax_rate: z.number().min(0).max(100).optional(),
    min_stock: z.number().min(0).max(10_000_000).optional(), max_stock: z.number().min(0).max(10_000_000).nullish(), track_lots: z.boolean().optional(),
    default_warehouse_id: z.number().int().positive().nullish(), linen_item_id: z.number().int().positive().nullish(), active: z.boolean().optional(),
  });
  const checkRefs = async (hotelId: number, b: any) => {
    if (b.max_stock != null && b.min_stock != null && b.max_stock < b.min_stock) throw badRequest('Stock maximum inférieur au minimum.');
    if (b.default_warehouse_id && !(await one(getPool(), 'SELECT 1 FROM warehouses WHERE id = $1 AND hotel_id = $2', [b.default_warehouse_id, hotelId]))) throw badRequest('Entrepôt inconnu.');
    if (b.linen_item_id && !(await one(getPool(), 'SELECT 1 FROM linen_items WHERE id = $1 AND hotel_id = $2', [b.linen_item_id, hotelId]))) throw badRequest('Article de linge inconnu.');
  };
  const dupe = (e: any) => { if (e.code === '23505') throw conflict('Référence ou code-barres déjà utilisé.'); throw e; };
  app.post('/api/stock/products', { preHandler: requirePerm('stock.manage') }, async (req, rep) => {
    const b = Prod.extend({ initial: z.number().min(0).max(10_000_000).optional(), warehouse_id: z.number().int().positive().optional(), lot_no: s(40), expiry_date: zDate.nullish() }).parse(req.body);
    await checkRefs(req.user!.hotelId, b);
    const r = await tx(async (c) => {
      const w = await one<any>(c, `SELECT id FROM warehouses WHERE hotel_id = $1 AND ${b.default_warehouse_id ? 'id = $2' : 'is_default'}`, b.default_warehouse_id ? [req.user!.hotelId, b.default_warehouse_id] : [req.user!.hotelId]);
      const p = await one<any>(c, `INSERT INTO products (hotel_id, code, name, description, category, unit, barcode, cost_price, avg_cost, sale_price, tax_rate, min_stock, max_stock, track_lots, default_warehouse_id, linen_item_id)
          VALUES ($1,$2,$3,$4,$5,$6,$7,COALESCE($8,0),COALESCE($8,0),COALESCE($9,0),COALESCE($10,19),COALESCE($11,0),$12,COALESCE($13,false),$14,$15) RETURNING *`,
        [req.user!.hotelId, b.code ?? null, b.name, b.description ?? null, b.category, b.unit, b.barcode ?? null, b.cost_price ?? null, b.sale_price ?? null, b.tax_rate ?? null, b.min_stock ?? null,
          b.max_stock ?? null, b.track_lots ?? null, w?.id ?? null, b.linen_item_id ?? null]).catch(dupe);
      if (b.initial) await moveStock(c, actorOf(req), { product_id: p.id, warehouse_id: b.warehouse_id ?? w?.id, kind: 'in', quantity: b.initial, unit_cost: b.cost_price ?? null, reason: 'Stock initial', lot_no: b.lot_no, expiry_date: b.expiry_date });
      await audit(c, actorOf(req), 'create', 'product', p.id, null, { name: b.name, category: b.category });
      return one(c, 'SELECT * FROM products WHERE id = $1', [p.id]);
    });
    rep.code(201);
    return r;
  });
  app.patch('/api/stock/products/:id', { preHandler: requirePerm('stock.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = Prod.partial().parse(req.body);
    await checkRefs(req.user!.hotelId, b);
    const before = await one<any>(getPool(), 'SELECT * FROM products WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!before) throw notFound('Article introuvable');
    const set = (k: string) => (b as any)[k] !== undefined;
    const r = await one(getPool(), `UPDATE products SET code = CASE WHEN $3 THEN $4 ELSE code END, name = COALESCE($5, name), description = CASE WHEN $6 THEN $7 ELSE description END, category = COALESCE($8, category),
        unit = COALESCE($9, unit), barcode = CASE WHEN $10 THEN $11 ELSE barcode END, cost_price = COALESCE($12, cost_price), sale_price = COALESCE($13, sale_price), tax_rate = COALESCE($14, tax_rate),
        min_stock = COALESCE($15, min_stock), max_stock = CASE WHEN $16 THEN $17 ELSE max_stock END, track_lots = COALESCE($18, track_lots), default_warehouse_id = COALESCE($19, default_warehouse_id),
        linen_item_id = CASE WHEN $20 THEN $21 ELSE linen_item_id END, active = COALESCE($22, active), updated_at = now() WHERE id = $1 AND hotel_id = $2 RETURNING *`,
      [id, req.user!.hotelId, set('code'), b.code ?? null, b.name ?? null, set('description'), b.description ?? null, b.category ?? null, b.unit ?? null, set('barcode'), b.barcode ?? null, b.cost_price ?? null,
        b.sale_price ?? null, b.tax_rate ?? null, b.min_stock ?? null, set('max_stock'), b.max_stock ?? null, b.track_lots ?? null, b.default_warehouse_id ?? null, set('linen_item_id'), b.linen_item_id ?? null, b.active ?? null]).catch(dupe);
    await audit(getPool(), actorOf(req), 'update', 'product', id, { name: before.name, min_stock: Number(before.min_stock), cost_price: Number(before.cost_price) }, b);
    return r;
  });
  app.post('/api/stock/products/:id/archive', { preHandler: requirePerm('stock.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ archived: z.boolean() }).parse(req.body);
    const p = await one<any>(getPool(), 'SELECT * FROM products WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!p) throw notFound('Article introuvable');
    if (b.archived && Number(p.stock_qty) !== 0) throw conflict('Article encore en stock : sortez ou ajustez le stock avant de l\'archiver.');
    if (b.archived && (await one(getPool(), `SELECT 1 FROM purchase_order_lines l JOIN purchase_orders po ON po.id = l.po_id WHERE l.product_id = $1 AND po.status IN ('draft','pending','approved','ordered','partial')`, [id]))) throw conflict('Article présent dans un achat en cours.');
    await getPool().query('UPDATE products SET archived_at = CASE WHEN $2 THEN now() END, active = NOT $2, updated_at = now() WHERE id = $1', [id, b.archived]);
    await audit(getPool(), actorOf(req), b.archived ? 'archive' : 'restore', 'product', id, null, null);
    return { ok: true };
  });
  app.get('/api/stock/lots', { preHandler: needAny(...VIEW) }, async (req) => {
    const qs = z.object({ product_id: z.coerce.number().int().positive(), warehouse_id: z.coerce.number().int().positive().optional() }).parse(req.query);
    return q(getPool(), `SELECT l.*, w.name AS warehouse FROM stock_lots l JOIN warehouses w ON w.id = l.warehouse_id JOIN products p ON p.id = l.product_id
        WHERE l.product_id = $1 AND p.hotel_id = $2 AND l.qty > 0 AND ($3::int IS NULL OR l.warehouse_id = $3) ORDER BY l.expiry_date NULLS LAST`, [qs.product_id, req.user!.hotelId, qs.warehouse_id ?? null]);
  });

  // ===================================================== Mouvements =====================================================
  app.get('/api/stock/movements', { preHandler: needAny(...VIEW) }, async (req) => {
    const qs = z.object({ product_id: z.coerce.number().int().positive().optional(), warehouse_id: z.coerce.number().int().positive().optional(), kind: z.string().max(20).optional(),
      department: z.string().max(20).optional(), from: zDate.optional(), to: zDate.optional() }).parse(req.query);
    const rows = await q<any>(getPool(), `SELECT m.*, p.name AS product, p.unit, u.full_name AS user_name, o.number AS order_number, w.name AS warehouse, l.lot_no, l.expiry_date
        FROM stock_movements m JOIN products p ON p.id = m.product_id LEFT JOIN users u ON u.id = m.created_by LEFT JOIN rs_orders o ON o.id = m.rs_order_id
        LEFT JOIN warehouses w ON w.id = m.warehouse_id LEFT JOIN stock_lots l ON l.id = m.lot_id
       WHERE p.hotel_id = $1 AND ($2::int IS NULL OR m.product_id = $2) AND ($3::int IS NULL OR m.warehouse_id = $3) AND ($4::text IS NULL OR m.kind = $4) AND ($5::text IS NULL OR m.department = $5)
         AND (m.created_at AT TIME ZONE 'Africa/Algiers')::date BETWEEN $6 AND $7 ORDER BY m.id DESC LIMIT 1000`,
      [req.user!.hotelId, qs.product_id ?? null, qs.warehouse_id ?? null, qs.kind ?? null, qs.department ?? null, qs.from ?? monthStart(today()), qs.to ?? today()]);
    return rows.map((m) => ({ ...m, kind_label: KIND_LABEL[m.kind] ?? m.kind, department_label: m.department ? DEPT_LABEL[m.department] : null }));
  });
  /** Entrée manuelle (hors achat), perte, ajustement (compatibilité écran Restaurant › Stock) */
  app.post('/api/stock/movements', { preHandler: requirePerm('stock.manage') }, async (req, rep) => {
    const b = z.object({ product_id: z.number().int().positive(), kind: z.enum(['in', 'adjust', 'waste']), quantity: Qty, reason: s(300), warehouse_id: z.number().int().positive().nullish(), unit_cost: z.number().min(0).max(10_000_000).nullish(),
      lot_no: s(40), expiry_date: zDate.nullish() }).parse(req.body);
    const r = await tx(async (c) => {
      if (b.kind === 'in' && (b.lot_no || b.expiry_date)) return (await stockIn(c, actorOf(req), { ...b })).movement;
      if (b.kind === 'adjust') return (await adjustStock(c, actorOf(req), { product_id: b.product_id, warehouse_id: b.warehouse_id, quantity: b.quantity, reason: b.reason ?? '' })).movement;
      return stockMove(c, actorOf(req), b);
    });
    rep.code(201);
    return r;
  });
  /** Sorties : consommation interne par département, pertes, casse, péremption, retour fournisseur */
  app.post('/api/stock/out', { preHandler: requirePerm('stock.issue') }, async (req, rep) => {
    const b = z.object({ product_id: z.number().int().positive(), warehouse_id: z.number().int().positive().nullish(), kind: z.enum(['issue', 'waste', 'damaged', 'expired', 'supplier_return']), quantity: z.number().positive().max(1_000_000),
      reason: s(300), department: Dept.nullish(), lot_id: z.number().int().positive().nullish(), ticket_id: z.number().int().positive().nullish(), supplier_id: z.number().int().positive().nullish(), force: z.boolean().optional() }).parse(req.body);
    const r = await tx((c) => stockOut(c, actorOf(req), req.user!.perms, b));
    rep.code(201);
    return { movement: r.movement, alert: r.alert };
  });
  app.post('/api/stock/transfer', { preHandler: requirePerm('stock.transfer') }, async (req, rep) => {
    const b = z.object({ product_id: z.number().int().positive(), from_id: z.number().int().positive(), to_id: z.number().int().positive(), quantity: z.number().positive().max(1_000_000), reason: s(300) }).parse(req.body);
    const r = await tx((c) => transfer(c, actorOf(req), b));
    rep.code(201);
    return r;
  });
  app.get('/api/stock/tickets', { preHandler: requirePerm('stock.issue') }, async (req) =>
    q(getPool(), `SELECT t.id, t.title, r.number AS room FROM maintenance_tickets t LEFT JOIN rooms r ON r.id = t.room_id WHERE t.hotel_id = $1 AND t.status IN ('new','assigned','in_progress','waiting_parts') ORDER BY t.id DESC LIMIT 100`, [req.user!.hotelId]));

  // ===================================================== Inventaires =====================================================
  app.get('/api/inventories', { preHandler: needAny('stock.view', 'stock.inventory') }, async (req) =>
    q(getPool(), `SELECT i.*, w.name AS warehouse, u.full_name AS created_by_name, uv.full_name AS validated_by_name,
        (SELECT count(*) FROM inventory_lines l WHERE l.inventory_id = i.id)::int AS lines, (SELECT count(*) FROM inventory_lines l WHERE l.inventory_id = i.id AND l.counted IS NOT NULL)::int AS counted
       FROM inventories i LEFT JOIN warehouses w ON w.id = i.warehouse_id LEFT JOIN users u ON u.id = i.created_by LEFT JOIN users uv ON uv.id = i.validated_by WHERE i.hotel_id = $1 ORDER BY i.id DESC LIMIT 200`, [req.user!.hotelId]));
  app.post('/api/inventories', { preHandler: requirePerm('stock.inventory') }, async (req, rep) => {
    const b = z.object({ scope: z.enum(['full', 'category', 'warehouse']), warehouse_id: z.number().int().positive().nullish(), category: s(60), notes: s(300) }).parse(req.body);
    const r = await tx((c) => createInventory(c, actorOf(req), b));
    rep.code(201);
    return r;
  });
  app.get('/api/inventories/:id', { preHandler: needAny('stock.view', 'stock.inventory') }, async (req) => {
    const { id } = Id.parse(req.params);
    const inv = await one<any>(getPool(), 'SELECT i.*, w.name AS warehouse FROM inventories i LEFT JOIN warehouses w ON w.id = i.warehouse_id WHERE i.id = $1 AND i.hotel_id = $2', [id, req.user!.hotelId]);
    if (!inv) throw notFound('Inventaire introuvable');
    const lines = await q<any>(getPool(), `SELECT l.*, p.name, p.code, p.unit, p.category, w.name AS warehouse, COALESCE(sl.qty, 0) AS current_qty FROM inventory_lines l JOIN products p ON p.id = l.product_id
        JOIN warehouses w ON w.id = l.warehouse_id LEFT JOIN stock_levels sl ON sl.product_id = l.product_id AND sl.warehouse_id = l.warehouse_id WHERE l.inventory_id = $1 ORDER BY p.category, p.name, w.name`, [id]);
    return { ...inv, lines: lines.map((l) => ({ ...l, gap: l.counted === null ? null : Math.round((Number(l.counted) - Number(l.theoretical)) * 1000) / 1000,
      gap_value: l.counted === null ? null : Math.round((Number(l.counted) - Number(l.theoretical)) * Number(l.unit_cost) * 100) / 100 })) };
  });
  app.put('/api/inventories/:id/count', { preHandler: requirePerm('stock.inventory') }, async (req) => {
    const b = z.object({ lines: z.array(z.object({ line_id: z.number().int().positive(), counted: z.number().min(0).max(10_000_000).nullable(), note: s(200) })).max(5000) }).parse(req.body);
    await tx((c) => countInventory(c, actorOf(req), Id.parse(req.params).id, b.lines));
    return { ok: true };
  });
  app.post('/api/inventories/:id/validate', { preHandler: requirePerm('stock.inventory') }, async (req) => tx((c) => validateInventory(c, actorOf(req), req.user!.perms, Id.parse(req.params).id)));
  app.post('/api/inventories/:id/cancel', { preHandler: requirePerm('stock.inventory') }, async (req) => {
    const { id } = Id.parse(req.params);
    const r = await one(getPool(), `UPDATE inventories SET status = 'cancelled' WHERE id = $1 AND hotel_id = $2 AND status = 'open' RETURNING id`, [id, req.user!.hotelId]);
    if (!r) throw conflict('Inventaire introuvable ou déjà clôturé.');
    await audit(getPool(), actorOf(req), 'cancel', 'inventory', id, null, null);
    return { ok: true };
  });

  // ===================================================== Fournisseurs =====================================================
  app.get('/api/suppliers', { preHandler: needAny(...VIEW, 'suppliers.manage') }, async (req) =>
    q(getPool(), `SELECT s.*, COALESCE((SELECT sum(total - paid) FROM supplier_invoices f WHERE f.supplier_id = s.id AND f.status IN ('unpaid','partial')), 0) AS balance,
        COALESCE((SELECT sum(total - paid) FROM supplier_invoices f WHERE f.supplier_id = s.id AND f.status IN ('unpaid','partial') AND f.due_date < CURRENT_DATE), 0) AS overdue,
        (SELECT count(*) FROM purchase_orders po WHERE po.supplier_id = s.id AND po.status IN ('ordered','partial','received'))::int AS orders,
        (SELECT count(*) FROM supplier_products sp WHERE sp.supplier_id = s.id)::int AS products
       FROM suppliers s WHERE s.hotel_id = $1 ORDER BY s.active DESC, s.name`, [req.user!.hotelId]));
  const Sup = z.object({
    name: z.string().trim().min(2).max(120), code: s(20), contact_name: s(80), phone: s(40), mobile: s(40), email: z.string().trim().email('E-mail invalide').max(120).nullish().or(z.literal('')),
    address: s(250), city: s(60), nif: s(30), nis: s(30), rc: s(30), ai: s(30), rib: s(40), payment_terms: z.number().int().min(0).max(365).optional(), notes: s(500), active: z.boolean().optional(),
  });
  const SUP_COLS = ['name', 'code', 'contact_name', 'phone', 'mobile', 'email', 'address', 'city', 'nif', 'nis', 'rc', 'ai', 'rib', 'payment_terms', 'notes', 'active'];
  app.post('/api/suppliers', { preHandler: requirePerm('suppliers.manage') }, async (req, rep) => {
    const b = Sup.parse(req.body);
    if (await one(getPool(), 'SELECT 1 FROM suppliers WHERE hotel_id = $1 AND lower(name) = lower($2)', [req.user!.hotelId, b.name])) throw conflict('Un fournisseur porte déjà ce nom.');
    const cols = SUP_COLS.filter((k) => (b as any)[k] !== undefined);
    const r = await one<any>(getPool(), `INSERT INTO suppliers (hotel_id, ${cols.join(', ')}) VALUES ($1, ${cols.map((_, i) => `$${i + 2}`).join(', ')}) RETURNING *`,
      [req.user!.hotelId, ...cols.map((k) => ((b as any)[k] === '' ? null : (b as any)[k]))]);
    await audit(getPool(), actorOf(req), 'create', 'supplier', r.id, null, b);
    rep.code(201);
    return r;
  });
  app.patch('/api/suppliers/:id', { preHandler: requirePerm('suppliers.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = Sup.partial().parse(req.body);
    const before = await one<any>(getPool(), 'SELECT * FROM suppliers WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!before) throw notFound('Fournisseur introuvable');
    const cols = SUP_COLS.filter((k) => (b as any)[k] !== undefined);
    if (!cols.length) return before;
    const r = await one(getPool(), `UPDATE suppliers SET ${cols.map((k, i) => `${k} = $${i + 2}`).join(', ')} WHERE id = $1 RETURNING *`, [id, ...cols.map((k) => ((b as any)[k] === '' ? null : (b as any)[k]))]);
    await audit(getPool(), actorOf(req), 'update', 'supplier', id, before, b);
    return r;
  });
  app.get('/api/suppliers/:id', { preHandler: needAny(...VIEW, 'suppliers.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const s0 = await one<any>(getPool(), 'SELECT * FROM suppliers WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!s0) throw notFound('Fournisseur introuvable');
    const products = await q(getPool(), 'SELECT sp.*, p.name, p.unit, p.code FROM supplier_products sp JOIN products p ON p.id = sp.product_id WHERE sp.supplier_id = $1 ORDER BY p.name', [id]);
    const orders = await q(getPool(), `SELECT id, number, po_number, status, total, ordered_at, expected_date, received_at FROM purchase_orders WHERE supplier_id = $1 ORDER BY id DESC LIMIT 100`, [id]);
    const invoices = await q(getPool(), `SELECT * FROM supplier_invoices WHERE supplier_id = $1 ORDER BY invoice_date DESC, id DESC LIMIT 200`, [id]);
    const payments = await q(getPool(), `SELECT sp.*, f.ref, f.number FROM supplier_payments sp JOIN supplier_invoices f ON f.id = sp.invoice_id WHERE f.supplier_id = $1 ORDER BY sp.paid_at DESC, sp.id DESC LIMIT 200`, [id]);
    const bal = await one<any>(getPool(), `SELECT COALESCE(sum(total) FILTER (WHERE status <> 'cancelled'), 0) AS invoiced, COALESCE(sum(paid), 0) AS paid, COALESCE(sum(total - paid) FILTER (WHERE status IN ('unpaid','partial')), 0) AS balance FROM supplier_invoices WHERE supplier_id = $1`, [id]);
    return { ...s0, products, orders: orders.map((o: any) => ({ ...o, status_label: PO_STATUS[o.status] })), invoices, payments, totals: { invoiced: Number(bal.invoiced), paid: Number(bal.paid), balance: Number(bal.balance) } };
  });
  app.put('/api/suppliers/:id/products', { preHandler: requirePerm('suppliers.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ products: z.array(z.object({ product_id: z.number().int().positive(), supplier_ref: s(40), last_price: z.number().min(0).max(10_000_000).nullish(), lead_days: z.number().int().min(0).max(365).nullish() })).max(500) }).parse(req.body);
    return tx(async (c) => {
      if (!(await one(c, 'SELECT 1 FROM suppliers WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]))) throw notFound('Fournisseur introuvable');
      await c.query('DELETE FROM supplier_products WHERE supplier_id = $1', [id]);
      for (const p of b.products) {
        if (!(await one(c, 'SELECT 1 FROM products WHERE id = $1 AND hotel_id = $2', [p.product_id, req.user!.hotelId]))) throw badRequest('Article inconnu.');
        await c.query('INSERT INTO supplier_products (supplier_id, product_id, supplier_ref, last_price, lead_days) VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING', [id, p.product_id, p.supplier_ref ?? null, p.last_price ?? null, p.lead_days ?? null]);
      }
      await audit(c, actorOf(req), 'products', 'supplier', id, null, { count: b.products.length });
      return { ok: true };
    });
  });

  // ===================================================== Achats =====================================================
  app.get('/api/purchases', { preHandler: needAny('purchase.request', 'purchase.approve', 'purchase.order', 'purchase.receive', 'purchase.pay', 'purchase.reports') }, async (req) => {
    const qs = z.object({ status: z.string().max(20).optional(), supplier_id: z.coerce.number().int().positive().optional(), search: z.string().max(60).default('') }).parse(req.query);
    const p = req.user!.perms;
    // un demandeur sans autre droit achats ne voit que ses demandes
    const onlyMine = !['purchase.approve', 'purchase.order', 'purchase.receive', 'purchase.pay', 'purchase.reports'].some((x) => p.has(x));
    const rows = await q<any>(getPool(), `SELECT po.*, s.name AS supplier, w.name AS warehouse, u.full_name AS requested_by_name, (SELECT count(*) FROM purchase_order_lines l WHERE l.po_id = po.id)::int AS lines,
        (po.status IN ('ordered','partial') AND po.expected_date < CURRENT_DATE) AS late
       FROM purchase_orders po LEFT JOIN suppliers s ON s.id = po.supplier_id JOIN warehouses w ON w.id = po.warehouse_id LEFT JOIN users u ON u.id = po.requested_by
      WHERE po.hotel_id = $1 AND ($2::text IS NULL OR po.status = $2) AND ($3::int IS NULL OR po.supplier_id = $3) AND (NOT $4 OR po.requested_by = $5)
        AND ($6 = '' OR lower(po.number || ' ' || coalesce(po.po_number,'') || ' ' || coalesce(s.name,'') || ' ' || coalesce(po.reason,'')) LIKE $7)
      ORDER BY array_position(ARRAY['pending','approved','ordered','partial','draft','received','cancelled'], po.status), po.id DESC LIMIT 300`,
      [req.user!.hotelId, qs.status ?? null, qs.supplier_id ?? null, onlyMine, req.user!.id, qs.search.trim(), `%${qs.search.trim().toLowerCase()}%`]);
    return rows.map((r) => ({ ...r, status_label: PO_STATUS[r.status] }));
  });
  const Line = z.object({ product_id: z.number().int().positive(), quantity: z.number().positive().max(1_000_000), unit_price: z.number().min(0).max(10_000_000).nullish(), tax_rate: z.number().min(0).max(100).nullish(), notes: s(200) });
  app.post('/api/purchases', { preHandler: requirePerm('purchase.request') }, async (req, rep) => {
    const b = z.object({ department: Dept.default('other'), warehouse_id: z.number().int().positive().nullish(), needed_by: zDate.nullish(), reason: s(300), notes: s(500), supplier_id: z.number().int().positive().nullish(),
      lines: z.array(Line).min(1).max(200), submit: z.boolean().optional() }).parse(req.body);
    const r = await tx((c) => createRequest(c, actorOf(req), b));
    rep.code(201);
    return poDetail(getPool(), req.user!.hotelId, r.id);
  });
  app.get('/api/purchases/:id', { preHandler: needAny('purchase.request', 'purchase.approve', 'purchase.order', 'purchase.receive', 'purchase.pay', 'purchase.reports') }, async (req) => poDetail(getPool(), req.user!.hotelId, Id.parse(req.params).id));
  app.patch('/api/purchases/:id', { preHandler: needAny('purchase.request', 'purchase.approve', 'purchase.order') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ department: Dept.optional(), warehouse_id: z.number().int().positive().nullish(), needed_by: zDate.nullish(), reason: s(300), notes: s(500), supplier_id: z.number().int().positive().nullish(),
      expected_date: zDate.nullish(), lines: z.array(Line).min(1).max(200).optional() }).parse(req.body);
    await tx((c) => updateRequest(c, actorOf(req), req.user!.perms, id, b));
    return poDetail(getPool(), req.user!.hotelId, id);
  });
  app.post('/api/purchases/:id/submit', { preHandler: requirePerm('purchase.request') }, async (req) => { await tx((c) => submit(c, actorOf(req), Id.parse(req.params).id)); return { ok: true }; });
  app.post('/api/purchases/:id/approve', { preHandler: requirePerm('purchase.approve') }, async (req) => {
    const b = z.object({ decision: z.enum(['approve', 'reject']), reason: s(300) }).parse(req.body);
    await tx((c) => approve(c, actorOf(req), req.user!.perms, Id.parse(req.params).id, b));
    return { ok: true };
  });
  app.post('/api/purchases/:id/quotes', { preHandler: requirePerm('purchase.order') }, async (req, rep) => {
    const b = z.object({ supplier_id: z.number().int().positive(), reference: s(60), delivery_days: z.number().int().min(0).max(365).nullish(), valid_until: zDate.nullish(), notes: s(300),
      lines: z.array(z.object({ line_id: z.number().int().positive(), unit_price: z.number().min(0).max(10_000_000), tax_rate: z.number().min(0).max(100).nullish(), available: z.boolean().optional() })).min(1).max(200) }).parse(req.body);
    const r = await tx((c) => saveQuote(c, actorOf(req), Id.parse(req.params).id, b));
    rep.code(201);
    return r;
  });
  app.get('/api/purchases/:id/compare', { preHandler: needAny('purchase.order', 'purchase.approve') }, async (req) => compareQuotes(getPool(), req.user!.hotelId, Id.parse(req.params).id));
  app.post('/api/purchases/:id/select-quote', { preHandler: requirePerm('purchase.order') }, async (req) => {
    const b = z.object({ quote_id: z.number().int().positive() }).parse(req.body);
    await tx((c) => selectQuote(c, actorOf(req), Id.parse(req.params).id, b.quote_id));
    return { ok: true };
  });
  app.post('/api/purchases/:id/order', { preHandler: requirePerm('purchase.order') }, async (req) => {
    const b = z.object({ expected_date: zDate.nullish() }).parse(req.body ?? {});
    await tx((c) => placeOrder(c, actorOf(req), Id.parse(req.params).id, b));
    return poDetail(getPool(), req.user!.hotelId, Id.parse(req.params).id);
  });
  app.post('/api/purchases/:id/receive', { preHandler: requirePerm('purchase.receive') }, async (req, rep) => {
    const b = z.object({ delivery_note: s(60), notes: s(300), warehouse_id: z.number().int().positive().nullish(),
      lines: z.array(z.object({ po_line_id: z.number().int().positive(), quantity: z.number().min(0).max(1_000_000), rejected_qty: z.number().min(0).max(1_000_000).optional(), lot_no: s(40), expiry_date: zDate.nullish(),
        unit_cost: z.number().min(0).max(10_000_000).nullish() })).min(1).max(200) }).parse(req.body);
    const r = await tx((c) => receive(c, actorOf(req), Id.parse(req.params).id, b));
    rep.code(201);
    return r;
  });
  app.post('/api/purchases/:id/cancel', { preHandler: needAny('purchase.request', 'purchase.order', 'purchase.approve') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(3).max(300) }).parse(req.body);
    const po = await one<any>(getPool(), 'SELECT status, requested_by FROM purchase_orders WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!po) throw notFound('Achat introuvable');
    const p = req.user!.perms;
    if (!(p.has('purchase.order') || p.has('purchase.approve') || (po.requested_by === req.user!.id && ['draft', 'pending'].includes(po.status)))) throw forbidden('Annulation réservée à l\'acheteur ou au responsable.');
    return { status: await tx((c) => cancelPo(c, actorOf(req), id, b.reason)) };
  });
  /** Bon de commande imprimable (PDF) */
  app.get('/api/purchases/:id/pdf', { preHandler: needAny('purchase.order', 'purchase.receive', 'purchase.approve') }, async (req, rep) => {
    const d = await poDetail(getPool(), req.user!.hotelId, Id.parse(req.params).id);
    const cols = [{ key: 'name', label: 'Article' }, { key: 'qty', label: 'Quantité' }, { key: 'unit', label: 'Unité' }, { key: 'price', label: 'Prix HT', money: true }, { key: 'tax', label: 'TVA %' }, { key: 'total', label: 'Total HT', money: true }];
    const rows = d.lines.map((l: any) => ({ name: l.name, qty: Number(l.quantity), unit: l.unit, price: Number(l.unit_price), tax: Number(l.tax_rate), total: Math.round(Number(l.unit_price) * Number(l.quantity) * 100) / 100 }));
    const sub = `${d.supplier ?? 'Fournisseur à définir'} · Livraison : ${d.warehouse}${d.expected_date ? ` · Prévue le ${String(d.expected_date).slice(0, 10)}` : ''} · Demande ${d.number}`;
    rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${d.po_number ?? d.number}.pdf"`);
    return rep.send(await tablePdf(await hotelName(req.user!.hotelId), `${d.po_number ? 'Bon de commande' : 'Demande d\'achat'} ${d.po_number ?? d.number}`, sub, cols, rows, { total: Number(d.subtotal), tax: `TVA ${d.tax_total} — TTC ${d.total}` }));
  });

  // ===================================================== Factures fournisseurs =====================================================
  app.get('/api/supplier-invoices', { preHandler: needAny('purchase.pay', 'purchase.reports') }, async (req) => {
    const qs = z.object({ status: z.string().max(20).optional(), supplier_id: z.coerce.number().int().positive().optional(), due: z.enum(['1']).optional() }).parse(req.query);
    return q(getPool(), `SELECT f.*, s.name AS supplier, po.po_number, (f.status IN ('unpaid','partial') AND f.due_date < CURRENT_DATE) AS overdue
        FROM supplier_invoices f JOIN suppliers s ON s.id = f.supplier_id LEFT JOIN purchase_orders po ON po.id = f.po_id
       WHERE f.hotel_id = $1 AND ($2::text IS NULL OR f.status = $2) AND ($3::int IS NULL OR f.supplier_id = $3) AND (NOT $4 OR f.status IN ('unpaid','partial'))
       ORDER BY (f.status IN ('unpaid','partial')) DESC, f.due_date, f.id DESC LIMIT 500`, [req.user!.hotelId, qs.status ?? null, qs.supplier_id ?? null, !!qs.due]);
  });
  app.get('/api/supplier-invoices/:id', { preHandler: needAny('purchase.pay', 'purchase.reports') }, async (req) => {
    const { id } = Id.parse(req.params);
    const f = await one<any>(getPool(), `SELECT f.*, s.name AS supplier, po.po_number FROM supplier_invoices f JOIN suppliers s ON s.id = f.supplier_id LEFT JOIN purchase_orders po ON po.id = f.po_id WHERE f.id = $1 AND f.hotel_id = $2`, [id, req.user!.hotelId]);
    if (!f) throw notFound('Facture introuvable');
    const payments = await q(getPool(), 'SELECT sp.*, u.full_name AS user_name FROM supplier_payments sp LEFT JOIN users u ON u.id = sp.created_by WHERE sp.invoice_id = $1 ORDER BY sp.id', [id]);
    return { ...f, payments };
  });
  app.post('/api/supplier-invoices', { preHandler: requirePerm('purchase.pay') }, async (req, rep) => {
    const b = z.object({ supplier_id: z.number().int().positive(), number: z.string().trim().min(1).max(40), po_id: z.number().int().positive().nullish(), invoice_date: zDate, due_date: zDate.nullish(),
      subtotal: z.number().min(0).max(100_000_000), tax_total: z.number().min(0).max(100_000_000).optional(), stamp_duty: z.number().min(0).max(1_000_000).optional(), category: s(60), notes: s(300) }).parse(req.body);
    if (b.due_date && b.due_date < b.invoice_date) throw badRequest('Échéance antérieure à la date de facture.');
    const r = await tx((c) => createInvoice(c, actorOf(req), b));
    rep.code(201);
    return r;
  });
  app.post('/api/supplier-invoices/:id/pay', { preHandler: requirePerm('purchase.pay') }, async (req, rep) => {
    const b = z.object({ amount: z.number().positive().max(100_000_000), method: z.enum(['cash', 'card', 'cheque', 'transfer']), reference: s(60), paid_at: zDate.nullish() }).parse(req.body);
    const r = await tx((c) => payInvoice(c, actorOf(req), Id.parse(req.params).id, b));
    rep.code(201);
    return r;
  });
  app.post('/api/supplier-invoices/:id/cancel', { preHandler: requirePerm('purchase.pay') }, async (req) => {
    const b = z.object({ reason: z.string().trim().min(3).max(300) }).parse(req.body);
    await tx((c) => cancelInvoice(c, actorOf(req), Id.parse(req.params).id, b.reason));
    return { ok: true };
  });

  // ===================================================== Tableau de bord, alertes, rapports, réglages =====================================================
  app.get('/api/stock/dashboard', { preHandler: needAny(...VIEW) }, async (req) => {
    const d = await stockDashboard(getPool(), req.user!.hotelId);
    const fin = req.user!.perms.has('purchase.pay') || req.user!.perms.has('purchase.reports');
    return fin ? d : { ...d, kpi: { ...d.kpi, invoiced_month: null, due: null, overdue: null }, alerts: d.alerts.filter((a) => a.code !== 'invoice_overdue') };
  });
  app.get('/api/stock/alerts', { preHandler: needAny(...VIEW) }, async (req) => stockAlerts(getPool(), req.user!.hotelId));
  const FIN = ['suppliers', 'debts', 'expenses', 'journal'];
  app.get('/api/stock/reports/:kind', { preHandler: needAny('stock.view', 'purchase.reports') }, async (req, rep) => {
    const { kind } = z.object({ kind: z.enum(Object.keys(STOCK_REPORTS) as [string, ...string[]]) }).parse(req.params);
    if (FIN.includes(kind) && !req.user!.perms.has('purchase.reports')) throw forbidden('Rapport financier : permission « purchase.reports » requise.');
    const qs = z.object({ from: zDate.optional(), to: zDate.optional(), format: z.enum(['json', 'pdf', 'xlsx', 'csv']).default('json') }).parse(req.query);
    const from = qs.from ?? monthStart(today()), to = qs.to ?? today();
    if (from > to) throw badRequest('Période invalide.');
    const r = await stockReport(getPool(), req.user!.hotelId, kind, from, to);
    if (qs.format === 'json') return r;
    return sendTable(rep, qs.format, `stock-${kind}-${from}-${to}`, r.title, `Du ${from} au ${to}`, r.columns, r.rows, r.total, await hotelName(req.user!.hotelId));
  });
  app.get('/api/stock/settings', { preHandler: needAny(...VIEW) }, async (req) => (await getSettings(getPool(), req.user!.hotelId)).stock);
  app.put('/api/stock/settings', { preHandler: requirePerm('stock.manage') }, async (req) => {
    const b = z.object({ expiry_alert_days: z.number().int().min(0).max(365), inventory_gap_percent: z.number().min(0).max(100), inventory_gap_value: z.number().min(0).max(100_000_000),
      restaurant_warehouse_id: z.number().int().positive().nullable(), purchase_category: z.string().trim().min(2).max(60), late_po_days: z.number().int().min(0).max(60).default(0) }).parse(req.body);
    if (b.restaurant_warehouse_id && !(await one(getPool(), 'SELECT 1 FROM warehouses WHERE id = $1 AND hotel_id = $2 AND active', [b.restaurant_warehouse_id, req.user!.hotelId]))) throw badRequest('Entrepôt inconnu.');
    const cur = (await getSettings(getPool(), req.user!.hotelId)).stock;
    await getPool().query(`INSERT INTO settings (hotel_id, key, value) VALUES ($1,'stock',$2) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value`, [req.user!.hotelId, JSON.stringify(b)]);
    await audit(getPool(), actorOf(req), 'update', 'settings', 'stock', cur, b);
    return b;
  });
}
