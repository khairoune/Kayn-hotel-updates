import { currency } from '../services/exports.js';
import { assertRoleGrantable } from '../services/admin.js';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import PDFDocument from 'pdfkit';
import { z } from 'zod';
import { getPool, one, q, tx } from '../db/pool.js';
import { audit } from '../lib/audit.js';
import { actorOf, hashPassword, requireAuth, requirePerm, validatePasswordStrength, verifyPassword } from '../lib/auth.js';
import { addDays, isDate, monthStart, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { getSettings } from '../services/common.js';
import { tableCsv, tablePdf, tableXlsx } from '../services/exports.js';
import {
  addAmendment, applyRotation, clearShift, clock, computePayroll, CONTRACT_LABEL, createContract, decideCorrection, decideLeave, decideSwap, EFFECTIVE_STATUS, employeeInScope, giveAdvance,
  HR_REPORTS, hrAlerts, hrDashboard, hrReport, hrSettings, leaveBalance, leaveDays, myEmployee, payPayroll, redact, requestCorrection, requestLeave, scopeOf, scopeSql, setShift, setStatus,
  STATUS_LABEL, TZ, validatePayroll, type Scope,
} from '../services/hr.js';

const Id = z.object({ id: z.coerce.number().int().positive() });
const zDate = z.string().refine(isDate, 'Date invalide (AAAA-MM-JJ)');
const Time = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Heure invalide (HH:MM)');
const Period = z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, 'Période invalide (AAAA-MM)');
const s = (n = 500) => z.string().trim().max(n).nullish();
const Money = z.number().min(0).max(1e10);
const needAny = (...ps: string[]) => async (req: FastifyRequest) => {
  await requireAuth(req, null as any);
  if (!ps.some((p) => req.user!.perms.has(p))) throw forbidden(`Permission requise : ${ps.join(' ou ')}`);
};
const HR_ANY = ['hr.self', 'hr.view', 'hr.team', 'hr.manage', 'hr.salary', 'hr.payroll'];
const STAFF = ['hr.view', 'hr.team', 'hr.manage', 'hr.salary', 'hr.payroll'];
const scope = (req: FastifyRequest) => scopeOf(getPool(), actorOf(req), req.user!.perms);
const hotelName = async (id: number) => (await one<any>(getPool(), 'SELECT name FROM hotels WHERE id = $1', [id]))?.name ?? 'Hôtel';
async function sendTable(rep: FastifyReply, format: string, name: string, title: string, sub: string, cols: any[], rows: any[], total: any, hotel: string) {
  if (format === 'xlsx') {
    rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('content-disposition', `attachment; filename="${name}.xlsx"`);
    return rep.send(await tableXlsx(title, sub, cols, rows, total));
  }
  if (format === 'csv') {
    rep.header('content-type', 'text/csv; charset=utf-8').header('content-disposition', `attachment; filename="${name}.csv"`);
    return rep.send(tableCsv(cols, rows, total));
  }
  rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${name}.pdf"`);
  return rep.send(await tablePdf(hotel, title, sub, cols, rows, total));
}
/** Le chef de département agit sur son équipe ; les RH sur tous. */
async function teamGuard(req: FastifyRequest, employeeId: number) {
  const sc = await scope(req);
  const p = req.user!.perms;
  if (!p.has('hr.manage') && !p.has('hr.team')) throw forbidden();
  const e = await employeeInScope(getPool(), actorOf(req), sc, employeeId, { team: true });
  return { sc, e };
}
const money = (n: number) => `${(Math.round(Number(n) * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} ${currency.symbol}`;
function payslipPdf(hotel: any, run: any, p: any): Promise<Buffer> {
  return new Promise((resolve) => {
    const doc = new PDFDocument({ size: 'A4', margin: 40 });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.fillColor('#7A1F2B').font('Helvetica-Bold').fontSize(18).text('BULLETIN DE PAIE', 40, 40);
    doc.fillColor('#111').fontSize(10).text(`Période : ${run.period} · N° ${p.number}`, 40, 64);
    doc.font('Helvetica-Bold').fontSize(11).text(hotel.name ?? '', 330, 40, { width: 225, align: 'right' });
    doc.font('Helvetica').fontSize(8).fillColor('#444').text([hotel.address, hotel.city, hotel.nif && `NIF ${hotel.nif}`].filter(Boolean).join('\n'), 330, 56, { width: 225, align: 'right' });
    doc.roundedRect(40, 96, 515, 52, 4).strokeColor('#ccc').stroke();
    doc.fillColor('#111').font('Helvetica-Bold').fontSize(10).text(p.full_name, 50, 104);
    doc.font('Helvetica').fontSize(8.5).fillColor('#444').text(`Matricule ${p.matricule} · ${p.position ?? ''} · ${p.department ?? ''}`, 50, 119)
      .text(`Salaire de base ${money(p.base_salary)} · Jours payés ${Number(p.paid_days)} · Absences ${Number(p.absence_days)} j`, 50, 132);
    let y = 166;
    doc.rect(40, y, 515, 16).fill('#7A1F2B');
    doc.fillColor('#fff').font('Helvetica-Bold').fontSize(8.5).text('Rubrique', 46, y + 4).text('Gains', 350, y + 4, { width: 95, align: 'right' }).text('Retenues', 450, y + 4, { width: 100, align: 'right' });
    y += 22;
    const row = (label: string, gain: number | null, ret: number | null, bold = false) => {
      doc.fillColor('#111').font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(8.5).text(label, 46, y, { width: 300 });
      if (gain !== null) doc.text(money(gain), 350, y, { width: 95, align: 'right' });
      if (ret !== null) doc.text(money(ret), 450, y, { width: 100, align: 'right' });
      y += 15;
      doc.moveTo(40, y - 3).lineTo(555, y - 3).strokeColor('#eee').stroke();
    };
    row('Salaire de base', Number(p.base_salary), null);
    for (const l of p.lines as any[]) {
      if (l.kind === 'employer') continue;
      if (l.amount >= 0) row(l.label, l.amount, null); else row(l.label, null, -l.amount);
    }
    y += 4;
    row('SALAIRE BRUT', Number(p.gross), null, true);
    row('Base des cotisations', Number(p.contributory_base), null);
    row('Revenu imposable', Number(p.taxable), null);
    y += 6;
    doc.rect(330, y, 225, 26).fill('#F5EEDC');
    doc.fillColor('#7A1F2B').font('Helvetica-Bold').fontSize(12).text('NET À PAYER', 340, y + 7).text(money(p.net), 430, y + 7, { width: 118, align: 'right' });
    y += 40;
    const emp = (p.lines as any[]).filter((l) => l.kind === 'employer');
    if (emp.length) {
      doc.fillColor('#555').font('Helvetica-Bold').fontSize(8).text('Charges patronales (information)', 40, y); y += 12;
      for (const l of emp) { doc.font('Helvetica').text(`${l.label} : ${money(l.amount)}`, 40, y); y += 11; }
    }
    doc.fillColor('#777').font('Helvetica').fontSize(7.5).text(`Bulletin ${run.status === 'draft' ? 'PROVISOIRE (paie non validée)' : 'validé'} — édité le ${new Date().toLocaleString('fr-FR', { timeZone: TZ })}. À conserver sans limitation de durée.`, 40, 780, { width: 515, align: 'center' });
    doc.end();
  });
}

export async function hrRoutes(app: FastifyInstance) {
  // ===================================================== Référentiels =====================================================
  app.get('/api/hr/meta', { preHandler: needAny(...HR_ANY, 'hr.terminal') }, async (req) => {
    const h = req.user!.hotelId;
    const sc = await scope(req);
    const sq = scopeSql(sc, 'e', 2);
    return {
      scope: sc, status: STATUS_LABEL, contract_kinds: CONTRACT_LABEL,
      departments: await q(getPool(), `SELECT d.*, e.first_name || ' ' || e.last_name AS manager FROM hr_departments d LEFT JOIN employees e ON e.id = d.manager_employee_id WHERE d.hotel_id = $1 ORDER BY d.active DESC, d.sort_order, d.name`, [h]),
      positions: await q(getPool(), 'SELECT * FROM hr_positions WHERE hotel_id = $1 AND active ORDER BY department, name', [h]),
      shift_types: await q(getPool(), 'SELECT * FROM hr_shift_types WHERE hotel_id = $1 ORDER BY active DESC, start_time', [h]),
      leave_types: await q(getPool(), 'SELECT * FROM hr_leave_types WHERE hotel_id = $1 AND active ORDER BY builtin DESC, name', [h]),
      employees: await q(getPool(), `SELECT e.id, e.matricule, e.first_name, e.last_name, e.department, e.position, e.status FROM employees e WHERE e.hotel_id = $1 AND e.status <> 'left' AND ${sq.sql} ORDER BY e.last_name`, [h, ...sq.params]),
      roles: req.user!.perms.has('users.manage') ? await q(getPool(), `SELECT code, name FROM roles WHERE code <> 'admin' ORDER BY name`) : [],
    };
  });

  app.get('/api/hr/dashboard', { preHandler: needAny(...STAFF) }, async (req) => hrDashboard(getPool(), req.user!.hotelId, await scope(req)));
  app.get('/api/hr/alerts', { preHandler: needAny(...STAFF) }, async (req) => hrAlerts(getPool(), req.user!.hotelId, await scope(req)));

  // ===================================================== Départements et postes =====================================================
  app.post('/api/hr/departments', { preHandler: requirePerm('hr.manage') }, async (req, rep) => {
    const b = z.object({ code: z.string().trim().min(2).max(30).regex(/^[a-z0-9_]+$/i), name: z.string().trim().min(2).max(60), manager_employee_id: z.number().int().positive().nullish() }).parse(req.body);
    if (await one(getPool(), 'SELECT 1 FROM hr_departments WHERE hotel_id = $1 AND lower(code) = lower($2)', [req.user!.hotelId, b.code])) throw conflict('Code de département déjà utilisé.');
    const r = await one(getPool(), `INSERT INTO hr_departments (hotel_id, code, name, manager_employee_id, sort_order) VALUES ($1,lower($2),$3,$4,100) RETURNING *`, [req.user!.hotelId, b.code, b.name, b.manager_employee_id ?? null]);
    await audit(getPool(), actorOf(req), 'create', 'hr_department', (r as any).id, null, b);
    rep.code(201);
    return r;
  });
  app.patch('/api/hr/departments/:id', { preHandler: requirePerm('hr.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ name: z.string().trim().min(2).max(60).optional(), manager_employee_id: z.number().int().positive().nullable().optional(), active: z.boolean().optional() }).parse(req.body);
    const cur = await one<any>(getPool(), 'SELECT * FROM hr_departments WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!cur) throw notFound('Département introuvable');
    if (b.active === false && (await one(getPool(), `SELECT 1 FROM employees WHERE hotel_id = $1 AND department = $2 AND status <> 'left'`, [req.user!.hotelId, cur.code]))) throw conflict('Des employés sont encore rattachés à ce département.');
    if (b.manager_employee_id && !(await one(getPool(), 'SELECT 1 FROM employees WHERE id = $1 AND hotel_id = $2', [b.manager_employee_id, req.user!.hotelId]))) throw badRequest('Employé inconnu.');
    const r = await one(getPool(), `UPDATE hr_departments SET name = COALESCE($2, name), manager_employee_id = CASE WHEN $3::boolean THEN $4 ELSE manager_employee_id END, active = COALESCE($5, active) WHERE id = $1 RETURNING *`,
      [id, b.name ?? null, b.manager_employee_id !== undefined, b.manager_employee_id ?? null, b.active ?? null]);
    await audit(getPool(), actorOf(req), 'update', 'hr_department', id, cur, b);
    return r;
  });
  app.post('/api/hr/positions', { preHandler: requirePerm('hr.manage') }, async (req, rep) => {
    const b = z.object({ department: z.string().min(1).max(30), name: z.string().trim().min(2).max(80), default_salary: Money.nullish() }).parse(req.body);
    if (!(await one(getPool(), 'SELECT 1 FROM hr_departments WHERE hotel_id = $1 AND code = $2', [req.user!.hotelId, b.department]))) throw badRequest('Département inconnu.');
    if (await one(getPool(), 'SELECT 1 FROM hr_positions WHERE hotel_id = $1 AND department = $2 AND lower(name) = lower($3)', [req.user!.hotelId, b.department, b.name])) throw conflict('Poste déjà existant.');
    rep.code(201);
    return one(getPool(), 'INSERT INTO hr_positions (hotel_id, department, name, default_salary) VALUES ($1,$2,$3,$4) RETURNING *', [req.user!.hotelId, b.department, b.name, b.default_salary ?? null]);
  });
  app.patch('/api/hr/positions/:id', { preHandler: requirePerm('hr.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ name: z.string().trim().min(2).max(80).optional(), default_salary: Money.nullable().optional(), active: z.boolean().optional() }).parse(req.body);
    const r = await one(getPool(), `UPDATE hr_positions SET name = COALESCE($3, name), default_salary = CASE WHEN $4::boolean THEN $5 ELSE default_salary END, active = COALESCE($6, active) WHERE id = $1 AND hotel_id = $2 RETURNING *`,
      [id, req.user!.hotelId, b.name ?? null, b.default_salary !== undefined, b.default_salary ?? null, b.active ?? null]);
    if (!r) throw notFound('Poste introuvable');
    return r;
  });
  app.post('/api/hr/shift-types', { preHandler: requirePerm('hr.manage') }, async (req, rep) => {
    const b = z.object({ code: z.string().trim().min(1).max(4), name: z.string().trim().min(2).max(40), start_time: Time, end_time: Time, break_minutes: z.number().int().min(0).max(240).default(0), color: z.string().regex(/^#[0-9a-f]{6}$/i).default('#64748B') }).parse(req.body);
    if (b.start_time === b.end_time) throw badRequest('Horaires identiques.');
    if (await one(getPool(), 'SELECT 1 FROM hr_shift_types WHERE hotel_id = $1 AND upper(code) = upper($2)', [req.user!.hotelId, b.code])) throw conflict('Code d\'équipe déjà utilisé.');
    rep.code(201);
    return one(getPool(), 'INSERT INTO hr_shift_types (hotel_id, code, name, start_time, end_time, break_minutes, color) VALUES ($1,upper($2),$3,$4,$5,$6,$7) RETURNING *', [req.user!.hotelId, b.code, b.name, b.start_time, b.end_time, b.break_minutes, b.color]);
  });
  app.patch('/api/hr/shift-types/:id', { preHandler: requirePerm('hr.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ name: z.string().trim().min(2).max(40).optional(), start_time: Time.optional(), end_time: Time.optional(), break_minutes: z.number().int().min(0).max(240).optional(), color: z.string().regex(/^#[0-9a-f]{6}$/i).optional(), active: z.boolean().optional() }).parse(req.body);
    const r = await one(getPool(), `UPDATE hr_shift_types SET name = COALESCE($3, name), start_time = COALESCE($4, start_time), end_time = COALESCE($5, end_time), break_minutes = COALESCE($6, break_minutes), color = COALESCE($7, color), active = COALESCE($8, active)
        WHERE id = $1 AND hotel_id = $2 RETURNING *`, [id, req.user!.hotelId, b.name ?? null, b.start_time ?? null, b.end_time ?? null, b.break_minutes ?? null, b.color ?? null, b.active ?? null]);
    if (!r) throw notFound('Équipe introuvable');
    return r;
  });
  app.post('/api/hr/leave-types', { preHandler: requirePerm('hr.manage') }, async (req, rep) => {
    const b = z.object({ code: z.string().trim().min(2).max(30).regex(/^[a-z0-9_]+$/i), name: z.string().trim().min(2).max(60), paid: z.boolean(), deducts_balance: z.boolean().default(false), hourly: z.boolean().default(false),
      requires_document: z.boolean().default(false), justified: z.boolean().default(true), color: z.string().regex(/^#[0-9a-f]{6}$/i).default('#0E7490') }).parse(req.body);
    if (await one(getPool(), 'SELECT 1 FROM hr_leave_types WHERE hotel_id = $1 AND lower(code) = lower($2)', [req.user!.hotelId, b.code])) throw conflict('Code déjà utilisé.');
    rep.code(201);
    return one(getPool(), `INSERT INTO hr_leave_types (hotel_id, code, name, paid, deducts_balance, hourly, requires_document, justified, color) VALUES ($1,lower($2),$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [req.user!.hotelId, b.code, b.name, b.paid, b.deducts_balance, b.hourly, b.requires_document, b.justified, b.color]);
  });

  // ===================================================== Employés =====================================================
  app.get('/api/hr/employees', { preHandler: needAny(...STAFF) }, async (req) => {
    const f = z.object({ q: z.string().optional(), department: z.string().optional(), status: z.string().optional() }).parse(req.query);
    const sc = await scope(req);
    const sq = scopeSql(sc, 'e', 5);
    const rows = await q<any>(getPool(), `SELECT * FROM (SELECT e.*, ${EFFECTIVE_STATUS('e')} AS effective_status, m.first_name || ' ' || m.last_name AS manager_name,
        (SELECT string_agg(u.username, ', ') FROM users u WHERE u.employee_id = e.id) AS usernames,
        (SELECT min(p.id) FROM photos p WHERE p.owner_type = 'employee' AND p.owner_id = e.id) AS photo_id,
        COALESCE((SELECT name FROM hr_departments d WHERE d.hotel_id = e.hotel_id AND d.code = e.department), e.department) AS department_name
       FROM employees e LEFT JOIN employees m ON m.id = e.manager_id WHERE e.hotel_id = $1 AND ${sq.sql}
         AND ($2::text IS NULL OR e.matricule ILIKE '%' || $2 || '%' OR e.last_name ILIKE '%' || $2 || '%' OR e.first_name ILIKE '%' || $2 || '%' OR e.phone ILIKE '%' || $2 || '%')
         AND ($3::text IS NULL OR e.department = $3)) x WHERE ($4::text IS NULL OR x.effective_status = $4 OR ($4 = 'present' AND x.status <> 'left')) ORDER BY (x.status = 'left'), x.last_name, x.first_name`,
    [req.user!.hotelId, f.q?.trim() || null, f.department || null, f.status || null, ...sq.params]);
    return rows.map((e) => redact(e, sc));
  });
  app.get('/api/hr/employees/:id', { preHandler: needAny(...HR_ANY) }, async (req) => {
    const { id } = Id.parse(req.params);
    const sc = await scope(req);
    const p = req.user!.perms;
    const e0 = await employeeInScope(getPool(), actorOf(req), sc, id);
    if (e0.id !== sc.employeeId && !STAFF.some((x) => p.has(x))) throw forbidden();
    const own = e0.id === sc.employeeId;
    const e = await one<any>(getPool(), `SELECT e.*, ${EFFECTIVE_STATUS('e')} AS effective_status, m.first_name || ' ' || m.last_name AS manager_name,
        (SELECT min(p.id) FROM photos p WHERE p.owner_type = 'employee' AND p.owner_id = e.id) AS photo_id FROM employees e LEFT JOIN employees m ON m.id = e.manager_id WHERE e.id = $1`, [id]);
    const salary = sc.salary || own;
    const docs = await q<any>(getPool(), `SELECT d.*, (SELECT array_agg(p.id ORDER BY p.id) FROM photos p WHERE p.owner_type = 'hr_document' AND p.owner_id = d.id) AS files FROM hr_documents d
        WHERE d.employee_id = $1 AND ($2::boolean OR NOT d.confidential) ORDER BY d.expiry_date NULLS LAST, d.id`, [id, p.has('hr.manage')]);
    return {
      ...redact(e, sc),
      contracts: (await q<any>(getPool(), `SELECT c.*, (SELECT coalesce(json_agg(a ORDER BY a.effective_date), '[]') FROM hr_contract_amendments a WHERE a.contract_id = c.id) AS amendments FROM hr_contracts c WHERE c.employee_id = $1 ORDER BY c.start_date DESC`, [id]))
        .map((c) => (salary ? c : { ...c, base_salary: null, amendments: (c.amendments as any[]).map((a) => ({ ...a, new_salary: null })) })),
      balance: await leaveBalance(getPool(), req.user!.hotelId, id),
      leaves: await q(getPool(), `SELECT r.*, t.name AS type_name, t.color FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id WHERE r.employee_id = $1 ORDER BY r.start_date DESC LIMIT 50`, [id]),
      attendance: await q(getPool(), `SELECT * FROM hr_attendance WHERE employee_id = $1 ORDER BY work_date DESC LIMIT 31`, [id]),
      schedule: await q(getPool(), `SELECT sh.*, st.code, st.name AS shift_name, st.color FROM hr_schedule sh LEFT JOIN hr_shift_types st ON st.id = sh.shift_type_id WHERE sh.employee_id = $1 AND sh.work_date BETWEEN $2 AND $3 ORDER BY sh.work_date`, [id, today(), addDays(today(), 13)]),
      documents: docs,
      evaluations: await q(getPool(), `SELECT v.*, u.full_name AS evaluator FROM hr_evaluations v LEFT JOIN users u ON u.id = v.evaluator_id WHERE v.employee_id = $1 AND ($2::boolean OR v.status = 'final') ORDER BY v.eval_date DESC`, [id, !own || STAFF.some((x) => p.has(x))]),
      trainings: await q(getPool(), 'SELECT * FROM hr_trainings WHERE employee_id = $1 ORDER BY start_date DESC NULLS LAST', [id]),
      skills: await q(getPool(), 'SELECT * FROM hr_skills WHERE employee_id = $1 ORDER BY level DESC, skill', [id]),
      pay_items: sc.salary ? await q(getPool(), 'SELECT * FROM hr_pay_items WHERE employee_id = $1 ORDER BY active DESC, id DESC', [id]) : [],
      advances: salary ? await q(getPool(), 'SELECT * FROM hr_advances WHERE employee_id = $1 ORDER BY id DESC', [id]) : [],
      payslips: salary ? await q(getPool(), `SELECT p.id, p.number, r.period, r.status, p.gross, p.net FROM hr_payslips p JOIN hr_payroll_runs r ON r.id = p.run_id WHERE p.employee_id = $1 AND r.status IN ('validated','paid') ORDER BY r.period DESC`, [id]) : [],
      users: req.user!.perms.has('users.manage') || own ? await q(getPool(), `SELECT u.id, u.username, u.active, u.last_login_at, r.code AS role, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.employee_id = $1`, [id]) : [],
      history: p.has('hr.manage') ? await q(getPool(), `SELECT a.created_at, a.action, u.full_name AS user FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE a.entity = 'employee' AND a.entity_id = $1 ORDER BY a.created_at DESC LIMIT 60`, [String(id)]) : [],
    };
  });
  const EmpBody = z.object({
    matricule: z.string().trim().min(2).max(20).regex(/^[A-Za-z0-9_-]+$/, 'Matricule : lettres, chiffres, - _').optional(), first_name: z.string().trim().min(1).max(60), last_name: z.string().trim().min(1).max(60),
    gender: z.enum(['M', 'F']).nullish(), birth_date: zDate.nullish(), phone: s(40), email: z.string().trim().email().max(120).nullish().or(z.literal('')), address: s(200), city: s(60), emergency_contact: s(160),
    hire_date: zDate.nullish(), department: z.string().min(1).max(30), position: s(80), manager_id: z.number().int().positive().nullish(), notes: s(2000),
  });
  const checkEmp = async (h: number, b: Partial<z.infer<typeof EmpBody>>, id: number | null) => {
    if (b.matricule && (await one(getPool(), 'SELECT 1 FROM employees WHERE hotel_id = $1 AND upper(matricule) = upper($2) AND id <> COALESCE($3, 0)', [h, b.matricule, id]))) throw conflict(`Matricule « ${b.matricule.toUpperCase()} » déjà attribué.`);
    if (b.department && !(await one(getPool(), 'SELECT 1 FROM hr_departments WHERE hotel_id = $1 AND code = $2 AND active', [h, b.department]))) throw badRequest('Département inconnu.');
    if (b.manager_id && (b.manager_id === id || !(await one(getPool(), 'SELECT 1 FROM employees WHERE id = $1 AND hotel_id = $2', [b.manager_id, h])))) throw badRequest('Responsable hiérarchique invalide.');
    if (b.birth_date && b.birth_date > addDays(today(), -365 * 16)) throw badRequest('Date de naissance invalide (16 ans minimum).');
    if (b.hire_date && b.hire_date > addDays(today(), 90)) throw badRequest('Date d\'embauche trop lointaine.');
  };
  app.post('/api/hr/employees', { preHandler: requirePerm('hr.manage') }, async (req, rep) => {
    const b = EmpBody.extend({
      contract: z.object({ kind: z.enum(['cdi', 'cdd', 'seasonal', 'trial', 'internship', 'consultant', 'other']), start_date: zDate, end_date: zDate.nullish(), trial_end: zDate.nullish(), base_salary: Money, weekly_hours: z.number().min(1).max(60).optional() }).nullish(),
      leave_opening: z.number().min(0).max(120).optional(),
    }).parse(req.body);
    const h = req.user!.hotelId;
    await checkEmp(h, b, null);
    if (b.contract && !req.user!.perms.has('hr.salary')) throw forbidden('Saisie du salaire : droit « hr.salary » requis.');
    const r = await tx(async (c) => {
      const e = await one<any>(c, `INSERT INTO employees (hotel_id, matricule, first_name, last_name, gender, birth_date, phone, email, address, city, emergency_contact, hire_date, department, position, manager_id, notes, leave_opening)
          VALUES ($1,upper($2),$3,$4,$5,$6,$7,$8,$9,$10,$11,COALESCE($12, CURRENT_DATE),$13,$14,$15,$16,$17) RETURNING *`,
      [h, b.matricule ?? null, b.first_name, b.last_name, b.gender ?? null, b.birth_date ?? null, b.phone ?? null, b.email || null, b.address ?? null, b.city ?? null, b.emergency_contact ?? null, b.hire_date ?? null, b.department, b.position ?? null, b.manager_id ?? null, b.notes ?? null, b.leave_opening ?? 0]);
      await audit(c, actorOf(req), 'create', 'employee', e.id, null, { matricule: e.matricule, name: `${b.first_name} ${b.last_name}`, department: b.department });
      if (b.contract) await createContract(c, actorOf(req), e.id, { ...b.contract, position: b.position ?? null, department: b.department });
      return one<any>(c, 'SELECT * FROM employees WHERE id = $1', [e.id]);
    }).catch((e: any) => { if (e?.code === '23505') throw conflict('Matricule déjà attribué.'); throw e; });
    rep.code(201);
    return r;
  });
  app.patch('/api/hr/employees/:id', { preHandler: requirePerm('hr.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = EmpBody.partial().extend({ leave_opening: z.number().min(0).max(120).optional() }).parse(req.body);
    const h = req.user!.hotelId;
    await checkEmp(h, b, id);
    return tx(async (c) => {
      const cur = await one<any>(c, 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, h]);
      if (!cur) throw notFound('Employé introuvable');
      const keys = Object.keys(b).filter((k) => (b as any)[k] !== undefined);
      if (!keys.length) return cur;
      const vals = keys.map((k) => (k === 'matricule' ? String((b as any)[k]).toUpperCase() : k === 'email' ? (b as any)[k] || null : (b as any)[k]));
      const r = await one<any>(c, `UPDATE employees SET ${keys.map((k, i) => `${k} = $${i + 2}`).join(', ')}, updated_at = now() WHERE id = $1 RETURNING *`, [id, ...vals]);
      // le nom affiché des comptes liés suit la fiche
      if (b.first_name || b.last_name) await c.query(`UPDATE users SET full_name = $2 WHERE employee_id = $1`, [id, `${r.first_name} ${r.last_name}`]);
      await audit(c, actorOf(req), 'update', 'employee', id, Object.fromEntries(keys.map((k) => [k, cur[k]])), Object.fromEntries(keys.map((k) => [k, r[k]])));
      return r;
    }).catch((e: any) => { if (e?.code === '23505') throw conflict('Matricule déjà attribué.'); throw e; });
  });
  app.post('/api/hr/employees/:id/status', { preHandler: requirePerm('hr.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ status: z.enum(['active', 'suspended', 'left']), date: zDate.nullish(), reason: s(500) }).parse(req.body);
    await tx((c) => setStatus(c, actorOf(req), id, b));
    return { ok: true };
  });
  app.post('/api/hr/employees/:id/pin', { preHandler: requirePerm('hr.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ pin: z.string().regex(/^\d{4,6}$/, 'Code de 4 à 6 chiffres') }).parse(req.body);
    const r = await one(getPool(), 'UPDATE employees SET pin_hash = $3 WHERE id = $1 AND hotel_id = $2 RETURNING id', [id, req.user!.hotelId, await hashPassword(b.pin)]);
    if (!r) throw notFound('Employé introuvable');
    await audit(getPool(), actorOf(req), 'set_pin', 'employee', id, null, null);
    return { ok: true };
  });
  app.post('/api/hr/employees/:id/leave-adjust', { preHandler: requirePerm('hr.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ days: z.number().min(-60).max(60).refine((x) => x !== 0, 'Nombre de jours nul'), reason: z.string().trim().min(5).max(300) }).parse(req.body);
    if (!(await one(getPool(), 'SELECT 1 FROM employees WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]))) throw notFound('Employé introuvable');
    await getPool().query('INSERT INTO hr_leave_adjustments (employee_id, days, reason, created_by) VALUES ($1,$2,$3,$4)', [id, b.days, b.reason, req.user!.id]);
    await audit(getPool(), actorOf(req), 'leave_adjust', 'employee', id, null, b);
    return leaveBalance(getPool(), req.user!.hotelId, id);
  });

  // ---- Accès au logiciel (Administration des utilisateurs) ----
  app.post('/api/hr/employees/:id/access', { preHandler: requirePerm('users.manage') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ username: z.string().trim().min(3).max(40).regex(/^[a-z0-9._-]+$/i, 'Identifiant : lettres, chiffres, . _ -'), password: z.string().min(8).max(100), role: z.string().min(2).max(40) }).parse(req.body);
    const weak = validatePasswordStrength(b.password);
    if (weak) throw badRequest(weak);
    if (b.role === 'admin') throw forbidden('Le rôle administrateur ne s\'attribue pas depuis les RH.');
    const r = await tx(async (c) => {
      const e = await one<any>(c, 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
      if (!e) throw notFound('Employé introuvable');
      if (e.status === 'left') throw conflict('Employé sorti.');
      if (await one(c, 'SELECT 1 FROM users WHERE lower(username) = lower($1)', [b.username])) throw conflict('Identifiant déjà utilisé.');
      const role = await assertRoleGrantable(c, req.user!, b.role);
      const u = await one<any>(c, `INSERT INTO users (hotel_id, username, full_name, password_hash, role_id, employee_id, must_change_password, active) VALUES ($1,$2,$3,$4,$5,$6,true,$7) RETURNING id, username`,
        [req.user!.hotelId, b.username, `${e.first_name} ${e.last_name}`, await hashPassword(b.password), role.id, id, e.status === 'active']);
      await c.query(`UPDATE users SET department_id = (SELECT d.id FROM hr_departments d WHERE d.hotel_id = $2 AND d.code = $3), first_name = $4, last_name = $5, job_title = $6, created_by = $7 WHERE id = $1`,
        [u.id, req.user!.hotelId, e.department, e.first_name, e.last_name, e.position ?? null, req.user!.id]);
      await audit(c, actorOf(req), 'create_access', 'employee', id, null, { username: b.username, role: b.role });
      return u;
    });
    rep.code(201);
    return r;
  });
  app.patch('/api/hr/users/:id', { preHandler: requirePerm('users.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ role: z.string().min(2).max(40).optional(), active: z.boolean().optional(), password: z.string().min(8).max(100).optional() }).parse(req.body);
    return tx(async (c) => {
      const u = await one<any>(c, `SELECT u.*, r.code AS role FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1 AND u.hotel_id = $2`, [id, req.user!.hotelId]);
      if (!u) throw notFound('Utilisateur introuvable');
      if (u.role === 'admin' || b.role === 'admin') throw forbidden('Compte administrateur : non modifiable ici.');
      if (u.id === req.user!.id) throw forbidden('Vous ne pouvez pas modifier votre propre compte ici.');
      if (b.active && u.employee_id && (await one(c, `SELECT 1 FROM employees WHERE id = $1 AND status <> 'active'`, [u.employee_id]))) throw conflict('Employé suspendu ou sorti : réactivez d\'abord sa fiche RH.');
      if (b.role) {
        const r = await assertRoleGrantable(c, req.user!, b.role);
        await c.query('UPDATE users SET role_id = $2 WHERE id = $1', [id, r.id]);
      }
      if (b.active !== undefined) await c.query('UPDATE users SET active = $2 WHERE id = $1', [id, b.active]);
      if (b.active === false) await c.query('DELETE FROM sessions WHERE user_id = $1', [id]);
      if (b.password) {
        const weak = validatePasswordStrength(b.password);
        if (weak) throw badRequest(weak);
        await c.query('UPDATE users SET password_hash = $2, must_change_password = true, failed_logins = 0, locked_until = NULL WHERE id = $1', [id, await hashPassword(b.password)]);
        await c.query('DELETE FROM sessions WHERE user_id = $1', [id]);
      }
      await audit(c, actorOf(req), 'update_access', 'user', id, { role: u.role, active: u.active }, { role: b.role, active: b.active, password_reset: !!b.password });
      return { ok: true };
    });
  });

  // ===================================================== Contrats =====================================================
  const ContractBody = z.object({ kind: z.enum(['cdi', 'cdd', 'seasonal', 'trial', 'internship', 'consultant', 'other']), position: s(80), department: z.string().max(30).nullish(), start_date: zDate, end_date: zDate.nullish(),
    trial_end: zDate.nullish(), base_salary: Money, weekly_hours: z.number().min(1).max(60).optional(), notes: s(1000), renew: z.boolean().optional() });
  app.post('/api/hr/employees/:id/contracts', { preHandler: requirePerm('hr.manage', 'hr.salary') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = ContractBody.parse(req.body);
    const r = await tx((c) => createContract(c, actorOf(req), id, b));
    rep.code(201);
    return r;
  });
  app.post('/api/hr/contracts/:id/amendments', { preHandler: requirePerm('hr.manage') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ effective_date: zDate, description: z.string().trim().min(5).max(1000), new_salary: Money.nullish(), new_position: s(80), new_end_date: zDate.nullish(), new_weekly_hours: z.number().min(1).max(60).nullish() }).parse(req.body);
    if (b.new_salary !== undefined && b.new_salary !== null && !req.user!.perms.has('hr.salary')) throw forbidden('Modification du salaire : droit « hr.salary » requis.');
    const r = await tx((c) => addAmendment(c, actorOf(req), id, b));
    rep.code(201);
    return r;
  });
  app.post('/api/hr/contracts/:id/archive', { preHandler: requirePerm('hr.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const c = await one<any>(getPool(), 'SELECT * FROM hr_contracts WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!c) throw notFound('Contrat introuvable');
    if (c.status === 'active') throw conflict('Le contrat en cours ne peut pas être archivé.');
    await getPool().query(`UPDATE hr_contracts SET status = 'archived' WHERE id = $1`, [id]);
    await audit(getPool(), actorOf(req), 'archive_contract', 'employee', c.employee_id, null, { contract: c.number });
    return { ok: true };
  });
  app.get('/api/hr/contracts', { preHandler: needAny('hr.manage', 'hr.salary') }, async (req) => {
    const f = z.object({ status: z.string().optional(), expiring: z.coerce.number().int().optional() }).parse(req.query);
    const sc = await scope(req);
    const rows = await q<any>(getPool(), `SELECT c.*, e.matricule, e.first_name, e.last_name FROM hr_contracts c JOIN employees e ON e.id = c.employee_id WHERE c.hotel_id = $1
        AND ($2::text IS NULL OR c.status = $2) AND ($3::int IS NULL OR (c.status = 'active' AND c.end_date IS NOT NULL AND c.end_date <= CURRENT_DATE + $3)) ORDER BY c.status, c.end_date NULLS LAST`, [req.user!.hotelId, f.status ?? null, f.expiring ?? null]);
    return rows.map((c) => (sc.salary ? c : { ...c, base_salary: null }));
  });

  // ===================================================== Planning =====================================================
  app.get('/api/hr/schedule', { preHandler: needAny(...HR_ANY) }, async (req) => {
    const f = z.object({ from: zDate, to: zDate, department: z.string().optional() }).parse(req.query);
    if (f.to < f.from || (Date.parse(f.to) - Date.parse(f.from)) / 86400000 > 45) throw badRequest('Période invalide (45 jours maximum).');
    const sc = await scope(req);
    const self = !STAFF.some((p) => req.user!.perms.has(p));
    // l'employé voit le planning de son département (sans données sensibles)
    const me = sc.employeeId ? await one<any>(getPool(), 'SELECT department FROM employees WHERE id = $1', [sc.employeeId]) : null;
    const sq = self ? { sql: `e.department = $3`, params: [me?.department ?? '__none__'] } : scopeSql(sc, 'e', 3);
    const emps = await q<any>(getPool(), `SELECT e.id, e.matricule, e.first_name, e.last_name, e.department, e.position, e.status FROM employees e WHERE e.hotel_id = $1 AND (e.status <> 'left' OR e.exit_date >= $2::date)
        AND ($${3 + sq.params.length}::text IS NULL OR e.department = $${3 + sq.params.length}) AND ${sq.sql} ORDER BY e.department, e.last_name`, [req.user!.hotelId, f.from, ...sq.params, f.department || null]);
    const ids = emps.map((e) => e.id);
    return {
      employees: emps,
      entries: await q(getPool(), `SELECT sh.*, st.code, st.color FROM hr_schedule sh LEFT JOIN hr_shift_types st ON st.id = sh.shift_type_id WHERE sh.employee_id = ANY($1::int[]) AND sh.work_date BETWEEN $2 AND $3`, [ids, f.from, f.to]),
      leaves: await q(getPool(), `SELECT r.id, r.employee_id, r.start_date, r.end_date, r.status, r.number, t.name AS type_name, t.color, t.hourly FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id
          WHERE r.employee_id = ANY($1::int[]) AND r.status IN ('approved','pending') AND r.start_date <= $3 AND r.end_date >= $2`, [ids, f.from, f.to]),
      editable: req.user!.perms.has('hr.manage') || req.user!.perms.has('hr.team'),
    };
  });
  const ShiftBody = z.object({ employee_id: z.number().int().positive(), work_date: zDate, shift_type_id: z.number().int().positive().nullish(), start_time: Time.nullish(), end_time: Time.nullish(),
    break_minutes: z.number().int().min(0).max(240).nullish(), rest: z.boolean().optional(), zone: s(80), notes: s(300) });
  app.put('/api/hr/schedule', { preHandler: needAny('hr.manage', 'hr.team') }, async (req) => {
    const b = ShiftBody.parse(req.body);
    await teamGuard(req, b.employee_id);
    return tx(async (c) => {
      const r = await setShift(c, actorOf(req), b);
      await audit(c, actorOf(req), 'schedule', 'employee', b.employee_id, null, { date: b.work_date, rest: !!b.rest, start: r.start_time, end: r.end_time });
      return r;
    });
  });
  app.delete('/api/hr/schedule', { preHandler: needAny('hr.manage', 'hr.team') }, async (req) => {
    const b = z.object({ employee_id: z.coerce.number().int().positive(), work_date: zDate }).parse(req.query);
    await teamGuard(req, b.employee_id);
    await tx((c) => clearShift(c, actorOf(req), b.employee_id, b.work_date));
    return { ok: true };
  });
  app.post('/api/hr/schedule/rotation', { preHandler: needAny('hr.manage', 'hr.team') }, async (req) => {
    const b = z.object({ employee_ids: z.array(z.number().int().positive()).min(1).max(60), start_date: zDate, end_date: zDate, pattern: z.array(z.string().min(1).max(4)).min(1).max(28), offset_per_employee: z.number().int().min(0).max(28).optional() }).parse(req.body);
    for (const id of b.employee_ids) await teamGuard(req, id);
    return tx((c) => applyRotation(c, actorOf(req), b));
  });
  // ---- Échanges de postes ----
  app.get('/api/hr/swaps', { preHandler: needAny(...HR_ANY) }, async (req) => {
    const sc = await scope(req);
    const sq = scopeSql(sc, 'e', 2);
    return q(getPool(), `SELECT w.*, e.first_name || ' ' || e.last_name AS requester, t.first_name || ' ' || t.last_name AS target FROM hr_shift_swaps w JOIN employees e ON e.id = w.requester_id JOIN employees t ON t.id = w.target_id
        WHERE w.hotel_id = $1 AND (${sq.sql} OR w.target_id = $${2 + sq.params.length}) ORDER BY (w.status = 'pending') DESC, w.created_at DESC LIMIT 100`, [req.user!.hotelId, ...sq.params, sc.employeeId ?? -1]);
  });
  app.post('/api/hr/swaps', { preHandler: needAny(...HR_ANY) }, async (req, rep) => {
    const b = z.object({ requester_id: z.number().int().positive().optional(), target_id: z.number().int().positive(), date_a: zDate, date_b: zDate, reason: s(300) }).parse(req.body);
    const sc = await scope(req);
    const reqId = b.requester_id ?? sc.employeeId;
    if (!reqId) throw conflict('Votre compte n\'est lié à aucune fiche employé.');
    if (reqId !== sc.employeeId) await teamGuard(req, reqId);
    if (reqId === b.target_id) throw badRequest('Choisissez un collègue.');
    const [a, t] = await Promise.all([one<any>(getPool(), 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2', [reqId, req.user!.hotelId]), one<any>(getPool(), 'SELECT * FROM employees WHERE id = $1 AND hotel_id = $2', [b.target_id, req.user!.hotelId])]);
    if (!a || !t || t.status !== 'active') throw badRequest('Collègue inconnu ou indisponible.');
    if (a.department !== t.department) throw conflict('Échange possible uniquement au sein du même département.');
    if (b.date_a < today() || b.date_b < today()) throw badRequest('Postes passés.');
    if (!(await one(getPool(), 'SELECT 1 FROM hr_schedule WHERE employee_id = $1 AND work_date = $2 AND NOT rest', [reqId, b.date_a]))) throw conflict('Aucun poste planifié pour vous à cette date.');
    if (!(await one(getPool(), 'SELECT 1 FROM hr_schedule WHERE employee_id = $1 AND work_date = $2', [b.target_id, b.date_b]))) throw conflict('Aucun poste planifié pour ce collègue à cette date.');
    if (await one(getPool(), `SELECT 1 FROM hr_shift_swaps WHERE requester_id = $1 AND date_a = $2 AND status = 'pending'`, [reqId, b.date_a])) throw conflict('Un échange est déjà en attente pour ce poste.');
    const r = await one(getPool(), `INSERT INTO hr_shift_swaps (hotel_id, requester_id, target_id, date_a, date_b, reason, requested_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`, [req.user!.hotelId, reqId, b.target_id, b.date_a, b.date_b, b.reason ?? null, req.user!.id]);
    await audit(getPool(), actorOf(req), 'swap_request', 'employee', reqId, null, b);
    rep.code(201);
    return r;
  });
  app.post('/api/hr/swaps/:id/decide', { preHandler: needAny('hr.manage', 'hr.team') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ approve: z.boolean(), note: s(300) }).parse(req.body);
    const sc = await scope(req);
    await tx((c) => decideSwap(c, actorOf(req), sc, id, b.approve, b.note ?? null));
    return { ok: true };
  });

  // ===================================================== Pointage =====================================================
  app.get('/api/hr/attendance', { preHandler: needAny(...STAFF) }, async (req) => {
    const f = z.object({ date: zDate.optional(), department: z.string().optional() }).parse(req.query);
    const d = f.date ?? today();
    const sc = await scope(req);
    const sq = scopeSql(sc, 'e', 3);
    return q(getPool(), `SELECT e.id AS employee_id, e.matricule, e.first_name, e.last_name, e.department, e.position, sh.start_time, sh.end_time, sh.rest, st.code AS shift_code, st.color,
        a.id, a.clock_in, a.clock_out, a.break_minutes, a.break_started_at, a.late_minutes, a.early_minutes, a.worked_minutes, a.overtime_minutes, a.source, a.corrected,
        (SELECT t.name FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id WHERE r.employee_id = e.id AND r.status = 'approved' AND NOT t.hourly AND $2::date BETWEEN r.start_date AND r.end_date LIMIT 1) AS leave
       FROM employees e LEFT JOIN hr_schedule sh ON sh.employee_id = e.id AND sh.work_date = $2 LEFT JOIN hr_shift_types st ON st.id = sh.shift_type_id LEFT JOIN hr_attendance a ON a.employee_id = e.id AND a.work_date = $2
      WHERE e.hotel_id = $1 AND (e.status IN ('active','suspended') OR a.id IS NOT NULL) AND ($${3 + sq.params.length}::text IS NULL OR e.department = $${3 + sq.params.length}) AND ${sq.sql}
      ORDER BY (sh.id IS NULL OR sh.rest), sh.start_time, e.last_name`, [req.user!.hotelId, d, ...sq.params, f.department || null]);
  });
  app.get('/api/hr/attendance/month', { preHandler: needAny(...HR_ANY) }, async (req) => {
    const f = z.object({ employee_id: z.coerce.number().int().positive().optional(), month: Period }).parse(req.query);
    const sc = await scope(req);
    const id = f.employee_id ?? sc.employeeId;
    if (!id) throw conflict('Compte non lié à une fiche employé.');
    await employeeInScope(getPool(), actorOf(req), sc, id);
    const from = `${f.month}-01`;
    const to2 = new Date(Date.UTC(+f.month.slice(0, 4), +f.month.slice(5, 7), 0)).toISOString().slice(0, 10);
    const rows = await q<any>(getPool(), `SELECT g.d::date::text AS date, sh.start_time, sh.end_time, sh.rest, st.code AS shift_code, a.clock_in, a.clock_out, a.break_minutes, a.late_minutes, a.worked_minutes, a.overtime_minutes, a.corrected,
        (SELECT t.name FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id WHERE r.employee_id = $1 AND r.status = 'approved' AND NOT t.hourly AND g.d BETWEEN r.start_date AND r.end_date LIMIT 1) AS leave
       FROM generate_series($2::date, $3::date, interval '1 day') g(d) LEFT JOIN hr_schedule sh ON sh.employee_id = $1 AND sh.work_date = g.d LEFT JOIN hr_shift_types st ON st.id = sh.shift_type_id
       LEFT JOIN hr_attendance a ON a.employee_id = $1 AND a.work_date = g.d ORDER BY g.d`, [id, from, to2]);
    const sum = rows.reduce((t, r) => ({ worked: t.worked + (r.worked_minutes ?? 0), overtime: t.overtime + (r.overtime_minutes ?? 0), late: t.late + (r.late_minutes > 0 ? 1 : 0), late_minutes: t.late_minutes + (r.late_minutes ?? 0),
      present: t.present + (r.clock_in ? 1 : 0), absent: t.absent + (r.start_time && !r.rest && !r.clock_in && !r.leave && r.date < today() ? 1 : 0), leave: t.leave + (r.leave ? 1 : 0) }), { worked: 0, overtime: 0, late: 0, late_minutes: 0, present: 0, absent: 0, leave: 0 });
    return { employee_id: id, month: f.month, days: rows, summary: sum };
  });
  // pointage personnel (depuis le poste de l'employé)
  app.post('/api/hr/clock', { preHandler: requirePerm('hr.self') }, async (req) => {
    const b = z.object({ action: z.enum(['in', 'out', 'break_start', 'break_end', 'toggle']) }).parse(req.body);
    const me = await myEmployee(getPool(), actorOf(req));
    return tx((c) => clock(c, actorOf(req), me.id, b.action, 'self'));
  });
  // pointage manuel par le responsable
  app.post('/api/hr/attendance/clock', { preHandler: needAny('hr.manage', 'hr.team') }, async (req) => {
    const b = z.object({ employee_id: z.number().int().positive(), action: z.enum(['in', 'out', 'break_start', 'break_end', 'toggle']) }).parse(req.body);
    await teamGuard(req, b.employee_id);
    return tx((c) => clock(c, actorOf(req), b.employee_id, b.action, 'manual'));
  });
  // borne de pointage : matricule + code personnel
  app.post('/api/hr/terminal/clock', { preHandler: requirePerm('hr.terminal'), config: { rateLimit: { max: 30, timeWindow: '1 minute' } } as any }, async (req) => {
    const b = z.object({ matricule: z.string().trim().min(2).max(20), pin: z.string().regex(/^\d{4,6}$/), action: z.enum(['in', 'out', 'break_start', 'break_end', 'toggle']).default('toggle') }).parse(req.body);
    const e = await one<any>(getPool(), 'SELECT * FROM employees WHERE hotel_id = $1 AND upper(matricule) = upper($2)', [req.user!.hotelId, b.matricule]);
    if (!e || !e.pin_hash || !(await verifyPassword(b.pin, e.pin_hash))) {
      await audit(getPool(), actorOf(req), 'terminal_refused', 'employee', e?.id ?? null, null, { matricule: b.matricule });
      throw forbidden('Matricule ou code incorrect.');
    }
    const r = await tx((c) => clock(c, actorOf(req), e.id, b.action, 'terminal'));
    return { ...r, name: `${e.first_name} ${e.last_name}` };
  });
  // corrections
  app.get('/api/hr/attendance/corrections', { preHandler: needAny(...HR_ANY) }, async (req) => {
    const sc = await scope(req);
    const sq = scopeSql(sc, 'e', 2);
    return q(getPool(), `SELECT c.*, e.matricule, e.first_name, e.last_name, u.full_name AS requester, d.full_name AS decider FROM hr_attendance_corrections c JOIN employees e ON e.id = c.employee_id
        LEFT JOIN users u ON u.id = c.requested_by LEFT JOIN users d ON d.id = c.decided_by WHERE c.hotel_id = $1 AND ${sq.sql} ORDER BY (c.status = 'pending') DESC, c.created_at DESC LIMIT 200`, [req.user!.hotelId, ...sq.params]);
  });
  app.post('/api/hr/attendance/corrections', { preHandler: needAny(...HR_ANY) }, async (req, rep) => {
    const b = z.object({ employee_id: z.number().int().positive().optional(), work_date: zDate, clock_in: z.string().datetime({ offset: true }).nullish(), clock_out: z.string().datetime({ offset: true }).nullish(),
      break_minutes: z.number().int().min(0).max(600).nullish(), reason: z.string().trim().min(5).max(500) }).parse(req.body);
    const sc = await scope(req);
    const id = b.employee_id ?? sc.employeeId;
    if (!id) throw conflict('Compte non lié à une fiche employé.');
    if (id !== sc.employeeId) await teamGuard(req, id);
    if (!b.clock_in && !b.clock_out && b.break_minutes == null) throw badRequest('Indiquez au moins une valeur corrigée.');
    const r = await tx((c) => requestCorrection(c, actorOf(req), req.user!.perms, { ...b, employee_id: id }));
    rep.code(201);
    return r;
  });
  app.post('/api/hr/attendance/corrections/:id/decide', { preHandler: requirePerm('hr.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ approve: z.boolean(), note: s(300) }).parse(req.body);
    return tx((c) => decideCorrection(c, actorOf(req), id, b.approve, b.note ?? null));
  });

  // ===================================================== Congés =====================================================
  app.get('/api/hr/leaves', { preHandler: needAny(...HR_ANY) }, async (req) => {
    const f = z.object({ status: z.string().optional(), employee_id: z.coerce.number().int().optional(), mine: z.coerce.boolean().optional() }).parse(req.query);
    const sc = await scope(req);
    const self = f.mine || !STAFF.some((p) => req.user!.perms.has(p));
    const sq = self ? { sql: 'e.id = $2', params: [sc.employeeId ?? -1] } : scopeSql(sc, 'e', 2);
    return q(getPool(), `SELECT r.*, t.name AS type_name, t.color, t.hourly, t.requires_document, e.matricule, e.first_name, e.last_name, e.department, u.full_name AS decider,
        (SELECT array_agg(p.id) FROM photos p WHERE p.owner_type = 'leave_request' AND p.owner_id = r.id) AS files
       FROM hr_leave_requests r JOIN hr_leave_types t ON t.id = r.type_id JOIN employees e ON e.id = r.employee_id LEFT JOIN users u ON u.id = r.decided_by
      WHERE r.hotel_id = $1 AND ${sq.sql} AND ($${2 + sq.params.length}::text IS NULL OR r.status = $${2 + sq.params.length}) AND ($${3 + sq.params.length}::int IS NULL OR r.employee_id = $${3 + sq.params.length})
      ORDER BY (r.status = 'pending') DESC, r.start_date DESC LIMIT 300`, [req.user!.hotelId, ...sq.params, f.status || null, f.employee_id ?? null]);
  });
  app.get('/api/hr/leaves/preview', { preHandler: needAny(...HR_ANY) }, async (req) => {
    const f = z.object({ employee_id: z.coerce.number().int().positive().optional(), start_date: zDate, end_date: zDate }).parse(req.query);
    const sc = await scope(req);
    const id = f.employee_id ?? sc.employeeId;
    if (!id) throw conflict('Compte non lié.');
    await employeeInScope(getPool(), actorOf(req), sc, id);
    return { days: f.end_date < f.start_date ? 0 : await leaveDays(getPool(), req.user!.hotelId, id, f.start_date, f.end_date), balance: await leaveBalance(getPool(), req.user!.hotelId, id) };
  });
  app.post('/api/hr/leaves', { preHandler: needAny(...HR_ANY) }, async (req, rep) => {
    const b = z.object({ employee_id: z.number().int().positive().optional(), type_id: z.number().int().positive().optional(), type_code: z.string().optional(), start_date: zDate, end_date: zDate,
      start_time: Time.nullish(), end_time: Time.nullish(), reason: s(500), force: z.boolean().optional(), approve: z.boolean().optional() }).parse(req.body);
    const sc = await scope(req);
    const id = b.employee_id ?? sc.employeeId;
    if (!id) throw conflict('Votre compte n\'est lié à aucune fiche employé.');
    const p = req.user!.perms;
    if (id !== sc.employeeId) await teamGuard(req, id);
    else if (!p.has('hr.self') && !p.has('hr.manage')) throw forbidden();
    if (b.approve && !(p.has('hr.manage') || (p.has('hr.team') && id !== sc.employeeId))) throw forbidden('Validation directe réservée au responsable.');
    const r = await tx((c) => requestLeave(c, actorOf(req), p, { ...b, employee_id: id }, sc));
    rep.code(201);
    return r;
  });
  app.post('/api/hr/leaves/:id/decide', { preHandler: needAny('hr.manage', 'hr.team') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ approve: z.boolean(), note: s(500) }).parse(req.body);
    const sc = await scope(req);
    return tx((c) => decideLeave(c, actorOf(req), req.user!.perms, sc, id, b.approve, b.note ?? null));
  });
  app.post('/api/hr/leaves/:id/cancel', { preHandler: needAny(...HR_ANY) }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: s(300) }).parse(req.body ?? {});
    const sc = await scope(req);
    return tx(async (c) => {
      const r = await one<any>(c, 'SELECT * FROM hr_leave_requests WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!r) throw notFound('Demande introuvable');
      const own = r.employee_id === sc.employeeId;
      if (r.status === 'pending' && !own) await teamGuard(req, r.employee_id);
      if (r.status === 'approved') {
        if (!req.user!.perms.has('hr.manage')) throw forbidden('Annulation d\'un congé validé réservée aux RH.');
        if (String(r.start_date).slice(0, 10) <= today()) throw conflict('Congé déjà commencé : enregistrez une reprise anticipée par un ajustement.');
        if (!b.reason?.trim()) throw badRequest('Motif obligatoire.');
      } else if (r.status !== 'pending') throw conflict('Demande déjà traitée.');
      await c.query(`UPDATE hr_leave_requests SET status = 'cancelled', decision_note = COALESCE($2, decision_note), decided_by = $3, decided_at = now() WHERE id = $1`, [id, b.reason ?? null, req.user!.id]);
      await audit(c, actorOf(req), 'leave_cancelled', 'employee', r.employee_id, { status: r.status }, { number: r.number, reason: b.reason ?? null });
      return { ok: true };
    });
  });

  // ===================================================== Espace personnel =====================================================
  app.get('/api/hr/me', { preHandler: requirePerm('hr.self') }, async (req) => {
    const sc = await scope(req);
    if (!sc.employeeId) return { linked: false };
    const id = sc.employeeId;
    const e = await one<any>(getPool(), `SELECT e.*, ${EFFECTIVE_STATUS('e')} AS effective_status, COALESCE((SELECT name FROM hr_departments d WHERE d.hotel_id = e.hotel_id AND d.code = e.department), e.department) AS department_name FROM employees e WHERE e.id = $1`, [id]);
    return {
      linked: true, employee: redact(e, sc),
      today: await one(getPool(), 'SELECT * FROM hr_attendance WHERE employee_id = $1 AND (work_date = $2 OR (clock_out IS NULL AND clock_in > now() - interval \'20 hours\')) ORDER BY work_date DESC LIMIT 1', [id, today()]),
      schedule: await q(getPool(), `SELECT sh.*, st.code, st.name AS shift_name, st.color FROM hr_schedule sh LEFT JOIN hr_shift_types st ON st.id = sh.shift_type_id WHERE sh.employee_id = $1 AND sh.work_date BETWEEN $2 AND $3 ORDER BY sh.work_date`, [id, today(), addDays(today(), 13)]),
      balance: await leaveBalance(getPool(), req.user!.hotelId, id),
      payslips: await q(getPool(), `SELECT p.id, p.number, r.period, p.net FROM hr_payslips p JOIN hr_payroll_runs r ON r.id = p.run_id WHERE p.employee_id = $1 AND r.status IN ('validated','paid') ORDER BY r.period DESC LIMIT 24`, [id]),
      colleagues: await q(getPool(), `SELECT id, first_name, last_name FROM employees WHERE hotel_id = $1 AND department = $2 AND id <> $3 AND status = 'active' ORDER BY last_name`, [req.user!.hotelId, e.department, id]),
    };
  });

  // ===================================================== Paie =====================================================
  app.get('/api/hr/pay-items', { preHandler: requirePerm('hr.salary') }, async (req) => {
    const f = z.object({ employee_id: z.coerce.number().int().optional(), period: z.string().optional() }).parse(req.query);
    return q(getPool(), `SELECT i.*, e.matricule, e.first_name, e.last_name FROM hr_pay_items i JOIN employees e ON e.id = i.employee_id WHERE i.hotel_id = $1 AND ($2::int IS NULL OR i.employee_id = $2)
        AND ($3::text IS NULL OR (NOT i.recurring AND i.period = $3) OR (i.recurring AND i.active)) ORDER BY e.last_name, i.id`, [req.user!.hotelId, f.employee_id ?? null, f.period ?? null]);
  });
  app.post('/api/hr/pay-items', { preHandler: requirePerm('hr.payroll') }, async (req, rep) => {
    const b = z.object({ employee_id: z.number().int().positive(), kind: z.enum(['bonus', 'allowance', 'deduction']), label: z.string().trim().min(2).max(80), amount: z.number().positive().max(1e9),
      taxable: z.boolean().default(true), contributory: z.boolean().default(true), recurring: z.boolean().default(false), period: Period.nullish(), start_period: Period.nullish(), end_period: Period.nullish() }).parse(req.body);
    if (!b.recurring && !b.period) throw badRequest('Mois obligatoire pour un élément ponctuel.');
    if (!(await one(getPool(), 'SELECT 1 FROM employees WHERE id = $1 AND hotel_id = $2', [b.employee_id, req.user!.hotelId]))) throw notFound('Employé introuvable');
    if (b.period && (await one(getPool(), `SELECT 1 FROM hr_payroll_runs WHERE hotel_id = $1 AND period = $2 AND status IN ('validated','paid')`, [req.user!.hotelId, b.period]))) throw conflict(`Paie ${b.period} déjà validée.`);
    const r = await one<any>(getPool(), `INSERT INTO hr_pay_items (hotel_id, employee_id, kind, label, amount, taxable, contributory, recurring, period, start_period, end_period, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
      [req.user!.hotelId, b.employee_id, b.kind, b.label, b.amount, b.taxable, b.contributory, b.recurring, b.recurring ? null : b.period, b.recurring ? b.start_period ?? null : null, b.recurring ? b.end_period ?? null : null, req.user!.id]);
    await audit(getPool(), actorOf(req), 'pay_item', 'employee', b.employee_id, null, b);
    rep.code(201);
    return r;
  });
  app.patch('/api/hr/pay-items/:id', { preHandler: requirePerm('hr.payroll') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ active: z.boolean().optional(), amount: z.number().positive().max(1e9).optional(), end_period: Period.nullish() }).parse(req.body);
    const cur = await one<any>(getPool(), 'SELECT * FROM hr_pay_items WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!cur) throw notFound('Élément introuvable');
    const r = await one(getPool(), `UPDATE hr_pay_items SET active = COALESCE($2, active), amount = COALESCE($3, amount), end_period = CASE WHEN $4::boolean THEN $5 ELSE end_period END WHERE id = $1 RETURNING *`,
      [id, b.active ?? null, b.amount ?? null, b.end_period !== undefined, b.end_period ?? null]);
    await audit(getPool(), actorOf(req), 'pay_item_update', 'employee', cur.employee_id, cur, b);
    return r;
  });
  app.get('/api/hr/advances', { preHandler: requirePerm('hr.salary') }, async (req) =>
    q(getPool(), `SELECT a.*, e.matricule, e.first_name, e.last_name FROM hr_advances a JOIN employees e ON e.id = a.employee_id WHERE a.hotel_id = $1 ORDER BY (a.status = 'open') DESC, a.id DESC LIMIT 300`, [req.user!.hotelId]));
  app.post('/api/hr/advances', { preHandler: requirePerm('hr.payroll_pay') }, async (req, rep) => {
    const b = z.object({ employee_id: z.number().int().positive(), amount: z.number().positive().max(1e9), installments: z.number().int().min(1).max(24).default(1), first_period: Period, method: z.enum(['cash', 'cheque', 'transfer']).default('cash'), reason: s(300) }).parse(req.body);
    const r = await tx((c) => giveAdvance(c, actorOf(req), b));
    rep.code(201);
    return r;
  });
  app.get('/api/hr/payroll', { preHandler: requirePerm('hr.salary') }, async (req) =>
    q(getPool(), `SELECT r.*, (SELECT count(*) FROM hr_payslips p WHERE p.run_id = r.id)::int AS slips, cu.full_name AS computed_name, vu.full_name AS validated_name FROM hr_payroll_runs r
        LEFT JOIN users cu ON cu.id = r.computed_by LEFT JOIN users vu ON vu.id = r.validated_by WHERE r.hotel_id = $1 ORDER BY r.period DESC, r.id DESC`, [req.user!.hotelId]));
  app.get('/api/hr/payroll/:id', { preHandler: requirePerm('hr.salary') }, async (req) => {
    const { id } = Id.parse(req.params);
    const r = await one<any>(getPool(), 'SELECT * FROM hr_payroll_runs WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!r) throw notFound('Paie introuvable');
    return { ...r, slips: await q(getPool(), 'SELECT * FROM hr_payslips WHERE run_id = $1 ORDER BY matricule', [id]) };
  });
  app.post('/api/hr/payroll/compute', { preHandler: requirePerm('hr.payroll') }, async (req) => {
    const b = z.object({ period: Period }).parse(req.body);
    return tx((c) => computePayroll(c, actorOf(req), b.period));
  });
  app.post('/api/hr/payroll/:id/validate', { preHandler: requirePerm('hr.payroll') }, async (req) => {
    const { id } = Id.parse(req.params);
    await tx((c) => validatePayroll(c, actorOf(req), id));
    return { ok: true };
  });
  app.post('/api/hr/payroll/:id/pay', { preHandler: requirePerm('hr.payroll_pay') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ method: z.enum(['cash', 'cheque', 'transfer']), reference: s(60) }).parse(req.body);
    return tx((c) => payPayroll(c, actorOf(req), id, b.method, b.reference ?? null));
  });
  app.post('/api/hr/payroll/:id/cancel', { preHandler: requirePerm('hr.payroll') }, async (req) => {
    const { id } = Id.parse(req.params);
    return tx(async (c) => {
      const r = await one<any>(c, 'SELECT * FROM hr_payroll_runs WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!r) throw notFound('Paie introuvable');
      if (r.status !== 'draft') throw conflict('Seul un brouillon de paie peut être annulé.');
      await c.query('DELETE FROM hr_payslips WHERE run_id = $1', [id]);
      await c.query(`UPDATE hr_payroll_runs SET status = 'cancelled' WHERE id = $1`, [id]);
      await audit(c, actorOf(req), 'payroll_cancel', 'hr_payroll', id, null, { period: r.period });
      return { ok: true };
    });
  });
  app.get('/api/hr/payroll/:id/export', { preHandler: requirePerm('hr.salary') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const f = z.object({ format: z.enum(['pdf', 'xlsx', 'csv']).default('xlsx') }).parse(req.query);
    const r = await one<any>(getPool(), 'SELECT * FROM hr_payroll_runs WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!r) throw notFound('Paie introuvable');
    const slips = await q<any>(getPool(), 'SELECT * FROM hr_payslips WHERE run_id = $1 ORDER BY matricule', [id]);
    const cols = [{ key: 'matricule', label: 'Matricule' }, { key: 'full_name', label: 'Employé' }, { key: 'position', label: 'Poste' }, { key: 'base_salary', label: 'Base', money: true }, { key: 'absence_deduction', label: 'Absences', money: true },
      { key: 'overtime_amount', label: 'Heures sup.', money: true }, { key: 'gross', label: 'Brut', money: true }, { key: 'employee_contrib', label: 'Cotisations', money: true }, { key: 'tax', label: 'Impôt', money: true },
      { key: 'deductions', label: 'Retenues', money: true }, { key: 'advances', label: 'Avances', money: true }, { key: 'net', label: 'Net', money: true }, { key: 'employer_contrib', label: 'Charges patronales', money: true }];
    const tot: any = { matricule: 'Total' };
    for (const c of cols.filter((x) => x.money)) tot[c.key] = Math.round(slips.reduce((t, p) => t + Number(p[c.key]) * 100, 0)) / 100;
    await audit(getPool(), actorOf(req), 'export', 'hr_payroll', id, null, { format: f.format });
    return sendTable(rep, f.format, `paie-${r.period}`, `Journal de paie ${r.period}`, ({ draft: 'Brouillon', validated: 'Validée', paid: 'Payée' } as any)[r.status], cols, slips, tot, await hotelName(req.user!.hotelId));
  });
  app.get('/api/hr/payslips/:id/pdf', { preHandler: needAny('hr.self', 'hr.salary') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const p = await one<any>(getPool(), 'SELECT p.*, r.period, r.status, r.hotel_id FROM hr_payslips p JOIN hr_payroll_runs r ON r.id = p.run_id WHERE p.id = $1', [id]);
    if (!p || p.hotel_id !== req.user!.hotelId) throw notFound('Bulletin introuvable');
    const sc = await scope(req);
    if (!sc.salary) {
      if (p.employee_id !== sc.employeeId) throw forbidden();
      if (p.status === 'draft') throw forbidden('Bulletin pas encore validé.');
    }
    const hotel = await one<any>(getPool(), 'SELECT * FROM hotels WHERE id = $1', [req.user!.hotelId]);
    await audit(getPool(), actorOf(req), 'payslip_view', 'employee', p.employee_id, null, { payslip: p.number });
    rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${p.number}.pdf"`);
    return rep.send(await payslipPdf(hotel, { period: p.period, status: p.status }, p));
  });

  // ===================================================== Évaluations, formations, compétences =====================================================
  const evalGuard = async (req: FastifyRequest, employeeId: number) => {
    const p = req.user!.perms;
    const sc = await scope(req);
    if (!p.has('hr.manage') && !p.has('hr.team')) throw forbidden();
    const e = await employeeInScope(getPool(), actorOf(req), sc, employeeId, { team: true });
    if (e.id === sc.employeeId && !p.has('hr.manage')) throw forbidden('Vous ne pouvez pas vous évaluer vous-même.');
    return e;
  };
  const EvalBody = z.object({ employee_id: z.number().int().positive(), period: z.string().trim().min(4).max(30), eval_date: zDate.optional(), criteria: z.array(z.object({ label: z.string().trim().min(2).max(80), score: z.number().int().min(1).max(5) })).max(20).default([]),
    objectives: z.array(z.object({ label: z.string().trim().min(2).max(200), due: zDate.nullish(), status: z.enum(['todo', 'in_progress', 'done', 'missed']).default('todo') })).max(20).default([]),
    strengths: s(2000), improvements: s(2000), manager_comment: s(2000), status: z.enum(['draft', 'final']).default('draft') });
  const avgScore = (c: { score: number }[]) => (c.length ? Math.round((c.reduce((a, x) => a + x.score, 0) / c.length) * 100) / 100 : null);
  app.post('/api/hr/evaluations', { preHandler: needAny('hr.manage', 'hr.team') }, async (req, rep) => {
    const b = EvalBody.parse(req.body);
    await evalGuard(req, b.employee_id);
    if (b.status === 'final' && !b.criteria.length) throw badRequest('Notez au moins un critère avant de finaliser.');
    const r = await one<any>(getPool(), `INSERT INTO hr_evaluations (hotel_id, employee_id, period, eval_date, evaluator_id, criteria, score, objectives, strengths, improvements, manager_comment, status) VALUES ($1,$2,$3,COALESCE($4, CURRENT_DATE),$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
      [req.user!.hotelId, b.employee_id, b.period, b.eval_date ?? null, req.user!.id, JSON.stringify(b.criteria), avgScore(b.criteria), JSON.stringify(b.objectives), b.strengths ?? null, b.improvements ?? null, b.manager_comment ?? null, b.status]);
    await audit(getPool(), actorOf(req), 'evaluation', 'employee', b.employee_id, null, { period: b.period, score: r.score, status: b.status });
    rep.code(201);
    return r;
  });
  app.patch('/api/hr/evaluations/:id', { preHandler: needAny(...HR_ANY) }, async (req) => {
    const { id } = Id.parse(req.params);
    const cur = await one<any>(getPool(), 'SELECT * FROM hr_evaluations WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!cur) throw notFound('Évaluation introuvable');
    const sc = await scope(req);
    // l'employé ajoute seulement son commentaire, sur une évaluation finalisée
    if (cur.employee_id === sc.employeeId && !req.user!.perms.has('hr.manage')) {
      const b = z.object({ employee_comment: z.string().trim().min(1).max(2000) }).parse(req.body);
      if (cur.status !== 'final') throw conflict('Évaluation pas encore finalisée.');
      await getPool().query('UPDATE hr_evaluations SET employee_comment = $2 WHERE id = $1', [id, b.employee_comment]);
      return { ok: true };
    }
    await evalGuard(req, cur.employee_id);
    if (cur.status === 'final') throw conflict('Évaluation finalisée : non modifiable.');
    const b = EvalBody.omit({ employee_id: true }).partial().parse(req.body);
    const crit = b.criteria ?? cur.criteria;
    if (b.status === 'final' && !crit.length) throw badRequest('Notez au moins un critère avant de finaliser.');
    await getPool().query(`UPDATE hr_evaluations SET period = COALESCE($2, period), criteria = $3, score = $4, objectives = COALESCE($5, objectives), strengths = COALESCE($6, strengths), improvements = COALESCE($7, improvements),
        manager_comment = COALESCE($8, manager_comment), status = COALESCE($9, status) WHERE id = $1`,
    [id, b.period ?? null, JSON.stringify(crit), avgScore(crit), b.objectives ? JSON.stringify(b.objectives) : null, b.strengths ?? null, b.improvements ?? null, b.manager_comment ?? null, b.status ?? null]);
    await audit(getPool(), actorOf(req), 'evaluation_update', 'employee', cur.employee_id, { status: cur.status }, { status: b.status ?? cur.status });
    return { ok: true };
  });
  app.post('/api/hr/trainings', { preHandler: needAny('hr.manage', 'hr.team') }, async (req, rep) => {
    const b = z.object({ employee_id: z.number().int().positive(), title: z.string().trim().min(2).max(160), provider: s(120), start_date: zDate.nullish(), end_date: zDate.nullish(), hours: z.number().min(0).max(2000).nullish(),
      cost: Money.nullish(), status: z.enum(['planned', 'in_progress', 'done', 'cancelled']).default('planned'), certificate_expiry: zDate.nullish(), notes: s(1000) }).parse(req.body);
    await teamGuard(req, b.employee_id);
    if (b.start_date && b.end_date && b.end_date < b.start_date) throw badRequest('Période invalide.');
    rep.code(201);
    return one(getPool(), `INSERT INTO hr_trainings (hotel_id, employee_id, title, provider, start_date, end_date, hours, cost, status, certificate_expiry, notes, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
      [req.user!.hotelId, b.employee_id, b.title, b.provider ?? null, b.start_date ?? null, b.end_date ?? null, b.hours ?? null, b.cost ?? null, b.status, b.certificate_expiry ?? null, b.notes ?? null, req.user!.id]);
  });
  app.patch('/api/hr/trainings/:id', { preHandler: needAny('hr.manage', 'hr.team') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ status: z.enum(['planned', 'in_progress', 'done', 'cancelled']).optional(), certificate_expiry: zDate.nullish(), hours: z.number().min(0).max(2000).nullish() }).parse(req.body);
    const cur = await one<any>(getPool(), 'SELECT * FROM hr_trainings WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!cur) throw notFound('Formation introuvable');
    await teamGuard(req, cur.employee_id);
    return one(getPool(), `UPDATE hr_trainings SET status = COALESCE($2, status), certificate_expiry = CASE WHEN $3::boolean THEN $4 ELSE certificate_expiry END, hours = COALESCE($5, hours) WHERE id = $1 RETURNING *`,
      [id, b.status ?? null, b.certificate_expiry !== undefined, b.certificate_expiry ?? null, b.hours ?? null]);
  });
  app.put('/api/hr/employees/:id/skills', { preHandler: needAny('hr.manage', 'hr.team') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ skills: z.array(z.object({ skill: z.string().trim().min(2).max(60), level: z.number().int().min(1).max(5) })).max(40) }).parse(req.body);
    await teamGuard(req, id);
    return tx(async (c) => {
      await c.query('DELETE FROM hr_skills WHERE employee_id = $1', [id]);
      for (const x of b.skills) await c.query('INSERT INTO hr_skills (employee_id, skill, level) VALUES ($1,$2,$3) ON CONFLICT (employee_id, skill) DO UPDATE SET level = EXCLUDED.level, updated_at = now()', [id, x.skill, x.level]);
      await audit(c, actorOf(req), 'skills', 'employee', id, null, { count: b.skills.length });
      return q(c, 'SELECT * FROM hr_skills WHERE employee_id = $1 ORDER BY level DESC, skill', [id]);
    });
  });

  // ===================================================== Documents =====================================================
  app.get('/api/hr/documents', { preHandler: needAny(...STAFF) }, async (req) => {
    const f = z.object({ expiring: z.coerce.number().int().optional() }).parse(req.query);
    const sc = await scope(req);
    const sq = scopeSql(sc, 'e', 3);
    return q(getPool(), `SELECT d.*, e.matricule, e.first_name, e.last_name, (SELECT array_agg(p.id) FROM photos p WHERE p.owner_type = 'hr_document' AND p.owner_id = d.id) AS files
        FROM hr_documents d JOIN employees e ON e.id = d.employee_id WHERE d.hotel_id = $1 AND ($2::boolean OR NOT d.confidential) AND ${sq.sql}
          AND ($${3 + sq.params.length}::int IS NULL OR (d.expiry_date IS NOT NULL AND d.expiry_date <= CURRENT_DATE + $${3 + sq.params.length})) ORDER BY d.expiry_date NULLS LAST, e.last_name`,
    [req.user!.hotelId, req.user!.perms.has('hr.manage'), ...sq.params, f.expiring ?? null]);
  });
  app.post('/api/hr/documents', { preHandler: requirePerm('hr.manage') }, async (req, rep) => {
    const b = z.object({ employee_id: z.number().int().positive(), kind: z.string().trim().min(2).max(60), title: z.string().trim().min(2).max(160), issue_date: zDate.nullish(), expiry_date: zDate.nullish(), confidential: z.boolean().default(true) }).parse(req.body);
    if (!(await one(getPool(), 'SELECT 1 FROM employees WHERE id = $1 AND hotel_id = $2', [b.employee_id, req.user!.hotelId]))) throw notFound('Employé introuvable');
    if (b.issue_date && b.expiry_date && b.expiry_date < b.issue_date) throw badRequest('Expiration avant la date d\'émission.');
    const r = await one<any>(getPool(), `INSERT INTO hr_documents (hotel_id, employee_id, kind, title, issue_date, expiry_date, confidential, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [req.user!.hotelId, b.employee_id, b.kind, b.title, b.issue_date ?? null, b.expiry_date ?? null, b.confidential, req.user!.id]);
    await audit(getPool(), actorOf(req), 'document', 'employee', b.employee_id, null, { title: b.title, kind: b.kind, expiry: b.expiry_date ?? null });
    rep.code(201);
    return r;
  });
  app.patch('/api/hr/documents/:id', { preHandler: requirePerm('hr.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ expiry_date: zDate.nullish(), confidential: z.boolean().optional(), title: z.string().trim().min(2).max(160).optional() }).parse(req.body);
    const r = await one<any>(getPool(), `UPDATE hr_documents SET expiry_date = CASE WHEN $3::boolean THEN $4 ELSE expiry_date END, confidential = COALESCE($5, confidential), title = COALESCE($6, title) WHERE id = $1 AND hotel_id = $2 RETURNING *`,
      [id, req.user!.hotelId, b.expiry_date !== undefined, b.expiry_date ?? null, b.confidential ?? null, b.title ?? null]);
    if (!r) throw notFound('Document introuvable');
    await audit(getPool(), actorOf(req), 'document_update', 'employee', r.employee_id, null, b);
    return r;
  });

  // ===================================================== Rapports, paramètres =====================================================
  app.get('/api/hr/reports/:kind', { preHandler: requirePerm('hr.reports') }, async (req, rep) => {
    const { kind } = z.object({ kind: z.string() }).parse(req.params);
    const f = z.object({ from: zDate.optional(), to: zDate.optional(), format: z.enum(['json', 'pdf', 'xlsx', 'csv']).default('json') }).parse(req.query);
    if (!HR_REPORTS[kind]) throw notFound('Rapport inconnu');
    const from = f.from ?? monthStart(today()), to = f.to ?? today();
    if (to < from) throw badRequest('Période invalide.');
    const r = await hrReport(getPool(), req.user!.hotelId, await scope(req), kind, from, to);
    if (f.format === 'json') return r;
    await audit(getPool(), actorOf(req), 'export', 'hr_report', null, null, { kind, from, to, format: f.format });
    return sendTable(rep, f.format, `rh-${kind}-${from}_${to}`, r.title, `Du ${from} au ${to}`, r.columns, r.rows, r.total, await hotelName(req.user!.hotelId));
  });
  app.get('/api/hr/settings', { preHandler: needAny('hr.manage', 'hr.payroll') }, async (req) => (await getSettings(getPool(), req.user!.hotelId)).hr);
  app.put('/api/hr/settings', { preHandler: needAny('hr.manage', 'hr.payroll') }, async (req) => {
    const b = z.object({
      late_tolerance_minutes: z.number().int().min(0).max(120), overtime_threshold_minutes: z.number().int().min(0).max(240), min_rest_hours: z.number().min(0).max(24), weekly_rest_days: z.array(z.number().int().min(0).max(6)).max(6),
      leave_days_per_month: z.number().min(0).max(5), leave_year_start_month: z.number().int().min(1).max(12), monthly_hours: z.number().min(1).max(400), day_divisor: z.number().min(1).max(31), overtime_rate_percent: z.number().min(0).max(300),
      contributions: z.array(z.object({ code: z.string().trim().min(1).max(12), label: z.string().trim().min(2).max(60), rate: z.number().min(0).max(100), side: z.enum(['employee', 'employer']) })).max(20),
      tax_brackets: z.array(z.object({ from: z.number().min(0), to: z.number().min(0).nullable(), rate: z.number().min(0).max(100) })).max(20),
      contract_alert_days: z.number().int().min(0).max(365), document_alert_days: z.number().int().min(0).max(365), payroll_category: z.string().trim().min(2).max(60), advance_category: z.string().trim().min(2).max(60),
    }).parse(req.body);
    const sorted = [...b.tax_brackets].sort((x, y) => x.from - y.from);
    for (let i = 0; i < sorted.length; i++) {
      if (sorted[i].to !== null && sorted[i].to! <= sorted[i].from) throw badRequest('Tranche d\'impôt invalide (fin ≤ début).');
      if (i && (sorted[i - 1].to === null || sorted[i - 1].to! > sorted[i].from)) throw badRequest('Tranches d\'impôt qui se chevauchent.');
    }
    const cur = (await getSettings(getPool(), req.user!.hotelId)).hr;
    // les règles de paie relèvent de la paie ; les règles de temps de travail des RH
    const payKeys = ['monthly_hours', 'day_divisor', 'overtime_rate_percent', 'contributions', 'tax_brackets', 'payroll_category', 'advance_category'];
    const p = req.user!.perms;
    const next: any = { ...cur };
    for (const [k, v] of Object.entries({ ...b, tax_brackets: sorted })) {
      if (JSON.stringify(cur[k]) === JSON.stringify(v)) continue;
      if (payKeys.includes(k) ? !p.has('hr.payroll') : !p.has('hr.manage')) throw forbidden(`Paramètre « ${k} » : droit insuffisant.`);
      next[k] = v;
    }
    await getPool().query(`INSERT INTO settings (hotel_id, key, value) VALUES ($1,'hr',$2) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value`, [req.user!.hotelId, JSON.stringify(next)]);
    await audit(getPool(), actorOf(req), 'update', 'settings', 'hr', cur, next);
    return next;
  });
  void hrSettings;
}
