import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { getPool, one, q, tx } from '../db/pool.js';
import { audit } from '../lib/audit.js';
import { actorOf, requireAuth, requirePerm } from '../lib/auth.js';
import { isDate, monthStart, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { getSettings } from '../services/common.js';
import { tableCsv, tablePdf, tableXlsx } from '../services/exports.js';
import {
  addExternal, addPart, addTime, assignTicket, cancelWorkOrder, completeWorkOrder, createWorkOrder, declareFault, DEPT_LABEL, EQ_CATEGORY, generatePreventive, MAINT_REPORTS, maintAlerts,
  maintDashboard, maintReport, myTechnician, OPEN_TICKET_SQL, PRIO_LABEL, TICKET_STATUS, ticketStatus, toggleChecklist, updateWorkOrder, validateWorkOrder, warrantyUntil, woAction, woComment, WO_STATUS,
} from '../services/maintenance.js';

const Id = z.object({ id: z.coerce.number().int().positive() });
const zDate = z.string().refine(isDate, 'Date invalide (AAAA-MM-JJ)');
const s = (n = 500) => z.string().trim().max(n).nullish();
const Prio = z.enum(['low', 'normal', 'high', 'urgent']);
const Cat = z.enum(['hvac', 'heating', 'plumbing', 'electrical', 'elevator', 'kitchen', 'furniture', 'it', 'fire_safety', 'other']);
const LocType = z.enum(['room', 'floor', 'kitchen', 'restaurant', 'reception', 'pool', 'laundry', 'technical', 'public', 'outdoor', 'other']);
const Dept = z.enum(['rooms', 'restaurant', 'reception', 'housekeeping', 'technical', 'leisure', 'admin', 'other']);
const needAny = (...ps: string[]) => async (req: FastifyRequest) => {
  await requireAuth(req, null as any);
  if (!ps.some((p) => req.user!.perms.has(p))) throw forbidden(`Permission requise : ${ps.join(' ou ')}`);
};
const VIEW = ['maintenance.view', 'maintenance.supervise', 'maintenance.work'];
const REPORT = ['maintenance.report', 'maintenance.manage', 'maintenance.supervise'];
const hotelName = async (id: number) => (await one<any>(getPool(), 'SELECT name FROM hotels WHERE id = $1', [id]))?.name ?? 'Hôtel';
async function sendTable(rep: FastifyReply, format: string, name: string, title: string, sub: string, cols: any[], rows: any[], total: any, hotel: string) {
  if (format === 'xlsx') {
    rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('content-disposition', `attachment; filename="${name}.xlsx"`);
    return rep.send(await tableXlsx(title, sub, cols, rows, total));
  }
  if (format === 'csv') {
    rep.header('content-type', 'text/csv; charset=utf-8').header('content-disposition', `attachment; filename="${name}.csv"`);
    return rep.send(tableCsv(cols, rows, total));
  }
  rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${name}.pdf"`);
  return rep.send(await tablePdf(hotel, title, sub, cols, rows, total));
}

const TICKET_SELECT = `SELECT m.*, r.number AS room, e.name AS equipment, e.code AS equipment_code, u.full_name AS reporter, t.name AS technician,
    (SELECT array_agg(p.id ORDER BY p.id) FROM photos p WHERE p.owner_type = 'ticket' AND p.owner_id = m.id) AS photos,
    (SELECT json_build_object('id', b.id, 'start', b.start_date, 'end', b.end_date) FROM room_blocks b WHERE b.ticket_id = m.id AND b.status = 'active' LIMIT 1) AS block,
    (SELECT json_build_object('id', w.id, 'number', w.number, 'status', w.status) FROM work_orders w WHERE w.ticket_id = m.id AND w.status <> 'cancelled' ORDER BY w.id DESC LIMIT 1) AS work_order
  FROM maintenance_tickets m LEFT JOIN rooms r ON r.id = m.room_id LEFT JOIN equipment e ON e.id = m.equipment_id LEFT JOIN users u ON u.id = m.reported_by
  LEFT JOIN maintenance_technicians t ON t.id = m.technician_id`;
const WO_SELECT = `SELECT w.*, r.number AS room, e.name AS equipment, e.code AS equipment_code, t.name AS technician, m.number AS ticket, m.status AS ticket_status, p.name AS plan, vu.full_name AS validator
  FROM work_orders w LEFT JOIN rooms r ON r.id = w.room_id LEFT JOIN equipment e ON e.id = w.equipment_id LEFT JOIN maintenance_technicians t ON t.id = w.technician_id
  LEFT JOIN maintenance_tickets m ON m.id = w.ticket_id LEFT JOIN maintenance_plans p ON p.id = w.plan_id LEFT JOIN users vu ON vu.id = w.validated_by`;

export async function maintenanceRoutes(app: FastifyInstance) {
  // ===================================================== Référentiels =====================================================
  app.get('/api/maintenance/meta', { preHandler: needAny(...VIEW, ...REPORT) }, async (req) => {
    const h = req.user!.hotelId;
    return {
      categories: EQ_CATEGORY, ticket_status: TICKET_STATUS, wo_status: WO_STATUS, priorities: PRIO_LABEL, departments: DEPT_LABEL,
      me: await myTechnician(getPool(), actorOf(req)),
      rooms: await q(getPool(), 'SELECT id, number, floor_id FROM rooms WHERE hotel_id = $1 AND active ORDER BY number', [h]),
      floors: await q(getPool(), 'SELECT id, name, number FROM floors WHERE hotel_id = $1 ORDER BY number', [h]),
      equipment: await q(getPool(), `SELECT id, code, name, category, room_id, status FROM equipment WHERE hotel_id = $1 AND active AND status <> 'retired' ORDER BY name`, [h]),
      technicians: await q(getPool(), 'SELECT id, name, specialties, available, external, hourly_rate, user_id FROM maintenance_technicians WHERE hotel_id = $1 AND active ORDER BY name', [h]),
      suppliers: await q(getPool(), 'SELECT id, name FROM suppliers WHERE hotel_id = $1 AND active ORDER BY name', [h]).catch(() => q(getPool(), 'SELECT id, name FROM suppliers WHERE hotel_id = $1 ORDER BY name', [h])),
    };
  });

  app.get('/api/maintenance/dashboard', { preHandler: needAny(...VIEW) }, async (req) => maintDashboard(getPool(), req.user!.hotelId));
  app.get('/api/maintenance/alerts', { preHandler: needAny(...VIEW) }, async (req) => maintAlerts(getPool(), req.user!.hotelId));

  // ===================================================== Équipements =====================================================
  app.get('/api/equipment', { preHandler: needAny(...VIEW, ...REPORT) }, async (req) => {
    const f = z.object({ category: Cat.optional(), status: z.string().optional(), room_id: z.coerce.number().int().optional(), q: z.string().optional(), all: z.coerce.boolean().optional() }).parse(req.query);
    const rows = await q<any>(getPool(), `SELECT e.*, r.number AS room, sp.name AS supplier,
        (SELECT count(*) FROM maintenance_tickets m WHERE m.equipment_id = e.id)::int AS faults,
        (SELECT count(*) FROM maintenance_tickets m WHERE m.equipment_id = e.id AND m.status IN ${OPEN_TICKET_SQL})::int AS open_faults,
        COALESCE((SELECT sum(total_cost) FROM work_orders w WHERE w.equipment_id = e.id AND w.status <> 'cancelled'), 0) AS cost,
        (SELECT min(next_due) FROM maintenance_plans p WHERE p.equipment_id = e.id AND p.active) AS next_preventive,
        (SELECT count(*) FROM photos p WHERE p.owner_type = 'equipment' AND p.owner_id = e.id)::int AS documents
       FROM equipment e LEFT JOIN rooms r ON r.id = e.room_id LEFT JOIN suppliers sp ON sp.id = e.supplier_id
      WHERE e.hotel_id = $1 AND ($2::text IS NULL OR e.category = $2) AND ($3::text IS NULL OR e.status = $3) AND ($4::int IS NULL OR e.room_id = $4)
        AND ($5::text IS NULL OR e.name ILIKE '%' || $5 || '%' OR e.code ILIKE '%' || $5 || '%' OR e.serial_no ILIKE '%' || $5 || '%' OR e.brand ILIKE '%' || $5 || '%')
        AND ($6::boolean OR e.status <> 'retired')
      ORDER BY e.category, e.name`, [req.user!.hotelId, f.category ?? null, f.status ?? null, f.room_id ?? null, f.q?.trim() || null, !!f.all]);
    return rows.map((e) => ({ ...e, warranty_until: warrantyUntil(e), under_warranty: !!warrantyUntil(e) && warrantyUntil(e)! >= today() }));
  });

  app.get('/api/equipment/:id', { preHandler: needAny(...VIEW) }, async (req) => {
    const { id } = Id.parse(req.params);
    const h = req.user!.hotelId;
    const e = await one<any>(getPool(), `SELECT e.*, r.number AS room, sp.name AS supplier FROM equipment e LEFT JOIN rooms r ON r.id = e.room_id LEFT JOIN suppliers sp ON sp.id = e.supplier_id WHERE e.id = $1 AND e.hotel_id = $2`, [id, h]);
    if (!e) throw notFound('Équipement introuvable');
    return {
      ...e, warranty_until: warrantyUntil(e),
      tickets: await q(getPool(), `${TICKET_SELECT} WHERE m.equipment_id = $1 ORDER BY m.created_at DESC`, [id]),
      work_orders: await q(getPool(), `${WO_SELECT} WHERE w.equipment_id = $1 ORDER BY w.created_at DESC`, [id]),
      plans: await q(getPool(), 'SELECT * FROM maintenance_plans WHERE equipment_id = $1 ORDER BY active DESC, next_due', [id]),
      documents: await q(getPool(), `SELECT id, caption, mime, created_at FROM photos WHERE owner_type = 'equipment' AND owner_id = $1 ORDER BY id`, [id]),
      history: await q(getPool(), `SELECT a.created_at, a.action, u.full_name AS user, a.after FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE a.entity = 'equipment' AND a.entity_id = $1 ORDER BY a.created_at DESC LIMIT 50`, [String(id)]).catch(() => []),
    };
  });

  const EqBody = z.object({
    code: z.string().trim().min(1).max(30), name: z.string().trim().min(2).max(120), category: Cat, brand: s(60), model: s(60), serial_no: s(80),
    location_type: LocType.default('other'), room_id: z.number().int().positive().nullish(), floor_id: z.number().int().positive().nullish(), location_detail: s(120), department: Dept.default('rooms'),
    purchase_date: zDate.nullish(), supplier_id: z.number().int().positive().nullish(), purchase_cost: z.number().min(0).max(1e10).nullish(), install_date: zDate.nullish(),
    warranty_months: z.number().int().min(0).max(240).nullish(), critical: z.boolean().optional(), notes: s(1000),
  });
  const checkEq = async (h: number, b: Partial<z.infer<typeof EqBody>>) => {
    if (b.room_id && !(await one(getPool(), 'SELECT 1 FROM rooms WHERE id = $1 AND hotel_id = $2', [b.room_id, h]))) throw badRequest('Chambre inconnue.');
    if (b.supplier_id && !(await one(getPool(), 'SELECT 1 FROM suppliers WHERE id = $1 AND hotel_id = $2', [b.supplier_id, h]))) throw badRequest('Fournisseur inconnu.');
    if (b.location_type === 'room' && !b.room_id) throw badRequest('Choisissez la chambre.');
    if (b.purchase_date && b.purchase_date > today()) throw badRequest('Date d\'achat dans le futur.');
    if (b.purchase_date && b.install_date && b.install_date < b.purchase_date) throw badRequest('Installation avant l\'achat.');
  };
  app.post('/api/equipment', { preHandler: requirePerm('equipment.manage') }, async (req, rep) => {
    const b = EqBody.parse(req.body);
    const h = req.user!.hotelId;
    await checkEq(h, b);
    if (await one(getPool(), 'SELECT 1 FROM equipment WHERE hotel_id = $1 AND upper(code) = upper($2)', [h, b.code])) throw conflict(`Référence « ${b.code} » déjà utilisée.`);
    const r = await one<any>(getPool(), `INSERT INTO equipment (hotel_id, code, name, category, brand, model, serial_no, location_type, room_id, floor_id, location_detail, department, purchase_date, supplier_id, purchase_cost, install_date, warranty_months, critical, notes)
      VALUES ($1,upper($2),$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19) RETURNING *`,
      [h, b.code, b.name, b.category, b.brand ?? null, b.model ?? null, b.serial_no ?? null, b.location_type, b.location_type === 'room' ? b.room_id : b.room_id ?? null, b.floor_id ?? null, b.location_detail ?? null, b.department,
        b.purchase_date ?? null, b.supplier_id ?? null, b.purchase_cost ?? null, b.install_date ?? null, b.warranty_months ?? null, !!b.critical, b.notes ?? null]);
    await audit(getPool(), actorOf(req), 'create', 'equipment', r.id, null, { code: r.code, name: r.name });
    rep.code(201);
    return r;
  });
  app.patch('/api/equipment/:id', { preHandler: requirePerm('equipment.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = EqBody.partial().extend({ status: z.enum(['operational', 'degraded', 'broken', 'out_of_service', 'retired']).optional(), active: z.boolean().optional() }).parse(req.body);
    const h = req.user!.hotelId;
    return tx(async (c) => {
      const cur = await one<any>(c, 'SELECT * FROM equipment WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, h]);
      if (!cur) throw notFound('Équipement introuvable');
      await checkEq(h, { ...cur, ...b });
      if (b.code && b.code.toUpperCase() !== cur.code && (await one(c, 'SELECT 1 FROM equipment WHERE hotel_id = $1 AND upper(code) = upper($2) AND id <> $3', [h, b.code, id]))) throw conflict(`Référence « ${b.code} » déjà utilisée.`);
      if (b.status === 'retired' && (await one(c, `SELECT 1 FROM maintenance_tickets WHERE equipment_id = $1 AND status IN ${OPEN_TICKET_SQL}`, [id]))) throw conflict('Pannes ouvertes sur cet équipement : clôturez-les avant de le retirer.');
      if (b.status === 'operational' && cur.status !== 'operational' && (await one(c, `SELECT 1 FROM maintenance_tickets WHERE equipment_id = $1 AND status IN ${OPEN_TICKET_SQL} AND priority IN ('high','urgent')`, [id]))) throw conflict('Panne importante en cours : l\'équipement redeviendra opérationnel à la clôture de l\'intervention.');
      const keys = Object.keys(b).filter((k) => (b as any)[k] !== undefined);
      const sets = keys.map((k, i) => `${k} = $${i + 3}`);
      const vals = keys.map((k) => (k === 'code' ? String((b as any)[k]).toUpperCase() : (b as any)[k]));
      if (b.status === 'retired') { sets.push('active = false'); }
      const r = await one<any>(c, `UPDATE equipment SET ${[...sets, 'updated_at = now()'].join(', ')} WHERE id = $1 AND hotel_id = $2 RETURNING *`, [id, h, ...vals]);
      await audit(c, actorOf(req), 'update', 'equipment', id, Object.fromEntries(keys.map((k) => [k, cur[k]])), b);
      return r;
    });
  });

  // ===================================================== Pannes =====================================================
  app.get('/api/maintenance/tickets', { preHandler: needAny(...VIEW, ...REPORT) }, async (req) => {
    const f = z.object({ status: z.string().optional(), open: z.coerce.boolean().optional(), priority: Prio.optional(), technician_id: z.coerce.number().int().optional(), equipment_id: z.coerce.number().int().optional(),
      room_id: z.coerce.number().int().optional(), mine: z.coerce.boolean().optional(), from: zDate.optional(), to: zDate.optional() }).parse(req.query);
    const perms = req.user!.perms;
    // un déclarant sans accès maintenance ne voit que ses propres pannes
    const ownOnly = !VIEW.some((p) => perms.has(p));
    let techId = f.technician_id ?? null;
    if (f.mine) techId = (await myTechnician(getPool(), actorOf(req)))?.id ?? -1;
    return q(getPool(), `${TICKET_SELECT} WHERE m.hotel_id = $1 AND ($2::text IS NULL OR m.status = ANY(string_to_array($2, ','))) AND (NOT $3::boolean OR m.status IN ${OPEN_TICKET_SQL})
        AND ($4::text IS NULL OR m.priority = $4) AND ($5::int IS NULL OR m.technician_id = $5) AND ($6::int IS NULL OR m.equipment_id = $6) AND ($7::int IS NULL OR m.room_id = $7)
        AND ($8::date IS NULL OR m.created_at >= $8::date) AND ($9::date IS NULL OR m.created_at < $9::date + 1) AND (NOT $10::boolean OR m.reported_by = $11)
      ORDER BY (m.status IN ${OPEN_TICKET_SQL}) DESC, array_position(ARRAY['urgent','high','normal','low'], m.priority), m.created_at DESC LIMIT 500`,
    [req.user!.hotelId, f.status ?? null, !!f.open, f.priority ?? null, techId, f.equipment_id ?? null, f.room_id ?? null, f.from ?? null, f.to ?? null, ownOnly, req.user!.id]);
  });
  app.get('/api/maintenance/tickets/:id', { preHandler: needAny(...VIEW, ...REPORT) }, async (req) => {
    const { id } = Id.parse(req.params);
    const t = await one<any>(getPool(), `${TICKET_SELECT} WHERE m.id = $1 AND m.hotel_id = $2`, [id, req.user!.hotelId]);
    if (!t) throw notFound('Panne introuvable');
    if (!VIEW.some((p) => req.user!.perms.has(p)) && t.reported_by !== req.user!.id) throw forbidden();
    return {
      ...t, work_orders: await q(getPool(), `${WO_SELECT} WHERE w.ticket_id = $1 ORDER BY w.id`, [id]),
      history: await q(getPool(), `SELECT a.created_at, a.action, u.full_name AS user, a.after FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE a.entity = 'maintenance_ticket' AND a.entity_id = $1 ORDER BY a.created_at`, [String(id)]).catch(() => []),
    };
  });
  app.post('/api/maintenance/tickets', { preHandler: needAny(...REPORT) }, async (req, rep) => {
    const b = z.object({
      title: z.string().trim().min(3).max(160), description: s(2000), category: Cat.nullish(), priority: Prio.default('normal'), equipment_id: z.number().int().positive().nullish(),
      room_id: z.number().int().positive().nullish(), location: s(160), technician_id: z.number().int().positive().nullish(),
      source: z.enum(['manual', 'reception', 'housekeeping', 'restaurant', 'inspection']).optional(),
      block_room: z.object({ end_date: zDate.nullish(), reason: s(300) }).nullish(),
    }).parse(req.body);
    const t = await tx((c) => declareFault(c, actorOf(req), req.user!.perms, b));
    rep.code(201);
    return t;
  });
  app.post('/api/maintenance/tickets/:id/assign', { preHandler: requirePerm('maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ technician_id: z.number().int().positive(), scheduled_at: z.string().max(30).nullish() }).parse(req.body);
    return tx((c) => assignTicket(c, actorOf(req), id, b.technician_id, { scheduled_at: b.scheduled_at ?? null }));
  });
  app.post('/api/maintenance/tickets/:id/status', { preHandler: needAny('maintenance.work', 'maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ action: z.enum(['start', 'waiting_parts', 'close', 'cancel', 'reopen']), reason: s(500) }).parse(req.body);
    await tx((c) => ticketStatus(c, actorOf(req), req.user!.perms, id, b));
    return { ok: true };
  });
  app.patch('/api/maintenance/tickets/:id', { preHandler: requirePerm('maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ priority: Prio.optional(), title: z.string().trim().min(3).max(160).optional(), description: s(2000), due_at: z.string().max(30).nullish(), equipment_id: z.number().int().positive().nullish() }).parse(req.body);
    return tx(async (c) => {
      const cur = await one<any>(c, 'SELECT * FROM maintenance_tickets WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!cur) throw notFound('Panne introuvable');
      if (b.equipment_id && !(await one(c, 'SELECT 1 FROM equipment WHERE id = $1 AND hotel_id = $2', [b.equipment_id, req.user!.hotelId]))) throw badRequest('Équipement inconnu.');
      const r = await one<any>(c, `UPDATE maintenance_tickets SET priority = COALESCE($2, priority), title = COALESCE($3, title), description = COALESCE($4, description),
          due_at = CASE WHEN $5::boolean THEN $6::timestamptz ELSE due_at END, equipment_id = CASE WHEN $7::boolean THEN $8 ELSE equipment_id END, updated_at = now() WHERE id = $1 RETURNING *`,
      [id, b.priority ?? null, b.title ?? null, b.description ?? null, b.due_at !== undefined, b.due_at ?? null, b.equipment_id !== undefined, b.equipment_id ?? null]);
      await audit(c, actorOf(req), 'update', 'maintenance_ticket', id, { priority: cur.priority, due_at: cur.due_at }, b);
      return r;
    });
  });
  // blocage de chambre depuis une panne (réactivation à la validation de la réparation)
  app.post('/api/maintenance/tickets/:id/block', { preHandler: needAny('maintenance.supervise', 'maintenance.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ start_date: zDate.optional(), end_date: zDate.nullish(), reason: s(300) }).parse(req.body);
    return tx(async (c) => {
      const t = await one<any>(c, 'SELECT * FROM maintenance_tickets WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!t) throw notFound('Panne introuvable');
      if (!t.room_id) throw badRequest('Aucune chambre liée à cette panne.');
      if (!['new', 'assigned', 'in_progress', 'waiting_parts'].includes(t.status)) throw conflict('Panne clôturée.');
      if (await one(c, `SELECT 1 FROM room_blocks WHERE ticket_id = $1 AND status = 'active'`, [id])) throw conflict('Chambre déjà bloquée pour cette panne.');
      const { createBlock } = await import('../services/rooms.js');
      const bl = await createBlock(c, actorOf(req), t.room_id, { start_date: b.start_date ?? today(), end_date: b.end_date ?? null, reason: b.reason?.trim() || `${t.number} — ${t.title}`, kind: 'out_of_service', ticket_id: id });
      await c.query('UPDATE maintenance_tickets SET puts_out_of_service = true, updated_at = now() WHERE id = $1', [id]);
      return bl;
    });
  });

  // ===================================================== Ordres de travail =====================================================
  app.get('/api/maintenance/work-orders', { preHandler: needAny(...VIEW) }, async (req) => {
    const f = z.object({ status: z.string().optional(), active: z.coerce.boolean().optional(), kind: z.string().optional(), technician_id: z.coerce.number().int().optional(), mine: z.coerce.boolean().optional(),
      equipment_id: z.coerce.number().int().optional(), from: zDate.optional(), to: zDate.optional() }).parse(req.query);
    let techId = f.technician_id ?? null;
    // le technicien sans droit de supervision ne voit que ses interventions (et celles non affectées)
    const me = await myTechnician(getPool(), actorOf(req));
    const restrict = !req.user!.perms.has('maintenance.supervise') && (me || !req.user!.perms.has('maintenance.view')) ? (me?.id ?? -1) : null;
    if (f.mine) techId = me?.id ?? -1;
    return q(getPool(), `${WO_SELECT} WHERE w.hotel_id = $1 AND ($2::text IS NULL OR w.status = ANY(string_to_array($2, ','))) AND (NOT $3::boolean OR w.status IN ('planned','in_progress','on_hold','done'))
        AND ($4::text IS NULL OR w.kind = $4) AND ($5::int IS NULL OR w.technician_id = $5) AND ($6::int IS NULL OR w.equipment_id = $6)
        AND ($7::date IS NULL OR COALESCE(w.scheduled_at, w.created_at) >= $7::date) AND ($8::date IS NULL OR COALESCE(w.scheduled_at, w.created_at) < $8::date + 1)
        AND ($9::int IS NULL OR w.technician_id = $9 OR w.technician_id IS NULL)
      ORDER BY array_position(ARRAY['in_progress','on_hold','planned','done','validated','cancelled'], w.status), array_position(ARRAY['urgent','high','normal','low'], w.priority), COALESCE(w.scheduled_at, w.created_at) LIMIT 500`,
    [req.user!.hotelId, f.status ?? null, !!f.active, f.kind ?? null, techId, f.equipment_id ?? null, f.from ?? null, f.to ?? null, restrict]);
  });
  app.get('/api/maintenance/work-orders/:id', { preHandler: needAny(...VIEW) }, async (req) => {
    const { id } = Id.parse(req.params);
    const w = await one<any>(getPool(), `${WO_SELECT} WHERE w.id = $1 AND w.hotel_id = $2`, [id, req.user!.hotelId]);
    if (!w) throw notFound('Ordre de travail introuvable');
    return {
      ...w,
      time: await q(getPool(), `SELECT l.*, t.name AS technician FROM wo_time_logs l LEFT JOIN maintenance_technicians t ON t.id = l.technician_id WHERE l.wo_id = $1 ORDER BY l.id`, [id]),
      parts: await q(getPool(), `SELECT x.*, p.name AS product, p.unit, wh.name AS warehouse FROM wo_parts x JOIN products p ON p.id = x.product_id LEFT JOIN warehouses wh ON wh.id = x.warehouse_id WHERE x.wo_id = $1 ORDER BY x.id`, [id]),
      external: await q(getPool(), `SELECT x.*, sp.name AS supplier, si.number AS invoice_number, si.status AS invoice_status FROM wo_external_costs x LEFT JOIN suppliers sp ON sp.id = x.supplier_id
          LEFT JOIN supplier_invoices si ON si.id = x.invoice_id WHERE x.wo_id = $1 ORDER BY x.id`, [id]),
      comments: await q(getPool(), `SELECT c.*, u.full_name AS user FROM wo_comments c LEFT JOIN users u ON u.id = c.created_by WHERE c.wo_id = $1 ORDER BY c.id`, [id]),
      photos: (await q<any>(getPool(), `SELECT id FROM photos WHERE owner_type = 'work_order' AND owner_id = $1 ORDER BY id`, [id])).map((p) => p.id),
      purchases: await q(getPool(), `SELECT id, number, status FROM purchase_orders WHERE hotel_id = $2 AND reason LIKE $1 || ' :%' ORDER BY id`, [w.number, req.user!.hotelId]),
    };
  });
  const WoBody = z.object({
    ticket_id: z.number().int().positive().nullish(), equipment_id: z.number().int().positive().nullish(), room_id: z.number().int().positive().nullish(),
    kind: z.enum(['corrective', 'preventive', 'inspection', 'improvement']).optional(), title: s(160), description: s(2000), priority: Prio.optional(),
    technician_id: z.number().int().positive().nullish(), scheduled_at: z.string().max(30).nullish(), due_at: z.string().max(30).nullish(), checklist: z.array(z.string().max(200)).max(40).optional(),
  });
  app.post('/api/maintenance/work-orders', { preHandler: requirePerm('maintenance.supervise') }, async (req, rep) => {
    const b = WoBody.parse(req.body);
    if (b.kind === 'preventive') throw badRequest('Les ordres préventifs sont générés depuis les plans.');
    const r = await tx((c) => createWorkOrder(c, actorOf(req), b));
    rep.code(201);
    return r;
  });
  app.patch('/api/maintenance/work-orders/:id', { preHandler: requirePerm('maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = WoBody.pick({ technician_id: true, scheduled_at: true, due_at: true, description: true, priority: true, checklist: true }).extend({ title: z.string().trim().min(2).max(160).optional() }).parse(req.body);
    await tx((c) => updateWorkOrder(c, actorOf(req), id, b as any));
    return { ok: true };
  });
  app.post('/api/maintenance/work-orders/:id/action', { preHandler: needAny('maintenance.work', 'maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ action: z.enum(['start', 'hold', 'resume']), reason: s(300), parts: z.boolean().optional() }).parse(req.body);
    await tx((c) => woAction(c, actorOf(req), req.user!.perms, id, b));
    return { ok: true };
  });
  app.post('/api/maintenance/work-orders/:id/checklist', { preHandler: needAny('maintenance.work', 'maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ index: z.number().int().min(0), done: z.boolean() }).parse(req.body);
    await tx((c) => toggleChecklist(c, actorOf(req), req.user!.perms, id, b.index, b.done));
    return { ok: true };
  });
  app.post('/api/maintenance/work-orders/:id/time', { preHandler: needAny('maintenance.work', 'maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ minutes: z.number().int().min(1).max(1440), work_date: zDate.nullish(), note: s(300), technician_id: z.number().int().positive().nullish() }).parse(req.body);
    return tx((c) => addTime(c, actorOf(req), req.user!.perms, id, b));
  });
  app.post('/api/maintenance/work-orders/:id/parts', { preHandler: needAny('maintenance.work', 'maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ product_id: z.number().int().positive(), quantity: z.number().positive().max(100000), warehouse_id: z.number().int().positive().nullish(), request_purchase: z.boolean().optional() }).parse(req.body);
    if (!req.user!.perms.has('stock.issue') && !req.user!.perms.has('maintenance.work') && !req.user!.perms.has('maintenance.supervise')) throw forbidden();
    return tx((c) => addPart(c, actorOf(req), req.user!.perms, id, b));
  });
  app.post('/api/maintenance/work-orders/:id/external', { preHandler: requirePerm('maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({
      description: z.string().trim().min(2).max(300), amount: z.number().positive().max(1e9), supplier_id: z.number().int().positive().nullish(), mode: z.enum(['paid', 'invoice']),
      method: z.enum(['cash', 'card', 'cheque', 'transfer']).optional(), reference: s(60), invoice_number: s(60), tax_total: z.number().min(0).nullish(),
    }).parse(req.body);
    if (b.mode === 'paid' && !req.user!.perms.has('expenses.create')) throw forbidden('Permission requise : expenses.create');
    if (b.mode === 'invoice' && !req.user!.perms.has('purchase.pay')) throw forbidden('Permission requise : purchase.pay');
    return tx((c) => addExternal(c, actorOf(req), req.user!.perms, id, b));
  });
  app.post('/api/maintenance/work-orders/:id/comments', { preHandler: needAny('maintenance.work', 'maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ text: z.string().trim().min(1).max(2000) }).parse(req.body);
    return tx((c) => woComment(c, actorOf(req), req.user!.perms, id, b.text));
  });
  app.post('/api/maintenance/work-orders/:id/complete', { preHandler: needAny('maintenance.work', 'maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ result: z.string().trim().min(3).max(2000), outcome: z.enum(['fixed', 'partial', 'not_fixed', 'no_issue']) }).parse(req.body);
    await tx((c) => completeWorkOrder(c, actorOf(req), req.user!.perms, id, b));
    return { ok: true };
  });
  app.post('/api/maintenance/work-orders/:id/validate', { preHandler: requirePerm('maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ rating: z.number().int().min(1).max(5).nullish(), comment: s(500), close_ticket: z.boolean().optional() }).parse(req.body);
    await tx((c) => validateWorkOrder(c, actorOf(req), id, b));
    return { ok: true };
  });
  app.post('/api/maintenance/work-orders/:id/cancel', { preHandler: requirePerm('maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(3).max(300) }).parse(req.body);
    await tx((c) => cancelWorkOrder(c, actorOf(req), id, b.reason));
    return { ok: true };
  });

  // ===================================================== Préventif =====================================================
  app.get('/api/maintenance/plans', { preHandler: needAny(...VIEW) }, async (req) =>
    q(getPool(), `SELECT p.*, e.name AS equipment, e.code AS equipment_code, t.name AS technician,
        (SELECT count(*) FROM work_orders w WHERE w.plan_id = p.id AND w.status = 'validated')::int AS done_count,
        (SELECT json_build_object('id', w.id, 'number', w.number, 'status', w.status) FROM work_orders w WHERE w.plan_id = p.id AND w.plan_due = p.next_due AND w.status <> 'cancelled' LIMIT 1) AS current_wo
       FROM maintenance_plans p LEFT JOIN equipment e ON e.id = p.equipment_id LEFT JOIN maintenance_technicians t ON t.id = p.technician_id
      WHERE p.hotel_id = $1 ORDER BY p.active DESC, p.next_due`, [req.user!.hotelId]));
  const PlanBody = z.object({
    name: z.string().trim().min(3).max(160), equipment_id: z.number().int().positive().nullish(), frequency: z.enum(['daily', 'weekly', 'monthly', 'quarterly', 'yearly']),
    interval_count: z.number().int().min(1).max(52).default(1), next_due: zDate, alert_days: z.number().int().min(0).max(90).default(3), technician_id: z.number().int().positive().nullish(),
    estimated_minutes: z.number().int().min(1).max(10000).default(30), checklist: z.array(z.string().trim().min(1).max(200)).max(40).default([]), instructions: s(2000), active: z.boolean().optional(),
  });
  const checkPlan = async (h: number, b: Partial<z.infer<typeof PlanBody>>) => {
    if (b.equipment_id && !(await one(getPool(), 'SELECT 1 FROM equipment WHERE id = $1 AND hotel_id = $2', [b.equipment_id, h]))) throw badRequest('Équipement inconnu.');
    if (b.technician_id && !(await one(getPool(), 'SELECT 1 FROM maintenance_technicians WHERE id = $1 AND hotel_id = $2', [b.technician_id, h]))) throw badRequest('Technicien inconnu.');
  };
  app.post('/api/maintenance/plans', { preHandler: requirePerm('maintenance.supervise') }, async (req, rep) => {
    const b = PlanBody.parse(req.body);
    await checkPlan(req.user!.hotelId, b);
    const r = await one<any>(getPool(), `INSERT INTO maintenance_plans (hotel_id, name, equipment_id, frequency, interval_count, next_due, alert_days, technician_id, estimated_minutes, checklist, instructions, created_by)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
    [req.user!.hotelId, b.name, b.equipment_id ?? null, b.frequency, b.interval_count, b.next_due, b.alert_days, b.technician_id ?? null, b.estimated_minutes, JSON.stringify(b.checklist), b.instructions ?? null, req.user!.id]);
    await audit(getPool(), actorOf(req), 'create', 'maintenance_plan', r.id, null, { name: b.name, frequency: b.frequency, next_due: b.next_due });
    rep.code(201);
    return r;
  });
  app.patch('/api/maintenance/plans/:id', { preHandler: requirePerm('maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = PlanBody.partial().parse(req.body);
    await checkPlan(req.user!.hotelId, b);
    const cur = await one<any>(getPool(), 'SELECT * FROM maintenance_plans WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!cur) throw notFound('Plan introuvable');
    const keys = Object.keys(b).filter((k) => (b as any)[k] !== undefined);
    if (!keys.length) return cur;
    const vals = keys.map((k) => (k === 'checklist' ? JSON.stringify((b as any)[k]) : (b as any)[k]));
    const r = await one<any>(getPool(), `UPDATE maintenance_plans SET ${keys.map((k, i) => `${k} = $${i + 3}`).join(', ')} WHERE id = $1 AND hotel_id = $2 RETURNING *`, [id, req.user!.hotelId, ...vals]);
    await audit(getPool(), actorOf(req), 'update', 'maintenance_plan', id, Object.fromEntries(keys.map((k) => [k, cur[k]])), b);
    return r;
  });
  app.post('/api/maintenance/plans/generate', { preHandler: requirePerm('maintenance.supervise') }, async (req) => tx((c) => generatePreventive(c, actorOf(req))));

  // ===================================================== Techniciens =====================================================
  app.get('/api/maintenance/technicians', { preHandler: needAny(...VIEW) }, async (req) =>
    q(getPool(), `SELECT t.*, u.username, sp.name AS supplier,
        (SELECT count(*) FROM work_orders w WHERE w.technician_id = t.id AND w.status IN ('planned','in_progress','on_hold'))::int AS open_orders,
        (SELECT count(*) FROM work_orders w WHERE w.technician_id = t.id AND w.status IN ('planned','in_progress','on_hold') AND w.priority IN ('high','urgent'))::int AS urgent_orders,
        (SELECT count(*) FROM work_orders w WHERE w.technician_id = t.id AND w.status = 'validated' AND w.validated_at >= date_trunc('month', now()))::int AS done_month,
        COALESCE((SELECT sum(minutes) FROM wo_time_logs l WHERE l.technician_id = t.id AND l.work_date >= $2), 0)::int AS minutes_month,
        (SELECT round(avg(rating)::numeric, 1) FROM work_orders w WHERE w.technician_id = t.id AND w.rating IS NOT NULL) AS rating
       FROM maintenance_technicians t LEFT JOIN users u ON u.id = t.user_id LEFT JOIN suppliers sp ON sp.id = t.supplier_id
      WHERE t.hotel_id = $1 ORDER BY t.active DESC, t.name`, [req.user!.hotelId, monthStart(today())]));
  const TechBody = z.object({
    name: z.string().trim().min(2).max(80), user_id: z.number().int().positive().nullish(), phone: s(30), specialties: z.array(Cat).max(10).default([]), hourly_rate: z.number().min(0).max(1e6).default(0),
    external: z.boolean().default(false), supplier_id: z.number().int().positive().nullish(), notes: s(500),
  });
  const checkTech = async (h: number, b: Partial<z.infer<typeof TechBody>>, id: number | null) => {
    if (b.user_id) {
      if (!(await one(getPool(), 'SELECT 1 FROM users WHERE id = $1 AND hotel_id = $2', [b.user_id, h]))) throw badRequest('Utilisateur inconnu.');
      if (await one(getPool(), 'SELECT 1 FROM maintenance_technicians WHERE user_id = $1 AND id <> COALESCE($2, 0)', [b.user_id, id])) throw conflict('Cet utilisateur est déjà lié à un technicien.');
    }
    if (b.supplier_id && !(await one(getPool(), 'SELECT 1 FROM suppliers WHERE id = $1 AND hotel_id = $2', [b.supplier_id, h]))) throw badRequest('Fournisseur inconnu.');
  };
  app.post('/api/maintenance/technicians', { preHandler: requirePerm('equipment.manage') }, async (req, rep) => {
    const b = TechBody.parse(req.body);
    await checkTech(req.user!.hotelId, b, null);
    const r = await one<any>(getPool(), `INSERT INTO maintenance_technicians (hotel_id, user_id, name, phone, specialties, hourly_rate, external, supplier_id, notes) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [req.user!.hotelId, b.user_id ?? null, b.name, b.phone ?? null, b.specialties, b.hourly_rate, b.external, b.supplier_id ?? null, b.notes ?? null]);
    await audit(getPool(), actorOf(req), 'create', 'maintenance_technician', r.id, null, { name: b.name });
    rep.code(201);
    return r;
  });
  app.patch('/api/maintenance/technicians/:id', { preHandler: needAny('equipment.manage', 'maintenance.supervise') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = TechBody.partial().extend({ available: z.boolean().optional(), unavailable_reason: s(200), unavailable_until: zDate.nullish(), active: z.boolean().optional() }).parse(req.body);
    // le responsable maintenance gère la disponibilité ; la fiche (taux, lien utilisateur) relève de equipment.manage
    const onlyAvail = Object.keys(b).every((k) => ['available', 'unavailable_reason', 'unavailable_until'].includes(k));
    if (!onlyAvail && !req.user!.perms.has('equipment.manage')) throw forbidden('Permission requise : equipment.manage');
    await checkTech(req.user!.hotelId, b, id);
    const cur = await one<any>(getPool(), 'SELECT * FROM maintenance_technicians WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!cur) throw notFound('Technicien introuvable');
    if (b.available === false && !b.unavailable_reason?.trim()) throw badRequest('Motif d\'indisponibilité obligatoire.');
    if (b.available === true) { b.unavailable_reason = null; b.unavailable_until = null; }
    const keys = Object.keys(b).filter((k) => (b as any)[k] !== undefined);
    if (!keys.length) return cur;
    const r = await one<any>(getPool(), `UPDATE maintenance_technicians SET ${keys.map((k, i) => `${k} = $${i + 3}`).join(', ')} WHERE id = $1 AND hotel_id = $2 RETURNING *`, [id, req.user!.hotelId, ...keys.map((k) => (b as any)[k])]);
    await audit(getPool(), actorOf(req), 'update', 'maintenance_technician', id, Object.fromEntries(keys.map((k) => [k, cur[k]])), b);
    return r;
  });
  app.get('/api/maintenance/users', { preHandler: requirePerm('equipment.manage') }, async (req) =>
    q(getPool(), `SELECT u.id, u.full_name, u.username FROM users u WHERE u.hotel_id = $1 AND u.active ORDER BY u.full_name`, [req.user!.hotelId]).catch(() => q(getPool(), `SELECT id, full_name, username FROM users WHERE hotel_id = $1 ORDER BY full_name`, [req.user!.hotelId])));

  // ===================================================== Pièces détachées =====================================================
  app.get('/api/maintenance/parts', { preHandler: needAny(...VIEW) }, async (req) =>
    q(getPool(), `SELECT p.id, p.name, p.category, p.unit, p.min_stock, p.avg_cost, p.cost_price, COALESCE((SELECT sum(qty) FROM stock_levels sl WHERE sl.product_id = p.id), 0) AS qty,
        COALESCE((SELECT sum(x.quantity) FROM wo_parts x WHERE x.product_id = p.id AND x.created_at >= date_trunc('month', now())), 0) AS used_month
       FROM products p WHERE p.hotel_id = $1 AND p.archived_at IS NULL AND (p.category ILIKE '%maint%' OR p.category ILIKE '%pièce%' OR p.category ILIKE '%technique%' OR p.category ILIKE '%électri%' OR p.category ILIKE '%plomb%'
          OR EXISTS (SELECT 1 FROM wo_parts x WHERE x.product_id = p.id) OR $2::boolean)
      ORDER BY p.name`, [req.user!.hotelId, (req.query as any)?.all === 'true']));
  app.get('/api/maintenance/parts/used', { preHandler: needAny(...VIEW) }, async (req) =>
    q(getPool(), `SELECT x.*, p.name AS product, p.unit, w.number AS wo_number, w.title, e.name AS equipment, u.full_name AS user FROM wo_parts x JOIN products p ON p.id = x.product_id JOIN work_orders w ON w.id = x.wo_id
        LEFT JOIN equipment e ON e.id = w.equipment_id LEFT JOIN users u ON u.id = x.created_by WHERE w.hotel_id = $1 ORDER BY x.id DESC LIMIT 300`, [req.user!.hotelId]));

  // ===================================================== Rapports =====================================================
  app.get('/api/maintenance/reports/:kind', { preHandler: requirePerm('maintenance.reports') }, async (req, rep) => {
    const { kind } = z.object({ kind: z.string() }).parse(req.params);
    const f = z.object({ from: zDate.optional(), to: zDate.optional(), equipment_id: z.coerce.number().int().optional(), format: z.enum(['json', 'pdf', 'xlsx', 'csv']).default('json') }).parse(req.query);
    if (!MAINT_REPORTS[kind]) throw notFound('Rapport inconnu');
    const from = f.from ?? monthStart(today()), to = f.to ?? today();
    if (to < from) throw badRequest('Période invalide.');
    const r = await maintReport(getPool(), req.user!.hotelId, kind, from, to, { equipment_id: f.equipment_id ?? null });
    if (f.format === 'json') return r;
    await audit(getPool(), actorOf(req), 'export', 'maintenance_report', null, null, { kind, from, to, format: f.format });
    return sendTable(rep, f.format, `maintenance-${kind}-${from}_${to}`, r.title, `Du ${from} au ${to}`, r.columns, r.rows, r.total, await hotelName(req.user!.hotelId));
  });

  // ===================================================== Paramètres =====================================================
  app.get('/api/maintenance/settings', { preHandler: needAny(...VIEW) }, async (req) => (await getSettings(getPool(), req.user!.hotelId)).maintenance);
  app.put('/api/maintenance/settings', { preHandler: requirePerm('maintenance.supervise') }, async (req) => {
    const H = z.number().min(1).max(24 * 60);
    const b = z.object({ sla_hours: z.object({ urgent: H, high: H, normal: H, low: H }), preventive_horizon_days: z.number().int().min(0).max(90), warranty_alert_days: z.number().int().min(0).max(365),
      expense_category: z.string().trim().min(2).max(60), default_hourly_rate: z.number().min(0).max(1e6) }).parse(req.body);
    const cur = (await getSettings(getPool(), req.user!.hotelId)).maintenance;
    await getPool().query(`INSERT INTO settings (hotel_id, key, value) VALUES ($1,'maintenance',$2) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value`, [req.user!.hotelId, JSON.stringify(b)]);
    await audit(getPool(), actorOf(req), 'update', 'settings', 'maintenance', cur, b);
    return b;
  });
}
