import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { getPool, one, q, tx } from '../db/pool.js';
import { audit } from '../lib/audit.js';
import { actorOf, requireAuth, requirePerm } from '../lib/auth.js';
import { isDate, monthStart, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { BALANCE_EXPR, FIN_SQL, getSettings, guestDisplayName, nextNumber, withBalance } from '../services/common.js';
import { tableCsv, tablePdf, tableXlsx } from '../services/exports.js';
import {
  adjustPoints, anonymize, applyMemberDiscount, campaignStats, cancelRedemption, complaintAction, COMPLAINT_CAT, COMPLAINT_STATUS, createComplaint, CRM_REPORTS, crmDashboard, crmReport, crmSettings, enroll,
  ensureSurvey, exportGuestData, findDuplicates, idsOf, loyaltyBalance, mergeGuests, queueMessage, redeem, refreshStatus, refreshTier, render, runAutomations, segmentMembers, sendCampaign, setStatus,
  STATUS_LABEL, submitSurvey, TZ, useRedemption, varsFor, type Criteria,
} from '../services/crm.js';

const Id = z.object({ id: z.coerce.number().int().positive() });
const zDate = z.string().refine(isDate, 'Date invalide (AAAA-MM-JJ)');
const s = (n = 500) => z.string().trim().max(n).nullish();
const needAny = (...ps: string[]) => async (req: FastifyRequest) => {
  await requireAuth(req, null as any);
  if (!ps.some((p) => req.user!.perms.has(p))) throw forbidden(`Permission requise : ${ps.join(' ou ')}`);
};
const VIEW = ['crm.view', 'guests.view'];
const hotelName = async (id: number) => (await one<any>(getPool(), 'SELECT name FROM hotels WHERE id = $1', [id]))?.name ?? 'Hôtel';
async function sendTable(rep: FastifyReply, format: string, name: string, title: string, sub: string, cols: any[], rows: any[], total: any, hotel: string) {
  if (format === 'xlsx') {
    rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('content-disposition', `attachment; filename="${name}.xlsx"`);
    return rep.send(await tableXlsx(title, sub, cols, rows, total));
  }
  if (format === 'csv') {
    rep.header('content-type', 'text/csv; charset=utf-8').header('content-disposition', `attachment; filename="${name}.csv"`);
    return rep.send(tableCsv(cols, rows, total));
  }
  rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${name}.pdf"`);
  return rep.send(await tablePdf(hotel, title, sub, cols, rows, total));
}
const guestOf = async (req: FastifyRequest, id: number) => {
  const g = await one<any>(getPool(), 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
  if (!g) throw notFound('Client introuvable');
  return g;
};
const esc = (v: string) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
const page = (title: string, body: string) => `<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title>
<style>body{font-family:system-ui,sans-serif;background:#f6f3ee;color:#1f2937;margin:0;padding:24px}main{max-width:620px;margin:auto;background:#fff;border-radius:14px;padding:24px;box-shadow:0 1px 3px #0002}
h1{color:#7A1F2B;font-size:22px}label{display:block;font-weight:600;margin:14px 0 6px}.r button{border:1px solid #ddd;background:#fff;border-radius:8px;padding:8px 12px;margin:2px;cursor:pointer;font-size:15px}
.r button.on{background:#7A1F2B;color:#fff;border-color:#7A1F2B}textarea{width:100%;min-height:80px;border:1px solid #ddd;border-radius:8px;padding:8px;box-sizing:border-box}
.send{background:#7A1F2B;color:#fff;border:0;border-radius:10px;padding:12px 18px;font-size:16px;margin-top:18px;cursor:pointer}.ok{color:#166534;font-weight:600}</style></head><body><main>${body}</main></body></html>`;

export async function crmRoutes(app: FastifyInstance) {
  // ===================================================== Référentiels, tableau de bord =====================================================
  app.get('/api/crm/meta', { preHandler: needAny(...VIEW) }, async (req) => {
    const h = req.user!.hotelId;
    const p = req.user!.perms;
    return {
      statuses: STATUS_LABEL, complaint_categories: COMPLAINT_CAT, complaint_status: COMPLAINT_STATUS,
      tiers: await q(getPool(), 'SELECT * FROM loyalty_tiers WHERE hotel_id = $1 ORDER BY min_points', [h]),
      rewards: await q(getPool(), 'SELECT r.*, t.name AS min_tier FROM loyalty_rewards r LEFT JOIN loyalty_tiers t ON t.id = r.min_tier_id WHERE r.hotel_id = $1 ORDER BY r.active DESC, r.points_cost', [h]),
      room_types: await q(getPool(), 'SELECT id, name FROM room_types WHERE hotel_id = $1 ORDER BY name', [h]),
      users: await q(getPool(), 'SELECT u.id, u.full_name FROM users u WHERE u.hotel_id = $1 AND u.active ORDER BY u.full_name', [h]),
      templates: p.has('crm.marketing') ? await q(getPool(), 'SELECT * FROM crm_templates WHERE hotel_id = $1 ORDER BY code, language', [h]) : [],
      surveys: await q(getPool(), 'SELECT * FROM crm_surveys WHERE hotel_id = $1 ORDER BY active DESC, id', [h]),
      settings: (await getSettings(getPool(), h)).crm,
    };
  });
  app.get('/api/crm/dashboard', { preHandler: requirePerm('crm.view') }, async (req) => crmDashboard(getPool(), req.user!.hotelId));

  // ===================================================== Clients =====================================================
  app.get('/api/crm/clients', { preHandler: needAny(...VIEW) }, async (req) => {
    const f = z.object({ q: z.string().max(80).default(''), status: z.string().optional(), kind: z.enum(['person', 'company', 'agency', 'all']).default('person'), tier: z.coerce.number().int().optional(),
      members: z.coerce.boolean().optional(), page: z.coerce.number().int().min(1).default(1) }).parse(req.query);
    const term = `%${f.q.trim().toLowerCase()}%`;
    const size = 50;
    const rows = await q<any>(getPool(), `SELECT g.id, g.code, g.kind, g.last_name, g.first_name, g.company_name, g.phone, g.email, g.country, g.nationality, g.language, g.crm_status, g.loyalty_number, g.anonymized_at,
        t.name AS tier, t.color AS tier_color, (SELECT count(*) FROM stays s WHERE s.guest_id = g.id AND s.checked_out_at IS NOT NULL)::int AS stays,
        (SELECT max(s.checked_in_at) FROM stays s WHERE s.guest_id = g.id) AS last_stay, EXISTS (SELECT 1 FROM stays s WHERE s.guest_id = g.id AND s.checked_out_at IS NULL) AS in_house,
        (SELECT count(*) FROM crm_complaints c WHERE c.guest_id = g.id AND c.status IN ('new','in_progress'))::int AS open_complaints,
        (SELECT min(p.id) FROM photos p WHERE p.owner_type = 'guest' AND p.owner_id = g.id) AS photo_id, count(*) OVER() AS total_count
       FROM guests g LEFT JOIN loyalty_tiers t ON t.id = g.loyalty_tier_id
      WHERE g.hotel_id = $1 AND g.merged_into_id IS NULL AND ($3 = 'all' OR g.kind = $3) AND ($4::text IS NULL OR g.crm_status = $4) AND ($5::int IS NULL OR g.loyalty_tier_id = $5) AND (NOT $6::boolean OR g.loyalty_number IS NOT NULL)
        AND (lower(coalesce(g.last_name,'') || ' ' || coalesce(g.first_name,'') || ' ' || coalesce(g.company_name,'')) LIKE $2 OR lower(g.code) LIKE $2 OR coalesce(g.phone,'') LIKE $2
             OR lower(coalesce(g.email,'')) LIKE $2 OR lower(coalesce(g.loyalty_number,'')) LIKE $2)
      ORDER BY g.updated_at DESC LIMIT ${size} OFFSET $7`, [req.user!.hotelId, term, f.kind, f.status || null, f.tier ?? null, !!f.members, (f.page - 1) * size]);
    return { total: Number(rows[0]?.total_count ?? 0), page: f.page, page_size: size, rows: rows.map(({ total_count, ...g }) => ({ ...g, name: guestDisplayName(g) })) };
  });
  app.get('/api/crm/duplicates', { preHandler: needAny(...VIEW) }, async (req) => {
    const b = z.object({ last_name: s(80), first_name: s(80), phone: s(40), email: s(120), id_doc_number: s(40), birth_date: zDate.nullish(), company_name: s(120), exclude_id: z.coerce.number().int().optional() }).parse(req.query);
    return findDuplicates(getPool(), req.user!.hotelId, b);
  });

  app.get('/api/crm/clients/:id', { preHandler: needAny(...VIEW) }, async (req) => {
    const { id } = Id.parse(req.params);
    const h = req.user!.hotelId;
    const p = req.user!.perms;
    const g = await guestOf(req, id);
    const ids = await idsOf(getPool(), id);
    const billing = p.has('crm.billing');
    if (!p.has('guests.edit')) { g.id_doc_number = g.id_doc_number ? `•••${String(g.id_doc_number).slice(-4)}` : null; g.father_name = null; g.mother_name = null; }
    delete g.unsubscribe_token;
    const stays = await q<any>(getPool(), `SELECT s.id, s.checked_in_at, s.checked_out_at, rr.check_in, rr.check_out, rr.rate, (rr.check_out - rr.check_in)::int AS nights, rm.number AS room, rt.name AS room_type, r.code, r.id AS reservation_id
        FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN reservations r ON r.id = rr.reservation_id JOIN rooms rm ON rm.id = rr.room_id JOIN room_types rt ON rt.id = rr.room_type_id
       WHERE s.guest_id = ANY($1::int[]) ORDER BY s.checked_in_at DESC LIMIT 100`, [ids]);
    const reservations = await q<any>(getPool(), `SELECT x.* FROM (SELECT r.id, r.code, r.check_in, r.check_out, r.status, r.source, r.created_at, (r.payer_guest_id = ANY($1::int[]) AND NOT r.guest_id = ANY($1::int[])) AS as_payer, ${FIN_SQL}
        FROM reservations r WHERE r.hotel_id = $2 AND (r.guest_id = ANY($1::int[]) OR r.payer_guest_id = ANY($1::int[]) OR EXISTS (SELECT 1 FROM reservation_rooms rr WHERE rr.reservation_id = r.id AND rr.guest_id = ANY($1::int[])))) x ORDER BY x.check_in DESC LIMIT 100`, [ids, h]);
    const fin = reservations.map((x) => ({ ...x, f: withBalance(x) }));
    const spent = await one<any>(getPool(), `SELECT COALESCE(sum(CASE WHEN void THEN 0 ELSE amount END),0) AS t FROM payments WHERE guest_id = ANY($1::int[])`, [ids]);
    const rs = await q<any>(getPool(), `SELECT o.id, o.number, o.created_at, o.total, o.settlement, o.outlet AS kind FROM rs_orders o WHERE o.guest_id = ANY($1::int[]) AND o.status <> 'cancelled' ORDER BY o.id DESC LIMIT 50`, [ids]).catch(() => []);
    const nights = stays.reduce((a, x) => a + (x.checked_out_at ? x.nights : 0), 0);
    const doneStays = stays.filter((x) => x.checked_out_at).length;
    await audit(getPool(), actorOf(req), 'view_profile', 'guest', id, null, { billing });
    return {
      ...g, name: guestDisplayName(g), merged_ids: ids.filter((x) => x !== id),
      photo_id: (await one<any>(getPool(), `SELECT min(id) AS id FROM photos WHERE owner_type = 'guest' AND owner_id = $1`, [id]))?.id ?? null,
      company: g.company_id ? await one(getPool(), 'SELECT id, code, company_name FROM guests WHERE id = $1', [g.company_id]) : null,
      tier: g.loyalty_tier_id ? await one(getPool(), 'SELECT * FROM loyalty_tiers WHERE id = $1', [g.loyalty_tier_id]) : null,
      stats: { stays: doneStays, nights, spent: billing ? Number(spent.t) : null, avg_stay: billing && doneStays ? Math.round((Number(spent.t) / doneStays) * 100) / 100 : null, last_stay: stays[0]?.checked_in_at ?? null, first_stay: stays[stays.length - 1]?.checked_in_at ?? null,
        balance: billing ? Math.round(fin.filter((x) => !['cancelled', 'no_show'].includes(x.status)).reduce((a, x) => a + x.f.balance, 0) * 100) / 100 : null },
      stays, reservations: fin.map((x) => ({ id: x.id, code: x.code, check_in: x.check_in, check_out: x.check_out, status: x.status, source: x.source, as_payer: x.as_payer, total: billing ? x.f.total : null, balance: billing ? x.f.balance : null })),
      invoices: billing ? await q(getPool(), `SELECT i.id, i.number, i.type, i.status, i.issued_at, i.total FROM invoices i WHERE i.guest_id = ANY($1::int[]) ORDER BY i.issued_at DESC LIMIT 100`, [ids]) : null,
      payments: billing ? await q(getPool(), `SELECT p.id, p.received_at, p.amount, p.method, p.kind, p.void, r.code FROM payments p LEFT JOIN reservations r ON r.id = p.reservation_id WHERE p.guest_id = ANY($1::int[]) ORDER BY p.received_at DESC LIMIT 100`, [ids]) : null,
      restaurant: rs.map((o) => ({ ...o, total: billing ? o.total : null })),
      preferences: await q(getPool(), `SELECT p.*, u.full_name AS by_name FROM guest_preferences p LEFT JOIN users u ON u.id = p.created_by WHERE p.guest_id = ANY($1::int[]) ORDER BY p.category, p.id`, [ids]),
      note_list: await q(getPool(), `SELECT n.*, u.full_name AS created_by_name, r.code FROM guest_notes n LEFT JOIN users u ON u.id = n.created_by LEFT JOIN reservations r ON r.id = n.reservation_id WHERE n.guest_id = ANY($1::int[]) ORDER BY n.created_at DESC LIMIT 100`, [ids]),
      complaints: await q(getPool(), `SELECT c.*, u.full_name AS assignee FROM crm_complaints c LEFT JOIN users u ON u.id = c.assigned_to WHERE c.guest_id = ANY($1::int[]) ORDER BY c.created_at DESC`, [ids]),
      interactions: await q(getPool(), `SELECT i.*, u.full_name AS by_name, n.status AS delivery FROM crm_interactions i LEFT JOIN users u ON u.id = i.created_by LEFT JOIN notifications n ON n.id = i.notification_id WHERE i.guest_id = ANY($1::int[]) ORDER BY i.created_at DESC LIMIT 100`, [ids]),
      loyalty: g.loyalty_number ? {
        ...(await loyaltyBalance(getPool(), id)),
        transactions: await q(getPool(), `SELECT t.*, u.full_name AS by_name FROM loyalty_transactions t LEFT JOIN users u ON u.id = t.created_by WHERE t.guest_id = ANY($1::int[]) ORDER BY t.id DESC LIMIT 100`, [ids]),
        redemptions: await q(getPool(), `SELECT r.*, w.name AS reward, w.kind, rs.code AS reservation FROM loyalty_redemptions r JOIN loyalty_rewards w ON w.id = r.reward_id LEFT JOIN reservations rs ON rs.id = r.reservation_id WHERE r.guest_id = ANY($1::int[]) ORDER BY r.id DESC`, [ids]),
      } : null,
      surveys: await q(getPool(), `SELECT r.id, r.score, r.nps, r.comment, r.completed_at, r.sent_at, s.name, rs.code FROM crm_survey_responses r JOIN crm_surveys s ON s.id = r.survey_id LEFT JOIN reservations rs ON rs.id = r.reservation_id WHERE r.guest_id = ANY($1::int[]) ORDER BY r.id DESC`, [ids]),
      contacts: g.kind !== 'person' ? await q(getPool(), 'SELECT * FROM crm_contacts WHERE company_id = $1 ORDER BY active DESC, name', [id]) : [],
      privacy: p.has('crm.privacy') ? await q(getPool(), `SELECT r.*, u.full_name AS by_name FROM crm_privacy_requests r LEFT JOIN users u ON u.id = r.handled_by WHERE r.guest_id = $1 ORDER BY r.id DESC`, [id]) : [],
      duplicates: g.anonymized_at ? [] : await findDuplicates(getPool(), h, { ...g, exclude_id: id }),
    };
  });
  /** Résumé pour la réservation et le check-in : statut, fidélité, préférences, réclamations ouvertes, occasions. */
  app.get('/api/crm/clients/:id/summary', { preHandler: needAny(...VIEW) }, async (req) => {
    const { id } = Id.parse(req.params);
    const g = await guestOf(req, id);
    const ids = await idsOf(getPool(), id);
    const occ = await q<any>(getPool(), `SELECT * FROM guest_preferences WHERE guest_id = ANY($1::int[]) AND category = 'occasion' AND event_date IS NOT NULL`, [ids]);
    const t = today();
    const soon = (d: string) => { const md = d.slice(5, 10); const y = Number(t.slice(0, 4)); for (const yy of [y, y + 1]) { const x = `${yy}-${md}`; if (x >= t && x <= new Date(Date.parse(t) + 30 * 86400000).toISOString().slice(0, 10)) return x; } return null; };
    const birthday = g.birth_date ? soon(String(g.birth_date).slice(0, 10)) : null;
    return {
      id: g.id, code: g.code, name: guestDisplayName(g), status: g.crm_status, status_label: STATUS_LABEL[g.crm_status], language: g.language,
      tier: g.loyalty_tier_id ? await one(getPool(), 'SELECT name, color, discount_percent, benefits FROM loyalty_tiers WHERE id = $1', [g.loyalty_tier_id]) : null,
      loyalty_number: g.loyalty_number, points: g.loyalty_number ? (await loyaltyBalance(getPool(), id)).balance : null,
      stays: (await one<any>(getPool(), 'SELECT count(*)::int AS n FROM stays WHERE guest_id = ANY($1::int[]) AND checked_out_at IS NOT NULL', [ids])).n,
      last_stay: (await one<any>(getPool(), 'SELECT max(checked_in_at) AS d FROM stays WHERE guest_id = ANY($1::int[])', [ids])).d,
      preferred_room_type: g.preferred_room_type_id ? (await one<any>(getPool(), 'SELECT name FROM room_types WHERE id = $1', [g.preferred_room_type_id]))?.name : null,
      preferences: await q(getPool(), `SELECT category, value, event_date FROM guest_preferences WHERE guest_id = ANY($1::int[]) AND category <> 'communication' ORDER BY category`, [ids]),
      legacy_preferences: g.preferences,
      open_complaints: await q(getPool(), `SELECT number, title, priority FROM crm_complaints WHERE guest_id = ANY($1::int[]) AND status IN ('new','in_progress')`, [ids]),
      occasions: [...(birthday ? [{ label: 'Anniversaire', date: birthday }] : []), ...occ.map((o) => ({ label: o.value, date: soon(String(o.event_date).slice(0, 10)) })).filter((o) => o.date)],
    };
  });
  const ClientBody = z.object({
    kind: z.enum(['person', 'company', 'agency']).default('person'), last_name: s(80), first_name: s(80), company_name: s(120), gender: z.enum(['M', 'F']).nullish(), birth_date: zDate.nullish(), nationality: s(60),
    phone: s(40), mobile: s(40), email: z.string().trim().max(120).email('E-mail invalide').or(z.literal('')).nullish(), address: s(200), city: s(80), country: s(60), language: z.enum(['fr', 'en', 'ar']).optional(),
    profession: s(80), job_title: s(80), company_id: z.number().int().positive().nullish(), preferred_room_type_id: z.number().int().positive().nullish(), notes: s(2000), nif: s(40),
    id_doc_type: z.enum(['cni', 'passport', 'permis', 'other']).nullish(), id_doc_number: s(40), consent_email: z.boolean().optional(), consent_sms: z.boolean().optional(), source: s(40),
    payment_terms_days: z.number().int().min(0).max(180).nullish(), credit_limit: z.number().min(0).max(1e10).nullish(), website: s(160), sector: s(80),
  });
  const checkClient = async (h: number, b: any, id: number | null) => {
    if (b.company_id && (b.company_id === id || !(await one(getPool(), `SELECT 1 FROM guests WHERE id = $1 AND hotel_id = $2 AND kind <> 'person'`, [b.company_id, h])))) throw badRequest('Entreprise inconnue.');
    if (b.preferred_room_type_id && !(await one(getPool(), 'SELECT 1 FROM room_types WHERE id = $1 AND hotel_id = $2', [b.preferred_room_type_id, h]))) throw badRequest('Type de chambre inconnu.');
  };
  app.post('/api/crm/clients', { preHandler: requirePerm('guests.edit') }, async (req, rep) => {
    const b = ClientBody.extend({ force: z.boolean().optional() }).parse(req.body);
    const h = req.user!.hotelId;
    if (b.kind === 'person' && !b.last_name?.trim()) throw badRequest('Le nom est obligatoire.');
    if (b.kind !== 'person' && !b.company_name?.trim()) throw badRequest('La raison sociale est obligatoire.');
    await checkClient(h, b, null);
    const d = (await findDuplicates(getPool(), h, b)).filter((x) => x.score >= 60);
    if (d.length && !b.force) throw conflict(`Client probablement déjà enregistré : ${d.map((x) => `${x.code} ${x.name} (${x.reasons.join(', ')})`).join(' · ')}`, { duplicates: d });
    const { force, ...data } = b;
    const keys = Object.keys(data).filter((k) => (data as any)[k] !== undefined);
    const vals = keys.map((k) => (k === 'email' ? (data as any)[k] || null : (data as any)[k]));
    const r = await tx(async (c) => {
      const g = await one<any>(c, `INSERT INTO guests (hotel_id, ${keys.join(', ')}, consent_updated_at) VALUES ($1, ${keys.map((_, i) => `$${i + 2}`).join(', ')}, CASE WHEN $${keys.length + 2}::boolean THEN now() END) RETURNING *`,
        [h, ...vals, b.consent_email !== undefined || b.consent_sms !== undefined]);
      await audit(c, actorOf(req), 'create', 'guest', g.id, null, { code: g.code, forced_despite_duplicates: d.length ? d.map((x) => x.code) : undefined });
      return g;
    });
    rep.code(201);
    return r;
  });
  app.patch('/api/crm/clients/:id', { preHandler: requirePerm('guests.edit') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = ClientBody.partial().omit({ kind: true }).extend({ rectification: z.boolean().optional() }).parse(req.body);
    const h = req.user!.hotelId;
    await checkClient(h, b, id);
    return tx(async (c) => {
      const cur = await one<any>(c, 'SELECT * FROM guests WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, h]);
      if (!cur) throw notFound('Client introuvable');
      if (cur.anonymized_at) throw conflict('Fiche anonymisée : non modifiable.');
      const { rectification, ...data } = b;
      const keys = Object.keys(data).filter((k) => (data as any)[k] !== undefined);
      if (!keys.length) return cur;
      const consentChange = keys.includes('consent_email') || keys.includes('consent_sms');
      const r = await one<any>(c, `UPDATE guests SET ${keys.map((k, i) => `${k} = $${i + 2}`).join(', ')}${consentChange ? ', consent_updated_at = now()' : ''}${data.consent_email ? ', unsubscribed_at = NULL' : ''}, updated_at = now() WHERE id = $1 RETURNING *`,
        [id, ...keys.map((k) => (k === 'email' ? (data as any)[k] || null : (data as any)[k]))]);
      await audit(c, actorOf(req), 'update', 'guest', id, Object.fromEntries(keys.map((k) => [k, cur[k]])), Object.fromEntries(keys.map((k) => [k, r[k]])));
      if (rectification) await c.query(`INSERT INTO crm_privacy_requests (hotel_id, guest_id, kind, details, outcome, handled_by) VALUES ($1,$2,'rectification',$3,'Fiche corrigée',$4)`, [h, id, keys.join(', '), req.user!.id]);
      if (consentChange && ((cur.consent_email && data.consent_email === false) || (cur.consent_sms && data.consent_sms === false))) {
        await c.query(`INSERT INTO crm_privacy_requests (hotel_id, guest_id, kind, details, outcome, handled_by) VALUES ($1,$2,'consent_withdrawal',$3,'Consentement retiré',$4)`, [h, id, keys.filter((k) => k.startsWith('consent')).join(', '), req.user!.id]);
      }
      if (keys.includes('preferred_room_type_id')) await c.query(`INSERT INTO guest_preferences (guest_id, category, value, created_by) SELECT $1, 'room', 'Type préféré : ' || name, $3 FROM room_types WHERE id = $2 AND NOT EXISTS (SELECT 1 FROM guest_preferences WHERE guest_id = $1 AND category = 'room' AND value = 'Type préféré : ' || room_types.name)`, [id, data.preferred_room_type_id, req.user!.id]);
      return r;
    });
  });
  app.post('/api/crm/clients/:id/status', { preHandler: requirePerm('crm.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ status: z.enum(['standard', 'loyal', 'vip', 'company']), locked: z.boolean().default(true) }).parse(req.body);
    await tx((c) => setStatus(c, actorOf(req), id, b.status, b.locked));
    return { ok: true };
  });
  app.post('/api/crm/clients/:id/preferences', { preHandler: requirePerm('guests.view') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ category: z.enum(['room', 'dietary', 'service', 'request', 'occasion', 'habit', 'communication']), value: z.string().trim().min(2).max(300), event_date: zDate.nullish(), recurring: z.boolean().optional(), volunteered: z.boolean().default(true) }).parse(req.body);
    const g = await guestOf(req, id);
    if (g.anonymized_at) throw conflict('Fiche anonymisée.');
    // les préférences alimentaires ne sont enregistrées que si le client les a communiquées lui-même
    if (b.category === 'dietary' && !b.volunteered) throw badRequest('Préférence alimentaire : uniquement si le client l\'a communiquée volontairement.');
    if (b.category === 'occasion' && !b.event_date) throw badRequest('Date de l\'occasion obligatoire.');
    const r = await one(getPool(), `INSERT INTO guest_preferences (guest_id, category, value, event_date, recurring, volunteered, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [id, b.category, b.value, b.event_date ?? null, !!b.recurring, b.volunteered, req.user!.id]);
    await audit(getPool(), actorOf(req), 'preference', 'guest', id, null, { category: b.category });
    rep.code(201);
    return r;
  });
  app.delete('/api/crm/preferences/:id', { preHandler: requirePerm('guests.edit') }, async (req) => {
    const { id } = Id.parse(req.params);
    const r = await one<any>(getPool(), `DELETE FROM guest_preferences p USING guests g WHERE p.id = $1 AND g.id = p.guest_id AND g.hotel_id = $2 RETURNING p.*`, [id, req.user!.hotelId]);
    if (!r) throw notFound('Préférence introuvable');
    await audit(getPool(), actorOf(req), 'preference_removed', 'guest', r.guest_id, { category: r.category, value: r.value }, null);
    return { ok: true };
  });
  app.post('/api/crm/clients/:id/merge', { preHandler: requirePerm('crm.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ duplicate_id: z.number().int().positive() }).parse(req.body);
    return tx((c) => mergeGuests(c, actorOf(req), id, b.duplicate_id));
  });
  app.post('/api/crm/clients/:id/interactions', { preHandler: requirePerm('guests.view') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ channel: z.enum(['phone', 'email', 'sms', 'whatsapp', 'in_person', 'letter', 'other']), direction: z.enum(['in', 'out']).default('out'), subject: s(200), body: s(4000), reservation_id: z.number().int().positive().nullish() }).parse(req.body);
    await guestOf(req, id);
    if (!b.subject?.trim() && !b.body?.trim()) throw badRequest('Objet ou contenu obligatoire.');
    rep.code(201);
    return one(getPool(), `INSERT INTO crm_interactions (hotel_id, guest_id, channel, direction, subject, body, reservation_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [req.user!.hotelId, id, b.channel, b.direction, b.subject ?? null, b.body ?? null, b.reservation_id ?? null, req.user!.id]);
  });
  app.post('/api/crm/clients/:id/message', { preHandler: requirePerm('crm.marketing') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ template_id: z.number().int().positive().nullish(), subject: s(200), body: s(8000), purpose: z.enum(['transactional', 'marketing']).default('transactional'), reservation_id: z.number().int().positive().nullish() }).parse(req.body);
    const g = await guestOf(req, id);
    let subject = b.subject ?? '', body = b.body ?? '', purpose = b.purpose;
    const vars = await varsFor(getPool(), req.user!.hotelId, g, b.reservation_id ?? null);
    if (b.template_id) {
      const t = await one<any>(getPool(), 'SELECT * FROM crm_templates WHERE id = $1 AND hotel_id = $2', [b.template_id, req.user!.hotelId]);
      if (!t) throw notFound('Modèle introuvable');
      subject = t.subject; body = t.body; purpose = t.purpose;
    }
    if (!subject.trim() || !body.trim()) throw badRequest('Objet et message obligatoires.');
    const r = await tx((c) => queueMessage(c, actorOf(req), { guest_id: id, purpose, kind: 'crm', subject: render(subject, vars), body: render(body, vars), reservation_id: b.reservation_id ?? null }));
    if ('skipped' in r) throw conflict(r.skipped === 'consent' ? 'Le client n\'a pas consenti aux communications commerciales (ou s\'est désabonné).' : r.skipped === 'contact' ? 'Aucune adresse e-mail valide pour ce client.' : 'Message déjà envoyé.');
    const smtp = (await getSettings(getPool(), req.user!.hotelId)).smtp;
    return { ...r, delivery: smtp?.host ? 'queued' : 'smtp_not_configured' };
  });
  app.post('/api/crm/templates/:id/preview', { preHandler: requirePerm('crm.marketing') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ guest_id: z.number().int().positive().nullish(), reservation_id: z.number().int().positive().nullish() }).parse(req.body);
    const t = await one<any>(getPool(), 'SELECT * FROM crm_templates WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!t) throw notFound('Modèle introuvable');
    const g = b.guest_id ? await guestOf(req, b.guest_id) : { first_name: 'Prénom', last_name: 'NOM', kind: 'person', unsubscribe_token: 'xxx', loyalty_number: null };
    const v = await varsFor(getPool(), req.user!.hotelId, g, b.reservation_id ?? null, { survey_url: '(lien de l\'enquête)' });
    return { subject: render(t.subject, v), body: render(t.body, v) };
  });

  // ===================================================== Fidélité =====================================================
  app.post('/api/crm/clients/:id/enroll', { preHandler: requirePerm('crm.loyalty') }, async (req) => {
    const { id } = Id.parse(req.params);
    return { loyalty_number: await tx((c) => enroll(c, actorOf(req), id)) };
  });
  app.post('/api/crm/clients/:id/points', { preHandler: requirePerm('crm.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ points: z.number().int().min(-100000).max(100000).refine((x) => x !== 0), reason: z.string().trim().min(5).max(300) }).parse(req.body);
    await guestOf(req, id);
    return tx((c) => adjustPoints(c, actorOf(req), id, b.points, b.reason));
  });
  app.post('/api/crm/clients/:id/redeem', { preHandler: requirePerm('crm.loyalty') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reward_id: z.number().int().positive(), reservation_id: z.number().int().positive().nullish() }).parse(req.body);
    return tx((c) => redeem(c, actorOf(req), id, b.reward_id, b.reservation_id ?? null));
  });
  app.post('/api/crm/redemptions/:id/use', { preHandler: requirePerm('crm.loyalty') }, async (req) => {
    const { id } = Id.parse(req.params);
    await tx((c) => useRedemption(c, actorOf(req), id));
    return { ok: true };
  });
  app.post('/api/crm/redemptions/:id/cancel', { preHandler: requirePerm('crm.loyalty') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(3).max(300) }).parse(req.body);
    await tx((c) => cancelRedemption(c, actorOf(req), id, b.reason));
    return { ok: true };
  });
  app.post('/api/crm/reservations/:id/member-discount', { preHandler: requirePerm('crm.loyalty') }, async (req) => {
    const { id } = Id.parse(req.params);
    return tx((c) => applyMemberDiscount(c, actorOf(req), id));
  });
  const TierBody = z.object({ code: z.string().trim().min(2).max(20), name: z.string().trim().min(2).max(40), min_points: z.number().int().min(0), earn_multiplier: z.number().min(0.1).max(10), discount_percent: z.number().min(0).max(50),
    benefits: s(500), color: z.string().regex(/^#[0-9a-f]{6}$/i).default('#64748B'), active: z.boolean().optional() });
  app.post('/api/crm/tiers', { preHandler: requirePerm('crm.manage') }, async (req, rep) => {
    const b = TierBody.parse(req.body);
    if (await one(getPool(), 'SELECT 1 FROM loyalty_tiers WHERE hotel_id = $1 AND upper(code) = upper($2)', [req.user!.hotelId, b.code])) throw conflict('Code déjà utilisé.');
    rep.code(201);
    const r = await one(getPool(), `INSERT INTO loyalty_tiers (hotel_id, code, name, min_points, earn_multiplier, discount_percent, benefits, color) VALUES ($1,upper($2),$3,$4,$5,$6,$7,$8) RETURNING *`,
      [req.user!.hotelId, b.code, b.name, b.min_points, b.earn_multiplier, b.discount_percent, b.benefits ?? null, b.color]);
    await audit(getPool(), actorOf(req), 'create', 'loyalty_tier', (r as any).id, null, b);
    return r;
  });
  app.patch('/api/crm/tiers/:id', { preHandler: requirePerm('crm.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = TierBody.partial().omit({ code: true }).parse(req.body);
    const cur = await one<any>(getPool(), 'SELECT * FROM loyalty_tiers WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!cur) throw notFound('Niveau introuvable');
    const keys = Object.keys(b).filter((k) => (b as any)[k] !== undefined);
    const r = await one(getPool(), `UPDATE loyalty_tiers SET ${keys.map((k, i) => `${k} = $${i + 2}`).join(', ') || 'name = name'} WHERE id = $1 RETURNING *`, [id, ...keys.map((k) => (b as any)[k])]);
    await audit(getPool(), actorOf(req), 'update', 'loyalty_tier', id, cur, b);
    if (keys.includes('min_points') || keys.includes('active')) for (const g of await q<any>(getPool(), 'SELECT id FROM guests WHERE hotel_id = $1 AND loyalty_number IS NOT NULL', [req.user!.hotelId])) await refreshTier(getPool(), g.id);
    return r;
  });
  const RewardBody = z.object({ name: z.string().trim().min(2).max(120), kind: z.enum(['discount_amount', 'discount_percent', 'service', 'upgrade', 'other']), points_cost: z.number().int().min(1).max(1e6),
    value: z.number().min(0).max(1e8).nullish(), min_tier_id: z.number().int().positive().nullish(), description: s(500), active: z.boolean().optional() });
  app.post('/api/crm/rewards', { preHandler: requirePerm('crm.manage') }, async (req, rep) => {
    const b = RewardBody.parse(req.body);
    if (b.kind.startsWith('discount') && !(Number(b.value) > 0)) throw badRequest('Montant ou pourcentage de la remise obligatoire.');
    if (b.kind === 'discount_percent' && Number(b.value) > 50) throw badRequest('Remise maximale : 50 %.');
    rep.code(201);
    return one(getPool(), `INSERT INTO loyalty_rewards (hotel_id, name, kind, points_cost, value, min_tier_id, description) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [req.user!.hotelId, b.name, b.kind, b.points_cost, b.value ?? null, b.min_tier_id ?? null, b.description ?? null]);
  });
  app.patch('/api/crm/rewards/:id', { preHandler: requirePerm('crm.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = RewardBody.partial().parse(req.body);
    const keys = Object.keys(b).filter((k) => (b as any)[k] !== undefined);
    const r = await one(getPool(), `UPDATE loyalty_rewards SET ${keys.map((k, i) => `${k} = $${i + 3}`).join(', ') || 'name = name'} WHERE id = $1 AND hotel_id = $2 RETURNING *`, [id, req.user!.hotelId, ...keys.map((k) => (b as any)[k])]);
    if (!r) throw notFound('Récompense introuvable');
    return r;
  });

  // ===================================================== Entreprises =====================================================
  app.get('/api/crm/companies', { preHandler: needAny(...VIEW) }, async (req) => {
    const f = z.object({ q: z.string().max(80).default('') }).parse(req.query);
    const billing = req.user!.perms.has('crm.billing');
    const rows = await q<any>(getPool(), `SELECT g.id, g.code, g.kind, g.company_name, g.phone, g.email, g.city, g.nif, g.payment_terms_days, g.credit_limit, g.sector,
        (SELECT count(*) FROM crm_contacts c WHERE c.company_id = g.id AND c.active)::int AS contacts,
        (SELECT count(*) FROM reservations r WHERE (r.payer_guest_id = g.id OR r.guest_id = g.id) AND r.status NOT IN ('cancelled','no_show'))::int AS reservations,
        (SELECT COALESCE(sum(rr.check_out - rr.check_in),0) FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id WHERE (r.payer_guest_id = g.id OR r.guest_id = g.id) AND rr.status IN ('checked_in','checked_out') AND rr.check_in > CURRENT_DATE - 365)::int AS nights_12m,
        (SELECT count(*) FROM crm_contracts k WHERE k.company_id = g.id AND k.status = 'active' AND (k.end_date IS NULL OR k.end_date >= CURRENT_DATE))::int AS contracts,
        (SELECT count(*) FROM rate_plans p WHERE p.guest_id = g.id AND p.active)::int AS rate_plans
       FROM guests g WHERE g.hotel_id = $1 AND g.kind <> 'person' AND g.merged_into_id IS NULL AND lower(g.company_name) LIKE $2 ORDER BY g.company_name LIMIT 300`, [req.user!.hotelId, `%${f.q.trim().toLowerCase()}%`]);
    if (!billing) return rows;
    const recv = await companyReceivables(req.user!.hotelId, rows.map((r) => r.id));
    return rows.map((r) => ({ ...r, due: recv[r.id] ?? 0 }));
  });
  async function companyReceivables(h: number, ids: number[]) {
    const out: Record<number, number> = {};
    if (!ids.length) return out;
    for (const x of await q<any>(getPool(), `SELECT * FROM (SELECT r.id, COALESCE(r.payer_guest_id, r.guest_id) AS cid, r.status, ${FIN_SQL} FROM reservations r WHERE r.hotel_id = $1 AND COALESCE(r.payer_guest_id, r.guest_id) = ANY($2::int[])) x
        WHERE ${BALANCE_EXPR} > 0.004 AND x.status IN ('checked_in','checked_out','cancelled','no_show')`, [h, ids])) out[x.cid] = Math.round(((out[x.cid] ?? 0) + withBalance(x).balance) * 100) / 100;
    for (const x of await q<any>(getPool(), `SELECT i.guest_id, i.total - (SELECT COALESCE(sum(p.amount),0) FROM payments p WHERE p.invoice_id = i.id AND NOT p.void) - (SELECT COALESCE(sum(-c.total),0) FROM invoices c WHERE c.credit_of_invoice_id = i.id AND c.type = 'credit_note') AS due
        FROM invoices i WHERE i.hotel_id = $1 AND i.type = 'invoice' AND i.reservation_id IS NULL AND i.status IN ('issued','partially_paid') AND i.guest_id = ANY($2::int[])`, [h, ids])) {
      if (Number(x.due) > 0.004) out[x.guest_id] = Math.round(((out[x.guest_id] ?? 0) + Number(x.due)) * 100) / 100;
    }
    return out;
  }
  app.get('/api/crm/companies/:id', { preHandler: needAny(...VIEW) }, async (req) => {
    const { id } = Id.parse(req.params);
    const g = await guestOf(req, id);
    if (g.kind === 'person') throw badRequest('Fiche non entreprise.');
    const billing = req.user!.perms.has('crm.billing');
    const res = await q<any>(getPool(), `SELECT x.* FROM (SELECT r.id, r.code, r.check_in, r.check_out, r.status, gg.last_name, gg.first_name, gg.kind, gg.company_name, ${FIN_SQL} FROM reservations r JOIN guests gg ON gg.id = r.guest_id
        WHERE r.hotel_id = $2 AND (r.payer_guest_id = $1 OR r.guest_id = $1)) x ORDER BY x.check_in DESC LIMIT 200`, [id, req.user!.hotelId]);
    return {
      ...g, name: g.company_name,
      contacts: await q(getPool(), 'SELECT * FROM crm_contacts WHERE company_id = $1 ORDER BY active DESC, is_billing DESC, name', [id]),
      contracts: await q(getPool(), `SELECT k.*, p.name AS rate_plan, (SELECT array_agg(ph.id) FROM photos ph WHERE ph.owner_type = 'crm_contract' AND ph.owner_id = k.id) AS files FROM crm_contracts k LEFT JOIN rate_plans p ON p.id = k.rate_plan_id WHERE k.company_id = $1 ORDER BY k.start_date DESC`, [id]),
      rate_plans: await q(getPool(), `SELECT p.id, p.code, p.name, p.kind, p.adjustment_type, p.adjustment_value, p.valid_from, p.valid_to, p.active FROM rate_plans p WHERE p.guest_id = $1 ORDER BY p.active DESC, p.name`, [id]),
      employees: await q(getPool(), `SELECT id, code, last_name, first_name, job_title, crm_status FROM guests WHERE company_id = $1 AND merged_into_id IS NULL ORDER BY last_name`, [id]),
      reservations: res.map((x) => { const f = withBalance(x); return { id: x.id, code: x.code, check_in: x.check_in, check_out: x.check_out, status: x.status, guest: guestDisplayName(x), total: billing ? f.total : null, balance: billing ? f.balance : null }; }),
      invoices: billing ? await q(getPool(), `SELECT i.id, i.number, i.type, i.status, i.issued_at, i.total, i.due_date FROM invoices i WHERE i.guest_id = $1 ORDER BY i.issued_at DESC LIMIT 100`, [id]) : null,
      due: billing ? (await companyReceivables(req.user!.hotelId, [id]))[id] ?? 0 : null,
    };
  });
  const ContactBody = z.object({ name: z.string().trim().min(2).max(100), role: s(80), phone: s(40), email: z.string().trim().email().max(120).or(z.literal('')).nullish(), is_billing: z.boolean().optional(), is_booker: z.boolean().optional(), active: z.boolean().optional() });
  app.post('/api/crm/companies/:id/contacts', { preHandler: requirePerm('crm.manage') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = ContactBody.parse(req.body);
    const g = await guestOf(req, id);
    if (g.kind === 'person') throw badRequest('Fiche non entreprise.');
    rep.code(201);
    return one(getPool(), 'INSERT INTO crm_contacts (company_id, name, role, phone, email, is_billing, is_booker) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *', [id, b.name, b.role ?? null, b.phone ?? null, b.email || null, !!b.is_billing, !!b.is_booker]);
  });
  app.patch('/api/crm/contacts/:id', { preHandler: requirePerm('crm.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = ContactBody.partial().parse(req.body);
    const keys = Object.keys(b).filter((k) => (b as any)[k] !== undefined);
    const r = await one(getPool(), `UPDATE crm_contacts c SET ${keys.map((k, i) => `${k} = $${i + 3}`).join(', ') || 'name = c.name'} FROM guests g WHERE c.id = $1 AND g.id = c.company_id AND g.hotel_id = $2 RETURNING c.*`, [id, req.user!.hotelId, ...keys.map((k) => (k === 'email' ? (b as any)[k] || null : (b as any)[k]))]);
    if (!r) throw notFound('Contact introuvable');
    return r;
  });
  const ContractBody = z.object({ title: z.string().trim().min(3).max(160), start_date: zDate, end_date: zDate.nullish(), rate_plan_id: z.number().int().positive().nullish(), room_nights_commitment: z.number().int().min(0).nullish(),
    payment_terms_days: z.number().int().min(0).max(180).nullish(), credit_limit: z.number().min(0).nullish(), terms: s(4000), status: z.enum(['draft', 'active', 'expired', 'terminated']).default('active') });
  app.post('/api/crm/companies/:id/contracts', { preHandler: requirePerm('crm.manage') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = ContractBody.parse(req.body);
    const g = await guestOf(req, id);
    if (g.kind === 'person') throw badRequest('Fiche non entreprise.');
    if (b.end_date && b.end_date < b.start_date) throw badRequest('Période invalide.');
    if (b.rate_plan_id && !(await one(getPool(), 'SELECT 1 FROM rate_plans WHERE id = $1 AND hotel_id = $2', [b.rate_plan_id, req.user!.hotelId]))) throw badRequest('Tarif inconnu.');
    const r = await tx(async (c) => {
      const n = await nextNumber(c, `ac-${today().slice(0, 4)}`);
      const k = await one<any>(c, `INSERT INTO crm_contracts (hotel_id, company_id, number, title, start_date, end_date, rate_plan_id, room_nights_commitment, payment_terms_days, credit_limit, terms, status, created_by)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
      [req.user!.hotelId, id, `AC${today().slice(0, 4)}-${String(n).padStart(4, '0')}`, b.title, b.start_date, b.end_date ?? null, b.rate_plan_id ?? null, b.room_nights_commitment ?? null, b.payment_terms_days ?? null, b.credit_limit ?? null, b.terms ?? null, b.status, req.user!.id]);
      // conditions de paiement reportées sur la fiche entreprise (facturation centralisée)
      if (b.status === 'active') await c.query('UPDATE guests SET payment_terms_days = COALESCE($2, payment_terms_days), credit_limit = COALESCE($3, credit_limit) WHERE id = $1', [id, b.payment_terms_days ?? null, b.credit_limit ?? null]);
      if (b.rate_plan_id) await c.query('UPDATE rate_plans SET guest_id = $2 WHERE id = $1 AND guest_id IS NULL', [b.rate_plan_id, id]);
      await audit(c, actorOf(req), 'contract', 'guest', id, null, { number: k.number, title: b.title });
      return k;
    });
    rep.code(201);
    return r;
  });
  app.patch('/api/crm/contracts/:id', { preHandler: requirePerm('crm.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = ContractBody.partial().parse(req.body);
    const cur = await one<any>(getPool(), 'SELECT * FROM crm_contracts WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!cur) throw notFound('Contrat introuvable');
    const keys = Object.keys(b).filter((k) => (b as any)[k] !== undefined);
    const r = await one(getPool(), `UPDATE crm_contracts SET ${keys.map((k, i) => `${k} = $${i + 2}`).join(', ') || 'title = title'} WHERE id = $1 RETURNING *`, [id, ...keys.map((k) => (b as any)[k])]);
    await audit(getPool(), actorOf(req), 'contract_update', 'guest', cur.company_id, cur, b);
    return r;
  });

  // ===================================================== Réclamations =====================================================
  app.get('/api/crm/complaints', { preHandler: needAny('crm.view', 'crm.complaints') }, async (req) => {
    const f = z.object({ status: z.string().optional(), mine: z.coerce.boolean().optional(), category: z.string().optional() }).parse(req.query);
    return q(getPool(), `SELECT c.*, g.code AS guest_code, g.kind, g.last_name, g.first_name, g.company_name, g.crm_status, u.full_name AS assignee, r.code AS reservation FROM crm_complaints c JOIN guests g ON g.id = c.guest_id
        LEFT JOIN users u ON u.id = c.assigned_to LEFT JOIN reservations r ON r.id = c.reservation_id
       WHERE c.hotel_id = $1 AND ($2::text IS NULL OR c.status = ANY(string_to_array($2, ','))) AND (NOT $3::boolean OR c.assigned_to = $4) AND ($5::text IS NULL OR c.category = $5)
       ORDER BY (c.status IN ('new','in_progress')) DESC, array_position(ARRAY['urgent','high','normal','low'], c.priority), c.created_at DESC LIMIT 300`, [req.user!.hotelId, f.status || null, !!f.mine, req.user!.id, f.category || null])
      .then((rows) => rows.map((x: any) => ({ ...x, guest: guestDisplayName(x) })));
  });
  app.get('/api/crm/complaints/:id', { preHandler: needAny('crm.view', 'crm.complaints') }, async (req) => {
    const { id } = Id.parse(req.params);
    const c = await one<any>(getPool(), `SELECT c.*, g.code AS guest_code, g.kind, g.last_name, g.first_name, g.company_name, g.crm_status, u.full_name AS assignee, r.code AS reservation FROM crm_complaints c JOIN guests g ON g.id = c.guest_id
        LEFT JOIN users u ON u.id = c.assigned_to LEFT JOIN reservations r ON r.id = c.reservation_id WHERE c.id = $1 AND c.hotel_id = $2`, [id, req.user!.hotelId]);
    if (!c) throw notFound('Réclamation introuvable');
    return { ...c, guest: guestDisplayName(c), updates: await q(getPool(), `SELECT x.*, u.full_name AS by_name FROM crm_complaint_updates x LEFT JOIN users u ON u.id = x.created_by WHERE x.complaint_id = $1 ORDER BY x.id`, [id]) };
  });
  app.post('/api/crm/complaints', { preHandler: needAny('guests.view', 'crm.complaints') }, async (req, rep) => {
    const b = z.object({ guest_id: z.number().int().positive(), reservation_id: z.number().int().positive().nullish(), category: z.enum(Object.keys(COMPLAINT_CAT) as [string, ...string[]]), priority: z.enum(['low', 'normal', 'high', 'urgent']).default('normal'),
      channel: z.enum(['in_person', 'phone', 'email', 'survey', 'online', 'other']).default('in_person'), kind: z.enum(['complaint', 'remark', 'compliment']).default('complaint'), title: z.string().trim().min(3).max(160), description: s(4000), assigned_to: z.number().int().positive().nullish() }).parse(req.body);
    if (b.assigned_to && !req.user!.perms.has('crm.complaints')) throw forbidden('Affectation réservée au responsable.');
    const r = await tx((c) => createComplaint(c, actorOf(req), b));
    rep.code(201);
    return r;
  });
  app.post('/api/crm/complaints/:id/action', { preHandler: requirePerm('crm.complaints') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ action: z.enum(['assign', 'comment', 'response', 'corrective', 'resolve', 'close', 'reopen']), text: s(4000), assigned_to: z.number().int().positive().nullish(), satisfaction: z.number().int().min(1).max(5).nullish(), compensation: s(300) }).parse(req.body);
    await tx((c) => complaintAction(c, actorOf(req), id, b));
    return { ok: true };
  });

  // ===================================================== Enquêtes =====================================================
  const Question = z.object({ id: z.string().trim().min(1).max(30).regex(/^[a-z0-9_]+$/i), label: z.string().trim().min(3).max(200), type: z.enum(['rating', 'nps', 'yesno', 'text']) });
  app.post('/api/crm/surveys', { preHandler: requirePerm('crm.complaints') }, async (req, rep) => {
    const b = z.object({ name: z.string().trim().min(3).max(120), questions: z.array(Question).min(1).max(30), trigger: z.enum(['manual', 'after_stay', 'after_complaint']).default('manual') }).parse(req.body);
    if (new Set(b.questions.map((x) => x.id)).size !== b.questions.length) throw badRequest('Identifiants de questions en double.');
    rep.code(201);
    return one(getPool(), 'INSERT INTO crm_surveys (hotel_id, name, questions, trigger) VALUES ($1,$2,$3,$4) RETURNING *', [req.user!.hotelId, b.name, JSON.stringify(b.questions), b.trigger]);
  });
  app.patch('/api/crm/surveys/:id', { preHandler: requirePerm('crm.complaints') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ name: z.string().trim().min(3).max(120).optional(), questions: z.array(Question).min(1).max(30).optional(), trigger: z.enum(['manual', 'after_stay', 'after_complaint']).optional(), active: z.boolean().optional() }).parse(req.body);
    if (b.questions && (await one(getPool(), 'SELECT 1 FROM crm_survey_responses WHERE survey_id = $1 AND completed_at IS NOT NULL', [id]))) throw conflict('Des réponses existent : créez un nouveau questionnaire pour changer les questions.');
    const r = await one(getPool(), `UPDATE crm_surveys SET name = COALESCE($3, name), questions = COALESCE($4, questions), trigger = COALESCE($5, trigger), active = COALESCE($6, active) WHERE id = $1 AND hotel_id = $2 RETURNING *`,
      [id, req.user!.hotelId, b.name ?? null, b.questions ? JSON.stringify(b.questions) : null, b.trigger ?? null, b.active ?? null]);
    if (!r) throw notFound('Questionnaire introuvable');
    return r;
  });
  app.get('/api/crm/surveys/:id/responses', { preHandler: needAny('crm.view', 'crm.complaints') }, async (req) => {
    const { id } = Id.parse(req.params);
    const rows = await q<any>(getPool(), `SELECT r.*, g.code AS guest_code, g.kind, g.last_name, g.first_name, g.company_name, rs.code AS reservation FROM crm_survey_responses r LEFT JOIN guests g ON g.id = r.guest_id LEFT JOIN reservations rs ON rs.id = r.reservation_id
        WHERE r.survey_id = $1 AND r.hotel_id = $2 ORDER BY r.completed_at DESC NULLS LAST, r.id DESC LIMIT 300`, [id, req.user!.hotelId]);
    return rows.map(({ token, ...r }) => ({ ...r, guest: r.guest_code ? guestDisplayName(r) : '' }));
  });
  /** Saisie d'une réponse par le personnel (questionnaire papier, appel). */
  app.post('/api/crm/surveys/:id/responses', { preHandler: requirePerm('crm.complaints') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ guest_id: z.number().int().positive().nullish(), reservation_id: z.number().int().positive().nullish(), answers: z.record(z.string(), z.any()), comment: s(2000) }).parse(req.body);
    const sv = await one<any>(getPool(), 'SELECT * FROM crm_surveys WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!sv) throw notFound('Questionnaire introuvable');
    let guestId = b.guest_id ?? null;
    if (b.reservation_id) {
      const r = await one<any>(getPool(), 'SELECT guest_id FROM reservations WHERE id = $1 AND hotel_id = $2', [b.reservation_id, req.user!.hotelId]);
      if (!r) throw badRequest('Réservation inconnue.');
      guestId = guestId ?? r.guest_id;
    }
    if (guestId) await guestOf(req, guestId);
    const r = await tx(async (c) => {
      const resp = await ensureSurvey(c, actorOf(req), id, b.reservation_id ?? null, guestId);
      return submitSurvey(c, resp.token, b.answers, b.comment ?? null, req.user!.id);
    });
    rep.code(201);
    return r;
  });
  app.post('/api/crm/surveys/:id/invite', { preHandler: requirePerm('crm.complaints') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reservation_id: z.number().int().positive() }).parse(req.body);
    const r = await one<any>(getPool(), 'SELECT * FROM reservations WHERE id = $1 AND hotel_id = $2', [b.reservation_id, req.user!.hotelId]);
    if (!r) throw notFound('Réservation introuvable');
    return tx(async (c) => {
      const resp = await ensureSurvey(c, actorOf(req), id, r.id, r.guest_id);
      const g = await one<any>(c, 'SELECT * FROM guests WHERE id = $1', [r.guest_id]);
      const v = await varsFor(c, req.user!.hotelId, g, r.id, { survey_url: resp.url });
      const sent = resp.url ? await queueMessage(c, actorOf(req), { guest_id: g.id, purpose: 'transactional', kind: 'survey', subject: render('Votre avis sur votre séjour à {{hotel}}', v), body: render('Bonjour {{first_name}},\n\nMerci de prendre une minute pour nous donner votre avis : {{survey_url}}\n\n{{hotel}}', v), reservation_id: r.id }) : { skipped: 'contact' };
      return { token: resp.token, url: resp.url, sent: 'notification_id' in sent };
    });
  });

  // ===================================================== Modèles, segments, campagnes =====================================================
  const TplBody = z.object({ code: z.string().trim().min(2).max(40).regex(/^[a-z0-9_]+$/), name: z.string().trim().min(2).max(120), purpose: z.enum(['transactional', 'marketing']), channel: z.enum(['email', 'sms', 'whatsapp']).default('email'),
    language: z.enum(['fr', 'en', 'ar']).default('fr'), subject: z.string().trim().min(2).max(200), body: z.string().trim().min(5).max(8000), active: z.boolean().optional() });
  const checkTpl = (b: any) => { if (b.purpose === 'marketing' && b.body && !/\{\{\s*unsubscribe_url\s*\}\}/.test(b.body)) throw badRequest('Un message commercial doit contenir {{unsubscribe_url}} (désabonnement).'); };
  app.post('/api/crm/templates', { preHandler: requirePerm('crm.marketing') }, async (req, rep) => {
    const b = TplBody.parse(req.body);
    checkTpl(b);
    if (await one(getPool(), 'SELECT 1 FROM crm_templates WHERE hotel_id = $1 AND code = $2 AND language = $3', [req.user!.hotelId, b.code, b.language])) throw conflict('Modèle déjà existant pour cette langue.');
    rep.code(201);
    return one(getPool(), 'INSERT INTO crm_templates (hotel_id, code, name, purpose, channel, language, subject, body) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *', [req.user!.hotelId, b.code, b.name, b.purpose, b.channel, b.language, b.subject, b.body]);
  });
  app.patch('/api/crm/templates/:id', { preHandler: requirePerm('crm.marketing') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = TplBody.partial().omit({ code: true, language: true }).parse(req.body);
    const cur = await one<any>(getPool(), 'SELECT * FROM crm_templates WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!cur) throw notFound('Modèle introuvable');
    checkTpl({ ...cur, ...b });
    const keys = Object.keys(b).filter((k) => (b as any)[k] !== undefined);
    return one(getPool(), `UPDATE crm_templates SET ${keys.map((k, i) => `${k} = $${i + 2}`).join(', ') || 'name = name'} WHERE id = $1 RETURNING *`, [id, ...keys.map((k) => (b as any)[k])]);
  });
  const CriteriaZ = z.object({
    kinds: z.array(z.enum(['person', 'company', 'agency'])).optional(), statuses: z.array(z.enum(['standard', 'loyal', 'vip', 'company'])).optional(), min_stays: z.number().int().min(0).nullish(), max_stays: z.number().int().min(0).nullish(),
    min_spent: z.number().min(0).nullish(), max_spent: z.number().min(0).nullish(), countries: z.array(z.string().max(60)).optional(), languages: z.array(z.enum(['fr', 'en', 'ar'])).optional(), tiers: z.array(z.number().int()).optional(),
    members_only: z.boolean().optional(), inactive_days: z.number().int().min(1).nullish(), active_days: z.number().int().min(1).nullish(), preference: z.string().max(80).nullish(), has_email: z.boolean().optional(),
    marketing_consent: z.boolean().optional(), birthday_month: z.number().int().min(1).max(12).nullish(),
  });
  const clean = (c: any): Criteria => Object.fromEntries(Object.entries(c).filter(([, v]) => v !== null && v !== undefined && !(Array.isArray(v) && !v.length))) as Criteria;
  const shape = (rows: any[], contact: boolean) => rows.map((m) => ({ id: m.id, code: m.code, name: guestDisplayName(m), status: m.crm_status, country: m.country ?? m.nationality ?? '', language: m.language, stays: m.stays, last_stay: m.last_stay,
    spent: Number(m.spent), reachable: contact ? m.has_email && m.consent_email && !m.unsubscribed_at : undefined }));
  app.get('/api/crm/segments', { preHandler: needAny('crm.marketing', 'crm.reports') }, async (req) => {
    const rows = await q<any>(getPool(), 'SELECT * FROM crm_segments WHERE hotel_id = $1 ORDER BY name', [req.user!.hotelId]);
    return Promise.all(rows.map(async (s) => { const m = await segmentMembers(getPool(), req.user!.hotelId, s.criteria); return { ...s, count: m.length, reachable: m.filter((x) => x.has_email && x.consent_email && !x.unsubscribed_at).length }; }));
  });
  app.post('/api/crm/segments/preview', { preHandler: needAny('crm.marketing', 'crm.reports') }, async (req) => {
    const b = z.object({ criteria: CriteriaZ }).parse(req.body);
    const m = await segmentMembers(getPool(), req.user!.hotelId, clean(b.criteria));
    return { count: m.length, reachable: m.filter((x) => x.has_email && x.consent_email && !x.unsubscribed_at).length, sample: shape(m.slice(0, 50), true) };
  });
  app.post('/api/crm/segments', { preHandler: requirePerm('crm.marketing') }, async (req, rep) => {
    const b = z.object({ name: z.string().trim().min(2).max(120), criteria: CriteriaZ }).parse(req.body);
    rep.code(201);
    return one(getPool(), 'INSERT INTO crm_segments (hotel_id, name, criteria, created_by) VALUES ($1,$2,$3,$4) RETURNING *', [req.user!.hotelId, b.name, JSON.stringify(clean(b.criteria)), req.user!.id]);
  });
  app.patch('/api/crm/segments/:id', { preHandler: requirePerm('crm.marketing') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ name: z.string().trim().min(2).max(120).optional(), criteria: CriteriaZ.optional() }).parse(req.body);
    const r = await one(getPool(), 'UPDATE crm_segments SET name = COALESCE($3, name), criteria = COALESCE($4, criteria) WHERE id = $1 AND hotel_id = $2 RETURNING *', [id, req.user!.hotelId, b.name ?? null, b.criteria ? JSON.stringify(clean(b.criteria)) : null]);
    if (!r) throw notFound('Segment introuvable');
    return r;
  });
  app.get('/api/crm/segments/:id/members', { preHandler: needAny('crm.marketing', 'crm.reports') }, async (req) => {
    const { id } = Id.parse(req.params);
    const sg = await one<any>(getPool(), 'SELECT * FROM crm_segments WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!sg) throw notFound('Segment introuvable');
    return shape(await segmentMembers(getPool(), req.user!.hotelId, sg.criteria, 1000), true);
  });
  app.get('/api/crm/campaigns', { preHandler: needAny('crm.marketing', 'crm.reports') }, async (req) => {
    const rows = await q<any>(getPool(), `SELECT c.*, s.name AS segment, t.name AS template, t.language FROM crm_campaigns c JOIN crm_segments s ON s.id = c.segment_id JOIN crm_templates t ON t.id = c.template_id WHERE c.hotel_id = $1 ORDER BY c.id DESC`, [req.user!.hotelId]);
    return Promise.all(rows.map(async (c) => ({ ...c, stats: c.status === 'sent' ? await campaignStats(getPool(), c.id) : null })));
  });
  app.post('/api/crm/campaigns', { preHandler: requirePerm('crm.marketing') }, async (req, rep) => {
    const b = z.object({ name: z.string().trim().min(2).max(120), segment_id: z.number().int().positive(), template_id: z.number().int().positive(), scheduled_at: z.string().datetime({ offset: true }).nullish() }).parse(req.body);
    const [sg, t] = await Promise.all([one<any>(getPool(), 'SELECT 1 FROM crm_segments WHERE id = $1 AND hotel_id = $2', [b.segment_id, req.user!.hotelId]), one<any>(getPool(), 'SELECT * FROM crm_templates WHERE id = $1 AND hotel_id = $2', [b.template_id, req.user!.hotelId])]);
    if (!sg || !t) throw badRequest('Segment ou modèle inconnu.');
    if (t.purpose !== 'marketing') throw badRequest('Choisissez un modèle de type « marketing ».');
    rep.code(201);
    return one(getPool(), `INSERT INTO crm_campaigns (hotel_id, name, segment_id, template_id, status, scheduled_at, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [req.user!.hotelId, b.name, b.segment_id, b.template_id, b.scheduled_at ? 'scheduled' : 'draft', b.scheduled_at ?? null, req.user!.id]);
  });
  app.post('/api/crm/campaigns/:id/send', { preHandler: requirePerm('crm.marketing') }, async (req) => {
    const { id } = Id.parse(req.params);
    return tx((c) => sendCampaign(c, actorOf(req), id));
  });
  app.post('/api/crm/campaigns/:id/cancel', { preHandler: requirePerm('crm.marketing') }, async (req) => {
    const { id } = Id.parse(req.params);
    const r = await one(getPool(), `UPDATE crm_campaigns SET status = 'cancelled' WHERE id = $1 AND hotel_id = $2 AND status IN ('draft','scheduled') RETURNING id`, [id, req.user!.hotelId]);
    if (!r) throw conflict('Campagne déjà envoyée.');
    return { ok: true };
  });
  app.get('/api/crm/campaigns/:id', { preHandler: needAny('crm.marketing', 'crm.reports') }, async (req) => {
    const { id } = Id.parse(req.params);
    const c = await one<any>(getPool(), 'SELECT * FROM crm_campaigns WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!c) throw notFound('Campagne introuvable');
    return { ...c, stats: c.sent_at ? await campaignStats(getPool(), id) : null };
  });
  app.post('/api/crm/automations/run', { preHandler: requirePerm('crm.marketing') }, async (req) => tx((c) => runAutomations(c, actorOf(req))));

  // ===================================================== Confidentialité =====================================================
  app.get('/api/crm/clients/:id/export', { preHandler: requirePerm('crm.privacy') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const data = await exportGuestData(getPool(), req.user!.hotelId, id);
    await getPool().query(`INSERT INTO crm_privacy_requests (hotel_id, guest_id, kind, outcome, handled_by) VALUES ($1,$2,'access','Données exportées',$3)`, [req.user!.hotelId, id, req.user!.id]);
    await audit(getPool(), actorOf(req), 'privacy_export', 'guest', id, null, null);
    rep.header('content-type', 'application/json; charset=utf-8').header('content-disposition', `attachment; filename="donnees-client-${data.profile.code}.json"`);
    return rep.send(JSON.stringify(data, null, 2));
  });
  app.post('/api/crm/clients/:id/anonymize', { preHandler: requirePerm('crm.privacy') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(5).max(500) }).parse(req.body);
    await tx((c) => anonymize(c, actorOf(req), id, b.reason));
    return { ok: true };
  });
  app.get('/api/crm/privacy-requests', { preHandler: requirePerm('crm.privacy') }, async (req) =>
    q(getPool(), `SELECT r.*, g.code, u.full_name AS by_name FROM crm_privacy_requests r JOIN guests g ON g.id = r.guest_id LEFT JOIN users u ON u.id = r.handled_by WHERE r.hotel_id = $1 ORDER BY r.id DESC LIMIT 300`, [req.user!.hotelId]));

  // ===================================================== Rapports, paramètres =====================================================
  app.get('/api/crm/reports/:kind', { preHandler: requirePerm('crm.reports') }, async (req, rep) => {
    const { kind } = z.object({ kind: z.string() }).parse(req.params);
    const f = z.object({ from: zDate.optional(), to: zDate.optional(), format: z.enum(['json', 'pdf', 'xlsx', 'csv']).default('json') }).parse(req.query);
    if (!CRM_REPORTS[kind]) throw notFound('Rapport inconnu');
    const from = f.from ?? monthStart(today()), to = f.to ?? today();
    if (to < from) throw badRequest('Période invalide.');
    const r = await crmReport(getPool(), req.user!.hotelId, kind, from, to);
    if (f.format === 'json') return r;
    await audit(getPool(), actorOf(req), 'export', 'crm_report', null, null, { kind, from, to, format: f.format });
    return sendTable(rep, f.format, `crm-${kind}-${from}_${to}`, r.title, `Du ${from} au ${to}`, r.columns, r.rows, r.total, await hotelName(req.user!.hotelId));
  });
  app.get('/api/crm/settings', { preHandler: requirePerm('crm.view') }, async (req) => crmSettings(getPool(), req.user!.hotelId));
  app.put('/api/crm/settings', { preHandler: requirePerm('crm.manage') }, async (req) => {
    const b = z.object({
      loyal_min_stays: z.number().int().min(1).max(50), inactive_days: z.number().int().min(30).max(3650),
      loyalty: z.object({ enabled: z.boolean(), amount_per_point: z.number().min(1).max(1e6), min_nights: z.number().int().min(0).max(30), expiry_months: z.number().int().min(0).max(120), enrollment_bonus: z.number().int().min(0).max(1e6), restaurant: z.boolean() }),
      complaint_sla_hours: z.object({ urgent: z.number().min(1), high: z.number().min(1), normal: z.number().min(1), low: z.number().min(1) }),
      automations: z.object({ thanks: z.boolean(), pre_arrival_days: z.number().int().min(0).max(30), post_stay_survey: z.boolean(), birthday: z.boolean() }),
      public_url: z.string().trim().max(200).refine((v) => !v || /^https?:\/\/[^\s]+$/.test(v), 'Adresse invalide (http://…)'),
    }).parse(req.body);
    const cur = await crmSettings(getPool(), req.user!.hotelId);
    await getPool().query(`INSERT INTO settings (hotel_id, key, value) VALUES ($1,'crm',$2) ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value`, [req.user!.hotelId, JSON.stringify(b)]);
    await audit(getPool(), actorOf(req), 'update', 'settings', 'crm', cur, b);
    return b;
  });

  // ===================================================== Pages publiques (lien envoyé au client) =====================================================
  app.get('/p/unsubscribe/:token', async (req, rep) => {
    const { token } = z.object({ token: z.string().min(10).max(64) }).parse(req.params);
    const g = await one<any>(getPool(), 'SELECT * FROM guests WHERE unsubscribe_token = $1', [token]);
    rep.header('content-type', 'text/html; charset=utf-8');
    if (!g) return rep.code(404).send(page('Lien invalide', '<h1>Lien invalide</h1><p>Ce lien de désabonnement n\'est pas reconnu.</p>'));
    if (g.consent_email || !g.unsubscribed_at) {
      await getPool().query(`UPDATE guests SET consent_email = false, consent_sms = false, unsubscribed_at = now(), consent_updated_at = now() WHERE id = $1`, [g.id]);
      await getPool().query(`UPDATE crm_campaign_recipients SET status = 'unsubscribed' WHERE guest_id = $1 AND status IN ('queued','sent')`, [g.id]);
      await getPool().query(`INSERT INTO crm_privacy_requests (hotel_id, guest_id, kind, details, outcome) VALUES ($1,$2,'consent_withdrawal','Lien de désabonnement','Désabonné des communications commerciales')`, [g.hotel_id, g.id]);
      await audit(getPool(), { userId: null, hotelId: g.hotel_id, deviceId: null, ip: req.ip } as any, 'unsubscribe', 'guest', g.id, null, null);
    }
    const h = await one<any>(getPool(), 'SELECT name FROM hotels WHERE id = $1', [g.hotel_id]);
    return rep.send(page('Désabonnement', `<h1>${esc(h?.name ?? '')}</h1><p class="ok">Vous ne recevrez plus nos offres commerciales.</p><p>Les messages liés à vos réservations (confirmation, facture) restent envoyés.</p>`));
  });
  app.get('/p/survey/:token', async (req, rep) => {
    const { token } = z.object({ token: z.string().min(10).max(64) }).parse(req.params);
    const r = await one<any>(getPool(), 'SELECT r.*, s.questions, s.name, h.name AS hotel FROM crm_survey_responses r JOIN crm_surveys s ON s.id = r.survey_id JOIN hotels h ON h.id = r.hotel_id WHERE r.token = $1', [token]);
    rep.header('content-type', 'text/html; charset=utf-8');
    if (!r) return rep.code(404).send(page('Questionnaire', '<h1>Lien invalide</h1>'));
    if (r.completed_at) return rep.send(page(r.name, `<h1>${esc(r.hotel)}</h1><p class="ok">Merci, votre avis a bien été enregistré.</p>`));
    const qs = (r.questions as any[]).map((x) => {
      const opts = x.type === 'rating' ? [1, 2, 3, 4, 5] : x.type === 'nps' ? [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10] : x.type === 'yesno' ? ['Oui', 'Non'] : null;
      return `<label>${esc(x.label)}</label>${opts ? `<div class="r" data-q="${esc(x.id)}">${opts.map((o) => `<button type="button" data-v="${o === 'Oui' ? 'true' : o === 'Non' ? 'false' : o}">${o}${x.type === 'rating' ? ' ★' : ''}</button>`).join('')}</div>` : `<textarea data-q="${esc(x.id)}"></textarea>`}`;
    }).join('');
    return rep.send(page(r.name, `<h1>${esc(r.hotel)}</h1><p>${esc(r.name)}</p><form id="f">${qs}<label>Commentaire</label><textarea id="c"></textarea><button class="send" type="submit">Envoyer</button></form><p id="m"></p>
<script>const a={};document.querySelectorAll('.r').forEach(d=>d.querySelectorAll('button').forEach(b=>b.onclick=()=>{d.querySelectorAll('button').forEach(x=>x.classList.remove('on'));b.classList.add('on');a[d.dataset.q]=b.dataset.v;}));
document.getElementById('f').onsubmit=async e=>{e.preventDefault();document.querySelectorAll('textarea[data-q]').forEach(t=>{if(t.value)a[t.dataset.q]=t.value});
const r=await fetch(location.pathname,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({answers:a,comment:document.getElementById('c').value})});const j=await r.json();
if(r.ok){document.getElementById('f').remove();document.getElementById('m').innerHTML='<span class="ok">Merci pour votre avis !</span>'}else document.getElementById('m').textContent=j.message||'Erreur';};</script>`));
  });
  app.post('/p/survey/:token', { config: { rateLimit: { max: 10, timeWindow: '1 minute' } } as any }, async (req) => {
    const { token } = z.object({ token: z.string().min(10).max(64) }).parse(req.params);
    const b = z.object({ answers: z.record(z.string(), z.any()), comment: z.string().max(2000).nullish() }).parse(req.body);
    return submitSurvey(getPool(), token, b.answers, b.comment ?? null, null);
  });
  void refreshStatus; void TZ;
}
