import { fileURLToPath } from 'node:url';
import type { FastifyInstance } from 'fastify';
import { createReadStream, existsSync, mkdirSync } from 'node:fs';
import { unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { config } from '../config.js';
import { getPool, one, q, tx } from '../db/pool.js';
import { audit } from '../lib/audit.js';
import { actorOf, requireAuth, requirePerm } from '../lib/auth.js';
import { isDate, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { checkPlan, loadPricing, priceStay } from '../services/pricing.js';
import {
  ROOM_STATUS_SQL, createBlock, createRoom, deactivateRoom, reactivateRoom, releaseBlock, roomDetail, syncOutOfService, updateRoom,
} from '../services/rooms.js';

const zDate = z.string().refine(isDate, 'Date invalide');
const Id = z.object({ id: z.coerce.number().int().positive() });
const str = (max = 200) => z.string().max(max);

const RoomBody = z.object({
  number: str(20).optional(), floor_id: z.number().int().positive().optional(), room_type_id: z.number().int().positive().optional(),
  capacity: z.number().int().min(1).max(20).nullable().optional(), beds: z.number().int().min(1).max(20).nullable().optional(),
  description: str(2000).nullable().optional(), features: z.array(str(60)).max(30).optional(), amenity_ids: z.array(z.number().int()).max(80).optional(),
  rate_supplement: z.number().min(-1_000_000).max(1_000_000).optional(), sort_order: z.number().int().optional(), notes: str(1000).nullable().optional(),
});
const TypeBody = z.object({
  code: str(12).regex(/^[A-Za-z0-9_-]+$/, 'Code : lettres et chiffres uniquement').optional(), name: str(60).optional(), category: str(40).optional(),
  description: str(2000).nullable().optional(), capacity: z.number().int().min(1).max(20).optional(), max_adults: z.number().int().min(1).max(20).optional(),
  max_children: z.number().int().min(0).max(20).optional(), beds: z.number().int().min(1).max(20).optional(), bed_type: str(80).nullable().optional(),
  area_m2: z.number().positive().max(10000).nullable().optional(), base_rate: z.number().min(0).max(10_000_000).optional(),
  weekend_rate: z.number().min(0).max(10_000_000).nullable().optional(), child_rate: z.number().min(0).max(1_000_000).optional(),
  color: str(20).nullable().optional(), sort_order: z.number().int().optional(), amenity_ids: z.array(z.number().int()).max(80).optional(),
});

const UPLOAD_DIR = process.env.UPLOAD_DIR ?? fileURLToPath(new URL('../../data/uploads', import.meta.url));

export async function roomsAdminRoutes(app: FastifyInstance) {
  // ============ Chambres ============
  app.get('/api/rooms/manage', { preHandler: requirePerm('rooms.view') }, async (req) => {
    const qs = z.object({
      search: str(40).optional(), floor_id: z.coerce.number().int().optional(), building_id: z.coerce.number().int().optional(),
      room_type_id: z.coerce.number().int().optional(), status: str(30).optional(), hk: str(20).optional(), include_inactive: z.enum(['true', 'false']).optional(),
    }).parse(req.query);
    const t = today();
    const rows = await q<any>(
      getPool(),
      `SELECT * FROM (
         SELECT r.id, r.number, r.active, r.hk_status, r.out_of_service, r.oos_reason, r.description, r.features, r.rate_supplement, r.sort_order,
                r.deactivation_reason, COALESCE(r.capacity, t.capacity) AS capacity, COALESCE(r.beds, t.beds) AS beds,
                t.id AS type_id, t.name AS type_name, t.code AS type_code, t.category, t.base_rate, t.area_m2, t.bed_type,
                f.id AS floor_id, f.number AS floor, f.name AS floor_name, b.id AS building_id, b.name AS building_name,
                ${ROOM_STATUS_SQL.replaceAll('$D', '$2')} AS status,
                (SELECT min(p.id) FROM photos p WHERE p.owner_type = 'room' AND p.owner_id = r.id) AS photo_id,
                (SELECT count(*) FROM room_amenities ra WHERE ra.room_id = r.id)::int AS amenity_count,
                (SELECT json_build_object('rr_id', rr.id, 'reservation_id', rr.reservation_id, 'check_out', rr.check_out,
                        'guest', COALESCE(NULLIF(trim(coalesce(og.last_name,'') || ' ' || coalesce(og.first_name,'')), ''), coalesce(g.company_name, trim(coalesce(g.last_name,'') || ' ' || coalesce(g.first_name,'')))))
                   FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id JOIN reservations res ON res.id = rr.reservation_id
                   JOIN guests g ON g.id = res.guest_id LEFT JOIN guests og ON og.id = rr.guest_id
                  WHERE s.room_id = r.id AND s.checked_out_at IS NULL LIMIT 1) AS current,
                (SELECT min(rr.check_in) FROM reservation_rooms rr WHERE rr.room_id = r.id AND rr.status IN ('pending','confirmed') AND rr.check_in >= $2) AS next_arrival
           FROM rooms r JOIN room_types t ON t.id = r.room_type_id JOIN floors f ON f.id = r.floor_id JOIN buildings b ON b.id = f.building_id
          WHERE r.hotel_id = $1 AND ($3::boolean OR r.active)
            AND ($4::text IS NULL OR r.number ILIKE $4) AND ($5::int IS NULL OR f.id = $5) AND ($6::int IS NULL OR b.id = $6) AND ($7::int IS NULL OR t.id = $7)
            AND ($9::text IS NULL OR r.hk_status = $9)
       ) x WHERE ($8::text IS NULL OR x.status = $8)
       ORDER BY x.building_name, x.floor, length(x.number), x.number`,
      [req.user!.hotelId, t, qs.include_inactive === 'true', qs.search?.trim() ? `%${qs.search.trim()}%` : null, qs.floor_id ?? null, qs.building_id ?? null,
        qs.room_type_id ?? null, qs.status ?? null, qs.hk ?? null],
    );
    return rows;
  });

  app.get('/api/rooms/:id', { preHandler: requirePerm('rooms.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    return roomDetail(getPool(), req.user!.hotelId, id);
  });

  app.post('/api/rooms', { preHandler: requirePerm('rooms.manage') }, async (req, rep) => {
    const b = RoomBody.parse(req.body);
    const r = await tx((c) => createRoom(c, actorOf(req), b));
    rep.code(201);
    return r;
  });

  app.patch('/api/rooms/:id', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    return tx((c) => updateRoom(c, actorOf(req), id, RoomBody.parse(req.body)));
  });

  app.post('/api/rooms/:id/deactivate', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(2).max(300) }).parse(req.body);
    await tx((c) => deactivateRoom(c, actorOf(req), id, b.reason));
    return { ok: true };
  });

  app.post('/api/rooms/:id/reactivate', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    await tx((c) => reactivateRoom(c, actorOf(req), id));
    return { ok: true };
  });

  // ============ Blocages / maintenance ============
  app.post('/api/rooms/:id/blocks', { preHandler: requirePerm('maintenance.manage') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({
      start_date: zDate, end_date: zDate.nullable().optional(), reason: z.string().trim().min(2).max(300),
      kind: z.enum(['out_of_service', 'maintenance']).optional(), priority: z.enum(['low', 'normal', 'high', 'urgent']).optional(),
    }).parse(req.body);
    const r = await tx((c) => createBlock(c, actorOf(req), id, b));
    rep.code(201);
    return r;
  });

  app.post('/api/room-blocks/:id/release', { preHandler: requirePerm('maintenance.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ resolution: str(500).nullable().optional(), needs_cleaning: z.boolean().optional() }).parse(req.body ?? {});
    await tx((c) => releaseBlock(c, actorOf(req), id, b));
    return { ok: true };
  });

  app.post('/api/rooms/:id/tickets', { preHandler: requirePerm('maintenance.manage') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ title: z.string().trim().min(2).max(200), description: str(2000).nullable().optional(), priority: z.enum(['low', 'normal', 'high', 'urgent']).default('normal'), category: str(40).default('other') }).parse(req.body);
    const t = await tx(async (c) => {
      if (!(await one(c, 'SELECT 1 FROM rooms WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]))) throw notFound('Chambre introuvable');
      const row = await one<any>(c, `INSERT INTO maintenance_tickets (room_id, title, description, priority, category, reported_by, source) VALUES ($1,$2,$3,$4,$5,$6,'reception') RETURNING *`,
        [id, b.title, b.description ?? null, b.priority, b.category, req.user!.id]);
      await audit(c, actorOf(req), 'incident', 'room', id, null, { ticket_id: row.id, title: b.title });
      return row;
    });
    rep.code(201);
    return t;
  });

  app.post('/api/tickets/:id/:action', { preHandler: requirePerm('maintenance.manage') }, async (req) => {
    const { id, action } = z.object({ id: z.coerce.number().int(), action: z.enum(['start', 'resolve', 'cancel']) }).parse(req.params);
    const b = z.object({ resolution: str(1000).nullable().optional() }).parse(req.body ?? {});
    await tx(async (c) => {
      const tk = await one<any>(c, `SELECT m.* FROM maintenance_tickets m WHERE m.id = $1 FOR UPDATE OF m`, [id]);
      if (!tk || tk.hotel_id !== req.user!.hotelId) throw notFound('Ticket introuvable');
      if (['resolved', 'closed', 'cancelled'].includes(tk.status)) throw conflict('Ticket déjà clos.');
      const st = action === 'start' ? 'in_progress' : action === 'resolve' ? 'resolved' : 'cancelled';
      await c.query(`UPDATE maintenance_tickets SET status = $2, resolution = COALESCE($3, resolution),
                       resolved_at = CASE WHEN $2 IN ('resolved','cancelled') THEN now() ELSE resolved_at END,
                       resolved_by = CASE WHEN $2 IN ('resolved','cancelled') THEN $4 ELSE resolved_by END,
                       started_at = CASE WHEN $2 = 'in_progress' THEN COALESCE(started_at, now()) ELSE started_at END, updated_at = now() WHERE id = $1`, [id, st, b.resolution ?? null, req.user!.id]);
      if (st !== 'in_progress') {
        const blocks = await q<any>(c, `SELECT id FROM room_blocks WHERE ticket_id = $1 AND status = 'active'`, [id]);
        for (const bl of blocks) await releaseBlock(c, actorOf(req), bl.id, { resolution: b.resolution ?? null });
      }
      await audit(c, actorOf(req), `ticket_${action}`, 'room', tk.room_id, { status: tk.status }, { status: st, ticket_id: id });
    });
    return { ok: true };
  });

  // ============ Types de chambres ============
  app.get('/api/room-types/manage', { preHandler: requirePerm('rooms.view') }, async (req) => {
    return q(getPool(), `SELECT t.*,
        (SELECT count(*) FROM rooms r WHERE r.room_type_id = t.id AND r.active)::int AS room_count,
        (SELECT coalesce(json_agg(a.amenity_id), '[]') FROM room_type_amenities a WHERE a.room_type_id = t.id) AS amenity_ids,
        (SELECT min(p.id) FROM photos p WHERE p.owner_type = 'room_type' AND p.owner_id = t.id) AS photo_id
      FROM room_types t WHERE t.hotel_id = $1 ORDER BY t.active DESC, t.sort_order, t.name`, [req.user!.hotelId]);
  });

  app.post('/api/room-types', { preHandler: requirePerm('rooms.manage') }, async (req, rep) => {
    const b = TypeBody.parse(req.body);
    if (!b.code || !b.name || b.base_rate === undefined || !b.capacity) throw badRequest('Code, nom, capacité et tarif de base obligatoires.');
    const r = await tx(async (c) => {
      const row = await one<any>(c, `INSERT INTO room_types (hotel_id, code, name, category, description, capacity, max_adults, max_children, beds, bed_type, area_m2,
                                       base_rate, weekend_rate, child_rate, color, sort_order)
                                     VALUES ($1,upper($2),$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING *`,
        [req.user!.hotelId, b.code, b.name, b.category ?? 'Standard', b.description ?? null, b.capacity, b.max_adults ?? b.capacity, b.max_children ?? 0,
          b.beds ?? 1, b.bed_type ?? null, b.area_m2 ?? null, b.base_rate, b.weekend_rate ?? null, b.child_rate ?? 0, b.color ?? null, b.sort_order ?? 0]);
      if (b.amenity_ids) await c.query(`INSERT INTO room_type_amenities (room_type_id, amenity_id) SELECT $1, id FROM amenities WHERE hotel_id = $2 AND id = ANY($3::int[])`, [row.id, req.user!.hotelId, b.amenity_ids]);
      await audit(c, actorOf(req), 'create', 'room_type', row.id, null, row);
      return row;
    });
    rep.code(201);
    return r;
  });

  app.patch('/api/room-types/:id', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = TypeBody.parse(req.body);
    return tx(async (c) => {
      const before = await one<any>(c, 'SELECT * FROM room_types WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!before) throw notFound('Type introuvable');
      if (b.capacity !== undefined && b.capacity < before.capacity) {
        const over = await q<any>(c, `SELECT DISTINCT res.code FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id JOIN rooms r ON r.id = rr.room_id
                                       WHERE r.room_type_id = $1 AND r.capacity IS NULL AND rr.status IN ('pending','confirmed','checked_in') AND rr.check_out > $2
                                         AND rr.adults + rr.children > $3`, [id, today(), b.capacity]);
        if (over.length) throw conflict(`Capacité ${b.capacity} insuffisante pour : ${over.map((x) => x.code).join(', ')}.`);
      }
      const cols = ['code', 'name', 'category', 'description', 'capacity', 'max_adults', 'max_children', 'beds', 'bed_type', 'area_m2', 'base_rate', 'weekend_rate', 'child_rate', 'color', 'sort_order'] as const;
      const sets: string[] = [];
      const vals: unknown[] = [id];
      for (const k of cols) if (b[k] !== undefined) { vals.push(k === 'code' ? String(b[k]).toUpperCase() : b[k]); sets.push(`${k} = $${vals.length}`); }
      if (sets.length) await c.query(`UPDATE room_types SET ${sets.join(', ')} WHERE id = $1`, vals);
      if (b.amenity_ids) {
        await c.query('DELETE FROM room_type_amenities WHERE room_type_id = $1', [id]);
        await c.query(`INSERT INTO room_type_amenities (room_type_id, amenity_id) SELECT $1, id FROM amenities WHERE hotel_id = $2 AND id = ANY($3::int[])`, [id, req.user!.hotelId, b.amenity_ids]);
      }
      const after = await one<any>(c, 'SELECT * FROM room_types WHERE id = $1', [id]);
      await audit(c, actorOf(req), 'update', 'room_type', id, before, after);
      return after;
    });
  });

  app.post('/api/room-types/:id/:action', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id, action } = z.object({ id: z.coerce.number().int(), action: z.enum(['deactivate', 'activate']) }).parse(req.params);
    await tx(async (c) => {
      const t = await one<any>(c, 'SELECT * FROM room_types WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!t) throw notFound('Type introuvable');
      if (action === 'deactivate') {
        const n = await one<any>(c, 'SELECT count(*)::int AS n FROM rooms WHERE room_type_id = $1 AND active', [id]);
        if (n.n) throw conflict(`${n.n} chambre(s) active(s) utilisent ce type : changez-les de catégorie d'abord.`);
      }
      await c.query('UPDATE room_types SET active = $2 WHERE id = $1', [id, action === 'activate']);
      await audit(c, actorOf(req), action, 'room_type', id, { active: t.active }, { active: action === 'activate' });
    });
    return { ok: true };
  });

  // ============ Bâtiments & étages ============
  app.get('/api/buildings', { preHandler: requirePerm('rooms.view') }, async (req) =>
    q(getPool(), `SELECT b.*, (SELECT count(*) FROM floors f WHERE f.building_id = b.id)::int AS floor_count FROM buildings b WHERE b.hotel_id = $1 ORDER BY b.code`, [req.user!.hotelId]));

  app.post('/api/buildings', { preHandler: requirePerm('rooms.manage') }, async (req, rep) => {
    const b = z.object({ code: str(10).min(1), name: str(80).min(2), description: str(500).nullable().optional() }).parse(req.body);
    const r = await tx(async (c) => {
      const row = await one<any>(c, `INSERT INTO buildings (hotel_id, code, name, description) VALUES ($1,upper($2),$3,$4) RETURNING *`, [req.user!.hotelId, b.code, b.name, b.description ?? null]);
      await audit(c, actorOf(req), 'create', 'building', row.id, null, row);
      return row;
    });
    rep.code(201);
    return r;
  });

  app.patch('/api/buildings/:id', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ code: str(10).min(1).optional(), name: str(80).min(2).optional(), description: str(500).nullable().optional() }).parse(req.body);
    return tx(async (c) => {
      const before = await one<any>(c, 'SELECT * FROM buildings WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
      if (!before) throw notFound('Bâtiment introuvable');
      const row = await one<any>(c, `UPDATE buildings SET code = upper(COALESCE($2, code)), name = COALESCE($3, name), description = COALESCE($4, description) WHERE id = $1 RETURNING *`, [id, b.code ?? null, b.name ?? null, b.description ?? null]);
      await audit(c, actorOf(req), 'update', 'building', id, before, row);
      return row;
    });
  });

  app.delete('/api/buildings/:id', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    await tx(async (c) => {
      const n = await one<any>(c, 'SELECT count(*)::int AS n FROM floors WHERE building_id = $1', [id]);
      if (n.n) throw conflict('Ce bâtiment contient encore des étages.');
      const r = await one<any>(c, 'DELETE FROM buildings WHERE id = $1 AND hotel_id = $2 RETURNING *', [id, req.user!.hotelId]);
      if (!r) throw notFound('Bâtiment introuvable');
      await audit(c, actorOf(req), 'delete', 'building', id, r, null);
    });
    return { ok: true };
  });

  app.get('/api/floors/stats', { preHandler: requirePerm('rooms.view') }, async (req) => {
    const t = today();
    return q(
      getPool(),
      `SELECT f.id, f.number, f.name, f.description, f.building_id, b.name AS building_name,
              count(x.id)::int AS rooms,
              count(*) FILTER (WHERE x.status = 'available')::int AS available,
              count(*) FILTER (WHERE x.status = 'occupied')::int AS occupied,
              count(*) FILTER (WHERE x.status = 'reserved')::int AS reserved,
              count(*) FILTER (WHERE x.status = 'out_of_service')::int AS out_of_service,
              count(*) FILTER (WHERE x.status = 'maintenance')::int AS maintenance,
              count(*) FILTER (WHERE x.hk_status NOT IN ('clean','inspected'))::int AS dirty,
              COALESCE(sum(x.capacity), 0)::int AS beds_capacity
         FROM floors f JOIN buildings b ON b.id = f.building_id
         LEFT JOIN (SELECT r.id, r.floor_id, r.hk_status, COALESCE(r.capacity, t.capacity) AS capacity, ${ROOM_STATUS_SQL.replaceAll('$D', '$2')} AS status
                      FROM rooms r JOIN room_types t ON t.id = r.room_type_id WHERE r.active) x ON x.floor_id = f.id
        WHERE f.hotel_id = $1 GROUP BY f.id, b.name ORDER BY b.name, f.number`,
      [req.user!.hotelId, t],
    );
  });

  app.post('/api/floors', { preHandler: requirePerm('rooms.manage') }, async (req, rep) => {
    const b = z.object({ building_id: z.number().int().positive(), number: z.number().int().min(-5).max(200), name: str(60).min(1), description: str(500).nullable().optional() }).parse(req.body);
    const r = await tx(async (c) => {
      if (!(await one(c, 'SELECT 1 FROM buildings WHERE id = $1 AND hotel_id = $2', [b.building_id, req.user!.hotelId]))) throw badRequest('Bâtiment inconnu.');
      const row = await one<any>(c, `INSERT INTO floors (hotel_id, building_id, number, name, description) VALUES ($1,$2,$3,$4,$5) RETURNING *`, [req.user!.hotelId, b.building_id, b.number, b.name, b.description ?? null]);
      await audit(c, actorOf(req), 'create', 'floor', row.id, null, row);
      return row;
    });
    rep.code(201);
    return r;
  });

  app.patch('/api/floors/:id', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ building_id: z.number().int().positive().optional(), number: z.number().int().min(-5).max(200).optional(), name: str(60).min(1).optional(), description: str(500).nullable().optional() }).parse(req.body);
    return tx(async (c) => {
      const before = await one<any>(c, 'SELECT * FROM floors WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
      if (!before) throw notFound('Étage introuvable');
      const row = await one<any>(c, `UPDATE floors SET building_id = COALESCE($2, building_id), number = COALESCE($3, number), name = COALESCE($4, name), description = COALESCE($5, description) WHERE id = $1 RETURNING *`,
        [id, b.building_id ?? null, b.number ?? null, b.name ?? null, b.description ?? null]);
      await audit(c, actorOf(req), 'update', 'floor', id, before, row);
      return row;
    });
  });

  app.delete('/api/floors/:id', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    await tx(async (c) => {
      const n = await one<any>(c, 'SELECT count(*)::int AS n FROM rooms WHERE floor_id = $1', [id]);
      if (n.n) throw conflict(`Cet étage contient ${n.n} chambre(s) (y compris désactivées) : réaffectez-les avant de le supprimer.`);
      const r = await one<any>(c, 'DELETE FROM floors WHERE id = $1 AND hotel_id = $2 RETURNING *', [id, req.user!.hotelId]);
      if (!r) throw notFound('Étage introuvable');
      await audit(c, actorOf(req), 'delete', 'floor', id, r, null);
    });
    return { ok: true };
  });

  // ============ Équipements ============
  app.get('/api/amenities', { preHandler: requirePerm('rooms.view') }, async (req) =>
    q(getPool(), `SELECT a.*, (SELECT count(*) FROM room_amenities ra WHERE ra.amenity_id = a.id)::int AS room_count FROM amenities a WHERE a.hotel_id = $1 ORDER BY a.active DESC, a.builtin DESC, a.name_fr`, [req.user!.hotelId]));

  app.post('/api/amenities', { preHandler: requirePerm('rooms.manage') }, async (req, rep) => {
    const b = z.object({ name_fr: str(60).min(2), name_en: str(60).optional(), name_ar: str(60).optional(), icon: str(30).optional() }).parse(req.body);
    const code = b.name_fr.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 30) || `eq_${Date.now()}`;
    const r = await tx(async (c) => {
      const row = await one<any>(c, `INSERT INTO amenities (hotel_id, code, name_fr, name_en, name_ar, icon) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
        [req.user!.hotelId, code, b.name_fr, b.name_en || b.name_fr, b.name_ar || b.name_fr, b.icon ?? null]);
      await audit(c, actorOf(req), 'create', 'amenity', row.id, null, row);
      return row;
    });
    rep.code(201);
    return r;
  });

  app.patch('/api/amenities/:id', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ name_fr: str(60).min(2).optional(), name_en: str(60).optional(), name_ar: str(60).optional(), active: z.boolean().optional() }).parse(req.body);
    const row = await one<any>(getPool(), `UPDATE amenities SET name_fr = COALESCE($3, name_fr), name_en = COALESCE($4, name_en), name_ar = COALESCE($5, name_ar), active = COALESCE($6, active)
                                            WHERE id = $1 AND hotel_id = $2 RETURNING *`, [id, req.user!.hotelId, b.name_fr ?? null, b.name_en ?? null, b.name_ar ?? null, b.active ?? null]);
    if (!row) throw notFound('Équipement introuvable');
    return row;
  });

  // ============ Photos ============
  if (!existsSync(UPLOAD_DIR)) mkdirSync(UPLOAD_DIR, { recursive: true });
  // Droits par type de photo : chambres (gestion des chambres), inspection (contrôleur), objets trouvés (enregistrement)
  const PHOTO_PERM: Record<string, { write: string; read: string[] }> = {
    room: { write: 'rooms.manage', read: ['rooms.view'] }, room_type: { write: 'rooms.manage', read: ['rooms.view'] },
    inspection: { write: 'housekeeping.inspect', read: ['housekeeping.view'] }, menu_item: { write: 'restaurant.menu', read: ['restaurant.view'] }, lost_item: { write: 'lostfound.record', read: ['lostfound.record', 'lostfound.manage'] },
    equipment: { write: 'equipment.manage', read: ['maintenance.view'] }, ticket: { write: 'maintenance.report', read: ['maintenance.view', 'maintenance.report'] }, work_order: { write: 'maintenance.work', read: ['maintenance.view'] },
    employee: { write: 'hr.manage', read: ['hr.view', 'hr.manage', 'hr.salary', 'hr.self'] }, hr_document: { write: 'hr.manage', read: ['hr.manage', 'hr.self'] }, leave_request: { write: 'hr.self', read: ['hr.self', 'hr.team', 'hr.manage'] },
  };
  const OWNER_SQL: Record<string, string> = {
    room: 'SELECT 1 FROM rooms WHERE id = $1 AND hotel_id = $2', room_type: 'SELECT 1 FROM room_types WHERE id = $1 AND hotel_id = $2',
    inspection: 'SELECT 1 FROM hk_inspections i JOIN rooms r ON r.id = i.room_id WHERE i.id = $1 AND r.hotel_id = $2', lost_item: 'SELECT 1 FROM lost_items WHERE id = $1 AND hotel_id = $2', menu_item: 'SELECT 1 FROM rs_items WHERE id = $1 AND hotel_id = $2',
    equipment: 'SELECT 1 FROM equipment WHERE id = $1 AND hotel_id = $2', ticket: 'SELECT 1 FROM maintenance_tickets WHERE id = $1 AND hotel_id = $2', work_order: 'SELECT 1 FROM work_orders WHERE id = $1 AND hotel_id = $2',
    employee: 'SELECT 1 FROM employees WHERE id = $1 AND hotel_id = $2', hr_document: 'SELECT 1 FROM hr_documents WHERE id = $1 AND hotel_id = $2', leave_request: 'SELECT 1 FROM hr_leave_requests WHERE id = $1 AND hotel_id = $2',
  };
  /** Documents RH et justificatifs : l'employé n'accède qu'aux siens (et jamais aux documents confidentiels). */
  const hrOwnerOk = async (req: any, type: string, ownerId: number, write: boolean) => {
    if (!['hr_document', 'leave_request', 'employee'].includes(type)) return true;
    const p: Set<string> = req.user.perms;
    if (p.has('hr.manage') || (type === 'employee' && !write && (p.has('hr.view') || p.has('hr.salary')))) return true;
    const me = await one<any>(getPool(), 'SELECT employee_id FROM users WHERE id = $1', [req.user.id]);
    if (type === 'employee') return !write && me?.employee_id === ownerId;
    if (type === 'hr_document') return !write && !!(await one(getPool(), 'SELECT 1 FROM hr_documents WHERE id = $1 AND employee_id = $2 AND NOT confidential', [ownerId, me?.employee_id ?? -1]));
    const lr = await one<any>(getPool(), 'SELECT r.employee_id, e.department FROM hr_leave_requests r JOIN employees e ON e.id = r.employee_id WHERE r.id = $1', [ownerId]);
    if (lr?.employee_id === me?.employee_id) return true;
    return !write && p.has('hr.team');
  };
  const canRead = (perms: Set<string>, t: string) => (PHOTO_PERM[t]?.read ?? []).some((p) => perms.has(p));
  app.post('/api/photos', { preHandler: requireAuth }, async (req, rep) => {
    const file = await (req as any).file({ limits: { fileSize: 6 * 1024 * 1024 } });
    if (!file) throw badRequest('Aucun fichier reçu.');
    const ownerType = String(file.fields.owner_type?.value ?? '');
    const ownerId = Number(file.fields.owner_id?.value);
    if (!PHOTO_PERM[ownerType] || !ownerId) throw badRequest('Propriétaire de la photo invalide.');
    if (!req.user!.perms.has(PHOTO_PERM[ownerType].write)) throw forbidden(`Permission requise : ${PHOTO_PERM[ownerType].write}`);
    // documents PDF (notices, garanties, factures) acceptés pour les équipements et les ordres de travail
    const pdfOk = ['equipment', 'work_order', 'hr_document', 'leave_request'].includes(ownerType);
    const ext = ({ 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', ...(pdfOk ? { 'application/pdf': 'pdf' } : {}) } as Record<string, string>)[file.mimetype];
    if (!ext) throw badRequest(pdfOk ? 'Format accepté : JPEG, PNG, WebP ou PDF.' : 'Format accepté : JPEG, PNG ou WebP.');
    const buf: Buffer = await file.toBuffer();
    if (file.file.truncated) throw badRequest('Photo trop lourde (6 Mo maximum).');
    // Vérifie la signature réelle du fichier (le type déclaré par le navigateur ne suffit pas)
    const sig = buf.subarray(0, 12);
    const okSig = ext === 'pdf' ? sig.subarray(0, 5).toString() === '%PDF-' : ext === 'png' ? sig.subarray(0, 4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47]))
      : ext === 'jpg' ? sig[0] === 0xff && sig[1] === 0xd8 && sig[2] === 0xff
      : sig.subarray(0, 4).toString() === 'RIFF' && sig.subarray(8, 12).toString() === 'WEBP';
    if (!okSig) throw badRequest('Fichier image invalide ou corrompu.');
    if (!(await one(getPool(), OWNER_SQL[ownerType], [ownerId, req.user!.hotelId]))) throw notFound('Élément introuvable');
    if (!(await hrOwnerOk(req, ownerType, ownerId, true))) throw forbidden();
    const name = `${randomUUID()}.${ext}`;
    await writeFile(path.join(UPLOAD_DIR, name), buf);
    const row = await one<any>(getPool(), `INSERT INTO photos (hotel_id, owner_type, owner_id, filename, mime, size, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [req.user!.hotelId, ownerType, ownerId, name, file.mimetype, buf.length, req.user!.id]);
    await audit(getPool(), actorOf(req), 'add_photo', ownerType, ownerId, null, { photo_id: row.id });
    rep.code(201);
    return row;
  });

  app.get('/api/photos', { preHandler: requireAuth }, async (req) => {
    const b = z.object({ owner_type: z.enum(['room', 'room_type', 'inspection', 'lost_item', 'menu_item', 'equipment', 'ticket', 'work_order']), owner_id: z.coerce.number().int().positive() }).parse(req.query);
    if (!canRead(req.user!.perms, b.owner_type) || !(await hrOwnerOk(req, b.owner_type, b.owner_id, false))) throw forbidden();
    return q(getPool(), 'SELECT id, caption, sort_order, mime FROM photos WHERE hotel_id = $1 AND owner_type = $2 AND owner_id = $3 ORDER BY sort_order, id', [req.user!.hotelId, b.owner_type, b.owner_id]);
  });

  app.get('/api/photos/:id', { preHandler: requireAuth }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const p = await one<any>(getPool(), 'SELECT * FROM photos WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!p) throw notFound('Photo introuvable');
    if (!canRead(req.user!.perms, p.owner_type) || !(await hrOwnerOk(req, p.owner_type, p.owner_id, false))) throw forbidden();
    if (['employee', 'hr_document', 'leave_request'].includes(p.owner_type)) await audit(getPool(), actorOf(req), 'view_document', p.owner_type, p.owner_id, null, { photo_id: id });
    const file = path.join(UPLOAD_DIR, path.basename(p.filename));
    if (!existsSync(file)) throw notFound('Fichier photo absent du serveur');
    rep.header('content-type', p.mime);
    rep.header('cache-control', 'private, max-age=86400');
    return rep.send(createReadStream(file));
  });

  app.delete('/api/photos/:id', { preHandler: requireAuth }, async (req) => {
    const { id } = Id.parse(req.params);
    const cur = await one<any>(getPool(), 'SELECT owner_type FROM photos WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!cur) throw notFound('Photo introuvable');
    // une photo d'inspection, un justificatif ou un document RH est une preuve : jamais supprimé
    if (['leave_request', 'hr_document'].includes(cur.owner_type)) throw conflict('Document RH : suppression interdite (traçabilité).');
    if (cur.owner_type === 'inspection') throw conflict('Photo d\'inspection : suppression interdite (preuve).');
    const need = ({ lost_item: 'lostfound.manage', menu_item: 'restaurant.menu', equipment: 'equipment.manage', ticket: 'maintenance.supervise', work_order: 'maintenance.supervise', employee: 'hr.manage', hr_document: 'hr.manage', leave_request: 'hr.manage' } as Record<string, string>)[cur.owner_type] ?? 'rooms.manage';
    if (!req.user!.perms.has(need)) throw forbidden(`Permission requise : ${need}`);
    const p = await one<any>(getPool(), 'DELETE FROM photos WHERE id = $1 AND hotel_id = $2 RETURNING *', [id, req.user!.hotelId]);
    if (!p) throw notFound('Photo introuvable');
    await unlink(path.join(UPLOAD_DIR, path.basename(p.filename))).catch(() => {});
    await audit(getPool(), actorOf(req), 'remove_photo', p.owner_type, p.owner_id, { photo_id: id }, null);
    return { ok: true };
  });

  // ============ Tarifs ============
  const PlanBody = z.object({
    code: str(12).regex(/^[A-Za-z0-9_-]+$/).optional(), name: str(80).min(2).optional(),
    kind: z.enum(['standard', 'corporate', 'agency', 'group', 'negotiated', 'promo']).optional(),
    adjustment_type: z.enum(['none', 'percent', 'amount']).optional(), adjustment_value: z.number().min(-1_000_000).max(1_000_000).optional(),
    guest_id: z.number().int().positive().nullable().optional(), company_name: str(120).nullable().optional(),
    min_nights: z.number().int().min(1).max(365).optional(), valid_from: zDate.nullable().optional(), valid_to: zDate.nullable().optional(),
    description: str(500).nullable().optional(), active: z.boolean().optional(),
    prices: z.array(z.object({ room_type_id: z.number().int(), price: z.number().min(0).nullable() })).optional(),
  });

  app.get('/api/rate-plans', { preHandler: requirePerm('reservations.view') }, async (req) =>
    q(getPool(), `SELECT p.*, g.company_name, g.kind AS guest_kind,
        (SELECT coalesce(json_agg(json_build_object('room_type_id', x.room_type_id, 'price', x.price)), '[]') FROM rate_plan_prices x WHERE x.rate_plan_id = p.id) AS prices
      FROM rate_plans p LEFT JOIN guests g ON g.id = p.guest_id WHERE p.hotel_id = $1 ORDER BY p.active DESC, p.kind = 'standard' DESC, p.name`, [req.user!.hotelId]));

  const savePlan = async (c: any, req: any, id: number | null, b: z.infer<typeof PlanBody>) => {
    if (b.valid_from && b.valid_to && b.valid_to < b.valid_from) throw badRequest('Période de validité invalide.');
    let guestId = b.guest_id;
    if (b.company_name?.trim()) {
      const g = await one<any>(c, `SELECT id FROM guests WHERE hotel_id = $1 AND kind IN ('company','agency') AND lower(company_name) = lower($2)`, [req.user!.hotelId, b.company_name.trim()]);
      guestId = g ? g.id : (await one<any>(c, `INSERT INTO guests (hotel_id, kind, company_name) VALUES ($1,'company',$2) RETURNING id`, [req.user!.hotelId, b.company_name.trim()])).id;
    }
    let row: any;
    if (id === null) {
      if (!b.code || !b.name || !b.kind) throw badRequest('Code, nom et type de tarif obligatoires.');
      row = await one<any>(c, `INSERT INTO rate_plans (hotel_id, code, name, kind, adjustment_type, adjustment_value, guest_id, min_nights, valid_from, valid_to, description)
                               VALUES ($1,upper($2),$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
        [req.user!.hotelId, b.code, b.name, b.kind, b.adjustment_type ?? 'none', b.adjustment_value ?? 0, guestId ?? null, b.min_nights ?? 1, b.valid_from ?? null, b.valid_to ?? null, b.description ?? null]);
      await audit(c, actorOf(req), 'create', 'rate_plan', row.id, null, row);
    } else {
      const before = await one<any>(c, 'SELECT * FROM rate_plans WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!before) throw notFound('Tarif introuvable');
      const cols = ['code', 'name', 'kind', 'adjustment_type', 'adjustment_value', 'min_nights', 'valid_from', 'valid_to', 'description', 'active'] as const;
      const sets: string[] = [];
      const vals: unknown[] = [id];
      for (const k of cols) if ((b as any)[k] !== undefined) { vals.push(k === 'code' ? String(b[k]).toUpperCase() : (b as any)[k]); sets.push(`${k} = $${vals.length}`); }
      if (guestId !== undefined) { vals.push(guestId); sets.push(`guest_id = $${vals.length}`); }
      if (sets.length) await c.query(`UPDATE rate_plans SET ${sets.join(', ')} WHERE id = $1`, vals);
      row = await one<any>(c, 'SELECT * FROM rate_plans WHERE id = $1', [id]);
      await audit(c, actorOf(req), 'update', 'rate_plan', id, before, row);
    }
    if (b.prices) {
      await c.query('DELETE FROM rate_plan_prices WHERE rate_plan_id = $1', [row.id]);
      for (const p of b.prices) if (p.price !== null) await c.query(`INSERT INTO rate_plan_prices (rate_plan_id, room_type_id, price) SELECT $1, id, $3 FROM room_types WHERE id = $2 AND hotel_id = $4`, [row.id, p.room_type_id, p.price, req.user!.hotelId]);
    }
    return row;
  };
  app.post('/api/rate-plans', { preHandler: requirePerm('rooms.manage') }, async (req, rep) => {
    const r = await tx((c) => savePlan(c, req, null, PlanBody.parse(req.body)));
    rep.code(201);
    return r;
  });
  app.patch('/api/rate-plans/:id', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    return tx((c) => savePlan(c, req, id, PlanBody.parse(req.body)));
  });

  const SeasonBody = z.object({
    name: str(80).min(2), kind: z.enum(['high', 'low', 'event']), start_date: zDate, end_date: zDate, room_type_id: z.number().int().positive().nullable().optional(),
    adjustment_type: z.enum(['percent', 'amount', 'fixed']), adjustment_value: z.number().min(-1_000_000).max(10_000_000), active: z.boolean().optional(),
  });
  /** Deux périodes actives sur la même catégorie (ou toutes) ne peuvent pas se chevaucher : le prix serait ambigu. */
  const assertNoSeasonOverlap = async (c: any, hotelId: number, m: any, exceptId: number | null) => {
    if (m.active === false) return;
    const o = await one<any>(c, `SELECT name, start_date, end_date FROM rate_seasons
       WHERE hotel_id = $1 AND active AND id <> COALESCE($2, 0) AND room_type_id IS NOT DISTINCT FROM $3 AND start_date <= $5 AND end_date >= $4 LIMIT 1`,
      [hotelId, exceptId, m.room_type_id ?? null, m.start_date, m.end_date]);
    if (o) throw conflict(`Chevauchement avec la période « ${o.name} » (${o.start_date} → ${o.end_date}).`);
  };
  app.get('/api/rate-seasons', { preHandler: requirePerm('reservations.view') }, async (req) =>
    q(getPool(), `SELECT s.*, t.name AS room_type_name FROM rate_seasons s LEFT JOIN room_types t ON t.id = s.room_type_id WHERE s.hotel_id = $1 ORDER BY s.start_date DESC`, [req.user!.hotelId]));
  app.post('/api/rate-seasons', { preHandler: requirePerm('rooms.manage') }, async (req, rep) => {
    const b = SeasonBody.parse(req.body);
    if (b.end_date < b.start_date) throw badRequest('La date de fin doit être après la date de début.');
    if (b.adjustment_type === 'fixed' && b.adjustment_value < 0) throw badRequest('Prix fixe invalide.');
    const r = await tx(async (c) => {
      await assertNoSeasonOverlap(c, req.user!.hotelId, b, null);
      const row = await one<any>(c, `INSERT INTO rate_seasons (hotel_id, name, kind, start_date, end_date, room_type_id, adjustment_type, adjustment_value) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
        [req.user!.hotelId, b.name, b.kind, b.start_date, b.end_date, b.room_type_id ?? null, b.adjustment_type, b.adjustment_value]);
      await audit(c, actorOf(req), 'create', 'rate_season', row.id, null, row);
      return row;
    });
    rep.code(201);
    return r;
  });
  app.patch('/api/rate-seasons/:id', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = SeasonBody.partial().parse(req.body);
    return tx(async (c) => {
      const before = await one<any>(c, 'SELECT * FROM rate_seasons WHERE id = $1 AND hotel_id = $2 FOR UPDATE', [id, req.user!.hotelId]);
      if (!before) throw notFound('Saison introuvable');
      const m = { ...before, ...b };
      if (m.end_date < m.start_date) throw badRequest('La date de fin doit être après la date de début.');
      await assertNoSeasonOverlap(c, req.user!.hotelId, m, id);
      const row = await one<any>(c, `UPDATE rate_seasons SET name=$2, kind=$3, start_date=$4, end_date=$5, room_type_id=$6, adjustment_type=$7, adjustment_value=$8, active=$9 WHERE id = $1 RETURNING *`,
        [id, m.name, m.kind, m.start_date, m.end_date, m.room_type_id, m.adjustment_type, m.adjustment_value, m.active]);
      await audit(c, actorOf(req), 'update', 'rate_season', id, before, row);
      return row;
    });
  });
  app.delete('/api/rate-seasons/:id', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    await tx(async (c) => {
      const r = await one<any>(c, 'DELETE FROM rate_seasons WHERE id = $1 AND hotel_id = $2 RETURNING *', [id, req.user!.hotelId]);
      if (!r) throw notFound('Saison introuvable');
      await audit(c, actorOf(req), 'delete', 'rate_season', id, r, null);
    });
    return { ok: true };
  });

  /** Devis : prix nuit par nuit pour une ou plusieurs chambres (utilisé par le formulaire de réservation). */
  app.post('/api/rates/quote', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const b = z.object({
      check_in: zDate, check_out: zDate, meal_plan: z.enum(['RO', 'BB', 'HB', 'FB']).default('RO'), rate_plan_id: z.number().int().positive().nullable().optional(),
      payer_guest_id: z.number().int().nullable().optional(),
      rooms: z.array(z.object({ room_id: z.number().int(), adults: z.number().int().min(1).default(1), children: z.number().int().min(0).default(0) })).max(60),
    }).parse(req.body);
    if (b.check_out <= b.check_in) throw badRequest('Dates invalides.');
    const pool = getPool();
    const ctx = await loadPricing(pool, req.user!.hotelId);
    let planError: string | null = null;
    try { checkPlan(ctx, b.rate_plan_id ?? null, b.check_in, b.check_out, b.payer_guest_id ?? null, null); } catch (e: any) { planError = e.message; }
    const out = [];
    for (const r of b.rooms) {
      const room = await one<any>(pool, 'SELECT id, room_type_id, rate_supplement FROM rooms WHERE id = $1 AND hotel_id = $2', [r.room_id, req.user!.hotelId]);
      if (!room) continue;
      const type = await one<any>(pool, 'SELECT * FROM room_types WHERE id = $1', [room.room_type_id]);
      const s = priceStay(ctx, type, room, b.check_in, b.check_out, b.meal_plan, r.adults, r.children, planError ? null : b.rate_plan_id ?? null);
      out.push({ room_id: r.room_id, ...s });
    }
    return { rooms: out, plan_error: planError };
  });

  // ============ Synchronisation quotidienne ============
  app.post('/api/rooms/sync-status', { preHandler: requirePerm('rooms.manage') }, async (req) => {
    await syncOutOfService(getPool(), req.user!.hotelId);
    return { ok: true };
  });
}
