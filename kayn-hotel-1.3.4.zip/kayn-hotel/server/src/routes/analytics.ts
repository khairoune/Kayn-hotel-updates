/** Phase 12 — Rapports & statistiques : tableaux de bord analytiques, drill-down, rapports détaillés, exports, vues personnalisées. */
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { getPool, one, q } from '../db/pool.js';
import { audit } from '../lib/audit.js';
import { actorOf, requireAuth } from '../lib/auth.js';
import { isDate } from '../lib/dates.js';
import { badRequest, forbidden, notFound } from '../lib/errors.js';
import { config } from '../config.js';
import { SOURCE_LBL, OUTLET_LBL, RES_STATUS_LBL, type Ctx, type Filters, type Section } from '../services/analytics/core.js';
import { sectionCsv, sectionPdf, sectionXlsx, type Meta } from '../services/analytics/export.js';
import { assertDomain, canDomain, catalogList, DOMAINS, drillList, runCatalog, runDomain, runDrill } from '../services/analytics/index.js';
import { resolvePeriod, type Period } from '../services/analytics/period.js';
import { scopeOf } from '../services/hr.js';

const zDate = z.string().refine(isDate, 'Date invalide (AAAA-MM-JJ)');
const QS = z.object({
  preset: z.string().max(20).optional(), from: zDate.optional(), to: zDate.optional(), compare: z.enum(['prev', 'year', 'none']).optional(), group: z.enum(['day', 'week', 'month', 'year']).optional(),
  room_type_id: z.coerce.number().int().positive().optional(), floor_id: z.coerce.number().int().positive().optional(), source: z.string().max(30).optional(), status: z.string().max(30).optional(),
  outlet: z.string().max(30).optional(), category: z.string().max(60).optional(), department: z.string().max(60).optional(),
  fresh: z.coerce.boolean().optional(), page: z.coerce.number().int().min(1).max(100000).optional(), size: z.coerce.number().int().min(1).max(500).optional(), format: z.enum(['json', 'pdf', 'xlsx', 'csv']).optional(),
});
const needReports = async (req: FastifyRequest) => { await requireAuth(req, null as any); if (!req.user!.perms.has('reports.view')) throw forbidden('Permission requise : reports.view'); };
const fmtD = (d: string) => `${d.slice(8, 10)}/${d.slice(5, 7)}/${d.slice(0, 4)}`;

async function ctxOf(req: FastifyRequest, domain: string | null): Promise<{ c: Ctx; qs: z.infer<typeof QS> }> {
  const qs = QS.parse(req.query);
  let P: Period;
  try { P = resolvePeriod(qs, config.timezone); } catch (e: any) { throw badRequest(e.message); }
  const allowed = domain ? DOMAINS[domain]?.filters ?? [] : ['room_type_id', 'floor_id', 'source', 'status', 'outlet', 'category', 'department'];
  const F: Filters = {};
  for (const k of allowed) if ((qs as any)[k] !== undefined && (qs as any)[k] !== '') (F as any)[k] = (qs as any)[k];
  const h = await one<any>(getPool(), 'SELECT currency FROM hotels WHERE id = $1', [req.user!.hotelId]);
  return { c: { db: getPool(), hotelId: req.user!.hotelId, tz: config.timezone, P, F, perms: req.user!.perms, actor: actorOf(req), currency: h?.currency ?? 'DA' }, qs };
}
async function metaOf(req: FastifyRequest, c: Ctx, title: string): Promise<Meta> {
  const h = await one<any>(getPool(), 'SELECT name FROM hotels WHERE id = $1', [c.hotelId]);
  const f: string[] = [];
  const F = c.F;
  if (F.room_type_id) f.push(`Type : ${(await one<any>(getPool(), 'SELECT name FROM room_types WHERE id = $1', [F.room_type_id]))?.name ?? F.room_type_id}`);
  if (F.floor_id) f.push(`Étage : ${(await one<any>(getPool(), 'SELECT number FROM floors WHERE id = $1', [F.floor_id]))?.number ?? F.floor_id}`);
  if (F.source) f.push(`Canal : ${SOURCE_LBL[F.source] ?? F.source}`);
  if (F.status) f.push(`Statut : ${RES_STATUS_LBL[F.status] ?? F.status}`);
  if (F.outlet) f.push(`Point de vente : ${OUTLET_LBL[F.outlet] ?? F.outlet}`);
  if (F.category) f.push(`Catégorie : ${F.category}`);
  if (F.department) f.push(`Département : ${F.department}`);
  return {
    hotel: h?.name ?? 'Hôtel', title, period: `du ${fmtD(c.P.from)} au ${fmtD(c.P.to)}`, compare: c.P.pfrom && c.P.pto ? `du ${fmtD(c.P.pfrom)} au ${fmtD(c.P.pto)}` : null,
    currency: c.currency, filters: f, generatedBy: req.user!.fullName, tz: c.tz,
  };
}
async function sendFile(rep: FastifyReply, format: string, name: string, m: Meta, s: Section, extra?: any[]) {
  const safe = name.replace(/[^a-z0-9_-]/gi, '_');
  if (format === 'xlsx') return rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('content-disposition', `attachment; filename="${safe}.xlsx"`).send(await sectionXlsx(m, s, extra));
  if (format === 'csv') return rep.header('content-type', 'text/csv; charset=utf-8').header('content-disposition', `attachment; filename="${safe}.csv"`).send(sectionCsv(m, s, extra));
  return rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${safe}.pdf"`).send(await sectionPdf(m, s, extra));
}

export async function analyticsRoutes(app: FastifyInstance) {
  // ----------------------------------------------------- Méta : modules autorisés, filtres, rapports, vues
  app.get('/api/analytics/meta', { preHandler: needReports }, async (req) => {
    const db = getPool();
    const perms = req.user!.perms;
    const H = req.user!.hotelId;
    const domains = Object.entries(DOMAINS).filter(([k]) => canDomain(perms, k)).map(([key, d]) => ({ key, title: d.title, filters: d.filters, reports: catalogList(perms, key) }));
    const s = perms.has('hr.reports') ? await scopeOf(db, actorOf(req), perms) : null;
    const hrDepts = s ? await q<any>(db, `SELECT code, name FROM hr_departments WHERE hotel_id = $1 AND active ${s.all ? '' : 'AND code = ANY($2)'} ORDER BY sort_order, name`, s.all ? [H] : [H, s.departments]) : [];
    return {
      domains,
      drills: drillList().filter((d) => d.domain.some((x) => canDomain(perms, x))),
      options: {
        room_type_id: (await q<any>(db, 'SELECT id AS value, name AS label FROM room_types WHERE hotel_id = $1 AND active ORDER BY sort_order, name', [H])),
        floor_id: (await q<any>(db, `SELECT id AS value, COALESCE(name, 'Étage ' || number) AS label FROM floors WHERE hotel_id = $1 ORDER BY number`, [H])),
        source: Object.entries(SOURCE_LBL).map(([value, label]) => ({ value, label })),
        status: Object.entries(RES_STATUS_LBL).map(([value, label]) => ({ value, label })),
        outlet: Object.entries(OUTLET_LBL).map(([value, label]) => ({ value, label })),
        category: {
          restaurant: (await q<any>(db, 'SELECT id::text AS value, name AS label FROM rs_categories WHERE hotel_id = $1 AND active ORDER BY sort_order, name', [H])),
          housekeeping: [['checkout_clean', 'Ménage départ'], ['stayover', 'Recouche'], ['arrival_prep', 'Préparation arrivée'], ['deep_clean', 'Grand ménage'], ['inspection', 'Inspection'], ['turndown', 'Couverture'], ['other', 'Autre']].map(([value, label]) => ({ value, label })),
          stock: (await q<any>(db, `SELECT DISTINCT category AS value, category AS label FROM products WHERE hotel_id = $1 AND category IS NOT NULL AND category <> '' ORDER BY 1`, [H])),
          maintenance: [['hvac', 'Climatisation'], ['heating', 'Chauffage'], ['plumbing', 'Plomberie'], ['electrical', 'Électricité'], ['elevator', 'Ascenseur'], ['kitchen', 'Cuisine'], ['furniture', 'Mobilier'], ['it', 'Informatique'], ['fire_safety', 'Sécurité incendie'], ['other', 'Autre']].map(([value, label]) => ({ value, label })),
        },
        department: {
          finance: [['room', 'Hébergement'], ['restaurant', 'Restauration'], ['services', 'Services'], ['tax', 'Taxe de séjour']].map(([value, label]) => ({ value, label })),
          stock: [['restaurant', 'Restaurant'], ['bar', 'Bar'], ['housekeeping', 'Housekeeping'], ['maintenance', 'Maintenance'], ['reception', 'Réception'], ['admin', 'Administration'], ['other', 'Autre']].map(([value, label]) => ({ value, label })),
          hr: hrDepts.map((d) => ({ value: d.code, label: d.name })),
        },
      },
      role: req.user!.role,
      can_manage_roles: perms.has('reports.manage'),
      roles: perms.has('reports.manage') ? await q<any>(db, 'SELECT code, name FROM roles ORDER BY name', []) : [],
    };
  });

  // ----------------------------------------------------- Vues personnalisées (tableau de bord, filtres favoris, rapports enregistrés)
  app.get('/api/analytics/views', { preHandler: needReports }, async (req) => {
    return q<any>(getPool(), `SELECT v.*, (v.user_id IS NULL) AS role_view FROM report_views v WHERE v.hotel_id = $1 AND (v.user_id = $2 OR v.role_code = $3) ORDER BY v.kind, v.domain, v.role_code NULLS FIRST, v.name`,
      [req.user!.hotelId, req.user!.id, req.user!.role]);
  });
  const VB = z.object({
    kind: z.enum(['layout', 'filter', 'report']), domain: z.string().max(30), name: z.string().trim().min(1).max(80),
    config: z.record(z.string(), z.any()).refine((x) => JSON.stringify(x).length < 8000, 'Configuration trop volumineuse'), is_default: z.boolean().default(false), role_code: z.string().max(40).nullish(),
  });
  app.post('/api/analytics/views', { preHandler: needReports }, async (req) => {
    const b = VB.parse(req.body);
    if (b.domain !== '*' && !DOMAINS[b.domain]) throw badRequest('Module inconnu');
    if (b.domain !== '*') assertDomain(req.user!.perms, b.domain);
    if (b.role_code && !req.user!.perms.has('reports.manage')) throw forbidden('Seul un administrateur peut définir la vue d\'un rôle.');
    if (b.role_code && !(await one<any>(getPool(), 'SELECT 1 FROM roles WHERE code = $1', [b.role_code]))) throw badRequest('Rôle inconnu');
    const db = getPool();
    if (b.is_default && b.kind === 'layout') {
      if (b.role_code) await db.query(`UPDATE report_views SET is_default = false WHERE hotel_id = $1 AND role_code = $2 AND domain = $3 AND kind = 'layout'`, [req.user!.hotelId, b.role_code, b.domain]);
      else await db.query(`UPDATE report_views SET is_default = false WHERE hotel_id = $1 AND user_id = $2 AND domain = $3 AND kind = 'layout'`, [req.user!.hotelId, req.user!.id, b.domain]);
    }
    const v = await one<any>(db, `INSERT INTO report_views (hotel_id, user_id, role_code, kind, domain, name, config, is_default) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [req.user!.hotelId, b.role_code ? null : req.user!.id, b.role_code ?? null, b.kind, b.domain, b.name, JSON.stringify(b.config), b.is_default && b.kind === 'layout']);
    await audit(db, actorOf(req), 'create', 'report_view', v.id, null, { kind: b.kind, domain: b.domain, name: b.name, role: b.role_code ?? null });
    return v;
  });
  const own = async (req: FastifyRequest, id: number) => {
    const v = await one<any>(getPool(), 'SELECT * FROM report_views WHERE id = $1 AND hotel_id = $2', [id, req.user!.hotelId]);
    if (!v) throw notFound('Vue introuvable');
    if (v.user_id ? v.user_id !== req.user!.id : !req.user!.perms.has('reports.manage')) throw forbidden('Vous ne pouvez modifier que vos propres vues.');
    return v;
  };
  app.patch('/api/analytics/views/:id', { preHandler: needReports }, async (req) => {
    const { id } = z.object({ id: z.coerce.number().int().positive() }).parse(req.params);
    const v = await own(req, id);
    const b = VB.partial().omit({ kind: true, domain: true, role_code: true }).parse(req.body);
    const db = getPool();
    if (b.is_default && v.kind === 'layout') await db.query(`UPDATE report_views SET is_default = false WHERE hotel_id = $1 AND domain = $2 AND kind = 'layout' AND ${v.user_id ? 'user_id = $3' : 'role_code = $3'}`, [v.hotel_id, v.domain, v.user_id ?? v.role_code]);
    const r = await one<any>(db, `UPDATE report_views SET name = COALESCE($2, name), config = COALESCE($3, config), is_default = COALESCE($4, is_default), updated_at = now() WHERE id = $1 RETURNING *`,
      [id, b.name ?? null, b.config ? JSON.stringify(b.config) : null, b.is_default === undefined ? null : b.is_default && v.kind === 'layout']);
    await audit(db, actorOf(req), 'update', 'report_view', id, { name: v.name }, { name: r.name });
    return r;
  });
  app.delete('/api/analytics/views/:id', { preHandler: needReports }, async (req) => {
    const { id } = z.object({ id: z.coerce.number().int().positive() }).parse(req.params);
    const v = await own(req, id);
    await getPool().query('DELETE FROM report_views WHERE id = $1', [id]);
    await audit(getPool(), actorOf(req), 'delete', 'report_view', id, { name: v.name, kind: v.kind }, null);
    return { ok: true };
  });

  // ----------------------------------------------------- Détail d'un indicateur (drill-down)
  app.get('/api/analytics/drill/:key', { preHandler: needReports }, async (req, rep) => {
    const { key } = z.object({ key: z.string().max(40) }).parse(req.params);
    const { c, qs } = await ctxOf(req, null);
    const format = qs.format ?? 'json';
    const r = await runDrill(c, key, format === 'json' ? qs.page ?? 1 : 1, format === 'json' ? qs.size ?? 50 : 5000);
    if (format === 'json') return { ...r, period: c.P };
    await audit(getPool(), actorOf(req), 'export_report', 'analytics', null, null, { drill: key, format, from: c.P.from, to: c.P.to });
    return sendFile(rep, format, `detail-${key}-${c.P.from}_${c.P.to}`, await metaOf(req, c, r.title), { kpis: [], charts: [], tables: [{ key, title: r.title, columns: r.columns, rows: r.rows, total: r.total }] });
  });

  // ----------------------------------------------------- Rapports détaillés existants des modules
  app.get('/api/analytics/catalog/:domain/:kind', { preHandler: needReports }, async (req, rep) => {
    const { domain, kind } = z.object({ domain: z.string().max(30), kind: z.string().max(40) }).parse(req.params);
    const { c, qs } = await ctxOf(req, domain);
    const r = await runCatalog(c, domain, kind);
    const format = qs.format ?? 'json';
    if (format === 'json') {
      const size = qs.size ?? 100, pg = qs.page ?? 1;
      return { ...r, rows: r.rows.slice((pg - 1) * size, pg * size), count: r.rows.length, page: pg, page_size: size, period: c.P };
    }
    await audit(getPool(), actorOf(req), 'export_report', 'analytics', null, null, { domain, report: kind, format, from: c.P.from, to: c.P.to });
    return sendFile(rep, format, `${domain}-${kind}-${c.P.from}_${c.P.to}`, await metaOf(req, c, r.title), { kpis: [], charts: [], tables: [{ key: kind, title: r.title, columns: r.columns, rows: r.rows, total: r.total }] });
  });

  // ----------------------------------------------------- Tableau de bord d'un module (+ export complet)
  app.get('/api/analytics/:domain', { preHandler: needReports }, async (req) => {
    const { domain } = z.object({ domain: z.string().max(30) }).parse(req.params);
    const { c, qs } = await ctxOf(req, domain);
    const t0 = Date.now();
    const s = await runDomain(c, domain, !!qs.fresh);
    return { domain, title: DOMAINS[domain].title, period: c.P, filters: c.F, currency: c.currency, ...s, ms: Date.now() - t0 };
  });
  app.get('/api/analytics/:domain/export', { preHandler: needReports }, async (req, rep) => {
    const { domain } = z.object({ domain: z.string().max(30) }).parse(req.params);
    const { c, qs } = await ctxOf(req, domain);
    const s = await runDomain(c, domain, true);
    const format = qs.format && qs.format !== 'json' ? qs.format : 'pdf';
    await audit(getPool(), actorOf(req), 'export_report', 'analytics', null, null, { domain, format, from: c.P.from, to: c.P.to, filters: c.F });
    return sendFile(rep, format, `rapport-${domain}-${c.P.from}_${c.P.to}`, await metaOf(req, c, `Rapport — ${DOMAINS[domain].title}`), s);
  });
}
