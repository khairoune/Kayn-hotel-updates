import type { FastifyInstance, FastifyReply } from 'fastify';
import { z } from 'zod';
import { getPool, one, q, tx } from '../db/pool.js';
import { actorOf, requirePerm } from '../lib/auth.js';
import { isDate, monthStart, today } from '../lib/dates.js';
import { badRequest, conflict, forbidden } from '../lib/errors.js';
import {
  creditNote, invoiceDetail, manualInvoice, payInvoice, proforma, refundReservation, splitInvoice, stayInvoice, transferCharge,
} from '../services/billing.js';
import { addExpense, addIncome, addMovement, closeSession, openSession, sessionSummary, validateSession, voidEntry } from '../services/cash.js';
import { getSettings, guestDisplayName, TAX_CATEGORIES } from '../services/common.js';
import { invoicePdf, tableCsv, tablePdf, tableXlsx } from '../services/exports.js';
import { financeSummary, FIN_REPORTS, finReport, receivables, transactions } from '../services/finance.js';
import { folio } from '../services/frontoffice.js';
import { getReservation } from '../services/reservations.js';
import { findOpenSession } from '../services/billing.js';

const Id = z.object({ id: z.coerce.number().int().positive() });
const zDate = z.string().refine(isDate, 'Date invalide (AAAA-MM-JJ)');
const s = (n = 500) => z.string().trim().max(n).nullish();
const Amount = z.number().positive().max(100_000_000);
const Method = z.enum(['cash', 'card', 'cheque', 'transfer', 'company_account', 'online']);
const Period = z.object({ from: zDate.optional(), to: zDate.optional() });
const period = (qs: { from?: string; to?: string }) => ({ from: qs.from ?? monthStart(today()), to: qs.to ?? today() });
const GuestRef = z.object({ id: z.number().int().positive().optional(), kind: z.enum(['person', 'company', 'agency']).optional(), last_name: s(80), first_name: s(80), company_name: s(120), phone: s(40), address: s(200), nif: s(40) });

async function send(rep: FastifyReply, format: string, name: string, title: string, sub: string, cols: any[], rows: any[], total: any, hotel: string) {
  if (format === 'xlsx') {
    rep.header('content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('content-disposition', `attachment; filename="${name}.xlsx"`);
    return rep.send(await tableXlsx(title, sub, cols, rows, total));
  }
  if (format === 'csv') {
    rep.header('content-type', 'text/csv; charset=utf-8').header('content-disposition', `attachment; filename="${name}.csv"`);
    return rep.send(tableCsv(cols, rows, total));
  }
  rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${name}.pdf"`);
  return rep.send(await tablePdf(hotel, title, sub, cols, rows, total));
}
const hotelName = async (id: number) => (await one<any>(getPool(), 'SELECT name FROM hotels WHERE id = $1', [id]))?.name ?? 'Hôtel';

export async function billingRoutes(app: FastifyInstance) {
  // ===================================================== Factures =====================================================
  app.get('/api/invoices', { preHandler: requirePerm('invoices.view') }, async (req) => {
    const qs = z.object({
      search: z.string().max(80).default(''), type: z.enum(['invoice', 'proforma', 'credit_note']).optional(), status: z.string().max(20).optional(),
      from: zDate.optional(), to: zDate.optional(), page: z.coerce.number().int().min(1).default(1),
    }).parse(req.query);
    const size = 50;
    const rows = await q<any>(getPool(),
      `SELECT i.id, i.number, i.type, i.status, i.issued_at, i.total, i.tax_total, i.bill_to, i.reservation_id, r.code, i.credit_of_invoice_id, count(*) OVER() AS total_count,
              (SELECT number FROM invoices o WHERE o.id = i.credit_of_invoice_id) AS credit_of
         FROM invoices i LEFT JOIN reservations r ON r.id = i.reservation_id
        WHERE i.hotel_id = $1 AND ($2::text IS NULL OR i.type = $2) AND ($3::text IS NULL OR i.status = $3)
          AND ($4::date IS NULL OR (i.issued_at AT TIME ZONE 'Africa/Algiers')::date >= $4) AND ($5::date IS NULL OR (i.issued_at AT TIME ZONE 'Africa/Algiers')::date <= $5)
          AND ($6 = '' OR lower(i.number) LIKE $7 OR lower(coalesce(i.bill_to->>'name','')) LIKE $7 OR lower(coalesce(r.code,'')) LIKE $7)
        ORDER BY i.issued_at DESC, i.id DESC LIMIT ${size} OFFSET $8`,
      [req.user!.hotelId, qs.type ?? null, qs.status ?? null, qs.from ?? null, qs.to ?? null, qs.search.trim(), `%${qs.search.trim().toLowerCase()}%`, (qs.page - 1) * size]);
    return { total: Number(rows[0]?.total_count ?? 0), page: qs.page, page_size: size, rows: rows.map(({ total_count, ...x }) => ({ ...x, client: x.bill_to?.name ?? '' })) };
  });

  app.get('/api/invoices/:id', { preHandler: requirePerm('invoices.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    return invoiceDetail(getPool(), req.user!.hotelId, id);
  });

  app.get('/api/invoices/:id/pdf', { preHandler: requirePerm('invoices.view') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const inv = await invoiceDetail(getPool(), req.user!.hotelId, id);
    const qs = z.object({ paper: z.enum(['A4', 'thermal']).optional() }).parse(req.query);
    const d = (await getSettings(getPool(), req.user!.hotelId)).documents ?? {};
    // logo figé dans la facture (version au moment de l'émission), à défaut le logo actuel
    const logoId = inv.seller?.logo_id ?? null;
    const logo = d.show_logo === false || !logoId ? null : (await one<any>(getPool(), 'SELECT data FROM hotel_logos WHERE id = $1', [logoId]))?.data ?? null;
    rep.header('content-type', 'application/pdf').header('content-disposition', `inline; filename="${inv.number}.pdf"`);
    return rep.send(await invoicePdf(inv, { logo, paper: qs.paper ?? d.invoice_paper ?? 'A4', showFiscal: d.show_fiscal !== false, header: d.receipt_header || undefined }));
  });

  /** Facture de séjour (dossier terminé / annulé avec frais, sans facture active) */
  app.post('/api/reservations/:id/invoices', { preHandler: requirePerm('invoices.create') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const r = await tx(async (c) => {
      const res = await getReservation(c, req.user!.hotelId, id);
      await c.query('SELECT id FROM reservations WHERE id = $1 FOR UPDATE', [id]);
      if (!['checked_out', 'cancelled', 'no_show'].includes(res.status)) throw conflict('Séjour en cours : la facture finale est émise au check-out (utilisez une pro forma).');
      const active = await one(c, `SELECT number FROM invoices WHERE reservation_id = $1 AND type = 'invoice' AND status <> 'credited'`, [id]);
      if (active) throw conflict(`Facture déjà émise (${(active as any).number}) : faites un avoir avant d'en émettre une autre.`);
      return stayInvoice(c, actorOf(req), id, null, true);
    });
    rep.code(201);
    return r;
  });

  app.post('/api/reservations/:id/invoices/proforma', { preHandler: requirePerm('invoices.create') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ rr_ids: z.array(z.number().int()).optional() }).parse(req.body ?? {});
    const r = await tx((c) => proforma(c, actorOf(req), id, b.rr_ids?.length ? b.rr_ids : null));
    rep.code(201);
    return r;
  });

  app.post('/api/invoices/manual', { preHandler: requirePerm('invoices.create') }, async (req, rep) => {
    const b = z.object({
      guest: GuestRef, due_date: zDate.nullish(), notes: s(1000),
      lines: z.array(z.object({
        description: z.string().trim().min(2).max(200), category: z.enum([...TAX_CATEGORIES] as [string, ...string[]]),
        quantity: z.number().positive().max(100000), unit_price: z.number().min(0).max(100_000_000), discount: z.number().min(0).max(100_000_000).optional(), tax_rate: z.number().min(0).max(100).nullish(),
      })).min(1).max(100),
    }).parse(req.body);
    if (b.lines.some((l) => l.tax_rate != null) && !req.user!.perms.has('settings.manage')) throw forbidden('Seul un administrateur peut forcer un taux de TVA.');
    const r = await tx((c) => manualInvoice(c, actorOf(req), b as any));
    rep.code(201);
    return r;
  });

  app.post('/api/invoices/:id/credit-note', { preHandler: requirePerm('invoices.credit') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ mode: z.enum(['commercial', 'cancel_reissue']), reason: z.string().trim().min(3).max(300), amount: Amount.nullish() }).parse(req.body);
    const r = await tx((c) => creditNote(c, actorOf(req), id, b));
    rep.code(201);
    return r;
  });

  app.post('/api/invoices/:id/split', { preHandler: requirePerm('invoices.credit') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().max(300).default('Partage de la facture'), parts: z.array(z.object({ guest: GuestRef, percent: z.number().positive().max(100).optional(), amount: Amount.optional() })).min(2).max(20) }).parse(req.body);
    const r = await tx((c) => splitInvoice(c, actorOf(req), id, b.parts as any, b.reason));
    rep.code(201);
    return r;
  });

  app.post('/api/invoices/:id/payments', { preHandler: requirePerm('payments.create') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ amount: Amount, method: Method, reference: s(120), card_last4: z.string().regex(/^\d{4}$/).nullish(), card_brand: s(30) }).parse(req.body);
    const r = await tx((c) => payInvoice(c, actorOf(req), id, b as any));
    rep.code(201);
    return r;
  });

  // ===================================================== Folio =====================================================
  app.get('/api/reservations/:id/folio', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const { id } = Id.parse(req.params);
    const h = req.user!.hotelId;
    const res = await getReservation(getPool(), h, id);
    const active = res.rooms.filter((x: any) => !['cancelled', 'no_show'].includes(x.status) && !res.rooms.some((y: any) => y.moved_from_rr_id === x.id));
    const rooms = [];
    for (const rr of active) {
      const f = await folio(getPool(), h, rr.id);
      rooms.push({ rr_id: rr.id, room: rr.room_number, guest: rr.occupant_name ?? res.guest_name, status: rr.status, scope: f.scope, total: f.total, paid: f.paid - f.refunded, balance: f.balance });
    }
    const cats: Record<string, { label: string; total: number; count: number }> = {};
    const LBL: Record<string, string> = { room: 'Hébergement', breakfast: 'Petit-déjeuner', restaurant: 'Restaurant', minibar: 'Mini-bar', laundry: 'Blanchisserie', room_service: 'Room service', transfer: 'Transport', parking: 'Parking', service: 'Services', other: 'Autres', cancellation_fee: 'Frais d\'annulation', no_show_fee: 'Non-présentation', adjustment: 'Avoirs / ajustements' };
    cats.room = { label: LBL.room, total: Number(res.room_total), count: active.length };
    for (const c of res.charges.filter((x: any) => !x.void)) {
      const k = c.kind;
      cats[k] = cats[k] ?? { label: LBL[k] ?? k, total: 0, count: 0 };
      cats[k].total = Math.round((cats[k].total + Number(c.total)) * 100) / 100;
      cats[k].count++;
    }
    const others = await q<any>(getPool(), `SELECT r.id, r.code, rr.id AS rr_id, rm.number AS room, g.kind, g.last_name, g.first_name, g.company_name
        FROM reservation_rooms rr JOIN reservations r ON r.id = rr.reservation_id JOIN rooms rm ON rm.id = rr.room_id JOIN guests g ON g.id = COALESCE(rr.guest_id, r.guest_id)
       WHERE r.hotel_id = $1 AND rr.status = 'checked_in' ORDER BY length(rm.number), rm.number`, [h]);
    return {
      reservation_id: id, code: res.code, status: res.status, billing_mode: res.billing_mode, categories: Object.entries(cats).map(([k, v]) => ({ kind: k, ...v })),
      charges: res.charges, rooms, totals: { total: res.total, vat: res.vat_amount, tourist: res.tourist_tax_amount, discount: res.discount_total, paid: Number(res.paid) - Number(res.refunded), balance: res.balance },
      invoices: await q(getPool(), `SELECT id, number, type, status, total, issued_at, credit_of_invoice_id FROM invoices WHERE reservation_id = $1 ORDER BY id`, [id]),
      transfer_targets: others.map((o) => ({ reservation_id: o.id, rr_id: o.rr_id, label: `${o.room} · ${guestDisplayName(o)} (${o.code})` })),
    };
  });

  app.post('/api/charges/:id/transfer', { preHandler: requirePerm('frontoffice.charges') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reservation_id: z.number().int().positive(), reservation_room_id: z.number().int().positive().nullish(), reason: z.string().trim().min(2).max(300) }).parse(req.body);
    return tx((c) => transferCharge(c, actorOf(req), id, b, b.reason));
  });

  app.post('/api/reservations/:id/refunds', { preHandler: requirePerm('frontoffice.refund') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ amount: Amount, method: z.enum(['cash', 'card', 'cheque', 'transfer', 'online']), reason: z.string().trim().min(3).max(300), reservation_room_id: z.number().int().nullish() }).parse(req.body);
    const r = await tx((c) => refundReservation(c, actorOf(req), id, b));
    rep.code(201);
    return r;
  });

  // ===================================================== Caisse =====================================================
  app.get('/api/cash/registers', { preHandler: requirePerm('cash.operate') }, async (req) =>
    q(getPool(), `SELECT cr.*, (SELECT cs.id FROM cash_sessions cs WHERE cs.cash_register_id = cr.id AND cs.status = 'open') AS open_session_id,
        (SELECT u.full_name FROM cash_sessions cs JOIN users u ON u.id = cs.opened_by WHERE cs.cash_register_id = cr.id AND cs.status = 'open') AS opened_by_name
       FROM cash_registers cr WHERE cr.hotel_id = $1 ORDER BY cr.id`, [req.user!.hotelId]));
  app.post('/api/cash/registers', { preHandler: requirePerm('cash.manage') }, async (req, rep) => {
    const b = z.object({ name: z.string().trim().min(2).max(60) }).parse(req.body);
    rep.code(201);
    return one(getPool(), 'INSERT INTO cash_registers (hotel_id, name) VALUES ($1,$2) RETURNING *', [req.user!.hotelId, b.name]);
  });

  /** Ma caisse ouverte (ou celle utilisée par défaut pour mes encaissements) */
  app.get('/api/cash/current', { preHandler: requirePerm('payments.create') }, async (req) => {
    const s0 = await findOpenSession(getPool(), actorOf(req));
    return s0 ? sessionSummary(getPool(), req.user!.hotelId, s0.id) : null;
  });

  app.get('/api/cash/sessions', { preHandler: requirePerm('cash.operate') }, async (req) => {
    const p = period(Period.parse(req.query));
    const all = req.user!.perms.has('cash.manage');
    return q(getPool(), `SELECT cs.*, cr.name AS register_name, u.full_name AS opened_by_name, v.full_name AS validated_by_name FROM cash_sessions cs
        JOIN cash_registers cr ON cr.id = cs.cash_register_id JOIN users u ON u.id = cs.opened_by LEFT JOIN users v ON v.id = cs.validated_by
       WHERE cr.hotel_id = $1 AND ((cs.opened_at AT TIME ZONE 'Africa/Algiers')::date BETWEEN $2 AND $3 OR cs.status = 'open') AND ($4 OR cs.opened_by = $5)
       ORDER BY cs.opened_at DESC`, [req.user!.hotelId, p.from, p.to, all, req.user!.id]);
  });
  app.get('/api/cash/sessions/:id', { preHandler: requirePerm('cash.operate') }, async (req) => {
    const { id } = Id.parse(req.params);
    const r = await sessionSummary(getPool(), req.user!.hotelId, id);
    if (r.opened_by !== req.user!.id && !req.user!.perms.has('cash.manage')) throw forbidden('Caisse d\'un autre caissier.');
    return r;
  });
  app.get('/api/cash/sessions/:id/pdf', { preHandler: requirePerm('cash.operate') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const r = await sessionSummary(getPool(), req.user!.hotelId, id);
    if (r.opened_by !== req.user!.id && !req.user!.perms.has('cash.manage')) throw forbidden('Caisse d\'un autre caissier.');
    const fmt = (d: any) => (d ? new Date(d).toLocaleString('fr-FR', { timeZone: 'Africa/Algiers' }) : '');
    const cols = [{ key: 'at', label: 'Heure' }, { key: 'label', label: 'Opération' }, { key: 'ref', label: 'Réf.' }, { key: 'method', label: 'Mode' }, { key: 'by_name', label: 'Par' }, { key: 'amount', label: 'Montant', money: true }];
    const rows = r.operations.map((o: any) => ({ ...o, at: fmt(o.at), label: o.void ? `[ANNULÉ] ${o.label}` : o.label, amount: o.void ? 0 : Number(o.amount) }));
    const total = { label: `Fond ${r.totals.opening} · théorique espèces ${r.totals.expected}${r.declared_amount !== null ? ` · compté ${r.declared_amount} · écart ${r.difference}` : ''}`, amount: r.totals.expected };
    return send(rep, 'pdf', `caisse-${id}`, `Rapport de caisse n° ${id} — ${r.register_name}`, `Ouverte par ${r.opened_by_name} le ${fmt(r.opened_at)}${r.closed_at ? ` · clôturée le ${fmt(r.closed_at)}` : ' · en cours'}`, cols, rows, total, await hotelName(req.user!.hotelId));
  });
  app.post('/api/cash/sessions/open', { preHandler: requirePerm('cash.operate') }, async (req, rep) => {
    const b = z.object({ register_id: z.number().int().positive().nullish(), opening_amount: z.number().min(0).max(100_000_000), note: s(300) }).parse(req.body);
    const r = await tx((c) => openSession(c, actorOf(req), b));
    rep.code(201);
    return r;
  });
  app.post('/api/cash/sessions/:id/movements', { preHandler: requirePerm('cash.operate') }, async (req, rep) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ direction: z.enum(['in', 'out']), category: z.enum(['float', 'bank_deposit', 'change', 'withdrawal', 'other']), amount: Amount, description: z.string().trim().min(2).max(200), reference: s(80) }).parse(req.body);
    if (b.direction === 'out' && ['bank_deposit', 'withdrawal'].includes(b.category) && !req.user!.perms.has('cash.manage')) throw forbidden('Versement en banque / retrait : réservé au superviseur.');
    const r = await tx((c) => addMovement(c, actorOf(req), req.user!.perms, id, b));
    rep.code(201);
    return r;
  });
  app.post('/api/cash/sessions/:id/close', { preHandler: requirePerm('cash.operate') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ counted_amount: z.number().min(0).max(100_000_000), justification: s(500) }).parse(req.body);
    return tx((c) => closeSession(c, actorOf(req), req.user!.perms, id, b));
  });
  app.post('/api/cash/sessions/:id/validate', { preHandler: requirePerm('cash.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ note: s(300) }).parse(req.body ?? {});
    await tx((c) => validateSession(c, actorOf(req), id, b.note ?? null));
    return { ok: true };
  });

  // ===================================================== Dépenses & recettes =====================================================
  app.get('/api/expenses', { preHandler: requirePerm('expenses.create') }, async (req) => {
    const p = period(Period.parse(req.query));
    return q(getPool(), `SELECT e.*, s.name AS supplier, u.full_name AS created_by_name FROM expenses e LEFT JOIN suppliers s ON s.id = e.supplier_id LEFT JOIN users u ON u.id = e.created_by
       WHERE e.hotel_id = $1 AND e.expense_date BETWEEN $2 AND $3 ORDER BY e.expense_date DESC, e.id DESC`, [req.user!.hotelId, p.from, p.to]);
  });
  app.get('/api/expense-categories', { preHandler: requirePerm('expenses.create') }, async (req) =>
    q(getPool(), `SELECT name FROM expense_categories WHERE hotel_id = $1 AND active UNION SELECT DISTINCT category FROM expenses WHERE hotel_id = $1 ORDER BY 1`, [req.user!.hotelId]));
  app.post('/api/expenses', { preHandler: requirePerm('expenses.create') }, async (req, rep) => {
    const b = z.object({ category: z.string().trim().min(2).max(60), description: z.string().trim().min(2).max(200), amount: Amount, method: z.enum(['cash', 'card', 'cheque', 'transfer']), supplier: s(120), expense_date: zDate.nullish(), reference: s(80) }).parse(req.body);
    const r = await tx((c) => addExpense(c, actorOf(req), b));
    rep.code(201);
    return r;
  });
  app.post('/api/expenses/:id/void', { preHandler: requirePerm('cash.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(3).max(300) }).parse(req.body);
    await tx((c) => voidEntry(c, actorOf(req), 'expenses', id, b.reason));
    return { ok: true };
  });
  app.get('/api/incomes', { preHandler: requirePerm('cash.operate') }, async (req) => {
    const p = period(Period.parse(req.query));
    return q(getPool(), `SELECT x.*, u.full_name AS created_by_name FROM incomes x LEFT JOIN users u ON u.id = x.created_by WHERE x.hotel_id = $1 AND x.income_date BETWEEN $2 AND $3 ORDER BY x.income_date DESC, x.id DESC`, [req.user!.hotelId, p.from, p.to]);
  });
  app.post('/api/incomes', { preHandler: requirePerm('cash.operate') }, async (req, rep) => {
    const b = z.object({ category: z.string().trim().min(2).max(60), description: z.string().trim().min(2).max(200), amount: Amount, method: z.enum(['cash', 'card', 'cheque', 'transfer', 'online']), income_date: zDate.nullish(), reference: s(80) }).parse(req.body);
    const r = await tx((c) => addIncome(c, actorOf(req), b));
    rep.code(201);
    return r;
  });
  app.post('/api/incomes/:id/void', { preHandler: requirePerm('cash.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ reason: z.string().trim().min(3).max(300) }).parse(req.body);
    await tx((c) => voidEntry(c, actorOf(req), 'incomes', id, b.reason));
    return { ok: true };
  });

  // ===================================================== Rapports =====================================================
  app.get('/api/finance/summary', { preHandler: requirePerm('finance.reports') }, async (req) => {
    const p = period(Period.parse(req.query));
    return { ...p, ...(await financeSummary(getPool(), req.user!.hotelId, p.from, p.to)) };
  });
  app.get('/api/finance/receivables', { preHandler: requirePerm('invoices.view') }, async (req) => receivables(getPool(), req.user!.hotelId));
  app.get('/api/finance/transactions', { preHandler: requirePerm('finance.reports') }, async (req) => {
    const qs = Period.extend({ type: z.enum(['payment', 'refund', 'movement', 'expense', 'income']).optional(), method: Method.optional() }).parse(req.query);
    const p = period(qs);
    return transactions(getPool(), req.user!.hotelId, p.from, p.to, qs.type, qs.method);
  });
  app.get('/api/finance/reports', { preHandler: requirePerm('finance.reports') }, async () =>
    Object.entries(FIN_REPORTS).map(([kind, d]) => ({ kind, title: d.title, dated: d.dated })));
  app.get('/api/finance/reports/:kind', { preHandler: requirePerm('finance.reports') }, async (req, rep) => {
    const { kind } = z.object({ kind: z.string().max(30) }).parse(req.params);
    const qs = Period.extend({ format: z.enum(['json', 'xlsx', 'csv', 'pdf']).default('json') }).parse(req.query);
    const p = period(qs);
    if (p.to < p.from) throw badRequest('Période invalide.');
    const r = await finReport(getPool(), req.user!.hotelId, kind, p.from, p.to);
    if (qs.format === 'json') return r;
    const sub = FIN_REPORTS[kind].dated ? `Période du ${p.from} au ${p.to}` : `Au ${today()}`;
    return send(rep, qs.format, `${kind}-${p.from}-${p.to}`, r.title, sub, r.columns, r.rows, r.total, await hotelName(req.user!.hotelId));
  });
}
