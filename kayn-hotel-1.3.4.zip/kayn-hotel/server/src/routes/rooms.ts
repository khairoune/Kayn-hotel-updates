import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { recordTaxVersion } from '../services/admin.js';
import { badRequest, forbidden as forbiddenErr } from '../lib/errors.js';
import { requireAuth } from '../lib/auth.js';
const needAnyPerm = (...ps: string[]) => async (req: any) => { await requireAuth(req, null as any); if (!ps.some((p) => req.user!.perms.has(p))) throw forbiddenErr(`Permission requise : ${ps.join(' ou ')}`); };
import { getPool, one, q, tx } from '../db/pool.js';
import { actorOf, requirePerm } from '../lib/auth.js';
import { audit } from '../lib/audit.js';
import { isDate, today } from '../lib/dates.js';
import { getSettings, guestDisplayName } from '../services/common.js';
import { dashboard } from '../services/dashboard.js';
import { setRoomHousekeeping } from '../services/reservations.js';
import { setRoomOutOfServiceNow } from '../services/rooms.js';

const Id = z.object({ id: z.coerce.number().int().positive() });

export async function roomRoutes(app: FastifyInstance) {
  app.get('/api/dashboard', { preHandler: requirePerm('dashboard.view') }, async (req) => {
    const qs = z.object({ date: z.string().refine(isDate).optional() }).parse(req.query);
    return dashboard(req.user!.hotelId, qs.date ?? today(), req.user!.perms.has('dashboard.finance'));
  });

  app.get('/api/settings', { preHandler: requirePerm('reservations.view') }, async (req) => {
    const s = await getSettings(getPool(), req.user!.hotelId);
    return {
      meal_supplements: s.meal_supplements, check_in_time: s.check_in_time, check_out_time: s.check_out_time, vat_rate: s.vat_rate,
      tourist_tax_per_adult_night: s.tourist_tax_per_adult_night, deposit_policy: s.deposit_policy, cancellation_policy: s.cancellation_policy,
      default_guest_language: s.default_guest_language, weekend_nights: s.weekend_nights, tax_rates: s.tax_rates,
      cash_session_required: s.cash_session_required, payment_gateway: { enabled: !!s.payment_gateway?.enabled, provider: s.payment_gateway?.provider ?? '' },
    };
  });

  // ===== Paramètres (administration) =====
  const SettingsBody = z.object({
    meal_supplements: z.object({ RO: z.number().min(0), BB: z.number().min(0), HB: z.number().min(0), FB: z.number().min(0) }).optional(),
    vat_rate: z.number().min(0).max(100).optional(),
    tourist_tax_per_adult_night: z.number().min(0).max(100000).optional(),
    check_in_time: z.string().regex(/^\d{2}:\d{2}$/).optional(),
    check_out_time: z.string().regex(/^\d{2}:\d{2}$/).optional(),
    reminder_days_before: z.number().int().min(0).max(14).optional(),
    weekend_nights: z.array(z.number().int().min(0).max(6)).max(7).optional(),
    tax_rates: z.record(z.string(), z.number().min(0).max(100)).optional(),
    cash_session_required: z.boolean().optional(),
    payment_gateway: z.object({ enabled: z.boolean(), provider: z.string().max(60).default('') }).optional(),
    invoice_footer: z.string().max(1000).optional(),
    default_guest_language: z.enum(['fr', 'en', 'ar']).optional(),
    deposit_policy: z.object({
      mode: z.enum(['none', 'auto_pending', 'block']),
      percent: z.number().min(0).max(100),
      exempt_sources: z.array(z.enum(['walk_in', 'phone', 'email', 'company', 'agency', 'website', 'other'])),
    }).optional(),
    cancellation_policy: z.object({
      enabled: z.boolean(), hours_before: z.number().int().min(0).max(720),
      fee_type: z.enum(['nights', 'percent', 'amount']), fee_value: z.number().min(0),
      no_show_enabled: z.boolean(), no_show_fee_type: z.enum(['nights', 'percent', 'amount']), no_show_fee_value: z.number().min(0),
    }).optional(),
    smtp: z.object({ host: z.string().max(120), port: z.number().int().min(1).max(65535), user: z.string().max(120).optional(), pass: z.string().max(200).optional(), from: z.string().max(200).optional() }).nullable().optional(),
  });

  app.get('/api/settings/all', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const s = await getSettings(getPool(), req.user!.hotelId);
    const hotel = await getPool().query('SELECT * FROM hotels WHERE id = $1', [req.user!.hotelId]);
    const { updates: _u, update_state: _us, ...rest } = s as any;
    return { settings: { ...rest, smtp: s.smtp ? { ...s.smtp, pass: s.smtp.pass ? '••••••••' : '' } : null }, hotel: hotel.rows[0] };
  });

  /** Test de l'envoi d'e-mails avec les paramètres enregistrés (Gmail ou autre serveur SMTP). */
  app.post('/api/settings/smtp-test', { preHandler: requirePerm('settings.manage'), config: { rateLimit: { max: 5, timeWindow: '1 minute' } } }, async (req) => {
    const b = z.object({ to: z.string().trim().max(120).refine((v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), 'Adresse e-mail invalide') }).parse(req.body);
    const smtp = (await getSettings(getPool(), req.user!.hotelId)).smtp;
    if (!smtp?.host) throw badRequest('Enregistrez d\'abord les paramètres du serveur e-mail.');
    const { smtpTransport, smtpError } = await import('../services/notifications.js');
    const hotel = await one<any>(getPool(), 'SELECT name, commercial_name FROM hotels WHERE id = $1', [req.user!.hotelId]);
    try {
      await smtpTransport(smtp).sendMail({ from: smtp.from || smtp.user, to: b.to, subject: `Test d'envoi — ${hotel.commercial_name || hotel.name}`,
        text: `Bonjour,\n\nCe message confirme que KAYN Hotel peut envoyer des e-mails (confirmations, rappels, factures).\n\n${hotel.commercial_name || hotel.name}` });
    } catch (e: any) {
      await audit(getPool(), actorOf(req), 'smtp_test', 'setting', 'smtp', null, { to: b.to, ok: false }, { result: 'failure' });
      throw badRequest(smtpError(e));
    }
    await audit(getPool(), actorOf(req), 'smtp_test', 'setting', 'smtp', null, { to: b.to, ok: true });
    // les e-mails en attente partent tout de suite
    const { processEmailOutbox } = await import('../services/notifications.js');
    const r = await processEmailOutbox(req.user!.hotelId).catch(() => null);
    return { ok: true, pending_sent: r?.sent ?? 0 };
  });
  app.put('/api/settings', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const body = SettingsBody.parse(req.body);
    await tx(async (c) => {
      const before = await getSettings(c, req.user!.hotelId);
      for (const [k, v] of Object.entries(body)) {
        if (v === undefined) continue;
        let value: any = v;
        if (k === 'smtp' && v && (v as any).pass === '••••••••') value = { ...(v as any), pass: before.smtp?.pass };
        await c.query(
          `INSERT INTO settings (hotel_id, key, value, updated_at) VALUES ($1,$2,$3,now())
           ON CONFLICT (hotel_id, key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
          [req.user!.hotelId, k, JSON.stringify(value)],
        );
        await audit(c, actorOf(req), 'update', 'setting', k, k === 'smtp' ? null : before[k], k === 'smtp' ? { host: (v as any)?.host } : value);
      }
      // historique des taux (taxes versionnées) : chaque changement est daté, sans effet sur les documents déjà émis
      const d = today();
      if (body.vat_rate !== undefined && Number(body.vat_rate) !== Number(before.vat_rate)) await recordTaxVersion(c, req.user!.hotelId, req.user!.id, 'default', body.vat_rate, d, 'TVA par défaut', 'Paramètres');
      if (body.tourist_tax_per_adult_night !== undefined && Number(body.tourist_tax_per_adult_night) !== Number(before.tourist_tax_per_adult_night)) await recordTaxVersion(c, req.user!.hotelId, req.user!.id, 'tourist', body.tourist_tax_per_adult_night, d, 'Taxe de séjour', 'Paramètres');
      for (const [cat, r] of Object.entries(body.tax_rates ?? {})) if (Number(before.tax_rates?.[cat]) !== Number(r)) await recordTaxVersion(c, req.user!.hotelId, req.user!.id, cat, r, d, null, 'Paramètres');
    });
    return { ok: true };
  });

  app.put('/api/hotel', { preHandler: requirePerm('settings.manage') }, async (req) => {
    const b = z.object({
      name: z.string().trim().min(2).max(120), address: z.string().max(200).nullish(), city: z.string().max(80).nullish(), phone: z.string().max(40).nullish(),
      email: z.string().max(120).nullish(), nif: z.string().max(40).nullish(), nis: z.string().max(40).nullish(), rc: z.string().max(40).nullish(), art: z.string().max(40).nullish(),
    }).parse(req.body);
    await tx(async (c) => {
      const before = (await c.query('SELECT * FROM hotels WHERE id = $1', [req.user!.hotelId])).rows[0];
      await c.query(`UPDATE hotels SET name=$2, address=$3, city=$4, phone=$5, email=$6, nif=$7, nis=$8, rc=$9, art=$10 WHERE id = $1`,
        [req.user!.hotelId, b.name, b.address ?? null, b.city ?? null, b.phone ?? null, b.email ?? null, b.nif ?? null, b.nis ?? null, b.rc ?? null, b.art ?? null]);
      await audit(c, actorOf(req), 'update', 'hotel', req.user!.hotelId, before, b);
    });
    return { ok: true };
  });

  app.get('/api/room-types', { preHandler: needAnyPerm('rooms.view', 'reservations.view') }, async (req) =>
    q(getPool(), 'SELECT * FROM room_types WHERE hotel_id = $1 AND active ORDER BY base_rate, name', [req.user!.hotelId]));

  app.get('/api/floors', { preHandler: requirePerm('rooms.view') }, async (req) =>
    q(getPool(), 'SELECT * FROM floors WHERE hotel_id = $1 ORDER BY number', [req.user!.hotelId]));

  app.get('/api/rooms', { preHandler: requirePerm('rooms.view') }, async (req) => {
    const t = today();
    const rows = await q<any>(
      getPool(),
      `SELECT r.id, r.number, r.hk_status, r.dnd, r.out_of_service, r.oos_reason, f.number AS floor, t.name AS type_name, t.code AS type_code,
              s.id AS stay_id, rr.check_out AS stay_check_out,
              g.kind, g.last_name, g.first_name, g.company_name,
              (SELECT row_to_json(x) FROM (SELECT rr2.id AS rr_id, rr2.check_in, g2.kind, g2.last_name, g2.first_name, g2.company_name
                 FROM reservation_rooms rr2 JOIN reservations r2 ON r2.id = rr2.reservation_id JOIN guests g2 ON g2.id = r2.guest_id
                WHERE rr2.room_id = r.id AND rr2.status IN ('pending','confirmed') AND rr2.check_in = $2 LIMIT 1) x) AS arrival,
              (SELECT row_to_json(ht) FROM (SELECT id, kind, status, created_at FROM housekeeping_tasks
                WHERE room_id = r.id AND status IN ('todo','in_progress','to_inspect') ORDER BY created_at LIMIT 1) ht) AS task
         FROM rooms r JOIN floors f ON f.id = r.floor_id JOIN room_types t ON t.id = r.room_type_id
         LEFT JOIN stays s ON s.room_id = r.id AND s.checked_out_at IS NULL
         LEFT JOIN reservation_rooms rr ON rr.id = s.reservation_room_id
         LEFT JOIN reservations res ON res.id = rr.reservation_id
         LEFT JOIN guests g ON g.id = res.guest_id
        WHERE r.hotel_id = $1 AND r.active ORDER BY f.number, length(r.number), r.number`,
      [req.user!.hotelId, t],
    );
    return rows.map((r) => ({
      id: r.id, number: r.number, floor: r.floor, type_name: r.type_name, type_code: r.type_code, hk_status: r.hk_status, dnd: r.dnd,
      out_of_service: r.out_of_service, oos_reason: r.oos_reason, occupied: !!r.stay_id,
      guest: r.stay_id ? guestDisplayName(r) : null, stay_check_out: r.stay_check_out,
      arrival: r.arrival ? { rr_id: r.arrival.rr_id, guest: guestDisplayName(r.arrival) } : null,
      task: r.task,
    }));
  });

  app.post('/api/rooms/:id/housekeeping', { preHandler: requirePerm('housekeeping.update') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ status: z.enum(['dirty', 'to_clean', 'cleaning', 'to_inspect', 'clean', 'inspected']) }).parse(req.body);
    await tx((c) => setRoomHousekeeping(c, actorOf(req), id, b.status, req.user!.perms));
    return { ok: true };
  });

  app.post('/api/rooms/:id/out-of-service', { preHandler: requirePerm('maintenance.manage') }, async (req) => {
    const { id } = Id.parse(req.params);
    const b = z.object({ out_of_service: z.boolean(), reason: z.string().max(300).nullish() }).parse(req.body);
    await tx((c) => setRoomOutOfServiceNow(c, actorOf(req), id, b.out_of_service, b.reason ?? null));
    return { ok: true };
  });

}
