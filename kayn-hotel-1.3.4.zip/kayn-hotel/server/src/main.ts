import { fileURLToPath } from 'node:url';
import { currentDay } from './services/nightaudit.js';
import { buildApp } from './app.js';
import { createWriteStream, mkdirSync, renameSync, statSync } from 'node:fs';
import path from 'node:path';
import { prepareSetup } from './routes/setup.js';
import { purgeIdScans } from './routes/idscan.js';
import { config } from './config.js';
import { runMigrations } from './db/migrate.js';
import { getPool, q, tx } from './db/pool.js';
import { ensureHotelDefaults, syncRolesAndPermissions } from './db/seed.js';
import { today } from './lib/dates.js';
import { processEmailOutbox, queueReminders } from './services/notifications.js';
import { syncOutOfService } from './services/rooms.js';
import { generateTasks } from './services/housekeeping.js';
import { generatePreventive } from './services/maintenance.js';
import { expirePoints, runAutomations } from './services/crm.js';
import { applyEffectiveTaxes } from './services/admin.js';
import { runNotificationChecks } from './services/notify.js';
import { autoBackupIfDue, createBackup, syncRegistry } from './services/backup.js';
import { APP_VERSION, autoCheckIfDue, autoInstallIfDue, confirmBoot } from './services/updates.js';
import { monthlyReportIfDue } from './services/monthlyReport.js';
import { maintenance } from './lib/auth.js';
import { currency } from './services/exports.js';
import { getSettings } from './services/common.js';
import { closePool, one } from './db/pool.js';

/** Connexion à la base : message clair si PostgreSQL est arrêté ou mal configuré (le mot de passe n'est jamais affiché). */
try { await one(getPool(), 'SELECT 1'); } catch (e: any) {
  const url = config.databaseUrl.replace(/\/\/[^@]*@/, '//***@');
  console.error(`\n[KAYN Hotel] Impossible de se connecter à la base de données (${url}).\n  Cause : ${e?.code === 'ECONNREFUSED' ? 'PostgreSQL ne répond pas — vérifiez que le service est démarré.' : e?.code === '28P01' ? 'identifiant ou mot de passe PostgreSQL incorrect (DATABASE_URL dans .env).' : e?.code === '3D000' ? 'la base indiquée n\'existe pas — créez-la (voir README).' : e?.message}\n`);
  process.exit(1);
}

// mise à jour : sauvegarde automatique AVANT d'appliquer de nouvelles migrations (base déjà en service)
{
  const { readdirSync } = await import('node:fs');
  const files = readdirSync(new URL('./db/migrations', import.meta.url)).filter((f) => f.endsWith('.sql'));
  const inUse = (await one<any>(getPool(), `SELECT to_regclass('public.backups') AS b, to_regclass('public.schema_migrations') AS m`));
  if (inUse?.b && inUse?.m) {
    const done = new Set((await q<any>(getPool(), 'SELECT name FROM schema_migrations')).map((r) => r.name));
    const pending = files.filter((f) => !done.has(f));
    const hotel = await one<any>(getPool(), 'SELECT id FROM hotels ORDER BY id LIMIT 1');
    if (pending.length && hotel && process.env.SKIP_PRE_MIGRATION_BACKUP !== 'true') {
      console.log(`Mise à jour détectée (${pending.join(', ')}) : sauvegarde de sécurité avant migration…`);
      try {
        const { createBackup } = await import('./services/backup.js');
        const b = await createBackup('manual', { id: null, name: 'Mise à jour', hotelId: hotel.id }, `Avant mise à jour : ${pending.join(', ')}`);
        console.log(`✔ Sauvegarde ${b.file_name} vérifiée.`);
      } catch (e: any) {
        console.error(`\n[KAYN Hotel] Mise à jour interrompue : la sauvegarde de sécurité a échoué (${e?.message ?? e}).\n  Aucune donnée n'a été modifiée. Corrigez la cause (outils PostgreSQL : PG_BIN) puis relancez.\n`);
        process.exit(1);
      }
    }
  }
}
await runMigrations();
await tx(async (c) => {
  await syncRolesAndPermissions(c);
  // mise à niveau : données de référence ajoutées par les nouvelles versions (équipements, tarifs, prestations…)
  for (const h of await q<{ id: number }>(c, 'SELECT id FROM hotels')) await ensureHotelDefaults(c, h.id);
});
// fuseau horaire de l'établissement (Administration → Établissement)
{ const h = await one<any>(getPool(), 'SELECT id, timezone, currency_symbol FROM hotels ORDER BY id LIMIT 1');
  if (h?.timezone) { config.timezone = h.timezone; currency.tz = h.timezone; }
  if (h?.currency_symbol) currency.symbol = h.currency_symbol;
  if (h) currency.decimals = Number((await getSettings(getPool(), h.id)).rounding?.decimals ?? 2); }
// journal d'erreurs du serveur : console + fichier (server/data/logs/kayn-hotel.log, rotation à 10 Mo)
const logDir = process.env.LOG_DIR ?? fileURLToPath(new URL('../data/logs', import.meta.url));
mkdirSync(logDir, { recursive: true });
const logFile = path.join(logDir, 'kayn-hotel.log');
try { if (statSync(logFile).size > 10 * 1024 * 1024) renameSync(logFile, `${logFile}.1`); } catch { /* premier démarrage */ }
const logOut = createWriteStream(logFile, { flags: 'a' });
const app = await buildApp({ logger: { level: process.env.LOG_LEVEL ?? 'info', stream: { write: (m: string) => { process.stdout.write(m); logOut.write(m); } } } });
await prepareSetup((s) => { console.log(s); logOut.write(`${JSON.stringify({ time: Date.now(), msg: 'Installation en attente : code affiché dans la console et dans data/CODE-INSTALLATION.txt' })}\n`); });
await app.listen({ port: config.port, host: config.host });
console.log(`KAYN Hotel ${APP_VERSION} démarré sur http://localhost:${config.port}`);
// mise à jour : démarrage réussi → version confirmée (pas de retour arrière)
confirmBoot();
// lancé par le superviseur (start.cjs) : s'arrêter si le superviseur disparaît (arrêt par 3-ARRETER.bat)
if (process.env.KAYN_SUPERVISED === '1') {
  const parent = process.ppid;
  setInterval(() => { try { process.kill(parent, 0); } catch { process.exit(0); } }, 5_000).unref();
}

/** Tâches planifiées : rappels avant arrivée + envoi des e-mails en attente (toutes les 15 min). */
async function scheduler() {
  if (maintenance.on) return;
  try {
    const hotels = await q<{ id: number }>(getPool(), 'SELECT id FROM hotels');
    for (const h of hotels) {
      // night audit : la journée opérationnelle courante existe toujours (aucune clôture automatique)
      await currentDay(getPool(), h.id).catch(() => {});
      await syncOutOfService(getPool(), h.id);
      // taxes : version datée devenue applicable aujourd'hui → nouvelles lignes uniquement
      await applyEffectiveTaxes(getPool(), h.id, today()).catch((e) => app.log.error(e));
      // notifications internes (événements réels) et sauvegarde automatique
      await runNotificationChecks(getPool(), h.id).catch((e) => app.log.error(e));
      await autoBackupIfDue(h.id).catch((e) => app.log.error(e));
      await purgeIdScans(h.id).catch((e) => app.log.error(e));
      await autoCheckIfDue(h.id).catch((e) => app.log.error(e));
      await autoInstallIfDue(h.id, (note) => createBackup('manual', { id: null, name: 'Mise à jour automatique', hotelId: h.id }, note)).catch((e) => app.log.error(e));
      await monthlyReportIfDue(h.id).catch((e) => app.log.error(e));
      await queueReminders(h.id, today());
      await processEmailOutbox(h.id);
      // ménage : tâches du jour (départs, recouches, arrivées) — idempotent
      const sys = await q<{ id: number }>(getPool(), `SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id WHERE u.hotel_id = $1 AND r.code = 'admin' AND u.active ORDER BY u.protected DESC, u.id LIMIT 1`, [h.id]);
      if (sys[0]) await tx((c) => generateTasks(c, { userId: sys[0].id, hotelId: h.id, deviceId: null, ip: 'scheduler' } as any));
      // maintenance préventive : ordres de travail des échéances proches — idempotent
      if (sys[0]) await tx((c) => generatePreventive(c, { userId: sys[0].id, hotelId: h.id, deviceId: null, ip: 'scheduler' } as any));
      // CRM : expiration des points, messages automatiques (remerciement, avant l'arrivée, anniversaire) — idempotent
      if (sys[0]) await tx(async (c) => { const a = { userId: sys[0].id, hotelId: h.id, deviceId: null, ip: 'scheduler' } as any; await expirePoints(c, a); await runAutomations(c, a); });
    }
    await getPool().query(`DELETE FROM idempotency_keys WHERE created_at < now() - interval '2 days'`);
  } catch (e) {
    app.log.error(e);
  }
}
syncRegistry().catch(() => {});
// envoi automatique des e-mails en attente chaque minute (confirmations, rappels) : délai d'envoi ≤ 1 min
setInterval(async () => {
  if (maintenance.on) return;
  try { for (const h of await q<any>(getPool(), 'SELECT id FROM hotels')) await processEmailOutbox(h.id); } catch { /* base momentanément indisponible */ }
}, 60_000).unref();
setTimeout(scheduler, 3_000);
setInterval(scheduler, 15 * 60_000);

/** Arrêt contrôlé : plus de nouvelles requêtes, fin des requêtes en cours, fermeture propre de la base. */
let stopping = false;
for (const sig of ['SIGINT', 'SIGTERM'] as const) process.on(sig, async () => {
  if (stopping) return; stopping = true;
  console.log(`[KAYN Hotel] Arrêt demandé (${sig})…`);
  await app.close().catch(() => {});
  await closePool().catch(() => {});
  process.exit(0);
});
