import { createHash, randomBytes } from 'node:crypto';
import bcrypt from 'bcryptjs';
import type { FastifyReply, FastifyRequest } from 'fastify';
import { config } from '../config.js';
import { getPool, one, q } from '../db/pool.js';
import { forbidden, unauthorized } from './errors.js';
import { audit, type Actor } from './audit.js';
import { getSettings } from '../services/common.js';

export const SESSION_COOKIE = 'kh_session';
export const DEVICE_COOKIE = 'kh_device';

export interface AuthUser {
  id: number;
  hotelId: number;
  username: string;
  fullName: string;
  role: string;
  roleName: string;
  language: string;
  perms: Set<string>;
  deviceId: number | null;
  mustChangePassword: boolean;
}

declare module 'fastify' {
  interface FastifyRequest {
    user?: AuthUser;
  }
}

export const sha256 = (s: string) => createHash('sha256').update(s).digest('hex');
export const newToken = () => randomBytes(32).toString('base64url');

export async function hashPassword(pw: string) {
  return bcrypt.hash(pw, 11);
}
export async function verifyPassword(pw: string, hash: string) {
  return bcrypt.compare(pw, hash);
}

/** Politique de sécurité de l'établissement (paramètres, mise en cache 30 s). */
const secCache = new Map<number, { at: number; v: any }>();
export async function securityOf(hotelId: number) {
  const hit = secCache.get(hotelId);
  if (hit && Date.now() - hit.at < 30_000) return hit.v;
  const v = (await getSettings(getPool(), hotelId)).security;
  secCache.set(hotelId, { at: Date.now(), v });
  return v;
}
export const clearSecurityCache = () => secCache.clear();
/** Établissement en maintenance (restauration en cours) : les requêtes sont suspendues. */
export const maintenance = { on: false, reason: '' };

export function validatePasswordStrength(pw: string, minLength = 8): string | null {
  if (pw.length < minLength) return `Le mot de passe doit contenir au moins ${minLength} caractères.`;
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return 'Le mot de passe doit contenir des lettres et des chiffres.';
  return null;
}

export function cookieOpts(maxAgeSec: number) {
  return { path: '/', httpOnly: true, sameSite: 'strict' as const, secure: config.cookieSecure, maxAge: maxAgeSec };
}

export async function createSession(userId: number, deviceId: number | null, req: FastifyRequest) {
  const token = newToken();
  const expires = new Date(Date.now() + config.sessionHours * 3600_000);
  await getPool().query(
    `INSERT INTO sessions (id, user_id, device_id, ip, user_agent, expires_at) VALUES ($1,$2,$3,$4,$5,$6)`,
    [sha256(token), userId, deviceId, req.ip, String(req.headers['user-agent'] ?? '').slice(0, 300), expires],
  );
  return token;
}

export async function loadUserFromRequest(req: FastifyRequest): Promise<AuthUser | null> {
  const token = req.cookies?.[SESSION_COOKIE];
  if (!token) return null;
  const pool = getPool();
  const row = await one<any>(
    pool,
    `SELECT s.id AS sid, s.device_id, u.id, u.hotel_id, u.username, u.full_name, u.language, u.must_change_password,
            r.code AS role, r.name AS role_name, d.status AS device_status
       FROM sessions s
       JOIN users u ON u.id = s.user_id AND u.active
       JOIN roles r ON r.id = u.role_id
       LEFT JOIN devices d ON d.id = s.device_id
      WHERE s.id = $1 AND NOT s.revoked AND s.expires_at > now()`,
    [sha256(token)],
  );
  if (!row) return null;
  if (row.device_id && row.device_status === 'revoked') return null;
  // expiration après inactivité (paramètre de sécurité)
  const sec = await securityOf(row.hotel_id);
  const idle = await one<any>(pool, `SELECT (last_seen_at < now() - ($2 || ' minutes')::interval) AS idle FROM sessions WHERE id = $1`, [row.sid, String(sec.session_idle_minutes ?? 480)]);
  if (idle?.idle) { await pool.query('UPDATE sessions SET revoked = true WHERE id = $1', [row.sid]); return null; }
  const perms = await q<{ code: string }>(
    pool,
    `SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id
      JOIN roles r ON r.id = rp.role_id WHERE r.code = $1 AND r.active`,
    [row.role],
  );
  // expiration glissante
  await pool.query(
    `UPDATE sessions SET last_seen_at = now(), expires_at = now() + ($2 || ' hours')::interval WHERE id = $1`,
    [row.sid, String(config.sessionHours)],
  );
  return {
    id: row.id,
    hotelId: row.hotel_id,
    username: row.username,
    fullName: row.full_name,
    role: row.role,
    roleName: row.role_name,
    language: row.language,
    perms: new Set(perms.map((p) => p.code)),
    deviceId: row.device_id,
    mustChangePassword: row.must_change_password,
  };
}

/** preHandler : exige une session valide. */
export async function requireAuth(req: FastifyRequest, _rep: FastifyReply) {
  const u = await loadUserFromRequest(req);
  if (!u) throw unauthorized();
  req.user = u;
}

/** preHandler : exige une ou plusieurs permissions. */
export function requirePerm(...perms: string[]) {
  return async (req: FastifyRequest, rep: FastifyReply) => {
    if (!req.user) await requireAuth(req, rep);
    for (const p of perms) if (!req.user!.perms.has(p)) {
      // toute tentative refusée est tracée (alerte de sécurité en cas de répétition)
      await audit(getPool(), actorOf(req), 'permission_denied', 'api', null, null, { method: req.method, url: req.url.split('?')[0], permission: p }, { result: 'denied' }).catch(() => {});
      throw forbidden(`Permission requise : ${p}`);
    }
  };
}

export function actorOf(req: FastifyRequest): Actor {
  return { userId: req.user!.id, hotelId: req.user!.hotelId, deviceId: req.user!.deviceId, ip: req.ip };
}
