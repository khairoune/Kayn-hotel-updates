/**
 * Calculs monétaires exacts en centimes (entiers) — jamais de flottants pour les montants.
 * Arrondi « au demi supérieur, loin de zéro », identique à round() de PostgreSQL.
 */
export const toCents = (v: number | string | null | undefined): number => {
  const s = String(v ?? 0).trim().replace(',', '.');
  if (!/^-?\d+(\.\d+)?$/.test(s)) return Math.round(Number(s) * 100);
  const neg = s.startsWith('-');
  const [i, d = ''] = s.replace('-', '').split('.');
  const frac = (d + '000').slice(0, 3);
  let c = Number(i) * 100 + Number(frac.slice(0, 2));
  if (Number(frac[2]) >= 5) c += 1;
  return neg ? -c : c;
};
export const fromCents = (c: number): number => Math.round(c) / 100;
/** a × b / d arrondi au plus proche (demi loin de zéro), entiers seulement */
const mulDiv = (a: number, b: number, d: number) => {
  const p = a * b;
  const s = p < 0 ? -1 : 1;
  return s * Math.floor((Math.abs(p) * 2 + d) / (2 * d));
};
/** Taxe en centimes d'une base en centimes au taux en % (2 décimales max) */
export const taxCents = (baseCents: number, rate: number) => mulDiv(baseCents, Math.round(rate * 100), 10_000);
/** Part en centimes : base × num / den */
export const shareCents = (baseCents: number, num: number, den: number) => (den === 0 ? 0 : mulDiv(baseCents, num, den));
export const money2 = (v: number | string) => fromCents(toCents(v));
export const sumMoney = (vals: (number | string)[]) => fromCents(vals.reduce<number>((s, v) => s + toCents(v), 0));
