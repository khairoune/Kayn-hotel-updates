import type { Db } from '../db/pool.js';

export interface Actor {
  userId: number;
  hotelId: number;
  deviceId?: number | null;
  ip?: string | null;
}

/** Clés jamais enregistrées dans le journal (mots de passe, jetons, codes, secrets). */
const SECRET_KEY = /pass(word)?|pwd|token|secret|hash|pin|code_hash|reset_code|otp|api_?key|cookie|session/i;
export function redactSecrets(v: unknown, depth = 0): unknown {
  if (v === null || v === undefined || depth > 6) return v;
  if (Array.isArray(v)) return v.map((x) => redactSecrets(x, depth + 1));
  if (typeof v === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, x] of Object.entries(v as Record<string, unknown>)) out[k] = SECRET_KEY.test(k) ? (x === null || x === undefined || x === '' ? x : '[masqué]') : redactSecrets(x, depth + 1);
    return out;
  }
  return v;
}

export async function audit(
  db: Db,
  actor: Actor | null,
  action: string,
  entity: string,
  entityId: string | number | null,
  before: unknown = null,
  after: unknown = null,
  opts: { result?: 'success' | 'failure' | 'denied'; userAgent?: string | null } = {},
) {
  await db.query(
    `INSERT INTO audit_logs (hotel_id, user_id, device_id, action, entity, entity_id, before, after, ip, result, user_agent)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
    [
      actor?.hotelId ?? null,
      actor?.userId ?? null,
      actor?.deviceId ?? null,
      action,
      entity,
      entityId === null ? null : String(entityId),
      before === null ? null : JSON.stringify(redactSecrets(before)),
      after === null ? null : JSON.stringify(redactSecrets(after)),
      actor?.ip ?? null,
      opts.result ?? (action === 'login_failed' ? 'failure' : 'success'),
      opts.userAgent ? opts.userAgent.slice(0, 300) : null,
    ],
  );
}
