export class AppError extends Error {
  constructor(public status: number, public code: string, message: string, public details?: unknown) {
    super(message);
  }
}

export const badRequest = (msg: string, details?: unknown) => new AppError(400, 'bad_request', msg, details);
export const unauthorized = (msg = 'Authentification requise') => new AppError(401, 'unauthorized', msg);
export const forbidden = (msg = 'Accès refusé') => new AppError(403, 'forbidden', msg);
export const notFound = (msg = 'Introuvable') => new AppError(404, 'not_found', msg);
export const conflict = (msg: string, details?: unknown) => new AppError(409, 'conflict', msg, details);

/** Traduit les erreurs PostgreSQL connues en messages clairs. */
export function fromPg(e: any): AppError | null {
  if (!e || typeof e !== 'object' || !('code' in e)) return null;
  switch (e.code) {
    case '23P01':
      return conflict('Chambre déjà occupée sur cette période (double réservation impossible).');
    case '23505':
      return conflict('Cette valeur existe déjà.', e.detail);
    case '23503':
      return badRequest('Référence invalide ou élément encore utilisé.', e.detail);
    case '23514':
      return badRequest('Données invalides (contrôle de cohérence).', e.constraint);
    case 'KH422':
      return new AppError(400, 'payment_method', e.message);
    case 'KH409':
      return new AppError(409, 'day_closed', e.message);
    case 'P0001':
      return new AppError(403, 'forbidden', e.message);
    default:
      return null;
  }
}
