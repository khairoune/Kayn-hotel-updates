/** Catalogue des permissions et rôles par défaut. */
export const PERMISSIONS: Record<string, string> = {
  'dashboard.view': 'Voir le tableau de bord',
  'dashboard.finance': 'Voir les chiffres financiers du tableau de bord',
  'planning.view': 'Voir le planning',
  'reservations.view': 'Voir les réservations',
  'reservations.create': 'Créer une réservation',
  'reservations.edit': 'Modifier / déplacer une réservation',
  'reservations.cancel': 'Annuler une réservation / non-présentation',
  'reservations.override_policy': 'Déroger aux politiques (acompte, frais d\'annulation)',
  'frontoffice.checkin': 'Effectuer un check-in',
  'frontoffice.checkout': 'Effectuer un check-out',
  'frontoffice.checkout_with_balance': 'Valider un départ avec solde impayé',
  'frontoffice.refund': 'Effectuer un remboursement',
  'frontoffice.charges': 'Ajouter des prestations au séjour',
  'services.manage': 'Gérer le catalogue des prestations',
  'payments.create': 'Encaisser un paiement',
  'payments.void': 'Annuler un paiement',
  'invoices.view': 'Voir les factures',
  'cash.operate': 'Caissier : ouvrir / clôturer sa caisse, mouvements, recettes',
  'cash.manage': 'Superviseur caisse : toutes les caisses, validation des écarts, annulations',
  'invoices.create': 'Émettre factures, pro forma et factures libres',
  'invoices.credit': 'Émettre des avoirs et partager des factures',
  'finance.reports': 'Consulter les rapports financiers',
  'expenses.create': 'Saisir une dépense',
  'rooms.view': 'Voir les chambres',
  'rooms.manage': 'Créer / modifier les chambres et types',
  'housekeeping.view': 'Voir le housekeeping',
  'housekeeping.update': 'Mettre à jour le statut ménage',
  'maintenance.manage': 'Signaler une panne / bloquer une chambre (réception, ménage)',
  'maintenance.view': 'Maintenance : consulter pannes, équipements et interventions',
  'maintenance.report': 'Maintenance : déclarer une panne',
  'maintenance.work': 'Maintenance : réaliser les interventions (technicien)',
  'maintenance.supervise': 'Maintenance : affecter, valider, clôturer, préventif, coûts externes',
  'maintenance.reports': 'Maintenance : rapports et exports',
  'hr.self': 'RH : espace personnel (pointage, planning, congés, bulletins)',
  'hr.view': 'RH : voir le personnel de son département',
  'hr.team': 'RH : chef de département (planning, présences, congés de son équipe)',
  'hr.manage': 'RH : dossiers du personnel, contrats, documents, corrections de pointage',
  'hr.salary': 'RH : voir les salaires',
  'hr.payroll': 'RH : calculer et valider la paie',
  'hr.payroll_pay': 'RH : payer les salaires et les avances (caisse)',
  'hr.reports': 'RH : rapports et exports',
  'hr.terminal': 'RH : borne de pointage',
  'crm.view': 'CRM : tableau de bord, fiches et historique clients',
  'crm.manage': 'CRM : statut, préférences, entreprises, contrats, fusion des doublons',
  'crm.billing': 'CRM : factures, paiements et créances dans la fiche client',
  'crm.loyalty': 'CRM : programme de fidélité (adhésion, récompenses, ajustements)',
  'crm.complaints': 'CRM : traiter les réclamations et enquêtes',
  'crm.marketing': 'CRM : modèles, segments, campagnes, messages',
  'crm.reports': 'CRM : rapports et exports',
  'crm.privacy': 'CRM : demandes des clients (accès, effacement, consentement)',
  'equipment.manage': 'Maintenance : gérer le parc d\'équipements et les techniciens',
  'housekeeping.manage': 'Superviser le ménage : tâches, affectations, planning du personnel, réglages',
  'housekeeping.inspect': 'Inspecter et valider / refuser les chambres',
  'housekeeping.dnd': 'Indiquer « Ne pas déranger »',
  'housekeeping.minibar': 'Saisir les consommations du mini-bar',
  'housekeeping.reports': 'Consulter les rapports housekeeping',
  'linen.manage': 'Gérer le linge et la blanchisserie',
  'lostfound.record': 'Enregistrer un objet trouvé',
  'lostfound.manage': 'Stocker / restituer / archiver les objets trouvés',
  'restaurant.view': 'Restaurant : voir le tableau de bord, la salle et les commandes',
  'restaurant.order': 'Restaurant : prendre et modifier des commandes, gérer les tables',
  'restaurant.kitchen': 'Cuisine : écran cuisine (préparation, commande prête)',
  'restaurant.bar': 'Bar : préparation des boissons, ventes au comptoir',
  'restaurant.menu': 'Restaurant : gérer la carte, les menus, les tables et les recettes',
  'restaurant.discount': 'Restaurant : accorder une remise',
  'restaurant.cancel': 'Restaurant : annuler une commande ou un plat déjà envoyé en cuisine',
  'restaurant.settle': 'Restaurant : encaisser, porter sur la chambre, facturer',
  'restaurant.reports': 'Restaurant : rapports et statistiques',
  'roomservice.deliver': 'Room service : prendre en charge et livrer',
  'breakfast.manage': 'Petit-déjeuner : pointer les consommations',
  'stock.view': 'Stock : consulter',
  'stock.manage': 'Stock : articles, entrepôts, entrées, ajustements, pertes',
  'stock.issue': 'Stock : sorties pour consommation (restaurant, housekeeping, maintenance…)',
  'stock.transfer': 'Stock : transferts entre entrepôts',
  'stock.inventory': 'Stock : inventaires (comptage et validation)',
  'stock.approve': 'Stock : valider les écarts d\'inventaire importants',
  'stock.force': 'Stock : autoriser une sortie supérieure au disponible',
  'purchase.request': 'Achats : créer des demandes d\'achat',
  'purchase.approve': 'Achats : valider / refuser les demandes',
  'purchase.order': 'Achats : devis, comparaison, bons de commande',
  'purchase.receive': 'Achats : réceptionner les marchandises',
  'purchase.pay': 'Achats : factures et paiements fournisseurs',
  'purchase.reports': 'Achats & stocks : rapports et exports comptables',
  'suppliers.manage': 'Gérer les fournisseurs',
  'guests.view': 'Voir les clients',
  'guests.edit': 'Modifier les clients',
  'users.manage': 'Administration : gérer les comptes utilisateurs',
  'roles.manage': 'Administration : gérer les rôles et les permissions',
  'departments.manage': 'Administration : gérer les départements',
  'admin.view': 'Administration : tableau de bord administratif et état du système',
  'security.manage': 'Administration : sécurité (sessions, verrouillage, appareils, politique de mot de passe)',
  'backups.manage': 'Sauvegardes : créer, vérifier, télécharger, configurer',
  'backups.restore': 'Sauvegardes : restaurer une sauvegarde (écrase les données actuelles)',
  'devices.manage': 'Approuver les appareils',
  'audit.view': 'Consulter le journal d\'audit',
  'settings.manage': 'Modifier les paramètres',
  'nightaudit.view': 'Night audit : consulter',
  'nightaudit.check': 'Night audit : lancer les vérifications et commenter',
  'nightaudit.correct': 'Night audit : traiter / justifier les anomalies',
  'nightaudit.cash': 'Night audit : compter et valider la caisse',
  'nightaudit.post': 'Night audit : comptabiliser les revenus',
  'nightaudit.close': 'Night audit : valider et clôturer la journée',
  'nightaudit.reopen': 'Night audit : réouvrir une journée clôturée (exceptionnel)',
  'nightaudit.history': 'Night audit : consulter l\'historique et les rapports',
  'reports.view': 'Rapports & statistiques : accéder au centre de rapports',
  'reports.global': 'Rapports : tableau de bord analytique global (direction)',
  'reports.reservations': 'Rapports : réservations et hébergement',
  'reports.manage': 'Rapports : définir les vues par défaut des rôles',
};

const all = Object.keys(PERMISSIONS);

export const ROLES: Record<string, { name: string; perms: string[] }> = {
  admin: { name: 'Super administrateur', perms: all },
  manager: { name: 'Directeur', perms: all.filter((p) => !['users.manage', 'roles.manage', 'devices.manage', 'settings.manage', 'security.manage', 'backups.manage', 'backups.restore'].includes(p)) },
  tech_admin: { name: 'Admin technique', perms: ['dashboard.view', 'admin.view', 'users.manage', 'roles.manage', 'departments.manage', 'devices.manage', 'security.manage', 'audit.view', 'settings.manage', 'backups.manage', 'backups.restore', 'rooms.view', 'planning.view'] },
  reception: {
    name: 'Réception',
    perms: ['hr.self', 
      'dashboard.view', 'planning.view', 'reservations.view', 'reservations.create', 'reservations.edit', 'reservations.cancel',
      'frontoffice.checkin', 'frontoffice.checkout', 'frontoffice.charges', 'frontoffice.refund', 'payments.create', 'cash.operate', 'invoices.create', 'invoices.view', 'rooms.view', 'housekeeping.view',
      'guests.view', 'guests.edit', 'crm.view', 'crm.loyalty', 'maintenance.manage', 'maintenance.view', 'maintenance.report', 'housekeeping.dnd', 'lostfound.record', 'lostfound.manage',
      'restaurant.view', 'restaurant.order', 'restaurant.settle', 'breakfast.manage',
    ],
  },
  accountant: {
    name: 'Comptabilité',
    perms: ['hr.self', 'dashboard.view', 'dashboard.finance', 'reservations.view', 'payments.create', 'payments.void', 'invoices.view', 'invoices.create', 'invoices.credit',
      'cash.operate', 'cash.manage', 'expenses.create', 'finance.reports', 'frontoffice.refund', 'audit.view', 'guests.view', 'restaurant.view', 'restaurant.reports', 'stock.view', 'purchase.pay', 'purchase.reports', 'suppliers.manage', 'hr.salary', 'hr.payroll', 'hr.payroll_pay', 'hr.reports', 'hr.view', 'crm.view', 'crm.billing'],
  },
  housekeeping: { name: 'Femme / valet de chambre', perms: ['hr.self', 'housekeeping.view', 'housekeeping.update', 'housekeeping.dnd', 'housekeeping.minibar', 'lostfound.record', 'rooms.view', 'maintenance.manage', 'maintenance.report'] },
  hk_supervisor: {
    name: 'Gouvernante / superviseur ménage',
    perms: ['hr.self', 'dashboard.view', 'planning.view', 'rooms.view', 'housekeeping.view', 'housekeeping.update', 'housekeeping.manage', 'housekeeping.inspect', 'housekeeping.dnd',
      'housekeeping.minibar', 'housekeeping.reports', 'linen.manage', 'lostfound.record', 'lostfound.manage', 'maintenance.manage', 'maintenance.view', 'maintenance.report', 'stock.view', 'stock.issue', 'purchase.request'],
  },
  waiter: { name: 'Serveur', perms: ['hr.self', 'restaurant.view', 'restaurant.order', 'roomservice.deliver', 'breakfast.manage', 'stock.view'] },
  chef: { name: 'Chef cuisinier', perms: ['hr.self', 'maintenance.report', 'restaurant.view', 'restaurant.kitchen', 'restaurant.menu', 'stock.view', 'stock.manage', 'stock.issue', 'purchase.request'] },
  barman: { name: 'Barman', perms: ['hr.self', 'restaurant.view', 'restaurant.order', 'restaurant.bar', 'restaurant.settle', 'cash.operate', 'payments.create', 'stock.view'] },
  rs_manager: {
    name: 'Responsable restaurant',
    perms: ['hr.self', 'dashboard.view', 'maintenance.report', 'restaurant.view', 'restaurant.order', 'restaurant.kitchen', 'restaurant.bar', 'restaurant.menu', 'restaurant.discount', 'restaurant.cancel',
      'restaurant.settle', 'restaurant.reports', 'roomservice.deliver', 'breakfast.manage', 'stock.view', 'stock.manage', 'stock.issue', 'stock.transfer', 'purchase.request', 'cash.operate', 'payments.create', 'invoices.view', 'invoices.create', 'guests.view', 'crm.view'],
  },
  cashier: { name: 'Caissier', perms: ['hr.self', 'restaurant.view', 'restaurant.settle', 'cash.operate', 'payments.create', 'invoices.view', 'invoices.create', 'expenses.create', 'guests.view'] },
  storekeeper: { name: 'Magasinier', perms: ['hr.self', 'stock.view', 'stock.manage', 'stock.issue', 'stock.transfer', 'stock.inventory', 'purchase.request', 'purchase.receive'] },
  technician: { name: 'Technicien de maintenance', perms: ['hr.self', 'maintenance.view', 'maintenance.report', 'maintenance.work', 'rooms.view', 'stock.view', 'purchase.request'] },
  maintenance_manager: {
    name: 'Responsable maintenance',
    perms: ['hr.self', 'dashboard.view', 'planning.view', 'rooms.view', 'maintenance.manage', 'maintenance.view', 'maintenance.report', 'maintenance.work', 'maintenance.supervise', 'maintenance.reports', 'equipment.manage',
      'stock.view', 'stock.issue', 'purchase.request', 'suppliers.manage', 'expenses.create', 'purchase.pay', 'cash.operate'],
  },
  employee: { name: 'Employé', perms: ['hr.self'] },
  crm_manager: {
    name: 'Responsable relation client',
    perms: ['dashboard.view', 'hr.self', 'guests.view', 'guests.edit', 'reservations.view', 'planning.view', 'invoices.view', 'crm.view', 'crm.manage', 'crm.billing', 'crm.loyalty', 'crm.complaints', 'crm.marketing', 'crm.reports', 'crm.privacy'],
  },
  dept_head: { name: 'Chef de département', perms: ['dashboard.view', 'hr.self', 'hr.view', 'hr.team', 'maintenance.report'] },
  hr_manager: {
    name: 'Responsable RH',
    perms: ['dashboard.view', 'hr.self', 'hr.view', 'hr.team', 'hr.manage', 'hr.salary', 'hr.payroll', 'hr.reports', 'hr.terminal', 'maintenance.report'],
  },
  hr_terminal: { name: 'Borne de pointage', perms: ['hr.terminal'] },
  purchaser: { name: 'Acheteur', perms: ['hr.self', 'stock.view', 'purchase.request', 'purchase.order', 'purchase.receive', 'purchase.reports', 'suppliers.manage'] },
};
// Rôles de l'organigramme hôtelier (Phase 14)
ROLES.reception.name = 'Réceptionniste';
ROLES.accountant.name = 'Comptable';
ROLES.employee.name = 'Utilisateur standard';
ROLES.hk_supervisor.name = 'Responsable housekeeping';
ROLES.housekeeping.name = 'Agent housekeeping';
ROLES.rs_manager.name = 'Responsable restaurant';
ROLES.maintenance_manager.name = 'Responsable maintenance';
ROLES.technician.name = 'Technicien';
ROLES.reception_manager = { name: 'Responsable réception', perms: [...ROLES.reception.perms, 'reservations.override_policy', 'frontoffice.checkout_with_balance', 'payments.void', 'invoices.credit', 'cash.manage', 'services.manage', 'guests.edit', 'reports.reservations', 'audit.view', 'departments.manage'] };
ROLES.finance_manager = { name: 'Responsable comptabilité', perms: [...ROLES.accountant.perms, 'reports.global', 'dashboard.finance', 'admin.view'] };
ROLES.hr_officer = { name: 'Employé RH', perms: ['dashboard.view', 'hr.self', 'hr.view', 'hr.team', 'hr.manage', 'hr.reports', 'hr.terminal'] };
ROLES.stock_manager = { name: 'Responsable stocks', perms: [...new Set([...ROLES.storekeeper.perms, ...ROLES.purchaser.perms, 'dashboard.view', 'stock.reports'].filter((p) => p in PERMISSIONS))] };
// Night audit
ROLES.reception.perms.push('nightaudit.view', 'nightaudit.check', 'nightaudit.correct', 'nightaudit.history');
ROLES.accountant.perms.push('nightaudit.view', 'nightaudit.check', 'nightaudit.correct', 'nightaudit.cash', 'nightaudit.post', 'nightaudit.close', 'nightaudit.history');
ROLES.night_auditor = {
  name: 'Auditeur de nuit',
  perms: ['hr.self', 'dashboard.view', 'planning.view', 'reservations.view', 'reservations.edit', 'reservations.cancel', 'frontoffice.checkin', 'frontoffice.checkout', 'frontoffice.charges',
    'payments.create', 'cash.operate', 'invoices.view', 'invoices.create', 'rooms.view', 'housekeeping.view', 'guests.view', 'restaurant.view', 'restaurant.settle',
    'nightaudit.view', 'nightaudit.check', 'nightaudit.correct', 'nightaudit.cash', 'nightaudit.post', 'nightaudit.close', 'nightaudit.history'],
};
// Rapports & statistiques : la réception voit les rapports réservations / hébergement ; tout rôle ayant au moins un droit de rapport accède au centre de rapports.
ROLES.reception.perms.push('reports.reservations');
const REPORT_PERMS = ['reports.global', 'reports.reservations', 'finance.reports', 'restaurant.reports', 'housekeeping.reports', 'purchase.reports', 'maintenance.reports', 'hr.reports', 'crm.reports'];
for (const r of Object.values(ROLES)) if (r.perms.some((p) => REPORT_PERMS.includes(p)) && !r.perms.includes('reports.view')) r.perms.push('reports.view');


// Les rôles « responsables » héritent des droits de leur équipe déjà définis plus haut (night audit, rapports)
ROLES.reception_manager.perms = [...new Set([...ROLES.reception_manager.perms, ...ROLES.reception.perms])];
ROLES.finance_manager.perms = [...new Set([...ROLES.finance_manager.perms, ...ROLES.accountant.perms])];
for (const r of Object.values(ROLES)) r.perms = [...new Set(r.perms.filter((p) => p in PERMISSIONS))];

/** Permissions donnant accès à des données sensibles (salaires, finances détaillées, données personnelles, sécurité). */
export const SENSITIVE = new Set(['hr.salary', 'hr.payroll', 'hr.payroll_pay', 'crm.billing', 'crm.privacy', 'dashboard.finance', 'finance.reports', 'payments.void', 'invoices.credit',
  'users.manage', 'roles.manage', 'security.manage', 'settings.manage', 'devices.manage', 'audit.view', 'backups.manage', 'backups.restore', 'nightaudit.reopen', 'frontoffice.refund', 'reservations.override_policy']);
/** Libellés des modules (préfixe du code de permission). */
export const MODULES: Record<string, string> = {
  dashboard: 'Tableau de bord', planning: 'Planning', reservations: 'Réservations', frontoffice: 'Réception', services: 'Prestations', payments: 'Paiements', invoices: 'Factures',
  cash: 'Caisse', expenses: 'Dépenses', finance: 'Finances', rooms: 'Chambres', housekeeping: 'Housekeeping', lostfound: 'Objets trouvés', restaurant: 'Restaurant',
  roomservice: 'Room service', breakfast: 'Petit-déjeuner', stock: 'Stocks', purchase: 'Achats', suppliers: 'Fournisseurs', maintenance: 'Maintenance', hr: 'Ressources humaines',
  guests: 'Clients', crm: 'CRM', reports: 'Rapports', nightaudit: 'Night audit', users: 'Utilisateurs', roles: 'Rôles', departments: 'Départements', admin: 'Administration',
  security: 'Sécurité', devices: 'Appareils', audit: 'Journal d\'audit', settings: 'Paramètres', backups: 'Sauvegardes',
};
/** Classement d'une permission dans la grille module × action. */
export function actionOf(code: string): string {
  const a = code.split('.')[1] ?? '';
  if (SENSITIVE.has(code) && /salary|payroll|billing|privacy|finance/.test(a)) return 'sensitive';
  if (/^(view|self|history)$/.test(a)) return 'view';
  if (/^(create|record|request|order|report|issue|enroll)$/.test(a)) return 'create';
  if (/^(edit|update|manage|menu|work|team|kitchen|bar|dnd|minibar|charges|loyalty|marketing|complaints|transfer|inventory|receive|deliver|checkin|checkout|operate|correct|check|cash|post|terminal|order)$/.test(a)) return 'edit';
  if (/^(delete|purge)$/.test(a)) return 'delete';
  if (/^(validate|approve|close|override_policy|checkout_with_balance|settle|pay|payroll_pay)$/.test(a)) return 'validate';
  if (/^(cancel|void|credit|refund|reopen|restore)$/.test(a)) return 'cancel';
  if (/^(reports|export|global|reservations)$/.test(a)) return 'export';
  if (/^(print)$/.test(a)) return 'print';
  return 'other';
}
