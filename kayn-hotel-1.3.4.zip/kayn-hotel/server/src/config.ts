import { fileURLToPath } from 'node:url';
import 'dotenv/config';

export const config = {
  databaseUrl: process.env.DATABASE_URL ?? 'postgres://postgres@localhost:5432/kayn_hotel',
  port: Number(process.env.PORT ?? 8080),
  host: process.env.HOST ?? '0.0.0.0',
  sessionHours: Number(process.env.SESSION_HOURS ?? 12),
  cookieSecure: process.env.COOKIE_SECURE === 'true',
  webDist: process.env.WEB_DIST ?? fileURLToPath(new URL('../../web/dist', import.meta.url)),
  timezone: process.env.HOTEL_TZ ?? 'Africa/Algiers',
  /** Désactiver l'approbation des appareils (utile en développement uniquement) */
  requireDeviceApproval: process.env.REQUIRE_DEVICE_APPROVAL !== 'false',
};
