import Fastify from 'fastify';
import cookie from '@fastify/cookie';
import rateLimit from '@fastify/rate-limit';
import multipart from '@fastify/multipart';
import fastifyStatic from '@fastify/static';
import { existsSync } from 'node:fs';
import { ZodError, z } from 'zod';

// messages de validation en français, avec le nom des champs en clair
z.config(z.locales.fr());
const FIELD: Record<string, string> = {
  username: 'Identifiant', password: 'Mot de passe', email: 'E-mail', phone: 'Téléphone', first_name: 'Prénom', last_name: 'Nom', company_name: 'Raison sociale',
  name: 'Nom', code: 'Code', description: 'Désignation', amount: 'Montant', method: 'Mode de paiement', reference: 'Référence', reason: 'Motif', note: 'Note', notes: 'Notes',
  check_in: 'Date d\'arrivée', check_out: 'Date de départ', rooms: 'Chambres', room_id: 'Chambre', adults: 'Adultes', children: 'Enfants', rate: 'Tarif', price: 'Prix',
  quantity: 'Quantité', unit_price: 'Prix unitaire', discount: 'Remise', category: 'Catégorie', role: 'Rôle', department_id: 'Département', valid_from: 'Date d\'application',
  opening_amount: 'Fond de caisse', counted: 'Montant compté', justification: 'Justification', text: 'Commentaire', confirm: 'Confirmation', birth_date: 'Date de naissance',
  id_doc_number: 'N° de pièce d\'identité', nationality: 'Nationalité', check_in_time: 'Heure d\'arrivée', check_out_time: 'Heure de départ', vat_rate: 'TVA',
  currency: 'Devise', currency_symbol: 'Symbole monétaire', timezone: 'Fuseau horaire', card_last4: '4 derniers chiffres de la carte', start_date: 'Date de début', end_date: 'Date de fin',
};
/** Formulations simples pour le personnel (les autres cas gardent le message français de zod). */
function frIssue(i: any): string {
  if (i.code === 'invalid_type' && /indéfini|undefined/.test(i.message)) return 'obligatoire';
  if (i.code === 'too_small' && i.origin === 'string') return Number(i.minimum) <= 1 ? 'obligatoire' : `au moins ${i.minimum} caractères`;
  if (i.code === 'too_big' && i.origin === 'string') return `${i.maximum} caractères maximum`;
  if (i.code === 'too_small' && i.origin === 'array') return Number(i.minimum) <= 1 ? 'au moins un élément requis' : `au moins ${i.minimum} éléments`;
  if (i.code === 'too_small' && i.origin === 'number') return `doit être ${i.inclusive ? '≥' : '>'} ${i.minimum}`;
  if (i.code === 'too_big' && i.origin === 'number') return `doit être ${i.inclusive ? '≤' : '<'} ${i.maximum}`;
  return i.message;
}
const fieldOf = (path: PropertyKey[]) => { const k = [...path].reverse().find((x) => typeof x === 'string') as string | undefined; return k ? (FIELD[k] ?? k) : 'Données'; };
import { config } from './config.js';
import { getPool, one } from './db/pool.js';
import { AppError, fromPg } from './lib/errors.js';
import { authRoutes } from './routes/auth.js';
import { reservationRoutes } from './routes/reservations.js';
import { roomRoutes } from './routes/rooms.js';
import { roomsAdminRoutes } from './routes/roomsAdmin.js';
import { frontOfficeRoutes } from './routes/frontoffice.js';
import { billingRoutes } from './routes/billing.js';
import { housekeepingRoutes } from './routes/housekeeping.js';
import { restaurantRoutes } from './routes/restaurant.js';
import { stockRoutes } from './routes/stock.js';
import { maintenanceRoutes } from './routes/maintenance.js';
import { hrRoutes } from './routes/hr.js';
import { crmRoutes } from './routes/crm.js';
import { analyticsRoutes } from './routes/analytics.js';
import { nightAuditRoutes } from './routes/nightaudit.js';
import { adminRoutes, maintenanceGuard } from './routes/admin.js';
import { setupRoutes } from './routes/setup.js';
import { idScanRoutes } from './routes/idscan.js';
import { monthlyReportRoutes } from './routes/monthlyReport.js';
import { maintenance } from './lib/auth.js';

export async function buildApp(opts: { logger?: boolean | Record<string, unknown>; serveWeb?: boolean } = {}) {
  const app = Fastify({ logger: (opts.logger ?? false) as any, trustProxy: false, bodyLimit: 1_000_000 });

  maintenanceGuard(app, maintenance);
  await app.register(cookie);
  await app.register(rateLimit, { max: 600, timeWindow: '1 minute' });
  await app.register(multipart, { limits: { fileSize: 6 * 1024 * 1024, files: 1 } });

  // En-têtes de sécurité
  app.addHook('onSend', async (_req, rep, payload) => {
    rep.header('X-Content-Type-Options', 'nosniff');
    rep.header('X-Frame-Options', 'SAMEORIGIN');
    rep.header('Referrer-Policy', 'same-origin');
    return payload;
  });

  // Protection CSRF : toute requête modifiante doit venir de l'application (en-tête personnalisé)
  app.addHook('preHandler', async (req) => {
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && req.url.startsWith('/api/')) {
      if (req.headers['x-kayn-client'] !== 'web') throw new AppError(403, 'csrf', 'Requête refusée (origine inconnue).');
    }
  });

  /**
   * Anti double opération : une requête modifiante portant l'en-tête « Idempotency-Key » n'est exécutée qu'une fois.
   * Répétée (double clic, réseau qui renvoie), elle reçoit la réponse de la première exécution ; pendant l'exécution, 409.
   */
  app.addHook('preHandler', async (req, rep) => {
    const key = req.headers['idempotency-key'];
    if (typeof key !== 'string' || !['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) || !req.url.startsWith('/api/')) return;
    if (!/^[A-Za-z0-9_-]{8,100}$/.test(key)) throw new AppError(400, 'bad_request', 'Clé d\'opération invalide.');
    const ins = await one(getPool(), `INSERT INTO idempotency_keys (key, method, url) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING RETURNING key`, [key, req.method, req.url]);
    if (ins) { (req as any).idemKey = key; return; }
    const prev = await one<any>(getPool(), 'SELECT * FROM idempotency_keys WHERE key = $1', [key]);
    if (!prev || prev.method !== req.method || prev.url !== req.url) throw new AppError(409, 'idempotency', 'Clé d\'opération déjà utilisée pour une autre action.');
    if (prev.status_code === null) throw new AppError(409, 'in_progress', 'Opération déjà en cours de traitement : patientez.');
    rep.header('idempotent-replay', 'true').header('content-type', 'application/json; charset=utf-8').code(prev.status_code);
    return rep.send(prev.response === null ? '' : JSON.stringify(prev.response));
  });
  app.addHook('onSend', async (req, rep, payload) => {
    const key = (req as any).idemKey;
    if (!key) return payload;
    (req as any).idemKey = null;
    if (rep.statusCode >= 200 && rep.statusCode < 300) {
      let body: unknown = null;
      try { body = typeof payload === 'string' && payload ? JSON.parse(payload) : null; } catch { body = null; }
      await getPool().query('UPDATE idempotency_keys SET status_code = $2, response = $3 WHERE key = $1', [key, rep.statusCode, body === null ? null : JSON.stringify(body)]);
    } else {
      // échec : la clé est libérée pour permettre de corriger et réessayer
      await getPool().query('DELETE FROM idempotency_keys WHERE key = $1', [key]);
    }
    return payload;
  });

  app.setErrorHandler((err: any, _req, rep) => {
    if (err instanceof ZodError) {
      return rep.code(400).send({ error: 'validation', message: err.issues.map((i) => `${fieldOf(i.path)} : ${frIssue(i)}`).join(' · '), fields: err.issues.map((i) => i.path.join('.')) });
    }
    const pgErr = fromPg(err);
    const e = err instanceof AppError ? err : pgErr;
    if (e) return rep.code(e.status).send({ error: e.code, message: e.message, details: e.details });
    if (err.statusCode && err.statusCode < 500) return rep.code(err.statusCode).send({ error: 'request', message: err.message });
    app.log.error(err);
    console.error(err);
    return rep.code(500).send({ error: 'server', message: 'Erreur interne du serveur.' });
  });

  app.get('/api/health', async () => ({ ok: true, version: '1.0.0' }));
  await app.register(authRoutes);
  await app.register(monthlyReportRoutes);
  await app.register(reservationRoutes);
  await app.register(roomRoutes);
  await app.register(roomsAdminRoutes);
  await app.register(frontOfficeRoutes);
  await app.register(billingRoutes);
  await app.register(housekeepingRoutes);
  await app.register(restaurantRoutes);
  await app.register(stockRoutes);
  await app.register(maintenanceRoutes);
  await app.register(hrRoutes);
  await app.register(crmRoutes);
  await app.register(analyticsRoutes);
  await app.register(nightAuditRoutes);
  await app.register(adminRoutes);
  await app.register(setupRoutes);
  await app.register(idScanRoutes);
  app.addHook('onClose', async () => { const { stopOcr } = await import('./services/idscan.js'); await stopOcr(); });

  if (opts.serveWeb !== false && existsSync(config.webDist)) {
    await app.register(fastifyStatic, { root: config.webDist, prefix: '/' });
    app.setNotFoundHandler((req, rep) => {
      if (req.url.startsWith('/api/')) return rep.code(404).send({ error: 'not_found', message: 'Route inconnue' });
      return rep.sendFile('index.html');
    });
  }
  return app;
}
