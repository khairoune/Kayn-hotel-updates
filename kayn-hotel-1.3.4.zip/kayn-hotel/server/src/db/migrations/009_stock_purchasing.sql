-- =====================================================================================================
-- Phase 8 : Stocks & Achats (entrepôts, lots / péremption, PMP, achats, devis, réceptions,
--           factures et paiements fournisseurs, inventaires)
-- =====================================================================================================

-- ---------- Entrepôts ----------
CREATE TABLE warehouses (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  code        text NOT NULL,
  name        text NOT NULL,
  kind        text NOT NULL DEFAULT 'store' CHECK (kind IN ('store','reserve','kitchen','bar','housekeeping','maintenance','other')),
  is_default  boolean NOT NULL DEFAULT false,
  active      boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, code)
);
CREATE UNIQUE INDEX warehouses_default_uq ON warehouses(hotel_id) WHERE is_default;

-- ---------- Produits ----------
ALTER TABLE products
  ADD COLUMN description   text,
  ADD COLUMN barcode       text,
  ADD COLUMN max_stock     numeric(12,3),
  ADD COLUMN avg_cost      numeric(14,4) NOT NULL DEFAULT 0,     -- prix moyen pondéré
  ADD COLUMN tax_rate      numeric(5,2) NOT NULL DEFAULT 19,     -- TVA déductible habituelle
  ADD COLUMN track_lots    boolean NOT NULL DEFAULT false,       -- n° de lot et date de péremption
  ADD COLUMN default_warehouse_id int REFERENCES warehouses(id),
  ADD COLUMN linen_item_id int REFERENCES linen_items(id),       -- réception → stock du linge (Housekeeping)
  ADD COLUMN archived_at   timestamptz;
UPDATE products SET avg_cost = cost_price;
CREATE UNIQUE INDEX products_code_uq ON products(hotel_id, code) WHERE code IS NOT NULL;
CREATE UNIQUE INDEX products_barcode_uq ON products(hotel_id, barcode) WHERE barcode IS NOT NULL;

-- Stock par entrepôt (products.stock_qty = total de tous les entrepôts, tenu à jour par le même service)
CREATE TABLE stock_levels (
  product_id    int NOT NULL REFERENCES products(id),
  warehouse_id  int NOT NULL REFERENCES warehouses(id),
  qty           numeric(12,3) NOT NULL DEFAULT 0,
  PRIMARY KEY (product_id, warehouse_id)
);

-- Lots et péremption (consommation FEFO : premier périmé, premier sorti)
CREATE TABLE stock_lots (
  id            serial PRIMARY KEY,
  product_id    int NOT NULL REFERENCES products(id),
  warehouse_id  int NOT NULL REFERENCES warehouses(id),
  lot_no        text,
  expiry_date   date,
  qty           numeric(12,3) NOT NULL DEFAULT 0 CHECK (qty >= 0),
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX stock_lots_idx ON stock_lots(product_id, warehouse_id, expiry_date);

-- ---------- Mouvements : entrepôt, valeur, département, référence ----------
ALTER TABLE stock_movements DROP CONSTRAINT stock_movements_kind_check;
ALTER TABLE stock_movements ADD CONSTRAINT stock_movements_kind_check CHECK (kind IN (
  'in','out','adjust','sale','waste',                                 -- anciens types (conservés)
  'receipt','issue','transfer_out','transfer_in','supplier_return','inventory','damaged','expired'));
ALTER TABLE stock_movements
  ADD COLUMN warehouse_id   int REFERENCES warehouses(id),
  ADD COLUMN unit_cost      numeric(14,4),
  ADD COLUMN value          numeric(14,2),
  ADD COLUMN department     text CHECK (department IN ('restaurant','bar','housekeeping','maintenance','reception','admin','other')),
  ADD COLUMN lot_id         int REFERENCES stock_lots(id),
  ADD COLUMN ref_type       text,                       -- purchase_receipt, transfer, inventory, maintenance_ticket…
  ADD COLUMN ref_id         int,
  ADD COLUMN forced         boolean NOT NULL DEFAULT false;   -- sortie au-delà du disponible (autorisation)
CREATE INDEX stock_movements_prod_idx ON stock_movements(product_id, created_at);
CREATE INDEX stock_movements_ref_idx ON stock_movements(ref_type, ref_id);

-- ---------- Fournisseurs ----------
ALTER TABLE suppliers
  ADD COLUMN code           text,
  ADD COLUMN contact_name   text,
  ADD COLUMN mobile         text,
  ADD COLUMN city           text,
  ADD COLUMN rc             text,        -- registre de commerce
  ADD COLUMN nis            text,
  ADD COLUMN ai             text,        -- article d'imposition
  ADD COLUMN rib            text,
  ADD COLUMN payment_terms  int NOT NULL DEFAULT 30,   -- jours
  ADD COLUMN notes          text,
  ADD COLUMN created_at     timestamptz NOT NULL DEFAULT now();

CREATE TABLE supplier_products (
  supplier_id   int NOT NULL REFERENCES suppliers(id),
  product_id    int NOT NULL REFERENCES products(id),
  supplier_ref  text,
  last_price    numeric(12,2),
  lead_days     int,
  PRIMARY KEY (supplier_id, product_id)
);

-- ---------- Achats : demande → validation → devis → bon de commande → réceptions ----------
CREATE TABLE purchase_orders (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  number          text NOT NULL,                     -- DA2026-0001 (demande) puis BC2026-0001 (commande)
  po_number       text,
  status          text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending','approved','ordered','partial','received','cancelled')),
  department      text NOT NULL DEFAULT 'other',
  supplier_id     int REFERENCES suppliers(id),
  warehouse_id    int NOT NULL REFERENCES warehouses(id),
  needed_by       date,
  expected_date   date,
  reason          text,
  notes           text,
  subtotal        numeric(14,2) NOT NULL DEFAULT 0,
  tax_total       numeric(14,2) NOT NULL DEFAULT 0,
  total           numeric(14,2) NOT NULL DEFAULT 0,
  requested_by    int REFERENCES users(id),
  submitted_at    timestamptz,
  approved_by     int REFERENCES users(id),
  approved_at     timestamptz,
  rejection_reason text,
  ordered_by      int REFERENCES users(id),
  ordered_at      timestamptz,
  received_at     timestamptz,
  cancelled_by    int REFERENCES users(id),
  cancelled_at    timestamptz,
  cancel_reason   text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (hotel_id, number)
);
CREATE UNIQUE INDEX purchase_orders_po_uq ON purchase_orders(hotel_id, po_number) WHERE po_number IS NOT NULL;

CREATE TABLE purchase_order_lines (
  id            serial PRIMARY KEY,
  po_id         int NOT NULL REFERENCES purchase_orders(id),
  product_id    int NOT NULL REFERENCES products(id),
  quantity      numeric(12,3) NOT NULL CHECK (quantity > 0),
  unit_price    numeric(12,2) NOT NULL DEFAULT 0 CHECK (unit_price >= 0),
  tax_rate      numeric(5,2) NOT NULL DEFAULT 0,
  received_qty  numeric(12,3) NOT NULL DEFAULT 0 CHECK (received_qty >= 0),
  notes         text,
  CHECK (received_qty <= quantity)
);

CREATE TABLE purchase_quotes (
  id             serial PRIMARY KEY,
  po_id          int NOT NULL REFERENCES purchase_orders(id),
  supplier_id    int NOT NULL REFERENCES suppliers(id),
  reference      text,
  delivery_days  int,
  valid_until    date,
  notes          text,
  selected       boolean NOT NULL DEFAULT false,
  total          numeric(14,2) NOT NULL DEFAULT 0,
  created_by     int REFERENCES users(id),
  created_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (po_id, supplier_id)
);
CREATE TABLE purchase_quote_lines (
  quote_id    int NOT NULL REFERENCES purchase_quotes(id) ON DELETE CASCADE,
  line_id     int NOT NULL REFERENCES purchase_order_lines(id),
  unit_price  numeric(12,2) NOT NULL CHECK (unit_price >= 0),
  tax_rate    numeric(5,2) NOT NULL DEFAULT 0,
  available   boolean NOT NULL DEFAULT true,
  PRIMARY KEY (quote_id, line_id)
);

CREATE TABLE purchase_receipts (
  id            serial PRIMARY KEY,
  hotel_id      int NOT NULL REFERENCES hotels(id),
  number        text NOT NULL,                  -- BR2026-0001
  po_id         int NOT NULL REFERENCES purchase_orders(id),
  warehouse_id  int NOT NULL REFERENCES warehouses(id),
  delivery_note text,                           -- n° du bon de livraison fournisseur
  received_by   int REFERENCES users(id),
  received_at   timestamptz NOT NULL DEFAULT now(),
  notes         text,
  value         numeric(14,2) NOT NULL DEFAULT 0,
  UNIQUE (hotel_id, number)
);
CREATE TABLE purchase_receipt_lines (
  id            serial PRIMARY KEY,
  receipt_id    int NOT NULL REFERENCES purchase_receipts(id),
  po_line_id    int NOT NULL REFERENCES purchase_order_lines(id),
  product_id    int NOT NULL REFERENCES products(id),
  quantity      numeric(12,3) NOT NULL CHECK (quantity > 0),
  rejected_qty  numeric(12,3) NOT NULL DEFAULT 0 CHECK (rejected_qty >= 0),   -- refusé au contrôle (non conforme)
  unit_cost     numeric(12,2) NOT NULL,
  lot_no        text,
  expiry_date   date,
  movement_id   int REFERENCES stock_movements(id)
);
CREATE TRIGGER purchase_receipts_immutable BEFORE UPDATE OR DELETE ON purchase_receipts FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER purchase_receipt_lines_immutable BEFORE UPDATE OR DELETE ON purchase_receipt_lines FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ---------- Factures et paiements fournisseurs ----------
CREATE TABLE supplier_invoices (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  ref             text NOT NULL,                  -- n° interne FF2026-0001
  supplier_id     int NOT NULL REFERENCES suppliers(id),
  number          text NOT NULL,                  -- n° de la facture du fournisseur
  po_id           int REFERENCES purchase_orders(id),
  invoice_date    date NOT NULL,
  due_date        date NOT NULL,
  category        text NOT NULL DEFAULT 'Achats',
  subtotal        numeric(14,2) NOT NULL CHECK (subtotal >= 0),
  tax_total       numeric(14,2) NOT NULL DEFAULT 0 CHECK (tax_total >= 0),
  stamp_duty      numeric(14,2) NOT NULL DEFAULT 0 CHECK (stamp_duty >= 0),
  total           numeric(14,2) NOT NULL CHECK (total > 0),
  paid            numeric(14,2) NOT NULL DEFAULT 0,
  status          text NOT NULL DEFAULT 'unpaid' CHECK (status IN ('unpaid','partial','paid','cancelled')),
  received_value  numeric(14,2),                  -- valeur réceptionnée au moment de l'enregistrement (contrôle)
  notes           text,
  cancel_reason   text,
  created_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (hotel_id, ref),
  UNIQUE (supplier_id, number),
  CHECK (paid <= total)
);
CREATE TABLE supplier_payments (
  id              serial PRIMARY KEY,
  invoice_id      int NOT NULL REFERENCES supplier_invoices(id),
  amount          numeric(14,2) NOT NULL CHECK (amount > 0),
  method          text NOT NULL CHECK (method IN ('cash','card','cheque','transfer')),
  reference       text,
  paid_at         date NOT NULL,
  expense_id      int REFERENCES expenses(id),     -- dépense correspondante (Facturation & Caisse)
  created_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER supplier_payments_immutable BEFORE UPDATE OR DELETE ON supplier_payments FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ---------- Inventaires ----------
CREATE TABLE inventories (
  id             serial PRIMARY KEY,
  hotel_id       int NOT NULL REFERENCES hotels(id),
  number         text NOT NULL,                  -- INV2026-0001
  scope          text NOT NULL CHECK (scope IN ('full','category','warehouse')),
  warehouse_id   int REFERENCES warehouses(id),
  category       text,
  status         text NOT NULL DEFAULT 'open' CHECK (status IN ('open','validated','cancelled')),
  notes          text,
  created_by     int REFERENCES users(id),
  created_at     timestamptz NOT NULL DEFAULT now(),
  validated_by   int REFERENCES users(id),
  validated_at   timestamptz,
  gap_value      numeric(14,2),
  UNIQUE (hotel_id, number)
);
CREATE TABLE inventory_lines (
  id             serial PRIMARY KEY,
  inventory_id   int NOT NULL REFERENCES inventories(id),
  product_id     int NOT NULL REFERENCES products(id),
  warehouse_id   int NOT NULL REFERENCES warehouses(id),
  theoretical    numeric(12,3) NOT NULL,          -- stock théorique à l'ouverture
  counted        numeric(12,3) CHECK (counted >= 0),
  adjusted       numeric(12,3),                   -- écart appliqué à la validation
  unit_cost      numeric(14,4) NOT NULL DEFAULT 0,
  counted_by     int REFERENCES users(id),
  counted_at     timestamptz,
  note           text,
  UNIQUE (inventory_id, product_id, warehouse_id)
);
CREATE UNIQUE INDEX inventories_open_uq ON inventories(hotel_id, COALESCE(warehouse_id, 0), COALESCE(category, '')) WHERE status = 'open';

-- ---------- Reprise des données existantes : magasin central par hôtel ----------
INSERT INTO warehouses (hotel_id, code, name, kind, is_default) SELECT id, 'MAG', 'Magasin central', 'store', true FROM hotels;
INSERT INTO stock_levels (product_id, warehouse_id, qty)
  SELECT p.id, w.id, p.stock_qty FROM products p JOIN warehouses w ON w.hotel_id = p.hotel_id AND w.is_default;
UPDATE products p SET default_warehouse_id = w.id FROM warehouses w WHERE w.hotel_id = p.hotel_id AND w.is_default;
ALTER TABLE stock_movements DISABLE TRIGGER stock_movements_immutable;
UPDATE stock_movements m SET warehouse_id = p.default_warehouse_id FROM products p WHERE p.id = m.product_id AND m.warehouse_id IS NULL;
ALTER TABLE stock_movements ENABLE TRIGGER stock_movements_immutable;
