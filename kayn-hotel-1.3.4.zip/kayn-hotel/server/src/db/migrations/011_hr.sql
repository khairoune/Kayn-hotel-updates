-- =====================================================================================================
-- Phase 10 : Ressources humaines (employés, départements, postes, contrats, planning, pointage, congés,
-- paie, évaluations, formations, compétences, documents)
-- =====================================================================================================

-- ---------- Départements et postes ----------
CREATE TABLE hr_departments (
  id                   serial PRIMARY KEY,
  hotel_id             int NOT NULL REFERENCES hotels(id),
  code                 text NOT NULL,
  name                 text NOT NULL,
  manager_employee_id  int REFERENCES employees(id),
  builtin              boolean NOT NULL DEFAULT false,
  active               boolean NOT NULL DEFAULT true,
  sort_order           int NOT NULL DEFAULT 0,
  UNIQUE (hotel_id, code)
);
CREATE TABLE hr_positions (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  department       text NOT NULL,
  name             text NOT NULL,
  default_salary   numeric(14,2),
  active           boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, department, name)
);

-- ---------- Fiche employé (extension de la table existante, utilisée par le housekeeping) ----------
ALTER TABLE employees
  ADD COLUMN matricule          text,
  ADD COLUMN birth_date         date,
  ADD COLUMN gender             text CHECK (gender IN ('M','F')),
  ADD COLUMN address            text,
  ADD COLUMN city               text,
  ADD COLUMN emergency_contact  text,
  ADD COLUMN manager_id         int REFERENCES employees(id),
  ADD COLUMN contract_type      text,
  ADD COLUMN contract_start     date,
  ADD COLUMN contract_end       date,
  ADD COLUMN base_salary        numeric(14,2),
  ADD COLUMN status             text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','leave','left')),
  ADD COLUMN exit_date          date,
  ADD COLUMN exit_reason        text,
  ADD COLUMN leave_opening      numeric(6,2) NOT NULL DEFAULT 0,   -- solde de congés repris à la mise en service
  ADD COLUMN pin_hash           text,                              -- code de pointage (terminal)
  ADD COLUMN notes              text,
  ADD COLUMN updated_at         timestamptz NOT NULL DEFAULT now();
UPDATE employees SET status = CASE WHEN active THEN 'active' ELSE 'left' END;
UPDATE employees SET matricule = 'EMP' || lpad(id::text, 4, '0') WHERE matricule IS NULL;
ALTER TABLE employees ALTER COLUMN matricule SET NOT NULL;
CREATE UNIQUE INDEX employees_matricule_uq ON employees(hotel_id, upper(matricule));
CREATE INDEX employees_department_idx ON employees(hotel_id, department);
-- active reste synchronisé avec le statut (compatibilité des modules existants)
CREATE FUNCTION employees_sync_active() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.matricule IS NULL OR NEW.matricule = '' THEN NEW.matricule := 'EMP' || lpad(NEW.id::text, 4, '0'); END IF;
  IF TG_OP = 'UPDATE' AND NEW.active IS DISTINCT FROM OLD.active AND NEW.status IS NOT DISTINCT FROM OLD.status THEN
    NEW.status := CASE WHEN NEW.active THEN 'active' ELSE 'left' END;
  END IF;
  NEW.active := NEW.status <> 'left';
  RETURN NEW;
END $$;
CREATE TRIGGER employees_sync_active_trg BEFORE INSERT OR UPDATE ON employees FOR EACH ROW EXECUTE FUNCTION employees_sync_active();

-- ---------- Contrats, avenants ----------
CREATE TABLE hr_contracts (
  id             serial PRIMARY KEY,
  hotel_id       int NOT NULL REFERENCES hotels(id),
  employee_id    int NOT NULL REFERENCES employees(id),
  number         text NOT NULL,
  kind           text NOT NULL CHECK (kind IN ('cdi','cdd','seasonal','trial','internship','consultant','other')),
  position       text,
  department     text,
  start_date     date NOT NULL,
  end_date       date,
  trial_end      date,
  base_salary    numeric(14,2) NOT NULL DEFAULT 0 CHECK (base_salary >= 0),
  weekly_hours   numeric(5,2) NOT NULL DEFAULT 40,
  status         text NOT NULL DEFAULT 'active' CHECK (status IN ('active','ended','archived')),
  renewed_from   int REFERENCES hr_contracts(id),
  notes          text,
  created_by     int REFERENCES users(id),
  created_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (hotel_id, number),
  CHECK (end_date IS NULL OR end_date >= start_date)
);
CREATE UNIQUE INDEX hr_contracts_one_active ON hr_contracts(employee_id) WHERE status = 'active';
CREATE TABLE hr_contract_amendments (
  id              serial PRIMARY KEY,
  contract_id     int NOT NULL REFERENCES hr_contracts(id),
  effective_date  date NOT NULL,
  description     text NOT NULL,
  new_salary      numeric(14,2),
  new_position    text,
  new_end_date    date,
  new_weekly_hours numeric(5,2),
  created_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER hr_amendments_immutable BEFORE UPDATE OR DELETE ON hr_contract_amendments FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ---------- Planning ----------
CREATE TABLE hr_shift_types (
  id             serial PRIMARY KEY,
  hotel_id       int NOT NULL REFERENCES hotels(id),
  code           text NOT NULL,
  name           text NOT NULL,
  start_time     time NOT NULL,
  end_time       time NOT NULL,          -- < start_time = poste de nuit (fin le lendemain)
  break_minutes  int NOT NULL DEFAULT 0 CHECK (break_minutes >= 0),
  color          text NOT NULL DEFAULT '#64748B',
  active         boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, code)
);
CREATE TABLE hr_schedule (
  id             serial PRIMARY KEY,
  hotel_id       int NOT NULL REFERENCES hotels(id),
  employee_id    int NOT NULL REFERENCES employees(id),
  work_date      date NOT NULL,
  shift_type_id  int REFERENCES hr_shift_types(id),
  start_time     time,
  end_time       time,
  break_minutes  int NOT NULL DEFAULT 0,
  rest           boolean NOT NULL DEFAULT false,      -- jour de repos
  zone           text,
  notes          text,
  created_by     int REFERENCES users(id),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (employee_id, work_date),
  CHECK (rest OR (start_time IS NOT NULL AND end_time IS NOT NULL))
);
CREATE INDEX hr_schedule_date_idx ON hr_schedule(hotel_id, work_date);
CREATE TABLE hr_shift_swaps (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  requester_id    int NOT NULL REFERENCES employees(id),
  target_id       int NOT NULL REFERENCES employees(id),
  date_a          date NOT NULL,                       -- poste du demandeur
  date_b          date NOT NULL,                       -- poste du collègue
  reason          text,
  status          text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','refused','cancelled')),
  requested_by    int REFERENCES users(id),
  decided_by      int REFERENCES users(id),
  decided_at      timestamptz,
  decision_note   text,
  created_at      timestamptz NOT NULL DEFAULT now()
);

-- ---------- Pointage ----------
CREATE TABLE hr_attendance (
  id                serial PRIMARY KEY,
  hotel_id          int NOT NULL REFERENCES hotels(id),
  employee_id       int NOT NULL REFERENCES employees(id),
  work_date         date NOT NULL,
  clock_in          timestamptz,
  clock_out         timestamptz,
  break_minutes     int NOT NULL DEFAULT 0,
  break_started_at  timestamptz,
  scheduled_start   timestamptz,
  scheduled_end     timestamptz,
  scheduled_minutes int NOT NULL DEFAULT 0,
  late_minutes      int NOT NULL DEFAULT 0,
  early_minutes     int NOT NULL DEFAULT 0,
  worked_minutes    int NOT NULL DEFAULT 0,
  overtime_minutes  int NOT NULL DEFAULT 0,
  source            text NOT NULL DEFAULT 'manual' CHECK (source IN ('self','manual','terminal','correction')),
  corrected         boolean NOT NULL DEFAULT false,
  created_by        int REFERENCES users(id),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  UNIQUE (employee_id, work_date),
  CHECK (clock_out IS NULL OR clock_in IS NULL OR clock_out > clock_in)
);
CREATE INDEX hr_attendance_date_idx ON hr_attendance(hotel_id, work_date);
CREATE TABLE hr_attendance_corrections (
  id             serial PRIMARY KEY,
  hotel_id       int NOT NULL REFERENCES hotels(id),
  employee_id    int NOT NULL REFERENCES employees(id),
  work_date      date NOT NULL,
  attendance_id  int REFERENCES hr_attendance(id),
  before         jsonb,
  clock_in       timestamptz,
  clock_out      timestamptz,
  break_minutes  int,
  reason         text NOT NULL,
  status         text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','refused')),
  requested_by   int REFERENCES users(id),
  decided_by     int REFERENCES users(id),
  decided_at     timestamptz,
  created_at     timestamptz NOT NULL DEFAULT now()
);

-- ---------- Congés et absences ----------
CREATE TABLE hr_leave_types (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  code             text NOT NULL,
  name             text NOT NULL,
  paid             boolean NOT NULL DEFAULT true,       -- maintien du salaire
  deducts_balance  boolean NOT NULL DEFAULT false,      -- décompté du solde de congés annuels
  hourly           boolean NOT NULL DEFAULT false,      -- autorisation de sortie (heures)
  requires_document boolean NOT NULL DEFAULT false,
  justified        boolean NOT NULL DEFAULT true,
  color            text NOT NULL DEFAULT '#0E7490',
  builtin          boolean NOT NULL DEFAULT false,
  active           boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, code)
);
CREATE TABLE hr_leave_requests (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  number          text NOT NULL,
  employee_id     int NOT NULL REFERENCES employees(id),
  type_id         int NOT NULL REFERENCES hr_leave_types(id),
  start_date      date NOT NULL,
  end_date        date NOT NULL,
  start_time      time,                     -- autorisation de sortie
  end_time        time,
  days            numeric(6,2) NOT NULL DEFAULT 0,
  hours           numeric(6,2) NOT NULL DEFAULT 0,
  reason          text,
  status          text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','refused','cancelled')),
  requested_by    int REFERENCES users(id),
  decided_by      int REFERENCES users(id),
  decided_at      timestamptz,
  decision_note   text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (hotel_id, number),
  CHECK (end_date >= start_date)
);
CREATE INDEX hr_leave_emp_idx ON hr_leave_requests(employee_id, start_date);
CREATE TABLE hr_leave_adjustments (
  id           serial PRIMARY KEY,
  employee_id  int NOT NULL REFERENCES employees(id),
  adj_date     date NOT NULL DEFAULT CURRENT_DATE,
  days         numeric(6,2) NOT NULL,
  reason       text NOT NULL,
  created_by   int REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER hr_leave_adj_immutable BEFORE UPDATE OR DELETE ON hr_leave_adjustments FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ---------- Paie ----------
CREATE TABLE hr_pay_items (                -- primes, indemnités, retenues récurrentes ou ponctuelles
  id           serial PRIMARY KEY,
  hotel_id     int NOT NULL REFERENCES hotels(id),
  employee_id  int NOT NULL REFERENCES employees(id),
  kind         text NOT NULL CHECK (kind IN ('bonus','allowance','deduction')),
  label        text NOT NULL,
  amount       numeric(14,2) NOT NULL CHECK (amount > 0),
  taxable      boolean NOT NULL DEFAULT true,       -- soumis à l'impôt
  contributory boolean NOT NULL DEFAULT true,       -- soumis aux cotisations
  recurring    boolean NOT NULL DEFAULT false,
  period       text,                                -- AAAA-MM pour un élément ponctuel
  start_period text,
  end_period   text,
  active       boolean NOT NULL DEFAULT true,
  created_by   int REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  CHECK (recurring OR period IS NOT NULL)
);
CREATE TABLE hr_advances (
  id            serial PRIMARY KEY,
  hotel_id      int NOT NULL REFERENCES hotels(id),
  employee_id   int NOT NULL REFERENCES employees(id),
  advance_date  date NOT NULL,
  amount        numeric(14,2) NOT NULL CHECK (amount > 0),
  installments  int NOT NULL DEFAULT 1 CHECK (installments BETWEEN 1 AND 24),
  first_period  text NOT NULL,                      -- AAAA-MM de la première retenue
  repaid        numeric(14,2) NOT NULL DEFAULT 0,
  method        text NOT NULL DEFAULT 'cash',
  expense_id    int REFERENCES expenses(id),
  reason        text,
  status        text NOT NULL DEFAULT 'open' CHECK (status IN ('open','repaid','cancelled')),
  created_by    int REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE hr_payroll_runs (
  id             serial PRIMARY KEY,
  hotel_id       int NOT NULL REFERENCES hotels(id),
  period         text NOT NULL,                      -- AAAA-MM
  status         text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','validated','paid','cancelled')),
  gross_total    numeric(16,2) NOT NULL DEFAULT 0,
  net_total      numeric(16,2) NOT NULL DEFAULT 0,
  employer_total numeric(16,2) NOT NULL DEFAULT 0,
  rules          jsonb,                              -- règles de calcul figées
  warnings       jsonb NOT NULL DEFAULT '[]',
  computed_by    int REFERENCES users(id),
  computed_at    timestamptz,
  validated_by   int REFERENCES users(id),
  validated_at   timestamptz,
  paid_by        int REFERENCES users(id),
  paid_at        timestamptz,
  expense_id     int REFERENCES expenses(id),
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX hr_payroll_period_uq ON hr_payroll_runs(hotel_id, period) WHERE status <> 'cancelled';
CREATE TABLE hr_payslips (
  id                 serial PRIMARY KEY,
  run_id             int NOT NULL REFERENCES hr_payroll_runs(id),
  employee_id        int NOT NULL REFERENCES employees(id),
  number             text NOT NULL,
  matricule          text NOT NULL,
  full_name          text NOT NULL,
  department         text,
  position           text,
  base_salary        numeric(14,2) NOT NULL,
  paid_days          numeric(6,2) NOT NULL,
  absence_days       numeric(6,2) NOT NULL DEFAULT 0,
  absence_deduction  numeric(14,2) NOT NULL DEFAULT 0,
  overtime_minutes   int NOT NULL DEFAULT 0,
  overtime_amount    numeric(14,2) NOT NULL DEFAULT 0,
  lines              jsonb NOT NULL DEFAULT '[]',     -- [{code,label,kind,base,rate,amount}]
  gross              numeric(14,2) NOT NULL,
  contributory_base  numeric(14,2) NOT NULL,
  employee_contrib   numeric(14,2) NOT NULL DEFAULT 0,
  taxable            numeric(14,2) NOT NULL,
  tax                numeric(14,2) NOT NULL DEFAULT 0,
  deductions         numeric(14,2) NOT NULL DEFAULT 0,
  advances           numeric(14,2) NOT NULL DEFAULT 0,
  net                numeric(14,2) NOT NULL,
  employer_contrib   numeric(14,2) NOT NULL DEFAULT 0,
  created_at         timestamptz NOT NULL DEFAULT now(),
  UNIQUE (run_id, employee_id)
);
CREATE TABLE hr_advance_repayments (
  id          serial PRIMARY KEY,
  advance_id  int NOT NULL REFERENCES hr_advances(id),
  payslip_id  int NOT NULL REFERENCES hr_payslips(id),
  amount      numeric(14,2) NOT NULL
);
-- un bulletin validé ne se modifie plus
CREATE FUNCTION hr_payslip_lock() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE st text;
BEGIN
  SELECT status INTO st FROM hr_payroll_runs WHERE id = COALESCE(OLD.run_id, NEW.run_id);
  IF st IN ('validated','paid') THEN RAISE EXCEPTION 'Bulletin de paie validé : modification interdite'; END IF;
  RETURN COALESCE(NEW, OLD);
END $$;
CREATE TRIGGER hr_payslips_lock BEFORE UPDATE OR DELETE ON hr_payslips FOR EACH ROW EXECUTE FUNCTION hr_payslip_lock();

-- ---------- Évaluation, formation, compétences ----------
CREATE TABLE hr_evaluations (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  employee_id      int NOT NULL REFERENCES employees(id),
  period           text NOT NULL,
  eval_date        date NOT NULL DEFAULT CURRENT_DATE,
  evaluator_id     int REFERENCES users(id),
  criteria         jsonb NOT NULL DEFAULT '[]',      -- [{label, score 1..5}]
  score            numeric(3,2),
  objectives       jsonb NOT NULL DEFAULT '[]',      -- [{label, due, status}]
  strengths        text,
  improvements     text,
  manager_comment  text,
  employee_comment text,
  status           text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','final')),
  created_at       timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE hr_trainings (
  id            serial PRIMARY KEY,
  hotel_id      int NOT NULL REFERENCES hotels(id),
  employee_id   int NOT NULL REFERENCES employees(id),
  title         text NOT NULL,
  provider      text,
  start_date    date,
  end_date      date,
  hours         numeric(6,1),
  cost          numeric(14,2),
  status        text NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','in_progress','done','cancelled')),
  certificate_expiry date,
  notes         text,
  created_by    int REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE hr_skills (
  id           serial PRIMARY KEY,
  employee_id  int NOT NULL REFERENCES employees(id),
  skill        text NOT NULL,
  level        int NOT NULL CHECK (level BETWEEN 1 AND 5),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (employee_id, skill)
);

-- ---------- Documents RH ----------
CREATE TABLE hr_documents (
  id            serial PRIMARY KEY,
  hotel_id      int NOT NULL REFERENCES hotels(id),
  employee_id   int NOT NULL REFERENCES employees(id),
  kind          text NOT NULL,                      -- pièce d'identité, diplôme, certificat médical, contrat signé…
  title         text NOT NULL,
  issue_date    date,
  expiry_date   date,
  confidential  boolean NOT NULL DEFAULT true,      -- visible seulement par les RH
  created_by    int REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE photos DROP CONSTRAINT IF EXISTS photos_owner_type_check;
ALTER TABLE photos ADD CONSTRAINT photos_owner_type_check CHECK (owner_type IN ('room','room_type','inspection','lost_item','menu_item','equipment','ticket','work_order','employee','hr_document','leave_request'));
