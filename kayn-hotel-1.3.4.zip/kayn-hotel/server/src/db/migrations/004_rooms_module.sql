-- Étape 3 : gestion des chambres, types, étages, bâtiments, équipements, photos, blocages, tarifs

-- ===== Bâtiments =====
CREATE TABLE buildings (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  code        text NOT NULL,
  name        text NOT NULL,
  description text,
  active      boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, code)
);
INSERT INTO buildings (hotel_id, code, name) SELECT id, 'A', 'Bâtiment principal' FROM hotels;

ALTER TABLE floors ADD COLUMN building_id int REFERENCES buildings(id);
ALTER TABLE floors ADD COLUMN description text;
UPDATE floors f SET building_id = b.id FROM buildings b WHERE b.hotel_id = f.hotel_id AND b.code = 'A';
ALTER TABLE floors ALTER COLUMN building_id SET NOT NULL;
ALTER TABLE floors DROP CONSTRAINT floors_hotel_id_number_key;
ALTER TABLE floors ADD CONSTRAINT floors_building_number_key UNIQUE (building_id, number);

-- ===== Types de chambre enrichis =====
ALTER TABLE room_types
  ADD COLUMN max_adults    int CHECK (max_adults > 0),
  ADD COLUMN max_children  int NOT NULL DEFAULT 0 CHECK (max_children >= 0),
  ADD COLUMN bed_type      text,
  ADD COLUMN area_m2       numeric(6,1) CHECK (area_m2 > 0),
  ADD COLUMN weekend_rate  numeric(12,2) CHECK (weekend_rate >= 0),
  ADD COLUMN child_rate    numeric(12,2) NOT NULL DEFAULT 0 CHECK (child_rate >= 0),
  ADD COLUMN sort_order    int NOT NULL DEFAULT 0;
UPDATE room_types SET max_adults = capacity;

-- ===== Chambres : caractéristiques propres, désactivation logique =====
ALTER TABLE rooms
  ADD COLUMN description          text,
  ADD COLUMN capacity             int CHECK (capacity > 0),          -- vide = capacité du type
  ADD COLUMN beds                 int CHECK (beds > 0),              -- vide = lits du type
  ADD COLUMN features             jsonb NOT NULL DEFAULT '[]',       -- caractéristiques (vue mer, accessible PMR…)
  ADD COLUMN rate_supplement      numeric(12,2) NOT NULL DEFAULT 0,  -- supplément par nuit propre à la chambre
  ADD COLUMN deactivated_at       timestamptz,
  ADD COLUMN deactivation_reason  text;

-- ===== Équipements =====
CREATE TABLE amenities (
  id        serial PRIMARY KEY,
  hotel_id  int NOT NULL REFERENCES hotels(id),
  code      text NOT NULL,
  name_fr   text NOT NULL,
  name_en   text NOT NULL,
  name_ar   text NOT NULL,
  icon      text,
  builtin   boolean NOT NULL DEFAULT false,
  active    boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, code)
);
CREATE TABLE room_amenities (
  room_id     int NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  amenity_id  int NOT NULL REFERENCES amenities(id),
  PRIMARY KEY (room_id, amenity_id)
);
CREATE TABLE room_type_amenities (
  room_type_id int NOT NULL REFERENCES room_types(id) ON DELETE CASCADE,
  amenity_id   int NOT NULL REFERENCES amenities(id),
  PRIMARY KEY (room_type_id, amenity_id)
);
INSERT INTO amenities (hotel_id, code, name_fr, name_en, name_ar, builtin)
SELECT h.id, a.code, a.fr, a.en, a.ar, true FROM hotels h, (VALUES
  ('ac', 'Climatisation', 'Air conditioning', 'مكيف هواء'),
  ('heating', 'Chauffage', 'Heating', 'تدفئة'),
  ('tv', 'Télévision', 'Television', 'تلفاز'),
  ('wifi', 'Wi-Fi', 'Wi-Fi', 'واي فاي'),
  ('minibar', 'Mini-bar', 'Minibar', 'ميني بار'),
  ('safe', 'Coffre-fort', 'Safe', 'خزنة'),
  ('shower', 'Douche', 'Shower', 'دش'),
  ('bathtub', 'Baignoire', 'Bathtub', 'حوض استحمام'),
  ('balcony', 'Balcon', 'Balcony', 'شرفة'),
  ('fridge', 'Réfrigérateur', 'Fridge', 'ثلاجة'),
  ('phone', 'Téléphone', 'Telephone', 'هاتف'),
  ('desk', 'Bureau', 'Desk', 'مكتب'),
  ('hairdryer', 'Sèche-cheveux', 'Hair dryer', 'مجفف شعر')
) AS a(code, fr, en, ar);

-- ===== Photos (fichiers stockés sur le serveur) =====
CREATE TABLE photos (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  owner_type  text NOT NULL CHECK (owner_type IN ('room','room_type')),
  owner_id    int NOT NULL,
  filename    text NOT NULL,
  mime        text NOT NULL,
  size        int NOT NULL,
  caption     text,
  sort_order  int NOT NULL DEFAULT 0,
  created_by  int REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX photos_owner_idx ON photos(owner_type, owner_id);

-- ===== Blocages datés (hors service / maintenance) =====
CREATE TABLE room_blocks (
  id          serial PRIMARY KEY,
  room_id     int NOT NULL REFERENCES rooms(id),
  kind        text NOT NULL DEFAULT 'out_of_service' CHECK (kind IN ('out_of_service','maintenance')),
  start_date  date NOT NULL,
  end_date    date,                                 -- vide = jusqu'à la remise en service
  reason      text NOT NULL,
  ticket_id   int REFERENCES maintenance_tickets(id),
  status      text NOT NULL DEFAULT 'active' CHECK (status IN ('active','released')),
  created_by  int REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now(),
  released_by int REFERENCES users(id),
  released_at timestamptz,
  CHECK (end_date IS NULL OR end_date > start_date)
);
CREATE INDEX room_blocks_room_idx ON room_blocks(room_id, status);
-- reprise des chambres déjà hors service
INSERT INTO room_blocks (room_id, kind, start_date, reason, created_by)
SELECT id, 'out_of_service', CURRENT_DATE, COALESCE(oos_reason, 'Hors service'), NULL FROM rooms WHERE out_of_service;
ALTER TABLE maintenance_tickets ADD COLUMN category text NOT NULL DEFAULT 'other';
ALTER TABLE maintenance_tickets ADD COLUMN resolution text;

-- ===== Tarification =====
CREATE TABLE rate_plans (
  id                serial PRIMARY KEY,
  hotel_id          int NOT NULL REFERENCES hotels(id),
  code              text NOT NULL,
  name              text NOT NULL,
  kind              text NOT NULL CHECK (kind IN ('standard','corporate','agency','group','negotiated','promo')),
  adjustment_type   text NOT NULL DEFAULT 'none' CHECK (adjustment_type IN ('none','percent','amount')),
  adjustment_value  numeric(12,2) NOT NULL DEFAULT 0,      -- négatif = réduction, positif = supplément
  guest_id          int REFERENCES guests(id),              -- tarif négocié : société / agence concernée
  min_nights        int NOT NULL DEFAULT 1 CHECK (min_nights >= 1),
  valid_from        date,
  valid_to          date,
  description       text,
  active            boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, code)
);
CREATE TABLE rate_plan_prices (
  rate_plan_id  int NOT NULL REFERENCES rate_plans(id) ON DELETE CASCADE,
  room_type_id  int NOT NULL REFERENCES room_types(id),
  price         numeric(12,2) NOT NULL CHECK (price >= 0),  -- prix fixe par nuit pour ce type
  PRIMARY KEY (rate_plan_id, room_type_id)
);
INSERT INTO rate_plans (hotel_id, code, name, kind, adjustment_type, adjustment_value, description)
SELECT h.id, p.code, p.name, p.kind, p.at, p.av, p.descr FROM hotels h, (VALUES
  ('STD', 'Tarif standard', 'standard', 'none', 0, 'Prix public de la grille'),
  ('CORP', 'Tarif entreprise', 'corporate', 'percent', -10, 'Réduction entreprises'),
  ('AGENCY', 'Tarif agence', 'agency', 'percent', -15, 'Réduction agences de voyage'),
  ('GROUP', 'Tarif groupe', 'group', 'percent', -10, 'À partir de plusieurs chambres')
) AS p(code, name, kind, at, av, descr);

CREATE TABLE rate_seasons (
  id                serial PRIMARY KEY,
  hotel_id          int NOT NULL REFERENCES hotels(id),
  name              text NOT NULL,
  kind              text NOT NULL CHECK (kind IN ('high','low','event')),
  start_date        date NOT NULL,
  end_date          date NOT NULL,                          -- inclus
  room_type_id      int REFERENCES room_types(id),          -- vide = tous les types
  adjustment_type   text NOT NULL CHECK (adjustment_type IN ('percent','amount','fixed')),
  adjustment_value  numeric(12,2) NOT NULL,
  active            boolean NOT NULL DEFAULT true,
  CHECK (end_date >= start_date)
);

ALTER TABLE reservations ADD COLUMN rate_plan_id int REFERENCES rate_plans(id);
ALTER TABLE reservation_rooms ADD COLUMN nightly jsonb;     -- détail du prix nuit par nuit
