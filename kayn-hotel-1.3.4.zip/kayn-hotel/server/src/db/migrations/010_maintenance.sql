-- =====================================================================================================
-- Phase 9 : Maintenance (équipements, pannes, techniciens, ordres de travail, pièces, préventif, coûts)
-- =====================================================================================================

-- ---------- Équipements ----------
CREATE TABLE equipment (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  code             text NOT NULL,                       -- référence interne
  name             text NOT NULL,
  category         text NOT NULL CHECK (category IN ('hvac','heating','plumbing','electrical','elevator','kitchen','furniture','it','fire_safety','other')),
  brand            text,
  model            text,
  serial_no        text,
  location_type    text NOT NULL DEFAULT 'other' CHECK (location_type IN ('room','floor','kitchen','restaurant','reception','pool','laundry','technical','public','outdoor','other')),
  room_id          int REFERENCES rooms(id),
  floor_id         int REFERENCES floors(id),
  location_detail  text,
  department       text NOT NULL DEFAULT 'rooms' CHECK (department IN ('rooms','restaurant','reception','housekeeping','technical','leisure','admin','other')),
  purchase_date    date,
  supplier_id      int REFERENCES suppliers(id),
  purchase_cost    numeric(14,2),
  install_date     date,
  warranty_months  int CHECK (warranty_months >= 0),
  status           text NOT NULL DEFAULT 'operational' CHECK (status IN ('operational','degraded','broken','out_of_service','retired')),
  critical         boolean NOT NULL DEFAULT false,      -- impact client / sécurité
  notes            text,
  active           boolean NOT NULL DEFAULT true,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (hotel_id, code)
);
CREATE INDEX equipment_room_idx ON equipment(room_id);

-- ---------- Techniciens (internes ou prestataires) ----------
CREATE TABLE maintenance_technicians (
  id                 serial PRIMARY KEY,
  hotel_id           int NOT NULL REFERENCES hotels(id),
  user_id            int REFERENCES users(id),
  name               text NOT NULL,
  phone              text,
  specialties        text[] NOT NULL DEFAULT '{}',
  hourly_rate        numeric(10,2) NOT NULL DEFAULT 0 CHECK (hourly_rate >= 0),
  external           boolean NOT NULL DEFAULT false,
  supplier_id        int REFERENCES suppliers(id),
  available          boolean NOT NULL DEFAULT true,
  unavailable_reason text,
  unavailable_until  date,
  active             boolean NOT NULL DEFAULT true,
  notes              text,
  created_at         timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX maintenance_technicians_user_uq ON maintenance_technicians(user_id) WHERE user_id IS NOT NULL;

-- ---------- Pannes : extension des tickets existants ----------
ALTER TABLE maintenance_tickets
  ADD COLUMN hotel_id       int REFERENCES hotels(id),
  ADD COLUMN number         text,
  ADD COLUMN equipment_id   int REFERENCES equipment(id),
  ADD COLUMN location       text,
  ADD COLUMN source         text NOT NULL DEFAULT 'manual' CHECK (source IN ('manual','reception','housekeeping','restaurant','preventive','block','inspection')),
  ADD COLUMN technician_id  int REFERENCES maintenance_technicians(id),
  ADD COLUMN assigned_at    timestamptz,
  ADD COLUMN assigned_by    int REFERENCES users(id),
  ADD COLUMN started_at     timestamptz,
  ADD COLUMN waiting_reason text,
  ADD COLUMN due_at         timestamptz,
  ADD COLUMN closed_at      timestamptz,
  ADD COLUMN closed_by      int REFERENCES users(id),
  ADD COLUMN updated_at     timestamptz NOT NULL DEFAULT now();
UPDATE maintenance_tickets m SET hotel_id = r.hotel_id FROM rooms r WHERE r.id = m.room_id;
UPDATE maintenance_tickets SET hotel_id = (SELECT id FROM hotels ORDER BY id LIMIT 1) WHERE hotel_id IS NULL;
-- statuts : Nouvelle, Affectée, En cours, En attente de pièces, Résolue, Clôturée (+ Annulée)
ALTER TABLE maintenance_tickets DROP CONSTRAINT IF EXISTS maintenance_tickets_status_check;
UPDATE maintenance_tickets SET status = 'new' WHERE status = 'open';
ALTER TABLE maintenance_tickets ALTER COLUMN status SET DEFAULT 'new';
ALTER TABLE maintenance_tickets ADD CONSTRAINT maintenance_tickets_status_check CHECK (status IN ('new','assigned','in_progress','waiting_parts','resolved','closed','cancelled'));
-- l'hôtel est déduit de la chambre quand l'appelant ne le précise pas (compatibilité des modules existants)
CREATE SEQUENCE maintenance_ticket_seq;
CREATE FUNCTION maintenance_ticket_defaults() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.hotel_id IS NULL AND NEW.room_id IS NOT NULL THEN SELECT hotel_id INTO NEW.hotel_id FROM rooms WHERE id = NEW.room_id; END IF;
  IF NEW.hotel_id IS NULL AND NEW.equipment_id IS NOT NULL THEN SELECT hotel_id INTO NEW.hotel_id FROM equipment WHERE id = NEW.equipment_id; END IF;
  IF NEW.hotel_id IS NULL THEN RAISE EXCEPTION 'Panne sans hôtel'; END IF;
  IF NEW.status = 'open' THEN NEW.status := 'new'; END IF;
  IF NEW.number IS NULL THEN NEW.number := 'PN' || to_char(now(), 'YYYY') || '-' || lpad(nextval('maintenance_ticket_seq')::text, 4, '0'); END IF;
  IF NEW.due_at IS NULL THEN
    NEW.due_at := NEW.created_at + CASE NEW.priority WHEN 'urgent' THEN interval '4 hours' WHEN 'high' THEN interval '24 hours' WHEN 'normal' THEN interval '72 hours' ELSE interval '7 days' END;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER maintenance_tickets_defaults BEFORE INSERT ON maintenance_tickets FOR EACH ROW EXECUTE FUNCTION maintenance_ticket_defaults();
UPDATE maintenance_tickets SET due_at = created_at + interval '72 hours' WHERE due_at IS NULL;
UPDATE maintenance_tickets SET number = 'PN' || to_char(created_at, 'YYYY') || '-' || lpad(nextval('maintenance_ticket_seq')::text, 4, '0') WHERE number IS NULL;
ALTER TABLE maintenance_tickets ALTER COLUMN hotel_id SET NOT NULL;
CREATE INDEX maintenance_tickets_hotel_idx ON maintenance_tickets(hotel_id, status);

-- ---------- Plans de maintenance préventive ----------
CREATE TABLE maintenance_plans (
  id                 serial PRIMARY KEY,
  hotel_id           int NOT NULL REFERENCES hotels(id),
  name               text NOT NULL,
  equipment_id       int REFERENCES equipment(id),
  frequency          text NOT NULL CHECK (frequency IN ('daily','weekly','monthly','quarterly','yearly')),
  interval_count     int NOT NULL DEFAULT 1 CHECK (interval_count BETWEEN 1 AND 52),
  next_due           date NOT NULL,
  last_done          date,
  alert_days         int NOT NULL DEFAULT 3 CHECK (alert_days >= 0),
  technician_id      int REFERENCES maintenance_technicians(id),
  estimated_minutes  int NOT NULL DEFAULT 30 CHECK (estimated_minutes > 0),
  checklist          jsonb NOT NULL DEFAULT '[]',
  instructions       text,
  active             boolean NOT NULL DEFAULT true,
  created_by         int REFERENCES users(id),
  created_at         timestamptz NOT NULL DEFAULT now()
);

-- ---------- Ordres de travail ----------
CREATE TABLE work_orders (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  number           text NOT NULL,                              -- OT2026-0001
  kind             text NOT NULL DEFAULT 'corrective' CHECK (kind IN ('corrective','preventive','inspection','improvement')),
  ticket_id        int REFERENCES maintenance_tickets(id),
  plan_id          int REFERENCES maintenance_plans(id),
  plan_due         date,                                       -- échéance préventive couverte (anti-doublon)
  equipment_id     int REFERENCES equipment(id),
  room_id          int REFERENCES rooms(id),
  title            text NOT NULL,
  description      text,
  priority         text NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  technician_id    int REFERENCES maintenance_technicians(id),
  scheduled_at     timestamptz,
  due_at           timestamptz,
  status           text NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','in_progress','on_hold','done','validated','cancelled')),
  checklist        jsonb NOT NULL DEFAULT '[]',                -- [{label, done, by, at}]
  labor_minutes    int NOT NULL DEFAULT 0,
  labor_cost       numeric(14,2) NOT NULL DEFAULT 0,
  parts_cost       numeric(14,2) NOT NULL DEFAULT 0,
  external_cost    numeric(14,2) NOT NULL DEFAULT 0,
  total_cost       numeric(14,2) NOT NULL DEFAULT 0,
  result           text,
  outcome          text CHECK (outcome IN ('fixed','partial','not_fixed','no_issue')),
  rating           int CHECK (rating BETWEEN 1 AND 5),         -- évaluation par le responsable
  rating_comment   text,
  started_at       timestamptz,
  completed_at     timestamptz,
  validated_by     int REFERENCES users(id),
  validated_at     timestamptz,
  cancel_reason    text,
  created_by       int REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (hotel_id, number)
);
CREATE INDEX work_orders_status_idx ON work_orders(hotel_id, status);
CREATE UNIQUE INDEX work_orders_plan_due_uq ON work_orders(plan_id, plan_due) WHERE plan_id IS NOT NULL AND status <> 'cancelled';

CREATE TABLE wo_time_logs (
  id             serial PRIMARY KEY,
  wo_id          int NOT NULL REFERENCES work_orders(id),
  technician_id  int REFERENCES maintenance_technicians(id),
  work_date      date NOT NULL,
  minutes        int NOT NULL CHECK (minutes > 0 AND minutes <= 1440),
  hourly_rate    numeric(10,2) NOT NULL DEFAULT 0,
  cost           numeric(14,2) NOT NULL DEFAULT 0,
  note           text,
  created_by     int REFERENCES users(id),
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE wo_parts (
  id             serial PRIMARY KEY,
  wo_id          int NOT NULL REFERENCES work_orders(id),
  product_id     int NOT NULL REFERENCES products(id),
  warehouse_id   int REFERENCES warehouses(id),
  quantity       numeric(12,3) NOT NULL CHECK (quantity > 0),
  unit_cost      numeric(14,4) NOT NULL DEFAULT 0,
  cost           numeric(14,2) NOT NULL DEFAULT 0,
  movement_id    int REFERENCES stock_movements(id),
  created_by     int REFERENCES users(id),
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE wo_external_costs (
  id             serial PRIMARY KEY,
  wo_id          int NOT NULL REFERENCES work_orders(id),
  supplier_id    int REFERENCES suppliers(id),
  description    text NOT NULL,
  amount         numeric(14,2) NOT NULL CHECK (amount > 0),
  expense_id     int REFERENCES expenses(id),                  -- payé : dépense (Facturation & Caisse)
  invoice_id     int REFERENCES supplier_invoices(id),         -- à payer : facture fournisseur
  created_by     int REFERENCES users(id),
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE wo_comments (
  id          serial PRIMARY KEY,
  wo_id       int NOT NULL REFERENCES work_orders(id),
  text        text NOT NULL,
  created_by  int REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER wo_time_logs_immutable BEFORE UPDATE OR DELETE ON wo_time_logs FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER wo_parts_immutable BEFORE UPDATE OR DELETE ON wo_parts FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER wo_external_immutable BEFORE UPDATE OR DELETE ON wo_external_costs FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Photos et documents (PDF) : équipements, pannes, ordres de travail
ALTER TABLE photos DROP CONSTRAINT IF EXISTS photos_owner_type_check;
ALTER TABLE photos ADD CONSTRAINT photos_owner_type_check CHECK (owner_type IN ('room','room_type','inspection','lost_item','menu_item','equipment','ticket','work_order'));
