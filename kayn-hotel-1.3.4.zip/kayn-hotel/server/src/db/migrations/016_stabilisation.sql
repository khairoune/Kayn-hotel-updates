-- Phase 15 — Stabilisation : index des clés étrangères les plus sollicitées (soldes, folios, planning, rapports),
-- clés étrangères manquantes. Aucune donnée n'est modifiée ni supprimée.

-- Dossiers de réservation : chaque calcul de solde parcourt chambres, prestations, paiements et remboursements d'un dossier
CREATE INDEX IF NOT EXISTS reservation_rooms_reservation_idx ON reservation_rooms (reservation_id);
CREATE INDEX IF NOT EXISTS reservation_rooms_guest_idx ON reservation_rooms (guest_id);
CREATE INDEX IF NOT EXISTS reservation_rooms_dates_idx ON reservation_rooms (check_in, check_out);
CREATE INDEX IF NOT EXISTS reservations_guest_idx ON reservations (guest_id);
CREATE INDEX IF NOT EXISTS reservations_payer_idx ON reservations (payer_guest_id) WHERE payer_guest_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS reservations_dates_idx ON reservations (hotel_id, check_in, check_out);
CREATE INDEX IF NOT EXISTS charges_reservation_idx ON charges (reservation_id);
CREATE INDEX IF NOT EXISTS charges_rr_idx ON charges (reservation_room_id) WHERE reservation_room_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS payments_reservation_idx ON payments (reservation_id) WHERE reservation_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS payments_invoice_idx ON payments (invoice_id) WHERE invoice_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS payments_guest_idx ON payments (guest_id) WHERE guest_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS payments_session_idx ON payments (cash_session_id) WHERE cash_session_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS refunds_reservation_idx ON refunds (reservation_id) WHERE reservation_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS refunds_invoice_idx ON refunds (invoice_id) WHERE invoice_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS refunds_payment_idx ON refunds (payment_id) WHERE payment_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS refunds_session_idx ON refunds (cash_session_id) WHERE cash_session_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS stays_guest_idx ON stays (guest_id);
CREATE INDEX IF NOT EXISTS stays_room_idx ON stays (room_id);

-- Facturation
CREATE INDEX IF NOT EXISTS invoice_items_invoice_idx ON invoice_items (invoice_id);
CREATE INDEX IF NOT EXISTS invoices_guest_idx ON invoices (guest_id);
CREATE INDEX IF NOT EXISTS invoices_rr_idx ON invoices (reservation_room_id) WHERE reservation_room_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS invoices_credit_of_idx ON invoices (credit_of_invoice_id) WHERE credit_of_invoice_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS cash_movements_session_idx ON cash_movements (session_id);
CREATE INDEX IF NOT EXISTS incomes_session_idx ON incomes (cash_session_id) WHERE cash_session_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS expenses_session_idx ON expenses (cash_session_id) WHERE cash_session_id IS NOT NULL;

-- Restaurant, stocks, ménage, maintenance
CREATE INDEX IF NOT EXISTS rs_order_lines_item_idx ON rs_order_lines (item_id);
CREATE INDEX IF NOT EXISTS rs_orders_reservation_idx ON rs_orders (reservation_id) WHERE reservation_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS rs_orders_guest_idx ON rs_orders (guest_id) WHERE guest_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS rs_orders_table_idx ON rs_orders (table_id) WHERE table_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS rs_orders_room_idx ON rs_orders (room_id) WHERE room_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS stock_movements_order_idx ON stock_movements (rs_order_id) WHERE rs_order_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS stock_movements_wh_idx ON stock_movements (warehouse_id);
CREATE INDEX IF NOT EXISTS purchase_order_lines_po_idx ON purchase_order_lines (po_id);
CREATE INDEX IF NOT EXISTS purchase_orders_supplier_idx ON purchase_orders (supplier_id);
CREATE INDEX IF NOT EXISTS hk_tasks_rr_idx ON housekeeping_tasks (reservation_room_id) WHERE reservation_room_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS hk_tasks_assigned_idx ON housekeeping_tasks (assigned_to) WHERE assigned_to IS NOT NULL;
CREATE INDEX IF NOT EXISTS mt_tickets_room_idx ON maintenance_tickets (room_id) WHERE room_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS mt_tickets_equipment_idx ON maintenance_tickets (equipment_id) WHERE equipment_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS work_orders_ticket_idx ON work_orders (ticket_id) WHERE ticket_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS work_orders_room_idx ON work_orders (room_id) WHERE room_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS work_orders_equipment_idx ON work_orders (equipment_id) WHERE equipment_id IS NOT NULL;

-- Clients / CRM
CREATE INDEX IF NOT EXISTS guests_company_idx ON guests (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS guest_notes_reservation_idx ON guest_notes (reservation_id) WHERE reservation_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS loyalty_tx_reservation_idx ON loyalty_transactions (reservation_id) WHERE reservation_id IS NOT NULL;

-- Clés étrangères manquantes (ajoutées puis validées : refus explicite si des données orphelines existaient)
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'loyalty_transactions_redemption_fk') THEN
    ALTER TABLE loyalty_transactions ADD CONSTRAINT loyalty_transactions_redemption_fk FOREIGN KEY (redemption_id) REFERENCES loyalty_redemptions(id) NOT VALID;
    ALTER TABLE loyalty_transactions VALIDATE CONSTRAINT loyalty_transactions_redemption_fk;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'notifications_campaign_fk') THEN
    ALTER TABLE notifications ADD CONSTRAINT notifications_campaign_fk FOREIGN KEY (campaign_id) REFERENCES crm_campaigns(id) NOT VALID;
    ALTER TABLE notifications VALIDATE CONSTRAINT notifications_campaign_fk;
  END IF;
END $$;
