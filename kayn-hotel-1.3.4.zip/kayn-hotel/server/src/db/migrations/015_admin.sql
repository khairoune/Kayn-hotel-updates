-- Phase 14 : Administration & sécurité — utilisateurs, rôles (RBAC), départements, établissement, fiscalité, services,
-- documents, notifications internes, journal d'audit enrichi, sauvegardes et restaurations.
-- Aucune donnée existante n'est supprimée.

-- ===================================================== Rôles =====================================================
ALTER TABLE roles ADD COLUMN description text;
ALTER TABLE roles ADD COLUMN builtin boolean NOT NULL DEFAULT false;
ALTER TABLE roles ADD COLUMN active boolean NOT NULL DEFAULT true;
-- un rôle prédéfini dont les permissions ont été modifiées par l'administrateur n'est plus réaligné au démarrage
ALTER TABLE roles ADD COLUMN customized boolean NOT NULL DEFAULT false;
ALTER TABLE roles ADD COLUMN created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE roles ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE roles ADD CONSTRAINT roles_code_format CHECK (code ~ '^[a-z][a-z0-9_]{1,39}$');
ALTER TABLE permissions ADD COLUMN sensitive boolean NOT NULL DEFAULT false;

-- ===================================================== Départements =====================================================
ALTER TABLE hr_departments ADD COLUMN description text;
ALTER TABLE hr_departments ADD COLUMN manager_user_id int REFERENCES users(id);
ALTER TABLE hr_departments ADD COLUMN created_at timestamptz NOT NULL DEFAULT now();
INSERT INTO hr_departments (hotel_id, code, name, builtin, sort_order)
  SELECT h.id, d.code, d.name, true, d.so FROM hotels h CROSS JOIN (VALUES ('hr','Ressources humaines',90),('stock','Stocks et achats',95)) d(code, name, so)
  ON CONFLICT DO NOTHING;
-- un département porteur d'historique ne se supprime pas : seulement désactivable
CREATE FUNCTION hr_departments_no_delete() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'Un département ne peut pas être supprimé : désactivez-le.' USING ERRCODE = 'P0001'; END $$;
CREATE TRIGGER hr_departments_no_delete BEFORE DELETE ON hr_departments FOR EACH ROW EXECUTE FUNCTION hr_departments_no_delete();

-- ===================================================== Utilisateurs =====================================================
ALTER TABLE users ADD COLUMN first_name text;
ALTER TABLE users ADD COLUMN last_name text;
ALTER TABLE users ADD COLUMN email text;
ALTER TABLE users ADD COLUMN phone text;
ALTER TABLE users ADD COLUMN department_id int REFERENCES hr_departments(id);
ALTER TABLE users ADD COLUMN job_title text;
ALTER TABLE users ADD COLUMN protected boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN created_by int REFERENCES users(id);
ALTER TABLE users ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE users ADD COLUMN disabled_at timestamptz;
ALTER TABLE users ADD COLUMN disabled_by int REFERENCES users(id);
ALTER TABLE users ADD COLUMN disabled_reason text;
ALTER TABLE users ADD COLUMN password_changed_at timestamptz;
ALTER TABLE users ADD COLUMN reset_code_hash text;
ALTER TABLE users ADD COLUMN reset_expires_at timestamptz;
ALTER TABLE users ADD COLUMN reset_attempts int NOT NULL DEFAULT 0;

UPDATE users u SET first_name = COALESCE(e.first_name, NULLIF(split_part(u.full_name, ' ', 1), '')),
                   last_name = COALESCE(e.last_name, NULLIF(substr(u.full_name, length(split_part(u.full_name, ' ', 1)) + 2), '')),
                   email = NULLIF(e.email, ''), phone = NULLIF(e.phone, ''), job_title = e.position,
                   department_id = (SELECT d.id FROM hr_departments d WHERE d.hotel_id = u.hotel_id AND d.code = e.department)
  FROM users u2 LEFT JOIN employees e ON e.id = u2.employee_id WHERE u2.id = u.id;
UPDATE users SET first_name = full_name WHERE first_name IS NULL;
-- adresse e-mail en double : seule la première est conservée sur le compte
UPDATE users u SET email = NULL WHERE email IS NOT NULL AND EXISTS (SELECT 1 FROM users v WHERE lower(v.email) = lower(u.email) AND v.id < u.id);
CREATE UNIQUE INDEX users_username_lower ON users (lower(username));
CREATE UNIQUE INDEX users_email_lower ON users (lower(email)) WHERE email IS NOT NULL;
ALTER TABLE users ADD CONSTRAINT users_username_format CHECK (username ~ '^[A-Za-z0-9._-]{2,40}$') NOT VALID;
-- compte administrateur principal : le premier administrateur créé
UPDATE users SET protected = true WHERE id = (SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = 'admin' ORDER BY u.id LIMIT 1);

CREATE FUNCTION users_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'Un compte utilisateur ne se supprime pas (historique) : désactivez-le.' USING ERRCODE = 'P0001'; END IF;
  IF OLD.protected AND (NOT NEW.active OR NEW.role_id <> OLD.role_id OR NOT NEW.protected) THEN
    RAISE EXCEPTION 'Compte administrateur principal protégé : il ne peut être ni désactivé ni changé de rôle.' USING ERRCODE = 'P0001';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER users_guard BEFORE UPDATE OR DELETE ON users FOR EACH ROW EXECUTE FUNCTION users_guard();

-- ===================================================== Établissement =====================================================
CREATE TABLE hotel_logos (
  id         serial PRIMARY KEY,
  hotel_id   int NOT NULL REFERENCES hotels(id),
  mime       text NOT NULL CHECK (mime IN ('image/png','image/jpeg')),
  data       bytea NOT NULL,
  size_bytes int NOT NULL,
  created_by int REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
-- un logo n'est jamais modifié : les factures déjà émises gardent le logo de leur date
CREATE TRIGGER hotel_logos_immutable BEFORE UPDATE OR DELETE ON hotel_logos FOR EACH ROW EXECUTE FUNCTION forbid_change();
ALTER TABLE hotels ADD COLUMN commercial_name text;
ALTER TABLE hotels ADD COLUMN description text;
ALTER TABLE hotels ADD COLUMN category text;
ALTER TABLE hotels ADD COLUMN stars int CHECK (stars BETWEEN 0 AND 7);
ALTER TABLE hotels ADD COLUMN postal_code text;
ALTER TABLE hotels ADD COLUMN country text NOT NULL DEFAULT 'Algérie';
ALTER TABLE hotels ADD COLUMN website text;
ALTER TABLE hotels ADD COLUMN logo_id int REFERENCES hotel_logos(id);
ALTER TABLE hotels ADD COLUMN restaurants_count int NOT NULL DEFAULT 1 CHECK (restaurants_count >= 0);
ALTER TABLE hotels ADD COLUMN primary_language text NOT NULL DEFAULT 'fr' CHECK (primary_language IN ('fr','ar','en'));
ALTER TABLE hotels ADD COLUMN languages text[] NOT NULL DEFAULT ARRAY['fr','ar','en'];
ALTER TABLE hotels ADD COLUMN date_format text NOT NULL DEFAULT 'DD/MM/YYYY' CHECK (date_format IN ('DD/MM/YYYY','YYYY-MM-DD','MM/DD/YYYY'));
ALTER TABLE hotels ADD COLUMN time_format text NOT NULL DEFAULT '24h' CHECK (time_format IN ('24h','12h'));
ALTER TABLE hotels ADD COLUMN currency_symbol text NOT NULL DEFAULT 'DA';
ALTER TABLE hotels ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();

-- ===================================================== Fiscalité : versions des taux =====================================================
-- Historique des taux (TVA par catégorie, TVA par défaut, taxe de séjour) avec date d'effet. Les montants déjà saisis
-- (lignes de folio, factures) conservent leur taux figé : un changement ne s'applique qu'aux opérations à partir de sa date.
CREATE TABLE tax_versions (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  category    text NOT NULL,
  name        text NOT NULL,
  rate        numeric(10,2) NOT NULL CHECK (rate >= 0),
  valid_from  date NOT NULL,
  note        text,
  created_by  int REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now(),
  applied_at  timestamptz,
  UNIQUE (hotel_id, category, valid_from)
);
CREATE TRIGGER tax_versions_guard BEFORE DELETE ON tax_versions FOR EACH ROW EXECUTE FUNCTION forbid_change();
-- situation actuelle reprise comme première version
INSERT INTO tax_versions (hotel_id, category, name, rate, valid_from, note, applied_at)
  SELECT h.id, 'default', 'TVA par défaut', COALESCE((SELECT (value #>> '{}')::numeric FROM settings WHERE hotel_id = h.id AND key = 'vat_rate'), 0), '2000-01-01', 'Reprise de la configuration existante', now() FROM hotels h;
INSERT INTO tax_versions (hotel_id, category, name, rate, valid_from, note, applied_at)
  SELECT h.id, 'tourist', 'Taxe de séjour (par adulte et par nuit)', COALESCE((SELECT (value #>> '{}')::numeric FROM settings WHERE hotel_id = h.id AND key = 'tourist_tax_per_adult_night'), 0), '2000-01-01', 'Reprise de la configuration existante', now() FROM hotels h;
INSERT INTO tax_versions (hotel_id, category, name, rate, valid_from, note, applied_at)
  SELECT s.hotel_id, k.key, 'TVA ' || k.key, (k.value #>> '{}')::numeric, '2000-01-01', 'Reprise de la configuration existante', now()
    FROM settings s CROSS JOIN LATERAL jsonb_each(s.value::jsonb) k WHERE s.key = 'tax_rates' AND jsonb_typeof(s.value::jsonb) = 'object' AND (k.value #>> '{}') ~ '^[0-9.]+$';

-- Moyens de paiement acceptés : contrôle au niveau de la base (tous les modules)
CREATE FUNCTION payments_method_allowed() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE m jsonb;
BEGIN
  SELECT value::jsonb INTO m FROM settings WHERE hotel_id = NEW.hotel_id AND key = 'payment_methods';
  IF m IS NOT NULL AND jsonb_typeof(m) = 'array' AND NOT (m ? NEW.method) THEN
    RAISE EXCEPTION 'Moyen de paiement « % » non accepté par l''établissement (Administration → Finances).', NEW.method USING ERRCODE = 'KH422';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER payments_method_allowed BEFORE INSERT ON payments FOR EACH ROW EXECUTE FUNCTION payments_method_allowed();

-- ===================================================== Services de l'hôtel =====================================================
ALTER TABLE services ADD COLUMN description text;
ALTER TABLE services ADD COLUMN opening_hours text;
ALTER TABLE services ADD COLUMN manager_user_id int REFERENCES users(id);
ALTER TABLE services ADD COLUMN pricing text NOT NULL DEFAULT 'fixed' CHECK (pricing IN ('fixed','variable','free','none'));

-- ===================================================== Journal d'audit =====================================================
ALTER TABLE audit_logs ADD COLUMN result text NOT NULL DEFAULT 'success' CHECK (result IN ('success','failure','denied'));
ALTER TABLE audit_logs ADD COLUMN user_agent text;
CREATE INDEX audit_logs_created ON audit_logs (created_at DESC);
CREATE INDEX audit_logs_user ON audit_logs (user_id, created_at DESC);
CREATE INDEX audit_logs_action ON audit_logs (action, created_at DESC);
-- les échecs de connexion historiques
ALTER TABLE audit_logs DISABLE TRIGGER audit_logs_immutable;
UPDATE audit_logs SET result = 'failure' WHERE action = 'login_failed';
ALTER TABLE audit_logs ENABLE TRIGGER audit_logs_immutable;

-- ===================================================== Notifications internes =====================================================
CREATE TABLE user_notifications (
  id         bigserial PRIMARY KEY,
  hotel_id   int NOT NULL REFERENCES hotels(id),
  user_id    int NOT NULL REFERENCES users(id),
  kind       text NOT NULL CHECK (kind IN ('security','important','low_stock','maintenance','task_reminder','backup')),
  severity   text NOT NULL DEFAULT 'info' CHECK (severity IN ('info','warning','danger')),
  title      text NOT NULL,
  body       text,
  link       text,
  dedupe_key text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  read_at    timestamptz,
  UNIQUE (user_id, dedupe_key)
);
CREATE INDEX user_notifications_unread ON user_notifications (user_id) WHERE read_at IS NULL;

-- ===================================================== Sauvegardes =====================================================
-- Index des fichiers de sauvegarde (la source de vérité est le dossier : fichier .dump + fiche .json, resynchronisés après une restauration).
CREATE TABLE backups (
  id            serial PRIMARY KEY,
  file_name     text NOT NULL UNIQUE,
  kind          text NOT NULL CHECK (kind IN ('manual','auto','pre_restore','uploaded')),
  status        text NOT NULL CHECK (status IN ('creating','ok','failed','missing')),
  size_bytes    bigint,
  sha256        text,
  app_version   text,
  last_migration text,
  tables_count  int,
  rows_count    bigint,
  verified_at   timestamptz,
  verify_ok     boolean,
  verify_detail text,
  error         text,
  note          text,
  created_by    int,
  created_by_name text,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE restores (
  id             serial PRIMARY KEY,
  file_name      text NOT NULL,
  safety_file    text,
  status         text NOT NULL CHECK (status IN ('running','ok','failed')),
  detail         text,
  started_at     timestamptz NOT NULL,
  finished_at    timestamptz,
  by_name        text,
  uid            text UNIQUE
);

-- Catalogue des services : catégories spa et salle de réunion
ALTER TABLE services DROP CONSTRAINT IF EXISTS services_category_check;
ALTER TABLE services ADD CONSTRAINT services_category_check CHECK (category IN ('breakfast','restaurant','laundry','room_service','transfer','parking','minibar','spa','meeting_room','other'));
