-- ================= Étape 4 : Front Office =================

-- ---------- Protection contre les doubles opérations (double clic, requête répétée) ----------
CREATE TABLE idempotency_keys (
  key          text PRIMARY KEY,
  method       text NOT NULL,
  url          text NOT NULL,
  status_code  int,
  response     jsonb,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idempotency_keys_date_idx ON idempotency_keys (created_at);

-- Un séjour = un seul check-in et un seul check-out
CREATE UNIQUE INDEX check_ins_stay_uidx ON check_ins (stay_id);
CREATE UNIQUE INDEX check_outs_stay_uidx ON check_outs (stay_id);

-- ---------- Fiche client ----------
ALTER TABLE guests
  ADD COLUMN id_doc_issued_on    date,
  ADD COLUMN id_doc_issued_place text,
  ADD COLUMN preferences         text,
  ADD COLUMN vip                 boolean NOT NULL DEFAULT false,
  ADD COLUMN data_consent_at     timestamptz;          -- consentement au traitement des données (loi 18-07)

-- Notes internes, préférences, demandes particulières, réclamations
CREATE TABLE guest_notes (
  id              serial PRIMARY KEY,
  guest_id        int NOT NULL REFERENCES guests(id),
  reservation_id  int REFERENCES reservations(id),
  kind            text NOT NULL CHECK (kind IN ('note','preference','request','complaint')),
  text            text NOT NULL,
  status          text NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved')),
  resolution      text,
  created_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  resolved_by     int REFERENCES users(id),
  resolved_at     timestamptz
);
CREATE INDEX guest_notes_guest_idx ON guest_notes (guest_id);

-- ---------- Check-in ----------
ALTER TABLE stay_guests ADD COLUMN relation text;     -- accompagnant : conjoint, enfant, collègue…
ALTER TABLE check_ins
  ADD COLUMN coming_from     text,
  ADD COLUMN going_to        text,
  ADD COLUMN id_checked      boolean NOT NULL DEFAULT false,
  ADD COLUMN signed          boolean NOT NULL DEFAULT false,
  ADD COLUMN signature       text,                    -- image PNG (data URL) de la signature
  ADD COLUMN walk_in         boolean NOT NULL DEFAULT false;

-- ---------- Prestations ----------
CREATE TABLE services (
  id        serial PRIMARY KEY,
  hotel_id  int NOT NULL REFERENCES hotels(id),
  code      text NOT NULL,
  name      text NOT NULL,
  category  text NOT NULL CHECK (category IN ('breakfast','restaurant','laundry','room_service','transfer','parking','minibar','other')),
  price     numeric(12,2) NOT NULL DEFAULT 0 CHECK (price >= 0),
  unit      text NOT NULL DEFAULT 'unit' CHECK (unit IN ('unit','person','night','kg','trip','day')),
  active    boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0,
  UNIQUE (hotel_id, code)
);

ALTER TABLE charges DROP CONSTRAINT charges_kind_check;
ALTER TABLE charges ADD CONSTRAINT charges_kind_check
  CHECK (kind IN ('service','breakfast','restaurant','room_service','minibar','laundry','transfer','parking','cancellation_fee','no_show_fee','other'));
ALTER TABLE charges
  ADD COLUMN service_id  int REFERENCES services(id),
  ADD COLUMN voided_by   int REFERENCES users(id),
  ADD COLUMN voided_at   timestamptz;

-- ---------- Changements de chambre ----------
CREATE TABLE room_changes (
  id                   serial PRIMARY KEY,
  reservation_room_id  int NOT NULL REFERENCES reservation_rooms(id),
  from_room_id         int NOT NULL REFERENCES rooms(id),
  to_room_id           int NOT NULL REFERENCES rooms(id),
  change_date          date NOT NULL,
  reason               text NOT NULL,
  rate_policy          text NOT NULL CHECK (rate_policy IN ('keep','new')),
  rate_before          numeric(12,2) NOT NULL,
  rate_after           numeric(12,2) NOT NULL,
  in_house             boolean NOT NULL,
  done_by              int REFERENCES users(id),
  done_at              timestamptz NOT NULL DEFAULT now()
);

-- ---------- Remboursements : rattachement à la chambre ----------
ALTER TABLE refunds ADD COLUMN reservation_room_id int REFERENCES reservation_rooms(id);

-- Changement de chambre en cours de séjour : le séjour est découpé en segments (historique exact de chaque chambre)
ALTER TABLE reservation_rooms ADD COLUMN moved_from_rr_id int REFERENCES reservation_rooms(id);
