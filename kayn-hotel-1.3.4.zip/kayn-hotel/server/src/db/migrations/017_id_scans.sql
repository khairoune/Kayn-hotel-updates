-- Lecture de pièce d'identité (scan par téléphone ou import d'image) : sessions de scan à jeton unique.
-- La photo est conservée temporairement (paramètre id_scans.keep_days) puis effacée ; les données validées
-- par l'utilisateur sont enregistrées dans la fiche client (fiche de police), comme une saisie manuelle.
CREATE TABLE IF NOT EXISTS id_scans (
  id bigserial PRIMARY KEY,
  hotel_id int NOT NULL REFERENCES hotels(id),
  token_hash text NOT NULL UNIQUE,
  created_by int REFERENCES users(id),
  context text NOT NULL DEFAULT 'reservation' CHECK (context IN ('reservation','checkin','guest')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','uploaded','read','unreadable','used','expired')),
  file_path text,
  mime text,
  size_bytes int,
  uploads int NOT NULL DEFAULT 0,
  source text CHECK (source IN ('phone','upload')),
  mrz jsonb,
  guest_id int REFERENCES guests(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  uploaded_at timestamptz,
  used_at timestamptz,
  expires_at timestamptz NOT NULL,
  image_deleted_at timestamptz
);
CREATE INDEX IF NOT EXISTS id_scans_hotel_idx ON id_scans (hotel_id, created_at DESC);
CREATE INDEX IF NOT EXISTS id_scans_guest_idx ON id_scans (guest_id) WHERE guest_id IS NOT NULL;
