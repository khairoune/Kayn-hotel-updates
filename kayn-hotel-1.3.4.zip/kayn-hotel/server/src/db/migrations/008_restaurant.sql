-- =====================================================================================================
-- Phase 7 : Restaurant & Services (carte, menus, tables, commandes, cuisine, room service, petit-déjeuner, bar, stock)
-- =====================================================================================================

-- ---------- Carte ----------
CREATE TABLE rs_categories (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  name        text NOT NULL,
  kind        text NOT NULL CHECK (kind IN ('starter','main','dessert','drink','breakfast')),
  station     text NOT NULL DEFAULT 'kitchen' CHECK (station IN ('kitchen','bar','pastry','none')),
  sort_order  int NOT NULL DEFAULT 0,
  active      boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, name)
);

CREATE TABLE rs_items (
  id            serial PRIMARY KEY,
  hotel_id      int NOT NULL REFERENCES hotels(id),
  category_id   int NOT NULL REFERENCES rs_categories(id),
  name          text NOT NULL,
  description   text,
  price         numeric(12,2) NOT NULL CHECK (price >= 0),
  station       text CHECK (station IN ('kitchen','bar','pastry','none')),   -- NULL = poste de la catégorie
  prep_minutes  int NOT NULL DEFAULT 10 CHECK (prep_minutes >= 0),
  ingredients   text,                                                       -- composition affichée
  allergens     text[] NOT NULL DEFAULT '{}',
  available     boolean NOT NULL DEFAULT true,                              -- disponibilité manuelle (rupture)
  active        boolean NOT NULL DEFAULT true,                              -- désactivé = retiré de la carte (historique conservé)
  sort_order    int NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX rs_items_hotel_idx ON rs_items(hotel_id, active);

-- Variantes (un choix parmi) et suppléments (plusieurs)
CREATE TABLE rs_item_options (
  id           serial PRIMARY KEY,
  item_id      int NOT NULL REFERENCES rs_items(id),
  kind         text NOT NULL CHECK (kind IN ('variant','supplement')),
  name         text NOT NULL,
  price_delta  numeric(12,2) NOT NULL DEFAULT 0,
  active       boolean NOT NULL DEFAULT true,
  sort_order   int NOT NULL DEFAULT 0
);

-- Menus par service / horaire / jour ; menu du jour = date précise
CREATE TABLE rs_menus (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  name        text NOT NULL,
  outlets     text[] NOT NULL DEFAULT '{restaurant}',
  days        int[] NOT NULL DEFAULT '{0,1,2,3,4,5,6}',
  start_time  time NOT NULL DEFAULT '00:00',
  end_time    time NOT NULL DEFAULT '23:59',
  menu_date   date,                                 -- menu du jour
  set_price   numeric(12,2),                        -- formule à prix fixe (facultatif)
  active      boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE rs_menu_items (
  menu_id  int NOT NULL REFERENCES rs_menus(id) ON DELETE CASCADE,
  item_id  int NOT NULL REFERENCES rs_items(id),
  PRIMARY KEY (menu_id, item_id)
);

-- ---------- Stock (prépare le module Stocks & Achats : la table products existe déjà) ----------
ALTER TABLE products ADD COLUMN code text, ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE stock_movements DROP CONSTRAINT stock_movements_kind_check;
ALTER TABLE stock_movements ADD CONSTRAINT stock_movements_kind_check CHECK (kind IN ('in','out','adjust','sale','waste'));
ALTER TABLE stock_movements ADD COLUMN rs_order_id int, ADD COLUMN stock_after numeric(12,3);
ALTER TABLE products ALTER COLUMN stock_qty TYPE numeric(12,3), ALTER COLUMN min_stock TYPE numeric(12,3);
ALTER TABLE stock_movements ALTER COLUMN quantity TYPE numeric(12,3);
CREATE TRIGGER stock_movements_immutable BEFORE UPDATE OR DELETE ON stock_movements FOR EACH ROW EXECUTE FUNCTION forbid_change();

CREATE TABLE rs_recipes (
  item_id     int NOT NULL REFERENCES rs_items(id),
  product_id  int NOT NULL REFERENCES products(id),
  quantity    numeric(12,3) NOT NULL CHECK (quantity > 0),     -- par portion, dans l'unité du produit
  PRIMARY KEY (item_id, product_id)
);

-- ---------- Salle ----------
CREATE TABLE rs_tables (
  id           serial PRIMARY KEY,
  hotel_id     int NOT NULL REFERENCES hotels(id),
  number       text NOT NULL,
  area         text NOT NULL DEFAULT 'Salle',
  capacity     int NOT NULL DEFAULT 4 CHECK (capacity > 0),
  pos_x        int NOT NULL DEFAULT 0,
  pos_y        int NOT NULL DEFAULT 0,
  shape        text NOT NULL DEFAULT 'square' CHECK (shape IN ('square','round','long')),
  status       text NOT NULL DEFAULT 'available' CHECK (status IN ('available','occupied','to_clean')),
  merged_into  int REFERENCES rs_tables(id),           -- table regroupée avec une table principale
  active       boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, number)
);

CREATE TABLE rs_table_bookings (
  id           serial PRIMARY KEY,
  hotel_id     int NOT NULL REFERENCES hotels(id),
  table_id     int NOT NULL REFERENCES rs_tables(id),
  guest_name   text NOT NULL,
  phone        text,
  guest_id     int REFERENCES guests(id),
  room_id      int REFERENCES rooms(id),
  party_size   int NOT NULL CHECK (party_size > 0),
  starts_at    timestamptz NOT NULL,
  duration_min int NOT NULL DEFAULT 90 CHECK (duration_min BETWEEN 15 AND 480),
  status       text NOT NULL DEFAULT 'booked' CHECK (status IN ('booked','seated','cancelled','no_show')),
  notes        text,
  created_by   int REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX rs_table_bookings_idx ON rs_table_bookings(table_id, starts_at);

-- ---------- Commandes ----------
CREATE TABLE rs_orders (
  id                serial PRIMARY KEY,
  hotel_id          int NOT NULL REFERENCES hotels(id),
  number            text NOT NULL,
  outlet            text NOT NULL CHECK (outlet IN ('restaurant','bar','room_service','breakfast')),
  table_id          int REFERENCES rs_tables(id),
  room_id           int REFERENCES rooms(id),
  reservation_id    int REFERENCES reservations(id),
  reservation_room_id int REFERENCES reservation_rooms(id),
  guest_id          int REFERENCES guests(id),
  guest_name        text,
  covers            int NOT NULL DEFAULT 1 CHECK (covers > 0),
  status            text NOT NULL DEFAULT 'new' CHECK (status IN ('new','confirmed','preparing','ready','served','cancelled')),
  priority          text NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal','high','urgent')),
  notes             text,
  waiter_id         int REFERENCES users(id),
  assigned_to       int REFERENCES users(id),        -- room service : livreur
  discount_type     text CHECK (discount_type IN ('percent','amount')),
  discount_value    numeric(12,2) NOT NULL DEFAULT 0,
  discount_reason   text,
  discount_by       int REFERENCES users(id),
  subtotal          numeric(12,2) NOT NULL DEFAULT 0,   -- HT avant remise
  discount_total    numeric(12,2) NOT NULL DEFAULT 0,
  tax_total         numeric(12,2) NOT NULL DEFAULT 0,
  total             numeric(12,2) NOT NULL DEFAULT 0,   -- TTC après remise
  settlement        text NOT NULL DEFAULT 'open' CHECK (settlement IN ('open','paid','room','invoice','cancelled')),
  invoice_id        int REFERENCES invoices(id),
  settled_at        timestamptz,
  settled_by        int REFERENCES users(id),
  stock_done        boolean NOT NULL DEFAULT false,
  created_by        int REFERENCES users(id),
  created_at        timestamptz NOT NULL DEFAULT now(),
  confirmed_at      timestamptz,
  preparing_at      timestamptz,
  ready_at          timestamptz,
  served_at         timestamptz,
  out_at            timestamptz,                       -- room service : parti en livraison
  cancelled_at      timestamptz,
  cancelled_by      int REFERENCES users(id),
  cancel_reason     text,
  UNIQUE (hotel_id, number)
);
CREATE INDEX rs_orders_day_idx ON rs_orders(hotel_id, created_at);
CREATE INDEX rs_orders_open_idx ON rs_orders(hotel_id, status) WHERE status NOT IN ('served','cancelled');
-- une facture restaurant ne couvre qu'une seule commande (anti double facturation)
CREATE UNIQUE INDEX rs_orders_invoice_uq ON rs_orders(invoice_id) WHERE invoice_id IS NOT NULL;
ALTER TABLE stock_movements ADD CONSTRAINT stock_movements_order_fk FOREIGN KEY (rs_order_id) REFERENCES rs_orders(id);

CREATE TABLE rs_order_lines (
  id              serial PRIMARY KEY,
  order_id        int NOT NULL REFERENCES rs_orders(id),
  item_id         int NOT NULL REFERENCES rs_items(id),
  name            text NOT NULL,
  category_kind   text NOT NULL,
  station         text NOT NULL,
  unit_price      numeric(12,2) NOT NULL CHECK (unit_price >= 0),   -- prix plat + options, figé
  options         jsonb NOT NULL DEFAULT '[]',
  quantity        int NOT NULL CHECK (quantity > 0 AND quantity <= 100),
  comment         text,
  tax_rate        numeric(5,2) NOT NULL DEFAULT 0,
  discount        numeric(12,2) NOT NULL DEFAULT 0,                 -- part de la remise de commande
  kitchen_status  text NOT NULL DEFAULT 'pending' CHECK (kitchen_status IN ('pending','sent','preparing','ready','served')),
  sent_at         timestamptz,
  started_at      timestamptz,
  ready_at        timestamptz,
  cancelled       boolean NOT NULL DEFAULT false,
  cancel_reason   text,
  cancelled_by    int REFERENCES users(id),
  created_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX rs_order_lines_order_idx ON rs_order_lines(order_id);

-- Transfert au folio : une ligne de commande ne peut créer qu'une seule prestation active
ALTER TABLE charges ADD COLUMN rs_order_line_id int REFERENCES rs_order_lines(id);
CREATE UNIQUE INDEX charges_rs_line_uq ON charges(rs_order_line_id) WHERE rs_order_line_id IS NOT NULL AND NOT void;

-- ---------- Petit-déjeuner ----------
CREATE TABLE rs_breakfasts (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  service_date    date NOT NULL,
  reservation_room_id int REFERENCES reservation_rooms(id),
  room_id         int REFERENCES rooms(id),
  guest_name      text,
  included        int NOT NULL DEFAULT 0 CHECK (included >= 0),    -- petits-déjeuners inclus consommés
  extra           int NOT NULL DEFAULT 0 CHECK (extra >= 0),       -- supplémentaires payants
  charge_id       int REFERENCES charges(id),
  order_id        int REFERENCES rs_orders(id),
  late            boolean NOT NULL DEFAULT false,
  recorded_by     int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  CHECK (included + extra > 0)
);
CREATE INDEX rs_breakfasts_day_idx ON rs_breakfasts(hotel_id, service_date);

-- Photos de plats
ALTER TABLE photos DROP CONSTRAINT IF EXISTS photos_owner_type_check;
ALTER TABLE photos ADD CONSTRAINT photos_owner_type_check CHECK (owner_type IN ('room','room_type','inspection','lost_item','menu_item'));
