-- Étape 2 : gestion complète des réservations

-- Tarif, remise, taxes figées à la réservation, facturation de groupe, demandes particulières
ALTER TABLE reservations
  ADD COLUMN rate_mode        text NOT NULL DEFAULT 'standard' CHECK (rate_mode IN ('standard','custom')),
  ADD COLUMN discount_type    text CHECK (discount_type IN ('percent','amount')),
  ADD COLUMN discount_value   numeric(12,2) NOT NULL DEFAULT 0 CHECK (discount_value >= 0),
  ADD COLUMN vat_rate         numeric(5,2) NOT NULL DEFAULT 0 CHECK (vat_rate >= 0),
  ADD COLUMN tourist_tax      numeric(12,2) NOT NULL DEFAULT 0 CHECK (tourist_tax >= 0),
  ADD COLUMN special_requests text,
  ADD COLUMN billing_mode     text NOT NULL DEFAULT 'common' CHECK (billing_mode IN ('common','individual'));

-- Prix public (avant remise), remise par nuit, prix manuel, occupant de la chambre
ALTER TABLE reservation_rooms
  ADD COLUMN rack_rate           numeric(12,2),
  ADD COLUMN discount_per_night  numeric(12,2) NOT NULL DEFAULT 0 CHECK (discount_per_night >= 0),
  ADD COLUMN custom_rate         boolean NOT NULL DEFAULT false,
  ADD COLUMN guest_id            int REFERENCES guests(id);
UPDATE reservation_rooms SET rack_rate = rate WHERE rack_rate IS NULL;
ALTER TABLE reservation_rooms ALTER COLUMN rack_rate SET NOT NULL;
ALTER TABLE reservation_rooms ADD CONSTRAINT rr_rate_consistent CHECK (rate = rack_rate - discount_per_night);

-- Paiement et facture rattachables à une chambre (facturation individuelle des groupes)
ALTER TABLE payments ADD COLUMN reservation_room_id int REFERENCES reservation_rooms(id);
ALTER TABLE invoices ADD COLUMN reservation_room_id int REFERENCES reservation_rooms(id);

-- File de notifications (envoi quand Internet est disponible, ou envoi manuel WhatsApp)
CREATE TABLE notifications (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  reservation_id  int REFERENCES reservations(id),
  kind            text NOT NULL CHECK (kind IN ('confirmation','modification','cancellation','reminder')),
  channel         text NOT NULL CHECK (channel IN ('email','whatsapp','internal')),
  recipient       text,
  subject         text NOT NULL,
  body            text NOT NULL,
  status          text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sent','failed','cancelled')),
  attempts        int NOT NULL DEFAULT 0,
  last_error      text,
  created_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  sent_at         timestamptz,
  sent_by         int REFERENCES users(id)
);
CREATE INDEX notifications_status_idx ON notifications(status, channel);
CREATE UNIQUE INDEX one_reminder_per_channel ON notifications(reservation_id, channel) WHERE kind = 'reminder';

-- Le paiement rattaché à une chambre ne peut pas être modifié après coup
CREATE OR REPLACE FUNCTION payments_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Suppression d''un paiement interdite : utilisez l''annulation';
  END IF;
  IF OLD.void THEN
    RAISE EXCEPTION 'Paiement déjà annulé : modification interdite';
  END IF;
  IF NEW.amount <> OLD.amount OR NEW.method <> OLD.method OR NEW.received_at <> OLD.received_at
     OR NEW.reservation_id IS DISTINCT FROM OLD.reservation_id OR NEW.received_by IS DISTINCT FROM OLD.received_by
     OR NEW.cash_session_id IS DISTINCT FROM OLD.cash_session_id OR NEW.kind <> OLD.kind
     OR NEW.reservation_room_id IS DISTINCT FROM OLD.reservation_room_id THEN
    RAISE EXCEPTION 'Modification d''un paiement interdite : seule l''annulation est permise';
  END IF;
  IF NEW.void AND (NEW.void_reason IS NULL OR NEW.voided_by IS NULL) THEN
    RAISE EXCEPTION 'Annulation de paiement : motif et utilisateur obligatoires';
  END IF;
  RETURN NEW;
END $$;
