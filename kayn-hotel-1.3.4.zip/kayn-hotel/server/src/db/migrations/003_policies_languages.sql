-- Langue de communication du client (messages FR / EN / AR)
ALTER TABLE guests ADD COLUMN language text NOT NULL DEFAULT 'fr' CHECK (language IN ('fr','en','ar'));
ALTER TABLE notifications ADD COLUMN language text NOT NULL DEFAULT 'fr' CHECK (language IN ('fr','en','ar'));

-- Frais d'annulation tardive / non-présentation
ALTER TABLE charges DROP CONSTRAINT charges_kind_check;
ALTER TABLE charges ADD CONSTRAINT charges_kind_check
  CHECK (kind IN ('service','restaurant','minibar','laundry','transfer','parking','cancellation_fee','no_show_fee','other'));

-- Acompte : la réservation passe automatiquement en « Confirmée » quand l'acompte requis est atteint
ALTER TABLE reservations ADD COLUMN confirm_on_deposit boolean NOT NULL DEFAULT false;
ALTER TABLE reservations ADD COLUMN cancellation_fee numeric(12,2) NOT NULL DEFAULT 0 CHECK (cancellation_fee >= 0);
