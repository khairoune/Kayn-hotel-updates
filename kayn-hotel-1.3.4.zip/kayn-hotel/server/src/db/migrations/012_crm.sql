-- =====================================================================================================
-- Phase 11 : CRM & clients (fiche unique, préférences, fidélité, entreprises, réclamations, enquêtes,
-- communication, segments, campagnes, confidentialité)
-- =====================================================================================================

-- ---------- Fiche client : identifiant unique, statut, consentements, entreprise, fusion, anonymisation ----------
ALTER TABLE guests
  ADD COLUMN code               text,
  ADD COLUMN crm_status         text NOT NULL DEFAULT 'standard' CHECK (crm_status IN ('standard','loyal','vip','company')),
  ADD COLUMN status_locked      boolean NOT NULL DEFAULT false,      -- statut fixé à la main (pas de recalcul)
  ADD COLUMN company_id         int REFERENCES guests(id),           -- personne rattachée à une entreprise
  ADD COLUMN job_title          text,
  ADD COLUMN mobile             text,
  ADD COLUMN preferred_room_type_id int REFERENCES room_types(id),
  ADD COLUMN consent_email      boolean NOT NULL DEFAULT false,      -- communications commerciales
  ADD COLUMN consent_sms        boolean NOT NULL DEFAULT false,
  ADD COLUMN consent_updated_at timestamptz,
  ADD COLUMN unsubscribe_token  text,
  ADD COLUMN unsubscribed_at    timestamptz,
  ADD COLUMN loyalty_number     text,
  ADD COLUMN loyalty_joined_at  timestamptz,
  ADD COLUMN loyalty_tier_id    int,
  ADD COLUMN source             text,
  ADD COLUMN merged_into_id     int REFERENCES guests(id),
  ADD COLUMN anonymized_at      timestamptz,
  -- entreprises
  ADD COLUMN payment_terms_days int,
  ADD COLUMN credit_limit       numeric(14,2),
  ADD COLUMN website            text,
  ADD COLUMN sector             text;
UPDATE guests SET code = 'CL' || lpad(id::text, 6, '0') WHERE code IS NULL;
UPDATE guests SET crm_status = CASE WHEN kind <> 'person' THEN 'company' WHEN vip THEN 'vip' ELSE 'standard' END;
UPDATE guests SET unsubscribe_token = md5(random()::text || id::text || clock_timestamp()::text) WHERE unsubscribe_token IS NULL;
ALTER TABLE guests ALTER COLUMN code SET NOT NULL;
CREATE UNIQUE INDEX guests_code_uq ON guests(hotel_id, code);
CREATE UNIQUE INDEX guests_loyalty_uq ON guests(hotel_id, loyalty_number) WHERE loyalty_number IS NOT NULL;
CREATE UNIQUE INDEX guests_unsub_uq ON guests(unsubscribe_token);
CREATE INDEX guests_phone_idx ON guests(hotel_id, regexp_replace(coalesce(phone,''), '\D', '', 'g'));
CREATE INDEX guests_email_idx ON guests(hotel_id, lower(email));
CREATE FUNCTION guests_crm_defaults() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.code IS NULL OR NEW.code = '' THEN NEW.code := 'CL' || lpad(NEW.id::text, 6, '0'); END IF;
  IF NEW.unsubscribe_token IS NULL THEN NEW.unsubscribe_token := md5(random()::text || NEW.id::text || clock_timestamp()::text); END IF;
  IF TG_OP = 'INSERT' AND NEW.kind <> 'person' THEN NEW.crm_status := 'company'; END IF;
  IF TG_OP = 'INSERT' AND NEW.kind = 'person' AND NEW.vip AND NEW.crm_status = 'standard' THEN NEW.crm_status := 'vip'; NEW.status_locked := true; END IF;
  -- l'ancien indicateur VIP reste synchronisé avec le statut CRM
  IF TG_OP = 'UPDATE' AND NEW.vip IS DISTINCT FROM OLD.vip AND NEW.crm_status IS NOT DISTINCT FROM OLD.crm_status THEN
    NEW.crm_status := CASE WHEN NEW.vip THEN 'vip' WHEN NEW.kind <> 'person' THEN 'company' ELSE 'standard' END;
    NEW.status_locked := NEW.vip;
  END IF;
  NEW.vip := NEW.crm_status = 'vip';
  RETURN NEW;
END $$;
CREATE TRIGGER guests_crm_defaults_trg BEFORE INSERT OR UPDATE ON guests FOR EACH ROW EXECUTE FUNCTION guests_crm_defaults();

-- ---------- Préférences structurées ----------
CREATE TABLE guest_preferences (
  id          serial PRIMARY KEY,
  guest_id    int NOT NULL REFERENCES guests(id),
  category    text NOT NULL CHECK (category IN ('room','dietary','service','request','occasion','habit','communication')),
  value       text NOT NULL,
  event_date  date,                  -- occasion spéciale (anniversaire de mariage…)
  recurring   boolean NOT NULL DEFAULT false,
  volunteered boolean NOT NULL DEFAULT true,   -- communiqué volontairement par le client
  created_by  int REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX guest_preferences_guest_idx ON guest_preferences(guest_id);

-- ---------- Programme de fidélité ----------
CREATE TABLE loyalty_tiers (
  id                serial PRIMARY KEY,
  hotel_id          int NOT NULL REFERENCES hotels(id),
  code              text NOT NULL,
  name              text NOT NULL,
  min_points        int NOT NULL DEFAULT 0 CHECK (min_points >= 0),   -- points acquis sur 12 mois glissants
  earn_multiplier   numeric(4,2) NOT NULL DEFAULT 1 CHECK (earn_multiplier > 0),
  discount_percent  numeric(5,2) NOT NULL DEFAULT 0 CHECK (discount_percent BETWEEN 0 AND 50),
  benefits          text,
  color             text NOT NULL DEFAULT '#64748B',
  active            boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, code)
);
ALTER TABLE guests ADD CONSTRAINT guests_tier_fk FOREIGN KEY (loyalty_tier_id) REFERENCES loyalty_tiers(id);
CREATE TABLE loyalty_rewards (
  id            serial PRIMARY KEY,
  hotel_id      int NOT NULL REFERENCES hotels(id),
  name          text NOT NULL,
  kind          text NOT NULL CHECK (kind IN ('discount_amount','discount_percent','service','upgrade','other')),
  points_cost   int NOT NULL CHECK (points_cost > 0),
  value         numeric(12,2),                -- montant ou % de remise
  min_tier_id   int REFERENCES loyalty_tiers(id),
  description   text,
  active        boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE loyalty_transactions (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  guest_id         int NOT NULL REFERENCES guests(id),
  kind             text NOT NULL CHECK (kind IN ('earn','redeem','expire','adjust','bonus')),
  points           int NOT NULL CHECK (points <> 0),
  remaining        int NOT NULL DEFAULT 0,        -- points encore disponibles sur une ligne créditée (consommation FIFO)
  basis_amount     numeric(14,2),
  stay_id          int REFERENCES stays(id),
  rs_order_id      int REFERENCES rs_orders(id),
  reservation_id   int REFERENCES reservations(id),
  redemption_id    int,
  description      text NOT NULL,
  expires_at       date,
  created_by       int REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now()
);
-- jamais deux fois des points pour un même séjour ou une même commande
CREATE UNIQUE INDEX loyalty_earn_stay_uq ON loyalty_transactions(stay_id) WHERE kind = 'earn' AND stay_id IS NOT NULL;
CREATE UNIQUE INDEX loyalty_earn_order_uq ON loyalty_transactions(rs_order_id) WHERE kind = 'earn' AND rs_order_id IS NOT NULL;
CREATE INDEX loyalty_tx_guest_idx ON loyalty_transactions(guest_id, created_at);
CREATE FUNCTION loyalty_tx_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'Mouvement de points : suppression interdite'; END IF;
  IF NEW.points <> OLD.points OR NEW.kind <> OLD.kind OR NEW.guest_id <> OLD.guest_id OR NEW.created_at <> OLD.created_at THEN
    RAISE EXCEPTION 'Mouvement de points : modification interdite';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER loyalty_tx_guard_trg BEFORE UPDATE OR DELETE ON loyalty_transactions FOR EACH ROW EXECUTE FUNCTION loyalty_tx_guard();
CREATE TABLE loyalty_redemptions (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  number          text NOT NULL,
  guest_id        int NOT NULL REFERENCES guests(id),
  reward_id       int NOT NULL REFERENCES loyalty_rewards(id),
  points          int NOT NULL,
  reservation_id  int REFERENCES reservations(id),
  status          text NOT NULL DEFAULT 'issued' CHECK (status IN ('issued','used','cancelled')),
  applied_amount  numeric(12,2),
  notes           text,
  created_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  used_at         timestamptz,
  UNIQUE (hotel_id, number)
);
ALTER TABLE reservations ADD COLUMN discount_source text;   -- manual / loyalty_reward / member

-- ---------- Entreprises : contacts, contrats ----------
CREATE TABLE crm_contacts (
  id          serial PRIMARY KEY,
  company_id  int NOT NULL REFERENCES guests(id),
  name        text NOT NULL,
  role        text,
  phone       text,
  email       text,
  is_billing  boolean NOT NULL DEFAULT false,
  is_booker   boolean NOT NULL DEFAULT false,
  active      boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE crm_contracts (
  id            serial PRIMARY KEY,
  hotel_id      int NOT NULL REFERENCES hotels(id),
  company_id    int NOT NULL REFERENCES guests(id),
  number        text NOT NULL,
  title         text NOT NULL,
  start_date    date NOT NULL,
  end_date      date,
  rate_plan_id  int REFERENCES rate_plans(id),
  room_nights_commitment int,
  payment_terms_days int,
  credit_limit  numeric(14,2),
  terms         text,
  status        text NOT NULL DEFAULT 'active' CHECK (status IN ('draft','active','expired','terminated')),
  created_by    int REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (hotel_id, number),
  CHECK (end_date IS NULL OR end_date >= start_date)
);

-- ---------- Réclamations ----------
CREATE TABLE crm_complaints (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  number          text NOT NULL,
  guest_id        int NOT NULL REFERENCES guests(id),
  reservation_id  int REFERENCES reservations(id),
  stay_id         int REFERENCES stays(id),
  note_id         int REFERENCES guest_notes(id),
  category        text NOT NULL CHECK (category IN ('room','cleanliness','noise','staff','food','billing','maintenance','reservation','wifi','other')),
  priority        text NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  channel         text NOT NULL DEFAULT 'in_person' CHECK (channel IN ('in_person','phone','email','survey','online','other')),
  kind            text NOT NULL DEFAULT 'complaint' CHECK (kind IN ('complaint','remark','compliment')),
  title           text NOT NULL,
  description     text,
  status          text NOT NULL DEFAULT 'new' CHECK (status IN ('new','in_progress','resolved','closed')),
  assigned_to     int REFERENCES users(id),
  due_at          timestamptz,
  resolution      text,
  compensation    text,
  satisfaction    int CHECK (satisfaction BETWEEN 1 AND 5),
  created_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  resolved_at     timestamptz,
  resolved_by     int REFERENCES users(id),
  closed_at       timestamptz,
  UNIQUE (hotel_id, number)
);
CREATE INDEX crm_complaints_status_idx ON crm_complaints(hotel_id, status);
CREATE TABLE crm_complaint_updates (
  id            serial PRIMARY KEY,
  complaint_id  int NOT NULL REFERENCES crm_complaints(id),
  kind          text NOT NULL CHECK (kind IN ('comment','action','response','status')),
  text          text NOT NULL,
  created_by    int REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now()
);
-- reprise des réclamations existantes (notes clients)
INSERT INTO crm_complaints (hotel_id, number, guest_id, reservation_id, note_id, category, title, description, status, created_by, created_at, resolution, resolved_at, resolved_by)
SELECT g.hotel_id, 'RC' || to_char(n.created_at, 'YYYY') || '-' || lpad(row_number() OVER (ORDER BY n.id)::text, 4, '0'), n.guest_id, n.reservation_id, n.id, 'other', left(n.text, 120), n.text,
       CASE WHEN n.status = 'resolved' THEN 'closed' ELSE 'new' END, n.created_by, n.created_at, n.resolution, n.resolved_at, n.resolved_by
  FROM guest_notes n JOIN guests g ON g.id = n.guest_id WHERE n.kind = 'complaint';

-- ---------- Enquêtes de satisfaction ----------
CREATE TABLE crm_surveys (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  name        text NOT NULL,
  questions   jsonb NOT NULL DEFAULT '[]',    -- [{id, label, type: rating|nps|yesno|text}]
  trigger     text NOT NULL DEFAULT 'manual' CHECK (trigger IN ('manual','after_stay','after_complaint')),
  active      boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE crm_survey_responses (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  survey_id       int NOT NULL REFERENCES crm_surveys(id),
  guest_id        int REFERENCES guests(id),
  reservation_id  int REFERENCES reservations(id),
  complaint_id    int REFERENCES crm_complaints(id),
  token           text NOT NULL UNIQUE,
  answers         jsonb,
  score           numeric(4,2),          -- moyenne des notes /5
  nps             int CHECK (nps BETWEEN 0 AND 10),
  comment         text,
  sent_at         timestamptz,
  completed_at    timestamptz,
  entered_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX crm_survey_one_per_res ON crm_survey_responses(survey_id, reservation_id) WHERE reservation_id IS NOT NULL;

-- ---------- Communication ----------
CREATE TABLE crm_templates (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  code        text NOT NULL,
  name        text NOT NULL,
  purpose     text NOT NULL CHECK (purpose IN ('transactional','marketing')),
  channel     text NOT NULL DEFAULT 'email' CHECK (channel IN ('email','sms','whatsapp')),
  language    text NOT NULL DEFAULT 'fr' CHECK (language IN ('fr','en','ar')),
  subject     text NOT NULL,
  body        text NOT NULL,
  active      boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (hotel_id, code, language)
);
CREATE TABLE crm_interactions (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  guest_id         int NOT NULL REFERENCES guests(id),
  channel          text NOT NULL CHECK (channel IN ('phone','email','sms','whatsapp','in_person','letter','other')),
  direction        text NOT NULL DEFAULT 'out' CHECK (direction IN ('in','out')),
  subject          text,
  body             text,
  reservation_id   int REFERENCES reservations(id),
  notification_id  int REFERENCES notifications(id),
  campaign_id      int,
  created_by       int REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX crm_interactions_guest_idx ON crm_interactions(guest_id, created_at);
-- la file d'envoi existante accueille les messages CRM
ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_kind_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_kind_check CHECK (kind IN ('confirmation','modification','cancellation','reminder','crm','thanks','pre_arrival','post_stay','birthday','campaign','survey'));
ALTER TABLE notifications ADD COLUMN guest_id int REFERENCES guests(id), ADD COLUMN campaign_id int, ADD COLUMN scheduled_for timestamptz;
CREATE UNIQUE INDEX notifications_auto_uq ON notifications(guest_id, kind, reservation_id) WHERE kind IN ('pre_arrival','post_stay','thanks') AND reservation_id IS NOT NULL;
CREATE UNIQUE INDEX notifications_birthday_uq ON notifications(guest_id, kind, (date_trunc('year', created_at AT TIME ZONE 'UTC'))) WHERE kind = 'birthday';

-- ---------- Segments et campagnes ----------
CREATE TABLE crm_segments (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  name        text NOT NULL,
  criteria    jsonb NOT NULL DEFAULT '{}',
  created_by  int REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE crm_campaigns (
  id            serial PRIMARY KEY,
  hotel_id      int NOT NULL REFERENCES hotels(id),
  name          text NOT NULL,
  segment_id    int NOT NULL REFERENCES crm_segments(id),
  template_id   int NOT NULL REFERENCES crm_templates(id),
  status        text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','scheduled','sent','cancelled')),
  scheduled_at  timestamptz,
  sent_at       timestamptz,
  recipients    int NOT NULL DEFAULT 0,
  skipped       int NOT NULL DEFAULT 0,
  created_by    int REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE crm_campaign_recipients (
  id               serial PRIMARY KEY,
  campaign_id      int NOT NULL REFERENCES crm_campaigns(id),
  guest_id         int NOT NULL REFERENCES guests(id),
  status           text NOT NULL CHECK (status IN ('queued','skipped_consent','skipped_contact','sent','failed','unsubscribed')),
  notification_id  int REFERENCES notifications(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (campaign_id, guest_id)
);
ALTER TABLE crm_interactions ADD CONSTRAINT crm_interactions_campaign_fk FOREIGN KEY (campaign_id) REFERENCES crm_campaigns(id);

-- ---------- Confidentialité : demandes des clients ----------
CREATE TABLE crm_privacy_requests (
  id            serial PRIMARY KEY,
  hotel_id      int NOT NULL REFERENCES hotels(id),
  guest_id      int NOT NULL REFERENCES guests(id),
  kind          text NOT NULL CHECK (kind IN ('access','rectification','erasure','consent_withdrawal')),
  details       text,
  status        text NOT NULL DEFAULT 'done' CHECK (status IN ('pending','done','refused')),
  outcome       text,
  handled_by    int REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE photos DROP CONSTRAINT IF EXISTS photos_owner_type_check;
ALTER TABLE photos ADD CONSTRAINT photos_owner_type_check CHECK (owner_type IN ('room','room_type','inspection','lost_item','menu_item','equipment','ticket','work_order','employee','hr_document','leave_request','guest','crm_contract'));
