-- Rapport mensuel PDF envoyé automatiquement par e-mail (le 1er du mois, pour le mois écoulé)
CREATE TABLE monthly_reports (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  month       text NOT NULL CHECK (month ~ '^\d{4}-\d{2}$'),
  status      text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sent','failed')),
  recipients  text[] NOT NULL DEFAULT '{}',
  attempts    int NOT NULL DEFAULT 0,
  last_error  text,
  trigger     text NOT NULL DEFAULT 'auto' CHECK (trigger IN ('auto','manual')),
  created_by  int REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now(),
  sent_at     timestamptz
);
CREATE UNIQUE INDEX monthly_reports_auto_once ON monthly_reports(hotel_id, month) WHERE trigger = 'auto';
CREATE INDEX monthly_reports_hotel ON monthly_reports(hotel_id, created_at DESC);
