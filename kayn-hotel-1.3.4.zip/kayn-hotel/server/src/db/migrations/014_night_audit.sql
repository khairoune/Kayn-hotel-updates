-- Phase 13 : Night audit — date opérationnelle, contrôles, anomalies, comptabilisation des revenus, rapprochement de caisse, clôture journalière.

-- ===================================================== Journées opérationnelles =====================================================
CREATE TABLE audit_days (
  id             serial PRIMARY KEY,
  hotel_id       int NOT NULL REFERENCES hotels(id),
  business_date  date NOT NULL,
  -- open : journée en cours ; checking : vérification lancée ; ready : prête à clôturer ; closed : clôturée ;
  -- reopened : réouverte exceptionnellement ; suspended : journée suivante mise en attente pendant une réouverture
  status         text NOT NULL DEFAULT 'open' CHECK (status IN ('open','checking','ready','closed','reopened','suspended')),
  opened_at      timestamptz NOT NULL DEFAULT now(),
  opened_by      int REFERENCES users(id),
  check_started_at timestamptz,
  check_started_by int REFERENCES users(id),
  last_check_at  timestamptz,
  closed_at      timestamptz,
  closed_by      int REFERENCES users(id),
  close_count    int NOT NULL DEFAULT 0,
  reopen_count   int NOT NULL DEFAULT 0,
  UNIQUE (hotel_id, business_date)
);
-- une seule journée « courante » par hôtel (empêche deux journées ouvertes et les clôtures concurrentes)
CREATE UNIQUE INDEX audit_days_one_current ON audit_days (hotel_id) WHERE status IN ('open','checking','ready','reopened');

-- Chaque clôture (et re-clôture après réouverture) est figée : instantané des totaux et du rapport, non modifiable.
CREATE TABLE audit_closures (
  id             serial PRIMARY KEY,
  audit_day_id   int NOT NULL REFERENCES audit_days(id),
  hotel_id       int NOT NULL REFERENCES hotels(id),
  business_date  date NOT NULL,
  version        int NOT NULL,
  closed_at      timestamptz NOT NULL DEFAULT now(),
  closed_by      int NOT NULL REFERENCES users(id),
  confirmation   text NOT NULL,
  revenue        numeric(14,2) NOT NULL DEFAULT 0,
  collected      numeric(14,2) NOT NULL DEFAULT 0,
  expenses       numeric(14,2) NOT NULL DEFAULT 0,
  cash_difference numeric(14,2) NOT NULL DEFAULT 0,
  anomalies      int NOT NULL DEFAULT 0,
  anomalies_resolved int NOT NULL DEFAULT 0,
  anomalies_accepted int NOT NULL DEFAULT 0,
  report         jsonb NOT NULL,
  UNIQUE (audit_day_id, version)
);
CREATE TRIGGER audit_closures_immutable BEFORE UPDATE OR DELETE ON audit_closures FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Journal des événements de la journée (démarrage, contrôles, validations, clôture, réouverture…)
CREATE TABLE audit_day_events (
  id           serial PRIMARY KEY,
  audit_day_id int NOT NULL REFERENCES audit_days(id),
  kind         text NOT NULL,
  detail       jsonb,
  user_id      int REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER audit_day_events_immutable BEFORE UPDATE OR DELETE ON audit_day_events FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ===================================================== Anomalies =====================================================
CREATE TABLE audit_anomalies (
  id            serial PRIMARY KEY,
  audit_day_id  int NOT NULL REFERENCES audit_days(id),
  hotel_id      int NOT NULL REFERENCES hotels(id),
  code          text NOT NULL,
  item          text NOT NULL,      -- point de la checklist concerné
  module        text NOT NULL,
  severity      text NOT NULL CHECK (severity IN ('info','warning','critical')),
  ref_type      text,
  ref_id        int,
  ref_label     text,
  description   text NOT NULL,
  fingerprint   text NOT NULL,
  responsible_user_id int REFERENCES users(id),
  status        text NOT NULL DEFAULT 'open' CHECK (status IN ('open','corrected','accepted')),
  detected_at   timestamptz NOT NULL DEFAULT now(),
  last_seen_at  timestamptz NOT NULL DEFAULT now(),
  resolved_at   timestamptz,
  resolved_by   int REFERENCES users(id),
  resolution    text,
  UNIQUE (audit_day_id, fingerprint)
);
CREATE INDEX audit_anomalies_day ON audit_anomalies (audit_day_id, status);
CREATE TABLE audit_anomaly_history (
  id          serial PRIMARY KEY,
  anomaly_id  int NOT NULL REFERENCES audit_anomalies(id),
  kind        text NOT NULL CHECK (kind IN ('detected','comment','corrected','accepted','reopened','auto_resolved','redetected')),
  text        text,
  user_id     int REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER audit_anomaly_history_immutable BEFORE UPDATE OR DELETE ON audit_anomaly_history FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ===================================================== Checklist =====================================================
CREATE TABLE audit_checklist (
  id           serial PRIMARY KEY,
  audit_day_id int NOT NULL REFERENCES audit_days(id),
  item         text NOT NULL,
  validated_by int REFERENCES users(id),
  validated_at timestamptz,
  note         text,
  UNIQUE (audit_day_id, item)
);

-- ===================================================== Comptabilisation des revenus =====================================================
-- Écritures du journal des revenus : une ligne par opération d'origine (nuitée, commande, prestation) ; les corrections
-- ultérieures sont des écritures d'ajustement (jamais de modification) → aucune double comptabilisation.
CREATE TABLE audit_postings (
  id            serial PRIMARY KEY,
  hotel_id      int NOT NULL REFERENCES hotels(id),
  audit_day_id  int NOT NULL REFERENCES audit_days(id),
  business_date date NOT NULL,
  department    text NOT NULL CHECK (department IN ('room','restaurant','room_service','services','other')),
  source_type   text NOT NULL CHECK (source_type IN ('room_night','rs_order','charge')),
  source_id     int NOT NULL,
  seq           int NOT NULL DEFAULT 1,
  kind          text NOT NULL DEFAULT 'posting' CHECK (kind IN ('posting','adjustment')),
  reference     text NOT NULL,
  description   text NOT NULL,
  amount        numeric(14,2) NOT NULL,
  tax           numeric(14,2) NOT NULL DEFAULT 0,
  posted_by     int REFERENCES users(id),
  posted_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_date, source_type, source_id, seq)
);
CREATE INDEX audit_postings_day ON audit_postings (hotel_id, business_date);
CREATE TRIGGER audit_postings_immutable BEFORE UPDATE OR DELETE ON audit_postings FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ===================================================== Rapprochement de caisse =====================================================
CREATE TABLE audit_cash_counts (
  id            serial PRIMARY KEY,
  audit_day_id  int NOT NULL REFERENCES audit_days(id),
  register_id   int NOT NULL REFERENCES cash_registers(id),
  session_id    int REFERENCES cash_sessions(id),
  opening       numeric(14,2) NOT NULL,
  receipts      numeric(14,2) NOT NULL,
  outflows      numeric(14,2) NOT NULL,
  refunds       numeric(14,2) NOT NULL,
  expected      numeric(14,2) NOT NULL,
  counted       numeric(14,2) NOT NULL,
  difference    numeric(14,2) NOT NULL,
  justification text,
  counted_by    int NOT NULL REFERENCES users(id),
  counted_at    timestamptz NOT NULL DEFAULT now(),
  needs_approval boolean NOT NULL DEFAULT false,
  approved_by   int REFERENCES users(id),
  approved_at   timestamptz,
  approval_note text,
  superseded    boolean NOT NULL DEFAULT false
);
CREATE INDEX audit_cash_day ON audit_cash_counts (audit_day_id, register_id);
-- un comptage n'est jamais modifié : seul le marquage « remplacé » et l'autorisation sont permis
CREATE FUNCTION audit_cash_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'Comptage de caisse non supprimable'; END IF;
  IF (NEW.counted, NEW.expected, NEW.difference, NEW.counted_by, NEW.counted_at, NEW.justification) IS DISTINCT FROM (OLD.counted, OLD.expected, OLD.difference, OLD.counted_by, OLD.counted_at, OLD.justification)
    THEN RAISE EXCEPTION 'Comptage de caisse non modifiable : effectuez un nouveau comptage'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER audit_cash_counts_guard BEFORE UPDATE OR DELETE ON audit_cash_counts FOR EACH ROW EXECUTE FUNCTION audit_cash_guard();

-- ===================================================== Date opérationnelle des opérations =====================================================
CREATE FUNCTION kh_business_date(h int) RETURNS date LANGUAGE sql STABLE AS $$
  SELECT COALESCE(
    (SELECT business_date FROM audit_days WHERE hotel_id = h AND status IN ('open','checking','ready','reopened') ORDER BY business_date LIMIT 1),
    (now() AT TIME ZONE COALESCE((SELECT timezone FROM hotels WHERE id = h), 'Africa/Algiers'))::date)
$$;
CREATE FUNCTION kh_last_closed(h int) RETURNS date LANGUAGE sql STABLE AS $$
  SELECT max(business_date) FROM audit_days WHERE hotel_id = h AND status = 'closed'
$$;

ALTER TABLE payments ADD COLUMN business_date date;
ALTER TABLE refunds ADD COLUMN business_date date;
ALTER TABLE incomes ADD COLUMN business_date date;
ALTER TABLE expenses ADD COLUMN business_date date;
ALTER TABLE invoices ADD COLUMN business_date date;
ALTER TABLE cash_movements ADD COLUMN business_date date;
ALTER TABLE rs_orders ADD COLUMN business_date date;
ALTER TABLE charges ADD COLUMN business_date date;

-- reprise de l'historique : date locale de l'opération
ALTER TABLE refunds DISABLE TRIGGER refunds_immutable;
ALTER TABLE cash_movements DISABLE TRIGGER cash_movements_immutable;
ALTER TABLE payments DISABLE TRIGGER payments_guard;
ALTER TABLE expenses DISABLE TRIGGER expenses_guard;
ALTER TABLE incomes DISABLE TRIGGER incomes_guard;
ALTER TABLE invoices DISABLE TRIGGER invoices_guard;
UPDATE payments x SET business_date = (x.received_at AT TIME ZONE h.timezone)::date FROM hotels h WHERE h.id = x.hotel_id;
UPDATE incomes x SET business_date = (x.created_at AT TIME ZONE h.timezone)::date FROM hotels h WHERE h.id = x.hotel_id;
UPDATE expenses x SET business_date = (x.created_at AT TIME ZONE h.timezone)::date FROM hotels h WHERE h.id = x.hotel_id;
UPDATE invoices x SET business_date = (x.issued_at AT TIME ZONE h.timezone)::date FROM hotels h WHERE h.id = x.hotel_id;
UPDATE rs_orders x SET business_date = (x.created_at AT TIME ZONE h.timezone)::date FROM hotels h WHERE h.id = x.hotel_id;
UPDATE refunds x SET business_date = (x.created_at AT TIME ZONE 'Africa/Algiers')::date;
UPDATE cash_movements x SET business_date = (x.created_at AT TIME ZONE 'Africa/Algiers')::date;
UPDATE charges x SET business_date = x.service_date;
ALTER TABLE refunds ENABLE TRIGGER refunds_immutable;
ALTER TABLE cash_movements ENABLE TRIGGER cash_movements_immutable;
ALTER TABLE payments ENABLE TRIGGER payments_guard;
ALTER TABLE expenses ENABLE TRIGGER expenses_guard;
ALTER TABLE incomes ENABLE TRIGGER incomes_guard;
ALTER TABLE invoices ENABLE TRIGGER invoices_guard;
CREATE INDEX payments_bdate ON payments (hotel_id, business_date);
CREATE INDEX invoices_bdate ON invoices (hotel_id, business_date);
CREATE INDEX rs_orders_bdate ON rs_orders (hotel_id, business_date);
CREATE INDEX expenses_bdate ON expenses (hotel_id, business_date);

-- Hôtel d'une ligne, quelle que soit la table.
CREATE FUNCTION kh_row_hotel(t text, r jsonb) RETURNS int LANGUAGE plpgsql STABLE AS $$
DECLARE h int;
BEGIN
  IF r ? 'hotel_id' AND r->>'hotel_id' IS NOT NULL THEN RETURN (r->>'hotel_id')::int; END IF;
  IF t = 'refunds' THEN
    SELECT COALESCE((SELECT hotel_id FROM reservations WHERE id = (r->>'reservation_id')::int), (SELECT hotel_id FROM invoices WHERE id = (r->>'invoice_id')::int),
                    (SELECT hotel_id FROM payments WHERE id = (r->>'payment_id')::int)) INTO h;
  ELSIF t = 'charges' THEN SELECT hotel_id INTO h FROM reservations WHERE id = (r->>'reservation_id')::int;
  ELSIF t = 'cash_movements' THEN SELECT cr.hotel_id INTO h FROM cash_sessions s JOIN cash_registers cr ON cr.id = s.cash_register_id WHERE s.id = (r->>'session_id')::int;
  END IF;
  RETURN h;
END $$;

-- À l'insertion : date opérationnelle courante ; refus d'une date choisie appartenant à une journée clôturée.
CREATE FUNCTION kh_stamp_business_date() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE h int; closed date; d date; j jsonb;
BEGIN
  j := to_jsonb(NEW);
  h := kh_row_hotel(TG_TABLE_NAME, j);
  IF h IS NULL THEN RETURN NEW; END IF;
  closed := kh_last_closed(h);
  IF NEW.business_date IS NULL THEN NEW.business_date := kh_business_date(h); END IF;
  -- prestation tardive datée d'une journée clôturée : portée sur la journée en cours (usage hôtelier), la date d'origine est conservée dans le libellé
  IF TG_TABLE_NAME = 'charges' AND closed IS NOT NULL THEN
    IF (j->>'service_date')::date <= closed AND NEW.business_date > closed THEN
      NEW := jsonb_populate_record(NEW, jsonb_build_object('service_date', NEW.business_date,
        'description', (j->>'description') || ' (prestation du ' || to_char((j->>'service_date')::date, 'DD/MM/YYYY') || ')'));
    END IF;
  END IF;
  d := CASE TG_TABLE_NAME WHEN 'expenses' THEN (j->>'expense_date')::date WHEN 'incomes' THEN (j->>'income_date')::date ELSE NULL END;
  IF closed IS NOT NULL AND (NEW.business_date <= closed OR (d IS NOT NULL AND d <= closed)) THEN
    RAISE EXCEPTION 'La journée du % est clôturée (night audit) : enregistrez l''opération sur la journée en cours.', to_char(GREATEST(NEW.business_date, COALESCE(d, NEW.business_date)), 'DD/MM/YYYY') USING ERRCODE = 'KH409';
  END IF;
  RETURN NEW;
END $$;

-- Après clôture : montants, dates et annulations des opérations de la journée verrouillés (correction par une opération du jour).
CREATE FUNCTION kh_lock_closed_day() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE h int; closed date; changed boolean := false; o jsonb; n jsonb; k text;
  watched text[];
BEGIN
  o := to_jsonb(OLD);
  h := kh_row_hotel(TG_TABLE_NAME, o);
  closed := kh_last_closed(h);
  IF closed IS NULL OR OLD.business_date IS NULL OR OLD.business_date > closed THEN
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF; RETURN NEW;
  END IF;
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Journée du % clôturée : suppression impossible.', to_char(OLD.business_date, 'DD/MM/YYYY') USING ERRCODE = 'KH409';
  END IF;
  n := to_jsonb(NEW);
  watched := CASE TG_TABLE_NAME
    WHEN 'payments' THEN ARRAY['amount','method','void','received_at','business_date']
    WHEN 'incomes' THEN ARRAY['amount','method','void','income_date','business_date']
    WHEN 'expenses' THEN ARRAY['amount','method','void','expense_date','business_date']
    WHEN 'invoices' THEN ARRAY['total','subtotal','tax_total','discount_total','issued_at','type','business_date']
    WHEN 'charges' THEN ARRAY['total','quantity','unit_price','void','service_date','business_date']
    WHEN 'rs_orders' THEN ARRAY['business_date']
    ELSE ARRAY['business_date'] END;
  -- une commande d'une journée clôturée peut encore être servie / réglée, mais pas annulée
  IF TG_TABLE_NAME = 'rs_orders' AND (n->>'status') = 'cancelled' AND (o->>'status') <> 'cancelled' THEN changed := true; END IF;
  FOREACH k IN ARRAY watched LOOP
    IF (o->k) IS DISTINCT FROM (n->k) THEN changed := true; END IF;
  END LOOP;
  IF changed THEN
    RAISE EXCEPTION 'Journée du % clôturée (night audit) : modification impossible. Faites une correction datée du jour (remboursement, avoir, ajustement) ou demandez une réouverture.', to_char(OLD.business_date, 'DD/MM/YYYY') USING ERRCODE = 'KH409';
  END IF;
  RETURN NEW;
END $$;

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['payments','refunds','incomes','expenses','invoices','cash_movements','rs_orders','charges'] LOOP
    EXECUTE format('CREATE TRIGGER %I BEFORE INSERT ON %I FOR EACH ROW EXECUTE FUNCTION kh_stamp_business_date()', t || '_bdate_stamp', t);
    EXECUTE format('CREATE TRIGGER %I BEFORE UPDATE OR DELETE ON %I FOR EACH ROW EXECUTE FUNCTION kh_lock_closed_day()', t || '_closed_lock', t);
  END LOOP;
END $$;

-- Note : pour les tables déjà immuables (remboursements, mouvements de caisse), le verrou s'ajoute à la protection existante.
