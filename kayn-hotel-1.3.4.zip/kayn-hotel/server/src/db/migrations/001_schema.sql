-- KAYN Hotel — schéma initial
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- ============ Hôtel & paramètres ============
CREATE TABLE hotels (
  id            serial PRIMARY KEY,
  name          text NOT NULL,
  address       text,
  city          text,
  phone         text,
  email         text,
  nif           text,
  nis           text,
  rc            text,
  art           text,
  currency      text NOT NULL DEFAULT 'DZD',
  timezone      text NOT NULL DEFAULT 'Africa/Algiers',
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE settings (
  hotel_id   int NOT NULL REFERENCES hotels(id) ON DELETE CASCADE,
  key        text NOT NULL,
  value      jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (hotel_id, key)
);

CREATE TABLE counters (
  key   text PRIMARY KEY,
  value bigint NOT NULL DEFAULT 0
);

-- ============ Sécurité ============
CREATE TABLE roles (
  id    serial PRIMARY KEY,
  code  text NOT NULL UNIQUE,
  name  text NOT NULL
);

CREATE TABLE permissions (
  id          serial PRIMARY KEY,
  code        text NOT NULL UNIQUE,
  description text NOT NULL
);

CREATE TABLE role_permissions (
  role_id       int NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id int NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE employees (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  first_name  text NOT NULL,
  last_name   text NOT NULL,
  position    text,
  department  text,
  phone       text,
  email       text,
  hire_date   date,
  active      boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id             serial PRIMARY KEY,
  hotel_id       int NOT NULL REFERENCES hotels(id),
  employee_id    int REFERENCES employees(id),
  username       text NOT NULL UNIQUE,
  full_name      text NOT NULL,
  password_hash  text NOT NULL,
  role_id        int NOT NULL REFERENCES roles(id),
  language       text NOT NULL DEFAULT 'fr' CHECK (language IN ('fr','ar','en')),
  active         boolean NOT NULL DEFAULT true,
  must_change_password boolean NOT NULL DEFAULT false,
  failed_logins  int NOT NULL DEFAULT 0,
  locked_until   timestamptz,
  last_login_at  timestamptz,
  created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE devices (
  id           serial PRIMARY KEY,
  hotel_id     int NOT NULL REFERENCES hotels(id),
  name         text NOT NULL,
  fingerprint  text NOT NULL UNIQUE,
  status       text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','revoked')),
  approved_by  int REFERENCES users(id),
  approved_at  timestamptz,
  last_seen_at timestamptz,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sessions (
  id          text PRIMARY KEY,           -- SHA-256 du jeton (le jeton brut n'est jamais stocké)
  user_id     int NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_id   int REFERENCES devices(id),
  ip          text,
  user_agent  text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  expires_at  timestamptz NOT NULL,
  revoked     boolean NOT NULL DEFAULT false
);
CREATE INDEX sessions_user_idx ON sessions(user_id);

-- ============ Chambres ============
CREATE TABLE floors (
  id        serial PRIMARY KEY,
  hotel_id  int NOT NULL REFERENCES hotels(id),
  number    int NOT NULL,
  name      text NOT NULL,
  UNIQUE (hotel_id, number)
);

CREATE TABLE room_types (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  code        text NOT NULL,
  name        text NOT NULL,
  category    text NOT NULL DEFAULT 'Standard',
  capacity    int NOT NULL DEFAULT 2 CHECK (capacity > 0),
  beds        int NOT NULL DEFAULT 1 CHECK (beds > 0),
  base_rate   numeric(12,2) NOT NULL CHECK (base_rate >= 0),
  color       text,
  description text,
  active      boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, code)
);

CREATE TABLE rooms (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  floor_id        int NOT NULL REFERENCES floors(id),
  room_type_id    int NOT NULL REFERENCES room_types(id),
  number          text NOT NULL,
  hk_status       text NOT NULL DEFAULT 'clean' CHECK (hk_status IN ('clean','dirty','cleaning','inspected')),
  out_of_service  boolean NOT NULL DEFAULT false,
  oos_reason      text,
  equipments      jsonb NOT NULL DEFAULT '[]',
  photos          jsonb NOT NULL DEFAULT '[]',
  notes           text,
  sort_order      int NOT NULL DEFAULT 0,
  active          boolean NOT NULL DEFAULT true,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (hotel_id, number)
);

-- ============ Clients ============
CREATE TABLE guests (
  id             serial PRIMARY KEY,
  hotel_id       int NOT NULL REFERENCES hotels(id),
  kind           text NOT NULL DEFAULT 'person' CHECK (kind IN ('person','company','agency')),
  last_name      text,
  first_name     text,
  company_name   text,
  gender         text CHECK (gender IN ('M','F')),
  birth_date     date,
  birth_place    text,
  nationality    text,
  father_name    text,
  mother_name    text,
  id_doc_type    text CHECK (id_doc_type IN ('cni','passport','permis','other')),
  id_doc_number  text,
  id_doc_expiry  date,
  profession     text,
  address        text,
  city           text,
  country        text,
  phone          text,
  email          text,
  nif            text,
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  CHECK (kind <> 'person' OR last_name IS NOT NULL),
  CHECK (kind = 'person' OR company_name IS NOT NULL)
);
CREATE INDEX guests_name_idx ON guests (lower(coalesce(last_name,'') || ' ' || coalesce(first_name,'') || ' ' || coalesce(company_name,'')));

-- ============ Réservations ============
CREATE TABLE reservations (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  code             text NOT NULL UNIQUE,
  guest_id         int NOT NULL REFERENCES guests(id),
  payer_guest_id   int REFERENCES guests(id),          -- société / agence qui paie
  booker_type      text NOT NULL DEFAULT 'individual' CHECK (booker_type IN ('individual','group','company','agency')),
  group_name       text,
  source           text NOT NULL DEFAULT 'phone' CHECK (source IN ('walk_in','phone','email','company','agency','website','other')),
  status           text NOT NULL DEFAULT 'confirmed' CHECK (status IN ('pending','confirmed','checked_in','checked_out','cancelled','no_show')),
  check_in         date NOT NULL,
  check_out        date NOT NULL,
  adults           int NOT NULL DEFAULT 1 CHECK (adults >= 0),
  children         int NOT NULL DEFAULT 0 CHECK (children >= 0),
  meal_plan        text NOT NULL DEFAULT 'RO' CHECK (meal_plan IN ('RO','BB','HB','FB')),
  total_amount     numeric(12,2) NOT NULL DEFAULT 0,
  deposit_required numeric(12,2) NOT NULL DEFAULT 0,
  notes            text,
  cancel_reason    text,
  created_by       int REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  CHECK (check_out > check_in)
);
CREATE INDEX reservations_dates_idx ON reservations (check_in, check_out);

CREATE TABLE reservation_rooms (
  id              serial PRIMARY KEY,
  reservation_id  int NOT NULL REFERENCES reservations(id) ON DELETE CASCADE,
  room_id         int NOT NULL REFERENCES rooms(id),
  room_type_id    int NOT NULL REFERENCES room_types(id),
  check_in        date NOT NULL,
  check_out       date NOT NULL,
  rate            numeric(12,2) NOT NULL CHECK (rate >= 0),     -- prix par nuit
  adults          int NOT NULL DEFAULT 1,
  children        int NOT NULL DEFAULT 0,
  status          text NOT NULL DEFAULT 'confirmed' CHECK (status IN ('pending','confirmed','checked_in','checked_out','cancelled','no_show')),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  CHECK (check_out > check_in),
  -- Interdiction absolue des doubles réservations sur une même chambre
  CONSTRAINT no_double_booking EXCLUDE USING gist (
    room_id WITH =,
    daterange(check_in, check_out, '[)') WITH &&
  ) WHERE (status IN ('pending','confirmed','checked_in','checked_out'))
);
CREATE INDEX rr_dates_idx ON reservation_rooms (check_in, check_out);

CREATE TABLE stays (
  id                   serial PRIMARY KEY,
  reservation_room_id  int NOT NULL UNIQUE REFERENCES reservation_rooms(id),
  room_id              int NOT NULL REFERENCES rooms(id),
  guest_id             int NOT NULL REFERENCES guests(id),
  checked_in_at        timestamptz NOT NULL DEFAULT now(),
  checked_out_at       timestamptz
);

CREATE TABLE stay_guests (
  stay_id   int NOT NULL REFERENCES stays(id) ON DELETE CASCADE,
  guest_id  int NOT NULL REFERENCES guests(id),
  PRIMARY KEY (stay_id, guest_id)
);

CREATE TABLE check_ins (
  id          serial PRIMARY KEY,
  stay_id     int NOT NULL REFERENCES stays(id),
  done_by     int REFERENCES users(id),
  done_at     timestamptz NOT NULL DEFAULT now(),
  id_scanned  boolean NOT NULL DEFAULT false,
  notes       text
);

CREATE TABLE check_outs (
  id          serial PRIMARY KEY,
  stay_id     int NOT NULL REFERENCES stays(id),
  invoice_id  int,
  done_by     int REFERENCES users(id),
  done_at     timestamptz NOT NULL DEFAULT now(),
  balance     numeric(12,2) NOT NULL DEFAULT 0,
  notes       text
);

CREATE TABLE guest_requests (
  id              serial PRIMARY KEY,
  reservation_id  int NOT NULL REFERENCES reservations(id),
  room_id         int REFERENCES rooms(id),
  request         text NOT NULL,
  status          text NOT NULL DEFAULT 'open' CHECK (status IN ('open','done','cancelled')),
  created_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  done_at         timestamptz
);

-- ============ Finances ============
CREATE TABLE cash_registers (
  id        serial PRIMARY KEY,
  hotel_id  int NOT NULL REFERENCES hotels(id),
  name      text NOT NULL,
  active    boolean NOT NULL DEFAULT true
);

CREATE TABLE cash_sessions (
  id                 serial PRIMARY KEY,
  cash_register_id   int NOT NULL REFERENCES cash_registers(id),
  status             text NOT NULL DEFAULT 'open' CHECK (status IN ('open','closed')),
  opened_by          int NOT NULL REFERENCES users(id),
  opened_at          timestamptz NOT NULL DEFAULT now(),
  opening_amount     numeric(12,2) NOT NULL DEFAULT 0,
  closed_by          int REFERENCES users(id),
  closed_at          timestamptz,
  expected_amount    numeric(12,2),
  declared_amount    numeric(12,2),
  notes              text
);
CREATE UNIQUE INDEX one_open_session_per_register ON cash_sessions(cash_register_id) WHERE status = 'open';

CREATE TABLE charges (
  id              serial PRIMARY KEY,
  reservation_id  int NOT NULL REFERENCES reservations(id),
  reservation_room_id int REFERENCES reservation_rooms(id),
  service_date    date NOT NULL,
  kind            text NOT NULL CHECK (kind IN ('service','restaurant','minibar','laundry','transfer','parking','other')),
  description     text NOT NULL,
  quantity        numeric(10,2) NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit_price      numeric(12,2) NOT NULL CHECK (unit_price >= 0),
  total           numeric(12,2) NOT NULL,
  void            boolean NOT NULL DEFAULT false,
  void_reason     text,
  created_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE invoices (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  number          text NOT NULL UNIQUE,
  reservation_id  int REFERENCES reservations(id),
  guest_id        int NOT NULL REFERENCES guests(id),
  kind            text NOT NULL DEFAULT 'stay' CHECK (kind IN ('stay','service','group','proforma','credit_note')),
  status          text NOT NULL DEFAULT 'issued' CHECK (status IN ('issued','paid','partially_paid','cancelled')),
  issued_at       timestamptz NOT NULL DEFAULT now(),
  subtotal        numeric(12,2) NOT NULL DEFAULT 0,
  tax_total       numeric(12,2) NOT NULL DEFAULT 0,
  total           numeric(12,2) NOT NULL DEFAULT 0,
  created_by      int REFERENCES users(id)
);
ALTER TABLE check_outs ADD CONSTRAINT check_outs_invoice_fk FOREIGN KEY (invoice_id) REFERENCES invoices(id);

CREATE TABLE invoice_items (
  id            serial PRIMARY KEY,
  invoice_id    int NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  kind          text NOT NULL,
  description   text NOT NULL,
  service_date  date,
  quantity      numeric(10,2) NOT NULL DEFAULT 1,
  unit_price    numeric(12,2) NOT NULL,
  tax_rate      numeric(5,2) NOT NULL DEFAULT 0,
  total         numeric(12,2) NOT NULL
);

CREATE TABLE payments (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  reservation_id   int REFERENCES reservations(id),
  invoice_id       int REFERENCES invoices(id),
  guest_id         int REFERENCES guests(id),
  kind             text NOT NULL DEFAULT 'payment' CHECK (kind IN ('deposit','payment')),
  method           text NOT NULL CHECK (method IN ('cash','card','cheque','transfer','company_account')),
  amount           numeric(12,2) NOT NULL CHECK (amount > 0),
  reference        text,
  cash_session_id  int REFERENCES cash_sessions(id),
  received_by      int REFERENCES users(id),
  received_at      timestamptz NOT NULL DEFAULT now(),
  void             boolean NOT NULL DEFAULT false,
  void_reason      text,
  voided_by        int REFERENCES users(id),
  voided_at        timestamptz
);
CREATE INDEX payments_date_idx ON payments(received_at);

CREATE TABLE refunds (
  id               serial PRIMARY KEY,
  payment_id       int REFERENCES payments(id),
  reservation_id   int REFERENCES reservations(id),
  amount           numeric(12,2) NOT NULL CHECK (amount > 0),
  method           text NOT NULL CHECK (method IN ('cash','card','cheque','transfer')),
  reason           text NOT NULL,
  cash_session_id  int REFERENCES cash_sessions(id),
  created_by       int REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE suppliers (
  id        serial PRIMARY KEY,
  hotel_id  int NOT NULL REFERENCES hotels(id),
  name      text NOT NULL,
  phone     text,
  email     text,
  address   text,
  nif       text,
  active    boolean NOT NULL DEFAULT true
);

CREATE TABLE expenses (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  category         text NOT NULL,
  description      text NOT NULL,
  amount           numeric(12,2) NOT NULL CHECK (amount > 0),
  method           text NOT NULL CHECK (method IN ('cash','card','cheque','transfer')),
  supplier_id      int REFERENCES suppliers(id),
  cash_session_id  int REFERENCES cash_sessions(id),
  expense_date     date NOT NULL,
  created_by       int REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now()
);

-- ============ Opérations ============
CREATE TABLE housekeeping_tasks (
  id                   serial PRIMARY KEY,
  room_id              int NOT NULL REFERENCES rooms(id),
  reservation_room_id  int REFERENCES reservation_rooms(id),
  kind                 text NOT NULL CHECK (kind IN ('checkout_clean','stayover','inspection','deep_clean')),
  status               text NOT NULL DEFAULT 'todo' CHECK (status IN ('todo','in_progress','done','cancelled')),
  assigned_to          int REFERENCES employees(id),
  notes                text,
  created_by           int REFERENCES users(id),
  created_at           timestamptz NOT NULL DEFAULT now(),
  started_at           timestamptz,
  completed_at         timestamptz,
  completed_by         int REFERENCES users(id)
);

CREATE TABLE maintenance_tickets (
  id                  serial PRIMARY KEY,
  room_id             int REFERENCES rooms(id),
  title               text NOT NULL,
  description         text,
  priority            text NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  status              text NOT NULL DEFAULT 'open' CHECK (status IN ('open','in_progress','resolved','cancelled')),
  puts_out_of_service boolean NOT NULL DEFAULT false,
  reported_by         int REFERENCES users(id),
  created_at          timestamptz NOT NULL DEFAULT now(),
  resolved_at         timestamptz,
  resolved_by         int REFERENCES users(id)
);

CREATE TABLE products (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  name        text NOT NULL,
  category    text NOT NULL,
  unit        text NOT NULL DEFAULT 'unité',
  sale_price  numeric(12,2) NOT NULL DEFAULT 0,
  cost_price  numeric(12,2) NOT NULL DEFAULT 0,
  stock_qty   numeric(12,2) NOT NULL DEFAULT 0,
  min_stock   numeric(12,2) NOT NULL DEFAULT 0,
  active      boolean NOT NULL DEFAULT true
);

CREATE TABLE stock_movements (
  id           serial PRIMARY KEY,
  product_id   int NOT NULL REFERENCES products(id),
  kind         text NOT NULL CHECK (kind IN ('in','out','adjust')),
  quantity     numeric(12,2) NOT NULL,
  reason       text,
  supplier_id  int REFERENCES suppliers(id),
  created_by   int REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE restaurant_orders (
  id              serial PRIMARY KEY,
  hotel_id        int NOT NULL REFERENCES hotels(id),
  reservation_id  int REFERENCES reservations(id),
  room_id         int REFERENCES rooms(id),
  table_label     text,
  status          text NOT NULL DEFAULT 'open' CHECK (status IN ('open','served','charged','paid','cancelled')),
  total           numeric(12,2) NOT NULL DEFAULT 0,
  created_by      int REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE restaurant_order_items (
  id          serial PRIMARY KEY,
  order_id    int NOT NULL REFERENCES restaurant_orders(id) ON DELETE CASCADE,
  product_id  int REFERENCES products(id),
  description text NOT NULL,
  quantity    numeric(10,2) NOT NULL CHECK (quantity > 0),
  unit_price  numeric(12,2) NOT NULL,
  total       numeric(12,2) NOT NULL
);

-- ============ Traçabilité ============
CREATE TABLE audit_logs (
  id          bigserial PRIMARY KEY,
  hotel_id    int,
  user_id     int REFERENCES users(id),
  device_id   int REFERENCES devices(id),
  action      text NOT NULL,
  entity      text NOT NULL,
  entity_id   text,
  before      jsonb,
  after       jsonb,
  ip          text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_entity_idx ON audit_logs(entity, entity_id);

-- Le journal d'audit est en ajout seul
CREATE FUNCTION forbid_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'Opération interdite sur % : les données financières et le journal sont non modifiables', TG_TABLE_NAME;
END $$;

CREATE TRIGGER audit_logs_immutable BEFORE UPDATE OR DELETE ON audit_logs FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER refunds_immutable BEFORE UPDATE OR DELETE ON refunds FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER expenses_immutable BEFORE UPDATE OR DELETE ON expenses FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER invoice_items_immutable BEFORE UPDATE OR DELETE ON invoice_items FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Paiements : seule l'annulation tracée est autorisée
CREATE FUNCTION payments_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Suppression d''un paiement interdite : utilisez l''annulation';
  END IF;
  IF OLD.void THEN
    RAISE EXCEPTION 'Paiement déjà annulé : modification interdite';
  END IF;
  IF NEW.amount <> OLD.amount OR NEW.method <> OLD.method OR NEW.received_at <> OLD.received_at
     OR NEW.reservation_id IS DISTINCT FROM OLD.reservation_id OR NEW.received_by IS DISTINCT FROM OLD.received_by
     OR NEW.cash_session_id IS DISTINCT FROM OLD.cash_session_id THEN
    RAISE EXCEPTION 'Modification d''un paiement interdite : seule l''annulation est permise';
  END IF;
  IF NEW.void AND (NEW.void_reason IS NULL OR NEW.voided_by IS NULL) THEN
    RAISE EXCEPTION 'Annulation de paiement : motif et utilisateur obligatoires';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER payments_guard BEFORE UPDATE OR DELETE ON payments FOR EACH ROW EXECUTE FUNCTION payments_guard();

-- Factures : seul le statut peut évoluer
CREATE FUNCTION invoices_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Suppression d''une facture interdite : émettez un avoir';
  END IF;
  IF NEW.number <> OLD.number OR NEW.total <> OLD.total OR NEW.subtotal <> OLD.subtotal OR NEW.tax_total <> OLD.tax_total
     OR NEW.guest_id <> OLD.guest_id OR NEW.issued_at <> OLD.issued_at THEN
    RAISE EXCEPTION 'Modification d''une facture émise interdite';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER invoices_guard BEFORE UPDATE OR DELETE ON invoices FOR EACH ROW EXECUTE FUNCTION invoices_guard();
