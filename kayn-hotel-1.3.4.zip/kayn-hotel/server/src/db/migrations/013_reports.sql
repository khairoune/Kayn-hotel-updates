-- Phase 12 : Rapports & statistiques — uniquement la personnalisation (vues, filtres et rapports enregistrés).
-- Les chiffres sont calculés à la volée depuis les tables des modules : aucune table de données parallèle.
CREATE TABLE IF NOT EXISTS report_views (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  user_id     int REFERENCES users(id) ON DELETE CASCADE,
  role_code   text,
  kind        text NOT NULL CHECK (kind IN ('layout','filter','report')),
  domain      text NOT NULL,
  name        text NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 80),
  config      jsonb NOT NULL DEFAULT '{}',
  is_default  boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  CHECK (user_id IS NOT NULL OR role_code IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS report_views_user ON report_views (hotel_id, user_id, kind);
CREATE INDEX IF NOT EXISTS report_views_role ON report_views (hotel_id, role_code, kind);
-- une seule vue par défaut par utilisateur (ou par rôle) et par module
CREATE UNIQUE INDEX IF NOT EXISTS report_views_default_user ON report_views (hotel_id, user_id, domain) WHERE is_default AND user_id IS NOT NULL AND kind = 'layout';
CREATE UNIQUE INDEX IF NOT EXISTS report_views_default_role ON report_views (hotel_id, role_code, domain) WHERE is_default AND role_code IS NOT NULL AND kind = 'layout';

-- Index utiles aux agrégations
CREATE INDEX IF NOT EXISTS rr_dates_idx ON reservation_rooms (check_in, check_out);
CREATE INDEX IF NOT EXISTS res_created_idx ON reservations (hotel_id, created_at);
CREATE INDEX IF NOT EXISTS res_checkin_idx ON reservations (hotel_id, check_in);
CREATE INDEX IF NOT EXISTS charges_date_idx ON charges (service_date);
CREATE INDEX IF NOT EXISTS payments_received_idx ON payments (hotel_id, received_at);
CREATE INDEX IF NOT EXISTS rs_orders_created_idx ON rs_orders (hotel_id, created_at);
CREATE INDEX IF NOT EXISTS hk_tasks_completed_idx ON housekeeping_tasks (completed_at);
CREATE INDEX IF NOT EXISTS stock_mv_created_idx ON stock_movements (created_at);
CREATE INDEX IF NOT EXISTS expenses_date_idx ON expenses (hotel_id, expense_date);
