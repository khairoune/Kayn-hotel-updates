-- ================= Étape 5 : Facturation & Caisse =================

-- ---------- Taxes : taux figé sur chaque prestation, exonération client ----------
ALTER TABLE charges ADD COLUMN tax_rate numeric(5,2);
UPDATE charges c SET tax_rate = r.vat_rate FROM reservations r WHERE r.id = c.reservation_id;
UPDATE charges SET tax_rate = 0 WHERE tax_rate IS NULL;
ALTER TABLE charges ALTER COLUMN tax_rate SET NOT NULL, ALTER COLUMN tax_rate SET DEFAULT 0;

-- Ajustements (avoirs commerciaux) : montant négatif autorisé uniquement pour ce type
ALTER TABLE charges DROP CONSTRAINT charges_kind_check;
ALTER TABLE charges ADD CONSTRAINT charges_kind_check
  CHECK (kind IN ('service','breakfast','restaurant','room_service','minibar','laundry','transfer','parking','cancellation_fee','no_show_fee','adjustment','other'));
ALTER TABLE charges DROP CONSTRAINT IF EXISTS charges_unit_price_check;
ALTER TABLE charges ADD CONSTRAINT charges_price_sign CHECK (unit_price >= 0 OR kind = 'adjustment');
ALTER TABLE charges ADD COLUMN source_charge_id int REFERENCES charges(id);   -- transfert : prestation d'origine
ALTER TABLE charges ADD COLUMN invoice_ref text;                              -- avoir : n° de l'avoir

ALTER TABLE guests
  ADD COLUMN tax_exempt         boolean NOT NULL DEFAULT false,
  ADD COLUMN tax_exempt_reason  text;

-- ---------- Factures : type, destinataire figé, détail des taxes, avoirs ----------
ALTER TABLE invoices DROP CONSTRAINT invoices_status_check;
ALTER TABLE invoices ADD CONSTRAINT invoices_status_check CHECK (status IN ('proforma','issued','paid','partially_paid','credited','cancelled'));
ALTER TABLE invoices
  ADD COLUMN type               text NOT NULL DEFAULT 'invoice' CHECK (type IN ('invoice','proforma','credit_note')),
  ADD COLUMN credit_of_invoice_id int REFERENCES invoices(id),
  ADD COLUMN credit_mode        text CHECK (credit_mode IN ('commercial','cancel_reissue')),
  ADD COLUMN reason             text,
  ADD COLUMN bill_to            jsonb,               -- nom, adresse, NIF… au moment de l'émission
  ADD COLUMN seller             jsonb,               -- identité fiscale de l'hôtel au moment de l'émission
  ADD COLUMN discount_total     numeric(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN tourist_tax_total  numeric(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN tax_breakdown      jsonb NOT NULL DEFAULT '[]',   -- [{rate, base, tax}]
  ADD COLUMN currency           text NOT NULL DEFAULT 'DZD',
  ADD COLUMN due_date           date,
  ADD COLUMN notes              text;
CREATE INDEX invoices_date_idx ON invoices (issued_at);
CREATE INDEX invoices_res_idx ON invoices (reservation_id);

ALTER TABLE invoice_items
  ADD COLUMN tax_amount  numeric(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN discount    numeric(12,2) NOT NULL DEFAULT 0,      -- remise de ligne (montant)
  ADD COLUMN category    text;

-- Les champs financiers d'une facture émise restent figés ; seul le statut évolue
CREATE OR REPLACE FUNCTION invoices_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Suppression d''une facture interdite : émettez un avoir';
  END IF;
  IF NEW.number <> OLD.number OR NEW.total <> OLD.total OR NEW.subtotal <> OLD.subtotal OR NEW.tax_total <> OLD.tax_total
     OR NEW.guest_id <> OLD.guest_id OR NEW.issued_at <> OLD.issued_at OR NEW.type <> OLD.type
     OR NEW.bill_to IS DISTINCT FROM OLD.bill_to OR NEW.tax_breakdown IS DISTINCT FROM OLD.tax_breakdown
     OR NEW.discount_total <> OLD.discount_total OR NEW.tourist_tax_total <> OLD.tourist_tax_total THEN
    RAISE EXCEPTION 'Modification d''une facture émise interdite : émettez un avoir';
  END IF;
  RETURN NEW;
END $$;

-- ---------- Paiements : en ligne, carte (4 derniers chiffres seulement) ----------
ALTER TABLE payments DROP CONSTRAINT payments_method_check;
ALTER TABLE payments ADD CONSTRAINT payments_method_check CHECK (method IN ('cash','card','cheque','transfer','company_account','online'));
ALTER TABLE payments
  ADD COLUMN card_last4  text CHECK (card_last4 IS NULL OR card_last4 ~ '^[0-9]{4}$'),
  ADD COLUMN card_brand  text;
ALTER TABLE refunds DROP CONSTRAINT refunds_method_check;
ALTER TABLE refunds ADD CONSTRAINT refunds_method_check CHECK (method IN ('cash','card','cheque','transfer','online'));
ALTER TABLE refunds ADD COLUMN invoice_id int REFERENCES invoices(id);

-- ---------- Caisse ----------
ALTER TABLE cash_sessions
  ADD COLUMN difference      numeric(12,2),
  ADD COLUMN justification   text,
  ADD COLUMN validated_by    int REFERENCES users(id),
  ADD COLUMN validated_at    timestamptz,
  ADD COLUMN validation_note text;
-- une seule session ouverte par caisse
CREATE UNIQUE INDEX cash_sessions_one_open ON cash_sessions (cash_register_id) WHERE status = 'open';

CREATE TABLE cash_movements (
  id           serial PRIMARY KEY,
  session_id   int NOT NULL REFERENCES cash_sessions(id),
  direction    text NOT NULL CHECK (direction IN ('in','out')),
  category     text NOT NULL CHECK (category IN ('float','bank_deposit','change','withdrawal','other')),
  amount       numeric(12,2) NOT NULL CHECK (amount > 0),
  description  text NOT NULL,
  reference    text,
  created_by   int REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER cash_movements_immutable BEFORE UPDATE OR DELETE ON cash_movements FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ---------- Dépenses : annulation tracée (plus de modification ni suppression) ----------
DROP TRIGGER expenses_immutable ON expenses;
ALTER TABLE expenses
  ADD COLUMN reference    text,
  ADD COLUMN void         boolean NOT NULL DEFAULT false,
  ADD COLUMN void_reason  text,
  ADD COLUMN voided_by    int REFERENCES users(id),
  ADD COLUMN voided_at    timestamptz;
CREATE FUNCTION finance_void_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'Suppression interdite : utilisez l''annulation'; END IF;
  IF OLD.void THEN RAISE EXCEPTION 'Opération déjà annulée'; END IF;
  IF NEW.amount <> OLD.amount OR NEW.method <> OLD.method OR NEW.cash_session_id IS DISTINCT FROM OLD.cash_session_id THEN
    RAISE EXCEPTION 'Modification interdite : seule l''annulation est permise';
  END IF;
  IF NEW.void AND (NEW.void_reason IS NULL OR NEW.voided_by IS NULL) THEN RAISE EXCEPTION 'Annulation : motif obligatoire'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER expenses_guard BEFORE UPDATE OR DELETE ON expenses FOR EACH ROW EXECUTE FUNCTION finance_void_guard();

-- ---------- Recettes diverses (hors séjours : location de salle, vente comptoir…) ----------
CREATE TABLE incomes (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  category         text NOT NULL,
  description      text NOT NULL,
  amount           numeric(12,2) NOT NULL CHECK (amount > 0),
  method           text NOT NULL CHECK (method IN ('cash','card','cheque','transfer','online')),
  reference        text,
  cash_session_id  int REFERENCES cash_sessions(id),
  income_date      date NOT NULL,
  created_by       int REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  void             boolean NOT NULL DEFAULT false,
  void_reason      text,
  voided_by        int REFERENCES users(id),
  voided_at        timestamptz
);
CREATE TRIGGER incomes_guard BEFORE UPDATE OR DELETE ON incomes FOR EACH ROW EXECUTE FUNCTION finance_void_guard();

CREATE TABLE expense_categories (
  id        serial PRIMARY KEY,
  hotel_id  int NOT NULL REFERENCES hotels(id),
  name      text NOT NULL,
  active    boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, name)
);
