-- ================= Étape 6 : Housekeeping =================

-- ---------- Statuts de propreté des chambres ----------
-- dirty = Sale · to_clean = À nettoyer · cleaning = En cours · to_inspect = À inspecter · clean = Nettoyée · inspected = Propre et disponible
ALTER TABLE rooms DROP CONSTRAINT rooms_hk_status_check;
ALTER TABLE rooms ADD CONSTRAINT rooms_hk_status_check CHECK (hk_status IN ('dirty','to_clean','cleaning','to_inspect','clean','inspected'));
ALTER TABLE rooms
  ADD COLUMN dnd           boolean NOT NULL DEFAULT false,   -- Ne pas déranger
  ADD COLUMN dnd_set_at    timestamptz,
  ADD COLUMN dnd_set_by    int REFERENCES users(id),
  ADD COLUMN hk_updated_at timestamptz;

-- ---------- Tâches ----------
ALTER TABLE housekeeping_tasks DROP CONSTRAINT housekeeping_tasks_kind_check;
ALTER TABLE housekeeping_tasks ADD CONSTRAINT housekeeping_tasks_kind_check
  CHECK (kind IN ('checkout_clean','stayover','arrival_prep','deep_clean','inspection','turndown','other'));
ALTER TABLE housekeeping_tasks DROP CONSTRAINT housekeeping_tasks_status_check;
ALTER TABLE housekeeping_tasks ADD CONSTRAINT housekeeping_tasks_status_check
  CHECK (status IN ('todo','in_progress','done','to_inspect','validated','cancelled'));
ALTER TABLE housekeeping_tasks
  ADD COLUMN task_date      date NOT NULL DEFAULT CURRENT_DATE,
  ADD COLUMN priority       text NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  ADD COLUMN due_at         timestamptz,
  ADD COLUMN assigned_at    timestamptz,
  ADD COLUMN assigned_by    int REFERENCES users(id),
  ADD COLUMN source         text NOT NULL DEFAULT 'auto' CHECK (source IN ('auto','manual')),
  ADD COLUMN refusal_count  int NOT NULL DEFAULT 0,
  ADD COLUMN inspected_by   int REFERENCES users(id),
  ADD COLUMN inspected_at   timestamptz,
  ADD COLUMN cancel_reason  text;
CREATE INDEX hk_tasks_date_idx ON housekeeping_tasks (task_date, status);
CREATE INDEX hk_tasks_room_idx ON housekeeping_tasks (room_id, status);

CREATE TABLE hk_task_comments (
  id          serial PRIMARY KEY,
  task_id     int NOT NULL REFERENCES housekeeping_tasks(id),
  kind        text NOT NULL DEFAULT 'comment' CHECK (kind IN ('comment','issue','minibar','status')),
  text        text NOT NULL,
  ticket_id   int REFERENCES maintenance_tickets(id),
  charge_id   int REFERENCES charges(id),
  created_by  int REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- ---------- Personnel ----------
ALTER TABLE employees ADD COLUMN max_rooms int NOT NULL DEFAULT 14;   -- crédit de chambres par jour
CREATE TABLE hk_shifts (
  id           serial PRIMARY KEY,
  employee_id  int NOT NULL REFERENCES employees(id),
  work_date    date NOT NULL,
  start_time   time,
  end_time     time,
  started_at   timestamptz,          -- pointage réel
  ended_at     timestamptz,
  zone         text,                 -- ex. étages 1-2
  notes        text,
  UNIQUE (employee_id, work_date)
);

-- ---------- Inspection ----------
CREATE TABLE hk_checklist_items (
  id         serial PRIMARY KEY,
  hotel_id   int NOT NULL REFERENCES hotels(id),
  category   text NOT NULL,
  label      text NOT NULL,
  critical   boolean NOT NULL DEFAULT false,   -- un point critique non conforme = refus
  active     boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0
);
CREATE TABLE hk_inspections (
  id            serial PRIMARY KEY,
  task_id       int REFERENCES housekeeping_tasks(id),
  room_id       int NOT NULL REFERENCES rooms(id),
  inspector_id  int NOT NULL REFERENCES users(id),
  result        text NOT NULL CHECK (result IN ('passed','failed')),
  score         int,                -- % de points conformes
  items         jsonb NOT NULL DEFAULT '[]',
  remarks       text,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER hk_inspections_immutable BEFORE UPDATE OR DELETE ON hk_inspections FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- photos : inspections et objets trouvés
ALTER TABLE photos DROP CONSTRAINT photos_owner_type_check;
ALTER TABLE photos ADD CONSTRAINT photos_owner_type_check CHECK (owner_type IN ('room','room_type','inspection','lost_item'));

-- ---------- Linge ----------
CREATE TABLE linen_items (
  id          serial PRIMARY KEY,
  hotel_id    int NOT NULL REFERENCES hotels(id),
  code        text NOT NULL,
  name        text NOT NULL,
  category    text NOT NULL DEFAULT 'lit',
  par_level   int NOT NULL DEFAULT 0,          -- stock propre minimum
  qty_clean   int NOT NULL DEFAULT 0 CHECK (qty_clean >= 0),
  qty_in_use  int NOT NULL DEFAULT 0 CHECK (qty_in_use >= 0),
  qty_dirty   int NOT NULL DEFAULT 0 CHECK (qty_dirty >= 0),
  qty_laundry int NOT NULL DEFAULT 0 CHECK (qty_laundry >= 0),
  unit_cost   numeric(12,2) NOT NULL DEFAULT 0,
  active      boolean NOT NULL DEFAULT true,
  UNIQUE (hotel_id, code)
);
CREATE TABLE linen_batches (
  id           serial PRIMARY KEY,
  hotel_id     int NOT NULL REFERENCES hotels(id),
  ref          text NOT NULL,
  provider     text,
  status       text NOT NULL DEFAULT 'sent' CHECK (status IN ('sent','partial','returned')),
  sent_at      timestamptz NOT NULL DEFAULT now(),
  sent_by      int REFERENCES users(id),
  returned_at  timestamptz,
  cost         numeric(12,2),
  expense_id   int REFERENCES expenses(id),
  notes        text,
  UNIQUE (hotel_id, ref)
);
CREATE TABLE linen_movements (
  id          serial PRIMARY KEY,
  item_id     int NOT NULL REFERENCES linen_items(id),
  kind        text NOT NULL CHECK (kind IN ('purchase','issue','collect','send_laundry','return_laundry','discard','adjust')),
  quantity    int NOT NULL CHECK (quantity <> 0),
  batch_id    int REFERENCES linen_batches(id),
  room_id     int REFERENCES rooms(id),
  reason      text,
  created_by  int REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER linen_movements_immutable BEFORE UPDATE OR DELETE ON linen_movements FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ---------- Objets trouvés ----------
CREATE TABLE lost_items (
  id               serial PRIMARY KEY,
  hotel_id         int NOT NULL REFERENCES hotels(id),
  ref              text NOT NULL,
  found_at         timestamptz NOT NULL DEFAULT now(),
  room_id          int REFERENCES rooms(id),
  location         text,
  category         text NOT NULL DEFAULT 'autre',
  description      text NOT NULL,
  value_note       text,
  found_by_name    text NOT NULL,
  recorded_by      int REFERENCES users(id),
  guest_id         int REFERENCES guests(id),
  status           text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','stored','returned','archived')),
  storage_location text,
  returned_to      text,
  returned_at      timestamptz,
  returned_by      int REFERENCES users(id),
  archived_reason  text,
  notes            text,
  UNIQUE (hotel_id, ref)
);
