/**
 * Sauvegarde en ligne de commande (utilisée avant une mise à jour) : `npm run backup -- "note"`.
 * Même format et mêmes vérifications que la sauvegarde de l'écran Administration → Sauvegardes.
 */
import { closePool, getPool, one } from './pool.js';
import { createBackup, backupDir } from '../services/backup.js';

const note = process.argv.slice(2).join(' ') || 'Sauvegarde en ligne de commande';
try {
  if (!(await one(getPool(), `SELECT to_regclass('public.backups') AS t`))?.t) {
    console.error('Base trop ancienne ou vide : utilisez pg_dump manuellement (voir docs/INSTALLATION-ET-EXPLOITATION.md).');
    process.exit(2);
  }
  const h = await one<any>(getPool(), 'SELECT id FROM hotels ORDER BY id LIMIT 1');
  const b = await createBackup('manual', { id: null, name: 'Ligne de commande', hotelId: h?.id ?? null }, note);
  console.log(`✔ Sauvegarde créée et vérifiée : ${backupDir()}/${b.file_name} (${Math.round(Number(b.size_bytes) / 1024)} Ko, ${b.tables_count} tables, ${b.rows_count} lignes)`);
  await closePool();
} catch (e: any) {
  console.error(`✘ Sauvegarde impossible : ${e?.message ?? e}`);
  await closePool().catch(() => {});
  process.exit(1);
}
