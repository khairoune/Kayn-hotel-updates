import { randomBytes } from 'node:crypto';
import { mkdirSync, writeFileSync } from 'node:fs';
import { getSettings } from '../services/common.js';
/**
 * Initialisation de la base :
 *   npm run seed        → configuration de l'hôtel (rôles, permissions, admin, étages, types, chambres, caisse)
 *   npm run seed:demo   → + données de démonstration (clients, réservations, séjours, paiements)
 */
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { closePool, getPool, one, q, tx } from './pool.js';
import { runMigrations } from './migrate.js';
import { PERMISSIONS, ROLES, SENSITIVE } from '../lib/permissions.js';
import { hashPassword } from '../lib/auth.js';
import { addDays, today } from '../lib/dates.js';
import type { Actor } from '../lib/audit.js';
import { addPayment, checkIn, createReservation, markRoomDirty } from '../services/reservations.js';
import { setRoomOutOfServiceNow } from '../services/rooms.js';
import { autoAssign, generateTasks, linenMove } from '../services/housekeeping.js';
import { addLines, confirmOrder, createOrder, kitchenAction, serveOrder, settle, stockMove } from '../services/restaurant.js';
import { moveStock, stockOut, transfer } from '../services/stock.js';
import { complaintAction as crmComplaintAction, createComplaint as crmCreateComplaint, earnForStay as crmEarnForStay, enroll as crmEnroll, ensureSurvey as crmEnsureSurvey, refreshStatus as crmRefreshStatus, refreshTier as crmRefreshTier, submitSurvey as crmSubmitSurvey } from '../services/crm.js';
import { applyRotation, computePayroll, createContract, DEFAULT_DEPARTMENTS, DEFAULT_LEAVE_TYPES, DEFAULT_SHIFTS, recompute as recomputeAttendance, requestLeave, validatePayroll } from '../services/hr.js';
import { addPart, addTime, assignTicket, completeWorkOrder, declareFault, generatePreventive, validateWorkOrder, woAction } from '../services/maintenance.js';
import { approve as poApprove, createInvoice, createRequest, payInvoice as paySupplier, placeOrder, receive, saveQuote, selectQuote } from '../services/purchase.js';

/** Met à jour le catalogue des permissions et des rôles (appelé au démarrage). */
export async function syncRolesAndPermissions(c: any) {
  for (const [code, description] of Object.entries(PERMISSIONS)) {
    await c.query(`INSERT INTO permissions(code, description, sensitive) VALUES ($1,$2,$3) ON CONFLICT (code) DO UPDATE SET description = EXCLUDED.description, sensitive = EXCLUDED.sensitive`, [code, description, SENSITIVE.has(code)]);
  }
  for (const [code, r] of Object.entries(ROLES)) {
    const role = await one<any>(c, `INSERT INTO roles(code, name, builtin) VALUES ($1,$2,true) ON CONFLICT (code) DO UPDATE SET builtin = true, name = CASE WHEN roles.customized THEN roles.name ELSE EXCLUDED.name END RETURNING id, customized`, [code, r.name]);
    // un rôle modifié par l'administrateur garde ses permissions ; le super administrateur a toujours toutes les permissions
    if (role.customized && code !== 'admin') continue;
    await c.query(`DELETE FROM role_permissions WHERE role_id = $1`, [role.id]);
    await c.query(`INSERT INTO role_permissions(role_id, permission_id) SELECT $1, id FROM permissions WHERE code = ANY($2::text[])`, [role.id, r.perms]);
  }
}

export const DEFAULT_AMENITIES: [string, string, string, string][] = [
  ['ac', 'Climatisation', 'Air conditioning', 'مكيف هواء'], ['heating', 'Chauffage', 'Heating', 'تدفئة'], ['tv', 'Télévision', 'Television', 'تلفاز'],
  ['wifi', 'Wi-Fi', 'Wi-Fi', 'واي فاي'], ['minibar', 'Mini-bar', 'Minibar', 'ميني بار'], ['safe', 'Coffre-fort', 'Safe', 'خزنة'],
  ['shower', 'Douche', 'Shower', 'دش'], ['bathtub', 'Baignoire', 'Bathtub', 'حوض استحمام'], ['balcony', 'Balcon', 'Balcony', 'شرفة'],
  ['fridge', 'Réfrigérateur', 'Fridge', 'ثلاجة'], ['phone', 'Téléphone', 'Telephone', 'هاتف'], ['desk', 'Bureau', 'Desk', 'مكتب'],
  ['hairdryer', 'Sèche-cheveux', 'Hair dryer', 'مجفف شعر'],
];

/** Données de référence d'un hôtel (idempotent) : bâtiment, équipements, plans tarifaires. */
export async function ensureHotelDefaults(c: any, hotelId: number) {
  // historique des taxes : version initiale reprise des paramètres actuels (une seule fois)
  if (!(await c.query('SELECT 1 FROM tax_versions WHERE hotel_id = $1 LIMIT 1', [hotelId])).rowCount) {
    const st = await getSettings(c, hotelId);
    const init: [string, string, number][] = [['default', 'TVA par défaut', Number(st.vat_rate ?? 0)], ['tourist', 'Taxe de séjour', Number(st.tourist_tax_per_adult_night ?? 0)],
      ...Object.entries(st.tax_rates ?? {}).map(([k, v]) => [k, `TVA ${k}`, Number(v)] as [string, string, number])];
    for (const [cat, name, rate] of init) await c.query(`INSERT INTO tax_versions (hotel_id, category, name, rate, valid_from, note, applied_at) VALUES ($1,$2,$3,$4,'2000-01-01','Taux initial (paramètres)', now()) ON CONFLICT DO NOTHING`, [hotelId, cat, name, rate]);
  }
  // comptes liés à une fiche employé : département repris de la fiche RH s'il n'est pas renseigné
  await c.query(`UPDATE users u SET department_id = d.id FROM employees e JOIN hr_departments d ON d.hotel_id = e.hotel_id AND d.code = e.department
     WHERE u.employee_id = e.id AND u.department_id IS NULL AND u.hotel_id = $1`, [hotelId]).catch(() => {});
  await c.query(`INSERT INTO buildings (hotel_id, code, name) VALUES ($1,'A','Bâtiment principal') ON CONFLICT DO NOTHING`, [hotelId]);
  for (const [code, fr, en, ar] of DEFAULT_AMENITIES) {
    await c.query(`INSERT INTO amenities (hotel_id, code, name_fr, name_en, name_ar, builtin) VALUES ($1,$2,$3,$4,$5,true) ON CONFLICT DO NOTHING`, [hotelId, code, fr, en, ar]);
  }
  const plans = [['STD', 'Tarif standard', 'standard', 'none', 0, 'Prix public de la grille'], ['CORP', 'Tarif entreprise', 'corporate', 'percent', -10, 'Réduction entreprises'],
    ['AGENCY', 'Tarif agence', 'agency', 'percent', -15, 'Réduction agences de voyage'], ['GROUP', 'Tarif groupe', 'group', 'percent', -10, 'À partir de plusieurs chambres']];
  for (const [code, name, kind, at, av, d] of plans) {
    await c.query(`INSERT INTO rate_plans (hotel_id, code, name, kind, adjustment_type, adjustment_value, description) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING`, [hotelId, code, name, kind, at, av, d]);
  }
  // Catalogue de prestations (prix indicatifs, modifiables)
  const services: [string, string, string, number, string][] = [
    ['PDJ', 'Petit-déjeuner', 'breakfast', 800, 'person'], ['DEJ', 'Déjeuner', 'restaurant', 1500, 'person'], ['DIN', 'Dîner', 'restaurant', 1800, 'person'],
    ['RSV', 'Room service', 'room_service', 800, 'unit'], ['BLA', 'Blanchisserie (pièce)', 'laundry', 300, 'unit'], ['REP', 'Repassage (pièce)', 'laundry', 150, 'unit'],
    ['TRF', 'Transfert aéroport', 'transfer', 2500, 'trip'], ['PRK', 'Parking', 'parking', 300, 'day'], ['MNB', 'Mini-bar', 'minibar', 200, 'unit'],
    ['LIT', 'Lit supplémentaire', 'other', 2000, 'night'],
  ];
  for (const n of ['Achats alimentaires', 'Boissons', 'Produits d\'entretien', 'Blanchisserie externe', 'Électricité / gaz / eau', 'Maintenance', 'Fournitures', 'Salaires', 'Transport', 'Divers']) {
    await c.query(`INSERT INTO expense_categories (hotel_id, name) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [hotelId, n]);
  }
  let i = 0;
  for (const [code, name, cat, price, unit] of services) {
    await c.query(`INSERT INTO services (hotel_id, code, name, category, price, unit, sort_order) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING`, [hotelId, code, name, cat, price, unit, i++]);
  }
  // Stocks : magasin central par défaut, catégorie de dépense des achats
  if (!(await c.query('SELECT 1 FROM warehouses WHERE hotel_id = $1 LIMIT 1', [hotelId])).rowCount) {
    await c.query(`INSERT INTO warehouses (hotel_id, code, name, kind, is_default) VALUES ($1,'MAG','Magasin central','store',true)`, [hotelId]);
  }
  await c.query(`INSERT INTO expense_categories (hotel_id, name) VALUES ($1,'Achats fournisseurs') ON CONFLICT DO NOTHING`, [hotelId]);
  // RH : départements, équipes, types de congés (modifiables), catégories de dépenses de paie
  for (const [i2, [code, name]] of DEFAULT_DEPARTMENTS.entries()) {
    await c.query(`INSERT INTO hr_departments (hotel_id, code, name, builtin, sort_order) VALUES ($1,$2,$3,true,$4) ON CONFLICT DO NOTHING`, [hotelId, code, name, i2]);
  }
  for (const [code, name, st, en, brk, color] of DEFAULT_SHIFTS) {
    await c.query(`INSERT INTO hr_shift_types (hotel_id, code, name, start_time, end_time, break_minutes, color) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING`, [hotelId, code, name, st, en, brk, color]);
  }
  for (const [code, name, paid, ded, hourly, doc, just, color] of DEFAULT_LEAVE_TYPES) {
    await c.query(`INSERT INTO hr_leave_types (hotel_id, code, name, paid, deducts_balance, hourly, requires_document, justified, color, builtin) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,true) ON CONFLICT DO NOTHING`,
      [hotelId, code, name, paid, ded, hourly, doc, just, color]);
  }
  for (const n of ['Salaires', 'Avances sur salaire']) await c.query(`INSERT INTO expense_categories (hotel_id, name) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [hotelId, n]);
  // CRM : niveaux de fidélité, récompenses, modèles de messages, enquête de satisfaction (modifiables)
  if (!(await c.query('SELECT 1 FROM loyalty_tiers WHERE hotel_id = $1 LIMIT 1', [hotelId])).rowCount) {
    for (const [code, name, min, mult, disc, color, ben] of [['SILVER', 'Silver', 0, 1, 0, '#94A3B8', 'Cumul de points sur chaque séjour'], ['GOLD', 'Gold', 1500, 1.25, 5, '#C9A227', 'Points × 1,25 · 5 % de réduction membre · départ tardif selon disponibilité'],
      ['PLATINUM', 'Platinum', 5000, 1.5, 10, '#7A1F2B', 'Points × 1,5 · 10 % de réduction membre · surclassement selon disponibilité · accueil personnalisé']] as const) {
      await c.query(`INSERT INTO loyalty_tiers (hotel_id, code, name, min_points, earn_multiplier, discount_percent, color, benefits) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`, [hotelId, code, name, min, mult, disc, color, ben]);
    }
    for (const [name, kind, cost, value] of [['Réduction de 1 000 DA sur un séjour', 'discount_amount', 500, 1000], ['Réduction de 3 000 DA sur un séjour', 'discount_amount', 1400, 3000], ['Départ tardif (16 h)', 'service', 300, null],
      ['Petit-déjeuner offert pour deux', 'service', 400, null], ['Surclassement de chambre', 'upgrade', 900, null]] as const) {
      await c.query(`INSERT INTO loyalty_rewards (hotel_id, name, kind, points_cost, value) VALUES ($1,$2,$3,$4,$5)`, [hotelId, name, kind, cost, value]);
    }
  }
  const TPL: [string, string, string, string, string, string][] = [
    ['thanks', 'Remerciement après séjour', 'transactional', 'fr', 'Merci pour votre séjour, {{first_name}}', 'Bonjour {{first_name}},\n\nToute l\'équipe de {{hotel}} vous remercie pour votre séjour ({{code}}).\nVotre avis compte : {{survey_url}}\n\nÀ très bientôt,\n{{hotel}} — {{hotel_phone}}'],
    ['thanks', 'Thank you after stay', 'transactional', 'en', 'Thank you for staying with us, {{first_name}}', 'Dear {{first_name}},\n\nThe whole team at {{hotel}} thanks you for your stay ({{code}}).\nYour feedback matters: {{survey_url}}\n\nSee you soon,\n{{hotel}} — {{hotel_phone}}'],
    ['thanks', 'شكر بعد الإقامة', 'transactional', 'ar', 'شكراً على إقامتكم، {{first_name}}', 'مرحباً {{first_name}}،\n\nيشكركم فريق {{hotel}} على إقامتكم ({{code}}).\nرأيكم يهمنا: {{survey_url}}\n\nإلى اللقاء،\n{{hotel}} — {{hotel_phone}}'],
    ['pre_arrival', 'Avant l\'arrivée', 'transactional', 'fr', 'Votre arrivée le {{check_in}} — {{hotel}}', 'Bonjour {{first_name}},\n\nNous avons le plaisir de vous accueillir le {{check_in}} (réservation {{code}}).\nUne demande particulière ? Répondez simplement à ce message.\n\n{{hotel}} — {{hotel_phone}}'],
    ['pre_arrival', 'Before arrival', 'transactional', 'en', 'Your arrival on {{check_in}} — {{hotel}}', 'Dear {{first_name}},\n\nWe look forward to welcoming you on {{check_in}} (booking {{code}}).\nAny special request? Just reply to this message.\n\n{{hotel}} — {{hotel_phone}}'],
    ['birthday', 'Anniversaire', 'marketing', 'fr', 'Joyeux anniversaire, {{first_name}} !', 'Bonjour {{first_name}},\n\nToute l\'équipe de {{hotel}} vous souhaite un très joyeux anniversaire !\n\n{{unsubscribe_url}}'],
    ['promo', 'Offre promotionnelle', 'marketing', 'fr', '{{first_name}}, une offre réservée à nos clients', 'Bonjour {{first_name}},\n\nProfitez de notre offre réservée à nos fidèles clients. Votre solde : {{points}} points ({{tier}}).\nRéservez au {{hotel_phone}}.\n\n{{hotel}}\n\n{{unsubscribe_url}}'],
  ];
  for (const [code, name, purpose, lang, subject, body] of TPL) {
    await c.query(`INSERT INTO crm_templates (hotel_id, code, name, purpose, language, subject, body) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING`, [hotelId, code, name, purpose, lang, subject, body.replace(/\\n/g, '\n')]);
  }
  if (!(await c.query('SELECT 1 FROM crm_surveys WHERE hotel_id = $1 LIMIT 1', [hotelId])).rowCount) {
    await c.query(`INSERT INTO crm_surveys (hotel_id, name, trigger, questions) VALUES ($1,'Satisfaction après séjour','after_stay',$2)`, [hotelId, JSON.stringify([
      { id: 'welcome', label: 'Accueil et réception', type: 'rating' }, { id: 'room', label: 'Confort de la chambre', type: 'rating' }, { id: 'clean', label: 'Propreté', type: 'rating' },
      { id: 'food', label: 'Restauration / petit-déjeuner', type: 'rating' }, { id: 'value', label: 'Rapport qualité-prix', type: 'rating' },
      { id: 'nps', label: 'Recommanderiez-vous notre hôtel à un proche ? (0 à 10)', type: 'nps' }, { id: 'return', label: 'Reviendriez-vous chez nous ?', type: 'yesno' },
    ])]);
  }
  // Restaurant : catégories de la carte (modifiables)
  const cats: [string, string, string][] = [['Entrées', 'starter', 'kitchen'], ['Plats principaux', 'main', 'kitchen'], ['Desserts', 'dessert', 'pastry'], ['Boissons', 'drink', 'bar'], ['Petit-déjeuner', 'breakfast', 'kitchen']];
  for (const [k, [name, kind, station]] of cats.entries()) {
    await c.query('INSERT INTO rs_categories (hotel_id, name, kind, station, sort_order) VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING', [hotelId, name, kind, station, k]);
  }
  // Housekeeping : checklist d'inspection par défaut (modifiable) et articles de linge
  const hasList = await c.query('SELECT 1 FROM hk_checklist_items WHERE hotel_id = $1 LIMIT 1', [hotelId]);
  if (!hasList.rowCount) {
    const list: [string, string, boolean][] = [
      ['Chambre', 'Lit fait, draps propres et sans tache', true], ['Chambre', 'Sols aspirés / lavés', false], ['Chambre', 'Poussière (meubles, rebords, TV)', false],
      ['Chambre', 'Poubelles vidées', false], ['Chambre', 'Climatisation / éclairage / TV fonctionnent', false], ['Chambre', 'Aucun objet oublié par le client précédent', true],
      ['Salle de bain', 'Sanitaires désinfectés (WC, lavabo, douche)', true], ['Salle de bain', 'Serviettes propres en place', false], ['Salle de bain', 'Produits d\'accueil réapprovisionnés', false],
      ['Salle de bain', 'Miroirs et robinetterie sans traces', false], ['Accueil', 'Mini-bar contrôlé et complété', false], ['Accueil', 'Odeur agréable, chambre aérée', false],
    ];
    let k = 0;
    for (const [cat, label, crit] of list) await c.query('INSERT INTO hk_checklist_items (hotel_id, category, label, critical, sort_order) VALUES ($1,$2,$3,$4,$5)', [hotelId, cat, label, crit, k++]);
  }
  const linen: [string, string, string, number][] = [
    ['DRP-1', 'Drap 1 place', 'bed', 80], ['DRP-2', 'Drap 2 places', 'bed', 80], ['HSO', 'Housse de couette', 'bed', 60], ['TOI', 'Taie d\'oreiller', 'bed', 150],
    ['SRV-B', 'Serviette de bain', 'bath', 150], ['SRV-M', 'Serviette de toilette', 'bath', 150], ['TAP', 'Tapis de bain', 'bath', 60], ['PGN', 'Peignoir', 'bath', 30],
  ];
  for (const [code, name, cat, par] of linen) {
    await c.query('INSERT INTO linen_items (hotel_id, code, name, category, par_level) VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING', [hotelId, code, name, cat, par]);
  }
}

function randomPassword() {
  const a = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  return `${Array.from(randomBytes(12), (b) => a[b % a.length]).join('')}7k`;
}

export async function seedBase(opts: { adminPassword?: string; log?: (s: string) => void } = {}) {
  const log = opts.log ?? console.log;
  const pool = getPool();
  return tx(async (c) => {
    await syncRolesAndPermissions(c);
    let hotel = await one<any>(c, 'SELECT * FROM hotels ORDER BY id LIMIT 1');
    if (hotel) {
      log('Hôtel déjà configuré : rôles et permissions mis à jour.');
      return { hotelId: hotel.id, adminId: (await one<any>(c, `SELECT id FROM users WHERE username = 'admin'`))?.id };
    }
    hotel = await one<any>(c, `INSERT INTO hotels (name, city) VALUES ('Hôtel K', 'Oran') RETURNING *`);
    const settings: Record<string, unknown> = {
      meal_supplements: { RO: 0, BB: 800, HB: 2200, FB: 3800 },
      vat_rate: 0,
      tourist_tax_per_adult_night: 0,
      check_in_time: '14:00',
      check_out_time: '12:00',
    };
    for (const [k, v] of Object.entries(settings)) {
      await c.query('INSERT INTO settings(hotel_id, key, value) VALUES ($1,$2,$3)', [hotel.id, k, JSON.stringify(v)]);
    }
    await ensureHotelDefaults(c, hotel.id);
    const building = await one<any>(c, `SELECT id FROM buildings WHERE hotel_id = $1 AND code = 'A'`, [hotel.id]);
    const adminRole = await one<any>(c, `SELECT id FROM roles WHERE code = 'admin'`);
    // jamais de mot de passe codé en dur : celui de l'environnement, sinon un mot de passe aléatoire affiché une seule fois
    const pw = opts.adminPassword ?? process.env.ADMIN_PASSWORD ?? randomPassword();
    const admin = await one<any>(
      c,
      `INSERT INTO users (hotel_id, username, full_name, first_name, password_hash, role_id, must_change_password, protected) VALUES ($1,'admin','Administrateur','Administrateur',$2,$3,$4,true) RETURNING id`,
      [hotel.id, await hashPassword(pw), adminRole.id, !opts.adminPassword && !process.env.ADMIN_PASSWORD],
    );
    // Catalogue des types : tarifs indicatifs à remplacer par la grille réelle de l'hôtel
    const types = [
      { code: 'SGL', name: 'Single', category: 'Standard', capacity: 1, adults: 1, children: 0, beds: 1, bed: '1 lit simple', area: 14, rate: 6500 },
      { code: 'DBL', name: 'Double', category: 'Standard', capacity: 2, adults: 2, children: 1, beds: 1, bed: '1 grand lit', area: 18, rate: 9000 },
      { code: 'TWN', name: 'Twin', category: 'Standard', capacity: 2, adults: 2, children: 0, beds: 2, bed: '2 lits simples', area: 18, rate: 9000 },
      { code: 'TPL', name: 'Triple', category: 'Standard', capacity: 3, adults: 3, children: 1, beds: 3, bed: '3 lits simples', area: 22, rate: 11500 },
      { code: 'QDP', name: 'Quadruple', category: 'Standard', capacity: 4, adults: 4, children: 2, beds: 4, bed: '2 grands lits', area: 26, rate: 14000 },
      { code: 'FAM', name: 'Familiale', category: 'Standard', capacity: 5, adults: 3, children: 3, beds: 3, bed: '1 grand lit + 2 lits simples', area: 30, rate: 15000 },
      { code: 'STD', name: 'Standard', category: 'Standard', capacity: 2, adults: 2, children: 1, beds: 1, bed: '1 grand lit', area: 20, rate: 8000 },
      { code: 'DLX', name: 'Deluxe', category: 'Deluxe', capacity: 2, adults: 2, children: 1, beds: 1, bed: '1 lit king size', area: 26, rate: 13000 },
      { code: 'EXE', name: 'Executive', category: 'Executive', capacity: 2, adults: 2, children: 1, beds: 1, bed: '1 lit king size', area: 32, rate: 18000 },
      { code: 'STE', name: 'Suite', category: 'Suite', capacity: 4, adults: 3, children: 2, beds: 2, bed: '1 lit king size + canapé-lit', area: 40, rate: 16000 },
    ];
    const typeIds: Record<string, number> = {};
    for (const [i, t] of types.entries()) {
      const r = await one<any>(c, `INSERT INTO room_types (hotel_id, code, name, category, capacity, max_adults, max_children, beds, bed_type, area_m2, base_rate, sort_order)
                                   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
        [hotel.id, t.code, t.name, t.category, t.capacity, t.adults, t.children, t.beds, t.bed, t.area, t.rate, i]);
      typeIds[t.code] = r.id;
      const am = t.category === 'Standard' ? ['ac', 'tv', 'wifi', 'shower'] : ['ac', 'heating', 'tv', 'wifi', 'minibar', 'safe', 'bathtub', 'desk', 'hairdryer'];
      await c.query(`INSERT INTO room_type_amenities (room_type_id, amenity_id) SELECT $1, id FROM amenities WHERE hotel_id = $2 AND code = ANY($3::text[])`, [r.id, hotel.id, am]);
    }
    const pattern = ['STE', 'DBL', 'DBL', 'TPL', 'SGL', 'DBL', 'SGL', 'DBL', 'DBL', 'SGL'];
    for (let f = 1; f <= 4; f++) {
      const floor = await one<any>(c, `INSERT INTO floors (hotel_id, building_id, number, name) VALUES ($1,$2,$3,$4) RETURNING id`, [hotel.id, building.id, f, f === 1 ? '1er étage' : `${f}e étage`]);
      for (let i = 1; i <= 10; i++) {
        const room = await one<any>(c, `INSERT INTO rooms (hotel_id, floor_id, room_type_id, number, sort_order) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
          [hotel.id, floor.id, typeIds[pattern[i - 1]], String(f * 100 + i), i]);
        await c.query(`INSERT INTO room_amenities (room_id, amenity_id) SELECT $1, amenity_id FROM room_type_amenities WHERE room_type_id = $2`, [room.id, typeIds[pattern[i - 1]]]);
      }
    }
    await c.query(`INSERT INTO cash_registers (hotel_id, name) VALUES ($1, 'Caisse réception')`, [hotel.id]);
    log(`✔ Hôtel créé (40 chambres). Connexion : admin / ${pw}`);
    return { hotelId: hotel.id as number, adminId: admin.id as number };
  });
}

/** Générateur pseudo-aléatoire déterministe */
function rng(seed: number) {
  return () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 4294967296;
  };
}

const NAMES = [
  ['Benali', 'Karim'], ['Haddad', 'Sofiane'], ['Mansouri', 'Leila'], ['Kaci', 'Nadia'], ['Bouzid', 'Yacine'], ['Ferhat', 'Amel'],
  ['Larbi', 'Omar'], ['Touati', 'Samir'], ['Cherif', 'Imane'], ['Rahmani', 'Walid'], ['Saidi', 'Meriem'], ['Ait Ahmed', 'Rafik'],
  ['Guerfi', 'Lina'], ['Belkacem', 'Anis'], ['Ziani', 'Hocine'], ['Medjahed', 'Sara'], ['Hamidi', 'Fouad'], ['Brahimi', 'Kenza'],
  ['Mokrani', 'Adel'], ['Boudiaf', 'Rym'], ['Kherbouche', 'Nabil'], ['Lounes', 'Farid'], ['Amrani', 'Selma'], ['Djebbar', 'Mehdi'],
  ['Talbi', 'Karima'], ['Hadjadj', 'Riad'], ['Ouali', 'Sonia'], ['Benyahia', 'Ilyes'], ['Sahraoui', 'Mounir'], ['Meziane', 'Hana'],
  ['Bensalem', 'Tarek'], ['Chaib', 'Yasmine'], ['Zerrouki', 'Amine'], ['Guendouz', 'Lynda'], ['Kaddour', 'Imad'], ['Hamel', 'Sabrina'],
];

export async function seedDemo(log = console.log) {
  const pool = getPool();
  const hotel = await one<any>(pool, 'SELECT id FROM hotels ORDER BY id LIMIT 1');
  const admin = await one<any>(pool, `SELECT id FROM users WHERE username = 'admin'`);
  const has = await one<any>(pool, 'SELECT count(*)::int AS n FROM reservations WHERE hotel_id = $1', [hotel.id]);
  if (has.n > 0) {
    log('Des réservations existent déjà : données de démo non ajoutées.');
    return;
  }
  const actor: Actor = { userId: admin.id, hotelId: hotel.id, ip: 'seed' };
  const rooms = (await pool.query('SELECT r.id, r.number, t.capacity FROM rooms r JOIN room_types t ON t.id = r.room_type_id WHERE r.hotel_id = $1 ORDER BY r.number', [hotel.id])).rows;
  const T = today();
  const rand = rng(42);
  const pick = <X>(a: X[]) => a[Math.floor(rand() * a.length)];
  let nameIdx = 0;
  const guest = () => {
    const [last_name, first_name] = NAMES[nameIdx++ % NAMES.length];
    return { last_name, first_name, phone: `05${Math.floor(10000000 + rand() * 89999999)}`, nationality: 'Algérienne' };
  };
  const sources = ['phone', 'walk_in', 'company', 'email'] as const;
  const meals = ['RO', 'BB', 'BB', 'HB', 'FB'] as const;

  await tx(async (c) => {
    // historique de démo : les encaissements passés ne sont pas rattachés à la caisse du jour
    await c.query(`INSERT INTO settings (hotel_id, key, value) VALUES ($1,'cash_session_required','false')`, [hotel.id]);
    // 1) Historique : séjours terminés sur les 30 derniers jours (écriture directe : données passées)
    for (const room of rooms) {
      let cursor = addDays(T, -30 + Math.floor(rand() * 3));
      while (true) {
        const start = addDays(cursor, Math.floor(rand() * 3));
        const nights = 1 + Math.floor(rand() * 4);
        const end = addDays(start, nights);
        if (end > addDays(T, -4)) break;
        cursor = end;
        const res = await createReservation(c, actor, {
          guest: guest(), source: pick([...sources]), meal_plan: pick([...meals]), check_in: start, check_out: end,
          rooms: [{ room_id: room.id, adults: Math.min(room.capacity, 1 + Math.floor(rand() * 2)) }],
        }, { allowPast: true, silent: true });
        const rr = res.rooms[0];
        await c.query(`UPDATE reservation_rooms SET status = 'checked_out' WHERE id = $1`, [rr.id]);
        await c.query(`UPDATE reservations SET status = 'checked_out', created_at = $2::date - 5 WHERE id = $1`, [res.id, start]);
        const stay = await one<any>(c, `INSERT INTO stays (reservation_room_id, room_id, guest_id, checked_in_at, checked_out_at)
                                      VALUES ($1,$2,$3,$4::date + interval '15 hours',$5::date + interval '11 hours') RETURNING id`,
          [rr.id, room.id, res.guest_id, start, end]);
        await c.query(`INSERT INTO check_ins (stay_id, done_by, done_at) VALUES ($1,$2,$3::date + interval '15 hours')`, [stay.id, admin.id, start]);
        const paidAll = rand() > 0.12;
        const pay = await addPayment(c, actor, { reservation_id: res.id, amount: paidAll ? res.total : Math.round(res.total / 2), method: pick(['cash', 'cash', 'card'] as const) });
        await c.query(`ALTER TABLE payments DISABLE TRIGGER payments_guard`);
        await c.query(`UPDATE payments SET received_at = $2::date + interval '10 hours' WHERE id = $1`, [pay.id, end]);
        await c.query(`ALTER TABLE payments ENABLE TRIGGER payments_guard`);
      }
    }

    const free = rooms.map((r: any) => r.id);
    const takeRoom = () => free.splice(Math.floor(rand() * free.length), 1)[0];

    // 2) Clients en chambre (arrivés les jours précédents)
    for (let i = 0; i < 12; i++) {
      const roomId = takeRoom();
      const ci = addDays(T, -(1 + Math.floor(rand() * 3)));
      const co = addDays(T, 1 + Math.floor(rand() * 4));
      const res = await createReservation(c, actor, { guest: guest(), source: pick([...sources]), meal_plan: pick([...meals]), check_in: ci, check_out: co, rooms: [{ room_id: roomId, adults: 1 }] }, { allowPast: true, silent: true });
      await checkIn(c, actor, res.rooms[0].id, { id_scanned: true });
      if (rand() > 0.3) await addPayment(c, actor, { reservation_id: res.id, amount: Math.round(res.total * (rand() > 0.5 ? 1 : 0.5)), method: 'cash', kind: 'deposit' });
    }
    // 3) Départs du jour (en chambre, départ aujourd'hui)
    for (let i = 0; i < 4; i++) {
      const roomId = takeRoom();
      const ci = addDays(T, -(2 + Math.floor(rand() * 2)));
      const res = await createReservation(c, actor, { guest: guest(), source: 'phone', meal_plan: 'BB', check_in: ci, check_out: addDays(T, 1), rooms: [{ room_id: roomId, adults: 1 }] }, { allowPast: true, silent: true });
      await checkIn(c, actor, res.rooms[0].id);
      await c.query(`UPDATE reservation_rooms SET check_out = $2 WHERE id = $1`, [res.rooms[0].id, T]);
      await c.query(`UPDATE reservations SET check_out = $2, total_amount = total_amount - (SELECT rate FROM reservation_rooms WHERE id = $3) WHERE id = $1`, [res.id, T, res.rooms[0].id]);
      if (i % 2 === 0) await addPayment(c, actor, { reservation_id: res.id, amount: 5000, method: 'card', kind: 'deposit' });
    }
    // 4) Arrivées du jour
    for (let i = 0; i < 6; i++) {
      const roomId = takeRoom();
      await createReservation(c, actor, { guest: guest(), source: pick([...sources]), meal_plan: pick([...meals]), check_in: T, check_out: addDays(T, 1 + Math.floor(rand() * 4)), rooms: [{ room_id: roomId, adults: 1 }], status: i === 5 ? 'pending' : 'confirmed' }, { silent: true });
    }
    // 5) Réservations futures (sur toutes les chambres, sans chevauchement)
    const next = new Map<number, string>();
    for (const r of rooms) next.set(r.id, addDays(T, 5));
    for (let i = 0; i < 30; i++) {
      const room = pick(rooms);
      const ci = addDays(next.get(room.id)!, Math.floor(rand() * 6));
      const nights = 1 + Math.floor(rand() * 6);
      const co = addDays(ci, nights);
      next.set(room.id, co);
      const company = rand() > 0.8;
      await createReservation(c, actor, {
        guest: guest(), booker_type: company ? 'company' : 'individual', source: company ? 'company' : pick([...sources]),
        payer: company ? { kind: 'company', company_name: pick(['Atlas Conseil', 'Séminaire Ouest', 'Groupe Littoral']) } : null,
        meal_plan: pick([...meals]), check_in: ci, check_out: co, rooms: [{ room_id: room.id, adults: 1 }],
        status: rand() > 0.85 ? 'pending' : 'confirmed',
        deposit: rand() > 0.6 ? { amount: 5000, method: 'cash' } : null,
      }, { silent: true });
    }
    // 6) Ménage et maintenance
    const dirty = free.splice(0, 3);
    for (const id of dirty) await markRoomDirty(c, actor, id, null, 'checkout_clean');
    // chambre libre sans réservation future (sinon le blocage est refusé, à juste titre)
    for (const id of free) {
      const busy = await one<any>(c, `SELECT 1 FROM reservation_rooms WHERE room_id = $1 AND status IN ('pending','confirmed') AND check_out > $2 LIMIT 1`, [id, T]);
      if (busy) continue;
      await setRoomOutOfServiceNow(c, actor, id, true, 'Climatisation en panne');
      break;
    }
    // 6 bis) Équipe ménage (comptes : nadia = gouvernante, amina / sara = femmes de chambre ; mot de passe Menage2026!), planning du jour, tâches, linge
    const staffPw = await hashPassword('Menage2026!');
    for (const [first, last, user, role] of [['Nadia', 'Benali', 'nadia', 'hk_supervisor'], ['Amina', 'Kaddour', 'amina', 'housekeeping'], ['Sara', 'Mansouri', 'sara', 'housekeeping'], ['Yacine', 'Hamidi', null, null]] as const) {
      const e = await one<any>(c, `INSERT INTO employees (hotel_id, first_name, last_name, position, department, hire_date, max_rooms) VALUES ($1,$2,$3,$4,'housekeeping',$5,14) RETURNING id`,
        [hotel.id, first, last, role === 'hk_supervisor' ? 'Gouvernante' : 'Femme / valet de chambre', addDays(T, -400)]);
      if (user) {
        const r = await one<any>(c, 'SELECT id FROM roles WHERE code = $1', [role]);
        await c.query(`INSERT INTO users (hotel_id, username, full_name, password_hash, role_id, employee_id) VALUES ($1,$2,$3,$4,$5,$6)`, [hotel.id, user, `${first} ${last}`, staffPw, r.id, e.id]);
      }
      if (role !== 'hk_supervisor') await c.query(`INSERT INTO hk_shifts (employee_id, work_date, start_time, end_time) VALUES ($1,$2,'08:00','15:00')`, [e.id, T]);
    }
    await generateTasks(c, actor, T);
    await autoAssign(c, actor, T);
    for (const it of await c.query('SELECT id, par_level FROM linen_items WHERE hotel_id = $1', [hotel.id]).then((r: any) => r.rows)) {
      await linenMove(c, actor, { item_id: it.id, kind: 'purchase', quantity: it.par_level * 3, reason: 'Stock initial' });
      await linenMove(c, actor, { item_id: it.id, kind: 'issue', quantity: it.par_level, reason: 'Mise en chambres' });
      await linenMove(c, actor, { item_id: it.id, kind: 'collect', quantity: Math.round(it.par_level / 3) });
    }
    // 6 ter) Restaurant : stock, carte, tables, menus, personnel, commandes du jour
    const allPerms = new Set(Object.keys(PERMISSIONS));
    const prod: Record<string, number> = {};
    for (const [name, cat, unit, min, qty, cost] of [['Viande d\'agneau', 'Cuisine', 'kg', 3, 18, 1800], ['Poulet', 'Cuisine', 'kg', 3, 12, 650], ['Semoule', 'Cuisine', 'kg', 5, 25, 120],
      ['Poisson du jour', 'Cuisine', 'kg', 2, 6, 1400], ['Œufs', 'Petit-déjeuner', 'unité', 30, 180, 25], ['Lait', 'Petit-déjeuner', 'L', 5, 20, 110], ['Café', 'Boissons', 'kg', 1, 4, 2200],
      ['Eau minérale 1,5 L', 'Boissons', 'bouteille', 24, 96, 40], ['Jus d\'orange 1 L', 'Boissons', 'bouteille', 10, 30, 180], ['Coca-Cola 33 cl', 'Boissons', 'bouteille', 24, 20, 60]] as const) {
      const pr = await one<any>(c, `INSERT INTO products (hotel_id, name, category, unit, min_stock, cost_price) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`, [hotel.id, name, cat, unit, min, cost]);
      prod[name] = pr.id;
      await stockMove(c, actor, { product_id: pr.id, kind: 'in', quantity: qty, reason: 'Stock initial' });
    }
    const catId = async (k: string) => (await one<any>(c, 'SELECT id FROM rs_categories WHERE hotel_id = $1 AND kind = $2', [hotel.id, k])).id;
    const item = async (k: string, name: string, price: number, desc: string, allergens: string[], recipe: [string, number][] = [], station: string | null = null) => {
      const it = await one<any>(c, `INSERT INTO rs_items (hotel_id, category_id, name, description, price, allergens, station) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`, [hotel.id, await catId(k), name, desc, price, allergens, station]);
      for (const [p, q] of recipe) await c.query('INSERT INTO rs_recipes (item_id, product_id, quantity) VALUES ($1,$2,$3)', [it.id, prod[p], q]);
      return it.id as number;
    };
    const I = {
      chorba: await item('starter', 'Chorba frik', 450, 'Soupe traditionnelle à l\'agneau et au blé vert', ['gluten', 'celery'], [['Viande d\'agneau', 0.05]]),
      salade: await item('starter', 'Salade variée', 400, 'Crudités de saison, vinaigrette maison', ['mustard']),
      bourek: await item('starter', 'Bourek à la viande', 350, '2 pièces', ['gluten', 'eggs'], [['Viande d\'agneau', 0.05]]),
      couscous: await item('main', 'Couscous à l\'agneau', 1600, 'Semoule fine, légumes, agneau', ['gluten'], [['Viande d\'agneau', 0.25], ['Semoule', 0.15]]),
      poulet: await item('main', 'Poulet grillé', 1200, 'Frites ou riz, salade', [], [['Poulet', 0.35]]),
      poisson: await item('main', 'Poisson grillé', 1900, 'Selon arrivage', ['fish'], [['Poisson du jour', 0.4]]),
      steak: await item('main', 'Entrecôte', 2400, 'Sauce au choix', ['milk']),
      tiramisu: await item('dessert', 'Tiramisu', 500, '', ['gluten', 'eggs', 'milk']),
      fruits: await item('dessert', 'Salade de fruits', 350, 'Fruits de saison', []),
      cafe: await item('drink', 'Café', 150, '', [], [['Café', 0.008]]),
      the: await item('drink', 'Thé à la menthe', 150, '', []),
      eau: await item('drink', 'Eau minérale 1,5 L', 120, '', [], [['Eau minérale 1,5 L', 1]], 'none'),
      jus: await item('drink', 'Jus d\'orange', 300, '', [], [['Jus d\'orange 1 L', 0.25]]),
      coca: await item('drink', 'Coca-Cola', 200, '', [], [['Coca-Cola 33 cl', 1]], 'none'),
      pdj: await item('breakfast', 'Petit-déjeuner complet', 800, 'Boisson chaude, jus, viennoiseries, œufs', ['gluten', 'eggs', 'milk'], [['Œufs', 2], ['Lait', 0.2]]),
      omelette: await item('breakfast', 'Omelette', 350, '3 œufs', ['eggs'], [['Œufs', 3]]),
    };
    const st = await one<any>(c, `SELECT id FROM rs_items WHERE id = $1`, [I.steak]);
    for (const [k, n, d] of [['variant', 'Saignante', 0], ['variant', 'À point', 0], ['variant', 'Bien cuite', 0], ['supplement', 'Sauce poivre', 150], ['supplement', 'Frites maison', 200]] as const) {
      await c.query('INSERT INTO rs_item_options (item_id, kind, name, price_delta) VALUES ($1,$2,$3,$4)', [st.id, k, n, d]);
    }
    for (const [i, [n, cap, area, shape]] of ([['1', 2, 'Salle', 'square'], ['2', 2, 'Salle', 'square'], ['3', 4, 'Salle', 'square'], ['4', 4, 'Salle', 'square'], ['5', 4, 'Salle', 'round'], ['6', 6, 'Salle', 'long'],
      ['7', 4, 'Salle', 'round'], ['8', 8, 'Salle', 'long'], ['T1', 4, 'Terrasse', 'round'], ['T2', 4, 'Terrasse', 'round'], ['T3', 2, 'Terrasse', 'square']] as const).entries()) {
      await c.query('INSERT INTO rs_tables (hotel_id, number, capacity, area, shape, pos_x) VALUES ($1,$2,$3,$4,$5,$6)', [hotel.id, n, cap, area, shape, i]);
    }
    const menu = async (name: string, outlets: string[], st0: string, en: string, ids: number[]) => {
      const m = await one<any>(c, 'INSERT INTO rs_menus (hotel_id, name, outlets, start_time, end_time) VALUES ($1,$2,$3,$4,$5) RETURNING id', [hotel.id, name, outlets, st0, en]);
      for (const id of ids) await c.query('INSERT INTO rs_menu_items (menu_id, item_id) VALUES ($1,$2)', [m.id, id]);
    };
    await menu('Petit-déjeuner', ['breakfast', 'room_service'], '06:00', '10:59', [I.pdj, I.omelette, I.cafe, I.the, I.jus, I.eau]);
    await menu('Carte du jour', ['restaurant', 'room_service'], '11:00', '23:30', Object.values(I).filter((x) => ![I.pdj, I.omelette].includes(x)));
    const staffPw2 = await hashPassword('Resto2026!');
    for (const [u, n, role] of [['karim', 'Karim Saidi', 'waiter'], ['chef', 'Mourad Belkacem', 'chef'], ['bar', 'Samir Ouali', 'barman'], ['resto', 'Leila Haddad', 'rs_manager'], ['caisse', 'Nora Brahimi', 'cashier']]) {
      const r = await one<any>(c, 'SELECT id FROM roles WHERE code = $1', [role]);
      await c.query(`INSERT INTO users (hotel_id, username, full_name, password_hash, role_id) VALUES ($1,$2,$3,$4,$5)`, [hotel.id, u, n, staffPw2, r.id]);
    }
    const tbl = async (n: string) => (await one<any>(c, 'SELECT id FROM rs_tables WHERE hotel_id = $1 AND number = $2', [hotel.id, n])).id;
    const reg2 = await one<any>(c, 'SELECT id FROM cash_registers WHERE hotel_id = $1 LIMIT 1', [hotel.id]);
    await c.query(`INSERT INTO settings (hotel_id, key, value) VALUES ($1,'cash_session_required','false') ON CONFLICT (hotel_id, key) DO UPDATE SET value = 'false'`, [hotel.id]);
    void reg2;
    // commandes réglées (payées, sur la chambre) + commandes en cours en salle et en cuisine
    const o1 = await createOrder(c, actor, allPerms, { outlet: 'restaurant', table_id: await tbl('3'), covers: 3, lines: [{ item_id: I.chorba, quantity: 3 }, { item_id: I.couscous, quantity: 2 }, { item_id: I.poulet, quantity: 1 }, { item_id: I.eau, quantity: 2 }] });
    await confirmOrder(c, actor, o1.id); await kitchenAction(c, actor, o1.id, 'ready', null); await serveOrder(c, actor, allPerms, o1.id);
    const t1 = await one<any>(c, 'SELECT total FROM rs_orders WHERE id = $1', [o1.id]);
    await settle(c, actor, o1.id, { mode: 'pay', payments: [{ method: 'cash', amount: Number(t1.total) }] });
    await c.query(`UPDATE rs_tables SET status = 'available' WHERE id = $1`, [await tbl('3')]);
    const occupied = await q<any>(c, `SELECT room_id FROM stays s JOIN rooms r ON r.id = s.room_id WHERE r.hotel_id = $1 AND s.checked_out_at IS NULL ORDER BY r.number LIMIT 2`, [hotel.id]);
    if (occupied[0]) {
      const rs1 = await createOrder(c, actor, allPerms, { outlet: 'room_service', room_id: occupied[0].room_id, lines: [{ item_id: I.poisson, quantity: 1 }, { item_id: I.jus, quantity: 2 }] });
      await confirmOrder(c, actor, rs1.id); await kitchenAction(c, actor, rs1.id, 'ready', null); await serveOrder(c, actor, allPerms, rs1.id);
    }
    if (occupied[1]) {
      const rs2 = await createOrder(c, actor, allPerms, { outlet: 'room_service', room_id: occupied[1].room_id, lines: [{ item_id: I.steak, quantity: 1, option_ids: [(await one<any>(c, `SELECT id FROM rs_item_options WHERE item_id = $1 AND name = 'À point'`, [I.steak])).id] }, { item_id: I.eau, quantity: 1 }] });
      await confirmOrder(c, actor, rs2.id);
    }
    const o2 = await createOrder(c, actor, allPerms, { outlet: 'restaurant', table_id: await tbl('5'), covers: 4, lines: [{ item_id: I.salade, quantity: 2, comment: 'Sans oignon' }, { item_id: I.couscous, quantity: 4 }, { item_id: I.coca, quantity: 4 }] });
    await confirmOrder(c, actor, o2.id); await kitchenAction(c, actor, o2.id, 'start', 'kitchen');
    const o3 = await createOrder(c, actor, allPerms, { outlet: 'restaurant', table_id: await tbl('T1'), covers: 2, priority: 'high', lines: [{ item_id: I.poulet, quantity: 2 }, { item_id: I.the, quantity: 2 }] });
    await confirmOrder(c, actor, o3.id);
    await createOrder(c, actor, allPerms, { outlet: 'restaurant', table_id: await tbl('8'), covers: 6, lines: [{ item_id: I.bourek, quantity: 6 }] });
    await c.query(`DELETE FROM settings WHERE hotel_id = $1 AND key = 'cash_session_required'`, [hotel.id]);
    // 6 quater) Stocks & achats : entrepôts, fournisseurs, articles, achats complets, sorties par département, lots
    const mag = await one<any>(c, 'SELECT id FROM warehouses WHERE hotel_id = $1 AND is_default', [hotel.id]);
    await c.query('UPDATE products SET default_warehouse_id = $2 WHERE hotel_id = $1 AND default_warehouse_id IS NULL', [hotel.id, mag.id]);
    const wh: Record<string, number> = { MAG: mag.id };
    for (const [code, name, kind] of [['CUI', 'Cuisine', 'kitchen'], ['BAR', 'Bar', 'bar'], ['ETG', 'Réserve étages', 'housekeeping'], ['TEC', 'Atelier maintenance', 'maintenance']]) {
      wh[code] = (await one<any>(c, 'INSERT INTO warehouses (hotel_id, code, name, kind) VALUES ($1,$2,$3,$4) RETURNING id', [hotel.id, code, name, kind])).id;
    }
    const sup: Record<string, number> = {};
    for (const [code, name, city, terms, phone] of [['HYO', 'Hygiène Ouest SARL', 'Oran', 30, '041 33 22 11'], ['TXO', 'Textile Oran', 'Oran', 60, '041 45 67 89'], ['ALM', 'Alimentation Générale El Bahia', 'Oran', 15, '0550 12 34 56'],
      ['ELC', 'Électro Pro Es-Senia', 'Es-Senia', 30, '0661 22 33 44']] as const) {
      sup[code] = (await one<any>(c, `INSERT INTO suppliers (hotel_id, name, code, city, payment_terms, phone, nif) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`, [hotel.id, name, code, city, terms, phone, `0003100${Math.floor(rand() * 1e8)}`])).id;
    }
    const sp: Record<string, number> = {};
    const srvB = await one<any>(c, `SELECT id FROM linen_items WHERE hotel_id = $1 AND code = 'SRV-B'`, [hotel.id]);
    for (const [code, name, cat, unit, cost, min, max, lots, linen] of [
      ['NET-SOL', 'Détergent sol 5 L', 'Produits de nettoyage', 'bidon', 650, 6, 40, false, null], ['NET-JAV', 'Eau de Javel 1 L', 'Produits de nettoyage', 'bouteille', 90, 24, 120, false, null],
      ['NET-VIT', 'Nettoyant vitres', 'Produits de nettoyage', 'flacon', 280, 6, 30, false, null], ['ACC-SAV', 'Savonnette 25 g', 'Produits d\'accueil', 'pièce', 18, 200, 1500, false, null],
      ['ACC-SHP', 'Shampoing 30 ml', 'Produits d\'accueil', 'pièce', 25, 200, 1500, true, null], ['ACC-PH', 'Papier hygiénique', 'Produits d\'accueil', 'rouleau', 35, 120, 800, false, null],
      ['LIN-SRV', 'Serviette de bain (achat)', 'Linge et textile', 'pièce', 950, 0, null, false, srvB?.id ?? null], ['ADM-RAM', 'Ramette papier A4', 'Fournitures administratives', 'paquet', 750, 5, 30, false, null],
      ['EQP-AMP', 'Ampoule LED E27', 'Matériel et équipements', 'pièce', 180, 20, 100, false, null], ['ALI-YAO', 'Yaourt nature', 'Alimentation', 'pièce', 30, 40, 300, true, null],
    ] as const) {
      sp[code] = (await one<any>(c, `INSERT INTO products (hotel_id, code, name, category, unit, cost_price, avg_cost, min_stock, max_stock, track_lots, linen_item_id, default_warehouse_id, tax_rate)
          VALUES ($1,$2,$3,$4,$5,$6,$6,$7,$8,$9,$10,$11,19) RETURNING id`, [hotel.id, code, name, cat, unit, cost, min, max, lots, linen, mag.id])).id;
    }
    const pAdmin = new Set(Object.keys(PERMISSIONS));
    const stockPw = await hashPassword('Stock2026!');
    for (const [u, n, role] of [['magasin', 'Rachid Benamar', 'storekeeper'], ['achat', 'Yasmine Kaci', 'purchaser'], ['compta', 'Farid Meziane', 'accountant']]) {
      const r = await one<any>(c, 'SELECT id FROM roles WHERE code = $1', [role]);
      await c.query(`INSERT INTO users (hotel_id, username, full_name, password_hash, role_id) VALUES ($1,$2,$3,$4,$5)`, [hotel.id, u, n, stockPw, r.id]);
    }
    // achat complet : demande housekeeping → validation → 2 devis → commande → réception → facture → paiement
    const r1 = await createRequest(c, actor, { department: 'housekeeping', reason: 'Réassort mensuel produits d\'accueil', lines: [{ product_id: sp['NET-SOL'], quantity: 20 }, { product_id: sp['NET-JAV'], quantity: 120 }, { product_id: sp['ACC-SAV'], quantity: 1200 }, { product_id: sp['ACC-SHP'], quantity: 1000 }, { product_id: sp['ACC-PH'], quantity: 600 }], submit: true });
    await poApprove(c, actor, pAdmin, r1.id, { decision: 'approve' });
    const l1 = await q<any>(c, 'SELECT id, product_id, quantity FROM purchase_order_lines WHERE po_id = $1 ORDER BY id', [r1.id]);
    const pr = (code: string, k: number) => ({ 'NET-SOL': 650, 'NET-JAV': 90, 'ACC-SAV': 18, 'ACC-SHP': 25, 'ACC-PH': 35 } as Record<string, number>)[code] * k;
    const codeOf = (pid: number) => Object.entries(sp).find(([, v]) => v === pid)![0];
    await saveQuote(c, actor, r1.id, { supplier_id: sup.HYO, delivery_days: 3, lines: l1.map((l) => ({ line_id: l.id, unit_price: Math.round(pr(codeOf(l.product_id), 0.97)) })) });
    const qB = await saveQuote(c, actor, r1.id, { supplier_id: sup.ALM, delivery_days: 5, lines: l1.map((l) => ({ line_id: l.id, unit_price: Math.round(pr(codeOf(l.product_id), 1.04)) })) });
    void qB;
    const best = await one<any>(c, 'SELECT id FROM purchase_quotes WHERE po_id = $1 ORDER BY total LIMIT 1', [r1.id]);
    await selectQuote(c, actor, r1.id, best.id);
    await placeOrder(c, actor, r1.id, { expected_date: addDays(T, -2) });
    await receive(c, actor, r1.id, { delivery_note: 'BL-2231', lines: l1.map((l) => ({ po_line_id: l.id, quantity: Number(l.quantity), lot_no: l.product_id === sp['ACC-SHP'] ? 'SH-2611' : null, expiry_date: l.product_id === sp['ACC-SHP'] ? addDays(T, 400) : null })) });
    const tot = await one<any>(c, 'SELECT subtotal, tax_total FROM purchase_orders WHERE id = $1', [r1.id]);
    const f1 = await createInvoice(c, actor, { supplier_id: sup.HYO, number: 'HYO-7781', po_id: r1.id, invoice_date: addDays(T, -1), subtotal: Number(tot.subtotal), tax_total: Number(tot.tax_total) });
    await paySupplier(c, actor, f1.id, { amount: Math.round(Number(f1.total) / 2), method: 'transfer', reference: 'VIR-0451', paid_at: T });
    // commande en retard + demande à valider + facture échue
    const r2 = await createRequest(c, actor, { department: 'maintenance', supplier_id: sup.ELC, reason: 'Remplacement éclairage couloirs', lines: [{ product_id: sp['EQP-AMP'], quantity: 60, unit_price: 175 }], submit: true });
    await poApprove(c, actor, pAdmin, r2.id, { decision: 'approve' });
    await placeOrder(c, actor, r2.id, { expected_date: addDays(T, -1) });
    await createRequest(c, actor, { department: 'admin', reason: 'Fournitures bureau réception', lines: [{ product_id: sp['ADM-RAM'], quantity: 10, unit_price: 750 }], submit: true });
    await createInvoice(c, actor, { supplier_id: sup.TXO, number: 'TXO-2026-118', invoice_date: addDays(T, -75), subtotal: 38000, tax_total: 7220, category: 'Linge et textile' });
    // entrées directes, lots proches de la péremption, transferts et consommations
    await moveStock(c, actor, { product_id: sp['ALI-YAO'], kind: 'in', quantity: 60, unit_cost: 30, lot_no: 'Y-1108', expiry_date: addDays(T, 4), reason: 'Livraison crémerie' });
    await moveStock(c, actor, { product_id: sp['EQP-AMP'], kind: 'in', quantity: 12, unit_cost: 180, reason: 'Stock initial' });
    await moveStock(c, actor, { product_id: sp['ADM-RAM'], kind: 'in', quantity: 3, unit_cost: 750, reason: 'Stock initial' });
    await transfer(c, actor, { product_id: sp['ACC-SAV'], from_id: mag.id, to_id: wh.ETG, quantity: 400 });
    await transfer(c, actor, { product_id: sp['ALI-YAO'], from_id: mag.id, to_id: wh.CUI, quantity: 30 });
    for (const [code, qn, dept, from] of [['ACC-SAV', 160, 'housekeeping', wh.ETG], ['NET-JAV', 30, 'housekeeping', mag.id], ['ACC-PH', 140, 'housekeeping', mag.id], ['EQP-AMP', 8, 'maintenance', mag.id], ['ADM-RAM', 2, 'reception', mag.id]] as const) {
      await stockOut(c, actor, pAdmin, { product_id: sp[code], warehouse_id: from, kind: 'issue', department: dept, quantity: qn });
    }
    // 6 bis) Maintenance : techniciens, parc d'équipements, plans préventifs, pannes et interventions
    const mPw = await hashPassword('Maint2026!');
    const mUsers: Record<string, number> = {};
    for (const [u, n, role] of [['mourad', 'Mourad Hadj', 'maintenance_manager'], ['yacine', 'Yacine Boudiaf', 'technician'], ['omar', 'Omar Ziani', 'technician']]) {
      const r = await one<any>(c, 'SELECT id FROM roles WHERE code = $1', [role]);
      mUsers[u] = (await one<any>(c, `INSERT INTO users (hotel_id, username, full_name, password_hash, role_id) VALUES ($1,$2,$3,$4,$5) RETURNING id`, [hotel.id, u, n, mPw, r.id])).id;
    }
    const tech: Record<string, number> = {};
    for (const [k, n, uid, spec, rate, ext] of [['y', 'Yacine Boudiaf', mUsers.yacine, ['electrical', 'hvac', 'it'], 800, false], ['o', 'Omar Ziani', mUsers.omar, ['plumbing', 'heating'], 700, false],
      ['m', 'Mourad Hadj', mUsers.mourad, ['elevator', 'fire_safety', 'kitchen'], 1000, false], ['x', 'Froid Oranais (prestataire)', null, ['hvac', 'kitchen'], 2500, true]] as const) {
      tech[k] = (await one<any>(c, `INSERT INTO maintenance_technicians (hotel_id, user_id, name, specialties, hourly_rate, external, supplier_id) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
        [hotel.id, uid, n, spec, rate, ext, ext ? sup.ALM : null])).id;
    }
    const mRooms = await q<any>(c, 'SELECT id, number FROM rooms WHERE hotel_id = $1 ORDER BY number', [hotel.id]);
    const eqId: Record<string, number> = {};
    const eqs: [string, string, string, string, number | null, string, string | null, number | null, number][] = [
      ['CLIM-' + mRooms[0].number, `Climatiseur chambre ${mRooms[0].number}`, 'hvac', 'room', mRooms[0].id, 'rooms', 'Condor', 300, 24],
      ['CLIM-' + mRooms[1].number, `Climatiseur chambre ${mRooms[1].number}`, 'hvac', 'room', mRooms[1].id, 'rooms', 'Condor', 300, 24],
      ['CLIM-' + mRooms[2].number, `Climatiseur chambre ${mRooms[2].number}`, 'hvac', 'room', mRooms[2].id, 'rooms', 'LG', 900, 24],
      ['CHAUD-01', 'Chaudière eau chaude sanitaire', 'heating', 'technical', null, 'technical', 'Saunier Duval', 1200, 24],
      ['ASC-01', 'Ascenseur principal', 'elevator', 'public', null, 'technical', 'Schindler', 1500, 12],
      ['FOUR-01', 'Four mixte cuisine', 'kitchen', 'kitchen', null, 'restaurant', 'Rational', 400, 24],
      ['CHF-01', 'Chambre froide positive', 'kitchen', 'kitchen', null, 'restaurant', 'Frigo Oran', 800, 12],
      ['POMPE-PIS', 'Pompe de filtration piscine', 'plumbing', 'pool', null, 'leisure', 'Hayward', 200, 24],
      ['SRV-01', 'Serveur PMS / réseau', 'it', 'technical', null, 'admin', 'Dell', 100, 36],
      ['SSI-01', 'Centrale incendie', 'fire_safety', 'technical', null, 'technical', 'Siemens', 2000, 24],
      ['TABLE-REC', 'Comptoir réception', 'furniture', 'reception', null, 'reception', null, 1800, 0],
    ];
    for (const [code, name, cat, loc, roomId, dept, brand, ageDays, warranty] of eqs) {
      eqId[code] = (await one<any>(c, `INSERT INTO equipment (hotel_id, code, name, category, location_type, room_id, department, brand, purchase_date, install_date, warranty_months, supplier_id, critical, serial_no)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9,$10,$11,$12,$13) RETURNING id`,
        [hotel.id, code, name, cat, loc, roomId, dept, brand, addDays(T, -(ageDays ?? 365)), warranty, sup.ALM, ['ASC-01', 'SSI-01', 'CHF-01'].includes(code), `SN-${Math.floor(rand() * 1e6)}`])).id;
    }
    for (const [name, code, freq, due, t, list] of [
      ['Nettoyage filtres climatiseurs', 'CLIM-' + mRooms[0].number, 'monthly', addDays(T, 1), tech.y, ['Démonter et laver les filtres', 'Contrôler l\'écoulement', 'Tester le froid']],
      ['Visite réglementaire ascenseur', 'ASC-01', 'monthly', addDays(T, -2), tech.m, ['Freins', 'Portes palières', 'Alarme cabine']],
      ['Contrôle légionellose ECS', 'CHAUD-01', 'quarterly', addDays(T, 12), tech.o, ['Température > 55 °C', 'Purge des points morts']],
      ['Vérification extincteurs et SSI', 'SSI-01', 'yearly', addDays(T, 45), tech.m, ['Pression extincteurs', 'Test centrale']],
      ['Dégivrage chambre froide', 'CHF-01', 'weekly', T, tech.x, ['Dégivrer', 'Relever la température']],
    ] as const) {
      await c.query(`INSERT INTO maintenance_plans (hotel_id, name, equipment_id, frequency, next_due, alert_days, technician_id, checklist, estimated_minutes, created_by) VALUES ($1,$2,$3,$4,$5,3,$6,$7,45,$8)`,
        [hotel.id, name, eqId[code], freq, due, t, JSON.stringify(list), admin.id]);
    }
    const all = new Set(Object.keys(PERMISSIONS));
    // panne résolue et validée (pièce sortie du stock, temps passé)
    const mf1 = await declareFault(c, actor, all, { title: 'Éclairage couloir 1er étage HS', priority: 'normal', location: 'Couloir 1er étage', category: 'electrical', source: 'housekeeping' });
    const mw1 = await assignTicket(c, actor, mf1.id, tech.y);
    await woAction(c, actor, all, mw1.id, { action: 'start' });
    await addTime(c, actor, all, mw1.id, { minutes: 50, technician_id: tech.y });
    await addPart(c, actor, all, mw1.id, { product_id: sp['EQP-AMP'], quantity: 4 });
    await completeWorkOrder(c, actor, all, mw1.id, { result: '4 ampoules LED remplacées, circuit contrôlé', outcome: 'fixed' });
    await validateWorkOrder(c, actor, mw1.id, { rating: 5 });
    // panne critique en cours sur la chambre froide
    const mf2 = await declareFault(c, actor, all, { title: 'Température chambre froide à +9 °C', priority: 'urgent', equipment_id: eqId['CHF-01'], source: 'restaurant' });
    const mw2 = await assignTicket(c, actor, mf2.id, tech.x);
    await woAction(c, actor, all, mw2.id, { action: 'start' });
    // panne en attente de pièce
    const mf3 = await declareFault(c, actor, all, { title: 'Pompe piscine bruyante, débit faible', priority: 'high', equipment_id: eqId['POMPE-PIS'] });
    const mw3 = await assignTicket(c, actor, mf3.id, tech.o);
    await woAction(c, actor, all, mw3.id, { action: 'start' });
    await addTime(c, actor, all, mw3.id, { minutes: 40, technician_id: tech.o });
    await woAction(c, actor, all, mw3.id, { action: 'hold', reason: 'Garniture mécanique à commander', parts: true });
    // nouvelles pannes déclarées par la réception, dont une chambre bloquée
    await declareFault(c, actor, all, { title: 'Clim ne refroidit plus', priority: 'high', equipment_id: eqId['CLIM-' + mRooms[2].number], source: 'reception' });
    await declareFault(c, actor, all, { title: 'Porte d\'ascenseur lente à la fermeture', priority: 'normal', equipment_id: eqId['ASC-01'] });
    for (const r of [...mRooms].reverse()) {
      try {
        await c.query('SAVEPOINT blk');
        await declareFault(c, actor, all, { title: 'Infiltration d\'eau salle de bain', priority: 'high', room_id: r.id, category: 'plumbing', source: 'housekeeping', block_room: { end_date: addDays(T, 4) } });
        await c.query('RELEASE SAVEPOINT blk');
        break;
      } catch { await c.query('ROLLBACK TO SAVEPOINT blk'); }
    }
    // historique : quelques pannes résolues les semaines passées
    for (const [days, title, code, mins] of [[18, 'Disjoncteur cuisine saute', 'FOUR-01', 70], [11, 'Pression eau chaude insuffisante', 'CHAUD-01', 30], [6, 'Switch réseau bloqué', 'SRV-01', 25]] as const) {
      const f = await declareFault(c, actor, all, { title, priority: 'normal', equipment_id: eqId[code] });
      const w = await assignTicket(c, actor, f.id, code === 'SRV-01' ? tech.y : tech.o);
      await woAction(c, actor, all, w.id, { action: 'start' });
      await addTime(c, actor, all, w.id, { minutes: mins, technician_id: code === 'SRV-01' ? tech.y : tech.o });
      await completeWorkOrder(c, actor, all, w.id, { result: 'Réparé et testé', outcome: 'fixed' });
      await validateWorkOrder(c, actor, w.id, { rating: 4 });
      await c.query(`UPDATE maintenance_tickets SET created_at = created_at - make_interval(days => $2), resolved_at = resolved_at - make_interval(days => $2) + interval '5 hours', closed_at = closed_at - make_interval(days => $2) + interval '6 hours', due_at = due_at - make_interval(days => $2) WHERE id = $1`, [f.id, days]);
      await c.query(`UPDATE work_orders SET created_at = created_at - make_interval(days => $2), completed_at = completed_at - make_interval(days => $2) + interval '5 hours', validated_at = validated_at - make_interval(days => $2) + interval '6 hours' WHERE id = $1`, [w.id, days]);
    }
    await generatePreventive(c, actor);

    // 6 ter) Ressources humaines : fiches liées aux comptes existants, contrats, planning, pointages, congés, paie du mois précédent
    const hrPw = await hashPassword('Rh2026!');
    for (const [u, n, role] of [['samia', 'Samia Larbi', 'hr_manager'], ['rachid', 'Rachid Toumi', 'dept_head'], ['borne', 'Borne de pointage', 'hr_terminal']]) {
      const r = await one<any>(c, 'SELECT id FROM roles WHERE code = $1', [role]);
      await c.query(`INSERT INTO users (hotel_id, username, full_name, password_hash, role_id) VALUES ($1,$2,$3,$4,$5)`, [hotel.id, u, n, hrPw, r.id]);
    }
    const dept: Record<string, string> = { hk_supervisor: 'housekeeping', housekeeping: 'housekeeping', waiter: 'restaurant', chef: 'kitchen', barman: 'bar', rs_manager: 'restaurant', cashier: 'restaurant',
      storekeeper: 'admin', purchaser: 'admin', accountant: 'accounting', maintenance_manager: 'maintenance', technician: 'maintenance', hr_manager: 'admin', dept_head: 'reception' };
    const salary: Record<string, number> = { hk_supervisor: 62000, housekeeping: 42000, waiter: 40000, chef: 85000, barman: 45000, rs_manager: 78000, cashier: 42000, storekeeper: 48000, purchaser: 55000,
      accountant: 70000, maintenance_manager: 80000, technician: 52000, hr_manager: 75000, dept_head: 72000 };
    let mi = 1;
    const empOf: Record<string, number> = {};
    for (const u of await q<any>(c, `SELECT u.id, u.username, u.full_name, u.employee_id, r.code AS role FROM users u JOIN roles r ON r.id = u.role_id WHERE u.hotel_id = $1 AND r.code NOT IN ('admin','hr_terminal') ORDER BY u.id`, [hotel.id])) {
      const [first, ...rest] = String(u.full_name).split(' ');
      const hire = addDays(T, -200 - Math.floor(rand() * 1500));
      let id = u.employee_id;
      const roleName = (await one<any>(c, 'SELECT name FROM roles WHERE code = $1', [u.role])).name;
      if (!id) id = (await one<any>(c, `INSERT INTO employees (hotel_id, first_name, last_name, department, position, hire_date) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`, [hotel.id, first, rest.join(' ') || first, dept[u.role] ?? 'admin', roleName, hire])).id;
      await c.query(`UPDATE employees SET matricule = $2, birth_date = $3, phone = $4, city = 'Oran', hire_date = COALESCE(hire_date, $5), gender = $6 WHERE id = $1`,
        [id, `KH${String(mi++).padStart(3, '0')}`, `${1975 + Math.floor(rand() * 25)}-${String(1 + Math.floor(rand() * 12)).padStart(2, '0')}-${String(1 + Math.floor(rand() * 27)).padStart(2, '0')}`, `05${Math.floor(10000000 + rand() * 89999999)}`, hire, rand() > 0.5 ? 'M' : 'F']);
      await c.query('UPDATE users SET employee_id = $2 WHERE id = $1', [u.id, id]);
      const e = await one<any>(c, 'SELECT * FROM employees WHERE id = $1', [id]);
      const short = rand() < 0.25;
      await createContract(c, actor, id, { kind: short ? 'cdd' : 'cdi', start_date: String(e.hire_date).slice(0, 10), end_date: short ? addDays(T, 10 + Math.floor(rand() * 60)) : null, base_salary: salary[u.role] ?? 45000, position: e.position });
      await c.query('UPDATE employees SET leave_opening = $2 WHERE id = $1', [id, Math.round(rand() * 20)]);
      empOf[u.username] = id;
    }
    // réception : deux réceptionnistes sans compte + chef de réception
    for (const [f, l, sal] of [['Lina', 'Haddad', 58000], ['Sofiane', 'Meziane', 56000]] as const) {
      const e = await one<any>(c, `INSERT INTO employees (hotel_id, matricule, first_name, last_name, department, position, hire_date, birth_date, city) VALUES ($1,$2,$3,$4,'reception','Réceptionniste',$5,$6,'Oran') RETURNING id`,
        [hotel.id, `KH${String(mi++).padStart(3, '0')}`, f, l, addDays(T, -400), `1996-${T.slice(5, 7)}-${f === 'Lina' ? '18' : '03'}`]);
      await createContract(c, actor, e.id, { kind: 'cdi', start_date: addDays(T, -400), base_salary: sal, position: 'Réceptionniste' });
      await c.query('UPDATE employees SET leave_opening = 12 WHERE id = $1', [e.id]);
      empOf[f] = e.id;
    }
    await c.query(`UPDATE hr_departments SET manager_employee_id = $2 WHERE hotel_id = $1 AND code = 'reception'`, [hotel.id, empOf.rachid]);
    await c.query(`UPDATE hr_departments SET manager_employee_id = $2 WHERE hotel_id = $1 AND code = 'maintenance'`, [hotel.id, empOf.mourad]);
    await c.query(`UPDATE hr_departments SET manager_employee_id = $2 WHERE hotel_id = $1 AND code = 'housekeeping'`, [hotel.id, empOf.nadia]);
    await c.query(`UPDATE employees SET pin_hash = $1`, [await hashPassword('1234')]);
    // planning : rotations par département sur 3 semaines (à partir de lundi dernier)
    const monday = addDays(T, -((new Date(`${T}T00:00:00Z`).getUTCDay() + 6) % 7) - 7);
    const groups = await q<any>(c, `SELECT department, array_agg(id ORDER BY id) AS ids FROM employees WHERE hotel_id = $1 AND status = 'active' GROUP BY department`, [hotel.id]);
    for (const g of groups) {
      const pattern = ['reception', 'restaurant', 'bar'].includes(g.department) ? ['M', 'M', 'S', 'S', 'R', 'N', 'R'] : ['J', 'J', 'J', 'J', 'J', 'R', 'R'];
      await applyRotation(c, actor, { employee_ids: g.ids, start_date: monday, end_date: addDays(monday, 20), pattern, offset_per_employee: 2 });
    }
    // pointages des 7 derniers jours (quelques retards et heures sup.)
    for (const sh of await q<any>(c, `SELECT * FROM hr_schedule WHERE hotel_id = $1 AND NOT rest AND work_date BETWEEN $2::date - 7 AND $2::date - 1`, [hotel.id, T])) {
      if (rand() < 0.06) continue; // absence
      const late = rand() < 0.15 ? 8 + Math.floor(rand() * 25) : -Math.floor(rand() * 8);
      const extra = rand() < 0.2 ? 30 + Math.floor(rand() * 90) : Math.floor(rand() * 10);
      const d = String(sh.work_date).slice(0, 10);
      const r = await one<any>(c, `INSERT INTO hr_attendance (hotel_id, employee_id, work_date, clock_in, clock_out, break_minutes, source, created_by)
          VALUES ($1,$2,$3, (($3::date + $4::time) AT TIME ZONE $8) + make_interval(mins => $5), (($3::date + $6::time) AT TIME ZONE $8) + CASE WHEN $6::time <= $4::time THEN interval '1 day' ELSE interval '0' END + make_interval(mins => $7), $9, 'terminal', $10)
          ON CONFLICT DO NOTHING RETURNING id`, [hotel.id, sh.employee_id, d, sh.start_time, late, sh.end_time, extra, 'Africa/Algiers', sh.break_minutes, admin.id]);
      if (r) await recomputeAttendance(c, r.id);
    }
    // congés : un validé en cours, un en attente
    const all2 = new Set(Object.keys(PERMISSIONS));
    const sc = { all: true, departments: [], employeeId: null, salary: true, personal: true };
    await requestLeave(c, actor, all2, { employee_id: empOf.Sofiane, type_code: 'annual', start_date: addDays(T, 1), end_date: addDays(T, 5), reason: 'Mariage d\'un proche', approve: true }, sc);
    await requestLeave(c, actor, all2, { employee_id: empOf.Lina, type_code: 'annual', start_date: addDays(T, 20), end_date: addDays(T, 26), reason: 'Vacances' }, sc);
    await requestLeave(c, actor, all2, { employee_id: empOf.karim, type_code: 'sick', start_date: addDays(T, -1), end_date: addDays(T, 1), reason: 'Certificat médical', approve: true }, sc);
    await c.query(`INSERT INTO hr_pay_items (hotel_id, employee_id, kind, label, amount, taxable, contributory, recurring, created_by) SELECT $1, id, 'allowance', 'Indemnité de panier', 3000, false, false, true, $2 FROM employees WHERE hotel_id = $1`, [hotel.id, admin.id]);
    await c.query(`INSERT INTO hr_documents (hotel_id, employee_id, kind, title, expiry_date, confidential, created_by) VALUES ($1,$2,'Certificat médical','Aptitude médicale annuelle',$3,true,$4), ($1,$5,'Carte professionnelle','Carte d''hygiène alimentaire',$6,true,$4)`,
      [hotel.id, empOf.Lina, addDays(T, 12), admin.id, empOf.chef, addDays(T, -3)]);
    await c.query(`INSERT INTO hr_evaluations (hotel_id, employee_id, period, evaluator_id, criteria, score, manager_comment, status) VALUES ($1,$2,'2026-S1',$3,'[{"label":"Accueil","score":5},{"label":"Ponctualité","score":4},{"label":"Rigueur","score":4}]',4.33,'Très bon élément','final')`,
      [hotel.id, empOf.Lina, admin.id]);
    const prev = (() => { const d = new Date(`${T.slice(0, 7)}-01T00:00:00Z`); d.setUTCMonth(d.getUTCMonth() - 1); return d.toISOString().slice(0, 7); })();
    const run = await computePayroll(c, actor, prev);
    await validatePayroll(c, actor, run.id);

    // 6 quater) CRM : statuts, programme de fidélité, préférences, entreprise, réclamations, enquêtes, segment et campagne
    const crmPw = await hashPassword('Crm2026!');
    { const r = await one<any>(c, `SELECT id FROM roles WHERE code = 'crm_manager'`); await c.query(`INSERT INTO users (hotel_id, username, full_name, password_hash, role_id) VALUES ($1,'nadir','Nadir Hamel',$2,$3)`, [hotel.id, crmPw, r.id]); }
    const persons = await q<any>(c, `SELECT g.id, (SELECT count(*) FROM stays s WHERE s.guest_id = g.id)::int AS n FROM guests g WHERE g.hotel_id = $1 AND g.kind = 'person' ORDER BY n DESC, g.id`, [hotel.id]);
    for (const p of persons) await crmRefreshStatus(c, p.id);
    await c.query(`UPDATE guests SET consent_email = (random() < 0.6), consent_updated_at = now(), email = COALESCE(email, lower(regexp_replace(coalesce(last_name,'client'), '[^a-zA-Z]', '', 'g')) || id || '@exemple.dz'),
        birth_date = COALESCE(birth_date, DATE '1970-01-01' + (random() * 11000)::int), country = COALESCE(country, CASE WHEN random() < 0.8 THEN 'Algérie' ELSE 'France' END) WHERE hotel_id = $1 AND kind = 'person'`, [hotel.id]);
    for (const p of persons.slice(0, Math.min(18, persons.length))) {
      await crmEnroll(c, actor, p.id);
      for (const st of await q<any>(c, `SELECT rr.id FROM stays s JOIN reservation_rooms rr ON rr.id = s.reservation_room_id WHERE s.guest_id = $1 AND s.checked_out_at IS NOT NULL`, [p.id])) await crmEarnForStay(c, actor, st.id);
    }
    if (persons[0]) {
      await c.query(`UPDATE guests SET crm_status = 'vip', status_locked = true WHERE id = $1`, [persons[0].id]);
      await c.query(`INSERT INTO loyalty_transactions (hotel_id, guest_id, kind, points, remaining, description, expires_at) VALUES ($1,$2,'bonus',2200,2200,'Bonus de bienvenue VIP',CURRENT_DATE + 700)`, [hotel.id, persons[0].id]);
      await crmRefreshTier(c, persons[0].id);
      for (const [cat, val] of [['room', 'Chambre calme, étage élevé'], ['dietary', 'Sans gluten (communiqué par le client)'], ['service', 'Journal El Watan le matin'], ['habit', 'Arrive souvent tard (après 22 h)']]) {
        await c.query(`INSERT INTO guest_preferences (guest_id, category, value, created_by) VALUES ($1,$2,$3,$4)`, [persons[0].id, cat, val, admin.id]);
      }
      await c.query(`INSERT INTO guest_preferences (guest_id, category, value, event_date, recurring, created_by) VALUES ($1,'occasion','Anniversaire de mariage',$2,true,$3)`, [persons[0].id, `2012-${addDays(T, 6).slice(5)}`, admin.id]);
    }
    const co = await one<any>(c, `SELECT id FROM guests WHERE hotel_id = $1 AND kind = 'company' ORDER BY id LIMIT 1`, [hotel.id]);
    if (co) {
      await c.query(`UPDATE guests SET sector = 'Conseil', payment_terms_days = 30, credit_limit = 400000, email = COALESCE(email, 'compta@atlas-conseil.dz'), phone = COALESCE(phone, '041 33 22 11') WHERE id = $1`, [co.id]);
      await c.query(`INSERT INTO crm_contacts (company_id, name, role, phone, email, is_billing, is_booker) VALUES ($1,'Mme Amel Rahmani','Assistante de direction','0550 44 55 66','reservations@atlas-conseil.dz',false,true), ($1,'M. Karim Bensaid','Comptable','041 33 22 12','compta@atlas-conseil.dz',true,false)`, [co.id]);
      await c.query(`INSERT INTO crm_contracts (hotel_id, company_id, number, title, start_date, end_date, room_nights_commitment, payment_terms_days, credit_limit, terms, created_by) VALUES ($1,$2,'AC${T.slice(0, 4)}-0001','Accord-cadre hébergement',$3,$4,120,30,400000,'Tarif négocié -15 % sur la chambre, petit-déjeuner inclus, facturation mensuelle.',$5)`,
        [hotel.id, co.id, addDays(T, -60), addDays(T, 305), admin.id]);
      for (const p of persons.slice(5, 8)) await c.query('UPDATE guests SET company_id = $2, job_title = $3 WHERE id = $1', [p.id, co.id, 'Consultant']);
    }
    const sv = await one<any>(c, `SELECT id FROM crm_surveys WHERE hotel_id = $1 LIMIT 1`, [hotel.id]);
    for (const r of await q<any>(c, `SELECT id, guest_id FROM reservations WHERE hotel_id = $1 AND status = 'checked_out' ORDER BY id LIMIT 12`, [hotel.id])) {
      const resp = await crmEnsureSurvey(c, actor, sv.id, r.id, r.guest_id);
      const n = () => 3 + Math.floor(rand() * 3);
      await crmSubmitSurvey(c, resp.token, { welcome: n(), room: n(), clean: n(), food: n(), value: n(), nps: 6 + Math.floor(rand() * 5), return: rand() > 0.2 }, rand() > 0.6 ? 'Très bon séjour, personnel accueillant.' : null, admin.id);
    }
    const g2 = persons[2]?.id ?? persons[0]?.id;
    if (g2) {
      const c1 = await crmCreateComplaint(c, actor, { guest_id: g2, category: 'noise', priority: 'high', title: 'Bruit dans le couloir la nuit', description: 'Le client signale du bruit après minuit au 2e étage.' });
      await crmComplaintAction(c, actor, c1.id, { action: 'response', text: 'Excuses présentées, rappel des consignes à l\'équipe de nuit.' });
      await crmCreateComplaint(c, actor, { guest_id: persons[3]?.id ?? g2, category: 'billing', priority: 'normal', title: 'Écart sur la facture du minibar' });
      await crmCreateComplaint(c, actor, { guest_id: persons[1]?.id ?? g2, category: 'staff', kind: 'compliment', priority: 'low', title: 'Félicitations à la réception pour l\'accueil' });
    }
    const seg = await one<any>(c, `INSERT INTO crm_segments (hotel_id, name, criteria, created_by) VALUES ($1,'Clients fidèles consentants','{"kinds":["person"],"min_stays":1,"marketing_consent":true}',$2) RETURNING id`, [hotel.id, admin.id]);
    await c.query(`INSERT INTO crm_segments (hotel_id, name, criteria, created_by) VALUES ($1,'Clients inactifs depuis 6 mois','{"kinds":["person"],"inactive_days":180}',$2), ($1,'Clients étrangers','{"countries":["France"]}',$2)`, [hotel.id, admin.id]);
    const promo = await one<any>(c, `SELECT id FROM crm_templates WHERE hotel_id = $1 AND code = 'promo' LIMIT 1`, [hotel.id]);
    await c.query(`INSERT INTO crm_campaigns (hotel_id, name, segment_id, template_id, created_by) VALUES ($1,'Offre week-end d''hiver',$2,$3,$4)`, [hotel.id, seg.id, promo.id, admin.id]);

    // 6 quater) Historique housekeeping (rapports) : ménage de départ réalisé et inspecté pour chaque départ passé
    {
      const hk = await q<any>(c, `SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id WHERE u.hotel_id = $1 AND r.code = 'housekeeping' ORDER BY u.id`, [hotel.id]);
      const sup = await one<any>(c, `SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id WHERE u.hotel_id = $1 AND r.code = 'hk_supervisor' LIMIT 1`, [hotel.id]);
      const deps = await q<any>(c, `SELECT rr.id, rr.room_id, rr.check_out FROM reservation_rooms rr JOIN reservations res ON res.id = rr.reservation_id
          WHERE res.hotel_id = $1 AND rr.status = 'checked_out' AND rr.check_out < $2 AND rr.room_id IS NOT NULL ORDER BY rr.check_out`, [hotel.id, T]);
      for (const d of deps) {
        if (!hk.length) break;
        const by = pick(hk).id;
        const start = new Date(`${String(d.check_out instanceof Date ? d.check_out.toISOString() : d.check_out).slice(0, 10)}T09:30:00Z`);
        start.setUTCMinutes(start.getUTCMinutes() + Math.floor(rand() * 240));
        const done = new Date(start.getTime() + (22 + Math.floor(rand() * 30)) * 60000);
        const due = new Date(start.getTime() + 45 * 60000);
        const failed = rand() < 0.08;
        const t = await one<any>(c, `INSERT INTO housekeeping_tasks (room_id, reservation_room_id, kind, status, assigned_to, task_date, priority, source, started_at, completed_at, completed_by, due_at, inspected_by, inspected_at, refusal_count, created_by)
            VALUES ($1,$2,'checkout_clean','validated',$3,$4,'normal','auto',$5,$6,$3,$7,$8,$9,$10,$8) RETURNING id`,
          [d.room_id, d.id, by, d.check_out, start, done, due, sup?.id ?? null, new Date(done.getTime() + 20 * 60000), failed ? 1 : 0]);
        if (failed) await c.query(`INSERT INTO hk_inspections (task_id, room_id, inspector_id, result, score, items, remarks, created_at) VALUES ($1,$2,$3,'failed',2,'[]','Salle de bain à reprendre',$4)`, [t.id, d.room_id, sup?.id ?? null, new Date(done.getTime() + 10 * 60000)]);
        await c.query(`INSERT INTO hk_inspections (task_id, room_id, inspector_id, result, score, items, remarks, created_at) VALUES ($1,$2,$3,'passed',$4,'[]',NULL,$5)`, [t.id, d.room_id, sup?.id ?? null, 4 + Math.floor(rand() * 2), new Date(done.getTime() + 20 * 60000)]);
      }
    }

    // 7) Caisse du jour ouverte + dépenses
    await c.query(`DELETE FROM settings WHERE hotel_id = $1 AND key = 'cash_session_required'`, [hotel.id]);
    const reg = await one<any>(c, 'SELECT id FROM cash_registers WHERE hotel_id = $1 LIMIT 1', [hotel.id]);
    await c.query(`INSERT INTO cash_sessions (cash_register_id, opened_by, opening_amount) VALUES ($1,$2,20000)`, [reg.id, admin.id]);
    for (let i = 0; i < 12; i++) {
      await c.query(`INSERT INTO expenses (hotel_id, category, description, amount, method, expense_date, created_by) VALUES ($1,$2,$3,$4,'cash',$5,$6)`,
        [hotel.id, pick(['Fournitures', 'Entretien', 'Restauration', 'Énergie']), 'Dépense de démonstration', 1500 + Math.floor(rand() * 9000), addDays(T, -Math.floor(rand() * 20)), admin.id]);
    }
  });
  // Night audit : dates opérationnelles de l'historique de démonstration, puis clôtures réelles de J-3 et J-2 ; J-1 reste à auditer
  await tx(async (c) => {
    const tabs: [string, string][] = [['payments', 'received_at'], ['incomes', 'created_at'], ['expenses', 'created_at'], ['invoices', 'issued_at'], ['rs_orders', 'created_at'], ['refunds', 'created_at'], ['cash_movements', 'created_at']];
    const trig: Record<string, string[]> = { payments: ['payments_guard'], incomes: ['incomes_guard'], expenses: ['expenses_guard'], invoices: ['invoices_guard'], refunds: ['refunds_immutable'], cash_movements: ['cash_movements_immutable'], rs_orders: [] };
    for (const [t, col] of tabs) {
      for (const g of trig[t]) await c.query(`ALTER TABLE ${t} DISABLE TRIGGER ${g}`);
      await c.query(`UPDATE ${t} SET business_date = (${col} AT TIME ZONE 'Africa/Algiers')::date`);
      for (const g of trig[t]) await c.query(`ALTER TABLE ${t} ENABLE TRIGGER ${g}`);
    }
    await c.query(`UPDATE charges SET business_date = service_date`);
    await c.query(`INSERT INTO audit_days (hotel_id, business_date, opened_by) VALUES ($1,$2,$3)`, [hotel.id, addDays(T, -3), admin.id]);
    const na = await import('../services/nightaudit.js');
    const perms = new Set(['nightaudit.correct']);
    for (let i = 0; i < 2; i++) {
      let day = await na.currentDay(c, hotel.id, admin.id);
      await na.postRevenue(c, actor, day);
      await na.runChecks(c, actor, day);
      for (const a of await q<any>(c, `SELECT id, code FROM audit_anomalies WHERE audit_day_id = $1 AND status = 'open' AND severity <> 'info'`, [day.id])) {
        await na.anomalyAction(c, actor, perms, day, a.id, { action: 'accept', text: 'Reprise de l\'historique de démonstration (contrôlé)' }).catch(() => {});
      }
      day = await na.currentDay(c, hotel.id, admin.id);
      await na.validateDay(c, actor, day, 'Clôture de démonstration');
      await na.closeDay(c, actor, { confirm: `${String(day.business_date instanceof Date ? day.business_date.toISOString() : day.business_date).slice(0, 10).split('-').reverse().join('/')}` });
    }
  });
  log('✔ Données de démonstration ajoutées.');
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  (async () => {
    await runMigrations();
    if (process.argv.includes('--demo')) {
      // base de DÉMONSTRATION / formation : hôtel fictif « Hôtel K » (40 chambres) + activité simulée — jamais sur la base réelle
      const fresh = !(await one<any>(getPool(), 'SELECT 1 FROM hotels LIMIT 1'));
      const pw = process.env.ADMIN_PASSWORD ?? randomPassword();
      await seedBase({ adminPassword: pw });
      await seedDemo();
      if (fresh) {
        const dir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../data');
        mkdirSync(dir, { recursive: true });
        writeFileSync(path.join(dir, 'IDENTIFIANTS-DEMO.txt'), `Base de DÉMONSTRATION (données fictives)\nIdentifiant : admin\nMot de passe : ${pw}\n`);
        console.log(`Identifiants de démonstration enregistrés dans server/data/IDENTIFIANTS-DEMO.txt`);
      }
    } else {
      // installation réelle : uniquement la structure, les rôles et les permissions ; l'hôtel est créé par l'assistant de première installation
      await tx(async (c) => syncRolesAndPermissions(c));
      const h = await one<any>(getPool(), 'SELECT name FROM hotels ORDER BY id LIMIT 1');
      console.log(h ? `Hôtel « ${h.name} » déjà configuré : base à jour.` : 'Base prête. Démarrez KAYN Hotel puis ouvrez l\'adresse affichée : l\'assistant de première installation s\'ouvre (code d\'installation affiché par le serveur).');
    }
    await closePool();
  })().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
