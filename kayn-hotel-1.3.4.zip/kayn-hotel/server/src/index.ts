/**
 * Point d'entrée de KAYN Hotel (lancé par les scripts Windows : node dist\index.js).
 * 1) Installe une mise à jour préparée depuis Administration → Mises à jour (data/updates/pending.json) :
 *    contrôle d'empreinte, copie de l'ancienne version dans data/updates/rollback, remplacement des fichiers,
 *    npm install si les composants ont changé. Les données (server/data), la configuration (.env),
 *    node_modules et les scripts .bat (en cours d'exécution) ne sont jamais remplacés.
 * 2) Si la nouvelle version ne démarre pas 3 fois de suite → retour automatique à l'ancienne.
 * 3) Démarre le serveur (main.js).
 * Ce fichier n'importe que des modules Node intégrés : il fonctionne même si le reste est endommagé.
 */
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SERVER = fileURLToPath(new URL('..', import.meta.url));
const ROOT = path.dirname(path.resolve(SERVER));
const UPD = process.env.UPDATES_DIR ?? path.join(SERVER, 'data', 'updates');
const LOGS = path.join(SERVER, 'data', 'logs');

const log = (m: string) => { const l = `${new Date().toISOString()} [mise à jour] ${m}`; console.log(l); try { fs.mkdirSync(LOGS, { recursive: true }); fs.appendFileSync(path.join(LOGS, 'mises-a-jour.log'), `${l}\n`); } catch { /* */ } };
const readJson = (f: string) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
const writeJson = (f: string, v: unknown) => fs.writeFileSync(f, JSON.stringify(v, null, 1));
const sha256 = (f: string) => createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const rm = (p: string) => fs.rmSync(p, { recursive: true, force: true });

/** Jamais remplacés (chemins relatifs à la racine du projet). */
const KEEP = new Set(['server/data', 'server/.env', 'node_modules', 'server/node_modules', 'web/node_modules', '.git']);
const keep = (e: string) => KEEP.has(e) || /\.(bat|cmd)$/i.test(e);
function entries(src: string) {
  const out: string[] = [];
  for (const a of fs.readdirSync(src)) {
    if (keep(a)) continue;
    if ((a === 'server' || a === 'web') && fs.statSync(path.join(src, a)).isDirectory()) {
      for (const b of fs.readdirSync(path.join(src, a))) if (!keep(`${a}/${b}`)) out.push(`${a}/${b}`);
    } else out.push(a);
  }
  return out;
}
function extract(zip: string, dest: string) {
  rm(dest); fs.mkdirSync(dest, { recursive: true });
  const r = process.platform === 'win32'
    ? spawnSync('tar', ['-xf', zip, '-C', dest], { stdio: 'pipe' })
    : spawnSync('unzip', ['-q', '-o', zip, '-d', dest], { stdio: 'pipe' });
  if (r.status !== 0) throw new Error(`extraction impossible : ${String(r.stderr || r.error || '').slice(0, 300)}`);
  const top = fs.readdirSync(dest);
  return top.length === 1 && fs.statSync(path.join(dest, top[0])).isDirectory() ? path.join(dest, top[0]) : dest;
}
function npmInstall() {
  const cli = path.join(path.dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js');
  const env = { ...process.env, NODE_ENV: '' };
  const r = fs.existsSync(cli)
    ? spawnSync(process.execPath, [cli, 'install', '--no-audit', '--no-fund'], { cwd: ROOT, stdio: 'inherit', env })
    : spawnSync('npm', ['install', '--no-audit', '--no-fund'], { cwd: ROOT, stdio: 'inherit', shell: true, env });
  if (r.status !== 0) throw new Error('npm install a échoué (Internet nécessaire pour les nouveaux composants)');
}
/** Copie sûre sous Windows : copie de l'ancien vers rollback, suppression, copie du nouveau. */
function replace(list: string[], from: string, rb: string | null) {
  for (const e of list) {
    const cur = path.join(ROOT, e);
    if (fs.existsSync(cur)) { if (rb) fs.cpSync(cur, path.join(rb, e), { recursive: true }); rm(cur); }
    const n = path.join(from, e);
    if (fs.existsSync(n)) { fs.mkdirSync(path.dirname(cur), { recursive: true }); fs.cpSync(n, cur, { recursive: true }); }
  }
}
function applyPending() {
  const pf = path.join(UPD, 'pending.json');
  const p = readJson(pf);
  if (!p) return;
  log(`installation de la version ${p.version} (actuelle : ${p.from})…`);
  const staging = path.join(UPD, 'staging');
  const rb = path.join(UPD, 'rollback');
  let list: string[] = [];
  let started = false;
  try {
    if (!fs.existsSync(p.zip) || sha256(p.zip) !== p.sha256) throw new Error('fichier de mise à jour absent ou corrompu');
    const src = extract(p.zip, staging);
    const ver = readJson(path.join(src, 'server', 'package.json'))?.version;
    if (ver !== p.version) throw new Error(`le paquet contient la version ${ver}, ${p.version} attendue`);
    for (const need of ['server/dist/index.js', 'server/dist/main.js', 'web/dist/index.html']) if (!fs.existsSync(path.join(src, need))) throw new Error(`paquet incomplet (${need} manquant)`);
    const lock = path.join(ROOT, 'package-lock.json');
    const lockBefore = fs.existsSync(lock) ? sha256(lock) : '';
    list = [...new Set([...entries(src), ...entries(ROOT).filter((e) => /^(server\/(dist|src|assets)|web\/dist)$/.test(e))])];
    rm(rb); fs.mkdirSync(rb, { recursive: true });
    writeJson(path.join(UPD, 'rollback.json'), { list, from: p.from });
    started = true;
    replace(list, src, rb);
    if ((fs.existsSync(lock) ? sha256(lock) : '') !== lockBefore) { log('nouveaux composants : npm install…'); npmInstall(); }
    writeJson(path.join(UPD, 'boot.json'), { version: p.version, from: p.from, attempts: 0 });
    writeJson(path.join(UPD, 'last.json'), { ok: true, version: p.version, from: p.from, backup: p.backup, by: p.by, at: new Date().toISOString() });
    log(`version ${p.version} installée (sauvegarde de la base faite avant : ${p.backup}).`);
  } catch (e: any) {
    log(`ÉCHEC : ${e.message} — retour à la version ${p.from}.`);
    if (started) try { replace(list, rb, null); } catch (e2: any) { log(`retour arrière incomplet : ${e2.message}`); }
    writeJson(path.join(UPD, 'last.json'), { ok: false, version: p.version, from: p.from, error: e.message, at: new Date().toISOString() });
  } finally {
    rm(pf); rm(staging);
    try { fs.unlinkSync(p.zip); } catch { /* */ }
  }
}
/** Nouvelle version qui ne démarre pas 3 fois de suite → ancienne version rétablie. */
function bootGuard() {
  const bf = path.join(UPD, 'boot.json');
  const b = readJson(bf);
  if (!b) return;
  b.attempts = (b.attempts || 0) + 1;
  if (b.attempts <= 3) { writeJson(bf, b); return; }
  const r = readJson(path.join(UPD, 'rollback.json'));
  log(`la version ${b.version} ne démarre pas : retour à la version ${b.from}.`);
  if (r?.list) try { replace(r.list, path.join(UPD, 'rollback'), null); } catch (e: any) { log(`retour arrière incomplet : ${e.message}`); }
  writeJson(path.join(UPD, 'last.json'), { ok: false, version: b.version, from: b.from, error: 'la nouvelle version ne démarrait pas : ancienne version rétablie automatiquement.', at: new Date().toISOString() });
  rm(bf);
}

try { fs.mkdirSync(UPD, { recursive: true }); applyPending(); bootGuard(); } catch (e: any) { log(`erreur inattendue : ${e.message}`); }
await import('./main.js');
