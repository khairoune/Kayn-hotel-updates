/**
 * KAYN Hotel — superviseur (lancé par 2-DEMARRER.bat, DEMO-KAYN-HOTEL.bat ou la tâche de démarrage automatique).
 *  - lance le serveur (dist/index.js) et le relance automatiquement s'il s'arrête ;
 *  - continue de tourner en arrière-plan : fermer une fenêtre ne l'arrête pas, seul 3-ARRETER.bat l'arrête ;
 *  - applique une mise à jour téléchargée depuis Administration → Mises à jour (data/updates/pending.json),
 *    avec retour automatique à l'ancienne version si l'installation ou le premier démarrage échoue.
 * Les données (server/data), la configuration (server/.env) et node_modules ne sont jamais remplacés.
 * Usage : node start.cjs [--env chemin/fichier.env]
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn, spawnSync } = require('node:child_process');

const SERVER = __dirname;
const ROOT = path.dirname(SERVER);
process.chdir(SERVER);
const DATA = path.join(SERVER, 'data');
const UPD = process.env.UPDATES_DIR || path.join(DATA, 'updates');
const LOGS = path.join(DATA, 'logs');
fs.mkdirSync(UPD, { recursive: true });
fs.mkdirSync(LOGS, { recursive: true });
const STOP = path.join(DATA, 'STOP');

const log = (m) => { const line = `${new Date().toISOString()} ${m}\n`; try { fs.appendFileSync(path.join(LOGS, 'superviseur.log'), line); } catch { /* */ } process.stdout.write(line); };
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
const writeJson = (f, v) => fs.writeFileSync(f, JSON.stringify(v, null, 1));
const sha256 = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const rm = (p) => fs.rmSync(p, { recursive: true, force: true });

// --env fichier : variables de la démonstration (ou d'une installation particulière)
{
  const i = process.argv.indexOf('--env');
  if (i > 0 && process.argv[i + 1]) {
    const f = path.resolve(SERVER, process.argv[i + 1]);
    for (const l of (fs.existsSync(f) ? fs.readFileSync(f, 'utf8') : '').split(/\r?\n/)) {
      const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(l);
      if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2];
    }
  }
}

// ===== Mise à jour =====
/** Éléments jamais remplacés (relatifs à la racine du projet). */
const KEEP = new Set(['server/data', 'server/.env', 'node_modules', 'server/node_modules', 'web/node_modules', '.git']);
/** Liste des chemins (fichiers/dossiers de 1er niveau, et 2e niveau pour server/ et web/) livrés par la mise à jour. */
function entries(src) {
  const out = [];
  for (const a of fs.readdirSync(src)) {
    if (KEEP.has(a)) continue;
    if ((a === 'server' || a === 'web') && fs.statSync(path.join(src, a)).isDirectory()) {
      for (const b of fs.readdirSync(path.join(src, a))) if (!KEEP.has(`${a}/${b}`)) out.push(`${a}/${b}`);
    } else out.push(a);
  }
  return out;
}
function extract(zip, dest) {
  rm(dest); fs.mkdirSync(dest, { recursive: true });
  const r = process.platform === 'win32'
    ? spawnSync('tar', ['-xf', zip, '-C', dest], { stdio: 'pipe' })
    : spawnSync('unzip', ['-q', '-o', zip, '-d', dest], { stdio: 'pipe' });
  if (r.status !== 0) throw new Error(`extraction impossible : ${String(r.stderr || r.error || '').slice(0, 300)}`);
  const top = fs.readdirSync(dest);
  return top.length === 1 && fs.statSync(path.join(dest, top[0])).isDirectory() ? path.join(dest, top[0]) : dest;
}
function npmInstall() {
  const cli = path.join(path.dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js');
  const r = fs.existsSync(cli)
    ? spawnSync(process.execPath, [cli, 'install', '--no-audit', '--no-fund'], { cwd: ROOT, stdio: 'inherit', env: { ...process.env, NODE_ENV: '' } })
    : spawnSync('npm', ['install', '--no-audit', '--no-fund'], { cwd: ROOT, stdio: 'inherit', shell: true, env: { ...process.env, NODE_ENV: '' } });
  if (r.status !== 0) throw new Error('npm install a échoué (connexion Internet nécessaire pour les nouveaux composants)');
}
/** Remet l'ancienne version (dossier rollback) en place. */
function rollback(rb, list) {
  for (const e of list) {
    const cur = path.join(ROOT, e), old = path.join(rb, e);
    rm(cur);
    if (fs.existsSync(old)) { fs.mkdirSync(path.dirname(cur), { recursive: true }); fs.renameSync(old, cur); }
  }
}
function applyPending() {
  const pf = path.join(UPD, 'pending.json');
  const p = readJson(pf);
  if (!p) return;
  log(`Mise à jour ${p.from} → ${p.version} : installation…`);
  const staging = path.join(UPD, 'staging');
  const rb = path.join(UPD, 'rollback');
  let list = [];
  let moved = false;
  try {
    if (!fs.existsSync(p.zip) || sha256(p.zip) !== p.sha256) throw new Error('fichier de mise à jour absent ou corrompu');
    const src = extract(p.zip, staging);
    const ver = readJson(path.join(src, 'server', 'package.json'))?.version;
    if (ver !== p.version) throw new Error(`le paquet contient la version ${ver}, ${p.version} attendue`);
    for (const need of ['server/dist/index.js', 'server/start.cjs', 'web/dist/index.html']) if (!fs.existsSync(path.join(src, need))) throw new Error(`paquet incomplet (${need} manquant)`);
    const lockBefore = fs.existsSync(path.join(ROOT, 'package-lock.json')) ? sha256(path.join(ROOT, 'package-lock.json')) : '';
    list = [...new Set([...entries(src), ...entries(ROOT).filter((e) => /^(server\/(dist|src|assets|start\.cjs)|web\/dist)$/.test(e))])];
    rm(rb); fs.mkdirSync(rb, { recursive: true });
    moved = true;
    for (const e of list) {
      const cur = path.join(ROOT, e);
      if (fs.existsSync(cur)) { fs.mkdirSync(path.dirname(path.join(rb, e)), { recursive: true }); fs.renameSync(cur, path.join(rb, e)); }
      if (fs.existsSync(path.join(src, e))) { fs.mkdirSync(path.dirname(cur), { recursive: true }); fs.cpSync(path.join(src, e), cur, { recursive: true }); }
    }
    writeJson(path.join(rb, 'list.json'), list);
    const lockAfter = fs.existsSync(path.join(ROOT, 'package-lock.json')) ? sha256(path.join(ROOT, 'package-lock.json')) : '';
    if (lockAfter !== lockBefore) { log('Nouveaux composants : npm install…'); npmInstall(); }
    writeJson(path.join(UPD, 'boot.json'), { version: p.version, from: p.from, attempts: 0 });
    writeJson(path.join(UPD, 'last.json'), { ok: true, version: p.version, from: p.from, backup: p.backup, at: new Date().toISOString(), by: p.by });
    log(`Mise à jour ${p.version} installée (sauvegarde de la base : ${p.backup}).`);
  } catch (e) {
    log(`ÉCHEC de la mise à jour : ${e.message} — retour à la version ${p.from}.`);
    if (moved) try { rollback(rb, list); } catch (e2) { log(`Retour arrière incomplet : ${e2.message}`); }
    writeJson(path.join(UPD, 'last.json'), { ok: false, version: p.version, from: p.from, error: e.message, at: new Date().toISOString() });
  } finally {
    rm(pf); rm(staging);
    try { if (fs.existsSync(p.zip)) fs.unlinkSync(p.zip); } catch { /* */ }
  }
}
/** La nouvelle version ne démarre pas (3 échecs) → retour à l'ancienne. */
function bootGuard() {
  const bf = path.join(UPD, 'boot.json');
  const b = readJson(bf);
  if (!b) return;
  b.attempts = (b.attempts || 0) + 1;
  if (b.attempts <= 3) { writeJson(bf, b); return; }
  const rb = path.join(UPD, 'rollback');
  const list = readJson(path.join(rb, 'list.json')) || [];
  log(`La version ${b.version} ne démarre pas : retour à la version ${b.from}.`);
  try { rollback(rb, list); } catch (e) { log(`Retour arrière incomplet : ${e.message}`); }
  writeJson(path.join(UPD, 'last.json'), { ok: false, version: b.version, from: b.from, error: 'la nouvelle version ne démarrait pas : ancienne version rétablie (la sauvegarde faite avant installation permet de revenir aussi pour la base).', at: new Date().toISOString() });
  rm(bf);
}

// ===== Supervision =====
let child = null;
let stopping = false;
const stop = () => {
  if (stopping) return; stopping = true;
  log('Arrêt demandé.');
  try { fs.unlinkSync(STOP); } catch { /* */ }
  if (child) { try { child.kill(); } catch { /* */ } setTimeout(() => process.exit(0), 4000); } else process.exit(0);
};
try { fs.unlinkSync(STOP); } catch { /* ancien drapeau */ }
fs.writeFileSync(path.join(DATA, 'superviseur.pid'), String(process.pid));
setInterval(() => { if (fs.existsSync(STOP)) stop(); }, 2000);
process.on('SIGINT', stop);
process.on('SIGTERM', stop);

let quickFails = 0;
function launch() {
  if (stopping) return;
  const t0 = Date.now();
  child = spawn(process.execPath, [path.join(SERVER, 'dist', 'index.js')], { cwd: SERVER, stdio: 'inherit', env: { ...process.env, KAYN_SUPERVISED: '1' } });
  child.on('exit', (code) => {
    child = null;
    if (stopping) return process.exit(0);
    if (code === 75) { quickFails = 0; log('Redémarrage pour installer la mise à jour…'); return setImmediate(launch); }
    quickFails = Date.now() - t0 < 60_000 ? quickFails + 1 : 0;
    const wait = fs.existsSync(path.join(UPD, 'boot.json')) ? 3 : Math.min(60, 5 * Math.max(1, quickFails));
    log(`Serveur arrêté (code ${code}) : redémarrage dans ${wait} s. Détails : data/logs/kayn-hotel.log`);
    try { fs.appendFileSync(path.join(LOGS, 'redemarrages.log'), `${new Date().toISOString()} arret code ${code}\n`); } catch { /* */ }
    setTimeout(launch, wait * 1000);
  });
}
log(`Superviseur KAYN Hotel démarré (pid ${process.pid}).`);
launch();
