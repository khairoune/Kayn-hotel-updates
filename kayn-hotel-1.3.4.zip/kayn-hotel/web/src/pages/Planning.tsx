import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Page } from '../components/Layout';
import { NewReservation } from '../components/NewReservation';
import { ReservationPanel } from '../components/ReservationPanel';
import { HK_COLORS, Icon } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { get, patch } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { addDays, diffDays, fmtDate, isWeekend, money, todayLocal } from '../lib/format';
import { useLive } from '../lib/useLive';

type Bar = {
  rr_id: number; reservation_id: number; room_id: number; check_in: string; check_out: string; status: string; rate: number;
  adults: number; room_count: number; booker_name: string; children: number; code: string; booker_type: string; group_name: string | null; guest_name: string; phone: string | null;
  total: number; paid: number; balance: number; meal_plan: string; source: string;
};
type Block = { id: number; room_id: number; kind: 'out_of_service' | 'maintenance'; start_date: string; end_date: string | null; reason: string };
type Room = { id: number; number: string; hk_status: string; out_of_service: boolean; oos_reason: string | null; floor: number; floor_name: string; type_id: number; type_name: string; capacity: number; occupied: boolean };
type Drag = { bar: Bar; mode: 'move' | 'resize'; pos0: number; x0: number; y0: number; moved: boolean; preview: { room_id: number; check_in: string; check_out: string } | null; bad: boolean };

const ACTIVE = ['pending', 'confirmed', 'checked_in', 'checked_out'];

export function Planning() {
  const { t, locale, lang } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const today = todayLocal();
  const [days, setDays] = useState<number>(() => Number(localStorage.getItem('kh.planDays') ?? 14));
  const [from, setFrom] = useState(addDays(today, -1));
  const [data, setData] = useState<{ rooms: Room[]; bars: Bar[]; blocks?: Block[] } | null>(null);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<number | 0>(0);
  const [stFilter, setStFilter] = useState<string | null>(null);
  const [showCancelled, setShowCancelled] = useState(false);
  const [collapsed, setCollapsed] = useState<Record<number, boolean>>({});
  const [panel, setPanel] = useState<number | null>(null);
  const [newRes, setNewRes] = useState<{ room_id?: number; check_in?: string } | null>(null);
  const [tip, setTip] = useState<{ bar: Bar; x: number; y: number } | null>(null);
  const [drag, setDrag] = useState<Drag | null>(null);
  const dragRef = useRef<Drag | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  const W = days === 7 ? 130 : days === 30 ? 46 : 80;
  const rtl = lang === 'ar';

  const load = useCallback(async () => {
    try {
      setData(await get(`/api/planning?from=${from}&days=${days}${showCancelled ? '&include_cancelled=true' : ''}`));
    } catch (e: any) {
      toast('error', e.message);
    }
  }, [from, days, showCancelled]);
  useEffect(() => { load(); }, [load]);
  // synchronisation : modifications faites ailleurs (réservations, autres onglets, autres postes)
  useLive(useCallback(() => { if (!dragRef.current) load(); }, [load]));

  const blocksByRoom = useMemo(() => {
    const m = new Map<number, Block[]>();
    (data?.blocks ?? []).forEach((b) => m.set(b.room_id, [...(m.get(b.room_id) ?? []), b]));
    return m;
  }, [data]);
  const oosOn = (roomId: number, ci: string, co: string) =>
    (blocksByRoom.get(roomId) ?? []).some((b) => b.kind === 'out_of_service' && b.start_date < co && (!b.end_date || ci < b.end_date));
  const dayList = useMemo(() => Array.from({ length: days }, (_, i) => addDays(from, i)), [from, days]);
  const months = useMemo(() => {
    const out: { label: string; n: number }[] = [];
    for (const d of dayList) {
      const label = fmtDate(d, locale, { month: 'long', year: 'numeric' });
      if (out.length && out[out.length - 1].label === label) out[out.length - 1].n++;
      else out.push({ label, n: 1 });
    }
    return out;
  }, [dayList, locale]);

  const rooms = useMemo(() => (data?.rooms ?? []).filter((r) => !typeFilter || r.type_id === typeFilter), [data, typeFilter]);
  const types = useMemo(() => {
    const m = new Map<number, string>();
    data?.rooms.forEach((r) => m.set(r.type_id, r.type_name));
    return [...m.entries()];
  }, [data]);
  const floors = useMemo(() => {
    const m = new Map<number, { name: string; rooms: Room[] }>();
    rooms.forEach((r) => {
      if (!m.has(r.floor)) m.set(r.floor, { name: r.floor_name, rooms: [] });
      m.get(r.floor)!.rooms.push(r);
    });
    return [...m.entries()];
  }, [rooms]);

  const visual = (b: Bar) => {
    if (['cancelled', 'no_show'].includes(b.status)) return b.status;
    if (b.status === 'checked_in' && b.check_out <= today) return 'departure';
    if ((b.status === 'confirmed' || b.status === 'pending') && b.check_in === today) return 'arrival';
    return b.status;
  };

  const free = useMemo(() => dayList.map((d) => {
    const busy = new Set((data?.bars ?? []).filter((b) => ACTIVE.includes(b.status) && b.check_in <= d && b.check_out > d).map((b) => b.room_id));
    return rooms.filter((r) => !oosOn(r.id, d, addDays(d, 1)) && !busy.has(r.id)).length;
  }), [dayList, data, rooms]);

  const q = search.trim().toLowerCase();
  const isHit = (b: Bar) => !!q && (b.guest_name.toLowerCase().includes(q) || b.code.toLowerCase().includes(q) || (b.group_name ?? '').toLowerCase().includes(q));
  const hits = useMemo(() => (data?.bars ?? []).filter(isHit), [data, q]);

  const goToFirstHit = async () => {
    if (!q) return;
    let target = hits[0];
    if (!target) {
      // recherche hors période affichée
      const res = await get(`/api/reservations?search=${encodeURIComponent(search)}`);
      const r = res.rows.find((x: any) => !['cancelled', 'no_show'].includes(x.status)) ?? res.rows[0];
      if (!r) return toast('info', 'Aucune réservation trouvée.');
      setFrom(addDays(r.check_in, -1));
      return;
    }
    const el = document.querySelector(`[data-rr="${target.rr_id}"]`) as HTMLElement | null;
    el?.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
  };

  // ===== Glisser-déposer =====
  const posFromPoint = (x: number, y: number) => {
    const el = (document.elementFromPoint(x, y) as HTMLElement | null)?.closest('[data-room]') as HTMLElement | null;
    if (!el) return null;
    const rect = el.getBoundingClientRect();
    const pos = rtl ? (rect.right - x) / W : (x - rect.left) / W;
    return { room_id: Number(el.dataset.room), pos };
  };

  const startDrag = (e: React.PointerEvent, b: Bar, mode: 'move' | 'resize') => {
    if (e.button !== 0 || !can('reservations.edit')) return;
    if (!['pending', 'confirmed', 'checked_in'].includes(b.status)) return;
    e.stopPropagation();
    const p = posFromPoint(e.clientX, e.clientY);
    if (!p) return;
    const d: Drag = { bar: b, mode, pos0: p.pos, x0: e.clientX, y0: e.clientY, moved: false, preview: null, bad: false };
    dragRef.current = d;
    setTip(null);
  };

  useEffect(() => {
    const move = (e: PointerEvent) => {
      const d = dragRef.current;
      if (!d) return;
      if (!d.moved && Math.abs(e.clientX - d.x0) < 5 && Math.abs(e.clientY - d.y0) < 5) return;
      d.moved = true;
      const p = posFromPoint(e.clientX, e.clientY);
      if (!p) return;
      const b = d.bar;
      let preview: Drag['preview'];
      if (d.mode === 'resize') {
        const startIdx = diffDays(from, b.check_in);
        const endIdx = Math.max(startIdx + 1, Math.round(p.pos - 0.5));
        preview = { room_id: b.room_id, check_in: b.check_in, check_out: addDays(from, endIdx) };
      } else {
        const shift = b.status === 'checked_in' ? 0 : Math.round(p.pos - d.pos0);
        preview = { room_id: p.room_id, check_in: addDays(b.check_in, shift), check_out: addDays(b.check_out, shift) };
      }
      const bad = (data?.bars ?? []).some((o) => o.rr_id !== b.rr_id && ACTIVE.includes(o.status) && o.room_id === preview!.room_id && o.check_in < preview!.check_out && preview!.check_in < o.check_out)
        || (b.status !== 'checked_in' && preview.check_in < today && preview.check_in !== b.check_in)
        || oosOn(preview.room_id, preview.check_in, preview.check_out);
      const next = { ...d, preview, bad };
      dragRef.current = next;
      setDrag(next);
    };
    const up = async () => {
      const d = dragRef.current;
      if (!d) return;
      dragRef.current = null;
      setDrag(null);
      if (!d.moved) {
        setPanel(d.bar.reservation_id);
        return;
      }
      const p = d.preview;
      if (!p || (p.room_id === d.bar.room_id && p.check_in === d.bar.check_in && p.check_out === d.bar.check_out)) return;
      if (d.bad) {
        toast('error', 'Déplacement impossible : chambre occupée, hors service ou date passée.');
        return;
      }
      const body: any = {};
      if (p.room_id !== d.bar.room_id) body.room_id = p.room_id;
      if (p.check_in !== d.bar.check_in) body.check_in = p.check_in;
      if (p.check_out !== d.bar.check_out) body.check_out = p.check_out;
      try {
        await patch(`/api/reservation-rooms/${d.bar.rr_id}`, body);
        const room = data?.rooms.find((r) => r.id === p.room_id);
        toast('success', `${d.bar.guest_name} : chambre ${room?.number}, ${fmtDate(p.check_in, locale)} → ${fmtDate(p.check_out, locale)}`);
      } catch (e: any) {
        toast('error', e.message);
      }
      load();
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
  }, [data, from, W, rtl, rooms, load]);

  const shownBars = useMemo(() => {
    const bars = data?.bars ?? [];
    if (!drag?.preview) return bars;
    return bars.map((b) => (b.rr_id === drag.bar.rr_id ? { ...b, ...drag.preview! } : b));
  }, [data, drag]);

  const barsByRoom = useMemo(() => {
    const m = new Map<number, Bar[]>();
    shownBars.forEach((b) => {
      if (!m.has(b.room_id)) m.set(b.room_id, []);
      m.get(b.room_id)!.push(b);
    });
    return m;
  }, [shownBars]);

  const chipDefs: { k: string; label: Key; cls: string }[] = [
    { k: 'arrival', label: 'st.arrival', cls: 'st-arrival' },
    { k: 'checked_in', label: 'st.checked_in', cls: 'st-checked_in' },
    { k: 'departure', label: 'st.departure', cls: 'st-departure' },
    { k: 'confirmed', label: 'st.confirmed', cls: 'st-confirmed' },
    { k: 'pending', label: 'st.pending', cls: 'st-pending' },
    { k: 'checked_out', label: 'st.checked_out', cls: 'st-checked_out' },
  ];
  const count = (k: string) => (data?.bars ?? []).filter((b) => visual(b) === k).length;
  const gridW = 160 + days * W;

  return (
    <Page fixed>
      <div className="page-head">
        <div style={{ marginInlineEnd: 'auto', minWidth: 0 }}>
          <h1 className="page-title">{t('plan.title')}</h1>
          <div className="page-sub">{fmtDate(today, locale, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })} · {free[diffDays(from, today)] ?? '—'} {t('plan.free')} {t('plan.tonight')}</div>
        </div>
        <div className="row" style={{ gap: 6 }}>
          <button className="btn icon" aria-label="Période précédente" onClick={() => setFrom(addDays(from, -Math.max(1, Math.floor(days / 2))))}><Icon name={rtl ? 'chevR' : 'chevL'} /></button>
          <button className="btn" onClick={() => setFrom(addDays(today, -1))}>{t('common.today')}</button>
          <button className="btn icon" aria-label="Période suivante" onClick={() => setFrom(addDays(from, Math.max(1, Math.floor(days / 2))))}><Icon name={rtl ? 'chevL' : 'chevR'} /></button>
          <input type="date" className="input" style={{ width: 150 }} value={from} onChange={(e) => e.target.value && setFrom(e.target.value)} aria-label="Date de début" />
        </div>
        <div className="seg" role="group" aria-label="Période">
          {[7, 14, 30].map((n) => <button key={n} className={days === n ? 'on' : ''} onClick={() => { setDays(n); localStorage.setItem('kh.planDays', String(n)); }}>{n} j</button>)}
        </div>
        {can('reservations.create') && <button className="btn primary" onClick={() => setNewRes({})}><Icon name="plus" size={16} /> {t('plan.new')}</button>}
      </div>

      <div className="row" style={{ gap: 8 }}>
        <div style={{ position: 'relative' }}>
          <input className="input" style={{ width: 230, paddingInlineStart: 34 }} placeholder={t('plan.searchGuest')} value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && goToFirstHit()} aria-label={t('plan.searchGuest')} />
          <span style={{ position: 'absolute', insetInlineStart: 10, top: 11, color: 'var(--muted)' }}><Icon name="search" size={16} /></span>
        </div>
        {q && <span className="muted" style={{ fontSize: 12 }}>{hits.length} résultat(s) · Entrée pour y aller</span>}
        <select className="input" style={{ width: 170 }} value={typeFilter} onChange={(e) => setTypeFilter(Number(e.target.value))} aria-label="Type de chambre">
          <option value={0}>{t('plan.allTypes')}</option>
          {types.map(([id, name]) => <option key={id} value={id}>{name}</option>)}
        </select>
        {chipDefs.map((c) => (
          <button key={c.k} className={`chip ${stFilter === c.k ? 'on' : ''}`} aria-pressed={stFilter === c.k} onClick={() => setStFilter(stFilter === c.k ? null : c.k)}>
            <span className={`sw ${c.cls}`} />{t(c.label)} <b>{count(c.k)}</b>
          </button>
        ))}
        <label className="row" style={{ gap: 6, fontSize: 13 }}>
          <input type="checkbox" checked={showCancelled} onChange={(e) => setShowCancelled(e.target.checked)} /> {t('plan.cancelled')}
        </label>
      </div>

      <div className="plan-box" ref={boxRef}>
        {!data ? <div style={{ padding: 20 }}>{t('common.loading')}</div> : (
          <div style={{ width: gridW, paddingBottom: 40 }}>
            <div className="plan-head">
              <div className="plan-row" style={{ height: 28 }}>
                <div className="plan-roomcell" />
                {months.map((m, i) => <div key={i} className="plan-day" style={{ width: m.n * W, flexBasis: m.n * W, fontSize: 13, fontWeight: 700, color: 'var(--text)', textTransform: 'capitalize' }}>{m.label}</div>)}
              </div>
              <div className="plan-row" style={{ height: 56 }}>
                <div className="plan-roomcell" style={{ fontSize: 12, fontWeight: 600, color: 'var(--muted)' }}>{t('common.rooms').toUpperCase()}</div>
                {dayList.map((d, i) => (
                  <div key={d} className={`plan-day ${d === today ? 'today' : isWeekend(d) ? 'we' : ''}`} style={{ width: W, flexBasis: W }}>
                    <span>{d === today ? t('common.today') : fmtDate(d, locale, { weekday: 'short' })}</span>
                    <b>{Number(d.slice(8, 10))}</b>
                    <span className="plan-free" title={`${free[i]} ${t('plan.free')}`}>{free[i]}</span>
                  </div>
                ))}
              </div>
            </div>
            {floors.map(([fl, f]) => (
              <div key={fl}>
                <div className="plan-floor" style={{ width: gridW }}>
                  <button onClick={() => setCollapsed({ ...collapsed, [fl]: !collapsed[fl] })} aria-expanded={!collapsed[fl]}>
                    <Icon name={collapsed[fl] ? (rtl ? 'chevL' : 'chevR') : 'chevD'} size={14} /> {f.name} · {f.rooms.length} {t('common.rooms').toLowerCase()}
                  </button>
                </div>
                {!collapsed[fl] && f.rooms.map((room) => (
                  <div key={room.id} className="plan-row">
                    <div className="plan-roomcell" title={room.oos_reason ?? undefined}>
                      <span title={t(`hk.${room.out_of_service ? 'oos' : room.hk_status}` as Key)} style={{ width: 9, height: 9, borderRadius: 99, background: room.out_of_service ? HK_COLORS.oos : HK_COLORS[room.hk_status] }} />
                      <b>{room.number}</b>
                      <span className="muted" style={{ fontSize: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{room.type_name}</span>
                      {room.out_of_service && <span className="pill st-oos" style={{ fontSize: 10, padding: '1px 6px' }}>HS</span>}
                    </div>
                    <div className="plan-days" data-room={room.id}>
                      {dayList.map((d) => (
                        <button key={d} className={`plan-cell ${d === today ? 'today' : isWeekend(d) ? 'we' : ''}`} style={{ width: W, flexBasis: W }}
                          aria-label={`${t('plan.new')} · ${t('common.room')} ${room.number} · ${d}`}
                          disabled={!can('reservations.create') || d < today || oosOn(room.id, d, addDays(d, 1))}
                          onClick={() => setNewRes({ room_id: room.id, check_in: d })} />
                      ))}
                      {(blocksByRoom.get(room.id) ?? []).map((bl) => {
                        const x0 = Math.max(0, diffDays(from, bl.start_date) * W);
                        const x1 = bl.end_date ? Math.min(days * W, diffDays(from, bl.end_date) * W) : days * W;
                        if (x1 <= x0) return null;
                        return (
                          <div key={`bl${bl.id}`} className={`plan-block ${bl.kind}`} style={{ insetInlineStart: x0 + 1, width: x1 - x0 - 2 }}
                            title={`${bl.kind === 'out_of_service' ? t('plan.blocked') : t('rs.maintenance')} · ${bl.reason}${bl.end_date ? '' : ' (…)'}`}>
                            {bl.kind === 'out_of_service' ? t('plan.blocked') : t('rs.maintenance')} · {bl.reason}
                          </div>
                        );
                      })}
                      {(barsByRoom.get(room.id) ?? []).map((b) => {
                        const x0 = Math.max(0, (diffDays(from, b.check_in) + 0.5) * W);
                        const x1 = Math.min(days * W, (diffDays(from, b.check_out) + 0.5) * W);
                        if (x1 <= x0) return null;
                        const v = visual(b);
                        const dragging = drag?.bar.rr_id === b.rr_id;
                        const dim = (stFilter && v !== stFilter) || (q && !isHit(b));
                        return (
                          <button key={b.rr_id} data-rr={b.rr_id}
                            className={`bar st-${v} ${dragging ? 'dragging' : ''} ${dragging && drag?.bad ? 'bad' : ''} ${dim && !dragging ? 'dim' : ''} ${q && isHit(b) ? 'hit' : ''}`}
                            style={{ insetInlineStart: x0 + 2, width: Math.max(24, x1 - x0 - 4), pointerEvents: dragging ? 'none' : undefined, cursor: ['checked_out', 'cancelled', 'no_show'].includes(b.status) ? 'pointer' : undefined }}
                            aria-label={`${b.guest_name} · ${t(`st.${b.status}` as Key)} · ${t('common.room')} ${room.number}`}
                            onPointerDown={(e) => startDrag(e, b, 'move')}
                            onClick={(e) => { if (e.detail === 0) setPanel(b.reservation_id); else if (!['pending', 'confirmed', 'checked_in'].includes(b.status) || !can('reservations.edit')) setPanel(b.reservation_id); }}
                            onMouseEnter={(e) => !dragRef.current && setTip({ bar: b, x: e.clientX, y: e.clientY })}
                            onMouseMove={(e) => !dragRef.current && setTip({ bar: b, x: e.clientX, y: e.clientY })}
                            onMouseLeave={() => setTip(null)}>
                            {b.group_name ? `${b.group_name} · ` : ''}{b.guest_name}
                            {['pending', 'confirmed', 'checked_in'].includes(b.status) && can('reservations.edit') && (
                              <span className="grip" onPointerDown={(e) => startDrag(e, b, 'resize')} />
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="muted" style={{ fontSize: 12 }}>{t('plan.hint')}</div>

      {tip && !drag && (
        <div className="tip" style={{ left: Math.min(window.innerWidth - 270, tip.x + 14), top: Math.min(window.innerHeight - 190, tip.y + 14) }}>
          <b style={{ fontSize: 13 }}>{tip.bar.guest_name}</b>
          <span style={{ opacity: .8 }}>{tip.bar.code} · {t(`st.${tip.bar.status}` as Key)}{tip.bar.room_count > 1 ? ` · ${tip.bar.group_name ?? tip.bar.booker_name} (${tip.bar.room_count} ch.)` : ''}</span>
          <span style={{ opacity: .8 }}>{fmtDate(tip.bar.check_in, locale)} → {fmtDate(tip.bar.check_out, locale)} · {diffDays(tip.bar.check_in, tip.bar.check_out)} {t('common.nights')}</span>
          <div className="row2"><span style={{ opacity: .8 }}>{t('common.total')}</span><span>{money(tip.bar.total, locale)}</span></div>
          <div className="row2"><span style={{ opacity: .8 }}>{t('common.paid')}</span><span>{money(tip.bar.paid, locale)}</span></div>
          <div className="row2" style={{ borderTop: '1px solid rgba(127,127,127,.35)', paddingTop: 5 }}>
            <b>{t('common.balance')}</b>
            <span className="pill" style={tip.bar.balance > 0 ? { background: '#F59E0B', color: '#3B1D02' } : { background: '#0E7490', color: '#fff' }}>
              {tip.bar.balance > 0 ? money(tip.bar.balance, locale) : t('common.settled')}
            </span>
          </div>
        </div>
      )}
      {panel !== null && <ReservationPanel id={panel} onClose={() => setPanel(null)} onChanged={load} />}
      {newRes && <NewReservation initial={newRes} onClose={() => setNewRes(null)} onCreated={(r) => { setNewRes(null); load(); setPanel(r.id); }} />}
    </Page>
  );
}
