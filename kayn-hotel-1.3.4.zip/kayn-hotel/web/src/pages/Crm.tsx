import { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CrmStatus } from '../components/CrmCard';
import { Page } from '../components/Layout';
import { ReasonModal } from '../components/ReservationPanel';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { api, get, patch, post, upload } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { addDays, fmtDate, fmtDateTime, money, todayLocal, currency } from '../lib/format';
import { useLive } from '../lib/useLive';

type Tab = 'dashboard' | 'clients' | 'companies' | 'loyalty' | 'complaints' | 'surveys' | 'communication' | 'campaigns' | 'reports' | 'settings';
const CP_COLORS: Record<string, [string, string]> = { new: ['#FEE2E2', '#991B1B'], in_progress: ['#FEF3C7', '#92400E'], resolved: ['#DCFCE7', '#166534'], closed: ['#E2E8F0', '#334155'] };
const PCATS = ['room', 'dietary', 'service', 'request', 'occasion', 'habit', 'communication'];
const err = (toast: any) => (e: any) => toast('error', e.message);
const d10 = (v: any) => (v ? String(v).slice(0, 10) : '');
const toNum = (v: string | number) => Number(String(v ?? '').replace(',', '.').replace(/\s/g, '')) || 0;
const nm = (g: any) => (g.kind && g.kind !== 'person' ? g.company_name : `${g.last_name ?? ''} ${g.first_name ?? ''}`.trim());
const Pill = ({ map, s, k }: { map: Record<string, [string, string]>; s: string; k: string }) => { const { t } = useI18n(); const [bg, fg] = map[s] ?? ['#F1F5F9', '#475569']; return <span className="pill" style={{ background: bg, color: fg }}>{t(`${k}${s}` as Key)}</span>; };
function useMeta() {
  const [m, setM] = useState<any>(null);
  const load = useCallback(() => { get('/api/crm/meta').then(setM).catch(() => {}); }, []);
  useEffect(load, [load]);
  return { meta: m, reload: load };
}

export function Crm() {
  const { t } = useI18n();
  const { can } = useAuth();
  const [sp, setSp] = useSearchParams();
  const any = (ps: string[]) => ps.some((p) => can(p));
  const tabs = ([['dashboard', ['crm.view']], ['clients', ['crm.view', 'guests.view']], ['companies', ['crm.view', 'guests.view']], ['loyalty', ['crm.view', 'crm.loyalty']], ['complaints', ['crm.view', 'crm.complaints']],
    ['surveys', ['crm.complaints', 'crm.view']], ['communication', ['crm.marketing']], ['campaigns', ['crm.marketing']], ['reports', ['crm.reports']], ['settings', ['crm.manage']]] as [Tab, string[]][]).filter(([, ps]) => any(ps)).map(([k]) => k);
  const tab = tabs.includes(sp.get('tab') as Tab) ? (sp.get('tab') as Tab) : tabs[0];
  const go = (k: Tab) => setSp({ tab: k }, { replace: true });
  const [openId, setOpenId] = useState<number | null>(Number(sp.get('id')) || null);
  const open = (id: number) => setOpenId(id);
  return (
    <Page>
      <div className="page-head"><h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('crm.title')}</h1></div>
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>{tabs.map((k) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => go(k)}>{t(`crm.t_${k}` as Key)}</button>)}</div>
      {tab === 'dashboard' && <Dash go={go} open={open} />}
      {tab === 'clients' && <Clients open={open} />}
      {tab === 'companies' && <Companies open={open} />}
      {tab === 'loyalty' && <Loyalty open={open} />}
      {tab === 'complaints' && <Complaints open={open} />}
      {tab === 'surveys' && <Surveys />}
      {tab === 'communication' && <Communication />}
      {tab === 'campaigns' && <Campaigns />}
      {tab === 'reports' && <Reports />}
      {tab === 'settings' && <Settings />}
      {openId && <ClientSheet id={openId} onClose={() => { setOpenId(null); if (sp.get('id')) setSp({ tab }, { replace: true }); }} open={open} />}
    </Page>
  );
}

// ===================================================== Tableau de bord =====================================================
function Dash({ go, open }: { go: (t: Tab) => void; open: (id: number) => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const load = useCallback(() => { get('/api/crm/dashboard').then(setD).catch(err(toast)); }, []);
  useEffect(load, [load]);
  useLive(load, 60000);
  if (!d) return <span>{t('common.loading')}</span>;
  const k = d.kpi;
  const card = (label: string, v: any, color?: string, onClick?: () => void, hint?: string) => (
    <div className={`card kpi ${onClick ? 'clickable' : ''}`} style={{ borderInlineStart: color ? `4px solid ${color}` : undefined, cursor: onClick ? 'pointer' : undefined }} onClick={onClick}>
      <span className="label">{label}</span><span className="value" style={{ fontSize: typeof v === 'string' ? 20 : undefined }}>{v}</span>{hint && <span className="muted" style={{ fontSize: 12 }}>{hint}</span>}
    </div>
  );
  return (
    <>
      <div className="grid kpis">
        {card(t('crm.kTotal'), k.total, undefined, () => go('clients'), `${k.companies} ${t('crm.kCompanies')}`)}
        {card(t('crm.kNew'), k.new_month, '#0E7490')}
        {card(t('crm.kLoyal'), k.loyal, '#166534')}
        {card(t('crm.kVip'), k.vip, '#7A1F2B')}
        {card(t('crm.kActive'), `${k.active} · ${k.inactive} ${t('crm.inactive')}`, '#1E40AF')}
        {card(t('crm.kMembers'), k.members, '#C9A227', () => go('loyalty'))}
        {card(t('crm.kRetention'), `${k.retention} %`, '#15803D')}
        {card(t('crm.kSatisfaction'), k.satisfaction !== null ? `${k.satisfaction} / 5` : '—', '#C9A227', () => go('surveys'), k.nps !== null ? `NPS ${k.nps} · ${k.surveys} ${t('crm.responses')}` : undefined)}
        {card(t('crm.kComplaints'), `${k.complaints_pending}${k.complaints_late ? ` · ${k.complaints_late} ${t('crm.late')}` : ''}`, k.complaints_pending ? '#B91C1C' : undefined, () => go('complaints'))}
        {card(t('crm.kBirthdays'), k.birthdays, '#DB2777')}
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 14, alignItems: 'start' }}>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <h3 style={{ margin: 0 }}>{t('crm.vipInHouse')}</h3>
          {!d.inhouse.length && <span className="muted">{t('common.none')}</span>}
          {d.inhouse.map((g: any) => <div key={g.id} className="sum-row" style={{ cursor: 'pointer', fontSize: 13 }} onClick={() => open(g.id)}><span>{t('crm.room')} <b>{g.room}</b> · {nm(g)} {g.tier ? `· ${g.tier}` : ''}</span><CrmStatus s={g.crm_status} /></div>)}
          <h3 style={{ margin: '8px 0 0' }}>{t('crm.vipArrivals')}</h3>
          {!d.arrivals.length && <span className="muted">{t('common.none')}</span>}
          {d.arrivals.map((g: any) => <div key={g.id} className="sum-row" style={{ cursor: 'pointer', fontSize: 13 }} onClick={() => open(g.id)}><span>{nm(g)} · {g.res}</span><CrmStatus s={g.crm_status} /></div>)}
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <h3 style={{ margin: 0 }}>{t('crm.upcomingBirthdays')}</h3>
          {!d.birthdays.length && <span className="muted">{t('common.none')}</span>}
          {d.birthdays.map((b: any) => <div key={b.id} className="sum-row" style={{ cursor: 'pointer', fontSize: 13 }} onClick={() => open(b.id)}><span>🎂 {nm(b)}</span><span className="muted">{fmtDate(d10(b.next), locale, { day: 'numeric', month: 'long' })}</span></div>)}
        </div>
      </div>
    </>
  );
}

// ===================================================== Clients =====================================================
function Clients({ open }: { open: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta } = useMeta();
  const [f, setF] = useState({ q: '', status: '', tier: '', members: false, page: 1 });
  const [d, setD] = useState<any>(null);
  const [add, setAdd] = useState(false);
  const load = useCallback(() => {
    const h = setTimeout(() => get(`/api/crm/clients?q=${encodeURIComponent(f.q)}&page=${f.page}${f.status ? `&status=${f.status}` : ''}${f.tier ? `&tier=${f.tier}` : ''}${f.members ? '&members=true' : ''}`).then(setD).catch(err(toast)), 200);
    return () => clearTimeout(h);
  }, [f]);
  useEffect(load, [load]);
  const pages = d ? Math.max(1, Math.ceil(d.total / d.page_size)) : 1;
  return (
    <>
      <div className="row">
        <input className="input" style={{ maxWidth: 320 }} placeholder={t('crm.search')} aria-label={t('crm.search')} value={f.q} onChange={(e) => setF({ ...f, q: e.target.value, page: 1 })} />
        <select className="input" style={{ width: 'auto' }} aria-label={t('crm.status')} value={f.status} onChange={(e) => setF({ ...f, status: e.target.value, page: 1 })}><option value="">{t('crm.allStatuses')}</option>{['standard', 'loyal', 'vip'].map((s) => <option key={s} value={s}>{t(`crm.st_${s}` as Key)}</option>)}</select>
        <select className="input" style={{ width: 'auto' }} aria-label={t('crm.tier')} value={f.tier} onChange={(e) => setF({ ...f, tier: e.target.value, page: 1 })}><option value="">{t('crm.allTiers')}</option>{(meta?.tiers ?? []).map((x: any) => <option key={x.id} value={x.id}>{x.name}</option>)}</select>
        <label className="chip"><input type="checkbox" checked={f.members} onChange={(e) => setF({ ...f, members: e.target.checked, page: 1 })} /> {t('crm.membersOnly')}</label>
        <span className="muted" style={{ marginInlineStart: 'auto' }}>{d?.total ?? 0}</span>
        {can('guests.edit') && <button className="btn primary" onClick={() => setAdd(true)}><Icon name="plus" size={14} />{t('crm.newClient')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('crm.code')}</th><th>{t('crm.client')}</th><th>{t('crm.status')}</th><th>{t('crm.loyalty')}</th><th>{t('crm.contact')}</th><th>{t('crm.country')}</th><th className="num">{t('crm.stays')}</th><th>{t('crm.lastStay')}</th></tr></thead>
          <tbody>
            {d && !d.rows.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
            {(d?.rows ?? []).map((g: any) => (
              <tr key={g.id} style={{ cursor: 'pointer', opacity: g.anonymized_at ? 0.5 : 1 }} onClick={() => open(g.id)}>
                <td><b>{g.code}</b></td>
                <td>{g.name}{g.in_house ? <span className="pill" style={{ marginInlineStart: 6 }}>{t('crm.inHouse')}</span> : null}{g.open_complaints ? <span className="pill prio-urgent" style={{ marginInlineStart: 6 }}>⚠ {g.open_complaints}</span> : null}</td>
                <td><CrmStatus s={g.crm_status} /></td><td>{g.tier ? <span className="pill" style={{ background: g.tier_color, color: '#fff' }}>{g.tier}</span> : g.loyalty_number ? g.loyalty_number : ''}</td>
                <td style={{ fontSize: 12.5 }}>{g.phone ?? ''}{g.email ? <div className="muted">{g.email}</div> : null}</td><td>{g.country ?? g.nationality ?? ''}</td>
                <td className="num">{g.stays}</td><td>{g.last_stay ? fmtDate(d10(g.last_stay), locale, { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {pages > 1 && <div className="row" style={{ justifyContent: 'center' }}><button className="btn sm" disabled={f.page <= 1} onClick={() => setF({ ...f, page: f.page - 1 })}>‹</button><span>{f.page} / {pages}</span><button className="btn sm" disabled={f.page >= pages} onClick={() => setF({ ...f, page: f.page + 1 })}>›</button></div>}
      {add && <ClientModal init={{ kind: 'person' }} onClose={() => setAdd(false)} onDone={(g) => { setAdd(false); load(); if (g?.id) open(g.id); }} open={open} />}
    </>
  );
}

function ClientModal({ init, onClose, onDone, open }: { init: any; onClose: () => void; onDone: (g?: any) => void; open?: (id: number) => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const { meta } = useMeta();
  const company = init.kind && init.kind !== 'person';
  const [b, setB] = useState<any>({
    kind: init.kind ?? 'person', last_name: init.last_name ?? '', first_name: init.first_name ?? '', company_name: init.company_name ?? '', phone: init.phone ?? '', mobile: init.mobile ?? '', email: init.email ?? '',
    address: init.address ?? '', city: init.city ?? '', country: init.country ?? '', language: init.language ?? 'fr', birth_date: d10(init.birth_date), job_title: init.job_title ?? '', company_id: init.company_id ?? '',
    preferred_room_type_id: init.preferred_room_type_id ?? '', nif: init.nif ?? '', sector: init.sector ?? '', payment_terms_days: init.payment_terms_days ?? '', credit_limit: init.credit_limit ?? '', website: init.website ?? '',
    consent_email: !!init.consent_email, consent_sms: !!init.consent_sms, notes: init.notes ?? '',
  });
  const [dups, setDups] = useState<any[]>([]);
  const [companies, setCompanies] = useState<any[]>([]);
  useEffect(() => { if (!company) get('/api/crm/companies').then(setCompanies).catch(() => {}); }, []);
  useEffect(() => {
    if (init.id) return;
    const h = setTimeout(() => {
      const qs = new URLSearchParams(Object.entries({ last_name: b.last_name, first_name: b.first_name, phone: b.phone || b.mobile, email: b.email, company_name: company ? b.company_name : '' }).filter(([, v]) => v) as any);
      if ([...qs.keys()].length) get(`/api/crm/duplicates?${qs}`).then(setDups).catch(() => {}); else setDups([]);
    }, 350);
    return () => clearTimeout(h);
  }, [b.last_name, b.first_name, b.phone, b.mobile, b.email, b.company_name]);
  const set = (k: string) => (e: any) => setB({ ...b, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const save = async (force = false) => {
    const body: any = { ...b };
    for (const k of Object.keys(body)) if (body[k] === '') body[k] = null;
    for (const k of ['company_id', 'preferred_room_type_id', 'payment_terms_days']) body[k] = body[k] ? Number(body[k]) : null;
    body.credit_limit = body.credit_limit ? toNum(body.credit_limit) : null;
    if (init.id) delete body.kind;
    try { const r = init.id ? await patch(`/api/crm/clients/${init.id}`, body) : await post('/api/crm/clients', { ...body, force }); toast('success', t('crm.saved')); onDone(r); } catch (e: any) { toast('error', e.message); }
  };
  const strong = dups.filter((x) => x.score >= 60);
  return (
    <Modal title={init.id ? `${init.code} — ${nm(init)}` : company ? t('crm.newCompany') : t('crm.newClient')} onClose={onClose} size="lg" footer={<>
      <button className="btn" onClick={onClose}>{t('common.cancel')}</button>
      {strong.length > 0 && !init.id ? <button className="btn danger" onClick={() => save(true)}>{t('crm.createAnyway')}</button> : null}
      <button className="btn primary" disabled={company ? !b.company_name.trim() : !b.last_name.trim()} onClick={() => save(false)}>{t('common.save')}</button></>}>
      {dups.length > 0 && !init.id && (
        <div className="alert" style={{ borderColor: '#B45309', color: '#92400E', display: 'flex', flexDirection: 'column', gap: 4 }}>
          <b>{t('crm.possibleDuplicates')}</b>
          {dups.slice(0, 5).map((x) => <div key={x.id} className="row" style={{ gap: 8 }}><span>{x.code} · {x.name} — {x.reasons.join(', ')} ({x.score} %)</span>{open && <button className="btn sm" onClick={() => { onClose(); open(x.id); }}>{t('crm.openExisting')}</button>}</div>)}
        </div>
      )}
      <div className="form-grid">
        {company ? <>
          <Field label={t('crm.companyName')}><input className="input" value={b.company_name} onChange={set('company_name')} /></Field>
          <Field label="NIF"><input className="input" value={b.nif} onChange={set('nif')} /></Field>
          <Field label={t('crm.sector')}><input className="input" value={b.sector} onChange={set('sector')} /></Field>
          <Field label={t('crm.paymentTerms')}><input type="number" className="input" value={b.payment_terms_days} onChange={set('payment_terms_days')} /></Field>
          <Field label={t('crm.creditLimit')}><input className="input" value={b.credit_limit} onChange={set('credit_limit')} /></Field>
          <Field label={t('crm.website')}><input className="input" value={b.website} onChange={set('website')} /></Field>
        </> : <>
          <Field label={t('crm.lastName')}><input className="input" value={b.last_name} onChange={set('last_name')} autoFocus /></Field>
          <Field label={t('crm.firstName')}><input className="input" value={b.first_name} onChange={set('first_name')} /></Field>
          <Field label={t('crm.birthDate')}><input type="date" className="input" value={b.birth_date} onChange={set('birth_date')} /></Field>
          <Field label={t('crm.company')}><select className="input" value={b.company_id} onChange={set('company_id')}><option value="">—</option>{companies.map((c) => <option key={c.id} value={c.id}>{c.company_name}</option>)}</select></Field>
          <Field label={t('crm.jobTitle')}><input className="input" value={b.job_title} onChange={set('job_title')} /></Field>
          <Field label={t('crm.prefRoomType')}><select className="input" value={b.preferred_room_type_id} onChange={set('preferred_room_type_id')}><option value="">—</option>{(meta?.room_types ?? []).map((r: any) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></Field>
        </>}
        <Field label={t('crm.phone')}><input className="input" value={b.phone} onChange={set('phone')} /></Field>
        {!company && <Field label={t('crm.mobile')}><input className="input" value={b.mobile} onChange={set('mobile')} /></Field>}
        <Field label="E-mail"><input className="input" type="email" value={b.email} onChange={set('email')} /></Field>
        <Field label={t('crm.address')}><input className="input" value={b.address} onChange={set('address')} /></Field>
        <Field label={t('crm.city')}><input className="input" value={b.city} onChange={set('city')} /></Field>
        <Field label={t('crm.country')}><input className="input" value={b.country} onChange={set('country')} /></Field>
        <Field label={t('crm.language')}><select className="input" value={b.language} onChange={set('language')}><option value="fr">Français</option><option value="ar">العربية</option><option value="en">English</option></select></Field>
      </div>
      <div className="card" style={{ background: 'var(--surface2)', display: 'flex', gap: 14, flexWrap: 'wrap' }}>
        <b style={{ width: '100%' }}>{t('crm.consents')}</b>
        <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={b.consent_email} onChange={set('consent_email')} />{t('crm.consentEmail')}</label>
        <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={b.consent_sms} onChange={set('consent_sms')} />{t('crm.consentSms')}</label>
        <span className="muted" style={{ fontSize: 12.5 }}>{t('crm.consentHint')}</span>
      </div>
      <Field label={t('crm.internalNotes')}><textarea className="input" rows={2} value={b.notes} onChange={set('notes')} /></Field>
    </Modal>
  );
}

function ClientSheet({ id, onClose, open }: { id: number; onClose: () => void; open: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta } = useMeta();
  const [g, setG] = useState<any>(null);
  const [tab, setTab] = useState('overview');
  const [modal, setModal] = useState<any>(null);
  const photo = useRef<HTMLInputElement>(null);
  const load = useCallback(() => { get(`/api/crm/clients/${id}`).then(setG).catch(err(toast)); }, [id]);
  useEffect(load, [load]);
  const run = async (fn: () => Promise<any>, msg: string) => { try { await fn(); toast('success', msg); setModal(null); load(); } catch (e: any) { toast('error', e.message); } };
  if (!g) return <Modal title="…" onClose={onClose}><span>{t('common.loading')}</span></Modal>;
  const company = g.kind !== 'person';
  const anon = !!g.anonymized_at;
  const tabs = ['overview', 'history', ...(g.invoices ? ['billing'] : []), 'prefs', ...(!company ? ['loyalty'] : []), 'complaints', 'comms', ...(company ? ['company'] : []), ...(can('crm.privacy') ? ['privacy'] : [])];
  const kv = (k: Key, v: any) => <div><span className="muted">{t(k)}</span><div><b>{v || '—'}</b></div></div>;
  return (
    <Modal title={`${g.code} — ${g.name}`} onClose={onClose} size="lg">
      <div className="row" style={{ gap: 12, alignItems: 'center' }}>
        <div style={{ width: 58, height: 58, borderRadius: 99, overflow: 'hidden', background: 'var(--surface2)', display: 'grid', placeItems: 'center', cursor: can('guests.edit') && !anon ? 'pointer' : undefined }} onClick={() => can('guests.edit') && !anon && photo.current?.click()}>
          {g.photo_id ? <img src={`/api/photos/${g.photo_id}`} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <Icon name="users" size={24} />}
        </div>
        <input ref={photo} type="file" hidden accept="image/jpeg,image/png,image/webp" onChange={async (e) => { const f = e.target.files?.[0]; if (f) { try { await upload('/api/photos', f, { owner_type: 'guest', owner_id: String(id) }); load(); } catch (x: any) { toast('error', x.message); } } }} />
        <div style={{ flex: 1 }}>
          <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}><CrmStatus s={g.crm_status} />{g.tier && <span className="pill" style={{ background: g.tier.color, color: '#fff' }}>{g.tier.name}</span>}{g.loyalty_number && <span className="pill">{g.loyalty_number} · {g.loyalty?.balance ?? 0} pts</span>}{anon && <span className="pill prio-urgent">{t('crm.anonymized')}</span>}</div>
          <div className="muted" style={{ fontSize: 13, marginTop: 4 }}>{[g.phone, g.mobile, g.email].filter(Boolean).join(' · ')}{g.company ? ` · ${g.company.company_name}` : ''}</div>
        </div>
      </div>
      <div className="row" style={{ gap: 14, flexWrap: 'wrap', fontSize: 13 }}>
        <span>{t('crm.stays')} <b>{g.stats.stays}</b></span><span>{t('crm.nights')} <b>{g.stats.nights}</b></span>
        {g.stats.spent !== null && <span>{t('crm.spent')} <b>{money(g.stats.spent, locale)}</b></span>}{g.stats.avg_stay !== null && <span>{t('crm.avgStay')} <b>{money(g.stats.avg_stay, locale)}</b></span>}
        {g.stats.balance ? <span style={{ color: 'var(--danger)' }}>{t('crm.balance')} <b>{money(g.stats.balance, locale)}</b></span> : null}
      </div>
      {g.duplicates?.length > 0 && can('crm.manage') && (
        <div className="alert" style={{ borderColor: '#B45309', color: '#92400E' }}>
          <b>{t('crm.possibleDuplicates')}</b>
          {g.duplicates.slice(0, 4).map((x: any) => <div key={x.id} className="row" style={{ gap: 8 }}><span>{x.code} · {x.name} — {x.reasons.join(', ')}</span><button className="btn sm" onClick={() => open(x.id)}>{t('crm.open')}</button><button className="btn sm danger" onClick={() => confirm(t('crm.mergeConfirm')) && run(() => post(`/api/crm/clients/${id}/merge`, { duplicate_id: x.id }), t('crm.merged'))}>{t('crm.mergeHere')}</button></div>)}
        </div>
      )}
      <div className="seg" style={{ flexWrap: 'wrap' }}>{tabs.map((k) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{t(`crm.s_${k}` as Key)}</button>)}</div>

      {tab === 'overview' && <>
        <div className="form-grid">
          {kv('crm.address', [g.address, g.city, g.country].filter(Boolean).join(', '))}{kv('crm.language', ({ fr: 'Français', ar: 'العربية', en: 'English' } as any)[g.language])}
          {!company && kv('crm.birthDate', g.birth_date ? fmtDate(d10(g.birth_date), locale, { day: 'numeric', month: 'long', year: 'numeric' }) : '')}
          {kv('crm.nationality', g.nationality)}{kv('crm.firstStay', g.stats.first_stay ? fmtDate(d10(g.stats.first_stay), locale, { day: 'numeric', month: 'short', year: 'numeric' }) : '')}
          {kv('crm.lastStay', g.stats.last_stay ? fmtDate(d10(g.stats.last_stay), locale, { day: 'numeric', month: 'short', year: 'numeric' }) : '')}
          {kv('crm.consents', `${g.consent_email ? '✓ e-mail' : '✕ e-mail'} · ${g.consent_sms ? '✓ SMS' : '✕ SMS'}${g.unsubscribed_at ? ` · ${t('crm.unsubscribed')}` : ''}`)}
        </div>
        {g.notes && <p className="muted" style={{ whiteSpace: 'pre-wrap', margin: 0 }}>🔒 {g.notes}</p>}
        {!anon && <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          {can('guests.edit') && <button className="btn" onClick={() => setModal({ k: 'edit' })}>{t('common.edit')}</button>}
          {can('crm.manage') && !company && <select className="input" style={{ width: 'auto' }} aria-label={t('crm.status')} value={g.crm_status} onChange={(e) => run(() => post(`/api/crm/clients/${id}/status`, { status: e.target.value, locked: e.target.value !== 'standard' }), t('crm.saved'))}>{['standard', 'loyal', 'vip'].map((s) => <option key={s} value={s}>{t(`crm.st_${s}` as Key)}</option>)}</select>}
          {can('crm.loyalty') && !company && !g.loyalty_number && <button className="btn primary" onClick={() => run(() => post(`/api/crm/clients/${id}/enroll`, {}), t('crm.enrolled'))}>{t('crm.enroll')}</button>}
          {can('crm.marketing') && <button className="btn" onClick={() => setModal({ k: 'message', template_id: '', subject: '', body: '', purpose: 'transactional' })}>{t('crm.sendMessage')}</button>}
          <button className="btn" onClick={() => setModal({ k: 'interaction', channel: 'phone', direction: 'in', subject: '', body: '' })}>{t('crm.logInteraction')}</button>
        </div>}
      </>}

      {tab === 'history' && <>
        <h4 style={{ margin: 0 }}>{t('crm.stayHistory')}</h4>
        <table className="table"><thead><tr><th>{t('crm.dates')}</th><th>{t('crm.room')}</th><th>{t('crm.reservation')}</th><th className="num">{t('crm.nights')}</th></tr></thead>
          <tbody>{!g.stays.length && <tr><td colSpan={4} className="muted">{t('common.none')}</td></tr>}{g.stays.map((s: any) => <tr key={s.id}><td>{fmtDate(d10(s.check_in), locale)} → {fmtDate(d10(s.check_out), locale)}{!s.checked_out_at ? <span className="pill" style={{ marginInlineStart: 6 }}>{t('crm.inHouse')}</span> : null}</td><td>{s.room} · {s.room_type}</td><td>{s.code}</td><td className="num">{s.nights}</td></tr>)}</tbody></table>
        <h4 style={{ margin: '6px 0 0' }}>{t('crm.reservations')}</h4>
        <table className="table"><thead><tr><th>{t('crm.reservation')}</th><th>{t('crm.dates')}</th><th>{t('crm.status')}</th>{g.invoices && <th className="num">{t('crm.total')}</th>}</tr></thead>
          <tbody>{g.reservations.map((r: any) => <tr key={r.id}><td>{r.code}{r.as_payer ? <span className="muted"> ({t('crm.asPayer')})</span> : null}</td><td>{fmtDate(d10(r.check_in), locale)} → {fmtDate(d10(r.check_out), locale)}</td><td>{t(`st.${r.status}` as Key)}</td>{g.invoices && <td className="num">{money(r.total, locale)}</td>}</tr>)}</tbody></table>
        {g.restaurant.length > 0 && <><h4 style={{ margin: '6px 0 0' }}>{t('crm.restaurant')}</h4>{g.restaurant.map((o: any) => <div key={o.id} className="sum-row" style={{ fontSize: 13 }}><span>{fmtDateTime(o.created_at, locale)} · {o.number}</span>{o.total !== null && <b>{money(Number(o.total), locale)}</b>}</div>)}</>}
      </>}

      {tab === 'billing' && <>
        <h4 style={{ margin: 0 }}>{t('crm.invoices')}</h4>
        {g.invoices.map((i: any) => <div key={i.id} className="sum-row" style={{ fontSize: 13 }}><span>{i.number} · {fmtDate(d10(i.issued_at), locale)} · {i.status}</span><b>{money(Number(i.total), locale)}</b></div>)}
        <h4 style={{ margin: '6px 0 0' }}>{t('crm.payments')}</h4>
        {g.payments.map((p: any) => <div key={p.id} className="sum-row" style={{ fontSize: 13, textDecoration: p.void ? 'line-through' : undefined }}><span>{fmtDateTime(p.received_at, locale)} · {p.method} · {p.code ?? ''}</span><b>{money(Number(p.amount), locale)}</b></div>)}
      </>}

      {tab === 'prefs' && <>
        {!anon && can('guests.view') && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setModal({ k: 'pref', category: 'room', value: '', event_date: '' })}><Icon name="plus" size={14} />{t('crm.addPref')}</button>}
        {PCATS.map((c) => { const items = g.preferences.filter((p: any) => p.category === c); return items.length ? (
          <div key={c}><h4 style={{ margin: '6px 0 2px' }}>{t(`crm.pc_${c}` as Key)}</h4>
            {items.map((p: any) => <div key={p.id} className="sum-row" style={{ fontSize: 13 }}><span>{p.value}{p.event_date ? ` — ${fmtDate(d10(p.event_date), locale, { day: 'numeric', month: 'long' })}` : ''} <span className="muted">· {p.by_name ?? ''}</span></span>
              {can('guests.edit') && <button className="btn ghost sm" onClick={() => run(() => api('DELETE', `/api/crm/preferences/${p.id}`), t('crm.saved'))}>✕</button>}</div>)}</div>) : null; })}
        {g.preferences.length === 0 && !g.preferences_text && <span className="muted">{t('common.none')}</span>}
        {g.preferences_text && <p>{g.preferences_text}</p>}
        <h4 style={{ margin: '6px 0 0' }}>{t('crm.notes')}</h4>
        {g.note_list.map((n: any) => <div key={n.id} style={{ fontSize: 13 }}><span className="muted">{fmtDateTime(n.created_at, locale)} · {n.created_by_name} · {n.kind}</span><div>{n.text}</div></div>)}
      </>}

      {tab === 'loyalty' && (g.loyalty ? <>
        <div className="row" style={{ gap: 14, flexWrap: 'wrap' }}>
          <span>{t('crm.balancePts')} <b style={{ fontSize: 18 }}>{g.loyalty.balance}</b></span><span className="muted">{t('crm.qualifying')} {g.loyalty.qualifying}</span><span className="muted">{t('crm.earned')} {g.loyalty.earned}</span>
          <span className="muted">{t('crm.redeemed')} {g.loyalty.redeemed}</span><span className="muted">{t('crm.expired')} {g.loyalty.expired}</span>
          {g.loyalty.expiring_soon > 0 && <span style={{ color: '#B45309' }}>{g.loyalty.expiring_soon} {t('crm.expiringSoon')}</span>}
        </div>
        {g.tier?.benefits && <div className="alert" style={{ fontSize: 13 }}>{g.tier.name} : {g.tier.benefits}</div>}
        <div className="row" style={{ gap: 8 }}>
          {can('crm.loyalty') && <button className="btn primary" onClick={() => setModal({ k: 'redeem', reward_id: '', reservation_id: '' })}>{t('crm.redeem')}</button>}
          {can('crm.manage') && <button className="btn" onClick={() => setModal({ k: 'adjust', points: '', reason: '' })}>{t('crm.adjust')}</button>}
        </div>
        <h4 style={{ margin: '6px 0 0' }}>{t('crm.rewardsUsed')}</h4>
        {g.loyalty.redemptions.map((r: any) => <div key={r.id} className="sum-row" style={{ fontSize: 13 }}><span>{r.number} · {r.reward} · {r.points} pts{r.reservation ? ` · ${r.reservation}` : ''} · {t(`crm.rs_${r.status}` as Key)}</span>
          {r.status === 'issued' && can('crm.loyalty') && <span className="row" style={{ gap: 4 }}><button className="btn sm" onClick={() => run(() => post(`/api/crm/redemptions/${r.id}/use`, {}), t('crm.saved'))}>{t('crm.markUsed')}</button><button className="btn ghost sm" onClick={() => setModal({ k: 'cancelRed', id: r.id })}>{t('common.cancel')}</button></span>}</div>)}
        <h4 style={{ margin: '6px 0 0' }}>{t('crm.pointsHistory')}</h4>
        <table className="table"><thead><tr><th>{t('crm.date')}</th><th>{t('crm.movement')}</th><th className="num">{t('crm.points')}</th><th>{t('crm.expires')}</th></tr></thead>
          <tbody>{g.loyalty.transactions.map((x: any) => <tr key={x.id}><td>{fmtDate(d10(x.created_at), locale)}</td><td>{x.description}</td><td className="num" style={{ color: x.points < 0 ? 'var(--danger)' : '#15803D', fontWeight: 600 }}>{x.points > 0 ? '+' : ''}{x.points}</td><td>{x.expires_at && x.remaining > 0 ? `${x.remaining} → ${d10(x.expires_at)}` : ''}</td></tr>)}</tbody></table>
      </> : <span className="muted">{t('crm.notMember')}</span>)}

      {tab === 'complaints' && <>
        {can('guests.view') && !anon && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setModal({ k: 'complaint' })}><Icon name="plus" size={14} />{t('crm.newComplaint')}</button>}
        {g.complaints.map((c: any) => <div key={c.id} className="sum-row" style={{ fontSize: 13 }}><span>{c.number} · {t(`crm.cc_${c.category}` as Key)} · {c.title}{c.satisfaction ? ` · ${'★'.repeat(c.satisfaction)}` : ''}</span><Pill map={CP_COLORS} s={c.status} k="crm.cs_" /></div>)}
        <h4 style={{ margin: '6px 0 0' }}>{t('crm.surveys')}</h4>
        {g.surveys.map((s: any) => <div key={s.id} className="sum-row" style={{ fontSize: 13 }}><span>{s.name} · {s.code ?? ''}{s.comment ? ` — « ${s.comment} »` : ''}</span><b>{s.completed_at ? `${s.score ?? '—'} / 5${s.nps !== null ? ` · NPS ${s.nps}` : ''}` : t('crm.awaiting')}</b></div>)}
      </>}

      {tab === 'comms' && <>
        {g.interactions.map((i: any) => <div key={i.id} style={{ fontSize: 13, borderBottom: '1px solid var(--border)', paddingBottom: 4 }}><span className="muted">{fmtDateTime(i.created_at, locale)} · {t(`crm.ch_${i.channel}` as Key)} · {i.direction === 'in' ? '↙' : '↗'} {i.by_name ?? ''}{i.delivery ? ` · ${i.delivery}` : ''}</span><div><b>{i.subject}</b></div>{i.body && <div style={{ whiteSpace: 'pre-wrap' }}>{i.body}</div>}</div>)}
        {!g.interactions.length && <span className="muted">{t('common.none')}</span>}
      </>}

      {tab === 'company' && <CompanyPanel id={id} open={open} />}

      {tab === 'privacy' && <>
        <div className="alert" style={{ fontSize: 13 }}>{t('crm.privacyHint')}</div>
        <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          <a className="btn" href={`/api/crm/clients/${id}/export`}>{t('crm.exportData')}</a>
          {!anon && <button className="btn" onClick={() => setModal({ k: 'edit', rectification: true })}>{t('crm.rectify')}</button>}
          {!anon && <button className="btn danger" onClick={() => setModal({ k: 'anonymize' })}>{t('crm.anonymize')}</button>}
        </div>
        {g.privacy.map((r: any) => <div key={r.id} className="sum-row" style={{ fontSize: 13 }}><span>{fmtDateTime(r.created_at, locale)} · {t(`crm.pr_${r.kind}` as Key)} · {r.outcome ?? ''}</span><span className="muted">{r.by_name ?? t('crm.byClient')}</span></div>)}
      </>}

      {modal?.k === 'edit' && <ClientModal init={g} onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {modal?.k === 'complaint' && <ComplaintModal guest={g} onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {modal?.k === 'pref' && (
        <Modal title={t('crm.addPref')} onClose={() => setModal(null)} size="sm" footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={modal.value.trim().length < 2} onClick={() => run(() => post(`/api/crm/clients/${id}/preferences`, { category: modal.category, value: modal.value, event_date: modal.event_date || null }), t('crm.saved'))}>{t('common.save')}</button></>}>
          <Field label={t('crm.category')}><select className="input" value={modal.category} onChange={(e) => setModal({ ...modal, category: e.target.value })}>{PCATS.map((c) => <option key={c} value={c}>{t(`crm.pc_${c}` as Key)}</option>)}</select></Field>
          <Field label={t('crm.value')}><input className="input" value={modal.value} onChange={(e) => setModal({ ...modal, value: e.target.value })} /></Field>
          {modal.category === 'occasion' && <Field label={t('crm.date')}><input type="date" className="input" value={modal.event_date} onChange={(e) => setModal({ ...modal, event_date: e.target.value })} /></Field>}
          {modal.category === 'dietary' && <span className="muted" style={{ fontSize: 12.5 }}>{t('crm.dietaryHint')}</span>}
        </Modal>
      )}
      {modal?.k === 'redeem' && (
        <Modal title={t('crm.redeem')} onClose={() => setModal(null)} size="sm" footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!modal.reward_id} onClick={() => run(() => post(`/api/crm/clients/${id}/redeem`, { reward_id: Number(modal.reward_id), reservation_id: modal.reservation_id ? Number(modal.reservation_id) : null }), t('crm.redeemed'))}>{t('common.confirm')}</button></>}>
          <Field label={t('crm.reward')}><select className="input" value={modal.reward_id} onChange={(e) => setModal({ ...modal, reward_id: e.target.value })}><option value="">—</option>{(meta?.rewards ?? []).filter((r: any) => r.active).map((r: any) => <option key={r.id} value={r.id} disabled={r.points_cost > g.loyalty.balance}>{r.name} · {r.points_cost} pts{r.min_tier ? ` · ${r.min_tier}+` : ''}</option>)}</select></Field>
          <Field label={t('crm.onReservation')}><select className="input" value={modal.reservation_id} onChange={(e) => setModal({ ...modal, reservation_id: e.target.value })}><option value="">—</option>{g.reservations.filter((r: any) => ['pending', 'confirmed', 'checked_in'].includes(r.status)).map((r: any) => <option key={r.id} value={r.id}>{r.code} · {d10(r.check_in)}</option>)}</select></Field>
        </Modal>
      )}
      {modal?.k === 'adjust' && (
        <Modal title={t('crm.adjust')} onClose={() => setModal(null)} size="sm" footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!toNum(modal.points) || modal.reason.trim().length < 5} onClick={() => run(() => post(`/api/crm/clients/${id}/points`, { points: Math.round(toNum(modal.points)), reason: modal.reason }), t('crm.saved'))}>{t('common.save')}</button></>}>
          <Field label={t('crm.pointsPlusMinus')}><input className="input" value={modal.points} onChange={(e) => setModal({ ...modal, points: e.target.value })} /></Field>
          <Field label={t('crm.reason')}><input className="input" value={modal.reason} onChange={(e) => setModal({ ...modal, reason: e.target.value })} /></Field>
        </Modal>
      )}
      {modal?.k === 'cancelRed' && <ReasonModal title={t('common.cancel')} onClose={() => setModal(null)} onSubmit={(r) => run(() => post(`/api/crm/redemptions/${modal.id}/cancel`, { reason: r }), t('crm.saved'))} />}
      {modal?.k === 'anonymize' && <ReasonModal title={t('crm.anonymize')} onClose={() => setModal(null)} onSubmit={(r) => confirm(t('crm.anonymizeConfirm')) && run(() => post(`/api/crm/clients/${id}/anonymize`, { reason: r }), t('crm.saved'))} />}
      {modal?.k === 'interaction' && (
        <Modal title={t('crm.logInteraction')} onClose={() => setModal(null)} footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!modal.subject.trim() && !modal.body.trim()} onClick={() => run(() => post(`/api/crm/clients/${id}/interactions`, { channel: modal.channel, direction: modal.direction, subject: modal.subject || null, body: modal.body || null }), t('crm.saved'))}>{t('common.save')}</button></>}>
          <div className="form-grid">
            <Field label={t('crm.channel')}><select className="input" value={modal.channel} onChange={(e) => setModal({ ...modal, channel: e.target.value })}>{['phone', 'email', 'sms', 'whatsapp', 'in_person', 'letter', 'other'].map((c) => <option key={c} value={c}>{t(`crm.ch_${c}` as Key)}</option>)}</select></Field>
            <Field label={t('crm.direction')}><select className="input" value={modal.direction} onChange={(e) => setModal({ ...modal, direction: e.target.value })}><option value="in">{t('crm.incoming')}</option><option value="out">{t('crm.outgoing')}</option></select></Field>
          </div>
          <Field label={t('crm.subject')}><input className="input" value={modal.subject} onChange={(e) => setModal({ ...modal, subject: e.target.value })} /></Field>
          <Field label={t('crm.content')}><textarea className="input" rows={3} value={modal.body} onChange={(e) => setModal({ ...modal, body: e.target.value })} /></Field>
        </Modal>
      )}
      {modal?.k === 'message' && (
        <Modal title={t('crm.sendMessage')} onClose={() => setModal(null)} size="lg" footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" onClick={() => run(async () => {
          const r = await post(`/api/crm/clients/${id}/message`, modal.template_id ? { template_id: Number(modal.template_id) } : { subject: modal.subject, body: modal.body, purpose: modal.purpose });
          if (r.delivery === 'smtp_not_configured') toast('info', t('crm.smtpMissing'));
        }, t('crm.messageQueued'))}>{t('crm.send')}</button></>}>
          {!g.email && <div className="alert">{t('crm.noEmail')}</div>}
          <Field label={t('crm.template')}><select className="input" value={modal.template_id} onChange={async (e) => {
            const id2 = e.target.value; setModal({ ...modal, template_id: id2 });
            if (id2) { try { const p = await post(`/api/crm/templates/${id2}/preview`, { guest_id: id }); setModal((m: any) => ({ ...m, template_id: id2, subject: p.subject, body: p.body })); } catch { /* */ } }
          }}><option value="">{t('crm.freeMessage')}</option>{(meta?.templates ?? []).filter((x: any) => x.active).map((x: any) => <option key={x.id} value={x.id}>{x.name} ({x.language}) · {t(`crm.pu_${x.purpose}` as Key)}</option>)}</select></Field>
          <Field label={t('crm.subject')}><input className="input" disabled={!!modal.template_id} value={modal.subject} onChange={(e) => setModal({ ...modal, subject: e.target.value })} /></Field>
          <Field label={t('crm.content')}><textarea className="input" rows={7} disabled={!!modal.template_id} value={modal.body} onChange={(e) => setModal({ ...modal, body: e.target.value })} /></Field>
          {!modal.template_id && <Field label={t('crm.purpose')}><div className="seg"><button type="button" className={modal.purpose === 'transactional' ? 'on' : ''} onClick={() => setModal({ ...modal, purpose: 'transactional' })}>{t('crm.pu_transactional')}</button><button type="button" className={modal.purpose === 'marketing' ? 'on' : ''} onClick={() => setModal({ ...modal, purpose: 'marketing' })}>{t('crm.pu_marketing')}</button></div></Field>}
          <span className="muted" style={{ fontSize: 12.5 }}>{t('crm.placeholders')}</span>
        </Modal>
      )}
    </Modal>
  );
}

function CompanyPanel({ id, open }: { id: number; open: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [c, setC] = useState<any>(null);
  const [modal, setModal] = useState<any>(null);
  const load = useCallback(() => { get(`/api/crm/companies/${id}`).then(setC).catch(err(toast)); }, [id]);
  useEffect(load, [load]);
  const run = async (fn: () => Promise<any>) => { try { await fn(); toast('success', t('crm.saved')); setModal(null); load(); } catch (e: any) { toast('error', e.message); } };
  if (!c) return <span>{t('common.loading')}</span>;
  return (
    <>
      <div className="row" style={{ gap: 14, flexWrap: 'wrap', fontSize: 13 }}>
        <span>{t('crm.paymentTerms')} <b>{c.payment_terms_days ?? '—'} j</b></span>{c.credit_limit && <span>{t('crm.creditLimit')} <b>{money(Number(c.credit_limit), locale)}</b></span>}
        {c.due !== null && <span style={{ color: c.due > 0 ? 'var(--danger)' : undefined }}>{t('crm.receivable')} <b>{money(c.due, locale)}</b></span>}
      </div>
      <div className="row between"><h4 style={{ margin: 0 }}>{t('crm.contacts')}</h4>{can('crm.manage') && <button className="btn sm" onClick={() => setModal({ k: 'contact', name: '', role: '', phone: '', email: '', is_billing: false, is_booker: false })}><Icon name="plus" size={14} /></button>}</div>
      {c.contacts.map((x: any) => <div key={x.id} className="sum-row" style={{ fontSize: 13, opacity: x.active ? 1 : 0.5 }}><span><b>{x.name}</b> · {x.role ?? ''} {x.is_billing ? '· 🧾' : ''}{x.is_booker ? ' · 📅' : ''}</span><span className="muted">{[x.phone, x.email].filter(Boolean).join(' · ')}</span></div>)}
      <div className="row between"><h4 style={{ margin: '6px 0 0' }}>{t('crm.contracts')}</h4>{can('crm.manage') && <button className="btn sm" onClick={() => setModal({ k: 'contract', title: '', start_date: todayLocal(), end_date: addDays(todayLocal(), 365), rate_plan_id: '', payment_terms_days: c.payment_terms_days ?? 30, credit_limit: c.credit_limit ?? '', room_nights_commitment: '', terms: '' })}><Icon name="plus" size={14} /></button>}</div>
      {c.contracts.map((k: any) => <div key={k.id} className="sum-row" style={{ fontSize: 13 }}><span><b>{k.number}</b> · {k.title} · {d10(k.start_date)} → {k.end_date ? d10(k.end_date) : '…'}{k.rate_plan ? ` · ${k.rate_plan}` : ''}</span><span className="pill">{t(`crm.ks_${k.status}` as Key)}</span></div>)}
      <h4 style={{ margin: '6px 0 0' }}>{t('crm.negotiatedRates')}</h4>
      {!c.rate_plans.length && <span className="muted">{t('common.none')}</span>}
      {c.rate_plans.map((p: any) => <div key={p.id} className="sum-row" style={{ fontSize: 13 }}><span>{p.code} · {p.name}</span><span>{p.adjustment_type === 'percent' ? `${Number(p.adjustment_value)} %` : p.adjustment_type === 'amount' ? money(Number(p.adjustment_value), locale) : ''}</span></div>)}
      <h4 style={{ margin: '6px 0 0' }}>{t('crm.employees')}</h4>
      {c.employees.map((x: any) => <div key={x.id} className="sum-row" style={{ fontSize: 13, cursor: 'pointer' }} onClick={() => open(x.id)}><span>{x.code} · {x.last_name} {x.first_name}</span><span className="muted">{x.job_title ?? ''}</span></div>)}
      <h4 style={{ margin: '6px 0 0' }}>{t('crm.reservations')}</h4>
      {c.reservations.slice(0, 30).map((r: any) => <div key={r.id} className="sum-row" style={{ fontSize: 13 }}><span>{r.code} · {r.guest} · {d10(r.check_in)} → {d10(r.check_out)}</span>{r.total !== null && <b style={{ color: r.balance > 0 ? 'var(--danger)' : undefined }}>{money(r.total, locale)}{r.balance > 0 ? ` (${money(r.balance, locale)})` : ''}</b>}</div>)}
      {modal?.k === 'contact' && (
        <Modal title={t('crm.contacts')} onClose={() => setModal(null)} size="sm" footer={<button className="btn primary" disabled={modal.name.trim().length < 2} onClick={() => run(() => post(`/api/crm/companies/${id}/contacts`, { ...modal, k: undefined }))}>{t('common.save')}</button>}>
          {(['name', 'role', 'phone', 'email'] as const).map((k) => <Field key={k} label={t(`crm.f_${k}` as Key)}><input className="input" value={modal[k]} onChange={(e) => setModal({ ...modal, [k]: e.target.value })} /></Field>)}
          <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={modal.is_billing} onChange={(e) => setModal({ ...modal, is_billing: e.target.checked })} />{t('crm.billingContact')}</label>
          <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={modal.is_booker} onChange={(e) => setModal({ ...modal, is_booker: e.target.checked })} />{t('crm.bookerContact')}</label>
        </Modal>
      )}
      {modal?.k === 'contract' && <ContractModal m={modal} setM={setModal} save={() => run(() => post(`/api/crm/companies/${id}/contracts`, { title: modal.title, start_date: modal.start_date, end_date: modal.end_date || null, rate_plan_id: modal.rate_plan_id ? Number(modal.rate_plan_id) : null,
        payment_terms_days: modal.payment_terms_days ? Number(modal.payment_terms_days) : null, credit_limit: modal.credit_limit ? toNum(modal.credit_limit) : null, room_nights_commitment: modal.room_nights_commitment ? Number(modal.room_nights_commitment) : null, terms: modal.terms || null }))} />}
    </>
  );
}
function ContractModal({ m, setM, save }: { m: any; setM: (x: any) => void; save: () => void }) {
  const { t } = useI18n();
  const [plans, setPlans] = useState<any[]>([]);
  useEffect(() => { get('/api/rate-plans').then(setPlans).catch(() => {}); }, []);
  return (
    <Modal title={t('crm.newContract')} onClose={() => setM(null)} footer={<button className="btn primary" disabled={m.title.trim().length < 3} onClick={save}>{t('common.save')}</button>}>
      <Field label={t('crm.contractTitle')}><input className="input" value={m.title} onChange={(e) => setM({ ...m, title: e.target.value })} /></Field>
      <div className="form-grid">
        <Field label={t('crm.from')}><input type="date" className="input" value={m.start_date} onChange={(e) => setM({ ...m, start_date: e.target.value })} /></Field>
        <Field label={t('crm.to')}><input type="date" className="input" value={m.end_date} onChange={(e) => setM({ ...m, end_date: e.target.value })} /></Field>
        <Field label={t('crm.negotiatedRate')}><select className="input" value={m.rate_plan_id} onChange={(e) => setM({ ...m, rate_plan_id: e.target.value })}><option value="">—</option>{plans.filter((p) => p.active).map((p) => <option key={p.id} value={p.id}>{p.code} · {p.name}</option>)}</select></Field>
        <Field label={t('crm.paymentTerms')}><input type="number" className="input" value={m.payment_terms_days} onChange={(e) => setM({ ...m, payment_terms_days: e.target.value })} /></Field>
        <Field label={t('crm.creditLimit')}><input className="input" value={m.credit_limit} onChange={(e) => setM({ ...m, credit_limit: e.target.value })} /></Field>
        <Field label={t('crm.commitment')}><input type="number" className="input" value={m.room_nights_commitment} onChange={(e) => setM({ ...m, room_nights_commitment: e.target.value })} /></Field>
      </div>
      <Field label={t('crm.terms')}><textarea className="input" rows={3} value={m.terms} onChange={(e) => setM({ ...m, terms: e.target.value })} /></Field>
    </Modal>
  );
}

// ===================================================== Entreprises =====================================================
function Companies({ open }: { open: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [q, setQ] = useState('');
  const [rows, setRows] = useState<any[]>([]);
  const [add, setAdd] = useState(false);
  const load = useCallback(() => { get(`/api/crm/companies?q=${encodeURIComponent(q)}`).then(setRows).catch(err(toast)); }, [q]);
  useEffect(load, [load]);
  return (
    <>
      <div className="row"><input className="input" style={{ maxWidth: 320 }} placeholder={t('crm.search')} aria-label={t('crm.search')} value={q} onChange={(e) => setQ(e.target.value)} /><span style={{ flex: 1 }} />
        {can('guests.edit') && <button className="btn primary" onClick={() => setAdd(true)}><Icon name="plus" size={14} />{t('crm.newCompany')}</button>}</div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('crm.code')}</th><th>{t('crm.companyName')}</th><th>{t('crm.sector')}</th><th className="num">{t('crm.contacts')}</th><th className="num">{t('crm.reservations')}</th><th className="num">{t('crm.nights12m')}</th><th>{t('crm.contracts')}</th><th className="num">{t('crm.receivable')}</th></tr></thead>
          <tbody>
            {!rows.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
            {rows.map((c) => <tr key={c.id} style={{ cursor: 'pointer' }} onClick={() => open(c.id)}><td><b>{c.code}</b></td><td>{c.company_name}{c.kind === 'agency' ? <span className="pill" style={{ marginInlineStart: 6 }}>{t('crm.agency')}</span> : null}</td><td>{c.sector ?? ''}</td>
              <td className="num">{c.contacts}</td><td className="num">{c.reservations}</td><td className="num">{c.nights_12m}</td><td>{c.contracts ? `✓ ${c.contracts}` : '—'}{c.rate_plans ? ` · ${c.rate_plans} ${t('crm.rates')}` : ''}</td>
              <td className="num" style={{ color: c.due > 0 ? 'var(--danger)' : undefined }}>{c.due !== undefined ? money(c.due, locale) : ''}</td></tr>)}
          </tbody>
        </table>
      </div>
      {add && <ClientModal init={{ kind: 'company' }} onClose={() => setAdd(false)} onDone={(g) => { setAdd(false); load(); if (g?.id) open(g.id); }} open={open} />}
    </>
  );
}

// ===================================================== Fidélité =====================================================
function Loyalty({ open }: { open: (id: number) => void }) {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta, reload } = useMeta();
  const [dlg, setDlg] = useState<any>(null);
  const [top, setTop] = useState<any>(null);
  useEffect(() => { get('/api/crm/clients?members=true').then(setTop).catch(() => {}); }, []);
  const save = async (url: string, body: any, method = 'POST') => { try { await api(method, url, body); toast('success', t('crm.saved')); setDlg(null); reload(); } catch (e: any) { toast('error', e.message); } };
  const s = meta?.settings?.loyalty;
  return (
    <>
      {s && <div className="alert" style={{ fontSize: 13 }}>{s.enabled ? `${t('crm.rule')} : 1 ${t('crm.pointPer')} ${s.amount_per_point} ${currency.symbol} · ${t('crm.minNights')} ${s.min_nights} · ${t('crm.expiry')} ${s.expiry_months} ${t('crm.months')}` : t('crm.programOff')}</div>}
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 14, alignItems: 'start' }}>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div className="row between"><h3 style={{ margin: 0 }}>{t('crm.tiers')}</h3>{can('crm.manage') && <button className="btn sm" onClick={() => setDlg({ k: 'tier', code: '', name: '', min_points: 0, earn_multiplier: 1, discount_percent: 0, benefits: '', color: '#64748B' })}><Icon name="plus" size={14} /></button>}</div>
          {(meta?.tiers ?? []).map((x: any) => (
            <div key={x.id} className="hk-card" style={{ borderInlineStart: `4px solid ${x.color}`, cursor: can('crm.manage') ? 'pointer' : undefined, opacity: x.active ? 1 : 0.5 }} onClick={() => can('crm.manage') && setDlg({ k: 'tier', ...x })}>
              <div className="row between"><b>{x.name}</b><span className="muted">≥ {x.min_points} pts / 12 {t('crm.months')}</span></div>
              <div style={{ fontSize: 13 }}>× {Number(x.earn_multiplier)} · {Number(x.discount_percent)} % {t('crm.memberDiscount')}</div>
              {x.benefits && <div className="muted" style={{ fontSize: 12.5 }}>{x.benefits}</div>}
            </div>
          ))}
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <div className="row between"><h3 style={{ margin: 0 }}>{t('crm.rewards')}</h3>{can('crm.manage') && <button className="btn sm" onClick={() => setDlg({ k: 'reward', name: '', kind: 'service', points_cost: 100, value: '', min_tier_id: '', description: '', active: true })}><Icon name="plus" size={14} /></button>}</div>
          {(meta?.rewards ?? []).map((r: any) => <div key={r.id} className="sum-row" style={{ fontSize: 13, opacity: r.active ? 1 : 0.5, cursor: can('crm.manage') ? 'pointer' : undefined }} onClick={() => can('crm.manage') && setDlg({ k: 'reward', ...r, value: r.value ?? '', min_tier_id: r.min_tier_id ?? '' })}>
            <span>{r.name}{r.min_tier ? <span className="muted"> · {r.min_tier}+</span> : null}</span><b>{r.points_cost} pts</b></div>)}
        </div>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('crm.members')} ({top?.total ?? 0})</h3>
        <table className="table"><thead><tr><th>{t('crm.code')}</th><th>{t('crm.client')}</th><th>{t('crm.cardNo')}</th><th>{t('crm.tier')}</th><th className="num">{t('crm.stays')}</th></tr></thead>
          <tbody>{(top?.rows ?? []).map((g: any) => <tr key={g.id} style={{ cursor: 'pointer' }} onClick={() => open(g.id)}><td>{g.code}</td><td>{g.name}</td><td>{g.loyalty_number}</td><td>{g.tier ? <span className="pill" style={{ background: g.tier_color, color: '#fff' }}>{g.tier}</span> : ''}</td><td className="num">{g.stays}</td></tr>)}</tbody></table>
      </div>
      {dlg?.k === 'tier' && (
        <Modal title={t('crm.tiers')} onClose={() => setDlg(null)} footer={<button className="btn primary" onClick={() => save(dlg.id ? `/api/crm/tiers/${dlg.id}` : '/api/crm/tiers', { ...(dlg.id ? {} : { code: dlg.code }), name: dlg.name, min_points: Number(dlg.min_points), earn_multiplier: toNum(dlg.earn_multiplier), discount_percent: toNum(dlg.discount_percent), benefits: dlg.benefits || null, color: dlg.color, ...(dlg.id ? { active: dlg.active } : {}) }, dlg.id ? 'PATCH' : 'POST')}>{t('common.save')}</button>}>
          <div className="form-grid">
            {!dlg.id && <Field label="Code"><input className="input" value={dlg.code} onChange={(e) => setDlg({ ...dlg, code: e.target.value.toUpperCase() })} /></Field>}
            <Field label={t('crm.name')}><input className="input" value={dlg.name} onChange={(e) => setDlg({ ...dlg, name: e.target.value })} /></Field>
            <Field label={t('crm.minPoints')}><input type="number" className="input" value={dlg.min_points} onChange={(e) => setDlg({ ...dlg, min_points: e.target.value })} /></Field>
            <Field label={t('crm.multiplier')}><input className="input" value={dlg.earn_multiplier} onChange={(e) => setDlg({ ...dlg, earn_multiplier: e.target.value })} /></Field>
            <Field label={t('crm.memberDiscount')}><input className="input" value={dlg.discount_percent} onChange={(e) => setDlg({ ...dlg, discount_percent: e.target.value })} /></Field>
            <Field label={t('crm.color')}><input type="color" className="input" value={dlg.color} onChange={(e) => setDlg({ ...dlg, color: e.target.value })} /></Field>
          </div>
          <Field label={t('crm.benefits')}><textarea className="input" rows={2} value={dlg.benefits ?? ''} onChange={(e) => setDlg({ ...dlg, benefits: e.target.value })} /></Field>
          {dlg.id && <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={dlg.active} onChange={(e) => setDlg({ ...dlg, active: e.target.checked })} />{t('crm.active')}</label>}
        </Modal>
      )}
      {dlg?.k === 'reward' && (
        <Modal title={t('crm.rewards')} onClose={() => setDlg(null)} footer={<button className="btn primary" onClick={() => save(dlg.id ? `/api/crm/rewards/${dlg.id}` : '/api/crm/rewards', { name: dlg.name, kind: dlg.kind, points_cost: Number(dlg.points_cost), value: dlg.value === '' ? null : toNum(dlg.value), min_tier_id: dlg.min_tier_id ? Number(dlg.min_tier_id) : null, description: dlg.description || null, active: dlg.active }, dlg.id ? 'PATCH' : 'POST')}>{t('common.save')}</button>}>
          <div className="form-grid">
            <Field label={t('crm.name')}><input className="input" value={dlg.name} onChange={(e) => setDlg({ ...dlg, name: e.target.value })} /></Field>
            <Field label={t('crm.kind')}><select className="input" value={dlg.kind} onChange={(e) => setDlg({ ...dlg, kind: e.target.value })}>{['discount_amount', 'discount_percent', 'service', 'upgrade', 'other'].map((k) => <option key={k} value={k}>{t(`crm.rk_${k}` as Key)}</option>)}</select></Field>
            <Field label={t('crm.points')}><input type="number" className="input" value={dlg.points_cost} onChange={(e) => setDlg({ ...dlg, points_cost: e.target.value })} /></Field>
            {dlg.kind.startsWith('discount') && <Field label={t('crm.value')}><input className="input" value={dlg.value} onChange={(e) => setDlg({ ...dlg, value: e.target.value })} /></Field>}
            <Field label={t('crm.minTier')}><select className="input" value={dlg.min_tier_id} onChange={(e) => setDlg({ ...dlg, min_tier_id: e.target.value })}><option value="">—</option>{(meta?.tiers ?? []).map((x: any) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></Field>
          </div>
          <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={dlg.active} onChange={(e) => setDlg({ ...dlg, active: e.target.checked })} />{t('crm.active')}</label>
        </Modal>
      )}
    </>
  );
}

// ===================================================== Réclamations =====================================================
function ComplaintModal({ guest, onClose, onDone }: { guest?: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta } = useMeta();
  const [b, setB] = useState<any>({ guest_id: guest?.id ?? '', reservation_id: '', category: 'other', priority: 'normal', channel: 'in_person', kind: 'complaint', title: '', description: '', assigned_to: '' });
  const [q, setQ] = useState('');
  const [found, setFound] = useState<any[]>([]);
  useEffect(() => { if (guest || q.length < 2) return; const h = setTimeout(() => get(`/api/crm/clients?q=${encodeURIComponent(q)}&kind=all`).then((d) => setFound(d.rows)).catch(() => {}), 250); return () => clearTimeout(h); }, [q]);
  const save = async () => { try { await post('/api/crm/complaints', { ...b, guest_id: Number(b.guest_id), reservation_id: b.reservation_id ? Number(b.reservation_id) : null, assigned_to: b.assigned_to ? Number(b.assigned_to) : null, description: b.description || null }); toast('success', t('crm.saved')); onDone(); } catch (e: any) { toast('error', e.message); } };
  return (
    <Modal title={t('crm.newComplaint')} onClose={onClose} footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!b.guest_id || b.title.trim().length < 3} onClick={save}>{t('common.save')}</button></>}>
      {!guest && <Field label={t('crm.client')}><input className="input" value={q} placeholder={t('crm.search')} onChange={(e) => setQ(e.target.value)} />{found.length > 0 && !b.guest_id && <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>{found.slice(0, 6).map((g) => <button key={g.id} className="btn sm" style={{ justifyContent: 'flex-start' }} onClick={() => { setB({ ...b, guest_id: g.id }); setQ(`${g.code} · ${g.name}`); }}>{g.code} · {g.name}</button>)}</div>}</Field>}
      {guest && <div className="muted">{guest.code} · {guest.name}</div>}
      <div className="form-grid">
        <Field label={t('crm.kind')}><select className="input" value={b.kind} onChange={(e) => setB({ ...b, kind: e.target.value })}>{['complaint', 'remark', 'compliment'].map((k) => <option key={k} value={k}>{t(`crm.ck_${k}` as Key)}</option>)}</select></Field>
        <Field label={t('crm.category')}><select className="input" value={b.category} onChange={(e) => setB({ ...b, category: e.target.value })}>{Object.keys(meta?.complaint_categories ?? {}).map((k) => <option key={k} value={k}>{t(`crm.cc_${k}` as Key)}</option>)}</select></Field>
        <Field label={t('crm.priority')}><select className="input" value={b.priority} onChange={(e) => setB({ ...b, priority: e.target.value })}>{['low', 'normal', 'high', 'urgent'].map((k) => <option key={k} value={k}>{t(`crm.p_${k}` as Key)}</option>)}</select></Field>
        <Field label={t('crm.channel')}><select className="input" value={b.channel} onChange={(e) => setB({ ...b, channel: e.target.value })}>{['in_person', 'phone', 'email', 'online', 'other'].map((c) => <option key={c} value={c}>{t(`crm.ch_${c}` as Key)}</option>)}</select></Field>
        {guest && <Field label={t('crm.reservation')}><select className="input" value={b.reservation_id} onChange={(e) => setB({ ...b, reservation_id: e.target.value })}><option value="">—</option>{guest.reservations.map((r: any) => <option key={r.id} value={r.id}>{r.code} · {d10(r.check_in)}</option>)}</select></Field>}
        {can('crm.complaints') && <Field label={t('crm.assignTo')}><select className="input" value={b.assigned_to} onChange={(e) => setB({ ...b, assigned_to: e.target.value })}><option value="">—</option>{(meta?.users ?? []).map((u: any) => <option key={u.id} value={u.id}>{u.full_name}</option>)}</select></Field>}
      </div>
      <Field label={t('crm.subject')}><input className="input" value={b.title} onChange={(e) => setB({ ...b, title: e.target.value })} /></Field>
      <Field label={t('crm.description')}><textarea className="input" rows={3} value={b.description} onChange={(e) => setB({ ...b, description: e.target.value })} /></Field>
    </Modal>
  );
}
function Complaints({ open }: { open: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta } = useMeta();
  const [status, setStatus] = useState('new,in_progress');
  const [rows, setRows] = useState<any[]>([]);
  const [cur, setCur] = useState<any>(null);
  const [act, setAct] = useState<any>(null);
  const [add, setAdd] = useState(false);
  const load = useCallback(() => { get(`/api/crm/complaints${status ? `?status=${status}` : ''}`).then(setRows).catch(err(toast)); }, [status]);
  useEffect(load, [load]);
  const openC = (id: number) => get(`/api/crm/complaints/${id}`).then(setCur).catch(err(toast));
  const doAct = async (body: any) => { try { await post(`/api/crm/complaints/${cur.id}/action`, body); toast('success', t('crm.saved')); setAct(null); openC(cur.id); load(); } catch (e: any) { toast('error', e.message); } };
  return (
    <>
      <div className="row">
        <div className="seg">{[['new,in_progress', 'crm.open_'], ['resolved', 'crm.cs_resolved'], ['closed', 'crm.cs_closed'], ['', 'crm.all']].map(([v, k]) => <button key={v} className={status === v ? 'on' : ''} onClick={() => setStatus(v)}>{t(k as Key)}</button>)}</div>
        <span style={{ flex: 1 }} />
        <button className="btn primary" onClick={() => setAdd(true)}><Icon name="plus" size={14} />{t('crm.newComplaint')}</button>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('crm.number')}</th><th>{t('crm.date')}</th><th>{t('crm.client')}</th><th>{t('crm.category')}</th><th>{t('crm.subject')}</th><th>{t('crm.priority')}</th><th>{t('crm.status')}</th><th>{t('crm.assignee')}</th><th>{t('crm.due')}</th></tr></thead>
          <tbody>
            {!rows.length && <tr><td colSpan={9} className="muted">{t('common.none')}</td></tr>}
            {rows.map((c) => { const late = ['new', 'in_progress'].includes(c.status) && c.due_at && new Date(c.due_at) < new Date(); return (
              <tr key={c.id} style={{ cursor: 'pointer' }} onClick={() => openC(c.id)}><td><b>{c.number}</b>{c.kind !== 'complaint' ? <span className="pill" style={{ marginInlineStart: 4 }}>{t(`crm.ck_${c.kind}` as Key)}</span> : null}</td><td>{fmtDateTime(c.created_at, locale)}</td>
                <td>{c.guest} <CrmStatus s={c.crm_status} /></td><td>{t(`crm.cc_${c.category}` as Key)}</td><td className="wrap">{c.title}</td><td><span className={`pill prio-${c.priority}`}>{t(`crm.p_${c.priority}` as Key)}</span></td>
                <td><Pill map={CP_COLORS} s={c.status} k="crm.cs_" /></td><td>{c.assignee ?? '—'}</td><td style={{ color: late ? 'var(--danger)' : undefined, fontWeight: late ? 600 : undefined }}>{c.due_at ? fmtDateTime(c.due_at, locale) : ''}</td></tr>); })}
          </tbody>
        </table>
      </div>
      {cur && (
        <Modal title={`${cur.number} — ${cur.title}`} onClose={() => setCur(null)} size="lg">
          <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}><Pill map={CP_COLORS} s={cur.status} k="crm.cs_" /><span className={`pill prio-${cur.priority}`}>{t(`crm.p_${cur.priority}` as Key)}</span><span className="pill">{t(`crm.cc_${cur.category}` as Key)}</span>
            <button className="btn ghost sm" onClick={() => open(cur.guest_id)}>{cur.guest_code} · {cur.guest} →</button>{cur.reservation && <span className="muted">{cur.reservation}</span>}</div>
          {cur.description && <p style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{cur.description}</p>}
          {cur.resolution && <div className="alert" style={{ borderColor: '#15803D', color: '#166534' }}>{t('crm.resolution')} : {cur.resolution}{cur.compensation ? ` · ${cur.compensation}` : ''}{cur.satisfaction ? ` · ${'★'.repeat(cur.satisfaction)}` : ''}</div>}
          {can('crm.complaints') && <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
            {['new', 'in_progress'].includes(cur.status) && <>
              <select className="input" style={{ width: 'auto' }} aria-label={t('crm.assignTo')} value="" onChange={(e) => e.target.value && doAct({ action: 'assign', assigned_to: Number(e.target.value) })}><option value="">{cur.assignee ? `${t('crm.assignee')} : ${cur.assignee}` : t('crm.assignTo')}</option>{(meta?.users ?? []).map((u: any) => <option key={u.id} value={u.id}>{u.full_name}</option>)}</select>
              <button className="btn sm" onClick={() => setAct({ action: 'response', text: '' })}>{t('crm.addResponse')}</button>
              <button className="btn sm" onClick={() => setAct({ action: 'corrective', text: '' })}>{t('crm.addCorrective')}</button>
              <button className="btn sm primary" onClick={() => setAct({ action: 'resolve', text: '', compensation: '' })}>{t('crm.resolve')}</button></>}
            {cur.status === 'resolved' && <button className="btn sm primary" onClick={() => setAct({ action: 'close', satisfaction: 4 })}>{t('crm.close')}</button>}
            {['resolved', 'closed'].includes(cur.status) && <button className="btn sm" onClick={() => setAct({ action: 'reopen', text: '' })}>{t('crm.reopen')}</button>}
            <button className="btn sm ghost" onClick={() => setAct({ action: 'comment', text: '' })}>{t('crm.comment')}</button>
          </div>}
          <h4 style={{ margin: '6px 0 0' }}>{t('crm.timeline')}</h4>
          {cur.updates.map((u: any) => <div key={u.id} style={{ fontSize: 13 }}><span className="muted">{fmtDateTime(u.created_at, locale)} · {u.by_name ?? ''} · {t(`crm.uk_${u.kind}` as Key)}</span><div>{u.text}</div></div>)}
          {act && (
            <Modal title={t(`crm.act_${act.action}` as Key)} onClose={() => setAct(null)} size="sm" footer={<button className="btn primary" onClick={() => doAct(act)}>{t('common.save')}</button>}>
              {act.action !== 'close' && <Field label={t('crm.text')}><textarea className="input" rows={3} value={act.text} onChange={(e) => setAct({ ...act, text: e.target.value })} /></Field>}
              {act.action === 'resolve' && <Field label={t('crm.compensation')}><input className="input" value={act.compensation} onChange={(e) => setAct({ ...act, compensation: e.target.value })} /></Field>}
              {act.action === 'close' && <Field label={t('crm.clientSatisfaction')}><div className="seg">{[1, 2, 3, 4, 5].map((n) => <button key={n} type="button" className={act.satisfaction === n ? 'on' : ''} onClick={() => setAct({ ...act, satisfaction: n })}>{'★'.repeat(n)}</button>)}</div></Field>}
            </Modal>
          )}
        </Modal>
      )}
      {add && <ComplaintModal onClose={() => setAdd(false)} onDone={() => { setAdd(false); load(); }} />}
    </>
  );
}

// ===================================================== Enquêtes =====================================================
function Surveys() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta, reload } = useMeta();
  const [sel, setSel] = useState<number | null>(null);
  const [rows, setRows] = useState<any[]>([]);
  const [entry, setEntry] = useState<any>(null);
  const [edit, setEdit] = useState<any>(null);
  const sv = (meta?.surveys ?? []).find((x: any) => x.id === sel) ?? meta?.surveys?.[0];
  useEffect(() => { if (sv) get(`/api/crm/surveys/${sv.id}/responses`).then(setRows).catch(err(toast)); }, [sv?.id]);
  const done = rows.filter((r) => r.completed_at);
  const avg = (k: string) => { const v = done.map((r) => r.answers?.[k]).filter((x) => typeof x === 'number'); return v.length ? (v.reduce((a: number, b: number) => a + b, 0) / v.length).toFixed(2) : '—'; };
  return (
    <>
      <div className="row">
        <select className="input" style={{ width: 'auto' }} aria-label={t('crm.survey')} value={sv?.id ?? ''} onChange={(e) => setSel(Number(e.target.value))}>{(meta?.surveys ?? []).map((x: any) => <option key={x.id} value={x.id}>{x.name}{x.active ? '' : ` (${t('crm.inactive')})`}</option>)}</select>
        <span style={{ flex: 1 }} />
        {can('crm.complaints') && sv && <button className="btn" onClick={() => setEntry({ answers: {}, comment: '', reservation: '' })}>{t('crm.enterResponse')}</button>}
        {can('crm.complaints') && <button className="btn" onClick={() => setEdit({ name: '', trigger: 'manual', questions: [{ id: 'q1', label: '', type: 'rating' }] })}><Icon name="plus" size={14} />{t('crm.newSurvey')}</button>}
      </div>
      {sv && <div className="grid kpis">
        <div className="card kpi"><span className="label">{t('crm.responses')}</span><span className="value">{done.length} / {rows.length}</span></div>
        {(sv.questions as any[]).filter((x) => x.type !== 'text').map((x) => <div key={x.id} className="card kpi"><span className="label">{x.label}</span><span className="value" style={{ fontSize: 20 }}>{x.type === 'yesno' ? `${done.filter((r) => r.answers?.[x.id] === true).length} ✓` : avg(x.id)}</span></div>)}
      </div>}
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table"><thead><tr><th>{t('crm.date')}</th><th>{t('crm.client')}</th><th>{t('crm.reservation')}</th><th className="num">{t('crm.score')}</th><th className="num">NPS</th><th>{t('crm.comment')}</th></tr></thead>
          <tbody>{!rows.length && <tr><td colSpan={6} className="muted">{t('common.none')}</td></tr>}{rows.map((r) => <tr key={r.id}><td>{r.completed_at ? fmtDateTime(r.completed_at, locale) : <span className="muted">{t('crm.awaiting')}</span>}</td><td>{r.guest}</td><td>{r.reservation ?? ''}</td>
            <td className="num" style={{ color: r.score !== null && r.score <= 2 ? 'var(--danger)' : undefined, fontWeight: 600 }}>{r.score ?? ''}</td><td className="num">{r.nps ?? ''}</td><td className="wrap">{r.comment ?? ''}</td></tr>)}</tbody></table>
      </div>
      {entry && sv && (
        <Modal title={`${t('crm.enterResponse')} — ${sv.name}`} onClose={() => setEntry(null)} footer={<button className="btn primary" onClick={async () => {
          try { const r = await post(`/api/crm/surveys/${sv.id}/responses`, { reservation_id: entry.reservation_id ?? null, guest_id: entry.guest_id ?? null, answers: entry.answers, comment: entry.comment || null }); toast('success', `${t('crm.saved')} ${r.score ?? ''}`); setEntry(null); get(`/api/crm/surveys/${sv.id}/responses`).then(setRows); } catch (e: any) { toast('error', e.message); }
        }}>{t('common.save')}</button>}>
          <ReservationPicker onPick={(r) => setEntry({ ...entry, reservation_id: r.id, guest_id: r.guest_id, reservation: r.code })} value={entry.reservation} />
          {(sv.questions as any[]).map((x) => <Field key={x.id} label={x.label}>{x.type === 'text' ? <textarea className="input" rows={2} value={entry.answers[x.id] ?? ''} onChange={(e) => setEntry({ ...entry, answers: { ...entry.answers, [x.id]: e.target.value } })} /> :
            <div className="seg" style={{ flexWrap: 'wrap' }}>{(x.type === 'rating' ? [1, 2, 3, 4, 5] : x.type === 'nps' ? [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10] : [true, false]).map((v: any) => <button key={String(v)} type="button" className={entry.answers[x.id] === v ? 'on' : ''} onClick={() => setEntry({ ...entry, answers: { ...entry.answers, [x.id]: v } })}>{v === true ? t('crm.yes') : v === false ? t('crm.no') : v}</button>)}</div>}</Field>)}
          <Field label={t('crm.comment')}><textarea className="input" rows={2} value={entry.comment} onChange={(e) => setEntry({ ...entry, comment: e.target.value })} /></Field>
        </Modal>
      )}
      {edit && (
        <Modal title={t('crm.newSurvey')} onClose={() => setEdit(null)} size="lg" footer={<button className="btn primary" onClick={async () => { try { await post('/api/crm/surveys', { ...edit, questions: edit.questions.filter((x: any) => x.label.trim()) }); toast('success', t('crm.saved')); setEdit(null); reload(); } catch (e: any) { toast('error', e.message); } }}>{t('common.save')}</button>}>
          <div className="form-grid"><Field label={t('crm.name')}><input className="input" value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></Field>
            <Field label={t('crm.trigger')}><select className="input" value={edit.trigger} onChange={(e) => setEdit({ ...edit, trigger: e.target.value })}>{['manual', 'after_stay', 'after_complaint'].map((k) => <option key={k} value={k}>{t(`crm.tg_${k}` as Key)}</option>)}</select></Field></div>
          {edit.questions.map((x: any, i: number) => <div key={i} className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
            <input className="input" style={{ flex: 1, width: 'auto' }} aria-label={t('crm.question')} placeholder={t('crm.question')} value={x.label} onChange={(e) => setEdit({ ...edit, questions: edit.questions.map((y: any, j: number) => (j === i ? { ...y, label: e.target.value } : y)) })} />
            <select className="input" style={{ width: 'auto' }} aria-label={t('crm.kind')} value={x.type} onChange={(e) => setEdit({ ...edit, questions: edit.questions.map((y: any, j: number) => (j === i ? { ...y, type: e.target.value } : y)) })}>{['rating', 'nps', 'yesno', 'text'].map((k) => <option key={k} value={k}>{t(`crm.qt_${k}` as Key)}</option>)}</select></div>)}
          <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setEdit({ ...edit, questions: [...edit.questions, { id: `q${edit.questions.length + 1}`, label: '', type: 'rating' }] })}><Icon name="plus" size={14} />{t('crm.question')}</button>
        </Modal>
      )}
    </>
  );
}
function ReservationPicker({ onPick, value }: { onPick: (r: any) => void; value?: string }) {
  const { t } = useI18n();
  const [q, setQ] = useState(value ?? '');
  const [rows, setRows] = useState<any[]>([]);
  useEffect(() => { if (q.length < 3 || q === value) return; const h = setTimeout(() => get(`/api/reservations?search=${encodeURIComponent(q)}`).then((d) => setRows(Array.isArray(d) ? d : d.rows ?? [])).catch(() => {}), 250); return () => clearTimeout(h); }, [q]);
  return (
    <Field label={t('crm.reservation')}>
      <input className="input" value={q} placeholder={t('crm.searchReservation')} onChange={(e) => setQ(e.target.value)} />
      {rows.length > 0 && q !== value && <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>{rows.slice(0, 6).map((r) => <button key={r.id} className="btn sm" style={{ justifyContent: 'flex-start' }} onClick={() => { onPick(r); setQ(r.code); setRows([]); }}>{r.code} · {r.guest_name ?? ''} · {d10(r.check_in)}</button>)}</div>}
    </Field>
  );
}

// ===================================================== Communication =====================================================
function Communication() {
  const { t } = useI18n();
  const toast = useToast();
  const { meta, reload } = useMeta();
  const [edit, setEdit] = useState<any>(null);
  const runAuto = async () => { try { const r = await post('/api/crm/automations/run', {}); toast('success', `${t('crm.autoDone')} : ${r.thanks} / ${r.pre_arrival} / ${r.birthday}`); } catch (e: any) { toast('error', e.message); } };
  const save = async () => { try { if (edit.id) await patch(`/api/crm/templates/${edit.id}`, { name: edit.name, purpose: edit.purpose, subject: edit.subject, body: edit.body, active: edit.active }); else await post('/api/crm/templates', edit); toast('success', t('crm.saved')); setEdit(null); reload(); } catch (e: any) { toast('error', e.message); } };
  const a = meta?.settings?.automations;
  return (
    <>
      <div className="alert" style={{ fontSize: 13 }}>{t('crm.commHint')}{a ? ` · ${t('crm.autoThanks')} ${a.thanks ? '✓' : '✕'} · ${t('crm.autoPre')} ${a.pre_arrival_days ? `J-${a.pre_arrival_days}` : '✕'} · ${t('crm.autoBirthday')} ${a.birthday ? '✓' : '✕'}` : ''}</div>
      <div className="row"><button className="btn" onClick={runAuto}>{t('crm.runAutomations')}</button><span style={{ flex: 1 }} /><button className="btn primary" onClick={() => setEdit({ code: '', name: '', purpose: 'transactional', language: 'fr', subject: '', body: '', active: true })}><Icon name="plus" size={14} />{t('crm.newTemplate')}</button></div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table"><thead><tr><th>Code</th><th>{t('crm.name')}</th><th>{t('crm.language')}</th><th>{t('crm.purpose')}</th><th>{t('crm.subject')}</th></tr></thead>
          <tbody>{(meta?.templates ?? []).map((x: any) => <tr key={x.id} style={{ cursor: 'pointer', opacity: x.active ? 1 : 0.5 }} onClick={() => setEdit(x)}><td><b>{x.code}</b></td><td>{x.name}</td><td>{x.language}</td><td>{t(`crm.pu_${x.purpose}` as Key)}</td><td className="wrap">{x.subject}</td></tr>)}</tbody></table>
      </div>
      {edit && (
        <Modal title={edit.id ? edit.name : t('crm.newTemplate')} onClose={() => setEdit(null)} size="lg" footer={<button className="btn primary" onClick={save}>{t('common.save')}</button>}>
          <div className="form-grid">
            {!edit.id && <Field label="Code"><input className="input" value={edit.code} onChange={(e) => setEdit({ ...edit, code: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '') })} /></Field>}
            <Field label={t('crm.name')}><input className="input" value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></Field>
            {!edit.id && <Field label={t('crm.language')}><select className="input" value={edit.language} onChange={(e) => setEdit({ ...edit, language: e.target.value })}><option value="fr">FR</option><option value="ar">AR</option><option value="en">EN</option></select></Field>}
            <Field label={t('crm.purpose')}><select className="input" value={edit.purpose} onChange={(e) => setEdit({ ...edit, purpose: e.target.value })}><option value="transactional">{t('crm.pu_transactional')}</option><option value="marketing">{t('crm.pu_marketing')}</option></select></Field>
          </div>
          <Field label={t('crm.subject')}><input className="input" value={edit.subject} onChange={(e) => setEdit({ ...edit, subject: e.target.value })} /></Field>
          <Field label={t('crm.content')}><textarea className="input" rows={8} value={edit.body} onChange={(e) => setEdit({ ...edit, body: e.target.value })} /></Field>
          <span className="muted" style={{ fontSize: 12.5 }}>{t('crm.placeholders')}</span>
          {edit.id && <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={edit.active} onChange={(e) => setEdit({ ...edit, active: e.target.checked })} />{t('crm.active')}</label>}
        </Modal>
      )}
    </>
  );
}

// ===================================================== Segments et campagnes =====================================================
function Campaigns() {
  const { t, locale } = useI18n();
  const toast = useToast();
  const { meta } = useMeta();
  const [segs, setSegs] = useState<any[]>([]);
  const [camps, setCamps] = useState<any[]>([]);
  const [seg, setSeg] = useState<any>(null);
  const [pv, setPv] = useState<any>(null);
  const [camp, setCamp] = useState<any>(null);
  const load = useCallback(() => { get('/api/crm/segments').then(setSegs).catch(err(toast)); get('/api/crm/campaigns').then(setCamps).catch(() => {}); }, []);
  useEffect(load, [load]);
  const crit = (c: any) => Object.fromEntries(Object.entries(c).filter(([, v]) => v !== '' && v !== null && v !== false && !(Array.isArray(v) && !v.length)).map(([k, v]) => [k, ['min_stays', 'max_stays', 'min_spent', 'max_spent', 'inactive_days', 'active_days', 'birthday_month'].includes(k) ? Number(v) : v]));
  const preview = async () => { try { setPv(await post('/api/crm/segments/preview', { criteria: crit(seg.criteria) })); } catch (e: any) { toast('error', e.message); } };
  const saveSeg = async () => { try { if (seg.id) await patch(`/api/crm/segments/${seg.id}`, { name: seg.name, criteria: crit(seg.criteria) }); else await post('/api/crm/segments', { name: seg.name, criteria: crit(seg.criteria) }); toast('success', t('crm.saved')); setSeg(null); setPv(null); load(); } catch (e: any) { toast('error', e.message); } };
  const C = seg?.criteria ?? {};
  const setC = (k: string, v: any) => setSeg({ ...seg, criteria: { ...C, [k]: v } });
  const toggle = (k: string, v: any) => setC(k, (C[k] ?? []).includes(v) ? C[k].filter((x: any) => x !== v) : [...(C[k] ?? []), v]);
  return (
    <>
      <div className="row"><h3 style={{ margin: 0 }}>{t('crm.segments')}</h3><span style={{ flex: 1 }} /><button className="btn" onClick={() => { setSeg({ name: '', criteria: { kinds: ['person'] } }); setPv(null); }}><Icon name="plus" size={14} />{t('crm.newSegment')}</button></div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 12 }}>
        {segs.map((s) => <div key={s.id} className="hk-card clickable" onClick={() => { setSeg({ ...s, criteria: { ...s.criteria } }); setPv(null); }}><b>{s.name}</b><div style={{ fontSize: 13 }}>{s.count} {t('crm.clientsWord')} · <span style={{ color: '#15803D' }}>{s.reachable} {t('crm.reachable')}</span></div></div>)}
      </div>
      <div className="row"><h3 style={{ margin: 0 }}>{t('crm.campaigns')}</h3><span style={{ flex: 1 }} /><button className="btn primary" disabled={!segs.length} onClick={() => setCamp({ name: '', segment_id: segs[0]?.id ?? '', template_id: '' })}><Icon name="plus" size={14} />{t('crm.newCampaign')}</button></div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table"><thead><tr><th>{t('crm.name')}</th><th>{t('crm.segment')}</th><th>{t('crm.template')}</th><th>{t('crm.status')}</th><th className="num">{t('crm.sent')}</th><th className="num">{t('crm.noConsent')}</th><th className="num">{t('crm.unsubs')}</th><th className="num">{t('crm.bookings')}</th><th className="num">{t('crm.revenue')}</th><th /></tr></thead>
          <tbody>{!camps.length && <tr><td colSpan={10} className="muted">{t('common.none')}</td></tr>}{camps.map((c) => <tr key={c.id}><td><b>{c.name}</b>{c.sent_at ? <div className="muted" style={{ fontSize: 12 }}>{fmtDateTime(c.sent_at, locale)}</div> : null}</td><td>{c.segment}</td><td>{c.template} ({c.language})</td><td>{t(`crm.cps_${c.status}` as Key)}</td>
            <td className="num">{c.stats ? `${c.stats.sent}/${c.stats.targeted}` : ''}</td><td className="num">{c.stats?.no_consent ?? ''}</td><td className="num">{c.stats?.unsubscribed ?? ''}</td><td className="num">{c.stats ? `${c.stats.bookings} (${c.stats.conversion} %)` : ''}</td><td className="num">{c.stats ? money(c.stats.revenue, locale) : ''}</td>
            <td>{['draft', 'scheduled'].includes(c.status) && <span className="row" style={{ gap: 4, flexWrap: 'nowrap' }}><button className="btn sm primary" onClick={async () => { if (!confirm(t('crm.sendConfirm'))) return; try { const r = await post(`/api/crm/campaigns/${c.id}/send`, {}); toast('success', `${r.queued} ${t('crm.queued')} · ${r.skipped} ${t('crm.skipped')}`); load(); } catch (e: any) { toast('error', e.message); } }}>{t('crm.send')}</button>
              <button className="btn sm ghost" onClick={async () => { await post(`/api/crm/campaigns/${c.id}/cancel`, {}).catch(err(toast)); load(); }}>✕</button></span>}</td></tr>)}</tbody></table>
      </div>
      {seg && (
        <Modal title={seg.id ? seg.name : t('crm.newSegment')} onClose={() => setSeg(null)} size="lg" footer={<><button className="btn" onClick={preview}>{t('crm.preview')}</button><button className="btn primary" disabled={seg.name.trim().length < 2} onClick={saveSeg}>{t('common.save')}</button></>}>
          <Field label={t('crm.name')}><input className="input" value={seg.name} onChange={(e) => setSeg({ ...seg, name: e.target.value })} /></Field>
          <Field label={t('crm.clientType')}><div className="row" style={{ gap: 6 }}>{['person', 'company', 'agency'].map((k) => <button key={k} type="button" className={`chip ${(C.kinds ?? []).includes(k) ? 'on' : ''}`} onClick={() => toggle('kinds', k)}>{t(`crm.kd_${k}` as Key)}</button>)}</div></Field>
          <Field label={t('crm.status')}><div className="row" style={{ gap: 6 }}>{['standard', 'loyal', 'vip', 'company'].map((k) => <button key={k} type="button" className={`chip ${(C.statuses ?? []).includes(k) ? 'on' : ''}`} onClick={() => toggle('statuses', k)}>{t(`crm.st_${k}` as Key)}</button>)}</div></Field>
          <Field label={t('crm.tier')}><div className="row" style={{ gap: 6 }}>{(meta?.tiers ?? []).map((x: any) => <button key={x.id} type="button" className={`chip ${(C.tiers ?? []).includes(x.id) ? 'on' : ''}`} onClick={() => toggle('tiers', x.id)}>{x.name}</button>)}</div></Field>
          <div className="form-grid">
            <Field label={t('crm.minStays')}><input type="number" className="input" value={C.min_stays ?? ''} onChange={(e) => setC('min_stays', e.target.value)} /></Field>
            <Field label={t('crm.maxStays')}><input type="number" className="input" value={C.max_stays ?? ''} onChange={(e) => setC('max_stays', e.target.value)} /></Field>
            <Field label={t('crm.minSpent')}><input type="number" className="input" value={C.min_spent ?? ''} onChange={(e) => setC('min_spent', e.target.value)} /></Field>
            <Field label={t('crm.inactiveDays')}><input type="number" className="input" value={C.inactive_days ?? ''} onChange={(e) => setC('inactive_days', e.target.value)} /></Field>
            <Field label={t('crm.countries')}><input className="input" value={(C.countries ?? []).join(', ')} onChange={(e) => setC('countries', e.target.value.split(',').map((x) => x.trim()).filter(Boolean))} /></Field>
            <Field label={t('crm.preference')}><input className="input" value={C.preference ?? ''} onChange={(e) => setC('preference', e.target.value)} /></Field>
            <Field label={t('crm.birthdayMonth')}><input type="number" min={1} max={12} className="input" value={C.birthday_month ?? ''} onChange={(e) => setC('birthday_month', e.target.value)} /></Field>
          </div>
          <Field label={t('crm.language')}><div className="row" style={{ gap: 6 }}>{['fr', 'ar', 'en'].map((k) => <button key={k} type="button" className={`chip ${(C.languages ?? []).includes(k) ? 'on' : ''}`} onClick={() => toggle('languages', k)}>{k.toUpperCase()}</button>)}</div></Field>
          <div className="row" style={{ gap: 14 }}>
            <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={!!C.members_only} onChange={(e) => setC('members_only', e.target.checked)} />{t('crm.membersOnly')}</label>
            <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={!!C.marketing_consent} onChange={(e) => setC('marketing_consent', e.target.checked)} />{t('crm.consentOnly')}</label>
          </div>
          {pv && <div className="card" style={{ background: 'var(--surface2)' }}><b>{pv.count} {t('crm.clientsWord')} · {pv.reachable} {t('crm.reachable')}</b>
            {pv.sample.slice(0, 12).map((x: any) => <div key={x.id} className="sum-row" style={{ fontSize: 12.5 }}><span>{x.code} · {x.name} · {x.country}</span><span>{x.stays} · {money(x.spent, locale)} {x.reachable ? '✉' : ''}</span></div>)}</div>}
        </Modal>
      )}
      {camp && (
        <Modal title={t('crm.newCampaign')} onClose={() => setCamp(null)} size="sm" footer={<button className="btn primary" disabled={!camp.name.trim() || !camp.template_id} onClick={async () => { try { await post('/api/crm/campaigns', { name: camp.name, segment_id: Number(camp.segment_id), template_id: Number(camp.template_id) }); toast('success', t('crm.saved')); setCamp(null); load(); } catch (e: any) { toast('error', e.message); } }}>{t('common.save')}</button>}>
          <Field label={t('crm.name')}><input className="input" value={camp.name} onChange={(e) => setCamp({ ...camp, name: e.target.value })} /></Field>
          <Field label={t('crm.segment')}><select className="input" value={camp.segment_id} onChange={(e) => setCamp({ ...camp, segment_id: e.target.value })}>{segs.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.reachable})</option>)}</select></Field>
          <Field label={t('crm.template')}><select className="input" value={camp.template_id} onChange={(e) => setCamp({ ...camp, template_id: e.target.value })}><option value="">—</option>{(meta?.templates ?? []).filter((x: any) => x.purpose === 'marketing' && x.active).map((x: any) => <option key={x.id} value={x.id}>{x.name} ({x.language})</option>)}</select></Field>
          <span className="muted" style={{ fontSize: 12.5 }}>{t('crm.campaignHint')}</span>
        </Modal>
      )}
    </>
  );
}

// ===================================================== Rapports =====================================================
function Reports() {
  const { t, locale } = useI18n();
  const toast = useToast();
  const kinds = ['new_clients', 'returning', 'value', 'frequency', 'distribution', 'retention', 'satisfaction', 'complaints', 'loyalty'];
  const [kind, setKind] = useState(kinds[0]);
  const [p, setP] = useState({ from: `${todayLocal().slice(0, 4)}-01-01`, to: todayLocal() });
  const [r, setR] = useState<any>(null);
  const qs = `from=${p.from}&to=${p.to}`;
  useEffect(() => { setR(null); get(`/api/crm/reports/${kind}?${qs}`).then(setR).catch(err(toast)); }, [kind, qs]);
  const fmt = (c: any, v: any) => (v === null || v === undefined || v === '' ? '—' : c.money ? money(Number(v), locale) : String(v));
  return (
    <>
      <div className="row">
        <select className="input" style={{ width: 'auto' }} aria-label={t('crm.t_reports')} value={kind} onChange={(e) => setKind(e.target.value)}>{kinds.map((k) => <option key={k} value={k}>{t(`crm.rp_${k}` as Key)}</option>)}</select>
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('crm.from')} value={p.from} onChange={(e) => e.target.value && setP({ ...p, from: e.target.value })} />
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('crm.to')} value={p.to} min={p.from} onChange={(e) => e.target.value && setP({ ...p, to: e.target.value })} />
        <span style={{ flex: 1 }} />
        {['pdf', 'xlsx', 'csv'].map((f) => <button key={f} className="btn" onClick={() => window.open(`/api/crm/reports/${kind}?${qs}&format=${f}`, '_blank')}>{f === 'xlsx' ? 'Excel' : f.toUpperCase()}</button>)}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{r?.title ?? '…'}</h3>
        <table className="table">
          <thead><tr>{(r?.columns ?? []).map((c: any) => <th key={c.key} className={c.money ? 'num' : ''}>{c.label}</th>)}</tr></thead>
          <tbody>
            {r && !r.rows.length && <tr><td colSpan={r.columns.length} className="muted">{t('common.none')}</td></tr>}
            {(r?.rows ?? []).map((x: any, i: number) => <tr key={i}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : 'wrap'}>{fmt(c, x[c.key])}</td>)}</tr>)}
            {r?.total && r.rows.length > 0 && <tr style={{ fontWeight: 700, background: 'var(--surface2)' }}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : ''}>{r.total[c.key] !== undefined ? fmt(c, r.total[c.key]) : ''}</td>)}</tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ===================================================== Paramètres =====================================================
function Settings() {
  const { t } = useI18n();
  const toast = useToast();
  const [s, setS] = useState<any>(null);
  const [priv, setPriv] = useState<any[]>([]);
  const { can } = useAuth();
  useEffect(() => { get('/api/crm/settings').then(setS).catch(err(toast)); if (can('crm.privacy')) get('/api/crm/privacy-requests').then(setPriv).catch(() => {}); }, []);
  if (!s) return <span>{t('common.loading')}</span>;
  const save = async () => { try { setS(await api('PUT', '/api/crm/settings', s)); toast('success', t('crm.saved')); } catch (e: any) { toast('error', e.message); } };
  const L = s.loyalty, A = s.automations;
  return (
    <>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12, maxWidth: 860 }}>
        <h3 style={{ margin: 0 }}>{t('crm.t_loyalty')}</h3>
        <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={L.enabled} onChange={(e) => setS({ ...s, loyalty: { ...L, enabled: e.target.checked } })} />{t('crm.programOn')}</label>
        <div className="form-grid">
          <Field label={t('crm.amountPerPoint')}><input type="number" className="input" value={L.amount_per_point} onChange={(e) => setS({ ...s, loyalty: { ...L, amount_per_point: Number(e.target.value) } })} /></Field>
          <Field label={t('crm.minNights')}><input type="number" className="input" value={L.min_nights} onChange={(e) => setS({ ...s, loyalty: { ...L, min_nights: Number(e.target.value) } })} /></Field>
          <Field label={t('crm.expiryMonths')}><input type="number" className="input" value={L.expiry_months} onChange={(e) => setS({ ...s, loyalty: { ...L, expiry_months: Number(e.target.value) } })} /></Field>
          <Field label={t('crm.enrollBonus')}><input type="number" className="input" value={L.enrollment_bonus} onChange={(e) => setS({ ...s, loyalty: { ...L, enrollment_bonus: Number(e.target.value) } })} /></Field>
          <Field label={t('crm.loyalMinStays')}><input type="number" className="input" value={s.loyal_min_stays} onChange={(e) => setS({ ...s, loyal_min_stays: Number(e.target.value) })} /></Field>
          <Field label={t('crm.inactiveAfter')}><input type="number" className="input" value={s.inactive_days} onChange={(e) => setS({ ...s, inactive_days: Number(e.target.value) })} /></Field>
        </div>
        <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={L.restaurant} onChange={(e) => setS({ ...s, loyalty: { ...L, restaurant: e.target.checked } })} />{t('crm.restaurantPoints')}</label>
        <h3 style={{ margin: '6px 0 0' }}>{t('crm.slaTitle')}</h3>
        <div className="form-grid">{['urgent', 'high', 'normal', 'low'].map((k) => <Field key={k} label={`${t(`crm.p_${k}` as Key)} (h)`}><input type="number" className="input" value={s.complaint_sla_hours[k]} onChange={(e) => setS({ ...s, complaint_sla_hours: { ...s.complaint_sla_hours, [k]: Number(e.target.value) } })} /></Field>)}</div>
        <h3 style={{ margin: '6px 0 0' }}>{t('crm.automations')}</h3>
        <div className="row" style={{ gap: 14, flexWrap: 'wrap' }}>
          <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={A.thanks} onChange={(e) => setS({ ...s, automations: { ...A, thanks: e.target.checked } })} />{t('crm.autoThanks')}</label>
          <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={A.post_stay_survey} onChange={(e) => setS({ ...s, automations: { ...A, post_stay_survey: e.target.checked } })} />{t('crm.autoSurvey')}</label>
          <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={A.birthday} onChange={(e) => setS({ ...s, automations: { ...A, birthday: e.target.checked } })} />{t('crm.autoBirthday')}</label>
          <Field label={t('crm.autoPreDays')}><input type="number" min={0} className="input" style={{ width: 90 }} value={A.pre_arrival_days} onChange={(e) => setS({ ...s, automations: { ...A, pre_arrival_days: Number(e.target.value) } })} /></Field>
        </div>
        <Field label={t('crm.publicUrl')}><input className="input" placeholder="http://192.168.1.10:8080" value={s.public_url} onChange={(e) => setS({ ...s, public_url: e.target.value })} /></Field>
        <span className="muted" style={{ fontSize: 12.5 }}>{t('crm.publicUrlHint')}</span>
        <button className="btn primary" style={{ alignSelf: 'flex-start' }} onClick={save}>{t('common.save')}</button>
      </div>
      {priv.length > 0 && <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('crm.privacyRequests')}</h3>
        <table className="table"><tbody>{priv.map((r) => <tr key={r.id}><td>{d10(r.created_at)}</td><td>{r.code}</td><td>{t(`crm.pr_${r.kind}` as Key)}</td><td className="wrap">{r.outcome ?? ''}</td><td>{r.by_name ?? t('crm.byClient')}</td></tr>)}</tbody></table>
      </div>}
    </>
  );
}
