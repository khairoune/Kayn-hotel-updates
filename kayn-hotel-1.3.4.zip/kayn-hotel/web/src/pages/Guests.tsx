import { useCallback, useEffect, useState } from 'react';
import { IdentityFields, type GuestForm } from '../components/FrontDesk';
import { Page } from '../components/Layout';
import { ReasonModal, ReservationPanel } from '../components/ReservationPanel';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { del, get, patch, post } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, fmtDateTime, money } from '../lib/format';

export function Guests() {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [q, setQ] = useState('');
  const [kind, setKind] = useState('person');
  const [vip, setVip] = useState(false);
  const [page, setPage] = useState(1);
  const [data, setData] = useState<any>(null);
  const [open, setOpen] = useState<number | null>(null);
  const [toDelete, setToDelete] = useState<any>(null);
  const { can } = useAuth();
  const load = useCallback(() => {
    const h = setTimeout(() => get(`/api/guests/directory?search=${encodeURIComponent(q)}&kind=${kind}&page=${page}${vip ? '&vip=true' : ''}`).then(setData).catch((e) => toast('error', e.message)), 200);
    return () => clearTimeout(h);
  }, [q, kind, page, vip]);
  useEffect(load, [load]);
  const pages = data ? Math.max(1, Math.ceil(data.total / data.page_size)) : 1;
  return (
    <Page>
      <div className="page-head"><h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('gu.title')}</h1></div>
      <div className="alert" style={{ background: 'var(--gold-soft)', color: 'var(--gold-text)', border: 0 }}>🔒 {t('gu.privacy')}</div>
      <div className="row">
        <input className="input" style={{ maxWidth: 360 }} placeholder={t('gu.search')} aria-label={t('gu.search')} value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        <div className="seg">
          {['person', 'company', 'agency', 'all'].map((k) => <button key={k} className={kind === k ? 'on' : ''} onClick={() => { setKind(k); setPage(1); }}>{({ person: 'Personnes', company: 'Sociétés', agency: 'Agences', all: t('common.all') } as any)[k]}</button>)}
        </div>
        <label className="check"><input type="checkbox" checked={vip} onChange={(e) => setVip(e.target.checked)} /> {t('gu.vip')}</label>
        <span className="muted" style={{ marginInlineStart: 'auto' }}>{data?.total ?? 0}</span>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('fo.guest')}</th><th>{t('id.phone')}</th><th>{t('id.nationality')}</th><th>{t('id.docNumber')}</th><th className="num">{t('gu.stays')}</th><th>{t('gu.lastStay')}</th><th /></tr></thead>
          <tbody>
            {!data ? <tr><td colSpan={7}>{t('common.loading')}</td></tr> : !data.rows.length ? <tr><td colSpan={7} className="muted">{t('common.none')}</td></tr> : data.rows.map((g: any) => (
              <tr key={g.id} onClick={() => setOpen(g.id)} style={{ cursor: 'pointer' }}>
                <td><b>{g.vip ? '★ ' : ''}{g.name}</b>{g.in_house && <span className="pill" style={{ marginInlineStart: 6, background: '#DBEAFE', color: '#1E3A8A' }}>{t('gu.inHouse')}</span>}{g.open_complaints > 0 && <span className="pill" style={{ marginInlineStart: 6, background: '#FEE2E2', color: '#991B1B' }}>{g.open_complaints} {t('gu.n.complaint')}</span>}</td>
                <td>{g.phone ?? '—'}</td><td>{g.nationality ?? '—'}</td><td>{g.id_doc_number ?? '—'}</td><td className="num">{g.stays}</td>
                <td>{g.last_stay ? fmtDate(g.last_stay.slice(0, 10), locale) : '—'}</td>
                <td style={{ whiteSpace: 'nowrap' }} onClick={(e) => e.stopPropagation()}>
                  <button className="btn sm" title={t('gu.edit')} onClick={() => setOpen(g.id)}>✏️ {t('gu.edit')}</button>
                  {can('guests.edit') && <button className="btn sm" style={{ marginInlineStart: 6, color: '#B91C1C' }} title={t('gu.delete')} onClick={() => setToDelete(g)}>🗑️</button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {pages > 1 && (
        <div className="row" style={{ justifyContent: 'center' }}>
          <button className="btn sm" disabled={page <= 1} onClick={() => setPage(page - 1)}><Icon name="chevL" size={16} /></button>
          <span>{page} / {pages}</span>
          <button className="btn sm" disabled={page >= pages} onClick={() => setPage(page + 1)}><Icon name="chevR" size={16} /></button>
        </div>
      )}
      {open && <GuestProfile id={open} onClose={() => { setOpen(null); load(); }} />}
      {toDelete && <DeleteGuest g={toDelete} onClose={(done) => { setToDelete(null); if (done) load(); }} />}
    </Page>
  );
}

type Tab = 'info' | 'stays' | 'payments' | 'notes';
export function GuestProfile({ id, onClose }: { id: number; onClose: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [g, setG] = useState<any>(null);
  const [tab, setTab] = useState<Tab>('info');
  const [form, setForm] = useState<GuestForm | null>(null);
  const [extra, setExtra] = useState({ preferences: '', notes: '', vip: false, tax_exempt: false, tax_exempt_reason: '' });
  const [note, setNote] = useState({ kind: 'note', text: '' });
  const [resolveId, setResolveId] = useState<number | null>(null);
  const [panel, setPanel] = useState<number | null>(null);
  const load = useCallback(() => get(`/api/guests/${id}`).then((x) => {
    setG(x);
    setForm(Object.fromEntries(['last_name', 'first_name', 'gender', 'birth_date', 'birth_place', 'nationality', 'profession', 'id_doc_type', 'id_doc_number', 'id_doc_issued_on', 'id_doc_issued_place', 'id_doc_expiry', 'phone', 'email', 'address', 'city', 'country', 'language'].map((k) => [k, x[k] ?? ''])));
    setExtra({ preferences: x.preferences ?? '', notes: x.notes ?? '', vip: !!x.vip, tax_exempt: !!x.tax_exempt, tax_exempt_reason: x.tax_exempt_reason ?? '' });
  }).catch((e) => toast('error', e.message)), [id]);
  useEffect(() => { load(); }, [load]);
  const edit = can('guests.edit');
  const save = async () => {
    try {
      const body: any = Object.fromEntries(Object.entries(form!).map(([k, v]) => [k, v === '' ? null : v]));
      if (!body.gender) delete body.gender;
      if (g.kind !== 'person') { delete body.id_doc_type; }
      await patch(`/api/guests/${id}`, { ...body, preferences: extra.preferences || null, notes: extra.notes || null, vip: extra.vip, ...(can('settings.manage') ? { tax_exempt: extra.tax_exempt, tax_exempt_reason: extra.tax_exempt_reason || null } : {}) });
      toast('success', 'Fiche client enregistrée.');
      load();
    } catch (e: any) { toast('error', e.message); }
  };
  const addNote = async () => {
    try { await post(`/api/guests/${id}/notes`, note); setNote({ ...note, text: '' }); load(); } catch (e: any) { toast('error', e.message); }
  };
  const openNotes = (g?.notes ?? []).filter((n: any) => n.status === 'open').length;
  return (
    <>
      <div className="drawer-overlay" onClick={onClose} />
      <aside className="drawer wide" role="dialog" aria-label={t('fo.profile')}>
        {!g || !form ? <div className="modal-body">{t('common.loading')}</div> : (
          <>
            <div className="modal-head" style={{ alignItems: 'flex-start' }}>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
                <h2 style={{ fontSize: 21 }}>{g.vip ? '★ ' : ''}{g.name}</h2>
                <span className="muted" style={{ fontSize: 13 }}>{[g.nationality, g.phone, g.email].filter(Boolean).join(' · ')}</span>
              </div>
              <button className="btn ghost icon" aria-label={t('common.close')} onClick={onClose}><Icon name="close" /></button>
            </div>
            <div className="grid" style={{ gridTemplateColumns: 'repeat(4, minmax(0,1fr))', padding: '0 20px 12px', gap: 8 }}>
              <div className="mini"><span>{t('gu.stays')}</span><b>{g.stats.stays}</b></div>
              <div className="mini"><span>{t('gu.nightsTotal')}</span><b>{g.stats.nights}</b></div>
              <div className="mini"><span>{t('gu.spent')}</span><b>{money(g.stats.spent, locale)}</b></div>
              <div className="mini"><span>{t('fo.balance')}</span><b style={{ color: g.stats.balance > 0.005 ? 'var(--danger)' : undefined }}>{money(g.stats.balance, locale)}</b></div>
            </div>
            <div className="tabs">
              {(['info', 'stays', 'payments', 'notes'] as Tab[]).map((k) => (
                <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>
                  {({ info: t('rm.tInfo'), stays: t('gu.stays'), payments: t('gu.payments'), notes: t('gu.notes') } as any)[k]}{k === 'notes' && openNotes ? ` (${openNotes})` : ''}
                </button>
              ))}
            </div>
            <div className="modal-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 12 }}>
              {tab === 'info' && (
                <>
                  {g.kind === 'person' ? <fieldset disabled={!edit} style={{ border: 0, padding: 0, margin: 0 }}><IdentityFields g={form} set={setForm} /></fieldset>
                    : <div className="kv"><div><span>Raison sociale</span><b>{g.company_name}</b></div><div><span>NIF</span><b>{g.nif ?? '—'}</b></div></div>}
                  <fieldset disabled={!edit} style={{ border: 0, padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
                    <Field label={t('gu.preferences')} htmlFor="gp-pref"><textarea id="gp-pref" className="input" rows={2} placeholder="Ex. : étage élevé, oreiller ferme, sans gluten…" value={extra.preferences} onChange={(e) => setExtra({ ...extra, preferences: e.target.value })} /></Field>
                    <Field label={t('gu.n.note')} htmlFor="gp-notes"><textarea id="gp-notes" className="input" rows={2} value={extra.notes} onChange={(e) => setExtra({ ...extra, notes: e.target.value })} /></Field>
                    <label className="check"><input type="checkbox" checked={extra.vip} onChange={(e) => setExtra({ ...extra, vip: e.target.checked })} /> {t('gu.vip')}</label>
                  </fieldset>
                  <fieldset disabled={!can('settings.manage')} style={{ border: 0, padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
                    <label className="check"><input type="checkbox" checked={extra.tax_exempt} onChange={(e) => setExtra({ ...extra, tax_exempt: e.target.checked })} /> Exonéré de TVA (nouveaux dossiers)</label>
                    {extra.tax_exempt && <input className="input" aria-label="Motif de l'exonération" placeholder="Motif : corps diplomatique, attestation…" value={extra.tax_exempt_reason} onChange={(e) => setExtra({ ...extra, tax_exempt_reason: e.target.value })} />}
                  </fieldset>
                  <span className="muted" style={{ fontSize: 12 }}>{g.data_consent_at ? `Consentement données personnelles : ${fmtDateTime(g.data_consent_at, locale)}` : 'Consentement non enregistré (recueilli au check-in).'}</span>
                  {edit && <button className="btn primary" style={{ alignSelf: 'flex-start' }} onClick={save}>{t('common.save')}</button>}
                </>
              )}
              {tab === 'stays' && (g.stays.length ? g.stays.map((s: any) => (
                <div key={s.rr_id} className="card" style={{ padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <div className="row between"><b>{t('common.room')} {s.room_number} · {s.room_type}</b><button className="link" onClick={() => setPanel(s.reservation_id)}>{s.code}</button></div>
                  <span className="muted" style={{ fontSize: 12.5 }}>{fmtDate(s.check_in, locale)} → {fmtDate(s.check_out, locale)} · {t(`st.${s.status}` as Key)} · {money(s.rate, locale)} / {t('common.nights')}{s.companions ? ` · +${s.companions} acc.` : ''}</span>
                </div>
              )) : <span className="muted">{t('common.none')}</span>)}
              {tab === 'payments' && (g.payments.length ? (
                <table className="table">
                  <thead><tr><th>Date</th><th>{t('fo.code')}</th><th>{t('common.method')}</th><th className="num">{t('common.amount')}</th></tr></thead>
                  <tbody>{g.payments.map((p: any) => <tr key={p.id} style={{ textDecoration: p.void ? 'line-through' : undefined, opacity: p.void ? 0.5 : 1 }}><td>{fmtDateTime(p.received_at, locale)}</td><td>{p.code}</td><td>{t(`pm.${p.method}` as Key)}</td><td className="num">{money(p.amount, locale)}</td></tr>)}</tbody>
                </table>
              ) : <span className="muted">{t('common.none')}</span>)}
              {tab === 'notes' && (
                <>
                  <div className="row" style={{ alignItems: 'flex-end' }}>
                    <select className="input" style={{ width: 'auto' }} aria-label="Type" value={note.kind} onChange={(e) => setNote({ ...note, kind: e.target.value })}>{['note', 'preference', 'request', 'complaint'].map((k) => <option key={k} value={k}>{t(`gu.n.${k}` as Key)}</option>)}</select>
                    <input className="input" style={{ flex: 1, minWidth: 180 }} aria-label="Texte" value={note.text} onChange={(e) => setNote({ ...note, text: e.target.value })} />
                    <button className="btn primary" disabled={note.text.trim().length < 2} onClick={addNote}>{t('gu.addNote')}</button>
                  </div>
                  {g.notes.map((n: any) => (
                    <div key={n.id} className="card" style={{ padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 4, borderInlineStart: n.kind === 'complaint' ? '4px solid var(--danger)' : undefined }}>
                      <div className="row between">
                        <span className="pill" style={{ background: 'var(--soft)' }}>{t(`gu.n.${n.kind}` as Key)}</span>
                        {['complaint', 'request'].includes(n.kind) && (n.status === 'open' ? <button className="btn sm" onClick={() => setResolveId(n.id)}>{t('gu.resolve')}</button> : <span className="pill" style={{ background: 'var(--ok-bg)', color: 'var(--ok)' }}>{t('gu.resolved')}</span>)}
                      </div>
                      <span>{n.text}</span>
                      {n.resolution && <span style={{ fontSize: 13 }}>✓ {n.resolution} — {n.resolved_by_name}</span>}
                      <span className="muted" style={{ fontSize: 12 }}>{fmtDateTime(n.created_at, locale)} · {n.created_by_name}{n.code ? ` · ${n.code}` : ''}</span>
                    </div>
                  ))}
                </>
              )}
            </div>
          </>
        )}
      </aside>
      {resolveId && <ReasonModal title={t('gu.resolve')} onClose={() => setResolveId(null)} onSubmit={(resolution) => post(`/api/guest-notes/${resolveId}/resolve`, { resolution }).then(() => { setResolveId(null); load(); }).catch((e) => toast('error', e.message))} />}
      {panel && <ReservationPanel id={panel} onClose={() => setPanel(null)} onChanged={load} />}
    </>
  );
}

/** Supprimer un client (sans historique) ou, s'il a un historique, l'anonymiser (loi 18-07 + obligations comptables). */
function DeleteGuest({ g, onClose }: { g: any; onClose: (done: boolean) => void }) {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [blocked, setBlocked] = useState<string | null>(null);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const run = async (fn: () => Promise<any>, ok: string) => {
    setBusy(true);
    try { await fn(); toast('success', ok); onClose(true); }
    catch (e: any) { if (e.status === 409 && !blocked) setBlocked(e.message); else toast('error', e.message); }
    finally { setBusy(false); }
  };
  return (
    <Modal title={`${t('gu.delete')} — ${g.name}`} onClose={() => onClose(false)} size="sm"
      footer={<>
        <button className="btn" onClick={() => onClose(false)}>{t('common.cancel')}</button>
        {!blocked ? <button className="btn danger" disabled={busy} onClick={() => run(() => del(`/api/guests/${g.id}`), t('gu.deleted'))}>🗑️ {t('gu.delete')}</button>
          : can('crm.privacy') && <button className="btn danger" disabled={busy || reason.trim().length < 5} onClick={() => run(() => post(`/api/crm/clients/${g.id}/anonymize`, { reason }), t('gu.anonymized'))}>{t('gu.anonymize')}</button>}
      </>}>
      {!blocked ? <p>{t('gu.deleteConfirm')}</p> : <>
        <div className="alert warning">{blocked}</div>
        {can('crm.privacy') ? <Field label={t('gu.anonReason')}><textarea className="input" rows={2} value={reason} onChange={(e) => setReason(e.target.value)} placeholder={t('gu.anonReasonPh')} /></Field>
          : <p className="muted">{t('gu.anonNoRight')}</p>}
      </>}
    </Modal>
  );
}
