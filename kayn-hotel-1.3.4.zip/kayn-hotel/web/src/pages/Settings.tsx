import { useEffect, useState } from 'react';
import { Page } from '../components/Layout';
import { Field } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { api, get, post } from '../lib/api';
import { useToast } from '../lib/context';

const SOURCES = ['walk_in', 'phone', 'email', 'company', 'agency', 'website', 'other'];

export function Settings() {
  const { t } = useI18n();
  const toast = useToast();
  const [s, setS] = useState<any>(null);
  const [hotel, setHotel] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  const load = () => get('/api/settings/all').then((r) => { setS(r.settings); setHotel(r.hotel); }).catch((e) => toast('error', e.message));
  useEffect(() => { load(); }, []);
  if (!s || !hotel) return <Page>{t('common.loading')}</Page>;

  const dep = s.deposit_policy;
  const can = s.cancellation_policy;
  const setDep = (p: any) => setS({ ...s, deposit_policy: { ...dep, ...p } });
  const setCan = (p: any) => setS({ ...s, cancellation_policy: { ...can, ...p } });
  const num = (v: string) => Number(String(v).replace(',', '.')) || 0;

  const save = async () => {
    setBusy(true);
    try {
      await api('PUT', '/api/hotel', hotel);
      await api('PUT', '/api/settings', {
        meal_supplements: Object.fromEntries(Object.entries(s.meal_supplements).map(([k, v]) => [k, num(String(v))])),
        vat_rate: num(s.vat_rate), tourist_tax_per_adult_night: num(s.tourist_tax_per_adult_night),
        check_in_time: s.check_in_time, check_out_time: s.check_out_time,
        reminder_days_before: Math.round(num(s.reminder_days_before)), default_guest_language: s.default_guest_language,
        deposit_policy: { mode: dep.mode, percent: num(dep.percent), exempt_sources: dep.exempt_sources ?? [] },
        cancellation_policy: {
          enabled: !!can.enabled, hours_before: Math.round(num(can.hours_before)), fee_type: can.fee_type, fee_value: num(can.fee_value),
          no_show_enabled: !!can.no_show_enabled, no_show_fee_type: can.no_show_fee_type, no_show_fee_value: num(can.no_show_fee_value),
        },
        smtp: s.smtp?.host ? { host: s.smtp.host, port: Math.round(num(s.smtp.port || 587)), user: s.smtp.user || undefined, pass: s.smtp.pass || undefined, from: s.smtp.from || undefined } : null,
      });
      toast('success', t('set.saved'));
      load();
    } catch (e: any) {
      toast('error', e.message);
    } finally {
      setBusy(false);
    }
  };

  const feeSelect = (value: string, onChange: (v: string) => void, id: string) => (
    <select id={id} className="input" value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="nights">{t('set.feeNights')}</option><option value="percent">{t('set.feePercent')}</option><option value="amount">{t('set.feeAmount')}</option>
    </select>
  );

  return (
    <Page>
      <div className="page-head">
        <h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('set.title')}</h1>
        <button className="btn primary" disabled={busy} onClick={save}>{t('common.save')}</button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(380px, 1fr))', gap: 14, alignItems: 'start' }}>
        <div className="section card">
          <h3>{t('set.hotel')}</h3>
          <div className="form-grid">
            <Field label={t('set.hotelName')} htmlFor="h-n"><input id="h-n" className="input" value={hotel.name ?? ''} onChange={(e) => setHotel({ ...hotel, name: e.target.value })} /></Field>
            <Field label={t('form.address')} htmlFor="h-a"><input id="h-a" className="input" value={hotel.address ?? ''} onChange={(e) => setHotel({ ...hotel, address: e.target.value })} /></Field>
            <Field label={t('set.city')} htmlFor="h-c"><input id="h-c" className="input" value={hotel.city ?? ''} onChange={(e) => setHotel({ ...hotel, city: e.target.value })} /></Field>
            <Field label={t('new.phone')} htmlFor="h-p"><input id="h-p" className="input" value={hotel.phone ?? ''} onChange={(e) => setHotel({ ...hotel, phone: e.target.value })} /></Field>
            <Field label={t('new.email')} htmlFor="h-e"><input id="h-e" className="input" value={hotel.email ?? ''} onChange={(e) => setHotel({ ...hotel, email: e.target.value })} /></Field>
            {(['nif', 'nis', 'rc', 'art'] as const).map((k) => (
              <Field key={k} label={k.toUpperCase()} htmlFor={`h-${k}`}><input id={`h-${k}`} className="input" value={hotel[k] ?? ''} onChange={(e) => setHotel({ ...hotel, [k]: e.target.value })} /></Field>
            ))}
          </div>
        </div>

        <div className="section card">
          <h3>{t('set.deposit')}</h3>
          <Field label={t('set.depMode')} htmlFor="d-m">
            <select id="d-m" className="input" value={dep.mode} onChange={(e) => setDep({ mode: e.target.value })}>
              <option value="none">{t('set.depNone')}</option><option value="auto_pending">{t('set.depAuto')}</option><option value="block">{t('set.depBlock')}</option>
            </select>
          </Field>
          {dep.mode !== 'none' && (
            <>
              <Field label={`${t('set.percent')} (%)`} htmlFor="d-p"><input id="d-p" className="input" inputMode="decimal" value={dep.percent} onChange={(e) => setDep({ percent: e.target.value })} /></Field>
              <div className="field"><label>{t('set.exempt')}</label>
                <div className="row" style={{ gap: 6 }}>
                  {SOURCES.map((x) => {
                    const on = (dep.exempt_sources ?? []).includes(x);
                    return <button key={x} className={`chip ${on ? 'on' : ''}`} aria-pressed={on} onClick={() => setDep({ exempt_sources: on ? dep.exempt_sources.filter((y: string) => y !== x) : [...(dep.exempt_sources ?? []), x] })}>{t(`src.${x}` as Key)}</button>;
                  })}
                </div>
              </div>
            </>
          )}
        </div>

        <div className="section card">
          <h3>{t('set.cancel')}</h3>
          <label className="row" style={{ gap: 8, fontSize: 14 }}><input type="checkbox" checked={!!can.enabled} onChange={(e) => setCan({ enabled: e.target.checked })} /> {t('set.cancelOn')}</label>
          {can.enabled && (
            <div className="form-grid">
              <Field label={t('set.hoursBefore')} htmlFor="c-h"><input id="c-h" className="input" inputMode="numeric" value={can.hours_before} onChange={(e) => setCan({ hours_before: e.target.value })} /></Field>
              <Field label={t('set.feeType')} htmlFor="c-t">{feeSelect(can.fee_type, (v) => setCan({ fee_type: v }), 'c-t')}</Field>
              <Field label={t('set.feeValue')} htmlFor="c-v"><input id="c-v" className="input" inputMode="decimal" value={can.fee_value} onChange={(e) => setCan({ fee_value: e.target.value })} /></Field>
            </div>
          )}
          <h3 style={{ marginTop: 6 }}>{t('set.noShow')}</h3>
          <label className="row" style={{ gap: 8, fontSize: 14 }}><input type="checkbox" checked={!!can.no_show_enabled} onChange={(e) => setCan({ no_show_enabled: e.target.checked })} /> {t('set.noShowOn')}</label>
          {can.no_show_enabled && (
            <div className="form-grid">
              <Field label={t('set.feeType')} htmlFor="n-t">{feeSelect(can.no_show_fee_type, (v) => setCan({ no_show_fee_type: v }), 'n-t')}</Field>
              <Field label={t('set.feeValue')} htmlFor="n-v"><input id="n-v" className="input" inputMode="decimal" value={can.no_show_fee_value} onChange={(e) => setCan({ no_show_fee_value: e.target.value })} /></Field>
            </div>
          )}
        </div>

        <div className="section card">
          <h3>{t('set.rates')}</h3>
          <div className="form-grid">
            {['BB', 'HB', 'FB'].map((m) => (
              <Field key={m} label={`${t(`meal.${m}` as Key)} — ${t('set.supp')}`} htmlFor={`m-${m}`}>
                <input id={`m-${m}`} className="input" inputMode="decimal" value={s.meal_supplements[m]} onChange={(e) => setS({ ...s, meal_supplements: { ...s.meal_supplements, [m]: e.target.value } })} />
              </Field>
            ))}
            <Field label={`${t('form.vat')} (%)`} htmlFor="tx-v"><input id="tx-v" className="input" inputMode="decimal" value={s.vat_rate} onChange={(e) => setS({ ...s, vat_rate: e.target.value })} /></Field>
            <Field label={`${t('form.touristTax')} (DA)`} htmlFor="tx-t"><input id="tx-t" className="input" inputMode="decimal" value={s.tourist_tax_per_adult_night} onChange={(e) => setS({ ...s, tourist_tax_per_adult_night: e.target.value })} /></Field>
            <Field label="Check-in" htmlFor="tm-i"><input id="tm-i" className="input" type="time" value={s.check_in_time} onChange={(e) => setS({ ...s, check_in_time: e.target.value })} /></Field>
            <Field label="Check-out" htmlFor="tm-o"><input id="tm-o" className="input" type="time" value={s.check_out_time} onChange={(e) => setS({ ...s, check_out_time: e.target.value })} /></Field>
          </div>
        </div>

        <div className="section card">
          <h3>{t('set.notif')}</h3>
          <div className="form-grid">
            <Field label={t('set.reminderDays')} htmlFor="nt-d"><input id="nt-d" className="input" inputMode="numeric" value={s.reminder_days_before} onChange={(e) => setS({ ...s, reminder_days_before: e.target.value })} /></Field>
            <Field label={t('set.defLang')} htmlFor="nt-l">
              <select id="nt-l" className="input" value={s.default_guest_language} onChange={(e) => setS({ ...s, default_guest_language: e.target.value })}>
                {['fr', 'en', 'ar'].map((l) => <option key={l} value={l}>{t(`lang.${l}` as Key)}</option>)}
              </select>
            </Field>
          </div>
          <h3 style={{ marginTop: 6 }}>{t('set.smtp')}</h3>
          <SmtpHelp s={s} setS={setS} />
          <div className="form-grid">
            {(['host', 'port', 'user', 'pass', 'from'] as const).map((k) => (
              <Field key={k} label={t(`set.smtp${k[0].toUpperCase()}${k.slice(1)}` as Key)} htmlFor={`sm-${k}`}>
                <input id={`sm-${k}`} className="input" type={k === 'pass' ? 'password' : 'text'} value={s.smtp?.[k] ?? ''} onChange={(e) => setS({ ...s, smtp: { ...(s.smtp ?? {}), [k]: e.target.value } })} />
              </Field>
            ))}
          </div>
        </div>
        <MonthlyReport />
      </div>
    </Page>
  );
}


/** Envoi automatique par Gmail (ou tout serveur SMTP) : préréglage, mode d'emploi du mot de passe d'application, e-mail de test. */
function SmtpHelp({ s, setS }: { s: any; setS: (x: any) => void }) {
  const { t } = useI18n();
  const g = (k: string) => t(`gm.${k}` as Key);
  const [to, setTo] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const isGmail = s.smtp?.host === 'smtp.gmail.com';
  const test = async () => {
    setBusy(true); setMsg(null);
    try { const r = await post('/api/settings/smtp-test', { to }); setMsg({ ok: true, text: `${g('sent')}${r.pending_sent ? ` · ${r.pending_sent} ${g('pendingSent')}` : ''}` }); }
    catch (e: any) { setMsg({ ok: false, text: e.message }); } finally { setBusy(false); }
  };
  return (
    <div style={{ marginBottom: 10 }}>
      <div className="row" style={{ gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <button type="button" className="btn sm" onClick={() => setS({ ...s, smtp: { ...(s.smtp ?? {}), host: 'smtp.gmail.com', port: 587, from: s.smtp?.from || s.smtp?.user || '' } })}>✉️ {g('preset')}</button>
        <span className="muted" style={{ fontSize: 12 }}>{g('auto')}</span>
      </div>
      {isGmail && <div className="alert info" style={{ marginTop: 8, fontSize: 13 }}>
        <b>{g('howTitle')}</b>
        <ol style={{ margin: '6px 0 0', paddingInlineStart: 18 }}>{['s1', 's2', 's3', 's4', 's5'].map((k) => <li key={k}>{g(k)}</li>)}</ol>
      </div>}
      <div className="row" style={{ gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
        <input className="input" style={{ maxWidth: 280 }} type="email" placeholder={g('testTo')} value={to} onChange={(e) => setTo(e.target.value)} />
        <button type="button" className="btn sm" disabled={busy || !to} onClick={test}>{busy ? '…' : g('test')}</button>
        <span className="muted" style={{ fontSize: 12 }}>{g('saveFirst')}</span>
      </div>
      {msg && <div className={`alert ${msg.ok ? 'info' : 'danger'}`} style={{ marginTop: 8 }}>{msg.ok ? '✓ ' : ''}{msg.text}</div>}
    </div>
  );
}

/** Rapport mensuel PDF envoyé automatiquement au directeur le 1er de chaque mois. */
function MonthlyReport() {
  const { t } = useI18n();
  const r = (k: string) => t(`mr.${k}` as Key);
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const [cfg, setCfg] = useState<any>(null);
  const [month, setMonth] = useState('');
  const [busy, setBusy] = useState('');
  const load = () => get('/api/monthly-report').then((x) => { setD(x); setCfg({ enabled: x.config.enabled, recipients: (x.config.recipients ?? []).join(', ') }); setMonth((m) => m || x.last_month); }).catch((e) => toast('error', e.message));
  useEffect(() => { load(); }, []);
  if (!d || !cfg) return null;
  const list = cfg.recipients.split(/[,;\s]+/).map((x: string) => x.trim()).filter(Boolean);
  const save = async () => { setBusy('save'); try { await api('PUT', '/api/monthly-report', { enabled: cfg.enabled, recipients: list }); toast('success', r('saved')); load(); } catch (e: any) { toast('error', e.message); } finally { setBusy(''); } };
  const send = async () => { setBusy('send'); try { const x = await post('/api/monthly-report/send', { month }); toast('success', `${r('sent')} ${x.to.join(', ')}`); load(); } catch (e: any) { toast('error', e.message); load(); } finally { setBusy(''); } };
  return (
    <div className="section card">
      <h3>📊 {r('title')}</h3>
      <p className="muted" style={{ marginTop: 0, fontSize: 13 }}>{r('intro')}</p>
      {!d.smtp_ready && <div className="alert warning">{r('noSmtp')}</div>}
      <label className="row" style={{ gap: 8, fontSize: 14 }}><input type="checkbox" checked={cfg.enabled} onChange={(e) => setCfg({ ...cfg, enabled: e.target.checked })} /> {r('enable')}</label>
      <Field label={r('recipients')} htmlFor="mr-to"><input id="mr-to" className="input" dir="ltr" placeholder="directeur@hotel.dz, gerant@hotel.dz" value={cfg.recipients} onChange={(e) => setCfg({ ...cfg, recipients: e.target.value })} /></Field>
      <div><button className="btn primary" disabled={!!busy} onClick={save}>{t('common.save')}</button></div>
      <div className="row" style={{ gap: 8, flexWrap: 'wrap', marginTop: 14, alignItems: 'center' }}>
        <input type="month" className="input" style={{ width: 170 }} value={month} onChange={(e) => setMonth(e.target.value)} aria-label={r('month')} />
        <a className="btn" href={`/api/monthly-report/pdf?month=${month}`} target="_blank" rel="noreferrer">👁 {r('preview')}</a>
        <button className="btn" disabled={!!busy || !d.smtp_ready || !list.length} onClick={send}>✉️ {busy === 'send' ? '…' : r('sendNow')}</button>
      </div>
      {d.history.length > 0 && <div style={{ marginTop: 12 }}>
        <div className="muted" style={{ fontSize: 12, marginBottom: 4 }}>{r('history')}</div>
        {d.history.slice(0, 6).map((h: any) => (
          <div key={h.id} className="sum-row" style={{ fontSize: 13 }}>
            <span>{h.status === 'sent' ? '✓' : h.status === 'failed' ? '✗' : '…'} {h.month} · {h.trigger === 'auto' ? r('auto') : r('manual')} · {h.recipients.join(', ')}</span>
            <span className="muted" title={h.last_error ?? ''}>{h.status === 'sent' ? new Date(h.sent_at).toLocaleString() : (h.last_error ?? r('pending'))}</span>
          </div>))}
      </div>}
    </div>
  );
}
