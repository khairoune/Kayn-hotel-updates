import { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { InvoiceDrawer, InvStatus, ManualInvoiceModal, toNum } from '../components/Billing';
import { Page } from '../components/Layout';
import { ReasonModal, ReservationPanel } from '../components/ReservationPanel';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { api, ApiError, get, newOpKey, post, postOnce } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, fmtDateTime, money, todayLocal, currency } from '../lib/format';
import { useLive } from '../lib/useLive';

type Tab = 'invoices' | 'cash' | 'transactions' | 'expenses' | 'receivables' | 'reports' | 'taxes';
const monthStart = () => `${todayLocal().slice(0, 8)}01`;

export function Billing() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const [sp, setSp] = useSearchParams();
  const tabs = ([['invoices', 'invoices.view'], ['cash', 'cash.operate'], ['transactions', 'finance.reports'], ['expenses', 'expenses.create'], ['receivables', 'invoices.view'], ['reports', 'finance.reports'], ['taxes', 'settings.manage']] as [Tab, string][]).filter(([, p]) => can(p)).map(([k]) => k);
  const tab = (sp.get('tab') as Tab) && tabs.includes(sp.get('tab') as Tab) ? (sp.get('tab') as Tab) : tabs[0];
  const setTab = (k: Tab) => setSp({ tab: k }, { replace: true });
  const [period, setPeriod] = useState({ from: monthStart(), to: todayLocal() });
  const [sum, setSum] = useState<any>(null);
  const loadSum = useCallback(() => { if (can('finance.reports')) get(`/api/finance/summary?from=${period.from}&to=${period.to}`).then(setSum).catch(() => {}); }, [period]);
  useEffect(() => { loadSum(); }, [loadSum]);
  useLive(loadSum, 60000);
  return (
    <Page>
      <div className="page-head">
        <h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('bi.title')}</h1>
        <div className="row" style={{ gap: 6 }}>
          <span className="muted">{t('bi.period')}</span>
          <input type="month" className="input" style={{ width: 170 }} aria-label={t('dash.colMonth')} value={period.from.slice(0, 7)} onChange={(e) => { const v = e.target.value; if (!v) return; const [y, mo] = v.split('-').map(Number); const last = new Date(Date.UTC(y, mo, 0)).toISOString().slice(0, 10); const today = todayLocal(); setPeriod({ from: `${v}-01`, to: last > today ? today : last }); }} />
          <span className="muted">{t('bi.orDates')}</span>
          <input type="date" className="input" style={{ width: 160 }} aria-label={t('bi.from')} value={period.from} onChange={(e) => e.target.value && setPeriod({ ...period, from: e.target.value })} />
          <input type="date" className="input" style={{ width: 160 }} aria-label={t('bi.to')} value={period.to} min={period.from} onChange={(e) => e.target.value && setPeriod({ ...period, to: e.target.value })} />
        </div>
      </div>
      {sum && (
        <div className="grid kpis">
          {[['bi.kRevenue', sum.revenue_ttc], ['bi.kCollected', sum.collected], ['bi.kExpenses', sum.expenses], ['bi.kVat', sum.vat], ['bi.kReceivables', sum.receivables]].map(([k, v]) => (
            <div key={k as string} className="card kpi"><span className="label">{t(k as Key)}</span><span className="value" style={{ fontSize: 21 }}>{money(v as number, locale)}</span></div>
          ))}
        </div>
      )}
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>
        {tabs.map((k) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{t(`bi.${k}` as Key)}</button>)}
      </div>
      {tab === 'invoices' && <Invoices period={period} />}
      {tab === 'cash' && <Cash />}
      {tab === 'transactions' && <Transactions period={period} />}
      {tab === 'expenses' && <Expenses period={period} />}
      {tab === 'receivables' && <Receivables />}
      {tab === 'reports' && <Reports period={period} />}
      {tab === 'taxes' && <Taxes />}
    </Page>
  );
}

// ===================================================== Factures =====================================================
function Invoices({ period }: { period: { from: string; to: string } }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [f, setF] = useState({ search: '', type: '', status: '' });
  const [page, setPage] = useState(1);
  const [data, setData] = useState<any>(null);
  const [open, setOpen] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const load = useCallback(() => {
    const qs = new URLSearchParams({ search: f.search, from: period.from, to: period.to, page: String(page) });
    if (f.type) qs.set('type', f.type);
    if (f.status) qs.set('status', f.status);
    get(`/api/invoices?${qs}`).then(setData).catch((e) => toast('error', e.message));
  }, [f, period, page]);
  useEffect(() => { const h = setTimeout(load, 200); return () => clearTimeout(h); }, [load]);
  useLive(load);
  const pages = data ? Math.max(1, Math.ceil(data.total / data.page_size)) : 1;
  return (
    <>
      <div className="row">
        <input className="input" style={{ maxWidth: 280 }} placeholder={t('common.search')} aria-label={t('common.search')} value={f.search} onChange={(e) => { setF({ ...f, search: e.target.value }); setPage(1); }} />
        <select className="input" style={{ width: 'auto' }} aria-label={t('bi.type')} value={f.type} onChange={(e) => { setF({ ...f, type: e.target.value }); setPage(1); }}>
          <option value="">{t('bi.all')} — {t('bi.type')}</option>{['invoice', 'proforma', 'credit_note'].map((x) => <option key={x} value={x}>{t(`bi.t.${x}` as Key)}</option>)}
        </select>
        <select className="input" style={{ width: 'auto' }} aria-label={t('bi.status')} value={f.status} onChange={(e) => { setF({ ...f, status: e.target.value }); setPage(1); }}>
          <option value="">{t('bi.all')} — {t('bi.status')}</option>{['issued', 'partially_paid', 'paid', 'credited', 'proforma'].map((x) => <option key={x} value={x}>{t(`bi.s.${x}` as Key)}</option>)}
        </select>
        <span style={{ flex: 1 }} />
        {can('invoices.create') && <button className="btn primary" onClick={() => setCreating(true)}><Icon name="plus" /> {t('bi.newInvoice')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('bi.number')}</th><th>{t('bi.date')}</th><th>{t('bi.type')}</th><th>{t('bi.client')}</th><th>{t('bi.stay')}</th><th className="num">{t('bi.total')}</th><th>{t('bi.status')}</th><th /></tr></thead>
          <tbody>
            {!data ? <tr><td colSpan={8}>{t('common.loading')}</td></tr> : !data.rows.length ? <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr> : data.rows.map((x: any) => (
              <tr key={x.id} onClick={() => setOpen(x.id)} style={{ cursor: 'pointer' }}>
                <td><b>{x.number}</b>{x.credit_of && <div className="muted" style={{ fontSize: 11.5 }}>→ {x.credit_of}</div>}</td>
                <td>{fmtDateTime(x.issued_at, locale)}</td><td>{t(`bi.t.${x.type}` as Key)}</td><td>{x.client}</td><td>{x.code ?? '—'}</td>
                <td className="num" style={{ color: Number(x.total) < 0 ? 'var(--danger)' : undefined }}>{money(Number(x.total), locale)}</td>
                <td><InvStatus s={x.status} type={x.type} /></td>
                <td onClick={(e) => e.stopPropagation()}><button className="btn sm ghost" onClick={() => window.open(`/api/invoices/${x.id}/pdf`, '_blank')}>PDF</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {pages > 1 && <div className="row" style={{ justifyContent: 'center' }}><button className="btn sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>‹</button><span>{page} / {pages}</span><button className="btn sm" disabled={page >= pages} onClick={() => setPage(page + 1)}>›</button></div>}
      {open && <InvoiceDrawer id={open} onClose={() => setOpen(null)} onChanged={load} />}
      {creating && <ManualInvoiceModal onClose={() => setCreating(false)} onDone={(id) => { setCreating(false); load(); setOpen(id); }} />}
    </>
  );
}

// ===================================================== Caisse =====================================================
function Cash() {
  const { t, locale } = useI18n();
  const { can, me } = useAuth();
  const toast = useToast();
  const [regs, setRegs] = useState<any[]>([]);
  const [cur, setCur] = useState<any>(undefined);
  const [hist, setHist] = useState<any[]>([]);
  const [modal, setModal] = useState<null | 'open' | 'in' | 'out' | 'expense' | 'income' | 'close' | 'register'>(null);
  const [validateId, setValidateId] = useState<number | null>(null);
  const load = useCallback(() => {
    get('/api/cash/registers').then(setRegs).catch(() => {});
    get('/api/cash/current').then((c) => setCur(c && (c.opened_by === me?.id || can('cash.manage')) ? c : c ? { ...c, foreign: true } : null)).catch(() => setCur(null));
    get(`/api/cash/sessions?from=${addMonths(-1)}&to=${todayLocal()}`).then(setHist).catch(() => {});
  }, [me?.id]);
  useEffect(() => { load(); }, [load]);
  useLive(load, 20000);
  const shown = cur;
  return (
    <>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
        {regs.map((r) => (
          <div key={r.id} className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6, borderTop: `3px solid ${r.open_session_id ? 'var(--ok)' : 'var(--border)'}` }}>
            <b>{r.name}</b>
            <span className="muted" style={{ fontSize: 13 }}>{r.open_session_id ? `${t('cs.openedBy')} ${r.opened_by_name} · n° ${r.open_session_id}` : t('cs.closed')}</span>
            {!r.open_session_id && <button className="btn sm primary" style={{ alignSelf: 'flex-start' }} onClick={() => setModal('open')}>{t('cs.open')}</button>}
          </div>
        ))}
        {can('cash.manage') && <button className="card" style={{ font: 'inherit', cursor: 'pointer', color: 'var(--muted)' }} onClick={() => setModal('register')}><Icon name="plus" /> {t('cs.newRegister')}</button>}
      </div>
      {shown && !shown.foreign && <SessionCard s={shown} onAction={setModal} />}
      {shown?.foreign && <div className="alert">{t('cs.openedBy')} {shown.opened_by_name} — {shown.register_name}</div>}
      {!shown && cur === null && <div className="alert">{t('cs.needOpen')}</div>}
      <h3 style={{ margin: '4px 0 0', fontSize: 14 }}>{t('cs.history')}</h3>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>N°</th><th>{t('cs.register')}</th><th>{t('cs.openedBy')}</th><th>Ouverture</th><th>Clôture</th><th className="num">{t('cs.expected')}</th><th className="num">{t('cs.counted')}</th><th className="num">{t('cs.difference')}</th><th /></tr></thead>
          <tbody>
            {hist.map((s) => (
              <tr key={s.id}>
                <td>{s.id}</td><td>{s.register_name}</td><td>{s.opened_by_name}</td><td>{fmtDateTime(s.opened_at, locale)}</td><td>{s.closed_at ? fmtDateTime(s.closed_at, locale) : <span className="pill" style={{ background: 'var(--ok-bg)', color: 'var(--ok)' }}>Ouverte</span>}</td>
                <td className="num">{s.expected_amount !== null ? money(Number(s.expected_amount), locale) : '—'}</td>
                <td className="num">{s.declared_amount !== null ? money(Number(s.declared_amount), locale) : '—'}</td>
                <td className="num" style={{ color: Number(s.difference) ? 'var(--danger)' : undefined, fontWeight: 600 }}>{s.difference !== null ? money(Number(s.difference), locale) : '—'}</td>
                <td><div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                  <button className="btn sm ghost" onClick={() => window.open(`/api/cash/sessions/${s.id}/pdf`, '_blank')}>{t('cs.report')}</button>
                  {s.status === 'closed' && !s.validated_at && can('cash.manage') && <button className="btn sm" onClick={() => setValidateId(s.id)}>{t('cs.validate')}</button>}
                  {s.validated_at && <span className="pill" style={{ background: 'var(--ok-bg)', color: 'var(--ok)' }} title={s.validated_by_name}>{t('cs.validated')}</span>}
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {modal === 'open' && <OpenModal regs={regs.filter((r) => !r.open_session_id)} onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {modal === 'register' && <ReasonModal title={t('cs.newRegister')} defaultReason="Caisse restaurant" onClose={() => setModal(null)} onSubmit={(name) => post('/api/cash/registers', { name }).then(() => { setModal(null); load(); }).catch((e) => toast('error', e.message))} />}
      {(modal === 'in' || modal === 'out') && cur && <MoveModal sid={cur.id} dir={modal} onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {modal === 'expense' && <ExpenseModal kind="expense" onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {modal === 'income' && <ExpenseModal kind="income" onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {modal === 'close' && cur && <CloseModal s={cur} onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {validateId && <ReasonModal title={`${t('cs.validate')} n° ${validateId}`} defaultReason="Clôture contrôlée" onClose={() => setValidateId(null)} onSubmit={(note) => post(`/api/cash/sessions/${validateId}/validate`, { note }).then(() => { setValidateId(null); load(); toast('success', t('cs.validated')); }).catch((e) => toast('error', e.message))} />}
    </>
  );
}
const addMonths = (n: number) => { const d = new Date(); d.setMonth(d.getMonth() + n); return d.toISOString().slice(0, 10); };

function SessionCard({ s, onAction }: { s: any; onAction: (m: any) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div className="row between">
        <div><b style={{ fontSize: 16 }}>{s.register_name} · n° {s.id}</b><div className="muted" style={{ fontSize: 13 }}>{t('cs.openedBy')} {s.opened_by_name} · {fmtDateTime(s.opened_at, locale)}</div></div>
        <div className="row" style={{ gap: 6 }}>
          <button className="btn sm" onClick={() => onAction('in')}>+ {t('cs.cashIn')}</button>
          <button className="btn sm" onClick={() => onAction('out')}>− {t('cs.cashOut')}</button>
          {can('expenses.create') && <button className="btn sm" onClick={() => onAction('expense')}>{t('cs.expense')}</button>}
          <button className="btn sm" onClick={() => onAction('income')}>{t('cs.income')}</button>
          <button className="btn sm ghost" onClick={() => window.open(`/api/cash/sessions/${s.id}/pdf`, '_blank')}>{t('cs.report')}</button>
          <button className="btn sm primary" onClick={() => onAction('close')}>{t('cs.close')}</button>
        </div>
      </div>
      <div className="grid kpis">
        <div className="mini"><span>{t('cs.opening')}</span><b>{money(s.totals.opening, locale)}</b></div>
        <div className="mini"><span>{t('cs.in')}</span><b style={{ color: 'var(--ok)' }}>+ {money(s.totals.cash_in, locale)}</b></div>
        <div className="mini"><span>{t('cs.out')}</span><b style={{ color: 'var(--danger)' }}>− {money(s.totals.cash_out, locale)}</b></div>
        <div className="mini" style={{ background: 'var(--gold-soft)' }}><span>{t('cs.expected')}</span><b style={{ fontSize: 19 }}>{money(s.totals.expected, locale)}</b></div>
      </div>
      <div className="row" style={{ gap: 6 }}>
        <span className="muted" style={{ fontSize: 13 }}>{t('cs.byMethod')} :</span>
        {Object.entries(s.totals.by_method).map(([m, v]) => <span key={m} className="pill" style={{ background: 'var(--soft)' }}>{t(`pm.${m}` as Key)} {money(v as number, locale)}</span>)}
      </div>
      <div style={{ maxHeight: 300, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>Heure</th><th>{t('cs.ops')}</th><th>Réf.</th><th>{t('common.method')}</th><th>Par</th><th className="num">{t('common.amount')}</th></tr></thead>
          <tbody>{[...s.operations].reverse().map((o: any) => (
            <tr key={`${o.type}${o.id}`} style={{ opacity: o.void ? 0.5 : 1, textDecoration: o.void ? 'line-through' : undefined }}>
              <td>{new Date(o.at).toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' })}</td><td className="wrap">{o.label}</td><td>{o.ref ?? ''}</td><td>{t(`pm.${o.method}` as Key)}</td><td>{o.by_name}</td>
              <td className="num" style={{ color: Number(o.amount) < 0 ? 'var(--danger)' : 'var(--ok)', fontWeight: 600 }}>{money(Number(o.amount), locale)}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}

function OpenModal({ regs, onClose, onDone }: { regs: any[]; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('open'));
  const [x, setX] = useState({ register_id: regs[0]?.id ?? '', amount: '', note: '' });
  const submit = () => postOnce('/api/cash/sessions/open', { register_id: Number(x.register_id) || null, opening_amount: toNum(x.amount), note: x.note || null }, key).then(() => { toast('success', t('cs.open')); onDone(); }).catch((e) => toast('error', e.message));
  return (
    <Modal title={t('cs.open')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={x.amount === ''} onClick={submit}>{t('common.confirm')}</button></>}>
      <div className="form-grid">
        <Field label={t('cs.register')} htmlFor="op-r"><select id="op-r" className="input" value={x.register_id} onChange={(e) => setX({ ...x, register_id: e.target.value })}>{regs.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></Field>
        <Field label={`${t('cs.float')} (DA)`} htmlFor="op-a"><input id="op-a" className="input" inputMode="decimal" autoFocus value={x.amount} onChange={(e) => setX({ ...x, amount: e.target.value })} /></Field>
      </div>
    </Modal>
  );
}

function MoveModal({ sid, dir, onClose, onDone }: { sid: number; dir: 'in' | 'out'; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [key] = useState(() => newOpKey('mv'));
  const [x, setX] = useState({ category: 'other', amount: '', description: '', reference: '' });
  const CAT: Record<string, string> = { float: 'Complément de fond', change: 'Monnaie', bank_deposit: 'Versement en banque', withdrawal: 'Retrait (direction)', other: 'Autre' };
  const cats = dir === 'in' ? ['float', 'change', 'other'] : ['change', 'other', ...(can('cash.manage') ? ['bank_deposit', 'withdrawal'] : [])];
  const submit = () => postOnce(`/api/cash/sessions/${sid}/movements`, { direction: dir, category: x.category, amount: toNum(x.amount), description: x.description, reference: x.reference || null }, key).then(() => onDone()).catch((e) => toast('error', e.message));
  return (
    <Modal title={dir === 'in' ? t('cs.cashIn') : t('cs.cashOut')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!(toNum(x.amount) > 0) || x.description.trim().length < 2} onClick={submit}>{t('common.confirm')}</button></>}>
      <div className="form-grid">
        <Field label={t('bi.category')} htmlFor="mv-c"><select id="mv-c" className="input" value={x.category} onChange={(e) => setX({ ...x, category: e.target.value })}>{cats.map((c) => <option key={c} value={c}>{CAT[c]}</option>)}</select></Field>
        <Field label={t('common.amount')} htmlFor="mv-a"><input id="mv-a" className="input" inputMode="decimal" value={x.amount} onChange={(e) => setX({ ...x, amount: e.target.value })} /></Field>
        <Field label={t('ch.desc')} htmlFor="mv-d"><input id="mv-d" className="input" value={x.description} onChange={(e) => setX({ ...x, description: e.target.value })} /></Field>
        <Field label={t('common.reference')} htmlFor="mv-ref"><input id="mv-ref" className="input" value={x.reference} onChange={(e) => setX({ ...x, reference: e.target.value })} /></Field>
      </div>
    </Modal>
  );
}

function CloseModal({ s, onClose, onDone }: { s: any; onClose: () => void; onDone: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('close'));
  const [counted, setCounted] = useState('');
  const [just, setJust] = useState('');
  const [err, setErr] = useState('');
  const diff = counted === '' ? null : Math.round((toNum(counted) - s.totals.expected) * 100) / 100;
  const submit = async () => {
    try { await postOnce(`/api/cash/sessions/${s.id}/close`, { counted_amount: toNum(counted), justification: just || null }, key); toast('success', `${t('cs.close')} — n° ${s.id}`); onDone(); window.open(`/api/cash/sessions/${s.id}/pdf`, '_blank'); }
    catch (e: any) { setErr(e instanceof ApiError ? e.message : String(e)); }
  };
  return (
    <Modal title={`${t('cs.close')} — ${s.register_name} n° ${s.id}`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={counted === '' || (diff !== 0 && just.trim().length < 5)} onClick={submit}>{t('common.confirm')}</button></>}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {err && <div className="alert">{err}</div>}
        <div className="kv"><div><span>{t('cs.expected')}</span><b>{money(s.totals.expected, locale)}</b></div><div><span>{t('cs.difference')}</span><b style={{ color: diff ? 'var(--danger)' : 'var(--ok)' }}>{diff === null ? '—' : money(diff, locale)}</b></div></div>
        <Field label={`${t('cs.counted')} (DA)`} htmlFor="cl-c"><input id="cl-c" className="input" inputMode="decimal" autoFocus value={counted} onChange={(e) => setCounted(e.target.value)} /></Field>
        {diff !== null && diff !== 0 && <Field label={`${t('cs.justification')} *`} htmlFor="cl-j"><textarea id="cl-j" className="input" rows={2} value={just} onChange={(e) => setJust(e.target.value)} /></Field>}
        <span className="muted" style={{ fontSize: 12.5 }}>Le solde théorique est calculé automatiquement (fond + espèces encaissées + entrées − sorties − dépenses − remboursements). Toute différence doit être justifiée ; un superviseur valide ensuite la clôture.</span>
      </div>
    </Modal>
  );
}

function ExpenseModal({ kind, onClose, onDone }: { kind: 'expense' | 'income'; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey(kind));
  const [cats, setCats] = useState<string[]>([]);
  const [x, setX] = useState({ category: '', description: '', amount: '', method: 'cash', supplier: '', date: todayLocal(), reference: '' });
  useEffect(() => { if (kind === 'expense') get('/api/expense-categories').then((r) => setCats(r.map((c: any) => c.name))).catch(() => {}); else setCats(['Location de salle', 'Vente comptoir', 'Commission', 'Divers']); }, [kind]);
  const submit = () => postOnce(kind === 'expense' ? '/api/expenses' : '/api/incomes', kind === 'expense'
    ? { category: x.category, description: x.description, amount: toNum(x.amount), method: x.method, supplier: x.supplier || null, expense_date: x.date, reference: x.reference || null }
    : { category: x.category, description: x.description, amount: toNum(x.amount), method: x.method, income_date: x.date, reference: x.reference || null }, key)
    .then(() => { toast('success', `${kind === 'expense' ? t('cs.expense') : t('cs.income')} : ${x.amount} ${currency.symbol}`); onDone(); }).catch((e) => toast('error', e.message));
  return (
    <Modal title={kind === 'expense' ? t('ex.newExpense') : t('ex.newIncome')} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={x.category.trim().length < 2 || x.description.trim().length < 2 || !(toNum(x.amount) > 0)} onClick={submit}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('bi.category')} htmlFor="ex-c"><input id="ex-c" className="input" list="ex-cats" value={x.category} onChange={(e) => setX({ ...x, category: e.target.value })} /></Field>
        <datalist id="ex-cats">{cats.map((c) => <option key={c} value={c} />)}</datalist>
        <Field label={t('ch.desc')} htmlFor="ex-d"><input id="ex-d" className="input" value={x.description} onChange={(e) => setX({ ...x, description: e.target.value })} /></Field>
        <Field label={t('common.amount')} htmlFor="ex-a"><input id="ex-a" className="input" inputMode="decimal" value={x.amount} onChange={(e) => setX({ ...x, amount: e.target.value })} /></Field>
        <Field label={t('common.method')} htmlFor="ex-m"><select id="ex-m" className="input" value={x.method} onChange={(e) => setX({ ...x, method: e.target.value })}>{['cash', 'card', 'cheque', 'transfer'].map((m) => <option key={m} value={m}>{t(`pm.${m}` as Key)}</option>)}</select></Field>
        {kind === 'expense' && <Field label={t('ex.supplier')} htmlFor="ex-s"><input id="ex-s" className="input" value={x.supplier} onChange={(e) => setX({ ...x, supplier: e.target.value })} /></Field>}
        <Field label={t('bi.date')} htmlFor="ex-dt"><input id="ex-dt" type="date" className="input" max={todayLocal()} value={x.date} onChange={(e) => setX({ ...x, date: e.target.value })} /></Field>
        <Field label={t('common.reference')} htmlFor="ex-r"><input id="ex-r" className="input" value={x.reference} onChange={(e) => setX({ ...x, reference: e.target.value })} /></Field>
      </div>
    </Modal>
  );
}

// ===================================================== Transactions =====================================================
function Transactions({ period }: { period: { from: string; to: string } }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [f, setF] = useState({ type: '', method: '' });
  const [rows, setRows] = useState<any[] | null>(null);
  useEffect(() => {
    const qs = new URLSearchParams({ from: period.from, to: period.to });
    if (f.type) qs.set('type', f.type);
    if (f.method) qs.set('method', f.method);
    get(`/api/finance/transactions?${qs}`).then(setRows).catch((e) => toast('error', e.message));
  }, [f, period]);
  const net = (rows ?? []).filter((x) => !x.void).reduce((s, x) => s + Math.round(x.amount * 100), 0) / 100;
  return (
    <>
      <div className="row">
        <select className="input" style={{ width: 'auto' }} aria-label={t('tx.type')} value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}><option value="">{t('bi.all')} — {t('tx.type')}</option>{['payment', 'refund', 'movement', 'expense', 'income'].map((x) => <option key={x} value={x}>{t(`tx.${x}` as Key)}</option>)}</select>
        <select className="input" style={{ width: 'auto' }} aria-label={t('common.method')} value={f.method} onChange={(e) => setF({ ...f, method: e.target.value })}><option value="">{t('bi.all')} — {t('common.method')}</option>{['cash', 'card', 'cheque', 'transfer', 'company_account', 'online'].map((m) => <option key={m} value={m}>{t(`pm.${m}` as Key)}</option>)}</select>
        <span className="muted" style={{ marginInlineStart: 'auto' }}>{rows?.length ?? 0} · net <b>{money(net, locale)}</b></span>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>Date</th><th>{t('tx.type')}</th><th>Réf.</th><th>{t('ch.desc')}</th><th>{t('common.method')}</th><th>Par</th><th className="num">{t('common.amount')}</th></tr></thead>
          <tbody>{(rows ?? []).map((x) => (
            <tr key={`${x.type}${x.id}`} style={{ opacity: x.void ? 0.5 : 1, textDecoration: x.void ? 'line-through' : undefined }}>
              <td>{fmtDateTime(x.at, locale)}</td><td>{t(`tx.${x.type}` as Key)}</td><td>{x.ref ?? ''}</td><td className="wrap">{x.label}{x.reference ? ` · ${x.reference}` : ''}{x.card_last4 ? ` · ••${x.card_last4}` : ''}</td>
              <td>{x.method_label}</td><td>{x.by_name}</td><td className="num" style={{ color: x.amount < 0 ? 'var(--danger)' : 'var(--ok)', fontWeight: 600 }}>{money(x.amount, locale)}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </>
  );
}

// ===================================================== Dépenses & recettes =====================================================
function Expenses({ period }: { period: { from: string; to: string } }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [exp, setExp] = useState<any[]>([]);
  const [inc, setInc] = useState<any[]>([]);
  const [modal, setModal] = useState<null | 'expense' | 'income'>(null);
  const [voidX, setVoidX] = useState<null | { table: string; id: number }>(null);
  const load = useCallback(() => {
    get(`/api/expenses?from=${period.from}&to=${period.to}`).then(setExp).catch(() => {});
    if (can('cash.operate')) get(`/api/incomes?from=${period.from}&to=${period.to}`).then(setInc).catch(() => {});
  }, [period]);
  useEffect(() => { load(); }, [load]);
  const total = (l: any[]) => l.filter((x) => !x.void).reduce((s, x) => s + Math.round(Number(x.amount) * 100), 0) / 100;
  const table = (rows: any[], tableName: string, withSupplier: boolean) => (
    <div className="card" style={{ padding: 0, overflow: 'auto' }}>
      <table className="table">
        <thead><tr><th>{t('bi.date')}</th><th>{t('bi.category')}</th><th>{t('ch.desc')}</th>{withSupplier && <th>{t('ex.supplier')}</th>}<th>{t('common.method')}</th><th>Par</th><th className="num">{t('common.amount')}</th><th /></tr></thead>
        <tbody>
          {rows.map((x) => (
            <tr key={x.id} style={{ opacity: x.void ? 0.5 : 1 }}>
              <td>{fmtDate(x.expense_date ?? x.income_date, locale)}</td><td>{x.category}</td><td className="wrap" style={{ textDecoration: x.void ? 'line-through' : undefined }}>{x.description}{x.void ? <div className="muted" style={{ fontSize: 12 }}>Annulée : {x.void_reason}</div> : null}</td>
              {withSupplier && <td>{x.supplier ?? '—'}</td>}<td>{t(`pm.${x.method}` as Key)}</td><td>{x.created_by_name}</td><td className="num">{money(Number(x.amount), locale)}</td>
              <td>{!x.void && can('cash.manage') && <button className="btn sm ghost danger" onClick={() => setVoidX({ table: tableName, id: x.id })}>{t('ex.void')}</button>}</td>
            </tr>
          ))}
          {!rows.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
        </tbody>
      </table>
    </div>
  );
  return (
    <>
      <div className="row between"><h3 style={{ margin: 0 }}>{t('ex.expenses')} · {money(total(exp), locale)}</h3><button className="btn primary" onClick={() => setModal('expense')}><Icon name="plus" /> {t('ex.newExpense')}</button></div>
      {table(exp, 'expenses', true)}
      {can('cash.operate') && <>
        <div className="row between"><h3 style={{ margin: 0 }}>{t('ex.incomes')} · {money(total(inc), locale)}</h3><button className="btn" onClick={() => setModal('income')}><Icon name="plus" /> {t('ex.newIncome')}</button></div>
        {table(inc, 'incomes', false)}
      </>}
      {modal && <ExpenseModal kind={modal} onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {voidX && <ReasonModal title={t('ex.void')} onClose={() => setVoidX(null)} onSubmit={(reason) => post(`/api/${voidX.table}/${voidX.id}/void`, { reason }).then(() => { setVoidX(null); load(); }).catch((e) => toast('error', e.message))} />}
    </>
  );
}

// ===================================================== Créances =====================================================
function Receivables() {
  const { t, locale } = useI18n();
  const [rows, setRows] = useState<any[] | null>(null);
  const [panel, setPanel] = useState<number | null>(null);
  const [inv, setInv] = useState<number | null>(null);
  const load = useCallback(() => { get('/api/finance/receivables').then(setRows).catch(() => {}); }, []);
  useEffect(() => { load(); }, [load]);
  const total = (rows ?? []).reduce((s, x) => s + Math.round(x.due * 100), 0) / 100;
  return (
    <>
      <div className="row between"><span className="muted">{rows?.length ?? 0} dossier(s)</span><b>{t('bi.due')} : {money(total, locale)}</b></div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>Dossier / facture</th><th>{t('bi.client')}</th><th>Payeur</th><th>{t('bi.date')}</th><th className="num">Âge (j)</th><th className="num">{t('bi.total')}</th><th className="num">{t('bi.netPaid')}</th><th className="num">{t('bi.due')}</th></tr></thead>
          <tbody>{(rows ?? []).map((x) => (
            <tr key={`${x.kind}${x.id}`}>
              <td><button className="link" onClick={() => (x.kind === 'reservation' ? setPanel(x.id) : setInv(x.id))}>{x.ref}</button></td><td>{x.client}</td><td>{x.payer}</td><td>{fmtDate(x.date, locale)}</td>
              <td className="num" style={{ color: x.age > 30 ? 'var(--danger)' : undefined }}>{x.age}</td><td className="num">{money(x.total, locale)}</td><td className="num">{money(x.paid, locale)}</td><td className="num" style={{ fontWeight: 700, color: 'var(--danger)' }}>{money(x.due, locale)}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
      {panel && <ReservationPanel id={panel} onClose={() => setPanel(null)} onChanged={load} />}
      {inv && <InvoiceDrawer id={inv} onClose={() => setInv(null)} onChanged={load} />}
    </>
  );
}

// ===================================================== Rapports =====================================================
function Reports({ period }: { period: { from: string; to: string } }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [kinds, setKinds] = useState<any[]>([]);
  const [kind, setKind] = useState('revenue');
  const [r, setR] = useState<any>(null);
  useEffect(() => { get('/api/finance/reports').then(setKinds).catch(() => {}); }, []);
  const qs = `from=${period.from}&to=${period.to}`;
  useEffect(() => { setR(null); get(`/api/finance/reports/${kind}?${qs}`).then(setR).catch((e) => toast('error', e.message)); }, [kind, qs]);
  const fmt = (c: any, v: any) => (v === null || v === undefined || v === '' ? '—' : c.money ? money(Number(v), locale) : String(v));
  return (
    <>
      <div className="row">
        <select className="input" style={{ width: 'auto' }} aria-label="Rapport" value={kind} onChange={(e) => setKind(e.target.value)}>{kinds.map((k) => <option key={k.kind} value={k.kind}>{k.title}</option>)}</select>
        <span style={{ flex: 1 }} />
        {['pdf', 'xlsx', 'csv'].map((f) => <button key={f} className="btn" onClick={() => window.open(`/api/finance/reports/${kind}?${qs}&format=${f}`, '_blank')}>{f === 'xlsx' ? 'Excel' : f.toUpperCase()}</button>)}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{r?.title ?? '…'} <span className="muted" style={{ fontWeight: 500 }}>· {fmtDate(period.from, locale)} → {fmtDate(period.to, locale)}</span></h3>
        <table className="table">
          <thead><tr>{(r?.columns ?? []).map((c: any) => <th key={c.key} className={c.money ? 'num' : ''}>{c.label}</th>)}</tr></thead>
          <tbody>
            {r && !r.rows.length && <tr><td colSpan={r.columns.length} className="muted">{t('common.none')}</td></tr>}
            {(r?.rows ?? []).map((x: any, i: number) => <tr key={i}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : 'wrap'}>{fmt(c, x[c.key])}</td>)}</tr>)}
            {r?.total && r.rows.length > 0 && <tr style={{ fontWeight: 700, background: 'var(--surface2)' }}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : ''}>{r.total[c.key] !== undefined ? fmt(c, r.total[c.key]) : ''}</td>)}</tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ===================================================== Taxes & réglages =====================================================
const TAX_CATS = ['room', 'breakfast', 'restaurant', 'room_service', 'minibar', 'laundry', 'transfer', 'parking', 'service', 'fees', 'other'];
function Taxes() {
  const { t } = useI18n();
  const toast = useToast();
  const [s, setS] = useState<any>(null);
  useEffect(() => { get('/api/settings/all').then((r) => setS({ ...r.settings, tax_rates: Object.fromEntries(TAX_CATS.map((c) => [c, String(r.settings.tax_rates?.[c] ?? r.settings.vat_rate ?? 0)])) })).catch((e) => toast('error', e.message)); }, []);
  if (!s) return <span>{t('common.loading')}</span>;
  const save = async () => {
    try {
      await api('PUT', '/api/settings', {
        tax_rates: Object.fromEntries(Object.entries(s.tax_rates).map(([k, v]) => [k, toNum(v)])), tourist_tax_per_adult_night: toNum(s.tourist_tax_per_adult_night),
        cash_session_required: !!s.cash_session_required, payment_gateway: { enabled: !!s.payment_gateway?.enabled, provider: s.payment_gateway?.provider ?? '' }, invoice_footer: s.invoice_footer ?? '',
      });
      toast('success', t('set.saved'));
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div className="section">
        <h3>{t('tax.rates')}</h3>
        <div className="form-grid">
          {TAX_CATS.map((c) => <Field key={c} label={t(`tax.c.${c}` as Key)} htmlFor={`tx-${c}`}><input id={`tx-${c}`} className="input" inputMode="decimal" value={s.tax_rates[c]} onChange={(e) => setS({ ...s, tax_rates: { ...s.tax_rates, [c]: e.target.value } })} /></Field>)}
        </div>
        <span className="muted" style={{ fontSize: 12.5 }}>{t('tax.note')}</span>
      </div>
      <div className="form-grid">
        <Field label={t('tax.tourist')} htmlFor="tx-tt"><input id="tx-tt" className="input" inputMode="decimal" value={s.tourist_tax_per_adult_night} onChange={(e) => setS({ ...s, tourist_tax_per_adult_night: e.target.value })} /></Field>
      </div>
      <label className="check"><input type="checkbox" checked={!!s.cash_session_required} onChange={(e) => setS({ ...s, cash_session_required: e.target.checked })} /> {t('tax.cashRequired')}</label>
      <label className="check"><input type="checkbox" checked={!!s.payment_gateway?.enabled} onChange={(e) => setS({ ...s, payment_gateway: { ...s.payment_gateway, enabled: e.target.checked } })} /> {t('tax.gateway')}</label>
      {s.payment_gateway?.enabled && <Field label={t('tax.provider')} htmlFor="tx-pv"><input id="tx-pv" className="input" placeholder="Ex. : SATIM / CIB, Edahabia" value={s.payment_gateway?.provider ?? ''} onChange={(e) => setS({ ...s, payment_gateway: { ...s.payment_gateway, provider: e.target.value } })} /></Field>}
      <Field label={t('tax.footer')} htmlFor="tx-ft"><textarea id="tx-ft" className="input" rows={2} placeholder="Ex. : Conditions de paiement, RIB, mentions légales…" value={s.invoice_footer ?? ''} onChange={(e) => setS({ ...s, invoice_footer: e.target.value })} /></Field>
      <span className="muted" style={{ fontSize: 12.5 }}>Exonération de TVA d'un client (ambassade, organisme exonéré) : depuis sa fiche client (administrateur).</span>
      <div><button className="btn primary" onClick={save}>{t('common.save')}</button></div>
    </div>
  );
}
