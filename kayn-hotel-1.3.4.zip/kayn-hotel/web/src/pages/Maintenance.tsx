import { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Page } from '../components/Layout';
import { ReasonModal } from '../components/ReservationPanel';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { api, get, newOpKey, patch, post, postOnce, upload } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { addDays, fmtDate, fmtDateTime, money, todayLocal } from '../lib/format';
import { useLive } from '../lib/useLive';

type Tab = 'dashboard' | 'faults' | 'orders' | 'equipment' | 'preventive' | 'technicians' | 'parts' | 'rooms' | 'reports' | 'settings';
const VIEW = ['maintenance.view', 'maintenance.work', 'maintenance.supervise'];
const CATS = ['hvac', 'heating', 'plumbing', 'electrical', 'elevator', 'kitchen', 'furniture', 'it', 'fire_safety', 'other'];
const PRIOS = ['low', 'normal', 'high', 'urgent'];
const LOCS = ['room', 'floor', 'kitchen', 'restaurant', 'reception', 'pool', 'laundry', 'technical', 'public', 'outdoor', 'other'];
const DEPTS = ['rooms', 'restaurant', 'reception', 'housekeeping', 'technical', 'leisure', 'admin', 'other'];
const TK_COLORS: Record<string, [string, string]> = {
  new: ['#FEE2E2', '#991B1B'], assigned: ['#DBEAFE', '#1E40AF'], in_progress: ['#FEF3C7', '#92400E'], waiting_parts: ['#FFEDD5', '#9A3412'], resolved: ['#DCFCE7', '#166534'], closed: ['#E2E8F0', '#334155'], cancelled: ['#F1F5F9', '#64748B'],
};
const WO_COLORS: Record<string, [string, string]> = {
  planned: ['#DBEAFE', '#1E40AF'], in_progress: ['#FEF3C7', '#92400E'], on_hold: ['#FFEDD5', '#9A3412'], done: ['#E0E7FF', '#3730A3'], validated: ['#DCFCE7', '#166534'], cancelled: ['#F1F5F9', '#64748B'],
};
const EQ_COLORS: Record<string, [string, string]> = { operational: ['#DCFCE7', '#166534'], degraded: ['#FEF3C7', '#92400E'], broken: ['#FEE2E2', '#991B1B'], out_of_service: ['#FEE2E2', '#7F1D1D'], retired: ['#F1F5F9', '#64748B'] };
const toNum = (v: string | number) => Number(String(v ?? '').replace(',', '.').replace(/\s/g, '')) || 0;
const err = (toast: any) => (e: any) => toast('error', e.message);
const d10 = (v: any) => (v ? String(v).slice(0, 10) : '');
const hm = (m: number) => `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, '0')}`;

function Pill({ map, s, k }: { map: Record<string, [string, string]>; s: string; k: string }) {
  const { t } = useI18n();
  const [bg, fg] = map[s] ?? ['#F1F5F9', '#475569'];
  return <span className="pill" style={{ background: bg, color: fg }}>{t(`${k}${s}` as Key)}</span>;
}
const Prio = ({ p }: { p: string }) => { const { t } = useI18n(); return <span className={`pill prio-${p}`}>{t(`mt.p_${p}` as Key)}</span>; };
function useMeta() {
  const [m, setM] = useState<any>(null);
  const load = useCallback(() => { get('/api/maintenance/meta').then(setM).catch(() => {}); }, []);
  useEffect(load, [load]);
  return m;
}
const where = (x: any, t: (k: Key) => string) => [x.equipment, x.room ? `${t('mt.room')} ${x.room}` : null, x.location].filter(Boolean).join(' · ');

export function Maintenance() {
  const { t } = useI18n();
  const { can } = useAuth();
  const [sp, setSp] = useSearchParams();
  const any = (ps: string[]) => ps.some((p) => can(p));
  const tabs = ([['dashboard', VIEW], ['faults', [...VIEW, 'maintenance.report']], ['orders', VIEW], ['equipment', VIEW], ['preventive', VIEW], ['technicians', VIEW], ['parts', VIEW],
    ['rooms', VIEW], ['reports', ['maintenance.reports']], ['settings', ['maintenance.supervise']]] as [Tab, string[]][]).filter(([, ps]) => any(ps)).map(([k]) => k);
  const tab = tabs.includes(sp.get('tab') as Tab) ? (sp.get('tab') as Tab) : tabs[0];
  const go = (k: Tab) => setSp({ tab: k }, { replace: true });
  const [openWo, setOpenWo] = useState<number | null>(null);
  const [openTk, setOpenTk] = useState<number | null>(null);
  const [openEq, setOpenEq] = useState<number | null>(null);
  const [declare, setDeclare] = useState<any>(null);
  const [ver, setVer] = useState(0);
  const changed = () => setVer((v) => v + 1);
  return (
    <Page>
      <div className="page-head">
        <h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('mt.title')}</h1>
        {any(['maintenance.report', 'maintenance.manage', 'maintenance.supervise']) && <button className="btn primary" onClick={() => setDeclare({})}><Icon name="plus" size={16} />{t('mt.declare')}</button>}
      </div>
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>
        {tabs.map((k) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => go(k)}>{t(`mt.t_${k}` as Key)}</button>)}
      </div>
      <div key={ver} style={{ display: 'contents' }}>
        {tab === 'dashboard' && <Dash go={go} openTk={setOpenTk} />}
        {tab === 'faults' && <Faults openTk={setOpenTk} />}
        {tab === 'orders' && <Orders openWo={setOpenWo} />}
        {tab === 'equipment' && <Equipment openEq={setOpenEq} />}
        {tab === 'preventive' && <Preventive openWo={setOpenWo} />}
        {tab === 'technicians' && <Technicians />}
        {tab === 'parts' && <Parts openWo={setOpenWo} />}
        {tab === 'rooms' && <Rooms openTk={setOpenTk} />}
        {tab === 'reports' && <Reports />}
        {tab === 'settings' && <Settings />}
      </div>
      {declare && <DeclareModal init={declare} onClose={() => setDeclare(null)} onDone={(tk) => { setDeclare(null); changed(); if (any(VIEW)) setOpenTk(tk.id); }} />}
      {openTk && <TicketSheet id={openTk} onClose={() => setOpenTk(null)} onChanged={changed} openWo={(id) => { setOpenTk(null); setOpenWo(id); }} />}
      {openWo && <WoSheet id={openWo} onClose={() => setOpenWo(null)} onChanged={changed} />}
      {openEq && <EquipmentSheet id={openEq} onClose={() => setOpenEq(null)} onChanged={changed} declare={(e) => { setOpenEq(null); setDeclare({ equipment_id: e.id }); }} openWo={(id) => { setOpenEq(null); setOpenWo(id); }} openTk={(id) => { setOpenEq(null); setOpenTk(id); }} />}
    </Page>
  );
}

// ===================================================== Tableau de bord =====================================================
function Dash({ go, openTk }: { go: (t: Tab) => void; openTk: (id: number) => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const load = useCallback(() => { get('/api/maintenance/dashboard').then(setD).catch(err(toast)); }, []);
  useEffect(load, [load]);
  useLive(load, 30000);
  if (!d) return <span>{t('common.loading')}</span>;
  const k = d.kpi;
  const card = (label: string, v: any, color?: string, onClick?: () => void) => (
    <div className={`card kpi ${onClick ? 'clickable' : ''}`} style={{ borderInlineStart: color ? `4px solid ${color}` : undefined, cursor: onClick ? 'pointer' : undefined }} onClick={onClick}>
      <span className="label">{label}</span><span className="value" style={{ fontSize: typeof v === 'string' ? 20 : undefined }}>{v}</span>
    </div>
  );
  const lvl = (l: string) => (l === 'danger' ? 'var(--danger)' : l === 'warning' ? '#B45309' : undefined);
  return (
    <>
      <div className="grid kpis">
        {card(t('mt.kEquipment'), k.equipment.total, undefined, () => go('equipment'))}
        {card(t('mt.kOperational'), k.equipment.operational, '#15803D', () => go('equipment'))}
        {card(t('mt.kBroken'), `${k.equipment.broken}${k.equipment.degraded ? ` · ${k.equipment.degraded} ${t('mt.degraded')}` : ''}`, '#B91C1C', () => go('equipment'))}
        {card(t('mt.kPending'), k.tickets.pending, '#1E40AF', () => go('faults'))}
        {card(t('mt.kInProgress'), k.tickets.in_progress, '#92400E', () => go('orders'))}
        {card(t('mt.kDone'), k.tickets.done_month, '#166534')}
        {card(t('mt.kCritical'), `${k.tickets.critical}${k.tickets.late ? ` · ${k.tickets.late} ${t('mt.late')}` : ''}`, k.tickets.critical ? '#B91C1C' : undefined, () => go('faults'))}
        {card(t('mt.kToValidate'), k.work_orders.to_validate, '#3730A3', () => go('orders'))}
        {card(t('mt.kPreventive'), `${k.preventive.upcoming}${k.preventive.late ? ` · ${k.preventive.late} ${t('mt.late')}` : ''}`, k.preventive.late ? '#B45309' : '#7C3AED', () => go('preventive'))}
        {card(t('mt.kRooms'), k.rooms_blocked, k.rooms_blocked ? '#B91C1C' : undefined, () => go('rooms'))}
        {card(t('mt.kCostMonth'), money(k.cost_month.total, locale))}
        {card(t('mt.kCostYear'), money(k.cost_year, locale))}
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 14, alignItems: 'start' }}>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <h3 style={{ margin: 0 }}>{t('mt.alerts')} ({d.alerts.length})</h3>
          {!d.alerts.length && <span className="muted">{t('mt.noAlert')}</span>}
          {d.alerts.slice(0, 20).map((a: any, i: number) => (
            <div key={i} className="alert" style={{ padding: '6px 10px', fontSize: 13, borderColor: lvl(a.level), color: lvl(a.level), cursor: a.ref?.ticket_id ? 'pointer' : undefined }}
              onClick={() => a.ref?.ticket_id && openTk(a.ref.ticket_id)}>{a.message}</div>
          ))}
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <h3 style={{ margin: 0 }}>{t('mt.costBreakdown')}</h3>
          <div className="sum-row"><span>{t('mt.labor')}</span><b>{money(k.cost_month.labor, locale)}</b></div>
          <div className="sum-row"><span>{t('mt.partsCost')}</span><b>{money(k.cost_month.parts, locale)}</b></div>
          <div className="sum-row"><span>{t('mt.external')}</span><b>{money(k.cost_month.external, locale)}</b></div>
          <div className="sum-row" style={{ fontWeight: 700 }}><span>{t('mt.total')}</span><b>{money(k.cost_month.total, locale)}</b></div>
          <h3 style={{ margin: '8px 0 0' }}>{t('mt.t_rooms')}</h3>
          {!d.rooms.length && <span className="muted">{t('common.none')}</span>}
          {d.rooms.map((r: any) => <div key={r.id} className="sum-row"><span><b>{t('mt.room')} {r.number}</b> · {r.reason}</span><span className="muted">{r.end_date ? `→ ${fmtDate(d10(r.end_date), locale)}` : '…'}</span></div>)}
        </div>
      </div>
    </>
  );
}

// ===================================================== Pannes =====================================================
function Faults({ openTk }: { openTk: (id: number) => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [f, setF] = useState({ status: 'open', priority: '' });
  const [rows, setRows] = useState<any[] | null>(null);
  const load = useCallback(() => {
    const qs = new URLSearchParams();
    if (f.status === 'open') qs.set('open', 'true'); else if (f.status) qs.set('status', f.status);
    if (f.priority) qs.set('priority', f.priority);
    get(`/api/maintenance/tickets?${qs}`).then(setRows).catch(err(toast));
  }, [f.status, f.priority]);
  useEffect(load, [load]);
  useLive(load, 30000);
  return (
    <>
      <div className="row">
        <select className="input" style={{ width: 'auto' }} aria-label={t('mt.status')} value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}>
          <option value="open">{t('mt.openOnly')}</option><option value="">{t('mt.all')}</option>
          {Object.keys(TK_COLORS).map((s) => <option key={s} value={s}>{t(`mt.ts_${s}` as Key)}</option>)}
        </select>
        <select className="input" style={{ width: 'auto' }} aria-label={t('mt.priority')} value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value })}>
          <option value="">{t('mt.allPriorities')}</option>{PRIOS.map((p) => <option key={p} value={p}>{t(`mt.p_${p}` as Key)}</option>)}
        </select>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('mt.number')}</th><th>{t('mt.declaredAt')}</th><th>{t('mt.fault')}</th><th>{t('mt.where')}</th><th>{t('mt.priority')}</th><th>{t('mt.status')}</th><th>{t('mt.technician')}</th><th>{t('mt.due')}</th></tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
            {(rows ?? []).map((x) => {
              const late = x.due_at && new Date(x.due_at) < new Date() && ['new', 'assigned', 'in_progress', 'waiting_parts'].includes(x.status);
              return (
                <tr key={x.id} className="clickable" style={{ cursor: 'pointer' }} onClick={() => openTk(x.id)}>
                  <td><b>{x.number}</b></td><td>{fmtDateTime(x.created_at, locale)}</td>
                  <td className="wrap">{x.title}{x.block ? <span className="pill prio-urgent" style={{ marginInlineStart: 6 }}>{t('mt.blocked')}</span> : null}</td>
                  <td className="wrap">{where(x, t)}</td><td><Prio p={x.priority} /></td><td><Pill map={TK_COLORS} s={x.status} k="mt.ts_" /></td>
                  <td>{x.technician ?? <span className="muted">—</span>}</td>
                  <td style={{ color: late ? 'var(--danger)' : undefined, fontWeight: late ? 600 : undefined }}>{x.due_at ? fmtDateTime(x.due_at, locale) : ''}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}

function DeclareModal({ init, onClose, onDone }: { init: any; onClose: () => void; onDone: (tk: any) => void }) {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const meta = useMeta();
  const [b, setB] = useState<any>({ title: '', description: '', priority: 'normal', equipment_id: init.equipment_id ?? '', room_id: init.room_id ?? '', location: '', technician_id: '', block: false, end_date: '' });
  const [files, setFiles] = useState<File[]>([]);
  const [key] = useState(() => newOpKey('mt'));
  const [busy, setBusy] = useState(false);
  const sup = can('maintenance.supervise');
  const canBlock = sup || can('maintenance.manage');
  const eq = (meta?.equipment ?? []).find((e: any) => String(e.id) === String(b.equipment_id));
  const roomId = b.room_id || eq?.room_id || '';
  const submit = async () => {
    setBusy(true);
    try {
      const tk = await postOnce('/api/maintenance/tickets', {
        title: b.title, description: b.description || null, priority: b.priority, equipment_id: b.equipment_id ? Number(b.equipment_id) : null, room_id: b.room_id ? Number(b.room_id) : null,
        location: b.location || null, technician_id: sup && b.technician_id ? Number(b.technician_id) : null, block_room: b.block && roomId ? { end_date: b.end_date || null } : null,
      }, key);
      for (const f of files) await upload('/api/photos', f, { owner_type: 'ticket', owner_id: String(tk.id) }).catch(err(toast));
      toast('success', `${t('mt.declared')} ${tk.number}`);
      onDone(tk);
    } catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  return (
    <Modal title={t('mt.declare')} onClose={onClose} size="lg" footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={busy || b.title.trim().length < 3} onClick={submit}>{t('mt.declare')}</button></>}>
      <div className="form-grid">
        <Field label={t('mt.faultTitle')}><input className="input" value={b.title} maxLength={160} onChange={(e) => setB({ ...b, title: e.target.value })} autoFocus /></Field>
        <Field label={t('mt.priority')}>
          <div className="seg">{PRIOS.map((p) => <button key={p} type="button" className={b.priority === p ? 'on' : ''} onClick={() => setB({ ...b, priority: p })}>{t(`mt.p_${p}` as Key)}</button>)}</div>
        </Field>
        <Field label={t('mt.equipment')}>
          <select className="input" value={b.equipment_id} onChange={(e) => setB({ ...b, equipment_id: e.target.value })}>
            <option value="">—</option>{(meta?.equipment ?? []).map((e: any) => <option key={e.id} value={e.id}>{e.code} · {e.name}</option>)}
          </select>
        </Field>
        <Field label={t('mt.room')}>
          <select className="input" value={b.room_id} onChange={(e) => setB({ ...b, room_id: e.target.value })}>
            <option value="">{eq?.room_id ? `(${(meta?.rooms ?? []).find((r: any) => r.id === eq.room_id)?.number ?? ''})` : '—'}</option>{(meta?.rooms ?? []).map((r: any) => <option key={r.id} value={r.id}>{r.number}</option>)}
          </select>
        </Field>
        <Field label={t('mt.location')}><input className="input" value={b.location} placeholder={t('mt.locationPh')} onChange={(e) => setB({ ...b, location: e.target.value })} /></Field>
        {sup && <Field label={t('mt.assignTo')}><select className="input" value={b.technician_id} onChange={(e) => setB({ ...b, technician_id: e.target.value })}><option value="">{t('mt.later')}</option>{(meta?.technicians ?? []).map((x: any) => <option key={x.id} value={x.id} disabled={!x.available}>{x.name}{x.available ? '' : ` (${t('mt.unavailable')})`}</option>)}</select></Field>}
      </div>
      <Field label={t('mt.description')}><textarea className="input" rows={3} value={b.description} onChange={(e) => setB({ ...b, description: e.target.value })} /></Field>
      <Field label={t('mt.photos')}><input type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={(e) => setFiles(Array.from(e.target.files ?? []))} /></Field>
      {canBlock && roomId && (
        <div className="card" style={{ background: 'var(--surface2)', display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
          <label className="row" style={{ gap: 8 }}><input type="checkbox" checked={b.block} onChange={(e) => setB({ ...b, block: e.target.checked })} /> <b>{t('mt.blockRoom')}</b></label>
          {b.block && <Field label={t('mt.until')}><input type="date" className="input" min={addDays(todayLocal(), 1)} value={b.end_date} onChange={(e) => setB({ ...b, end_date: e.target.value })} /></Field>}
          <span className="muted" style={{ fontSize: 12.5 }}>{t('mt.blockHint')}</span>
        </div>
      )}
    </Modal>
  );
}

function Photos({ type, id, photos, canAdd, onChanged }: { type: string; id: number; photos: number[]; canAdd: boolean; onChanged: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const ref = useRef<HTMLInputElement>(null);
  const add = async (files: FileList | null) => {
    for (const f of Array.from(files ?? [])) { try { await upload('/api/photos', f, { owner_type: type, owner_id: String(id) }); } catch (e: any) { toast('error', e.message); } }
    if (ref.current) ref.current.value = '';
    onChanged();
  };
  return (
    <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
      {(photos ?? []).map((p) => <a key={p} href={`/api/photos/${p}`} target="_blank" rel="noreferrer"><img src={`/api/photos/${p}`} alt="" style={{ width: 84, height: 64, objectFit: 'cover', borderRadius: 8 }} /></a>)}
      {canAdd && <><input ref={ref} type="file" hidden accept="image/jpeg,image/png,image/webp" multiple onChange={(e) => add(e.target.files)} /><button className="btn sm" onClick={() => ref.current?.click()}><Icon name="plus" size={14} />{t('mt.addPhoto')}</button></>}
      {!photos?.length && !canAdd && <span className="muted">{t('common.none')}</span>}
    </div>
  );
}

function TicketSheet({ id, onClose, onChanged, openWo }: { id: number; onClose: () => void; onChanged: () => void; openWo: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const meta = useMeta();
  const [x, setX] = useState<any>(null);
  const [tech, setTech] = useState('');
  const [reason, setReason] = useState<null | 'close' | 'cancel' | 'waiting_parts'>(null);
  const [blockEnd, setBlockEnd] = useState<string | null>(null);
  const load = useCallback(() => { get(`/api/maintenance/tickets/${id}`).then(setX).catch(err(toast)); }, [id]);
  useEffect(load, [load]);
  const run = async (fn: () => Promise<any>, msg: string) => { try { await fn(); toast('success', msg); load(); onChanged(); } catch (e: any) { toast('error', e.message); } };
  if (!x) return <Modal title="…" onClose={onClose}><span>{t('common.loading')}</span></Modal>;
  const open = ['new', 'assigned', 'in_progress', 'waiting_parts'].includes(x.status);
  const sup = can('maintenance.supervise');
  return (
    <Modal title={`${x.number} — ${x.title}`} onClose={onClose} size="lg">
      <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
        <Pill map={TK_COLORS} s={x.status} k="mt.ts_" /><Prio p={x.priority} />
        {x.block && <span className="pill prio-urgent">{t('mt.blocked')}{x.block.end ? ` → ${fmtDate(d10(x.block.end), locale)}` : ''}</span>}
        <span className="muted">{t(`mt.src_${x.source}` as Key)} · {x.reporter ?? ''} · {fmtDateTime(x.created_at, locale)}</span>
      </div>
      <div className="form-grid">
        <div><span className="muted">{t('mt.where')}</span><div><b>{where(x, t) || '—'}</b></div></div>
        <div><span className="muted">{t('mt.technician')}</span><div><b>{x.technician ?? '—'}</b></div></div>
        <div><span className="muted">{t('mt.due')}</span><div><b style={{ color: open && new Date(x.due_at) < new Date() ? 'var(--danger)' : undefined }}>{fmtDateTime(x.due_at, locale)}</b></div></div>
        <div><span className="muted">{t('mt.category')}</span><div><b>{t(`mt.c_${x.category}` as Key)}</b></div></div>
      </div>
      {x.description && <p style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{x.description}</p>}
      {x.waiting_reason && <div className="alert">{t('mt.ts_waiting_parts')} : {x.waiting_reason}</div>}
      {x.resolution && <div className="alert" style={{ borderColor: '#15803D', color: '#166534' }}>{t('mt.result')} : {x.resolution}</div>}
      <h4 style={{ margin: '6px 0 0' }}>{t('mt.photos')}</h4>
      <Photos type="ticket" id={x.id} photos={x.photos ?? []} canAdd={open && can('maintenance.report')} onChanged={load} />
      {open && sup && (
        <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          <select className="input" style={{ width: 'auto' }} aria-label={t('mt.assignTo')} value={tech} onChange={(e) => setTech(e.target.value)}>
            <option value="">{x.technician_id ? t('mt.reassign') : t('mt.assignTo')}</option>
            {(meta?.technicians ?? []).map((m: any) => <option key={m.id} value={m.id} disabled={!m.available}>{m.name}{m.available ? '' : ` (${t('mt.unavailable')})`}</option>)}
          </select>
          <button className="btn primary" disabled={!tech} onClick={() => run(() => post(`/api/maintenance/tickets/${id}/assign`, { technician_id: Number(tech) }), t('mt.assigned'))}>{t('mt.assign')}</button>
        </div>
      )}
      <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
        {x.work_order && <button className="btn" onClick={() => openWo(x.work_order.id)}><Icon name="list" size={14} />{x.work_order.number}</button>}
        {open && x.room_id && !x.block && (sup || can('maintenance.manage')) && <button className="btn" onClick={() => setBlockEnd('')}>{t('mt.blockRoom')}</button>}
        {open && can('maintenance.work') && x.status !== 'waiting_parts' && <button className="btn" onClick={() => setReason('waiting_parts')}>{t('mt.ts_waiting_parts')}</button>}
        {sup && ['resolved', ...(open ? [x.status] : [])].includes(x.status) && <button className="btn primary" onClick={() => (x.status === 'resolved' ? run(() => post(`/api/maintenance/tickets/${id}/status`, { action: 'close' }), t('mt.closed')) : setReason('close'))}>{t('mt.close')}</button>}
        {sup && x.status === 'resolved' && <button className="btn" onClick={() => run(() => post(`/api/maintenance/tickets/${id}/status`, { action: 'reopen' }), t('mt.reopened'))}>{t('mt.reopen')}</button>}
        {sup && open && <button className="btn danger" onClick={() => setReason('cancel')}>{t('mt.cancelFault')}</button>}
      </div>
      {x.work_orders?.length > 0 && (
        <table className="table">
          <thead><tr><th>{t('mt.wo')}</th><th>{t('mt.technician')}</th><th>{t('mt.status')}</th><th className="num">{t('mt.total')}</th></tr></thead>
          <tbody>{x.work_orders.map((w: any) => <tr key={w.id} style={{ cursor: 'pointer' }} onClick={() => openWo(w.id)}><td><b>{w.number}</b></td><td>{w.technician ?? '—'}</td><td><Pill map={WO_COLORS} s={w.status} k="mt.ws_" /></td><td className="num">{money(Number(w.total_cost), locale)}</td></tr>)}</tbody>
        </table>
      )}
      <History rows={x.history ?? []} />
      {reason && <ReasonModal title={reason === 'close' ? t('mt.closeReason') : reason === 'cancel' ? t('mt.cancelFault') : t('mt.waitingWhat')} onClose={() => setReason(null)}
        onSubmit={(r) => { const a = reason; setReason(null); run(() => post(`/api/maintenance/tickets/${id}/status`, { action: a, reason: r }), t('mt.saved')); }} />}
      {blockEnd !== null && (
        <Modal title={t('mt.blockRoom')} onClose={() => setBlockEnd(null)} size="sm" footer={<><button className="btn" onClick={() => setBlockEnd(null)}>{t('common.cancel')}</button><button className="btn primary" onClick={() => { const e = blockEnd; setBlockEnd(null); run(() => post(`/api/maintenance/tickets/${id}/block`, { end_date: e || null }), t('mt.roomBlocked')); }}>{t('mt.blockRoom')}</button></>}>
          <Field label={t('mt.until')}><input type="date" className="input" min={addDays(todayLocal(), 1)} value={blockEnd} onChange={(e) => setBlockEnd(e.target.value)} /></Field>
          <span className="muted" style={{ fontSize: 12.5 }}>{t('mt.blockHint')}</span>
        </Modal>
      )}
    </Modal>
  );
}

function History({ rows }: { rows: any[] }) {
  const { t, locale } = useI18n();
  if (!rows.length) return null;
  return (
    <details>
      <summary className="muted" style={{ cursor: 'pointer' }}>{t('mt.history')} ({rows.length})</summary>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginTop: 6 }}>
        {rows.map((h, i) => <div key={i} className="sum-row" style={{ fontSize: 12.5 }}><span>{fmtDateTime(h.created_at, locale)} · <b>{h.action}</b></span><span className="muted">{h.user ?? ''}</span></div>)}
      </div>
    </details>
  );
}

// ===================================================== Ordres de travail =====================================================
function Orders({ openWo }: { openWo: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [f, setF] = useState({ scope: 'active', mine: !can('maintenance.supervise') });
  const [rows, setRows] = useState<any[] | null>(null);
  const [create, setCreate] = useState(false);
  const load = useCallback(() => {
    const qs = new URLSearchParams();
    if (f.scope === 'active') qs.set('active', 'true'); else if (f.scope) qs.set('status', f.scope);
    if (f.mine) qs.set('mine', 'true');
    get(`/api/maintenance/work-orders?${qs}`).then(setRows).catch(err(toast));
  }, [f.scope, f.mine]);
  useEffect(load, [load]);
  useLive(load, 30000);
  return (
    <>
      <div className="row">
        <select className="input" style={{ width: 'auto' }} aria-label={t('mt.status')} value={f.scope} onChange={(e) => setF({ ...f, scope: e.target.value })}>
          <option value="active">{t('mt.activeOrders')}</option><option value="">{t('mt.all')}</option>
          {Object.keys(WO_COLORS).map((s) => <option key={s} value={s}>{t(`mt.ws_${s}` as Key)}</option>)}
        </select>
        <label className="chip" style={{ cursor: 'pointer' }}><input type="checkbox" checked={f.mine} onChange={(e) => setF({ ...f, mine: e.target.checked })} /> {t('mt.mine')}</label>
        <span style={{ flex: 1 }} />
        {can('maintenance.supervise') && <button className="btn" onClick={() => setCreate(true)}><Icon name="plus" size={14} />{t('mt.newWo')}</button>}
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
        {rows && !rows.length && <span className="muted">{t('common.none')}</span>}
        {(rows ?? []).map((w) => {
          const done = (w.checklist ?? []).filter((c: any) => c.done).length, n = (w.checklist ?? []).length;
          return (
            <div key={w.id} className="hk-card clickable" onClick={() => openWo(w.id)}>
              <div className="row between"><b>{w.number}</b><Pill map={WO_COLORS} s={w.status} k="mt.ws_" /></div>
              <div style={{ fontWeight: 600 }}>{w.title}</div>
              <div className="muted" style={{ fontSize: 12.5 }}>{t(`mt.k_${w.kind}` as Key)} · {where(w, t) || '—'}</div>
              <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}><Prio p={w.priority} />{w.ticket && <span className="pill">{w.ticket}</span>}<span className="muted" style={{ fontSize: 12.5 }}>{w.technician ?? t('mt.unassigned')}</span></div>
              {n > 0 && <div className={`meter ${done === n ? 'ok' : ''}`}><i style={{ width: `${(done / n) * 100}%` }} /></div>}
              <div className="row between" style={{ fontSize: 12.5 }}>
                <span className="muted">{w.scheduled_at ? fmtDateTime(w.scheduled_at, locale) : fmtDateTime(w.created_at, locale)}</span>
                <b>{money(Number(w.total_cost), locale)}</b>
              </div>
            </div>
          );
        })}
      </div>
      {create && <NewWoModal onClose={() => setCreate(false)} onDone={(w) => { setCreate(false); load(); openWo(w.id); }} />}
    </>
  );
}

function NewWoModal({ onClose, onDone }: { onClose: () => void; onDone: (w: any) => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const meta = useMeta();
  const [b, setB] = useState<any>({ kind: 'improvement', title: '', description: '', priority: 'normal', equipment_id: '', room_id: '', technician_id: '', scheduled_at: '', checklist: '' });
  const [key] = useState(() => newOpKey('ot'));
  const submit = async () => {
    try {
      onDone(await postOnce('/api/maintenance/work-orders', {
        kind: b.kind, title: b.title, description: b.description || null, priority: b.priority, equipment_id: b.equipment_id ? Number(b.equipment_id) : null, room_id: b.room_id ? Number(b.room_id) : null,
        technician_id: b.technician_id ? Number(b.technician_id) : null, scheduled_at: b.scheduled_at || null, checklist: b.checklist.split('\n').map((s: string) => s.trim()).filter(Boolean),
      }, key));
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={t('mt.newWo')} onClose={onClose} size="lg" footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={b.title.trim().length < 2} onClick={submit}>{t('mt.create')}</button></>}>
      <div className="form-grid">
        <Field label={t('mt.woTitle')}><input className="input" value={b.title} onChange={(e) => setB({ ...b, title: e.target.value })} /></Field>
        <Field label={t('mt.kind')}><select className="input" value={b.kind} onChange={(e) => setB({ ...b, kind: e.target.value })}>{['improvement', 'inspection', 'corrective'].map((k) => <option key={k} value={k}>{t(`mt.k_${k}` as Key)}</option>)}</select></Field>
        <Field label={t('mt.equipment')}><select className="input" value={b.equipment_id} onChange={(e) => setB({ ...b, equipment_id: e.target.value })}><option value="">—</option>{(meta?.equipment ?? []).map((e: any) => <option key={e.id} value={e.id}>{e.code} · {e.name}</option>)}</select></Field>
        <Field label={t('mt.room')}><select className="input" value={b.room_id} onChange={(e) => setB({ ...b, room_id: e.target.value })}><option value="">—</option>{(meta?.rooms ?? []).map((r: any) => <option key={r.id} value={r.id}>{r.number}</option>)}</select></Field>
        <Field label={t('mt.technician')}><select className="input" value={b.technician_id} onChange={(e) => setB({ ...b, technician_id: e.target.value })}><option value="">{t('mt.later')}</option>{(meta?.technicians ?? []).filter((x: any) => x.available).map((x: any) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></Field>
        <Field label={t('mt.scheduled')}><input type="datetime-local" className="input" value={b.scheduled_at} onChange={(e) => setB({ ...b, scheduled_at: e.target.value })} /></Field>
        <Field label={t('mt.priority')}><select className="input" value={b.priority} onChange={(e) => setB({ ...b, priority: e.target.value })}>{PRIOS.map((p) => <option key={p} value={p}>{t(`mt.p_${p}` as Key)}</option>)}</select></Field>
      </div>
      <Field label={t('mt.description')}><textarea className="input" rows={2} value={b.description} onChange={(e) => setB({ ...b, description: e.target.value })} /></Field>
      <Field label={t('mt.checklistLines')}><textarea className="input" rows={3} value={b.checklist} onChange={(e) => setB({ ...b, checklist: e.target.value })} /></Field>
    </Modal>
  );
}

function WoSheet({ id, onClose, onChanged }: { id: number; onClose: () => void; onChanged: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const meta = useMeta();
  const [w, setW] = useState<any>(null);
  const [parts, setParts] = useState<any[]>([]);
  const [time, setTime] = useState({ minutes: '', note: '' });
  const [part, setPart] = useState({ product_id: '', quantity: '1' });
  const [missing, setMissing] = useState<string | null>(null);
  const [comment, setComment] = useState('');
  const [finish, setFinish] = useState<any>(null);
  const [valid, setValid] = useState<any>(null);
  const [ext, setExt] = useState<any>(null);
  const [hold, setHold] = useState(false);
  const [cancel, setCancel] = useState(false);
  const [editTech, setEditTech] = useState('');
  const load = useCallback(() => { get(`/api/maintenance/work-orders/${id}`).then(setW).catch(err(toast)); }, [id]);
  useEffect(load, [load]);
  useEffect(() => { get('/api/maintenance/parts?all=true').then(setParts).catch(() => {}); }, []);
  const run = async (fn: () => Promise<any>, msg?: string) => { try { const r = await fn(); if (msg) toast('success', msg); load(); onChanged(); return r; } catch (e: any) { toast('error', e.message); throw e; } };
  if (!w) return <Modal title="…" onClose={onClose}><span>{t('common.loading')}</span></Modal>;
  const me = meta?.me;
  const sup = can('maintenance.supervise');
  const mineOk = sup || (can('maintenance.work') && (!w.technician_id || w.technician_id === me?.id));
  const workable = ['planned', 'in_progress', 'on_hold'].includes(w.status) && mineOk;
  const addPart = async (purchase = false) => {
    try {
      const r = await post(`/api/maintenance/work-orders/${id}/parts`, { product_id: Number(part.product_id), quantity: toNum(part.quantity), request_purchase: purchase });
      setMissing(null);
      if (r.purchase) toast('success', `${t('mt.purchaseCreated')} ${r.purchase.number}`); else toast('success', t('mt.partAdded'));
      if (r.alert) toast('info', r.alert);
      setPart({ product_id: '', quantity: '1' });
      load(); onChanged();
    } catch (e: any) {
      if (e.code === 'missing_part' || e.body?.error === 'missing_part') setMissing(e.message); else toast('error', e.message);
    }
  };
  return (
    <Modal title={`${w.number} — ${w.title}`} onClose={onClose} size="lg">
      <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
        <Pill map={WO_COLORS} s={w.status} k="mt.ws_" /><Prio p={w.priority} /><span className="pill">{t(`mt.k_${w.kind}` as Key)}</span>
        {w.ticket && <span className="pill">{w.ticket} · {t(`mt.ts_${w.ticket_status}` as Key)}</span>}
        {w.plan && <span className="pill">{w.plan} · {d10(w.plan_due)}</span>}
      </div>
      <div className="form-grid">
        <div><span className="muted">{t('mt.where')}</span><div><b>{where(w, t) || '—'}</b></div></div>
        <div><span className="muted">{t('mt.technician')}</span><div><b>{w.technician ?? t('mt.unassigned')}</b></div></div>
        <div><span className="muted">{t('mt.scheduled')}</span><div><b>{w.scheduled_at ? fmtDateTime(w.scheduled_at, locale) : '—'}</b></div></div>
        <div><span className="muted">{t('mt.due')}</span><div><b>{w.due_at ? fmtDateTime(w.due_at, locale) : '—'}</b></div></div>
      </div>
      {w.description && <p style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{w.description}</p>}
      {sup && ['planned', 'in_progress', 'on_hold'].includes(w.status) && (
        <div className="row" style={{ gap: 8 }}>
          <select className="input" style={{ width: 'auto' }} aria-label={t('mt.assignTo')} value={editTech} onChange={(e) => setEditTech(e.target.value)}>
            <option value="">{t('mt.reassign')}</option>{(meta?.technicians ?? []).filter((x: any) => x.available).map((x: any) => <option key={x.id} value={x.id}>{x.name}</option>)}
          </select>
          <button className="btn sm" disabled={!editTech} onClick={() => run(() => patch(`/api/maintenance/work-orders/${id}`, { technician_id: Number(editTech) }), t('mt.assigned')).then(() => setEditTech(''))}>{t('mt.assign')}</button>
        </div>
      )}
      <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
        {workable && w.status === 'planned' && <button className="btn primary" onClick={() => run(() => post(`/api/maintenance/work-orders/${id}/action`, { action: 'start' }), t('mt.started'))}>{t('mt.start')}</button>}
        {workable && w.status === 'on_hold' && <button className="btn primary" onClick={() => run(() => post(`/api/maintenance/work-orders/${id}/action`, { action: 'resume' }), t('mt.started'))}>{t('mt.resume')}</button>}
        {workable && w.status === 'in_progress' && <button className="btn" onClick={() => setHold(true)}>{t('mt.hold')}</button>}
        {workable && w.status === 'in_progress' && <button className="btn primary" onClick={() => setFinish({ outcome: 'fixed', result: '' })}>{t('mt.finish')}</button>}
        {sup && w.status === 'done' && <button className="btn primary" onClick={() => setValid({ rating: 5, comment: '' })}>{t('mt.validate')}</button>}
        {sup && ['planned', 'in_progress', 'on_hold'].includes(w.status) && <button className="btn danger" onClick={() => setCancel(true)}>{t('common.cancel')}</button>}
      </div>
      {w.result && <div className="alert" style={{ borderColor: '#15803D', color: '#166534' }}>{t(`mt.o_${w.outcome}` as Key)} : {w.result}{w.rating ? ` · ${'★'.repeat(w.rating)}${w.validator ? ` (${w.validator})` : ''}` : ''}</div>}

      {(w.checklist ?? []).length > 0 && <>
        <h4 style={{ margin: '6px 0 0' }}>{t('mt.checklist')}</h4>
        {(w.checklist as any[]).map((c, i) => (
          <label key={i} className="row" style={{ gap: 8, cursor: workable && w.status === 'in_progress' ? 'pointer' : undefined }}>
            <input type="checkbox" checked={!!c.done} disabled={!(workable && w.status === 'in_progress')} onChange={(e) => run(() => post(`/api/maintenance/work-orders/${id}/checklist`, { index: i, done: e.target.checked })).catch(() => {})} />
            <span style={{ textDecoration: c.done ? 'line-through' : undefined }}>{c.label}</span>
          </label>
        ))}
      </>}

      <h4 style={{ margin: '6px 0 0' }}>{t('mt.timeSpent')} — {hm(w.labor_minutes)} · {money(Number(w.labor_cost), locale)}</h4>
      {w.time.map((l: any) => <div key={l.id} className="sum-row" style={{ fontSize: 13 }}><span>{fmtDate(d10(l.work_date), locale)} · {l.technician} · {hm(l.minutes)}{l.note ? ` — ${l.note}` : ''}</span><b>{money(Number(l.cost), locale)}</b></div>)}
      {workable && w.status !== 'planned' && (
        <div className="row" style={{ gap: 8, flexWrap: 'nowrap' }}>
          <input className="input" style={{ width: 110 }} type="number" min={1} max={1440} placeholder={t('mt.minutes')} aria-label={t('mt.minutes')} value={time.minutes} onChange={(e) => setTime({ ...time, minutes: e.target.value })} />
          <input className="input" style={{ flex: 1, width: 'auto' }} placeholder={t('mt.note')} aria-label={t('mt.note')} value={time.note} onChange={(e) => setTime({ ...time, note: e.target.value })} />
          <button className="btn" disabled={!(Number(time.minutes) > 0)} onClick={() => run(() => post(`/api/maintenance/work-orders/${id}/time`, { minutes: Number(time.minutes), note: time.note || null }), t('mt.timeAdded')).then(() => setTime({ minutes: '', note: '' })).catch(() => {})}>{t('mt.addTime')}</button>
        </div>
      )}

      <h4 style={{ margin: '6px 0 0' }}>{t('mt.partsUsed')} — {money(Number(w.parts_cost), locale)}</h4>
      {w.parts.map((p: any) => <div key={p.id} className="sum-row" style={{ fontSize: 13 }}><span>{p.product} × {Number(p.quantity)} {p.unit} <span className="muted">· {p.warehouse}</span></span><b>{money(Number(p.cost), locale)}</b></div>)}
      {w.purchases?.map((p: any) => <div key={p.id} className="muted" style={{ fontSize: 12.5 }}>{t('mt.purchaseCreated')} {p.number} · {p.status}</div>)}
      {workable && w.status !== 'planned' && (
        <div className="row" style={{ gap: 8, flexWrap: 'nowrap' }}>
          <select className="input" style={{ flex: 1, width: 'auto' }} aria-label={t('mt.part')} value={part.product_id} onChange={(e) => { setPart({ ...part, product_id: e.target.value }); setMissing(null); }}>
            <option value="">{t('mt.choosePart')}</option>{parts.map((p) => <option key={p.id} value={p.id}>{p.name} ({Number(p.qty)} {p.unit})</option>)}
          </select>
          <input className="input" style={{ width: 90 }} aria-label={t('mt.qty')} value={part.quantity} onChange={(e) => setPart({ ...part, quantity: e.target.value })} />
          <button className="btn" disabled={!part.product_id || !(toNum(part.quantity) > 0)} onClick={() => addPart(false)}>{t('mt.usePart')}</button>
        </div>
      )}
      {missing && (
        <div className="alert" style={{ borderColor: 'var(--danger)', color: 'var(--danger)', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <span style={{ flex: 1 }}>{missing}</span>
          {can('purchase.request') && <button className="btn sm primary" onClick={() => addPart(true)}>{t('mt.requestPurchase')}</button>}
        </div>
      )}

      <h4 style={{ margin: '6px 0 0' }}>{t('mt.external')} — {money(Number(w.external_cost), locale)}</h4>
      {w.external.map((x: any) => <div key={x.id} className="sum-row" style={{ fontSize: 13 }}><span>{x.description}{x.supplier ? ` · ${x.supplier}` : ''} <span className="muted">· {x.expense_id ? t('mt.paidExpense') : `${t('mt.invoice')} ${x.invoice_number ?? ''}`}</span></span><b>{money(Number(x.amount), locale)}</b></div>)}
      {sup && ['planned', 'in_progress', 'on_hold', 'done'].includes(w.status) && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setExt({ description: '', amount: '', supplier_id: '', mode: 'paid', method: 'cash', invoice_number: '', tax_total: '' })}><Icon name="plus" size={14} />{t('mt.addExternal')}</button>}

      <div className="sum-row" style={{ fontWeight: 700, fontSize: 15, borderTop: '1px solid var(--border)', paddingTop: 8 }}><span>{t('mt.totalCost')}</span><b>{money(Number(w.total_cost), locale)}</b></div>

      <h4 style={{ margin: '6px 0 0' }}>{t('mt.photos')}</h4>
      <Photos type="work_order" id={w.id} photos={w.photos} canAdd={mineOk && w.status !== 'cancelled'} onChanged={load} />
      <h4 style={{ margin: '6px 0 0' }}>{t('mt.comments')}</h4>
      {w.comments.map((c: any) => <div key={c.id} style={{ fontSize: 13 }}><span className="muted">{fmtDateTime(c.created_at, locale)} · {c.user}</span><div>{c.text}</div></div>)}
      {mineOk && (
        <div className="row" style={{ gap: 8, flexWrap: 'nowrap' }}>
          <input className="input" style={{ flex: 1, width: 'auto' }} placeholder={t('mt.addComment')} aria-label={t('mt.addComment')} value={comment} onChange={(e) => setComment(e.target.value)} />
          <button className="btn" disabled={!comment.trim()} onClick={() => run(() => post(`/api/maintenance/work-orders/${id}/comments`, { text: comment })).then(() => setComment('')).catch(() => {})}>{t('mt.send')}</button>
        </div>
      )}

      {hold && <HoldModal onClose={() => setHold(false)} onSubmit={(reason, partsWait) => { setHold(false); run(() => post(`/api/maintenance/work-orders/${id}/action`, { action: 'hold', reason, parts: partsWait }), t('mt.saved')).catch(() => {}); }} />}
      {cancel && <ReasonModal title={t('mt.cancelWo')} onClose={() => setCancel(false)} onSubmit={(r) => { setCancel(false); run(() => post(`/api/maintenance/work-orders/${id}/cancel`, { reason: r }), t('mt.saved')).catch(() => {}); }} />}
      {finish && (
        <Modal title={t('mt.finish')} onClose={() => setFinish(null)} footer={<><button className="btn" onClick={() => setFinish(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={finish.result.trim().length < 3} onClick={() => run(() => post(`/api/maintenance/work-orders/${id}/complete`, finish), t('mt.finished')).then(() => setFinish(null)).catch(() => {})}>{t('mt.finish')}</button></>}>
          <Field label={t('mt.outcome')}><div className="seg">{['fixed', 'partial', 'not_fixed', 'no_issue'].map((o) => <button key={o} type="button" className={finish.outcome === o ? 'on' : ''} onClick={() => setFinish({ ...finish, outcome: o })}>{t(`mt.o_${o}` as Key)}</button>)}</div></Field>
          <Field label={t('mt.result')}><textarea className="input" rows={3} value={finish.result} onChange={(e) => setFinish({ ...finish, result: e.target.value })} autoFocus /></Field>
        </Modal>
      )}
      {valid && (
        <Modal title={t('mt.validate')} onClose={() => setValid(null)} footer={<><button className="btn" onClick={() => setValid(null)}>{t('common.cancel')}</button><button className="btn primary" onClick={() => run(() => post(`/api/maintenance/work-orders/${id}/validate`, { rating: valid.rating, comment: valid.comment || null }), t('mt.validated')).then(() => setValid(null)).catch(() => {})}>{t('mt.validate')}</button></>}>
          <Field label={t('mt.rating')}><div className="seg">{[1, 2, 3, 4, 5].map((n) => <button key={n} type="button" className={valid.rating === n ? 'on' : ''} onClick={() => setValid({ ...valid, rating: n })}>{'★'.repeat(n)}</button>)}</div></Field>
          <Field label={t('mt.comment')}><input className="input" value={valid.comment} onChange={(e) => setValid({ ...valid, comment: e.target.value })} /></Field>
          <span className="muted" style={{ fontSize: 12.5 }}>{t('mt.validateHint')}</span>
        </Modal>
      )}
      {ext && (
        <Modal title={t('mt.addExternal')} onClose={() => setExt(null)} footer={<><button className="btn" onClick={() => setExt(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!ext.description.trim() || !(toNum(ext.amount) > 0)} onClick={() => run(() => post(`/api/maintenance/work-orders/${id}/external`, {
          description: ext.description, amount: toNum(ext.amount), supplier_id: ext.supplier_id ? Number(ext.supplier_id) : null, mode: ext.mode, method: ext.method, invoice_number: ext.invoice_number || null, tax_total: ext.tax_total ? toNum(ext.tax_total) : null,
        }), t('mt.saved')).then(() => setExt(null)).catch(() => {})}>{t('common.save')}</button></>}>
          <div className="form-grid">
            <Field label={t('mt.description')}><input className="input" value={ext.description} onChange={(e) => setExt({ ...ext, description: e.target.value })} /></Field>
            <Field label={t('mt.amountTtc')}><input className="input" value={ext.amount} onChange={(e) => setExt({ ...ext, amount: e.target.value })} /></Field>
            <Field label={t('mt.supplier')}><select className="input" value={ext.supplier_id} onChange={(e) => setExt({ ...ext, supplier_id: e.target.value })}><option value="">—</option>{(meta?.suppliers ?? []).map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
            <Field label={t('mt.mode')}><div className="seg"><button type="button" className={ext.mode === 'paid' ? 'on' : ''} onClick={() => setExt({ ...ext, mode: 'paid' })}>{t('mt.paidNow')}</button><button type="button" className={ext.mode === 'invoice' ? 'on' : ''} onClick={() => setExt({ ...ext, mode: 'invoice' })}>{t('mt.toPay')}</button></div></Field>
            {ext.mode === 'paid' ? <Field label={t('mt.method')}><select className="input" value={ext.method} onChange={(e) => setExt({ ...ext, method: e.target.value })}>{['cash', 'card', 'cheque', 'transfer'].map((m) => <option key={m} value={m}>{t(`mt.m_${m}` as Key)}</option>)}</select></Field>
              : <><Field label={t('mt.invoiceNo')}><input className="input" value={ext.invoice_number} onChange={(e) => setExt({ ...ext, invoice_number: e.target.value })} /></Field><Field label={t('mt.taxTotal')}><input className="input" value={ext.tax_total} onChange={(e) => setExt({ ...ext, tax_total: e.target.value })} /></Field></>}
          </div>
          <span className="muted" style={{ fontSize: 12.5 }}>{ext.mode === 'paid' ? t('mt.paidHint') : t('mt.invoiceHint')}</span>
        </Modal>
      )}
    </Modal>
  );
}
function HoldModal({ onClose, onSubmit }: { onClose: () => void; onSubmit: (r: string, parts: boolean) => void }) {
  const { t } = useI18n();
  const [r, setR] = useState('');
  const [p, setP] = useState(false);
  return (
    <Modal title={t('mt.hold')} onClose={onClose} size="sm" footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!r.trim()} onClick={() => onSubmit(r, p)}>{t('common.save')}</button></>}>
      <Field label={t('mt.reason')}><input className="input" value={r} onChange={(e) => setR(e.target.value)} autoFocus /></Field>
      <label className="row" style={{ gap: 8 }}><input type="checkbox" checked={p} onChange={(e) => setP(e.target.checked)} />{t('mt.waitingPartsCheck')}</label>
    </Modal>
  );
}

// ===================================================== Équipements =====================================================
function Equipment({ openEq }: { openEq: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [f, setF] = useState({ q: '', category: '', status: '' });
  const [rows, setRows] = useState<any[] | null>(null);
  const [edit, setEdit] = useState<any>(null);
  const load = useCallback(() => {
    const qs = new URLSearchParams();
    if (f.q) qs.set('q', f.q); if (f.category) qs.set('category', f.category); if (f.status) qs.set('status', f.status);
    if (f.status === 'retired') qs.set('all', 'true');
    get(`/api/equipment?${qs}`).then(setRows).catch(err(toast));
  }, [f.q, f.category, f.status]);
  useEffect(load, [load]);
  return (
    <>
      <div className="row">
        <input className="input" style={{ maxWidth: 260 }} placeholder={t('mt.search')} aria-label={t('mt.search')} value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} />
        <select className="input" style={{ width: 'auto' }} aria-label={t('mt.category')} value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}><option value="">{t('mt.allCategories')}</option>{CATS.map((c) => <option key={c} value={c}>{t(`mt.c_${c}` as Key)}</option>)}</select>
        <select className="input" style={{ width: 'auto' }} aria-label={t('mt.state')} value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}><option value="">{t('mt.allStates')}</option>{Object.keys(EQ_COLORS).map((s) => <option key={s} value={s}>{t(`mt.es_${s}` as Key)}</option>)}</select>
        <span style={{ flex: 1 }} />
        {can('equipment.manage') && <button className="btn primary" onClick={() => setEdit({})}><Icon name="plus" size={14} />{t('mt.newEquipment')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('mt.ref')}</th><th>{t('mt.equipment')}</th><th>{t('mt.category')}</th><th>{t('mt.where')}</th><th>{t('mt.state')}</th><th>{t('mt.warranty')}</th><th className="num">{t('mt.faults')}</th><th>{t('mt.nextPreventive')}</th><th className="num">{t('mt.cost')}</th></tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={9} className="muted">{t('common.none')}</td></tr>}
            {(rows ?? []).map((e) => (
              <tr key={e.id} style={{ cursor: 'pointer' }} onClick={() => openEq(e.id)}>
                <td><b>{e.code}</b>{e.critical ? <span className="pill prio-urgent" style={{ marginInlineStart: 4 }}>{t('mt.critical')}</span> : null}</td>
                <td className="wrap">{e.name}<div className="muted" style={{ fontSize: 12 }}>{[e.brand, e.model].filter(Boolean).join(' ')}</div></td>
                <td>{t(`mt.c_${e.category}` as Key)}</td><td className="wrap">{e.room ? `${t('mt.room')} ${e.room}` : t(`mt.l_${e.location_type}` as Key)}{e.location_detail ? ` · ${e.location_detail}` : ''}</td>
                <td><Pill map={EQ_COLORS} s={e.status} k="mt.es_" /></td>
                <td>{e.warranty_until ? <span style={{ color: e.under_warranty ? '#15803D' : 'var(--muted)' }}>{e.under_warranty ? '✓ ' : ''}{fmtDate(e.warranty_until, locale, { day: 'numeric', month: 'short', year: 'numeric' })}</span> : '—'}</td>
                <td className="num">{e.faults}{e.open_faults ? <span style={{ color: 'var(--danger)' }}> ({e.open_faults})</span> : null}</td>
                <td>{e.next_preventive ? fmtDate(d10(e.next_preventive), locale) : '—'}</td><td className="num">{money(Number(e.cost), locale)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {edit && <EquipmentModal init={edit} onClose={() => setEdit(null)} onDone={() => { setEdit(null); load(); }} />}
    </>
  );
}

function EquipmentModal({ init, onClose, onDone }: { init: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const meta = useMeta();
  const [b, setB] = useState<any>({
    code: init.code ?? '', name: init.name ?? '', category: init.category ?? 'hvac', brand: init.brand ?? '', model: init.model ?? '', serial_no: init.serial_no ?? '', location_type: init.location_type ?? 'room',
    room_id: init.room_id ?? '', location_detail: init.location_detail ?? '', department: init.department ?? 'rooms', purchase_date: d10(init.purchase_date), install_date: d10(init.install_date),
    warranty_months: init.warranty_months ?? '', supplier_id: init.supplier_id ?? '', purchase_cost: init.purchase_cost ?? '', critical: !!init.critical, notes: init.notes ?? '',
  });
  const set = (k: string) => (e: any) => setB({ ...b, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const save = async () => {
    const body = {
      ...b, room_id: b.room_id ? Number(b.room_id) : null, supplier_id: b.supplier_id ? Number(b.supplier_id) : null, purchase_date: b.purchase_date || null, install_date: b.install_date || null,
      warranty_months: b.warranty_months === '' ? null : Number(b.warranty_months), purchase_cost: b.purchase_cost === '' ? null : toNum(b.purchase_cost),
      brand: b.brand || null, model: b.model || null, serial_no: b.serial_no || null, location_detail: b.location_detail || null, notes: b.notes || null,
    };
    try { if (init.id) await patch(`/api/equipment/${init.id}`, body); else await post('/api/equipment', body); toast('success', t('mt.saved')); onDone(); } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={init.id ? `${init.code} — ${init.name}` : t('mt.newEquipment')} onClose={onClose} size="lg" footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!b.code.trim() || b.name.trim().length < 2} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('mt.ref')}><input className="input" value={b.code} onChange={set('code')} /></Field>
        <Field label={t('mt.name')}><input className="input" value={b.name} onChange={set('name')} /></Field>
        <Field label={t('mt.category')}><select className="input" value={b.category} onChange={set('category')}>{CATS.map((c) => <option key={c} value={c}>{t(`mt.c_${c}` as Key)}</option>)}</select></Field>
        <Field label={t('mt.department')}><select className="input" value={b.department} onChange={set('department')}>{DEPTS.map((c) => <option key={c} value={c}>{t(`mt.d_${c}` as Key)}</option>)}</select></Field>
        <Field label={t('mt.brand')}><input className="input" value={b.brand} onChange={set('brand')} /></Field>
        <Field label={t('mt.model')}><input className="input" value={b.model} onChange={set('model')} /></Field>
        <Field label={t('mt.serial')}><input className="input" value={b.serial_no} onChange={set('serial_no')} /></Field>
        <Field label={t('mt.locationType')}><select className="input" value={b.location_type} onChange={set('location_type')}>{LOCS.map((c) => <option key={c} value={c}>{t(`mt.l_${c}` as Key)}</option>)}</select></Field>
        {b.location_type === 'room' && <Field label={t('mt.room')}><select className="input" value={b.room_id} onChange={set('room_id')}><option value="">—</option>{(meta?.rooms ?? []).map((r: any) => <option key={r.id} value={r.id}>{r.number}</option>)}</select></Field>}
        <Field label={t('mt.locationDetail')}><input className="input" value={b.location_detail} onChange={set('location_detail')} /></Field>
        <Field label={t('mt.purchaseDate')}><input type="date" className="input" max={todayLocal()} value={b.purchase_date} onChange={set('purchase_date')} /></Field>
        <Field label={t('mt.installDate')}><input type="date" className="input" value={b.install_date} onChange={set('install_date')} /></Field>
        <Field label={t('mt.warrantyMonths')}><input type="number" min={0} max={240} className="input" value={b.warranty_months} onChange={set('warranty_months')} /></Field>
        <Field label={t('mt.supplier')}><select className="input" value={b.supplier_id} onChange={set('supplier_id')}><option value="">—</option>{(meta?.suppliers ?? []).map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
        <Field label={t('mt.purchaseCost')}><input className="input" value={b.purchase_cost} onChange={set('purchase_cost')} /></Field>
        <label className="row" style={{ gap: 8, alignSelf: 'end' }}><input type="checkbox" checked={b.critical} onChange={set('critical')} />{t('mt.criticalHint')}</label>
      </div>
      <Field label={t('mt.notes')}><textarea className="input" rows={2} value={b.notes} onChange={set('notes')} /></Field>
    </Modal>
  );
}

function EquipmentSheet({ id, onClose, onChanged, declare, openWo, openTk }: { id: number; onClose: () => void; onChanged: () => void; declare: (e: any) => void; openWo: (id: number) => void; openTk: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [e, setE] = useState<any>(null);
  const [edit, setEdit] = useState(false);
  const ref = useRef<HTMLInputElement>(null);
  const load = useCallback(() => { get(`/api/equipment/${id}`).then(setE).catch(err(toast)); }, [id]);
  useEffect(load, [load]);
  if (!e) return <Modal title="…" onClose={onClose}><span>{t('common.loading')}</span></Modal>;
  const addDoc = async (files: FileList | null) => {
    for (const f of Array.from(files ?? [])) { try { await upload('/api/photos', f, { owner_type: 'equipment', owner_id: String(id) }); } catch (x: any) { toast('error', x.message); } }
    if (ref.current) ref.current.value = '';
    load();
  };
  const setStatus = async (status: string) => { try { await patch(`/api/equipment/${id}`, { status }); load(); onChanged(); } catch (x: any) { toast('error', x.message); } };
  return (
    <Modal title={`${e.code} — ${e.name}`} onClose={onClose} size="lg">
      <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
        <Pill map={EQ_COLORS} s={e.status} k="mt.es_" /><span className="pill">{t(`mt.c_${e.category}` as Key)}</span>{e.critical && <span className="pill prio-urgent">{t('mt.critical')}</span>}
        {e.warranty_until && <span className="pill" style={{ background: e.warranty_until >= todayLocal() ? '#DCFCE7' : undefined }}>{t('mt.warranty')} → {fmtDate(e.warranty_until, locale, { day: 'numeric', month: 'short', year: 'numeric' })}</span>}
      </div>
      <div className="form-grid">
        {[['mt.brand', [e.brand, e.model].filter(Boolean).join(' ')], ['mt.serial', e.serial_no], ['mt.where', e.room ? `${t('mt.room')} ${e.room}` : t(`mt.l_${e.location_type}` as Key)], ['mt.locationDetail', e.location_detail],
          ['mt.department', t(`mt.d_${e.department}` as Key)], ['mt.supplier', e.supplier], ['mt.purchaseDate', e.purchase_date ? fmtDate(d10(e.purchase_date), locale, { day: 'numeric', month: 'short', year: 'numeric' }) : ''],
          ['mt.installDate', e.install_date ? fmtDate(d10(e.install_date), locale, { day: 'numeric', month: 'short', year: 'numeric' }) : ''], ['mt.purchaseCost', e.purchase_cost ? money(Number(e.purchase_cost), locale) : '']].map(([k, v]) => (
          <div key={k}><span className="muted">{t(k as Key)}</span><div><b>{v || '—'}</b></div></div>
        ))}
      </div>
      <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
        {can('maintenance.report') && e.status !== 'retired' && <button className="btn primary" onClick={() => declare(e)}>{t('mt.declare')}</button>}
        {can('equipment.manage') && <button className="btn" onClick={() => setEdit(true)}>{t('common.edit')}</button>}
        {can('equipment.manage') && e.status !== 'retired' && e.status !== 'out_of_service' && <button className="btn" onClick={() => setStatus('out_of_service')}>{t('mt.es_out_of_service')}</button>}
        {can('equipment.manage') && e.status === 'out_of_service' && <button className="btn" onClick={() => setStatus('operational')}>{t('mt.es_operational')}</button>}
        {can('equipment.manage') && e.status !== 'retired' && <button className="btn danger" onClick={() => confirm(t('mt.retireConfirm')) && setStatus('retired')}>{t('mt.retire')}</button>}
      </div>
      <h4 style={{ margin: '6px 0 0' }}>{t('mt.documents')}</h4>
      <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
        {e.documents.map((d: any) => d.mime === 'application/pdf'
          ? <a key={d.id} className="btn sm" href={`/api/photos/${d.id}`} target="_blank" rel="noreferrer">PDF #{d.id}</a>
          : <a key={d.id} href={`/api/photos/${d.id}`} target="_blank" rel="noreferrer"><img src={`/api/photos/${d.id}`} alt="" style={{ width: 84, height: 64, objectFit: 'cover', borderRadius: 8 }} /></a>)}
        {can('equipment.manage') && <><input ref={ref} type="file" hidden accept="image/jpeg,image/png,image/webp,application/pdf" multiple onChange={(x) => addDoc(x.target.files)} /><button className="btn sm" onClick={() => ref.current?.click()}><Icon name="plus" size={14} />{t('mt.addDoc')}</button></>}
        {!e.documents.length && !can('equipment.manage') && <span className="muted">{t('common.none')}</span>}
      </div>
      <h4 style={{ margin: '6px 0 0' }}>{t('mt.t_preventive')}</h4>
      {!e.plans.length && <span className="muted">{t('common.none')}</span>}
      {e.plans.map((p: any) => <div key={p.id} className="sum-row" style={{ fontSize: 13 }}><span>{p.name} · {t(`mt.f_${p.frequency}` as Key)}</span><span>{fmtDate(d10(p.next_due), locale)}</span></div>)}
      <h4 style={{ margin: '6px 0 0' }}>{t('mt.fullHistory')}</h4>
      <table className="table">
        <thead><tr><th>{t('mt.date')}</th><th>{t('mt.number')}</th><th>{t('mt.fault')}</th><th>{t('mt.status')}</th><th className="num">{t('mt.cost')}</th></tr></thead>
        <tbody>
          {[...e.tickets.map((x: any) => ({ ...x, _t: 'tk' })), ...e.work_orders.map((x: any) => ({ ...x, _t: 'wo' }))].sort((a, b) => String(b.created_at).localeCompare(String(a.created_at))).map((x: any) => (
            <tr key={`${x._t}${x.id}`} style={{ cursor: 'pointer' }} onClick={() => (x._t === 'tk' ? openTk(x.id) : openWo(x.id))}>
              <td>{fmtDateTime(x.created_at, locale)}</td><td><b>{x.number}</b></td><td className="wrap">{x.title}{x.result ? <div className="muted" style={{ fontSize: 12 }}>{x.result}</div> : null}</td>
              <td>{x._t === 'tk' ? <Pill map={TK_COLORS} s={x.status} k="mt.ts_" /> : <Pill map={WO_COLORS} s={x.status} k="mt.ws_" />}</td>
              <td className="num">{x._t === 'wo' ? money(Number(x.total_cost), locale) : ''}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {edit && <EquipmentModal init={e} onClose={() => setEdit(false)} onDone={() => { setEdit(false); load(); onChanged(); }} />}
    </Modal>
  );
}

// ===================================================== Préventif =====================================================
function Preventive({ openWo }: { openWo: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null);
  const [edit, setEdit] = useState<any>(null);
  const load = useCallback(() => { get('/api/maintenance/plans').then(setRows).catch(err(toast)); }, []);
  useEffect(load, [load]);
  const T = todayLocal();
  const gen = async () => { try { const r = await post('/api/maintenance/plans/generate', {}); toast('success', `${r.created} ${t('mt.generated')}`); load(); } catch (e: any) { toast('error', e.message); } };
  return (
    <>
      <div className="row">
        <span className="muted" style={{ flex: 1 }}>{t('mt.preventiveHint')}</span>
        {can('maintenance.supervise') && <button className="btn" onClick={gen}>{t('mt.generateNow')}</button>}
        {can('maintenance.supervise') && <button className="btn primary" onClick={() => setEdit({})}><Icon name="plus" size={14} />{t('mt.newPlan')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('mt.plan')}</th><th>{t('mt.equipment')}</th><th>{t('mt.frequency')}</th><th>{t('mt.nextDue')}</th><th>{t('mt.lastDone')}</th><th>{t('mt.technician')}</th><th>{t('mt.wo')}</th><th className="num">{t('mt.doneCount')}</th></tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
            {(rows ?? []).map((p) => {
              const due = d10(p.next_due), late = p.active && due < T, soon = p.active && !late && due <= addDays(T, p.alert_days);
              return (
                <tr key={p.id} style={{ opacity: p.active ? 1 : 0.5, cursor: can('maintenance.supervise') ? 'pointer' : undefined }} onClick={() => can('maintenance.supervise') && setEdit(p)}>
                  <td className="wrap"><b>{p.name}</b>{p.checklist?.length ? <div className="muted" style={{ fontSize: 12 }}>{p.checklist.length} {t('mt.points')}</div> : null}</td>
                  <td>{p.equipment ?? '—'}</td><td>{p.interval_count > 1 ? `${p.interval_count} × ` : ''}{t(`mt.f_${p.frequency}` as Key)}</td>
                  <td style={{ color: late ? 'var(--danger)' : soon ? '#B45309' : undefined, fontWeight: late || soon ? 600 : undefined }}>{fmtDate(due, locale)}{late ? ` · ${t('mt.late')}` : ''}</td>
                  <td>{p.last_done ? fmtDate(d10(p.last_done), locale) : '—'}</td><td>{p.technician ?? '—'}</td>
                  <td>{p.current_wo ? <button className="btn sm" onClick={(e) => { e.stopPropagation(); openWo(p.current_wo.id); }}>{p.current_wo.number} · {t(`mt.ws_${p.current_wo.status}` as Key)}</button> : '—'}</td>
                  <td className="num">{p.done_count}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {edit && <PlanModal init={edit} onClose={() => setEdit(null)} onDone={() => { setEdit(null); load(); }} />}
    </>
  );
}
function PlanModal({ init, onClose, onDone }: { init: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const meta = useMeta();
  const [b, setB] = useState<any>({
    name: init.name ?? '', equipment_id: init.equipment_id ?? '', frequency: init.frequency ?? 'monthly', interval_count: init.interval_count ?? 1, next_due: d10(init.next_due) || todayLocal(), alert_days: init.alert_days ?? 3,
    technician_id: init.technician_id ?? '', estimated_minutes: init.estimated_minutes ?? 30, checklist: (init.checklist ?? []).map((c: any) => (typeof c === 'string' ? c : c.label)).join('\n'), instructions: init.instructions ?? '', active: init.active ?? true,
  });
  const set = (k: string) => (e: any) => setB({ ...b, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const save = async () => {
    const body = { ...b, equipment_id: b.equipment_id ? Number(b.equipment_id) : null, technician_id: b.technician_id ? Number(b.technician_id) : null, interval_count: Number(b.interval_count), alert_days: Number(b.alert_days),
      estimated_minutes: Number(b.estimated_minutes), checklist: b.checklist.split('\n').map((s: string) => s.trim()).filter(Boolean), instructions: b.instructions || null };
    try { if (init.id) await patch(`/api/maintenance/plans/${init.id}`, body); else await post('/api/maintenance/plans', body); toast('success', t('mt.saved')); onDone(); } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={init.id ? init.name : t('mt.newPlan')} onClose={onClose} size="lg" footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={b.name.trim().length < 3} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('mt.plan')}><input className="input" value={b.name} onChange={set('name')} /></Field>
        <Field label={t('mt.equipment')}><select className="input" value={b.equipment_id} onChange={set('equipment_id')}><option value="">—</option>{(meta?.equipment ?? []).map((e: any) => <option key={e.id} value={e.id}>{e.code} · {e.name}</option>)}</select></Field>
        <Field label={t('mt.frequency')}><select className="input" value={b.frequency} onChange={set('frequency')}>{['daily', 'weekly', 'monthly', 'quarterly', 'yearly'].map((f) => <option key={f} value={f}>{t(`mt.f_${f}` as Key)}</option>)}</select></Field>
        <Field label={t('mt.every')}><input type="number" min={1} max={52} className="input" value={b.interval_count} onChange={set('interval_count')} /></Field>
        <Field label={t('mt.nextDue')}><input type="date" className="input" value={b.next_due} onChange={set('next_due')} /></Field>
        <Field label={t('mt.alertDays')}><input type="number" min={0} max={90} className="input" value={b.alert_days} onChange={set('alert_days')} /></Field>
        <Field label={t('mt.technician')}><select className="input" value={b.technician_id} onChange={set('technician_id')}><option value="">—</option>{(meta?.technicians ?? []).map((x: any) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></Field>
        <Field label={t('mt.estimated')}><input type="number" min={1} className="input" value={b.estimated_minutes} onChange={set('estimated_minutes')} /></Field>
        {init.id && <label className="row" style={{ gap: 8, alignSelf: 'end' }}><input type="checkbox" checked={b.active} onChange={set('active')} />{t('mt.active')}</label>}
      </div>
      <Field label={t('mt.checklistLines')}><textarea className="input" rows={4} value={b.checklist} onChange={set('checklist')} /></Field>
      <Field label={t('mt.instructions')}><textarea className="input" rows={2} value={b.instructions} onChange={set('instructions')} /></Field>
    </Modal>
  );
}

// ===================================================== Techniciens =====================================================
function Technicians() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null);
  const [edit, setEdit] = useState<any>(null);
  const [avail, setAvail] = useState<any>(null);
  const load = useCallback(() => { get('/api/maintenance/technicians').then(setRows).catch(err(toast)); }, []);
  useEffect(load, [load]);
  const setAvailable = async (x: any, body: any) => { try { await patch(`/api/maintenance/technicians/${x.id}`, body); load(); } catch (e: any) { toast('error', e.message); } };
  return (
    <>
      <div className="row"><span style={{ flex: 1 }} />{can('equipment.manage') && <button className="btn primary" onClick={() => setEdit({})}><Icon name="plus" size={14} />{t('mt.newTech')}</button>}</div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 12 }}>
        {(rows ?? []).map((x) => (
          <div key={x.id} className="hk-card" style={{ opacity: x.active ? 1 : 0.5 }}>
            <div className="row between"><b>{x.name}</b><span className="pill" style={{ background: x.available ? '#DCFCE7' : '#FEE2E2', color: x.available ? '#166534' : '#991B1B' }}>{x.available ? t('mt.available') : t('mt.unavailable')}</span></div>
            <div className="muted" style={{ fontSize: 12.5 }}>{x.external ? `${t('mt.externalTech')}${x.supplier ? ` · ${x.supplier}` : ''}` : x.username ? `@${x.username}` : t('mt.noAccount')} · {money(Number(x.hourly_rate), locale)}/h</div>
            {!x.available && x.unavailable_reason && <div style={{ fontSize: 12.5, color: 'var(--danger)' }}>{x.unavailable_reason}{x.unavailable_until ? ` → ${fmtDate(d10(x.unavailable_until), locale)}` : ''}</div>}
            <div className="row" style={{ gap: 4, flexWrap: 'wrap' }}>{(x.specialties ?? []).map((s: string) => <span key={s} className="pill">{t(`mt.c_${s}` as Key)}</span>)}</div>
            <div className="sum-row" style={{ fontSize: 13 }}><span>{t('mt.workload')}</span><b>{x.open_orders}{x.urgent_orders ? <span style={{ color: 'var(--danger)' }}> ({x.urgent_orders} !)</span> : null}</b></div>
            <div className={`meter ${x.open_orders < 3 ? 'ok' : ''}`}><i style={{ width: `${Math.min(100, x.open_orders * 20)}%` }} /></div>
            <div className="sum-row" style={{ fontSize: 13 }}><span>{t('mt.doneMonth')}</span><b>{x.done_month} · {hm(x.minutes_month)}</b></div>
            <div className="sum-row" style={{ fontSize: 13 }}><span>{t('mt.rating')}</span><b>{x.rating ? `${Number(x.rating).toFixed(1)} ★` : '—'}</b></div>
            <div className="row" style={{ gap: 6 }}>
              {can('maintenance.supervise') && x.active && (x.available ? <button className="btn sm" onClick={() => setAvail(x)}>{t('mt.setUnavailable')}</button> : <button className="btn sm" onClick={() => setAvailable(x, { available: true })}>{t('mt.setAvailable')}</button>)}
              {can('equipment.manage') && <button className="btn sm" onClick={() => setEdit(x)}>{t('common.edit')}</button>}
            </div>
          </div>
        ))}
      </div>
      {edit && <TechModal init={edit} onClose={() => setEdit(null)} onDone={() => { setEdit(null); load(); }} />}
      {avail && <AvailModal onClose={() => setAvail(null)} onSubmit={(reason, until) => { const x = avail; setAvail(null); setAvailable(x, { available: false, unavailable_reason: reason, unavailable_until: until || null }); }} />}
    </>
  );
}
function AvailModal({ onClose, onSubmit }: { onClose: () => void; onSubmit: (r: string, until: string) => void }) {
  const { t } = useI18n();
  const [r, setR] = useState('');
  const [u, setU] = useState('');
  return (
    <Modal title={t('mt.setUnavailable')} onClose={onClose} size="sm" footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!r.trim()} onClick={() => onSubmit(r, u)}>{t('common.save')}</button></>}>
      <Field label={t('mt.reason')}><input className="input" value={r} onChange={(e) => setR(e.target.value)} autoFocus /></Field>
      <Field label={t('mt.until')}><input type="date" className="input" min={todayLocal()} value={u} onChange={(e) => setU(e.target.value)} /></Field>
    </Modal>
  );
}
function TechModal({ init, onClose, onDone }: { init: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const meta = useMeta();
  const [users, setUsers] = useState<any[]>([]);
  useEffect(() => { get('/api/maintenance/users').then(setUsers).catch(() => {}); }, []);
  const [b, setB] = useState<any>({ name: init.name ?? '', user_id: init.user_id ?? '', phone: init.phone ?? '', specialties: init.specialties ?? [], hourly_rate: init.hourly_rate ?? 0, external: !!init.external, supplier_id: init.supplier_id ?? '', active: init.active ?? true });
  const save = async () => {
    const body: any = { name: b.name, user_id: b.user_id ? Number(b.user_id) : null, phone: b.phone || null, specialties: b.specialties, hourly_rate: toNum(b.hourly_rate), external: b.external, supplier_id: b.supplier_id ? Number(b.supplier_id) : null };
    if (init.id) body.active = b.active;
    try { if (init.id) await patch(`/api/maintenance/technicians/${init.id}`, body); else await post('/api/maintenance/technicians', body); toast('success', t('mt.saved')); onDone(); } catch (e: any) { toast('error', e.message); }
  };
  const tog = (c: string) => setB({ ...b, specialties: b.specialties.includes(c) ? b.specialties.filter((x: string) => x !== c) : [...b.specialties, c] });
  return (
    <Modal title={init.id ? init.name : t('mt.newTech')} onClose={onClose} size="lg" footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={b.name.trim().length < 2} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('mt.name')}><input className="input" value={b.name} onChange={(e) => setB({ ...b, name: e.target.value })} /></Field>
        <Field label={t('mt.phone')}><input className="input" value={b.phone} onChange={(e) => setB({ ...b, phone: e.target.value })} /></Field>
        <Field label={t('mt.hourlyRate')}><input className="input" value={b.hourly_rate} onChange={(e) => setB({ ...b, hourly_rate: e.target.value })} /></Field>
        <Field label={t('mt.userAccount')}><select className="input" value={b.user_id} onChange={(e) => setB({ ...b, user_id: e.target.value })}><option value="">{t('mt.noAccount')}</option>{users.map((u) => <option key={u.id} value={u.id}>{u.full_name} (@{u.username})</option>)}</select></Field>
        <label className="row" style={{ gap: 8, alignSelf: 'end' }}><input type="checkbox" checked={b.external} onChange={(e) => setB({ ...b, external: e.target.checked })} />{t('mt.externalTech')}</label>
        {b.external && <Field label={t('mt.supplier')}><select className="input" value={b.supplier_id} onChange={(e) => setB({ ...b, supplier_id: e.target.value })}><option value="">—</option>{(meta?.suppliers ?? []).map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>}
        {init.id && <label className="row" style={{ gap: 8, alignSelf: 'end' }}><input type="checkbox" checked={b.active} onChange={(e) => setB({ ...b, active: e.target.checked })} />{t('mt.active')}</label>}
      </div>
      <Field label={t('mt.specialties')}><div className="row" style={{ flexWrap: 'wrap', gap: 6 }}>{CATS.map((c) => <button key={c} type="button" className={`chip ${b.specialties.includes(c) ? 'on' : ''}`} onClick={() => tog(c)}>{t(`mt.c_${c}` as Key)}</button>)}</div></Field>
    </Modal>
  );
}

// ===================================================== Pièces détachées =====================================================
function Parts({ openWo }: { openWo: (id: number) => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [all, setAll] = useState(false);
  const [rows, setRows] = useState<any[] | null>(null);
  const [used, setUsed] = useState<any[]>([]);
  useEffect(() => { get(`/api/maintenance/parts${all ? '?all=true' : ''}`).then(setRows).catch(err(toast)); }, [all]);
  useEffect(() => { get('/api/maintenance/parts/used').then(setUsed).catch(() => {}); }, []);
  return (
    <>
      <div className="row"><label className="chip"><input type="checkbox" checked={all} onChange={(e) => setAll(e.target.checked)} /> {t('mt.allProducts')}</label><span className="muted" style={{ flex: 1 }}>{t('mt.partsHint')}</span></div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('mt.part')}</th><th>{t('mt.category')}</th><th className="num">{t('mt.inStock')}</th><th className="num">{t('mt.min')}</th><th className="num">{t('mt.unitCost')}</th><th className="num">{t('mt.usedMonth')}</th></tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={6} className="muted">{t('common.none')}</td></tr>}
            {(rows ?? []).map((p) => {
              const q = Number(p.qty), low = q <= Number(p.min_stock ?? 0);
              return <tr key={p.id}><td>{p.name}</td><td>{p.category}</td><td className="num" style={{ color: q <= 0 ? 'var(--danger)' : low ? '#B45309' : undefined, fontWeight: 600 }}>{q} {p.unit}</td><td className="num">{Number(p.min_stock ?? 0)}</td><td className="num">{money(Number(p.avg_cost) || Number(p.cost_price), locale)}</td><td className="num">{Number(p.used_month)}</td></tr>;
            })}
          </tbody>
        </table>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('mt.partsUsed')}</h3>
        <table className="table">
          <thead><tr><th>{t('mt.date')}</th><th>{t('mt.part')}</th><th className="num">{t('mt.qty')}</th><th>{t('mt.wo')}</th><th>{t('mt.equipment')}</th><th className="num">{t('mt.cost')}</th><th>{t('mt.user')}</th></tr></thead>
          <tbody>
            {!used.length && <tr><td colSpan={7} className="muted">{t('common.none')}</td></tr>}
            {used.map((x) => <tr key={x.id} style={{ cursor: 'pointer' }} onClick={() => openWo(x.wo_id)}><td>{fmtDateTime(x.created_at, locale)}</td><td>{x.product}</td><td className="num">{Number(x.quantity)} {x.unit}</td><td><b>{x.wo_number}</b></td><td>{x.equipment ?? ''}</td><td className="num">{money(Number(x.cost), locale)}</td><td>{x.user ?? ''}</td></tr>)}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ===================================================== Chambres hors service =====================================================
function Rooms({ openTk }: { openTk: (id: number) => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const load = useCallback(() => { get('/api/maintenance/dashboard').then(setD).catch(err(toast)); }, []);
  useEffect(load, [load]);
  return (
    <>
      <div className="alert" style={{ fontSize: 13 }}>{t('mt.roomsHint')}</div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('mt.room')}</th><th>{t('mt.reason')}</th><th>{t('mt.from')}</th><th>{t('mt.until')}</th><th>{t('mt.fault')}</th></tr></thead>
          <tbody>
            {d && !d.rooms.length && <tr><td colSpan={5} className="muted">{t('common.none')}</td></tr>}
            {(d?.rooms ?? []).map((r: any) => (
              <tr key={r.id} style={{ cursor: r.ticket_id ? 'pointer' : undefined }} onClick={() => r.ticket_id && openTk(r.ticket_id)}>
                <td><b>{r.number}</b></td><td className="wrap">{r.reason}</td><td>{fmtDate(d10(r.start_date), locale)}</td><td>{r.end_date ? fmtDate(d10(r.end_date), locale) : '…'}</td><td>{r.ticket ?? '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ===================================================== Rapports =====================================================
function Reports() {
  const { t, locale } = useI18n();
  const toast = useToast();
  const kinds = ['faults', 'technicians', 'resolution', 'equipment', 'costs', 'departments', 'preventive', 'rooms', 'history'];
  const [kind, setKind] = useState(kinds[0]);
  const [p, setP] = useState({ from: `${todayLocal().slice(0, 8)}01`, to: todayLocal() });
  const [r, setR] = useState<any>(null);
  const qs = `from=${p.from}&to=${p.to}`;
  useEffect(() => { setR(null); get(`/api/maintenance/reports/${kind}?${qs}`).then(setR).catch(err(toast)); }, [kind, qs]);
  const fmt = (c: any, v: any) => (v === null || v === undefined || v === '' ? '—' : c.money ? money(Number(v), locale) : String(v));
  return (
    <>
      <div className="row">
        <select className="input" style={{ width: 'auto' }} aria-label={t('mt.t_reports')} value={kind} onChange={(e) => setKind(e.target.value)}>{kinds.map((k) => <option key={k} value={k}>{t(`mt.rp_${k}` as Key)}</option>)}</select>
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('mt.from')} value={p.from} onChange={(e) => e.target.value && setP({ ...p, from: e.target.value })} />
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('mt.until')} value={p.to} min={p.from} onChange={(e) => e.target.value && setP({ ...p, to: e.target.value })} />
        <span style={{ flex: 1 }} />
        {['pdf', 'xlsx', 'csv'].map((f) => <button key={f} className="btn" onClick={() => window.open(`/api/maintenance/reports/${kind}?${qs}&format=${f}`, '_blank')}>{f === 'xlsx' ? 'Excel' : f.toUpperCase()}</button>)}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{r?.title ?? '…'}</h3>
        <table className="table">
          <thead><tr>{(r?.columns ?? []).map((c: any) => <th key={c.key} className={c.money ? 'num' : ''}>{c.label}</th>)}</tr></thead>
          <tbody>
            {r && !r.rows.length && <tr><td colSpan={r.columns.length} className="muted">{t('common.none')}</td></tr>}
            {(r?.rows ?? []).map((x: any, i: number) => <tr key={i}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : 'wrap'}>{fmt(c, x[c.key])}</td>)}</tr>)}
            {r?.total && r.rows.length > 0 && <tr style={{ fontWeight: 700, background: 'var(--surface2)' }}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : ''}>{r.total[c.key] !== undefined ? fmt(c, r.total[c.key]) : ''}</td>)}</tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function Settings() {
  const { t } = useI18n();
  const toast = useToast();
  const [s, setS] = useState<any>(null);
  useEffect(() => { get('/api/maintenance/settings').then(setS).catch(err(toast)); }, []);
  if (!s) return <span>{t('common.loading')}</span>;
  const save = async () => { try { setS(await api('PUT', '/api/maintenance/settings', s)); toast('success', t('mt.saved')); } catch (e: any) { toast('error', e.message); } };
  return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12, maxWidth: 720 }}>
      <h3 style={{ margin: 0 }}>{t('mt.slaTitle')}</h3>
      <div className="form-grid">
        {PRIOS.slice().reverse().map((p) => <Field key={p} label={`${t(`mt.p_${p}` as Key)} (h)`}><input type="number" min={1} className="input" value={s.sla_hours[p]} onChange={(e) => setS({ ...s, sla_hours: { ...s.sla_hours, [p]: Number(e.target.value) } })} /></Field>)}
      </div>
      <div className="form-grid">
        <Field label={t('mt.warrantyAlert')}><input type="number" min={0} max={365} className="input" value={s.warranty_alert_days} onChange={(e) => setS({ ...s, warranty_alert_days: Number(e.target.value) })} /></Field>
        <Field label={t('mt.defaultRate')}><input type="number" min={0} className="input" value={s.default_hourly_rate} onChange={(e) => setS({ ...s, default_hourly_rate: Number(e.target.value) })} /></Field>
        <Field label={t('mt.expenseCategory')}><input className="input" value={s.expense_category} onChange={(e) => setS({ ...s, expense_category: e.target.value })} /></Field>
      </div>
      <button className="btn primary" style={{ alignSelf: 'flex-start' }} onClick={save}>{t('common.save')}</button>
    </div>
  );
}


