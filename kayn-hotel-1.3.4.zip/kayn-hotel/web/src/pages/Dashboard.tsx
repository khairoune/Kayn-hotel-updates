import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BarChart } from '../components/Charts';
import { Page } from '../components/Layout';
import { ReservationPanel } from '../components/ReservationPanel';
import { CheckInWizard, CheckOutModal } from '../components/FrontDesk';
import { Icon } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { get } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, money } from '../lib/format';
import { useLive } from '../lib/useLive';

function Kpi({ label, value, hint, accent }: { label: string; value: string | number; hint?: string; accent?: string }) {
  return (
    <div className="card kpi" style={accent ? { borderTop: `3px solid ${accent}` } : undefined}>
      <span className="label">{label}</span>
      <span className="value">{value}</span>
      {hint && <span className="hint">{hint}</span>}
    </div>
  );
}

export function Dashboard() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const [panel, setPanel] = useState<number | null>(null);
  const [fo, setFo] = useState<null | { kind: 'in' | 'out'; rr: number }>(null);

  const load = useCallback(() => get('/api/dashboard').then(setD).catch((e) => toast('error', e.message)), []);
  useEffect(() => { load(); }, [load]);
  useLive(load, 60000);



  if (!d) return <Page>{t('common.loading')}</Page>;
  const m = (n: number) => money(n, locale);
  const f = d.finance;
  const occ = [...d.history.map((h: any) => ({ label: fmtDate(h.day, locale, { day: 'numeric', month: 'short' }), value: h.occupancy })),
    ...d.forecast.slice(1).map((h: any) => ({ label: fmtDate(h.day, locale, { day: 'numeric', month: 'short' }), value: h.occupancy, future: true }))];

  return (
    <Page>
      <div className="page-head">
        <div style={{ marginInlineEnd: 'auto' }}>
          <h1 className="page-title">{t('dash.title')}</h1>
          <div className="page-sub">{fmtDate(d.date, locale, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</div>
        </div>
        <Link className="btn" to="/planning"><Icon name="planning" size={16} /> {t('nav.planning')}</Link>
        <button className="btn icon" aria-label="Actualiser" onClick={load}>↻</button>
      </div>

      <div className="grid kpis">
        <Kpi label={t('dash.oos')} value={d.rooms.out_of_service} accent="#52525B" />
        <Kpi label={t('dash.arrivals')} value={`${d.movements.arrivals_done} / ${d.movements.arrivals}`} hint={t('dash.done')} accent="#F59E0B" />
        <Kpi label={t('dash.departures')} value={`${d.movements.departures_done} / ${d.movements.departures}`} hint={t('dash.done')} accent="#FDBA74" />
        <Kpi label={t('dash.newRes')} value={d.movements.reservations_today} />
        <Kpi label={`${t('dash.adr')} — ${t('dash.month')}`} value={m(d.kpi.adr_month)} />
        <Kpi label={`${t('dash.revpar')} — ${t('dash.month')}`} value={m(d.kpi.revpar_month)} />
      </div>

      {d.hr && d.hr.staff > 0 && (
        <Link to="/rh?tab=dashboard" className="grid kpis" style={{ textDecoration: 'none', color: 'inherit' }}>
          <Kpi label={t('rh.dashStaff')} value={`${d.hr.present} / ${d.hr.scheduled}`} hint={`${d.hr.staff} ${t('rh.kTotal').toLowerCase()}`} accent="#0E7490" />
          <Kpi label={t('rh.kAbsent')} value={d.hr.absent} accent="#B91C1C" />
          <Kpi label={t('rh.kLate')} value={d.hr.late} accent="#B45309" />
          <Kpi label={t('rh.dashLeave')} value={d.hr.on_leave} accent="#1E40AF" />
          <Kpi label={t('rh.dashPending')} value={d.hr.leave_pending} accent="#C9A227" />
          <Kpi label={t('rh.kContracts')} value={d.hr.contracts} accent="#52525B" />
        </Link>
      )}

      {d.maintenance && (
        <Link to="/maintenance?tab=dashboard" className="grid kpis" style={{ textDecoration: 'none', color: 'inherit' }}>
          <Kpi label={t('mt.dashOpen')} value={d.maintenance.open} hint={d.maintenance.late ? `${d.maintenance.late} ${t('mt.late')}` : undefined} accent="#7A1F2B" />
          <Kpi label={t('mt.kCritical')} value={d.maintenance.critical} accent="#B91C1C" />
          <Kpi label={t('mt.ts_waiting_parts')} value={d.maintenance.waiting_parts} accent="#C2410C" />
          <Kpi label={t('mt.kToValidate')} value={d.maintenance.to_validate} accent="#3730A3" />
          <Kpi label={t('mt.kBroken')} value={d.maintenance.broken} accent="#52525B" />
          <Kpi label={t('mt.dashPrevLate')} value={d.maintenance.preventive_late} accent="#C9A227" />
        </Link>
      )}

      {d.crm && (
        <Link to="/crm?tab=dashboard" className="grid kpis" style={{ textDecoration: 'none', color: 'inherit' }}>
          <Kpi label={t('crm.dashVipInHouse')} value={d.crm.vip_inhouse} accent="#7A1F2B" />
          <Kpi label={t('crm.dashVipArrivals')} value={d.crm.vip_arrivals} accent="#C9A227" />
          <Kpi label={t('crm.kComplaints')} value={d.crm.complaints} hint={d.crm.complaints_late ? `${d.crm.complaints_late} ${t('crm.late')}` : undefined} accent="#B91C1C" />
          <Kpi label={t('crm.kSatisfaction')} value={d.crm.satisfaction !== null && d.crm.satisfaction !== undefined ? `${d.crm.satisfaction} / 5` : '—'} accent="#15803D" />
          <Kpi label={t('crm.dashBirthdays')} value={d.crm.birthdays_today} accent="#DB2777" />
        </Link>
      )}

      {f && (
        <div className="grid kpis">
          <Kpi label={t('dash.revMonth')} value={m(f.revenue_month)} hint={f.prev_month ? `${t('dash.prevMonth')} : ${m(f.prev_month.revenue)}` : undefined} accent="#C9A227" />
          <Kpi label={t('dash.payMonth')} value={m(f.payments_month)} hint={f.prev_month ? `${t('dash.prevMonth')} : ${m(f.prev_month.payments)}` : undefined} />
          <Kpi label={t('dash.expMonth')} value={m(f.expenses_month)} hint={f.prev_month ? `${t('dash.prevMonth')} : ${m(f.prev_month.expenses)}` : undefined} />
          <Kpi label={t('dash.gapMonth')} value={m(f.revenue_month - f.expenses_month)} accent="#15803D" />
          <Kpi label={t('dash.receivables')} value={m(f.receivables)} hint={`${f.debtors} dossier(s)`} accent="#B91C1C" />
        </div>
      )}

      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))' }}>
        {f && (
          <div className="card">
            <h3>{t('dash.chartRevMonths')}</h3>
            <BarChart data={(f.months ?? []).map((x: any) => ({ label: fmtDate(`${x.month}-01`, locale, { month: 'short', year: '2-digit' }), value: x.revenue }))} format={m} />
          </div>
        )}
        <div className="card">
          <h3>{t('dash.chartOcc')}</h3>
          <BarChart data={occ} format={(n) => `${n} %`} color="#1E3A8A" />
        </div>
      </div>

      {f && f.months?.length > 0 && (
        <div className="card">
          <h3>{t('dash.monthTable')}</h3>
          <div className="table-wrap"><table className="table">
            <thead><tr><th>{t('dash.colMonth')}</th><th className="num">{t('dash.colRev')}</th><th className="num">{t('dash.colPay')}</th><th className="num">{t('dash.colExp')}</th><th className="num">{t('dash.colGap')}</th></tr></thead>
            <tbody>{[...f.months].reverse().map((x: any) => (
              <tr key={x.month}><td>{fmtDate(`${x.month}-01`, locale, { month: 'long', year: 'numeric' })}</td><td className="num">{m(x.revenue)}</td><td className="num">{m(x.payments)}</td><td className="num">{m(x.expenses)}</td><td className="num"><b style={{ color: x.revenue - x.expenses < 0 ? '#B91C1C' : undefined }}>{m(x.revenue - x.expenses)}</b></td></tr>
            ))}</tbody>
          </table></div>
        </div>
      )}

      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))' }}>
        <div className="card">
          <h3>{t('dash.alerts')}</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {d.alerts.length === 0 && <span className="muted">{t('dash.noAlert')}</span>}
            {d.alerts.map((a: any) => <div key={a.code} className={`alert ${a.level}`}>{a.message}</div>)}
          </div>
        </div>
        <div className="card">
          <h3>{t('dash.arrList')}</h3>
          <MoveList items={d.arrivals} onOpen={setPanel} action={(x) => ['pending', 'confirmed'].includes(x.status) && can('frontoffice.checkin')
            ? <button className="btn sm primary" onClick={() => setFo({ kind: 'in', rr: x.rr_id })}>{t('res.checkin')}</button>
            : <span className="pill" style={{ background: '#1E3A8A', color: '#fff' }}>{t(`st.${x.status}` as Key)}</span>} />
        </div>
        <div className="card">
          <h3>{t('dash.depList')}</h3>
          <MoveList items={d.departures} onOpen={setPanel} action={(x) => can('frontoffice.checkout')
            ? <button className="btn sm primary" onClick={() => setFo({ kind: 'out', rr: x.rr_id })}>{t('res.checkout')}</button> : null} />
        </div>
        {f && f.payment_methods.length > 0 && (
          <div className="card">
            <h3>{t('dash.methods')}</h3>
            {f.payment_methods.map((pm: any) => {
              const max = Math.max(...f.payment_methods.map((x: any) => x.amount));
              return (
                <div key={pm.method} style={{ marginBottom: 10 }}>
                  <div className="row between" style={{ fontSize: 13 }}><span>{t(`pm.${pm.method}` as Key)}</span><b>{m(pm.amount)}</b></div>
                  <div style={{ height: 8, borderRadius: 99, background: 'var(--soft)' }}><div style={{ height: 8, borderRadius: 99, width: `${(pm.amount / max) * 100}%`, background: '#7A1F2B' }} /></div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      {panel !== null && <ReservationPanel id={panel} onClose={() => setPanel(null)} onChanged={load} />}
      {fo?.kind === 'in' && <CheckInWizard rrId={fo.rr} onClose={() => setFo(null)} onDone={load} />}
      {fo?.kind === 'out' && <CheckOutModal rrId={fo.rr} onClose={() => setFo(null)} onDone={load} />}
    </Page>
  );
}

function MoveList({ items, onOpen, action }: { items: any[]; onOpen: (id: number) => void; action: (x: any) => React.ReactNode }) {
  const { t } = useI18n();
  if (!items.length) return <span className="muted">{t('common.none')}</span>;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {items.map((x) => (
        <div key={x.rr_id} className="row between" style={{ padding: '6px 0', borderBottom: '1px solid var(--soft)' }}>
          <button className="btn ghost sm" style={{ justifyContent: 'flex-start', flex: 1, minWidth: 0 }} onClick={() => onOpen(x.reservation_id)}>
            <b>{x.room}</b> <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{x.guest}</span>
          </button>
          {action(x)}
        </div>
      ))}
    </div>
  );
}
