import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CheckInWizard, CheckOutModal, ChargeModal, ExtendModal, printRegistration, RoomChangeModal } from '../components/FrontDesk';
import { Page } from '../components/Layout';
import { ReservationPanel } from '../components/ReservationPanel';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { get, patch, post } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, fmtDateTime, money, todayLocal } from '../lib/format';
import { useLive } from '../lib/useLive';
import { GuestProfile } from './Guests';

type Tab = 'inhouse' | 'arrivals' | 'departures' | 'reports' | 'services';
type Op = { kind: 'checkin' | 'checkout' | 'move' | 'extend' | 'charge' | 'walkin'; rr?: number; res?: number } | null;

const ST_STYLE: Record<string, React.CSSProperties> = {
  in_house: { background: '#DBEAFE', color: '#1E3A8A' }, arrived_today: { background: '#DCFCE7', color: '#166534' },
  departure_today: { background: '#FEF3C7', color: '#92400E' }, overdue: { background: '#FEE2E2', color: '#991B1B' },
};

export function FrontOffice() {
  const { t } = useI18n();
  const { can } = useAuth();
  const [sp, setSp] = useSearchParams();
  const tab = (sp.get('tab') as Tab) || 'inhouse';
  const setTab = (k: Tab) => setSp(k === 'inhouse' ? {} : { tab: k }, { replace: true });
  const [sum, setSum] = useState<any>(null);
  const [op, setOp] = useState<Op>(null);
  const [panel, setPanel] = useState<number | null>(null);
  const [guest, setGuest] = useState<number | null>(null);
  const [tick, setTick] = useState(0);
  const loadSum = useCallback(() => { get('/api/frontoffice/summary').then(setSum).catch(() => {}); setTick((x) => x + 1); }, []);
  useEffect(() => { loadSum(); }, [loadSum]);
  useLive(loadSum);
  const k = (label: Key, v: number | undefined, to?: Tab, tone?: string) => (
    <button className="card kpi fo-kpi" onClick={() => to && setTab(to)} style={tone && v ? { borderTop: `3px solid ${tone}` } : undefined}>
      <span className="label">{t(label)}</span><span className="value">{v ?? '—'}</span>
    </button>
  );
  const actions = { open: setOp, panel: setPanel, guest: setGuest };
  // ferme les menus « ⋯ » ouverts quand on clique ailleurs
  useEffect(() => {
    const h = (e: MouseEvent) => document.querySelectorAll('details.menu[open]').forEach((d) => { if (!d.contains(e.target as Node)) (d as HTMLDetailsElement).open = false; });
    document.addEventListener('click', h);
    return () => document.removeEventListener('click', h);
  }, []);
  return (
    <Page>
      <div className="page-head">
        <h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('fo.title')}</h1>
        {can('frontoffice.checkin') && can('reservations.create') && <button className="btn primary" onClick={() => setOp({ kind: 'walkin' })}><Icon name="plus" /> {t('fo.walkin')}</button>}
      </div>
      <div className="grid kpis">
        {k('fo.kInHouse', sum?.in_house, 'inhouse')}
        {k('fo.kGuests', sum?.guests, 'inhouse')}
        {k('fo.kArrivals', sum?.arrivals_pending, 'arrivals', '#D97706')}
        {k('fo.kDepartures', sum?.departures_pending, 'departures', '#D97706')}
        {k('fo.kOverdue', sum?.overdue, 'departures', '#B91C1C')}
        {k('fo.kBalance', sum?.balance_due, 'inhouse', '#B91C1C')}
        {k('fo.kReady', sum?.ready_rooms)}
      </div>
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>
        {(['inhouse', 'arrivals', 'departures', 'reports', 'services'] as Tab[]).map((x) => (
          <button key={x} className={tab === x ? 'on' : ''} onClick={() => setTab(x)}>{t(`fo.${x}` as Key)}</button>
        ))}
      </div>
      {tab === 'inhouse' && <InHouse tick={tick} a={actions} />}
      {tab === 'arrivals' && <Arrivals tick={tick} a={actions} />}
      {tab === 'departures' && <Departures tick={tick} a={actions} />}
      {tab === 'reports' && <Reports />}
      {tab === 'services' && <ServicesCatalog />}
      {op?.kind === 'checkin' && <CheckInWizard rrId={op.rr} onClose={() => setOp(null)} onDone={loadSum} />}
      {op?.kind === 'walkin' && <CheckInWizard onClose={() => setOp(null)} onDone={loadSum} />}
      {op?.kind === 'checkout' && <CheckOutModal rrId={op.rr!} onClose={() => setOp(null)} onDone={loadSum} />}
      {op?.kind === 'move' && <RoomChangeModal rrId={op.rr!} onClose={() => setOp(null)} onDone={loadSum} />}
      {op?.kind === 'extend' && <ExtendModal rrId={op.rr!} onClose={() => setOp(null)} onDone={loadSum} />}
      {op?.kind === 'charge' && <ChargeModal reservationId={op.res!} rrId={op.rr} onClose={() => setOp(null)} onDone={loadSum} />}
      {panel && <ReservationPanel id={panel} onClose={() => setPanel(null)} onChanged={loadSum} />}
      {guest && <GuestProfile id={guest} onClose={() => setGuest(null)} />}
    </Page>
  );
}

type Actions = { open: (o: Op) => void; panel: (id: number) => void; guest: (id: number) => void };

function RowActions({ x, a }: { x: any; a: Actions }) {
  const { t } = useI18n();
  const { can } = useAuth();
  return (
    <div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
      {can('frontoffice.checkout') && <button className="btn sm primary" onClick={() => a.open({ kind: 'checkout', rr: x.rr_id })}>{t('fo.checkout')}</button>}
      {can('frontoffice.charges') && <button className="btn sm" onClick={() => a.open({ kind: 'charge', rr: x.rr_id, res: x.reservation_id })} title={t('fo.charge')} aria-label={t('fo.charge')}>+</button>}
      <details className="menu">
        <summary className="btn sm ghost" aria-label="Plus d'actions">⋯</summary>
        <div className="menu-pop" onClick={(e) => { (e.currentTarget.closest('details') as HTMLDetailsElement).open = false; }}>
          {can('reservations.edit') && <button onClick={() => a.open({ kind: 'move', rr: x.rr_id })}>{t('fo.move')}</button>}
          {can('reservations.edit') && <button onClick={() => a.open({ kind: 'extend', rr: x.rr_id })}>{t('fo.extend')}</button>}
          <button onClick={() => printRegistration(x.rr_id)}>{t('fo.card')}</button>
          <button onClick={() => a.panel(x.reservation_id)}>{t('fo.file')}</button>
          {can('guests.view') && <button onClick={() => a.guest(x.guest_id)}>{t('fo.profile')}</button>}
        </div>
      </details>
    </div>
  );
}

// ===================================================== Main courante =====================================================
function InHouse({ tick, a }: { tick: number; a: Actions }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null);
  const [q, setQ] = useState('');
  const [st, setSt] = useState('');
  const [sort, setSort] = useState<{ k: string; d: 1 | -1 }>({ k: 'room_number', d: 1 });
  useEffect(() => { get('/api/frontoffice/in-house').then(setRows).catch((e) => toast('error', e.message)); }, [tick]);
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    const f = (rows ?? []).filter((x) => (!s || `${x.room_number} ${x.guest_name} ${x.code} ${x.phone ?? ''} ${x.group_name ?? ''} ${x.payer_name ?? ''}`.toLowerCase().includes(s))
      && (!st || (st === 'balance' ? x.balance > 0.005 : x.status === st)));
    const cmp = (u: any, v: any) => (sort.k === 'room_number' ? u.room_number.length - v.room_number.length || u.room_number.localeCompare(v.room_number) : typeof u[sort.k] === 'number' ? u[sort.k] - v[sort.k] : String(u[sort.k] ?? '').localeCompare(String(v[sort.k] ?? '')));
    return [...f].sort((u, v) => cmp(u, v) * sort.d);
  }, [rows, q, st, sort]);
  const th = (key: string, label: Key, num?: boolean) => (
    <th className={num ? 'num' : ''} aria-sort={sort.k === key ? (sort.d === 1 ? 'ascending' : 'descending') : 'none'}>
      <button className="th-sort" onClick={() => setSort({ k: key, d: sort.k === key ? (-sort.d as 1 | -1) : 1 })}>{t(label)}{sort.k === key ? (sort.d === 1 ? ' ▲' : ' ▼') : ''}</button>
    </th>
  );
  const count = (fn: (x: any) => boolean) => (rows ?? []).filter(fn).length;
  return (
    <>
      <div className="row">
        <input className="input" style={{ maxWidth: 300 }} placeholder={t('common.search')} aria-label={t('common.search')} value={q} onChange={(e) => setQ(e.target.value)} />
        <button className={`chip ${!st ? 'on' : ''}`} onClick={() => setSt('')}>{t('common.all')} <b>{rows?.length ?? 0}</b></button>
        {['arrived_today', 'departure_today', 'overdue'].map((s) => (
          <button key={s} className={`chip ${st === s ? 'on' : ''}`} onClick={() => setSt(st === s ? '' : s)}><span className="sw" style={{ background: (ST_STYLE[s].color as string) }} />{t(`fo.s.${s}` as Key)} <b>{count((x) => x.status === s)}</b></button>
        ))}
        <button className={`chip ${st === 'balance' ? 'on' : ''}`} onClick={() => setSt(st === 'balance' ? '' : 'balance')}>{t('fo.fBalance')} <b>{count((x) => x.balance > 0.005)}</b></button>
        <span style={{ flex: 1 }} />
        <button className="btn sm" onClick={() => window.open(`/api/frontoffice/reports/in_house/xlsx`, '_blank')}>{t('rp.excel')}</button>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead>
            <tr>
              {th('room_number', 'fo.room')}{th('guest_name', 'fo.guest')}{th('code', 'fo.code')}{th('arrival', 'fo.arrival')}{th('check_out', 'fo.departure')}
              {th('nights', 'fo.nights', true)}{th('persons', 'fo.persons', true)}{th('total', 'fo.amount', true)}{th('paid', 'fo.paid', true)}{th('balance', 'fo.balance', true)}{th('status', 'fo.status')}<th className="pin-end" />
            </tr>
          </thead>
          <tbody>
            {!rows ? <tr><td colSpan={12}>{t('common.loading')}</td></tr> : !list.length ? <tr><td colSpan={12} className="muted">{t('common.none')}</td></tr> : list.map((x) => (
              <tr key={x.rr_id}>
                <td><b>{x.room_number}</b></td>
                <td><button className="link" onClick={() => a.guest(x.guest_id)}>{x.vip ? '★ ' : ''}{x.guest_name}</button>{(x.group_name || x.payer_name) && <div className="muted" style={{ fontSize: 12 }}>{x.group_name ?? x.payer_name}{x.room_count > 1 ? ` · ${x.room_count} ch.` : ''}</div>}</td>
                <td><button className="link" onClick={() => a.panel(x.reservation_id)}>{x.code}</button></td>
                <td>{fmtDate(x.arrival, locale, { day: 'numeric', month: 'short' })}</td>
                <td>{fmtDate(x.check_out, locale, { day: 'numeric', month: 'short' })}</td>
                <td className="num">{x.nights}</td>
                <td className="num">{x.persons}{x.companions ? <span className="muted" title="accompagnants enregistrés"> ({x.companions + 1})</span> : null}</td>
                <td className="num">{money(x.total, locale)}</td>
                <td className="num">{money(x.paid, locale)}</td>
                <td className="num" style={{ color: x.balance > 0.005 ? 'var(--danger)' : undefined, fontWeight: 600 }}>{money(x.balance, locale)}</td>
                <td><span className="pill" style={ST_STYLE[x.status]}>{t(`fo.s.${x.status}` as Key)}</span></td>
                <td className="pin-end"><RowActions x={x} a={a} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ===================================================== Arrivées / départs =====================================================
function Arrivals({ tick, a }: { tick: number; a: Actions }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const [r, setR] = useState<any>(null);
  const [date, setDate] = useState(todayLocal());
  useEffect(() => { get(`/api/frontoffice/reports/arrivals?from=${date}`).then(setR).catch(() => {}); }, [tick, date]);
  return (
    <>
      <div className="row"><input type="date" className="input" style={{ width: 170 }} aria-label={t('rp.date')} value={date} onChange={(e) => e.target.value && setDate(e.target.value)} /></div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('fo.room')}</th><th>{t('fo.guest')}</th><th>{t('fo.code')}</th><th>{t('res.departure')}</th><th className="num">{t('fo.persons')}</th><th className="num">{t('fo.balance')}</th><th>{t('fo.status')}</th><th /></tr></thead>
          <tbody>
            {!r ? <tr><td colSpan={8}>{t('common.loading')}</td></tr> : !r.rows.length ? <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr> : r.rows.map((x: any) => (
              <tr key={x.rr_id}>
                <td><b>{x.room_number}</b></td><td>{x.guest_name}</td><td><button className="link" onClick={() => a.panel(x.reservation_id)}>{x.code}</button></td>
                <td>{fmtDate(x.check_out, locale)}</td><td className="num">{x.persons}</td><td className="num">{money(x.balance, locale)}</td>
                <td><span className={`pill st-${x.status}`}>{x.status_label}</span></td>
                <td>{['pending', 'confirmed'].includes(x.status) && date === todayLocal() && can('frontoffice.checkin') && <button className="btn sm primary" onClick={() => a.open({ kind: 'checkin', rr: x.rr_id })}>{t('fo.checkin')}</button>}
                  {x.status === 'checked_in' && <button className="btn sm ghost" onClick={() => printRegistration(x.rr_id)}>{t('fo.card')}</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function Departures({ tick, a }: { tick: number; a: Actions }) {
  const { t, locale } = useI18n();
  const [ih, setIh] = useState<any[] | null>(null);
  const [done, setDone] = useState<any>(null);
  useEffect(() => {
    get('/api/frontoffice/in-house').then((r) => setIh(r.filter((x: any) => x.status === 'departure_today' || x.status === 'overdue'))).catch(() => {});
    get(`/api/frontoffice/reports/checkouts?from=${todayLocal()}`).then(setDone).catch(() => {});
  }, [tick]);
  return (
    <>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('fo.room')}</th><th>{t('fo.guest')}</th><th>{t('fo.code')}</th><th>{t('fo.departure')}</th><th className="num">{t('fo.balance')}</th><th>{t('fo.status')}</th><th /></tr></thead>
          <tbody>
            {!ih ? <tr><td colSpan={7}>{t('common.loading')}</td></tr> : !ih.length ? <tr><td colSpan={7} className="muted">{t('common.none')}</td></tr> : ih.map((x) => (
              <tr key={x.rr_id}>
                <td><b>{x.room_number}</b></td><td>{x.guest_name}</td><td><button className="link" onClick={() => a.panel(x.reservation_id)}>{x.code}</button></td>
                <td>{fmtDate(x.check_out, locale)}</td><td className="num" style={{ color: x.balance > 0.005 ? 'var(--danger)' : undefined }}>{money(x.balance, locale)}</td>
                <td><span className="pill" style={ST_STYLE[x.status]}>{t(`fo.s.${x.status}` as Key)}</span></td><td><RowActions x={x} a={a} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h3 style={{ margin: '4px 0 0', fontSize: 14 }}>Départs effectués aujourd'hui ({done?.rows.length ?? 0})</h3>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>Heure</th><th>{t('fo.room')}</th><th>{t('fo.guest')}</th><th>Facture</th><th className="num">{t('fo.balance')}</th><th>Par</th></tr></thead>
          <tbody>
            {(done?.rows ?? []).map((x: any, i: number) => (
              <tr key={i}><td>{fmtDateTime(x.done_at, locale)}</td><td><b>{x.room_number}</b></td><td>{x.guest_name}</td>
                <td>{x.invoice_id ? <button className="link" onClick={() => window.open(`/print/invoice/${x.invoice_id}`, '_blank')}>{x.invoice}</button> : '—'}</td>
                <td className="num">{money(x.balance, locale)}</td><td>{x.done_by}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ===================================================== Rapports =====================================================
function Reports() {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [kinds, setKinds] = useState<any[]>([]);
  const [kind, setKind] = useState('arrivals');
  const [from, setFrom] = useState(todayLocal());
  const [to, setTo] = useState(todayLocal());
  const [r, setR] = useState<any>(null);
  useEffect(() => { get('/api/frontoffice/reports').then(setKinds).catch(() => {}); }, []);
  const def = kinds.find((x) => x.kind === kind);
  const qs = `from=${from}${def?.range ? `&to=${to}` : ''}`;
  useEffect(() => { setR(null); get(`/api/frontoffice/reports/${kind}?${qs}`).then(setR).catch((e) => toast('error', e.message)); }, [kind, qs]);
  const fmt = (k: string, v: any) => {
    if (v === null || v === undefined || v === '') return '—';
    if (['balance', 'total', 'paid', 'base_rate'].includes(k)) return money(Number(v), locale);
    if (k === 'done_at') return fmtDateTime(v, locale);
    if (['check_in', 'check_out', 'arrival'].includes(k)) return fmtDate(v, locale);
    return String(v);
  };
  return (
    <>
      <div className="row no-print">
        <Field label={t('rp.kind')} htmlFor="rp-k">
          <select id="rp-k" className="input" value={kind} onChange={(e) => setKind(e.target.value)}>{kinds.map((x) => <option key={x.kind} value={x.kind}>{x.title}</option>)}</select>
        </Field>
        {def?.dated && <Field label={t('rp.date')} htmlFor="rp-f"><input id="rp-f" type="date" className="input" value={from} onChange={(e) => e.target.value && setFrom(e.target.value)} /></Field>}
        {def?.range && <Field label={t('rp.to')} htmlFor="rp-t"><input id="rp-t" type="date" className="input" min={from} value={to} onChange={(e) => e.target.value && setTo(e.target.value)} /></Field>}
        <span style={{ flex: 1 }} />
        <button className="btn" style={{ alignSelf: 'flex-end' }} onClick={() => window.print()}><Icon name="print" /> {t('common.print')}</button>
        <button className="btn" style={{ alignSelf: 'flex-end' }} onClick={() => window.open(`/api/frontoffice/reports/${kind}/xlsx?${qs}`, '_blank')}>{t('rp.excel')}</button>
      </div>
      <div className="card print-area" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{r?.title ?? '…'} <span className="muted" style={{ fontWeight: 500 }}>· {fmtDate(from, locale)}{def?.range && to !== from ? ` → ${fmtDate(to, locale)}` : ''} · {r?.rows.length ?? 0}</span></h3>
        <table className="table">
          <thead><tr>{(r?.columns ?? []).map((c: any) => <th key={c.key}>{c.label}</th>)}</tr></thead>
          <tbody>
            {r && !r.rows.length && <tr><td colSpan={r.columns.length} className="muted">{t('common.none')}</td></tr>}
            {(r?.rows ?? []).map((x: any, i: number) => <tr key={i}>{r.columns.map((c: any) => <td key={c.key} className={c.key === 'notes' ? 'wrap' : ''}>{fmt(c.key, x[c.key])}</td>)}</tr>)}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ===================================================== Catalogue des prestations =====================================================
const CATS = ['breakfast', 'restaurant', 'laundry', 'room_service', 'transfer', 'parking', 'minibar', 'other'];
const UNITS = ['unit', 'person', 'night', 'kg', 'trip', 'day'];
function ServicesCatalog() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [rows, setRows] = useState<any[]>([]);
  const [edit, setEdit] = useState<any | null | undefined>(undefined);
  const load = () => get('/api/services').then(setRows).catch((e) => toast('error', e.message));
  useEffect(() => { load(); }, []);
  const manage = can('services.manage');
  return (
    <>
      <div className="row between">
        <span className="muted" style={{ fontSize: 13 }}>Prix appliqués lors de l'ajout d'une prestation au séjour. La réception ne peut pas modifier un prix du catalogue.</span>
        {manage && <button className="btn primary" onClick={() => setEdit(null)}><Icon name="plus" /> {t('sv.new')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>Code</th><th>{t('ch.desc')}</th><th>{t('sv.category')}</th><th className="num">{t('ch.price')}</th><th>{t('sv.unit')}</th><th /></tr></thead>
          <tbody>
            {rows.map((s) => (
              <tr key={s.id} style={{ opacity: s.active ? 1 : 0.5 }}>
                <td><b>{s.code}</b></td><td>{s.name}</td><td>{t(`sv.c.${s.category}` as Key)}</td><td className="num">{money(s.price, locale)}</td><td>{t(`sv.u.${s.unit}` as Key)}</td>
                <td>{manage && <div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                  <button className="btn sm ghost" onClick={() => setEdit(s)}>{t('common.edit')}</button>
                  <button className="btn sm ghost" onClick={() => patch(`/api/services/${s.id}`, { active: !s.active }).then(load).catch((e) => toast('error', e.message))}>{s.active ? t('ty.deactivate') : t('ty.activate')}</button>
                </div>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {edit !== undefined && <ServiceForm s={edit} onClose={() => setEdit(undefined)} onSaved={() => { setEdit(undefined); load(); }} />}
    </>
  );
}
function ServiceForm({ s, onClose, onSaved }: { s: any | null; onClose: () => void; onSaved: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [f, setF] = useState(() => s ? { ...s, price: String(s.price) } : { code: '', name: '', category: 'other', price: '', unit: 'unit' });
  const save = async () => {
    const body = { code: f.code.trim(), name: f.name.trim(), category: f.category, price: Number(String(f.price).replace(',', '.')) || 0, unit: f.unit };
    try {
      if (s) await patch(`/api/services/${s.id}`, body); else await post('/api/services', body);
      toast('success', 'Prestation enregistrée.');
      onSaved();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={s ? `${t('common.edit')} ${s.name}` : t('sv.new')} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.code || f.name.length < 2} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label="Code" htmlFor="sv-c"><input id="sv-c" className="input" maxLength={12} value={f.code} onChange={(e) => setF({ ...f, code: e.target.value.toUpperCase() })} /></Field>
        <Field label={t('ch.desc')} htmlFor="sv-n"><input id="sv-n" className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label={t('sv.category')} htmlFor="sv-cat"><select id="sv-cat" className="input" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{CATS.map((c) => <option key={c} value={c}>{t(`sv.c.${c}` as Key)}</option>)}</select></Field>
        <Field label={`${t('ch.price')} (DA)`} htmlFor="sv-p"><input id="sv-p" className="input" inputMode="decimal" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} /></Field>
        <Field label={t('sv.unit')} htmlFor="sv-u"><select id="sv-u" className="input" value={f.unit} onChange={(e) => setF({ ...f, unit: e.target.value })}>{UNITS.map((u) => <option key={u} value={u}>{t(`sv.u.${u}` as Key)}</option>)}</select></Field>
      </div>
    </Modal>
  );
}
