import { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Page } from '../components/Layout';
import { ReasonModal } from '../components/ReservationPanel';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { api, get, newOpKey, patch, post, postOnce } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { addDays, fmtDate, fmtDateTime, money, todayLocal } from '../lib/format';
import { useLive } from '../lib/useLive';

type Tab = 'dashboard' | 'products' | 'warehouses' | 'movements' | 'purchases' | 'suppliers' | 'invoices' | 'inventories' | 'reports' | 'settings';
const VIEW = ['stock.view', 'stock.manage', 'restaurant.menu', 'purchase.request', 'purchase.order', 'purchase.pay', 'purchase.reports'];
const PO_COLORS: Record<string, [string, string]> = {
  draft: ['#F1F5F9', '#475569'], pending: ['#FEF3C7', '#92400E'], approved: ['#DBEAFE', '#1E40AF'], ordered: ['#E0E7FF', '#3730A3'], partial: ['#FFEDD5', '#9A3412'], received: ['#DCFCE7', '#166534'], cancelled: ['#FEE2E2', '#991B1B'],
};
const n3 = (v: any) => Math.round(Number(v ?? 0) * 1000) / 1000;
const toNum = (v: string | number) => Number(String(v ?? '').replace(',', '.').replace(/\s/g, '')) || 0;
const err = (toast: any) => (e: any) => toast('error', e.message);
const d10 = (v: any) => (v ? String(v).slice(0, 10) : '');

function PoPill({ s }: { s: string }) {
  const { t } = useI18n();
  const [bg, fg] = PO_COLORS[s] ?? PO_COLORS.draft;
  return <span className="pill" style={{ background: bg, color: fg }}>{t(`sk.po_${s}` as Key)}</span>;
}
function useMeta() {
  const [m, setM] = useState<any>(null);
  useEffect(() => { get('/api/stock/meta').then(setM).catch(() => {}); }, []);
  return m;
}

export function Stock() {
  const { t } = useI18n();
  const { can } = useAuth();
  const [sp, setSp] = useSearchParams();
  const any = (ps: string[]) => ps.some((p) => can(p));
  const tabs = ([['dashboard', VIEW], ['products', VIEW], ['warehouses', VIEW], ['movements', VIEW], ['purchases', ['purchase.request', 'purchase.approve', 'purchase.order', 'purchase.receive', 'purchase.pay', 'purchase.reports']],
    ['suppliers', [...VIEW, 'suppliers.manage']], ['invoices', ['purchase.pay', 'purchase.reports']], ['inventories', ['stock.view', 'stock.inventory']], ['reports', ['stock.view', 'purchase.reports']], ['settings', ['stock.manage']]] as [Tab, string[]][])
    .filter(([, ps]) => any(ps)).map(([k]) => k);
  const tab = tabs.includes(sp.get('tab') as Tab) ? (sp.get('tab') as Tab) : tabs[0];
  const go = (k: Tab) => setSp({ tab: k }, { replace: true });
  return (
    <Page>
      <div className="page-head"><h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('sk.title')}</h1></div>
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>
        {tabs.map((k) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => go(k)}>{t(`sk.t_${k}` as Key)}</button>)}
      </div>
      {tab === 'dashboard' && <Dash go={go} />}
      {tab === 'products' && <Products />}
      {tab === 'warehouses' && <Warehouses />}
      {tab === 'movements' && <Movements />}
      {tab === 'purchases' && <Purchases />}
      {tab === 'suppliers' && <Suppliers />}
      {tab === 'invoices' && <Invoices />}
      {tab === 'inventories' && <Inventories />}
      {tab === 'reports' && <Reports />}
      {tab === 'settings' && <Settings />}
    </Page>
  );
}

// ===================================================== Tableau de bord =====================================================
function Dash({ go }: { go: (t: Tab) => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const load = useCallback(() => { get('/api/stock/dashboard').then(setD).catch(err(toast)); }, []);
  useEffect(load, [load]);
  useLive(load, 30000);
  if (!d) return <span>{t('common.loading')}</span>;
  const k = d.kpi;
  const card = (label: string, v: any, color?: string, onClick?: () => void) => (
    <div className={`card kpi ${onClick ? 'clickable' : ''}`} style={{ borderInlineStart: color ? `4px solid ${color}` : undefined, cursor: onClick ? 'pointer' : undefined }} onClick={onClick}>
      <span className="label">{label}</span><span className="value" style={{ fontSize: typeof v === 'string' ? 20 : undefined }}>{v}</span>
    </div>
  );
  return (
    <>
      <div className="grid kpis">
        {card(t('sk.kValue'), money(k.value, locale))}
        {card(t('sk.kAvailable'), `${k.available} / ${k.products}`, '#15803D', () => go('products'))}
        {card(t('sk.kOut'), k.out_of_stock, '#B91C1C', () => go('products'))}
        {card(t('sk.kLow'), k.low, '#D97706', () => go('products'))}
        {card(t('sk.kExpiring'), k.expiring, '#7C3AED')}
        {card(t('sk.kToApprove'), k.to_approve, '#92400E', () => go('purchases'))}
        {card(t('sk.kToReceive'), `${k.to_receive}${k.late ? ` · ${k.late} ${t('sk.late')}` : ''}`, '#3730A3', () => go('purchases'))}
        {card(t('sk.kReceivedMonth'), money(k.received_month, locale))}
        {k.due !== null && card(t('sk.kDue'), money(k.due, locale), k.overdue > 0 ? '#B91C1C' : undefined, () => go('invoices'))}
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 14, alignItems: 'start' }}>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <h3 style={{ margin: 0 }}>{t('sk.alerts')} ({d.alerts.length})</h3>
          {!d.alerts.length && <span className="muted">{t('sk.noAlert')}</span>}
          {d.alerts.slice(0, 15).map((a: any, i: number) => <div key={i} className={`alert ${a.level === 'danger' ? '' : ''}`} style={{ padding: '6px 10px', fontSize: 13, borderColor: a.level === 'danger' ? 'var(--danger)' : undefined, color: a.level === 'danger' ? 'var(--danger)' : undefined }}>{a.message}</div>)}
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <h3 style={{ margin: 0 }}>{t('sk.valueByCategory')}</h3>
          {d.by_category.map((c: any) => <div key={c.category} className="sum-row"><span>{c.category}</span><b>{money(c.value, locale)}</b></div>)}
          <h3 style={{ margin: '8px 0 0' }}>{t('sk.topSuppliers')}</h3>
          {!d.by_supplier.length && <span className="muted">{t('common.none')}</span>}
          {d.by_supplier.map((c: any) => <div key={c.name} className="sum-row"><span>{c.name}</span><b>{money(c.value, locale)}</b></div>)}
        </div>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('sk.recentMoves')}</h3>
        <MoveTable rows={d.recent} />
      </div>
    </>
  );
}

function MoveTable({ rows }: { rows: any[] }) {
  const { t, locale } = useI18n();
  return (
    <table className="table">
      <thead><tr><th>{t('sk.date')}</th><th>{t('sk.product')}</th><th>{t('sk.type')}</th><th>{t('sk.warehouse')}</th><th>{t('sk.department')}</th><th className="num">{t('sk.qty')}</th><th>{t('sk.reason')}</th><th>{t('sk.user')}</th></tr></thead>
      <tbody>
        {!rows.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
        {rows.map((m) => (
          <tr key={m.id}>
            <td>{fmtDateTime(m.created_at, locale)}</td><td>{m.product ?? m.name}{m.lot_no ? <span className="muted"> · lot {m.lot_no}</span> : null}</td>
            <td>{t(`sk.k_${m.kind}` as Key)}{m.forced ? <span className="pill prio-urgent" style={{ marginInlineStart: 4 }}>{t('sk.forced')}</span> : null}{m.order_number ? <span className="muted"> · {m.order_number}</span> : null}</td>
            <td>{m.warehouse ?? ''}</td><td>{m.department ? t(`sk.d_${m.department}` as Key) : ''}</td>
            <td className="num" style={{ color: Number(m.quantity) < 0 ? 'var(--danger)' : '#15803D', fontWeight: 600 }}>{Number(m.quantity) > 0 ? '+' : ''}{n3(m.quantity)} {m.unit ?? ''}</td>
            <td className="wrap" style={{ fontSize: 12.5 }}>{m.reason ?? ''}</td><td>{m.user_name ?? ''}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// ===================================================== Produits =====================================================
function Products() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const meta = useMeta();
  const [f, setF] = useState({ search: '', category: '', state: '', archived: false });
  const [rows, setRows] = useState<any[] | null>(null);
  const [edit, setEdit] = useState<any>(null);
  const [card, setCard] = useState<number | null>(null);
  const [move, setMove] = useState<any>(null);
  const load = useCallback(() => {
    const qs = new URLSearchParams({ search: f.search });
    if (f.archived) qs.set('archived', '1');
    get(`/api/stock/products?${qs}`).then(setRows).catch(err(toast));
  }, [f.search, f.archived]);
  useEffect(() => { const h = setTimeout(load, 200); return () => clearTimeout(h); }, [load]);
  useLive(load);
  const state = (p: any) => (Number(p.stock_qty) <= 0 ? 'out' : p.low ? 'low' : p.max_stock !== null && Number(p.stock_qty) > Number(p.max_stock) ? 'over' : 'ok');
  const list = (rows ?? []).filter((p) => (!f.category || p.category === f.category) && (!f.state || state(p) === f.state));
  const SC: Record<string, string> = { out: '#B91C1C', low: '#D97706', over: '#7C3AED', ok: '#15803D' };
  return (
    <>
      <div className="row">
        <input className="input" style={{ width: 230 }} placeholder={t('sk.searchPh')} aria-label={t('common.search')} value={f.search} onChange={(e) => setF({ ...f, search: e.target.value })} />
        <select className="input" style={{ width: 'auto' }} aria-label={t('sk.category')} value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}><option value="">{t('sk.allCategories')}</option>{(meta?.categories ?? []).map((c: string) => <option key={c}>{c}</option>)}</select>
        {['out', 'low', 'over'].map((s) => <button key={s} className={`chip ${f.state === s ? 'on' : ''}`} onClick={() => setF({ ...f, state: f.state === s ? '' : s })}><span className="sw" style={{ background: SC[s] }} />{t(`sk.st_${s}` as Key)} <b>{(rows ?? []).filter((p) => state(p) === s).length}</b></button>)}
        <label className="check" style={{ alignItems: 'center' }}><input type="checkbox" checked={f.archived} onChange={(e) => setF({ ...f, archived: e.target.checked })} />{t('sk.archived')}</label>
        <span style={{ flex: 1 }} />
        {can('stock.manage') && <button className="btn primary" onClick={() => setEdit({})}><Icon name="plus" />{t('sk.newProduct')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('sk.ref')}</th><th>{t('sk.product')}</th><th>{t('sk.category')}</th><th className="num">{t('sk.stock')}</th><th>{t('sk.byWarehouse')}</th><th className="num">Min / Max</th><th className="num">{t('sk.wac')}</th><th className="num">{t('sk.value')}</th><th>{t('sk.expiry')}</th><th /></tr></thead>
          <tbody>
            {rows && !list.length && <tr><td colSpan={10} className="muted">{t('common.none')}</td></tr>}
            {list.map((p) => (
              <tr key={p.id} style={{ opacity: p.active ? 1 : 0.55 }}>
                <td className="muted">{p.code ?? ''}</td>
                <td><button className="link" onClick={() => setCard(p.id)}><b>{p.name}</b></button>{p.track_lots ? <span className="pill" style={{ marginInlineStart: 6 }}>{t('sk.lots')}</span> : null}</td>
                <td>{p.category}</td>
                <td className="num"><span className="pill" style={{ background: SC[state(p)], color: '#fff' }}>{n3(p.stock_qty)} {p.unit}</span></td>
                <td style={{ fontSize: 12 }} className="muted">{p.levels.map((l: any) => `${l.warehouse} : ${n3(l.qty)}`).join(' · ')}</td>
                <td className="num muted">{n3(p.min_stock)}{p.max_stock !== null ? ` / ${n3(p.max_stock)}` : ''}</td>
                <td className="num">{money(Number(p.avg_cost), locale)}</td><td className="num">{money(Number(p.value), locale)}</td>
                <td style={{ fontSize: 12.5, color: p.next_expiry && d10(p.next_expiry) <= addDays(todayLocal(), 30) ? 'var(--danger)' : undefined }}>{p.next_expiry ? fmtDate(d10(p.next_expiry), locale) : ''}</td>
                <td className="pin-end"><div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                  {(can('stock.manage') || can('stock.issue')) && !p.archived_at && <button className="btn sm" onClick={() => setMove({ product: p })}>{t('sk.movement')}</button>}
                  {can('stock.manage') && <button className="btn sm ghost" onClick={() => setEdit(p)}>{t('sk.edit')}</button>}
                  {can('stock.manage') && <button className="btn sm ghost" onClick={async () => { try { await post(`/api/stock/products/${p.id}/archive`, { archived: !p.archived_at }); load(); } catch (e: any) { toast('error', e.message); } }}>{p.archived_at ? t('sk.restore') : t('sk.archive')}</button>}
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {edit && <ProductModal p={edit.id ? edit : null} meta={meta} onClose={() => setEdit(null)} onDone={() => { setEdit(null); load(); }} />}
      {card && <ProductCard id={card} onClose={() => setCard(null)} />}
      {move && <MoveModal preset={move} meta={meta} onClose={() => setMove(null)} onDone={() => { setMove(null); load(); }} />}
    </>
  );
}

function ProductModal({ p, meta, onClose, onDone }: { p: any; meta: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [linen, setLinen] = useState<any[]>([]);
  const [f, setF] = useState({ code: p?.code ?? '', name: p?.name ?? '', description: p?.description ?? '', category: p?.category ?? 'Alimentation', unit: p?.unit ?? 'pièce', barcode: p?.barcode ?? '',
    cost_price: String(p ? Number(p.cost_price) : ''), tax_rate: String(p ? Number(p.tax_rate) : 19), min_stock: String(p ? Number(p.min_stock) : ''), max_stock: p?.max_stock != null ? String(Number(p.max_stock)) : '',
    track_lots: !!p?.track_lots, default_warehouse_id: p?.default_warehouse_id ? String(p.default_warehouse_id) : '', linen_item_id: p?.linen_item_id ? String(p.linen_item_id) : '', initial: '', lot_no: '', expiry_date: '' });
  useEffect(() => { get('/api/linen').then(setLinen).catch(() => {}); }, []);
  const save = async () => {
    try {
      const body: any = { code: f.code || null, name: f.name, description: f.description || null, category: f.category, unit: f.unit, barcode: f.barcode || null, cost_price: toNum(f.cost_price), tax_rate: toNum(f.tax_rate),
        min_stock: toNum(f.min_stock), max_stock: f.max_stock === '' ? null : toNum(f.max_stock), track_lots: f.track_lots, default_warehouse_id: f.default_warehouse_id ? Number(f.default_warehouse_id) : null, linen_item_id: f.linen_item_id ? Number(f.linen_item_id) : null };
      if (p) await patch(`/api/stock/products/${p.id}`, body);
      else await post('/api/stock/products', { ...body, initial: toNum(f.initial) || undefined, lot_no: f.lot_no || null, expiry_date: f.expiry_date || null });
      toast('success', t('sk.saved'));
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal size="lg" title={p ? `${t('sk.edit')} — ${p.name}` : t('sk.newProduct')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={f.name.trim().length < 2} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('sk.product')}><input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label={t('sk.ref')}><input className="input" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} /></Field>
        <Field label={t('sk.barcode')}><input className="input" value={f.barcode} onChange={(e) => setF({ ...f, barcode: e.target.value })} /></Field>
        <Field label={t('sk.category')}><input className="input" list="sk-cats" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} /><datalist id="sk-cats">{(meta?.categories ?? []).map((c: string) => <option key={c} value={c} />)}</datalist></Field>
        <Field label={t('sk.unit')}><input className="input" list="sk-units" value={f.unit} onChange={(e) => setF({ ...f, unit: e.target.value })} /><datalist id="sk-units">{(meta?.units ?? []).map((c: string) => <option key={c} value={c} />)}</datalist></Field>
        <Field label={t('sk.buyPrice')}><input className="input" inputMode="decimal" value={f.cost_price} onChange={(e) => setF({ ...f, cost_price: e.target.value })} /></Field>
        <Field label={t('sk.taxRate')}><input className="input" inputMode="decimal" value={f.tax_rate} onChange={(e) => setF({ ...f, tax_rate: e.target.value })} /></Field>
        <Field label={t('sk.minStock')}><input className="input" inputMode="decimal" value={f.min_stock} onChange={(e) => setF({ ...f, min_stock: e.target.value })} /></Field>
        <Field label={t('sk.maxStock')}><input className="input" inputMode="decimal" value={f.max_stock} onChange={(e) => setF({ ...f, max_stock: e.target.value })} /></Field>
        <Field label={t('sk.defaultWarehouse')}><select className="input" value={f.default_warehouse_id} onChange={(e) => setF({ ...f, default_warehouse_id: e.target.value })}><option value="">—</option>{(meta?.warehouses ?? []).filter((w: any) => w.active).map((w: any) => <option key={w.id} value={w.id}>{w.name}</option>)}</select></Field>
        <Field label={t('sk.linenLink')}><select className="input" value={f.linen_item_id} onChange={(e) => setF({ ...f, linen_item_id: e.target.value })}><option value="">—</option>{linen.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select></Field>
      </div>
      {p && <p className="muted" style={{ margin: 0, fontSize: 12.5 }}>{t('sk.wac')} : {Number(p.avg_cost)} · {t('sk.stock')} : {n3(p.stock_qty)} {p.unit}</p>}
      <Field label={t('sk.description')}><textarea className="input" rows={2} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
      <label className="check"><input type="checkbox" checked={f.track_lots} onChange={(e) => setF({ ...f, track_lots: e.target.checked })} />{t('sk.trackLots')}</label>
      {!p && (
        <div className="form-grid">
          <Field label={t('sk.initial')}><input className="input" inputMode="decimal" value={f.initial} onChange={(e) => setF({ ...f, initial: e.target.value })} /></Field>
          {f.track_lots && <Field label={t('sk.lot')}><input className="input" value={f.lot_no} onChange={(e) => setF({ ...f, lot_no: e.target.value })} /></Field>}
          {f.track_lots && <Field label={t('sk.expiry')}><input type="date" className="input" value={f.expiry_date} onChange={(e) => setF({ ...f, expiry_date: e.target.value })} /></Field>}
        </div>
      )}
    </Modal>
  );
}

function ProductCard({ id, onClose }: { id: number; onClose: () => void }) {
  const { t, locale } = useI18n();
  const [p, setP] = useState<any>(null);
  useEffect(() => { get(`/api/stock/products/${id}`).then(setP).catch(() => {}); }, [id]);
  if (!p) return null;
  return (
    <Modal size="lg" title={`${p.name}${p.code ? ` · ${p.code}` : ''}`} onClose={onClose}>
      <div className="kv">
        <div><span>{t('sk.stock')}</span><b>{n3(p.stock_qty)} {p.unit}</b></div><div><span>{t('sk.category')}</span><b>{p.category}</b></div>
        <div><span>{t('sk.wac')}</span><b>{money(Number(p.avg_cost), locale)}</b></div><div><span>{t('sk.lastPrice')}</span><b>{money(Number(p.cost_price), locale)}</b></div>
        <div><span>Min / Max</span><b>{n3(p.min_stock)} / {p.max_stock ?? '—'}</b></div><div><span>{t('sk.barcode')}</span><b>{p.barcode ?? '—'}</b></div>
      </div>
      {p.description && <p style={{ margin: 0 }}>{p.description}</p>}
      <div className="section"><h3>{t('sk.byWarehouse')}</h3>{p.levels.map((l: any) => <div key={l.warehouse_id} className="sum-row"><span>{l.warehouse}</span><b>{n3(l.qty)} {p.unit}</b></div>)}</div>
      {p.lots.length > 0 && <div className="section"><h3>{t('sk.lotsExpiry')}</h3>{p.lots.map((l: any) => <div key={l.id} className="sum-row"><span>{l.lot_no ?? '—'} · {l.warehouse}</span><b style={{ color: l.expiry_date && d10(l.expiry_date) < todayLocal() ? 'var(--danger)' : undefined }}>{n3(l.qty)} · {l.expiry_date ? fmtDate(d10(l.expiry_date), locale) : '—'}</b></div>)}</div>}
      {p.suppliers.length > 0 && <div className="section"><h3>{t('sk.suppliers')}</h3>{p.suppliers.map((s: any) => <div key={s.supplier_id} className="sum-row"><span>{s.name}{s.supplier_ref ? ` · ${s.supplier_ref}` : ''}</span><b>{s.last_price ? money(Number(s.last_price), locale) : '—'}</b></div>)}</div>}
      <div className="section" style={{ padding: 0, overflow: 'auto' }}><h3 style={{ padding: '12px 14px 0' }}>{t('sk.history')}</h3><MoveTable rows={p.movements.map((m: any) => ({ ...m, product: p.name, unit: p.unit }))} /></div>
    </Modal>
  );
}

/** Mouvement manuel : entrée, sortie (consommation, perte, casse, péremption, retour), transfert, ajustement. */
function MoveModal({ preset, meta, onClose, onDone }: { preset: { product?: any; type?: string }; meta: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const types = [can('stock.issue') && 'out', can('stock.manage') && 'in', can('stock.transfer') && 'transfer', can('stock.manage') && 'adjust'].filter(Boolean) as string[];
  const [products, setProducts] = useState<any[]>(preset.product ? [preset.product] : []);
  const [lots, setLots] = useState<any[]>([]);
  const [tickets, setTickets] = useState<any[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [key] = useState(() => newOpKey('mv'));
  const [f, setF] = useState({ type: preset.type && types.includes(preset.type) ? preset.type : types[0], product_id: preset.product ? String(preset.product.id) : '', warehouse_id: '', to_id: '', kind: 'issue', department: 'housekeeping',
    quantity: '', unit_cost: '', reason: '', lot_id: '', lot_no: '', expiry_date: '', ticket_id: '', supplier_id: '', force: false });
  useEffect(() => {
    if (!preset.product) get('/api/stock/products').then(setProducts).catch(() => {});
    if (can('stock.issue')) get('/api/stock/tickets').then(setTickets).catch(() => {});
    get('/api/suppliers').then(setSuppliers).catch(() => {});
  }, []);
  const p = products.find((x) => String(x.id) === f.product_id);
  useEffect(() => { if (p?.track_lots) get(`/api/stock/lots?product_id=${p.id}${f.warehouse_id ? `&warehouse_id=${f.warehouse_id}` : ''}`).then(setLots).catch(() => {}); else setLots([]); }, [f.product_id, f.warehouse_id]);
  const whs = (meta?.warehouses ?? []).filter((w: any) => w.active);
  const level = p?.levels?.find((l: any) => String(l.warehouse_id) === (f.warehouse_id || String(p?.default_warehouse_id)));
  const save = async () => {
    try {
      const pid = Number(f.product_id), wid = f.warehouse_id ? Number(f.warehouse_id) : null, q = toNum(f.quantity);
      let r: any;
      if (f.type === 'out') r = await postOnce('/api/stock/out', { product_id: pid, warehouse_id: wid, kind: f.kind, quantity: q, reason: f.reason || null, department: f.kind === 'issue' ? f.department : null,
        lot_id: f.lot_id ? Number(f.lot_id) : null, ticket_id: f.ticket_id ? Number(f.ticket_id) : null, supplier_id: f.supplier_id ? Number(f.supplier_id) : null, force: f.force || undefined }, key);
      else if (f.type === 'in') r = await postOnce('/api/stock/movements', { product_id: pid, warehouse_id: wid, kind: 'in', quantity: q, unit_cost: f.unit_cost ? toNum(f.unit_cost) : null, reason: f.reason || null, lot_no: f.lot_no || null, expiry_date: f.expiry_date || null }, key);
      else if (f.type === 'transfer') r = await postOnce('/api/stock/transfer', { product_id: pid, from_id: Number(f.warehouse_id || p?.default_warehouse_id), to_id: Number(f.to_id), quantity: q, reason: f.reason || null }, key);
      else r = await postOnce('/api/stock/movements', { product_id: pid, warehouse_id: wid, kind: 'adjust', quantity: q, reason: f.reason }, key);
      toast('success', t('sk.moveSaved'));
      if (r?.alert) toast('info', r.alert);
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  const valid = f.product_id && toNum(f.quantity) !== 0 && (f.type !== 'transfer' || f.to_id) && (f.type !== 'adjust' || f.reason.trim().length > 1) && (f.type !== 'out' || f.kind === 'issue' || f.reason.trim().length > 1);
  return (
    <Modal title={t('sk.movement')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!valid} onClick={save}>{t('common.save')}</button></>}>
      <div className="seg">{types.map((x) => <button key={x} className={f.type === x ? 'on' : ''} onClick={() => setF({ ...f, type: x })}>{t(`sk.m_${x}` as Key)}</button>)}</div>
      <div className="form-grid">
        <Field label={t('sk.product')}><select className="input" value={f.product_id} onChange={(e) => setF({ ...f, product_id: e.target.value, lot_id: '' })}><option value="">—</option>{products.filter((x) => !x.archived_at).map((x) => <option key={x.id} value={x.id}>{x.name} ({n3(x.stock_qty)} {x.unit})</option>)}</select></Field>
        <Field label={f.type === 'transfer' ? t('sk.from') : t('sk.warehouse')}><select className="input" value={f.warehouse_id} onChange={(e) => setF({ ...f, warehouse_id: e.target.value, lot_id: '' })}><option value="">{t('sk.defaultWh')}</option>{whs.map((w: any) => <option key={w.id} value={w.id}>{w.name}</option>)}</select></Field>
        {f.type === 'transfer' && <Field label={t('sk.to')}><select className="input" value={f.to_id} onChange={(e) => setF({ ...f, to_id: e.target.value })}><option value="">—</option>{whs.map((w: any) => <option key={w.id} value={w.id}>{w.name}</option>)}</select></Field>}
        {f.type === 'out' && <Field label={t('sk.type')}><select className="input" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}>{['issue', 'waste', 'damaged', 'expired', 'supplier_return'].map((k) => <option key={k} value={k}>{t(`sk.k_${k}` as Key)}</option>)}</select></Field>}
        {f.type === 'out' && f.kind === 'issue' && <Field label={t('sk.department')}><select className="input" value={f.department} onChange={(e) => setF({ ...f, department: e.target.value })}>{(meta?.departments ?? []).map((d: any) => <option key={d.code} value={d.code}>{t(`sk.d_${d.code}` as Key)}</option>)}</select></Field>}
        <Field label={f.type === 'adjust' ? t('sk.qtyAdjust') : `${t('sk.qty')}${p ? ` (${p.unit})` : ''}`}><input className="input" inputMode="decimal" value={f.quantity} onChange={(e) => setF({ ...f, quantity: e.target.value })} /></Field>
        {f.type === 'in' && <Field label={t('sk.unitCost')}><input className="input" inputMode="decimal" value={f.unit_cost} onChange={(e) => setF({ ...f, unit_cost: e.target.value })} /></Field>}
        {f.type === 'in' && p?.track_lots && <Field label={t('sk.lot')}><input className="input" value={f.lot_no} onChange={(e) => setF({ ...f, lot_no: e.target.value })} /></Field>}
        {f.type === 'in' && p?.track_lots && <Field label={t('sk.expiry')}><input type="date" className="input" value={f.expiry_date} onChange={(e) => setF({ ...f, expiry_date: e.target.value })} /></Field>}
        {f.type === 'out' && lots.length > 0 && <Field label={t('sk.lot')}><select className="input" value={f.lot_id} onChange={(e) => setF({ ...f, lot_id: e.target.value })}><option value="">{t('sk.fefo')}</option>{lots.map((l) => <option key={l.id} value={l.id}>{l.lot_no ?? '—'} · {n3(l.qty)} · {d10(l.expiry_date)}</option>)}</select></Field>}
        {f.type === 'out' && f.kind === 'issue' && f.department === 'maintenance' && <Field label={t('sk.ticket')}><select className="input" value={f.ticket_id} onChange={(e) => setF({ ...f, ticket_id: e.target.value })}><option value="">—</option>{tickets.map((x) => <option key={x.id} value={x.id}>#{x.id} {x.title}{x.room ? ` · ${x.room}` : ''}</option>)}</select></Field>}
        {f.type === 'out' && f.kind === 'supplier_return' && <Field label={t('sk.supplier')}><select className="input" value={f.supplier_id} onChange={(e) => setF({ ...f, supplier_id: e.target.value })}><option value="">—</option>{suppliers.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></Field>}
      </div>
      {p && f.type !== 'in' && <p className="muted" style={{ margin: 0, fontSize: 12.5 }}>{t('sk.available')} : {level ? n3(level.qty) : 0} {p.unit}</p>}
      <Field label={`${t('sk.reason')}${f.type === 'adjust' || (f.type === 'out' && f.kind !== 'issue') || f.force ? ' *' : ''}`}><input className="input" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} /></Field>
      {f.type === 'out' && can('stock.force') && <label className="check"><input type="checkbox" checked={f.force} onChange={(e) => setF({ ...f, force: e.target.checked })} />{t('sk.forceOut')}</label>}
    </Modal>
  );
}

// ===================================================== Entrepôts =====================================================
function Warehouses() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const meta = useMeta();
  const [rows, setRows] = useState<any[] | null>(null);
  const [sel, setSel] = useState<any>(null);
  const [stock, setStock] = useState<any[]>([]);
  const [edit, setEdit] = useState<any>(null);
  const [move, setMove] = useState<any>(null);
  const load = useCallback(() => { get('/api/warehouses').then(setRows).catch(err(toast)); }, []);
  useEffect(load, [load]);
  useEffect(() => { if (sel) get(`/api/stock/products?warehouse_id=${sel.id}`).then((r) => setStock(r.filter((p: any) => Number(p.wh_qty) !== 0))).catch(() => {}); }, [sel, rows]);
  const act = async (fn: () => Promise<any>) => { try { await fn(); load(); } catch (e: any) { toast('error', e.message); } };
  return (
    <>
      <div className="row"><span style={{ flex: 1 }} />
        {can('stock.transfer') && <button className="btn" onClick={() => setMove({ type: 'transfer' })}>⇄ {t('sk.transfer')}</button>}
        {can('stock.manage') && <button className="btn primary" onClick={() => setEdit({})}><Icon name="plus" />{t('sk.newWarehouse')}</button>}
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 12 }}>
        {(rows ?? []).map((w) => (
          <div key={w.id} className={`card ${sel?.id === w.id ? '' : ''}`} style={{ display: 'flex', flexDirection: 'column', gap: 6, opacity: w.active ? 1 : 0.55, borderColor: sel?.id === w.id ? 'var(--primary)' : undefined, cursor: 'pointer' }} onClick={() => setSel(w)}>
            <div className="row between"><b>{w.name}</b><span className="muted">{w.code}</span></div>
            <span className="muted" style={{ fontSize: 12.5 }}>{t(`sk.wk_${w.kind}` as Key)}{w.is_default ? ` · ${t('sk.default')}` : ''}</span>
            <div className="sum-row"><span>{t('sk.products')}</span><b>{w.products}</b></div>
            <div className="sum-row"><span>{t('sk.value')}</span><b>{money(Number(w.value), locale)}</b></div>
            {can('stock.manage') && <div className="row" style={{ gap: 4 }} onClick={(e) => e.stopPropagation()}>
              <button className="btn sm ghost" onClick={() => setEdit(w)}>{t('sk.edit')}</button>
              {!w.is_default && w.active && <button className="btn sm ghost" onClick={() => act(() => patch(`/api/warehouses/${w.id}`, { is_default: true }))}>{t('sk.makeDefault')}</button>}
              {!w.is_default && <button className="btn sm ghost" onClick={() => act(() => patch(`/api/warehouses/${w.id}`, { active: !w.active }))}>{w.active ? t('sk.archive') : t('sk.restore')}</button>}
            </div>}
          </div>
        ))}
      </div>
      {sel && (
        <div className="card" style={{ padding: 0, overflow: 'auto' }}>
          <h3 style={{ padding: '12px 14px 0' }}>{t('sk.stockOf')} {sel.name}</h3>
          <table className="table">
            <thead><tr><th>{t('sk.product')}</th><th>{t('sk.category')}</th><th className="num">{t('sk.qty')}</th><th className="num">{t('sk.value')}</th><th /></tr></thead>
            <tbody>
              {!stock.length && <tr><td colSpan={5} className="muted">{t('common.none')}</td></tr>}
              {stock.map((p) => <tr key={p.id}><td>{p.name}</td><td>{p.category}</td><td className="num">{n3(p.wh_qty)} {p.unit}</td><td className="num">{money(Number(p.wh_qty) * Number(p.avg_cost), locale)}</td>
                <td className="pin-end">{can('stock.transfer') && <button className="btn sm" onClick={() => setMove({ type: 'transfer', product: { ...p, default_warehouse_id: sel.id } })}>⇄</button>}</td></tr>)}
            </tbody>
          </table>
        </div>
      )}
      {edit && <WarehouseModal w={edit.id ? edit : null} onClose={() => setEdit(null)} onDone={() => { setEdit(null); load(); }} />}
      {move && <MoveModal preset={move} meta={meta} onClose={() => setMove(null)} onDone={() => { setMove(null); load(); }} />}
    </>
  );
}
function WarehouseModal({ w, onClose, onDone }: { w: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [f, setF] = useState({ code: w?.code ?? '', name: w?.name ?? '', kind: w?.kind ?? 'store' });
  const save = async () => { try { if (w) await patch(`/api/warehouses/${w.id}`, { name: f.name, kind: f.kind }); else await post('/api/warehouses', f); onDone(); } catch (e: any) { toast('error', e.message); } };
  return (
    <Modal size="sm" title={w ? w.name : t('sk.newWarehouse')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.code || f.name.length < 2} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label="Code"><input className="input" disabled={!!w} value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} /></Field>
        <Field label={t('sk.name')}><input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label={t('sk.type')}><select className="input" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}>{['store', 'reserve', 'kitchen', 'bar', 'housekeeping', 'maintenance', 'other'].map((k) => <option key={k} value={k}>{t(`sk.wk_${k}` as Key)}</option>)}</select></Field>
      </div>
    </Modal>
  );
}

// ===================================================== Mouvements =====================================================
function Movements() {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const meta = useMeta();
  const [f, setF] = useState({ from: addDays(todayLocal(), -6), to: todayLocal(), kind: '', warehouse_id: '', department: '' });
  const [rows, setRows] = useState<any[] | null>(null);
  const [move, setMove] = useState<any>(null);
  const load = useCallback(() => {
    const qs = new URLSearchParams({ from: f.from, to: f.to });
    if (f.kind) qs.set('kind', f.kind);
    if (f.warehouse_id) qs.set('warehouse_id', f.warehouse_id);
    if (f.department) qs.set('department', f.department);
    get(`/api/stock/movements?${qs}`).then(setRows).catch(err(toast));
  }, [f]);
  useEffect(load, [load]);
  useLive(load);
  return (
    <>
      <div className="row">
        {can('stock.manage') && <button className="btn" onClick={() => setMove({ type: 'in' })}>＋ {t('sk.m_in')}</button>}
        {can('stock.issue') && <button className="btn" onClick={() => setMove({ type: 'out' })}>− {t('sk.m_out')}</button>}
        {can('stock.transfer') && <button className="btn" onClick={() => setMove({ type: 'transfer' })}>⇄ {t('sk.m_transfer')}</button>}
        {can('stock.manage') && <button className="btn" onClick={() => setMove({ type: 'adjust' })}>± {t('sk.m_adjust')}</button>}
      </div>
      <div className="row">
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('sk.from')} value={f.from} onChange={(e) => e.target.value && setF({ ...f, from: e.target.value })} />
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('sk.to')} value={f.to} min={f.from} onChange={(e) => e.target.value && setF({ ...f, to: e.target.value })} />
        <select className="input" style={{ width: 'auto' }} aria-label={t('sk.type')} value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}><option value="">{t('sk.allTypes')}</option>{Object.keys(meta?.kinds ?? {}).map((k) => <option key={k} value={k}>{t(`sk.k_${k}` as Key)}</option>)}</select>
        <select className="input" style={{ width: 'auto' }} aria-label={t('sk.warehouse')} value={f.warehouse_id} onChange={(e) => setF({ ...f, warehouse_id: e.target.value })}><option value="">{t('sk.allWarehouses')}</option>{(meta?.warehouses ?? []).map((w: any) => <option key={w.id} value={w.id}>{w.name}</option>)}</select>
        <select className="input" style={{ width: 'auto' }} aria-label={t('sk.department')} value={f.department} onChange={(e) => setF({ ...f, department: e.target.value })}><option value="">{t('sk.allDepartments')}</option>{(meta?.departments ?? []).map((d: any) => <option key={d.code} value={d.code}>{t(`sk.d_${d.code}` as Key)}</option>)}</select>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>{rows ? <MoveTable rows={rows} /> : t('common.loading')}</div>
      {move && <MoveModal preset={move} meta={meta} onClose={() => setMove(null)} onDone={() => { setMove(null); load(); }} />}
    </>
  );
}

// ===================================================== Achats =====================================================
function Purchases() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [rows, setRows] = useState<any[] | null>(null);
  const [open, setOpen] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const load = useCallback(() => {
    const qs = new URLSearchParams({ search });
    if (status) qs.set('status', status);
    get(`/api/purchases?${qs}`).then(setRows).catch(err(toast));
  }, [status, search]);
  useEffect(() => { const h = setTimeout(load, 200); return () => clearTimeout(h); }, [load]);
  useLive(load);
  return (
    <>
      <div className="row">
        <button className={`chip ${!status ? 'on' : ''}`} onClick={() => setStatus('')}>{t('common.all')}</button>
        {['draft', 'pending', 'approved', 'ordered', 'partial', 'received', 'cancelled'].map((s) => <button key={s} className={`chip ${status === s ? 'on' : ''}`} onClick={() => setStatus(status === s ? '' : s)}>{t(`sk.po_${s}` as Key)}</button>)}
        <input className="input" style={{ width: 200 }} placeholder={t('common.search')} aria-label={t('common.search')} value={search} onChange={(e) => setSearch(e.target.value)} />
        <span style={{ flex: 1 }} />
        {can('purchase.request') && <button className="btn primary" onClick={() => setCreating(true)}><Icon name="plus" />{t('sk.newRequest')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('sk.request')}</th><th>{t('sk.order')}</th><th>{t('sk.status')}</th><th>{t('sk.department')}</th><th>{t('sk.supplier')}</th><th className="num">{t('sk.lines')}</th><th className="num">TTC</th><th>{t('sk.expected')}</th><th>{t('sk.requestedBy')}</th></tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={9} className="muted">{t('common.none')}</td></tr>}
            {(rows ?? []).map((r) => (
              <tr key={r.id} style={{ cursor: 'pointer' }} onClick={() => setOpen(r.id)}>
                <td><b>{r.number}</b>{r.reason ? <div className="muted" style={{ fontSize: 12 }}>{r.reason}</div> : null}</td><td>{r.po_number ?? ''}</td><td><PoPill s={r.status} /></td>
                <td>{t(`sk.d_${r.department}` as Key)}</td><td>{r.supplier ?? '—'}</td><td className="num">{r.lines}</td><td className="num">{money(Number(r.total), locale)}</td>
                <td className={r.late ? 'late' : ''}>{r.expected_date ? fmtDate(d10(r.expected_date), locale) : ''}{r.late ? ` · ${t('sk.late')}` : ''}</td><td>{r.requested_by_name}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {creating && <RequestModal onClose={() => setCreating(false)} onDone={(id) => { setCreating(false); load(); setOpen(id); }} />}
      {open && <PurchaseModal id={open} onClose={() => { setOpen(null); load(); }} />}
    </>
  );
}

function RequestModal({ po, onClose, onDone }: { po?: any; onClose: () => void; onDone: (id: number) => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const meta = useMeta();
  const [products, setProducts] = useState<any[]>([]);
  const [key] = useState(() => newOpKey('po'));
  const [f, setF] = useState({ department: po?.department ?? 'other', warehouse_id: po?.warehouse_id ? String(po.warehouse_id) : '', needed_by: d10(po?.needed_by), reason: po?.reason ?? '', notes: po?.notes ?? '' });
  const [lines, setLines] = useState<any[]>(po ? po.lines.map((l: any) => ({ product_id: String(l.product_id), quantity: String(n3(l.quantity)), unit_price: String(Number(l.unit_price)) })) : [{ product_id: '', quantity: '', unit_price: '' }]);
  useEffect(() => { get('/api/stock/products').then(setProducts).catch(() => {}); }, []);
  const body = (submit: boolean) => ({ department: f.department, warehouse_id: f.warehouse_id ? Number(f.warehouse_id) : null, needed_by: f.needed_by || null, reason: f.reason || null, notes: f.notes || null, submit,
    lines: lines.filter((l) => l.product_id && toNum(l.quantity) > 0).map((l) => ({ product_id: Number(l.product_id), quantity: toNum(l.quantity), unit_price: l.unit_price === '' ? null : toNum(l.unit_price) })) });
  const save = async (submit: boolean) => {
    try {
      if (po) { const { submit: _s, ...b } = body(false); await patch(`/api/purchases/${po.id}`, b); if (submit) await post(`/api/purchases/${po.id}/submit`); onDone(po.id); }
      else { const r = await postOnce('/api/purchases', body(submit), key); onDone(r.id); }
      toast('success', submit ? t('sk.submitted') : t('sk.saved'));
    } catch (e: any) { toast('error', e.message); }
  };
  const valid = lines.some((l) => l.product_id && toNum(l.quantity) > 0);
  return (
    <Modal size="lg" title={po ? `${t('sk.edit')} — ${po.number}` : t('sk.newRequest')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button>
      {(!po || ['draft'].includes(po.status)) && <button className="btn" disabled={!valid} onClick={() => save(false)}>{t('sk.saveDraft')}</button>}
      <button className="btn primary" disabled={!valid} onClick={() => save(!po || po.status === 'draft')}>{!po || po.status === 'draft' ? t('sk.submit') : t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('sk.department')}><select className="input" value={f.department} onChange={(e) => setF({ ...f, department: e.target.value })}>{(meta?.departments ?? []).map((d: any) => <option key={d.code} value={d.code}>{t(`sk.d_${d.code}` as Key)}</option>)}</select></Field>
        <Field label={t('sk.deliverTo')}><select className="input" value={f.warehouse_id} onChange={(e) => setF({ ...f, warehouse_id: e.target.value })}><option value="">{t('sk.defaultWh')}</option>{(meta?.warehouses ?? []).filter((w: any) => w.active).map((w: any) => <option key={w.id} value={w.id}>{w.name}</option>)}</select></Field>
        <Field label={t('sk.neededBy')}><input type="date" className="input" min={todayLocal()} value={f.needed_by} onChange={(e) => setF({ ...f, needed_by: e.target.value })} /></Field>
      </div>
      <Field label={t('sk.reason')}><input className="input" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} placeholder={t('sk.reasonPh')} /></Field>
      <div className="section"><h3>{t('sk.items')}</h3>
        {lines.map((l, i) => {
          const p = products.find((x) => String(x.id) === l.product_id);
          return (
            <div key={i} className="row" style={{ gap: 6 }}>
              <select className="input" style={{ flex: 2, minWidth: 200 }} aria-label={t('sk.product')} value={l.product_id} onChange={(e) => { const x = products.find((y) => String(y.id) === e.target.value); setLines(lines.map((y, j) => (j === i ? { ...y, product_id: e.target.value, unit_price: x ? String(Number(x.cost_price)) : '' } : y))); }}>
                <option value="">—</option>{products.filter((x) => !x.archived_at).map((x) => <option key={x.id} value={x.id}>{x.name} · {n3(x.stock_qty)} {x.unit}{x.low ? ' ⚠' : ''}</option>)}
              </select>
              <input className="input" style={{ width: 100 }} inputMode="decimal" placeholder={t('sk.qty')} aria-label={t('sk.qty')} value={l.quantity} onChange={(e) => setLines(lines.map((y, j) => (j === i ? { ...y, quantity: e.target.value } : y)))} />
              <span className="muted" style={{ width: 60 }}>{p?.unit ?? ''}</span>
              <input className="input" style={{ width: 110 }} inputMode="decimal" placeholder={t('sk.estPrice')} aria-label={t('sk.estPrice')} value={l.unit_price} onChange={(e) => setLines(lines.map((y, j) => (j === i ? { ...y, unit_price: e.target.value } : y)))} />
              <button className="btn sm ghost danger" onClick={() => setLines(lines.filter((_, j) => j !== i))}>✕</button>
            </div>
          );
        })}
        <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setLines([...lines, { product_id: '', quantity: '', unit_price: '' }])}><Icon name="plus" />{t('sk.addLine')}</button>
        <button className="btn sm ghost" style={{ alignSelf: 'flex-start' }} onClick={() => {
          const low = products.filter((x) => x.low || Number(x.stock_qty) <= 0).filter((x) => !lines.some((l) => l.product_id === String(x.id)));
          setLines([...lines.filter((l) => l.product_id), ...low.map((x) => ({ product_id: String(x.id), quantity: String(Math.max(1, n3((Number(x.max_stock ?? 0) || Number(x.min_stock) * 2) - Number(x.stock_qty)))), unit_price: String(Number(x.cost_price)) }))]);
        }}>⚡ {t('sk.addLow')}</button>
      </div>
    </Modal>
  );
}

function PurchaseModal({ id, onClose }: { id: number; onClose: () => void }) {
  const { t, locale } = useI18n();
  const { can, me } = useAuth() as any;
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const [modal, setModal] = useState<'' | 'edit' | 'quote' | 'order' | 'receive' | 'reject' | 'cancel' | 'invoice'>('');
  const load = useCallback(() => { get(`/api/purchases/${id}`).then(setD).catch(err(toast)); }, [id]);
  useEffect(load, [load]);
  const act = async (fn: () => Promise<any>, ok?: string) => { try { const r = await fn(); if (ok) toast('success', ok); r?.alerts?.forEach((a: string) => toast('info', a)); load(); } catch (e: any) { toast('error', e.message); } };
  if (!d) return null;
  const steps = ['draft', 'pending', 'approved', 'ordered', 'received'];
  const cur = d.status === 'partial' ? 4 : steps.indexOf(d.status);
  const mine = d.requested_by === me?.id;
  return (
    <Modal size="lg" title={`${d.po_number ?? d.number} — ${t(`sk.d_${d.department}` as Key)}`} onClose={onClose}
      footer={<>
        {['draft', 'pending', 'approved', 'ordered'].includes(d.status) && (can('purchase.order') || can('purchase.approve') || (mine && ['draft', 'pending'].includes(d.status))) && <button className="btn ghost danger" onClick={() => setModal('cancel')}>{t('sk.cancelPo')}</button>}
        {d.status === 'partial' && can('purchase.order') && <button className="btn ghost danger" onClick={() => setModal('cancel')}>{t('sk.closeRemaining')}</button>}
        {(d.po_number || d.status === 'approved') && <button className="btn ghost" onClick={() => window.open(`/api/purchases/${id}/pdf`, '_blank')}><Icon name="print" />PDF</button>}
        <span style={{ flex: 1 }} />
        {d.status === 'draft' && (mine || can('purchase.approve')) && <button className="btn" onClick={() => setModal('edit')}>{t('sk.edit')}</button>}
        {d.status === 'draft' && (mine || can('purchase.approve')) && <button className="btn primary" onClick={() => act(() => post(`/api/purchases/${id}/submit`), t('sk.submitted'))}>{t('sk.submit')}</button>}
        {d.status === 'pending' && can('purchase.approve') && <><button className="btn danger" onClick={() => setModal('reject')}>{t('sk.reject')}</button><button className="btn primary" onClick={() => act(() => post(`/api/purchases/${id}/approve`, { decision: 'approve' }), t('sk.approved'))}>{t('sk.approve')}</button></>}
        {d.status === 'approved' && can('purchase.order') && <><button className="btn" onClick={() => setModal('quote')}>{t('sk.addQuote')}</button><button className="btn primary" onClick={() => setModal('order')}>{t('sk.placeOrder')}</button></>}
        {['ordered', 'partial'].includes(d.status) && can('purchase.receive') && <button className="btn primary" onClick={() => setModal('receive')}>{t('sk.receive')}</button>}
        {['partial', 'received'].includes(d.status) && can('purchase.pay') && <button className="btn" onClick={() => setModal('invoice')}>{t('sk.recordInvoice')}</button>}
      </>}>
      <div className="steps" style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {steps.map((s, i) => <span key={s} className="pill" style={d.status === 'cancelled' ? {} : i < cur ? { background: '#DCFCE7', color: '#166534' } : i === cur ? { background: 'var(--primary)', color: '#fff' } : {}}>{i + 1}. {t(`sk.po_${s === 'received' && d.status === 'partial' ? 'partial' : s}` as Key)}</span>)}
        {d.status === 'cancelled' && <PoPill s="cancelled" />}
      </div>
      {d.rejection_reason && d.status === 'draft' && <div className="alert">{t('sk.rejected')} : {d.rejection_reason}</div>}
      <div className="kv">
        <div><span>{t('sk.request')}</span><b>{d.number}</b></div><div><span>{t('sk.supplier')}</span><b>{d.supplier ?? '—'}</b></div>
        <div><span>{t('sk.deliverTo')}</span><b>{d.warehouse}</b></div><div><span>{t('sk.expected')}</span><b>{d.expected_date ? fmtDate(d10(d.expected_date), locale) : d.needed_by ? `${t('sk.neededBy')} ${fmtDate(d10(d.needed_by), locale)}` : '—'}</b></div>
        <div><span>{t('sk.requestedBy')}</span><b>{d.requested_by_name}</b></div><div><span>{t('sk.approvedBy')}</span><b>{d.approved_by_name ?? '—'}</b></div>
      </div>
      {d.reason && <p style={{ margin: 0 }}>📝 {d.reason}</p>}
      <table className="table">
        <thead><tr><th>{t('sk.product')}</th><th className="num">{t('sk.ordered')}</th><th className="num">{t('sk.received')}</th><th className="num">{t('sk.unitPrice')}</th><th className="num">TVA</th><th className="num">HT</th></tr></thead>
        <tbody>{d.lines.map((l: any) => <tr key={l.id}><td>{l.name}{l.track_lots ? <span className="pill" style={{ marginInlineStart: 4 }}>{t('sk.lots')}</span> : null}</td><td className="num">{n3(l.quantity)} {l.unit}</td>
          <td className="num" style={{ color: Number(l.received_qty) >= Number(l.quantity) ? '#15803D' : undefined }}>{n3(l.received_qty)}</td><td className="num">{money(Number(l.unit_price), locale)}</td><td className="num">{Number(l.tax_rate)} %</td>
          <td className="num">{money(Math.round(Number(l.unit_price) * Number(l.quantity) * 100) / 100, locale)}</td></tr>)}</tbody>
      </table>
      <div className="section" style={{ gap: 2 }}>
        <div className="sum-row"><span>HT</span><span>{money(Number(d.subtotal), locale)}</span></div><div className="sum-row"><span>TVA</span><span>{money(Number(d.tax_total), locale)}</span></div>
        <div className="sum-row big"><span>TTC</span><span>{money(Number(d.total), locale)}</span></div>
      </div>
      {d.quotes.quotes.length > 0 && (
        <div className="section" style={{ padding: 0, overflow: 'auto' }}><h3 style={{ padding: '12px 14px 0' }}>{t('sk.compare')}</h3>
          <table className="table">
            <thead><tr><th>{t('sk.product')}</th>{d.quotes.quotes.map((q: any) => <th key={q.id} className="num">{q.supplier}{q.selected ? ' ✓' : ''}{q.id === d.quotes.recommended ? ' ★' : ''}</th>)}</tr></thead>
            <tbody>
              {d.quotes.lines.map((l: any) => <tr key={l.line_id}><td>{l.product} × {l.quantity}</td>{l.offers.map((o: any, i: number) => <td key={i} className="num" style={o && o.available && o.unit_price === l.best ? { color: '#15803D', fontWeight: 700 } : {}}>{o ? (o.available ? money(o.unit_price, locale) : t('sk.notAvailable')) : '—'}</td>)}</tr>)}
              <tr style={{ fontWeight: 700 }}><td>TTC · {t('sk.delay')}</td>{d.quotes.quotes.map((q: any) => <td key={q.id} className="num">{money(q.total, locale)}{q.delivery_days != null ? ` · ${q.delivery_days} j` : ''}{!q.complete ? ' ⚠' : ''}</td>)}</tr>
              {d.status === 'approved' && can('purchase.order') && <tr><td /> {d.quotes.quotes.map((q: any) => <td key={q.id} className="num"><button className="btn sm" disabled={!q.complete || q.selected} onClick={() => act(() => post(`/api/purchases/${id}/select-quote`, { quote_id: q.id }), t('sk.quoteSelected'))}>{q.selected ? t('sk.selected') : t('sk.choose')}</button></td>)}</tr>}
            </tbody>
          </table>
          <p className="muted" style={{ fontSize: 12, padding: '0 14px 10px', margin: 0 }}>★ {t('sk.recommendedHint')}</p>
        </div>
      )}
      {d.receipts.length > 0 && <div className="section"><h3>{t('sk.receipts')}</h3>{d.receipts.map((r: any) => (
        <div key={r.id} style={{ fontSize: 13 }}><b>{r.number}</b> · {fmtDateTime(r.received_at, locale)} · {r.received_by_name} · {r.warehouse}{r.delivery_note ? ` · BL ${r.delivery_note}` : ''} · <b>{money(Number(r.value), locale)}</b>
          <div className="muted">{r.lines.map((l: any) => `${l.product} ${n3(l.quantity)}${Number(l.rejected) ? ` (${t('sk.rejectedQty')} ${n3(l.rejected)})` : ''}${l.lot ? ` lot ${l.lot}` : ''}${l.expiry ? ` ↦ ${d10(l.expiry)}` : ''}`).join(' · ')}</div></div>
      ))}</div>}
      {d.invoices.length > 0 && <div className="section"><h3>{t('sk.invoices')}</h3>{d.invoices.map((f: any) => <div key={f.id} className="sum-row"><span>{f.ref} · n° {f.number} · {t(`sk.inv_${f.status}` as Key)}</span><b>{money(Number(f.total), locale)}</b></div>)}</div>}
      {d.history.length > 0 && <details><summary className="muted" style={{ cursor: 'pointer' }}>{t('sk.history')} ({d.history.length})</summary>{d.history.map((h: any, i: number) => <div key={i} className="muted" style={{ fontSize: 12 }}>{fmtDateTime(h.created_at, locale)} · {h.user_name} · {h.action}</div>)}</details>}
      {modal === 'edit' && <RequestModal po={d} onClose={() => setModal('')} onDone={() => { setModal(''); load(); }} />}
      {modal === 'quote' && <QuoteModal po={d} onClose={() => setModal('')} onDone={() => { setModal(''); load(); }} />}
      {modal === 'order' && <OrderModal po={d} onClose={() => setModal('')} onDone={() => { setModal(''); load(); }} />}
      {modal === 'receive' && <ReceiveModal po={d} onClose={() => setModal('')} onDone={(r) => { setModal(''); r?.alerts?.forEach((a: string) => toast('info', a)); load(); }} />}
      {modal === 'invoice' && <InvoiceModal preset={{ supplier_id: d.supplier_id, po_id: d.id }} onClose={() => setModal('')} onDone={() => { setModal(''); load(); }} />}
      {modal === 'reject' && <ReasonModal title={t('sk.reject')} onClose={() => setModal('')} onSubmit={(reason) => { setModal(''); act(() => post(`/api/purchases/${id}/approve`, { decision: 'reject', reason })); }} />}
      {modal === 'cancel' && <ReasonModal title={d.status === 'partial' ? t('sk.closeRemaining') : t('sk.cancelPo')} onClose={() => setModal('')} onSubmit={(reason) => { setModal(''); act(() => post(`/api/purchases/${id}/cancel`, { reason })); }} />}
    </Modal>
  );
}

function QuoteModal({ po, onClose, onDone }: { po: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [sups, setSups] = useState<any[]>([]);
  const [f, setF] = useState({ supplier_id: '', reference: '', delivery_days: '', valid_until: '' });
  const [prices, setPrices] = useState<Record<number, { price: string; available: boolean }>>(Object.fromEntries(po.lines.map((l: any) => [l.id, { price: '', available: true }])));
  useEffect(() => { get('/api/suppliers').then((s) => setSups(s.filter((x: any) => x.active))).catch(() => {}); }, []);
  const save = async () => {
    try {
      await post(`/api/purchases/${po.id}/quotes`, { supplier_id: Number(f.supplier_id), reference: f.reference || null, delivery_days: f.delivery_days ? Number(f.delivery_days) : null, valid_until: f.valid_until || null,
        lines: po.lines.map((l: any) => ({ line_id: l.id, unit_price: toNum(prices[l.id].price), available: prices[l.id].available })) });
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={t('sk.addQuote')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.supplier_id} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('sk.supplier')}><select className="input" value={f.supplier_id} onChange={(e) => setF({ ...f, supplier_id: e.target.value })}><option value="">—</option>{sups.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
        <Field label={t('sk.quoteRef')}><input className="input" value={f.reference} onChange={(e) => setF({ ...f, reference: e.target.value })} /></Field>
        <Field label={t('sk.delayDays')}><input type="number" min={0} className="input" value={f.delivery_days} onChange={(e) => setF({ ...f, delivery_days: e.target.value })} /></Field>
        <Field label={t('sk.validUntil')}><input type="date" className="input" value={f.valid_until} onChange={(e) => setF({ ...f, valid_until: e.target.value })} /></Field>
      </div>
      {po.lines.map((l: any) => (
        <div key={l.id} className="ck">
          <span>{l.name} × {n3(l.quantity)} {l.unit}</span>
          <div className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
            <input className="input" style={{ width: 110 }} inputMode="decimal" aria-label={t('sk.unitPrice')} placeholder={t('sk.unitPrice')} disabled={!prices[l.id].available} value={prices[l.id].price} onChange={(e) => setPrices({ ...prices, [l.id]: { ...prices[l.id], price: e.target.value } })} />
            <label className="check" style={{ fontSize: 12.5 }}><input type="checkbox" checked={!prices[l.id].available} onChange={(e) => setPrices({ ...prices, [l.id]: { ...prices[l.id], available: !e.target.checked } })} />{t('sk.notAvailable')}</label>
          </div>
        </div>
      ))}
    </Modal>
  );
}

function OrderModal({ po, onClose, onDone }: { po: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [sups, setSups] = useState<any[]>([]);
  const [sup, setSup] = useState(po.supplier_id ? String(po.supplier_id) : '');
  const [date, setDate] = useState(d10(po.needed_by) || addDays(todayLocal(), 7));
  const [prices, setPrices] = useState<Record<number, string>>(Object.fromEntries(po.lines.map((l: any) => [l.id, String(Number(l.unit_price))])));
  useEffect(() => { get('/api/suppliers').then((s) => setSups(s.filter((x: any) => x.active))).catch(() => {}); }, []);
  const save = async () => {
    try {
      const changed = po.lines.some((l: any) => toNum(prices[l.id]) !== Number(l.unit_price)) || String(po.supplier_id ?? '') !== sup;
      if (changed) await patch(`/api/purchases/${po.id}`, { supplier_id: Number(sup), lines: po.lines.map((l: any) => ({ product_id: l.product_id, quantity: Number(l.quantity), unit_price: toNum(prices[l.id]), tax_rate: Number(l.tax_rate) })) });
      await post(`/api/purchases/${po.id}/order`, { expected_date: date });
      toast('success', t('sk.ordered_msg'));
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={t('sk.placeOrder')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!sup} onClick={save}>{t('sk.placeOrder')}</button></>}>
      <div className="form-grid">
        <Field label={t('sk.supplier')}><select className="input" value={sup} onChange={(e) => setSup(e.target.value)}><option value="">—</option>{sups.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
        <Field label={t('sk.expected')}><input type="date" className="input" min={todayLocal()} value={date} onChange={(e) => setDate(e.target.value)} /></Field>
      </div>
      {po.lines.map((l: any) => <div key={l.id} className="ck"><span>{l.name} × {n3(l.quantity)} {l.unit}</span><input className="input" style={{ width: 120 }} inputMode="decimal" aria-label={t('sk.unitPrice')} value={prices[l.id]} onChange={(e) => setPrices({ ...prices, [l.id]: e.target.value })} /></div>)}
    </Modal>
  );
}

function ReceiveModal({ po, onClose, onDone }: { po: any; onClose: () => void; onDone: (r: any) => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('rcv'));
  const [bl, setBl] = useState('');
  const [busy, setBusy] = useState(false);
  const [rows, setRows] = useState<Record<number, any>>(Object.fromEntries(po.lines.map((l: any) => [l.id, { quantity: String(n3(Number(l.quantity) - Number(l.received_qty))), rejected: '', lot_no: '', expiry_date: '' }])));
  const open = po.lines.filter((l: any) => Number(l.received_qty) < Number(l.quantity));
  const save = async () => {
    try {
      setBusy(true);
      const r = await postOnce(`/api/purchases/${po.id}/receive`, { delivery_note: bl || null, lines: open.map((l: any) => ({ po_line_id: l.id, quantity: toNum(rows[l.id].quantity), rejected_qty: toNum(rows[l.id].rejected) || 0, lot_no: rows[l.id].lot_no || null, expiry_date: rows[l.id].expiry_date || null })) }, key);
      toast('success', `${t('sk.received_msg')} ${r.receipt.number}`);
      onDone(r);
    } catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  return (
    <Modal size="lg" title={`${t('sk.receive')} — ${po.po_number}`} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={busy} onClick={save}>{t('sk.confirmReceipt')}</button></>}>
      <Field label={t('sk.deliveryNote')}><input className="input" value={bl} onChange={(e) => setBl(e.target.value)} /></Field>
      <table className="table">
        <thead><tr><th>{t('sk.product')}</th><th className="num">{t('sk.remaining')}</th><th>{t('sk.receivedNow')}</th><th>{t('sk.rejectedQty')}</th><th>{t('sk.lot')}</th><th>{t('sk.expiry')}</th></tr></thead>
        <tbody>{open.map((l: any) => {
          const r = rows[l.id], set = (k: string, v: string) => setRows({ ...rows, [l.id]: { ...r, [k]: v } });
          const over = toNum(r.quantity) > Number(l.quantity) - Number(l.received_qty);
          return (
            <tr key={l.id}><td>{l.name}</td><td className="num">{n3(Number(l.quantity) - Number(l.received_qty))} {l.unit}</td>
              <td><input className="input" style={{ width: 90, borderColor: over ? 'var(--danger)' : undefined }} inputMode="decimal" aria-label={t('sk.receivedNow')} value={r.quantity} onChange={(e) => set('quantity', e.target.value)} /></td>
              <td><input className="input" style={{ width: 80 }} inputMode="decimal" aria-label={t('sk.rejectedQty')} value={r.rejected} onChange={(e) => set('rejected', e.target.value)} /></td>
              <td>{l.track_lots ? <input className="input" style={{ width: 100 }} aria-label={t('sk.lot')} value={r.lot_no} onChange={(e) => set('lot_no', e.target.value)} /> : '—'}</td>
              <td>{l.track_lots ? <input type="date" className="input" aria-label={t('sk.expiry')} value={r.expiry_date} onChange={(e) => set('expiry_date', e.target.value)} /> : '—'}</td></tr>
          );
        })}</tbody>
      </table>
      <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>{t('sk.receiveHint')}</p>
    </Modal>
  );
}

// ===================================================== Fournisseurs =====================================================
function Suppliers() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null);
  const [edit, setEdit] = useState<any>(null);
  const [open, setOpen] = useState<number | null>(null);
  const [search, setSearch] = useState('');
  const load = useCallback(() => { get('/api/suppliers').then(setRows).catch(err(toast)); }, []);
  useEffect(load, [load]);
  const list = (rows ?? []).filter((s) => !search || `${s.name} ${s.code ?? ''} ${s.city ?? ''}`.toLowerCase().includes(search.toLowerCase()));
  return (
    <>
      <div className="row">
        <input className="input" style={{ width: 230 }} placeholder={t('common.search')} aria-label={t('common.search')} value={search} onChange={(e) => setSearch(e.target.value)} />
        <span style={{ flex: 1 }} />
        {can('suppliers.manage') && <button className="btn primary" onClick={() => setEdit({})}><Icon name="plus" />{t('sk.newSupplier')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('sk.supplier')}</th><th>{t('sk.contact')}</th><th>{t('sk.phone')}</th><th>NIF</th><th className="num">{t('sk.terms')}</th><th className="num">{t('sk.orders')}</th><th className="num">{t('sk.balance')}</th><th /></tr></thead>
          <tbody>
            {rows && !list.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
            {list.map((s) => (
              <tr key={s.id} style={{ opacity: s.active ? 1 : 0.55 }}>
                <td><button className="link" onClick={() => setOpen(s.id)}><b>{s.name}</b></button>{s.code ? <span className="muted"> · {s.code}</span> : null}{s.city ? <div className="muted" style={{ fontSize: 12 }}>{s.city}</div> : null}</td>
                <td>{s.contact_name ?? ''}{s.email ? <div className="muted" style={{ fontSize: 12 }}>{s.email}</div> : null}</td><td>{s.phone ?? s.mobile ?? ''}</td><td className="muted">{s.nif ?? ''}</td>
                <td className="num">{s.payment_terms} j</td><td className="num">{s.orders}</td>
                <td className="num" style={Number(s.overdue) > 0 ? { color: 'var(--danger)', fontWeight: 700 } : {}}>{money(Number(s.balance), locale)}</td>
                <td className="pin-end">{can('suppliers.manage') && <button className="btn sm ghost" onClick={() => setEdit(s)}>{t('sk.edit')}</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {edit && <SupplierModal s={edit.id ? edit : null} onClose={() => setEdit(null)} onDone={() => { setEdit(null); load(); }} />}
      {open && <SupplierCard id={open} onClose={() => setOpen(null)} />}
    </>
  );
}
function SupplierModal({ s, onClose, onDone }: { s: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const keys = ['name', 'code', 'contact_name', 'phone', 'mobile', 'email', 'address', 'city', 'nif', 'nis', 'rc', 'ai', 'rib', 'notes'];
  const [f, setF] = useState<any>({ ...Object.fromEntries(keys.map((k) => [k, s?.[k] ?? ''])), payment_terms: s?.payment_terms ?? 30, active: s?.active ?? true });
  const save = async () => {
    try {
      const b = { ...Object.fromEntries(keys.map((k) => [k, f[k] || null])), payment_terms: Number(f.payment_terms), active: f.active, email: f.email || null };
      if (s) await patch(`/api/suppliers/${s.id}`, b); else await post('/api/suppliers', b);
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal size="lg" title={s ? s.name : t('sk.newSupplier')} onClose={onClose} footer={<>{s && <label className="check" style={{ marginInlineEnd: 'auto' }}><input type="checkbox" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} />{t('sk.active')}</label>}<button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={String(f.name).trim().length < 2} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        {keys.filter((k) => k !== 'notes').map((k) => <Field key={k} label={t(`sk.sf_${k}` as Key)}><input className="input" value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></Field>)}
        <Field label={t('sk.terms')}><input type="number" min={0} max={365} className="input" value={f.payment_terms} onChange={(e) => setF({ ...f, payment_terms: e.target.value })} /></Field>
      </div>
      <Field label={t('sk.notes')}><textarea className="input" rows={2} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field>
    </Modal>
  );
}
function SupplierCard({ id, onClose }: { id: number; onClose: () => void }) {
  const { t, locale } = useI18n();
  const [s, setS] = useState<any>(null);
  useEffect(() => { get(`/api/suppliers/${id}`).then(setS).catch(() => {}); }, [id]);
  if (!s) return null;
  return (
    <Modal size="lg" title={s.name} onClose={onClose}>
      <div className="kv">
        <div><span>{t('sk.contact')}</span><b>{s.contact_name ?? '—'}</b></div><div><span>{t('sk.phone')}</span><b>{[s.phone, s.mobile].filter(Boolean).join(' · ') || '—'}</b></div>
        <div><span>E-mail</span><b>{s.email ?? '—'}</b></div><div><span>{t('sk.sf_address')}</span><b>{[s.address, s.city].filter(Boolean).join(', ') || '—'}</b></div>
        <div><span>NIF / NIS / RC</span><b>{[s.nif, s.nis, s.rc].filter(Boolean).join(' · ') || '—'}</b></div><div><span>{t('sk.terms')}</span><b>{s.payment_terms} j</b></div>
      </div>
      <div className="grid kpis">
        <div className="card kpi"><span className="label">{t('sk.invoiced')}</span><span className="value" style={{ fontSize: 18 }}>{money(s.totals.invoiced, locale)}</span></div>
        <div className="card kpi"><span className="label">{t('sk.paid')}</span><span className="value" style={{ fontSize: 18 }}>{money(s.totals.paid, locale)}</span></div>
        <div className="card kpi"><span className="label">{t('sk.balance')}</span><span className="value" style={{ fontSize: 18, color: s.totals.balance > 0 ? 'var(--danger)' : undefined }}>{money(s.totals.balance, locale)}</span></div>
      </div>
      {s.products.length > 0 && <div className="section"><h3>{t('sk.suppliedProducts')}</h3>{s.products.map((p: any) => <div key={p.product_id} className="sum-row"><span>{p.name}</span><b>{p.last_price ? money(Number(p.last_price), locale) : '—'}</b></div>)}</div>}
      <div className="section"><h3>{t('sk.purchaseHistory')}</h3>{!s.orders.length && <span className="muted">{t('common.none')}</span>}
        {s.orders.map((o: any) => <div key={o.id} className="sum-row"><span>{o.po_number ?? o.number} · <PoPill s={o.status} /></span><b>{money(Number(o.total), locale)}</b></div>)}</div>
      <div className="section"><h3>{t('sk.invoices')}</h3>{!s.invoices.length && <span className="muted">{t('common.none')}</span>}
        {s.invoices.map((f: any) => <div key={f.id} className="sum-row"><span>{fmtDate(d10(f.invoice_date), locale)} · n° {f.number} · {t(`sk.inv_${f.status}` as Key)}</span><b>{money(Number(f.total), locale)}{Number(f.paid) < Number(f.total) && f.status !== 'cancelled' ? <span style={{ color: 'var(--danger)' }}> · {money(Number(f.total) - Number(f.paid), locale)}</span> : null}</b></div>)}</div>
    </Modal>
  );
}

// ===================================================== Factures fournisseurs =====================================================
function Invoices() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [due, setDue] = useState(true);
  const [rows, setRows] = useState<any[] | null>(null);
  const [creating, setCreating] = useState(false);
  const [pay, setPay] = useState<any>(null);
  const [cancel, setCancel] = useState<any>(null);
  const load = useCallback(() => { get(`/api/supplier-invoices${due ? '?due=1' : ''}`).then(setRows).catch(err(toast)); }, [due]);
  useEffect(load, [load]);
  useLive(load);
  const total = (rows ?? []).filter((f) => ['unpaid', 'partial'].includes(f.status)).reduce((a, f) => a + Number(f.total) - Number(f.paid), 0);
  return (
    <>
      <div className="row">
        <div className="seg"><button className={due ? 'on' : ''} onClick={() => setDue(true)}>{t('sk.toPay')}</button><button className={!due ? 'on' : ''} onClick={() => setDue(false)}>{t('common.all')}</button></div>
        <span className="muted">{t('sk.totalDue')} : <b>{money(total, locale)}</b></span>
        <span style={{ flex: 1 }} />
        {can('purchase.pay') && <button className="btn primary" onClick={() => setCreating(true)}><Icon name="plus" />{t('sk.recordInvoice')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>Réf.</th><th>{t('sk.supplier')}</th><th>N°</th><th>{t('sk.order')}</th><th>{t('sk.date')}</th><th>{t('sk.dueDate')}</th><th className="num">TTC</th><th className="num">{t('sk.paid')}</th><th className="num">{t('sk.remaining')}</th><th>{t('sk.status')}</th><th /></tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={11} className="muted">{t('common.none')}</td></tr>}
            {(rows ?? []).map((f) => (
              <tr key={f.id}>
                <td className="muted">{f.ref}</td><td>{f.supplier}</td><td><b>{f.number}</b></td><td>{f.po_number ?? ''}</td><td>{fmtDate(d10(f.invoice_date), locale)}</td>
                <td className={f.overdue ? 'late' : ''}>{fmtDate(d10(f.due_date), locale)}</td><td className="num">{money(Number(f.total), locale)}</td><td className="num">{money(Number(f.paid), locale)}</td>
                <td className="num">{money(Number(f.total) - Number(f.paid), locale)}</td><td>{t(`sk.inv_${f.status}` as Key)}</td>
                <td className="pin-end"><div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                  {can('purchase.pay') && ['unpaid', 'partial'].includes(f.status) && <button className="btn sm primary" onClick={() => setPay(f)}>{t('sk.pay')}</button>}
                  {can('purchase.pay') && f.status === 'unpaid' && <button className="btn sm ghost danger" onClick={() => setCancel(f)}>✕</button>}
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {creating && <InvoiceModal onClose={() => setCreating(false)} onDone={() => { setCreating(false); load(); }} />}
      {pay && <PayModal inv={pay} onClose={() => setPay(null)} onDone={() => { setPay(null); load(); }} />}
      {cancel && <ReasonModal title={`${t('sk.cancelInvoice')} — ${cancel.number}`} onClose={() => setCancel(null)} onSubmit={async (reason) => { const c = cancel; setCancel(null); try { await post(`/api/supplier-invoices/${c.id}/cancel`, { reason }); load(); } catch (e: any) { toast('error', e.message); } }} />}
    </>
  );
}
function InvoiceModal({ preset, onClose, onDone }: { preset?: { supplier_id?: number; po_id?: number }; onClose: () => void; onDone: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [sups, setSups] = useState<any[]>([]);
  const [pos, setPos] = useState<any[]>([]);
  const [key] = useState(() => newOpKey('ff'));
  const [f, setF] = useState({ supplier_id: preset?.supplier_id ? String(preset.supplier_id) : '', po_id: preset?.po_id ? String(preset.po_id) : '', number: '', invoice_date: todayLocal(), due_date: '', subtotal: '', tax_total: '', stamp_duty: '', category: '', notes: '' });
  useEffect(() => { get('/api/suppliers').then(setSups).catch(() => {}); }, []);
  useEffect(() => { if (f.supplier_id) get(`/api/purchases?supplier_id=${f.supplier_id}`).then((r) => setPos(r.filter((x: any) => ['partial', 'received'].includes(x.status)))).catch(() => {}); }, [f.supplier_id]);
  useEffect(() => {
    const po = pos.find((x) => String(x.id) === f.po_id);
    if (po && !f.subtotal) get(`/api/purchases/${po.id}`).then((d) => {
      const ht = d.receipts.reduce((a: number, r: any) => a + r.lines.reduce((s: number, l: any) => s + Number(l.unit_cost) * Number(l.quantity), 0), 0);
      const tva = d.receipts.reduce((a: number, r: any) => a + r.lines.reduce((s: number, l: any) => { const pl = d.lines.find((x: any) => x.name === l.product); return s + Math.round(Number(l.unit_cost) * Number(l.quantity) * Number(pl?.tax_rate ?? 0)) / 100; }, 0), 0);
      setF((x) => ({ ...x, subtotal: String(Math.round(ht * 100) / 100), tax_total: String(Math.round(tva * 100) / 100) }));
    }).catch(() => {});
  }, [f.po_id, pos]);
  const total = toNum(f.subtotal) + toNum(f.tax_total) + toNum(f.stamp_duty);
  const save = async () => {
    try {
      const r = await postOnce('/api/supplier-invoices', { supplier_id: Number(f.supplier_id), po_id: f.po_id ? Number(f.po_id) : null, number: f.number, invoice_date: f.invoice_date, due_date: f.due_date || null,
        subtotal: toNum(f.subtotal), tax_total: toNum(f.tax_total), stamp_duty: toNum(f.stamp_duty), category: f.category || null, notes: f.notes || null }, key);
      r.warnings?.forEach((w: string) => toast('info', w));
      toast('success', `${t('sk.invoiceSaved')} ${r.ref}`);
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={t('sk.recordInvoice')} onClose={onClose} footer={<><span className="muted">TTC <b>{money(total, locale)}</b></span><span style={{ flex: 1 }} /><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.supplier_id || !f.number.trim() || !(total > 0)} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('sk.supplier')}><select className="input" value={f.supplier_id} onChange={(e) => setF({ ...f, supplier_id: e.target.value, po_id: '' })}><option value="">—</option>{sups.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
        <Field label={t('sk.order')}><select className="input" value={f.po_id} onChange={(e) => setF({ ...f, po_id: e.target.value, subtotal: '', tax_total: '' })}><option value="">—</option>{pos.map((p) => <option key={p.id} value={p.id}>{p.po_number} · {money(Number(p.total), locale)}</option>)}</select></Field>
        <Field label={t('sk.invoiceNumber')}><input className="input" value={f.number} onChange={(e) => setF({ ...f, number: e.target.value })} /></Field>
        <Field label={t('sk.date')}><input type="date" className="input" max={todayLocal()} value={f.invoice_date} onChange={(e) => setF({ ...f, invoice_date: e.target.value })} /></Field>
        <Field label={`${t('sk.dueDate')} (${t('sk.auto')})`}><input type="date" className="input" value={f.due_date} onChange={(e) => setF({ ...f, due_date: e.target.value })} /></Field>
        <Field label="HT"><input className="input" inputMode="decimal" value={f.subtotal} onChange={(e) => setF({ ...f, subtotal: e.target.value })} /></Field>
        <Field label="TVA"><input className="input" inputMode="decimal" value={f.tax_total} onChange={(e) => setF({ ...f, tax_total: e.target.value })} /></Field>
        <Field label={t('sk.stamp')}><input className="input" inputMode="decimal" value={f.stamp_duty} onChange={(e) => setF({ ...f, stamp_duty: e.target.value })} /></Field>
        <Field label={t('sk.expenseCategory')}><input className="input" placeholder="Achats fournisseurs" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} /></Field>
      </div>
      <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>{t('sk.invoiceHint')}</p>
    </Modal>
  );
}
function PayModal({ inv, onClose, onDone }: { inv: any; onClose: () => void; onDone: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('sp'));
  const due = Math.round((Number(inv.total) - Number(inv.paid)) * 100) / 100;
  const [f, setF] = useState({ amount: String(due), method: 'transfer', reference: '', paid_at: todayLocal() });
  const save = async () => {
    try { await postOnce(`/api/supplier-invoices/${inv.id}/pay`, { amount: toNum(f.amount), method: f.method, reference: f.reference || null, paid_at: f.paid_at }, key); toast('success', t('sk.paidMsg')); onDone(); }
    catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal size="sm" title={`${t('sk.pay')} — ${inv.supplier} n° ${inv.number}`} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!(toNum(f.amount) > 0)} onClick={save}>{t('common.confirm')}</button></>}>
      <p style={{ margin: 0 }}>{t('sk.remaining')} : <b>{money(due, locale)}</b></p>
      <div className="form-grid">
        <Field label={t('sk.amount')}><input className="input" inputMode="decimal" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} /></Field>
        <Field label={t('sk.method')}><select className="input" value={f.method} onChange={(e) => setF({ ...f, method: e.target.value })}>{['transfer', 'cheque', 'cash', 'card'].map((m) => <option key={m} value={m}>{t(`pm.${m}` as Key)}</option>)}</select></Field>
        <Field label={t('sk.reference')}><input className="input" value={f.reference} onChange={(e) => setF({ ...f, reference: e.target.value })} /></Field>
        <Field label={t('sk.date')}><input type="date" className="input" max={todayLocal()} value={f.paid_at} onChange={(e) => setF({ ...f, paid_at: e.target.value })} /></Field>
      </div>
      <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>{t('sk.payHint')}</p>
    </Modal>
  );
}

// ===================================================== Inventaires =====================================================
function Inventories() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null);
  const [open, setOpen] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const load = useCallback(() => { get('/api/inventories').then(setRows).catch(err(toast)); }, []);
  useEffect(load, [load]);
  return (
    <>
      <div className="row"><span style={{ flex: 1 }} />{can('stock.inventory') && <button className="btn primary" onClick={() => setCreating(true)}><Icon name="plus" />{t('sk.newInventory')}</button>}</div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>N°</th><th>{t('sk.scope')}</th><th>{t('sk.status')}</th><th className="num">{t('sk.progress')}</th><th className="num">{t('sk.gapValue')}</th><th>{t('sk.createdBy')}</th><th>{t('sk.validatedBy')}</th></tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={7} className="muted">{t('common.none')}</td></tr>}
            {(rows ?? []).map((i) => (
              <tr key={i.id} style={{ cursor: 'pointer' }} onClick={() => setOpen(i.id)}>
                <td><b>{i.number}</b><div className="muted" style={{ fontSize: 12 }}>{fmtDateTime(i.created_at, locale)}</div></td>
                <td>{t(`sk.sc_${i.scope}` as Key)}{i.warehouse ? ` · ${i.warehouse}` : ''}{i.category ? ` · ${i.category}` : ''}</td><td>{t(`sk.is_${i.status}` as Key)}</td>
                <td className="num">{i.counted} / {i.lines}</td><td className="num" style={{ color: Number(i.gap_value) < 0 ? 'var(--danger)' : undefined }}>{i.gap_value === null ? '' : money(Number(i.gap_value), locale)}</td>
                <td>{i.created_by_name}</td><td>{i.validated_by_name ?? ''}{i.validated_at ? ` · ${fmtDate(d10(i.validated_at), locale)}` : ''}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {creating && <NewInventoryModal onClose={() => setCreating(false)} onDone={(id) => { setCreating(false); load(); setOpen(id); }} />}
      {open && <InventoryModal id={open} onClose={() => { setOpen(null); load(); }} />}
    </>
  );
}
function NewInventoryModal({ onClose, onDone }: { onClose: () => void; onDone: (id: number) => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const meta = useMeta();
  const [f, setF] = useState({ scope: 'warehouse', warehouse_id: '', category: '' });
  return (
    <Modal size="sm" title={t('sk.newInventory')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={(f.scope === 'warehouse' && !f.warehouse_id) || (f.scope === 'category' && !f.category)} onClick={async () => {
      try { const r = await post('/api/inventories', { scope: f.scope, warehouse_id: f.warehouse_id ? Number(f.warehouse_id) : null, category: f.category || null }); onDone(r.id); } catch (e: any) { toast('error', e.message); }
    }}>{t('sk.start')}</button></>}>
      <div className="seg">{['full', 'warehouse', 'category'].map((s) => <button key={s} className={f.scope === s ? 'on' : ''} onClick={() => setF({ ...f, scope: s })}>{t(`sk.sc_${s}` as Key)}</button>)}</div>
      {f.scope === 'warehouse' && <Field label={t('sk.warehouse')}><select className="input" value={f.warehouse_id} onChange={(e) => setF({ ...f, warehouse_id: e.target.value })}><option value="">—</option>{(meta?.warehouses ?? []).filter((w: any) => w.active).map((w: any) => <option key={w.id} value={w.id}>{w.name}</option>)}</select></Field>}
      {f.scope === 'category' && <Field label={t('sk.category')}><select className="input" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}><option value="">—</option>{(meta?.categories ?? []).map((c: string) => <option key={c}>{c}</option>)}</select></Field>}
      <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>{t('sk.inventoryHint')}</p>
    </Modal>
  );
}
function InventoryModal({ id, onClose }: { id: number; onClose: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const [counts, setCounts] = useState<Record<number, string>>({});
  const [search, setSearch] = useState('');
  const load = useCallback(() => { get(`/api/inventories/${id}`).then((x) => { setD(x); setCounts(Object.fromEntries(x.lines.map((l: any) => [l.id, l.counted === null ? '' : String(n3(l.counted))]))); }).catch(err(toast)); }, [id]);
  useEffect(load, [load]);
  if (!d) return null;
  const open = d.status === 'open';
  const saveCounts = async (silent = false) => {
    await api('PUT', `/api/inventories/${id}/count`, { lines: d.lines.filter((l: any) => counts[l.id] !== (l.counted === null ? '' : String(n3(l.counted)))).map((l: any) => ({ line_id: l.id, counted: counts[l.id] === '' ? null : toNum(counts[l.id]) })) });
    if (!silent) toast('success', t('sk.saved'));
  };
  const lines = d.lines.filter((l: any) => !search || `${l.name} ${l.code ?? ''}`.toLowerCase().includes(search.toLowerCase()));
  const gap = d.lines.reduce((a: number, l: any) => a + (counts[l.id] === '' ? 0 : (toNum(counts[l.id]) - Number(l.theoretical)) * Number(l.unit_cost)), 0);
  return (
    <Modal size="lg" title={`${d.number} — ${t(`sk.sc_${d.scope}` as Key)}${d.warehouse ? ` · ${d.warehouse}` : ''}${d.category ? ` · ${d.category}` : ''}`} onClose={onClose}
      footer={<>
        <span className="muted">{t('sk.gapValue')} : <b style={{ color: gap < 0 ? 'var(--danger)' : undefined }}>{money(Math.round(gap * 100) / 100, locale)}</b></span><span style={{ flex: 1 }} />
        {open && can('stock.inventory') && <>
          <button className="btn ghost danger" onClick={async () => { try { await post(`/api/inventories/${id}/cancel`); onClose(); } catch (e: any) { toast('error', e.message); } }}>{t('sk.cancelInv')}</button>
          <button className="btn" onClick={() => saveCounts().then(load).catch((e) => toast('error', e.message))}>{t('sk.saveCounts')}</button>
          <button className="btn primary" onClick={async () => { try { await saveCounts(true); const r = await post(`/api/inventories/${id}/validate`); toast('success', `${t('sk.invValidated')} (${money(r.gap_value, locale)})`); load(); } catch (e: any) { toast('error', e.message); } }}>{t('sk.validate')}</button>
        </>}
      </>}>
      <div className="row"><input className="input" style={{ width: 220 }} placeholder={t('common.search')} aria-label={t('common.search')} value={search} onChange={(e) => setSearch(e.target.value)} />
        {open && <button className="btn sm ghost" onClick={() => setCounts(Object.fromEntries(d.lines.map((l: any) => [l.id, counts[l.id] === '' ? String(Math.max(0, n3(l.theoretical))) : counts[l.id]])))}>{t('sk.fillTheoretical')}</button>}
        <span className="muted">{d.lines.filter((l: any) => counts[l.id] !== '').length} / {d.lines.length} {t('sk.counted')}</span></div>
      <table className="table">
        <thead><tr><th>{t('sk.product')}</th><th>{t('sk.warehouse')}</th><th className="num">{t('sk.theoretical')}</th><th>{t('sk.physical')}</th><th className="num">{t('sk.gap')}</th><th className="num">{t('sk.gapValue')}</th>{!open && <th className="num">{t('sk.applied')}</th>}</tr></thead>
        <tbody>{lines.map((l: any) => {
          const c = counts[l.id];
          const g = c === '' ? null : n3(toNum(c) - Number(l.theoretical));
          return (
            <tr key={l.id}>
              <td>{l.name}<div className="muted" style={{ fontSize: 11.5 }}>{l.category}</div></td><td>{l.warehouse}</td><td className="num">{n3(l.theoretical)} {l.unit}</td>
              <td>{open ? <input className="input" style={{ width: 100 }} inputMode="decimal" aria-label={`${l.name} ${t('sk.physical')}`} value={c} onChange={(e) => setCounts({ ...counts, [l.id]: e.target.value })} /> : `${n3(l.counted)} ${l.unit}`}</td>
              <td className="num" style={{ color: g ? (g < 0 ? 'var(--danger)' : '#15803D') : undefined, fontWeight: g ? 700 : 400 }}>{g === null ? '' : `${g > 0 ? '+' : ''}${g}`}</td>
              <td className="num">{g === null ? '' : money(Math.round(g * Number(l.unit_cost) * 100) / 100, locale)}</td>{!open && <td className="num">{l.adjusted === null ? '' : n3(l.adjusted)}</td>}
            </tr>
          );
        })}</tbody>
      </table>
    </Modal>
  );
}

// ===================================================== Rapports & réglages =====================================================
function Reports() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const kinds = ['state', 'value', 'movements', 'departments', 'expired', 'inventory', ...(can('purchase.reports') ? ['suppliers', 'debts', 'expenses', 'journal'] : [])];
  const [kind, setKind] = useState(kinds[0]);
  const [p, setP] = useState({ from: `${todayLocal().slice(0, 8)}01`, to: todayLocal() });
  const [r, setR] = useState<any>(null);
  const qs = `from=${p.from}&to=${p.to}`;
  useEffect(() => { setR(null); get(`/api/stock/reports/${kind}?${qs}`).then(setR).catch(err(toast)); }, [kind, qs]);
  const fmt = (c: any, v: any) => (v === null || v === undefined || v === '' ? '—' : c.money ? money(Number(v), locale) : String(v));
  return (
    <>
      <div className="row">
        <select className="input" style={{ width: 'auto' }} aria-label={t('sk.t_reports')} value={kind} onChange={(e) => setKind(e.target.value)}>{kinds.map((k) => <option key={k} value={k}>{t(`sk.rp_${k}` as Key)}</option>)}</select>
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('sk.from')} value={p.from} onChange={(e) => e.target.value && setP({ ...p, from: e.target.value })} />
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('sk.to')} value={p.to} min={p.from} onChange={(e) => e.target.value && setP({ ...p, to: e.target.value })} />
        <span style={{ flex: 1 }} />
        {['pdf', 'xlsx', 'csv'].map((f) => <button key={f} className="btn" onClick={() => window.open(`/api/stock/reports/${kind}?${qs}&format=${f}`, '_blank')}>{f === 'xlsx' ? 'Excel' : f.toUpperCase()}</button>)}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{r?.title ?? '…'}</h3>
        <table className="table">
          <thead><tr>{(r?.columns ?? []).map((c: any) => <th key={c.key} className={c.money ? 'num' : ''}>{c.label}</th>)}</tr></thead>
          <tbody>
            {r && !r.rows.length && <tr><td colSpan={r.columns.length} className="muted">{t('common.none')}</td></tr>}
            {(r?.rows ?? []).map((x: any, i: number) => <tr key={i}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : 'wrap'}>{fmt(c, x[c.key])}</td>)}</tr>)}
            {r?.total && r.rows.length > 0 && <tr style={{ fontWeight: 700, background: 'var(--surface2)' }}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : ''}>{r.total[c.key] !== undefined ? fmt(c, r.total[c.key]) : ''}</td>)}</tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}
function Settings() {
  const { t } = useI18n();
  const toast = useToast();
  const meta = useMeta();
  const [s, setS] = useState<any>(null);
  useEffect(() => { get('/api/stock/settings').then(setS).catch(err(toast)); }, []);
  if (!s) return <span>{t('common.loading')}</span>;
  const save = async () => { try { setS(await api('PUT', '/api/stock/settings', { ...s, restaurant_warehouse_id: s.restaurant_warehouse_id ? Number(s.restaurant_warehouse_id) : null, late_po_days: s.late_po_days ?? 0 })); toast('success', t('sk.saved')); } catch (e: any) { toast('error', e.message); } };
  return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12, maxWidth: 720 }}>
      <div className="form-grid">
        <Field label={t('sk.expiryDays')}><input type="number" min={0} max={365} className="input" value={s.expiry_alert_days} onChange={(e) => setS({ ...s, expiry_alert_days: Number(e.target.value) })} /></Field>
        <Field label={t('sk.gapPercent')}><input type="number" min={0} max={100} className="input" value={s.inventory_gap_percent} onChange={(e) => setS({ ...s, inventory_gap_percent: Number(e.target.value) })} /></Field>
        <Field label={t('sk.gapValueSetting')}><input type="number" min={0} className="input" value={s.inventory_gap_value} onChange={(e) => setS({ ...s, inventory_gap_value: Number(e.target.value) })} /></Field>
        <Field label={t('sk.restaurantWh')}><select className="input" value={s.restaurant_warehouse_id ?? ''} onChange={(e) => setS({ ...s, restaurant_warehouse_id: e.target.value || null })}><option value="">{t('sk.defaultWh')}</option>{(meta?.warehouses ?? []).filter((w: any) => w.active).map((w: any) => <option key={w.id} value={w.id}>{w.name}</option>)}</select></Field>
        <Field label={t('sk.expenseCategory')}><input className="input" value={s.purchase_category} onChange={(e) => setS({ ...s, purchase_category: e.target.value })} /></Field>
      </div>
      <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>{t('sk.settingsHint')}</p>
      <button className="btn primary" style={{ alignSelf: 'flex-start' }} onClick={save}>{t('common.save')}</button>
    </div>
  );
}

