import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Page } from '../components/Layout';
import { ReasonModal } from '../components/ReservationPanel';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { api, get, newOpKey, patch, post, postOnce, upload } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { addDays, fmtDate, fmtDateTime, money, todayLocal } from '../lib/format';
import { useLive } from '../lib/useLive';

type Tab = 'me' | 'dashboard' | 'employees' | 'planning' | 'attendance' | 'leaves' | 'payroll' | 'documents' | 'reports' | 'settings';
const STAFF = ['hr.view', 'hr.team', 'hr.manage', 'hr.salary', 'hr.payroll'];
const ST_COLORS: Record<string, [string, string]> = { active: ['#DCFCE7', '#166534'], leave: ['#DBEAFE', '#1E40AF'], suspended: ['#FEF3C7', '#92400E'], left: ['#F1F5F9', '#64748B'] };
const LV_COLORS: Record<string, [string, string]> = { pending: ['#FEF3C7', '#92400E'], approved: ['#DCFCE7', '#166534'], refused: ['#FEE2E2', '#991B1B'], cancelled: ['#F1F5F9', '#64748B'] };
const toNum = (v: string | number) => Number(String(v ?? '').replace(',', '.').replace(/\s/g, '')) || 0;
const err = (toast: any) => (e: any) => toast('error', e.message);
const d10 = (v: any) => (v ? String(v).slice(0, 10) : '');
const hm = (m: number) => `${Math.floor((m ?? 0) / 60)} h ${String((m ?? 0) % 60).padStart(2, '0')}`;
const t5 = (v: any) => (v ? String(v).slice(0, 5) : '');
const timeOf = (v: any, locale: string) => (v ? new Date(v).toLocaleTimeString(locale === 'ar' ? 'ar-DZ' : locale, { hour: '2-digit', minute: '2-digit' }) : '—');
const name = (e: any) => `${e.last_name ?? ''} ${e.first_name ?? ''}`.trim();
const mondayOf = (d: string) => addDays(d, -((new Date(`${d}T00:00:00Z`).getUTCDay() + 6) % 7));

function Pill({ map, s, k }: { map: Record<string, [string, string]>; s: string; k: string }) {
  const { t } = useI18n();
  const [bg, fg] = map[s] ?? ['#F1F5F9', '#475569'];
  return <span className="pill" style={{ background: bg, color: fg }}>{t(`${k}${s}` as Key)}</span>;
}
function useMeta() {
  const [m, setM] = useState<any>(null);
  const load = useCallback(() => { get('/api/hr/meta').then(setM).catch(() => {}); }, []);
  useEffect(load, [load]);
  return { meta: m, reload: load };
}
const deptName = (meta: any, code: string) => meta?.departments?.find((d: any) => d.code === code)?.name ?? code ?? '';

export function Hr() {
  const { t } = useI18n();
  const { can } = useAuth();
  const [sp, setSp] = useSearchParams();
  const any = (ps: string[]) => ps.some((p) => can(p));
  const tabs = ([['me', ['hr.self']], ['dashboard', STAFF], ['employees', STAFF], ['planning', ['hr.self', ...STAFF]], ['attendance', STAFF], ['leaves', ['hr.self', ...STAFF]], ['payroll', ['hr.salary']],
    ['documents', STAFF], ['reports', ['hr.reports']], ['settings', ['hr.manage', 'hr.payroll']]] as [Tab, string[]][]).filter(([, ps]) => any(ps)).map(([k]) => k);
  const def: Tab = any(STAFF) ? 'dashboard' : 'me';
  const tab = tabs.includes(sp.get('tab') as Tab) ? (sp.get('tab') as Tab) : tabs.includes(def) ? def : tabs[0];
  const go = (k: Tab) => setSp({ tab: k }, { replace: true });
  const [openEmp, setOpenEmp] = useState<number | null>(null);
  return (
    <Page>
      <div className="page-head"><h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('rh.title')}</h1></div>
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>
        {tabs.map((k) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => go(k)}>{t(`rh.t_${k}` as Key)}</button>)}
      </div>
      {tab === 'me' && <Me />}
      {tab === 'dashboard' && <Dash go={go} openEmp={setOpenEmp} />}
      {tab === 'employees' && <Employees openEmp={setOpenEmp} />}
      {tab === 'planning' && <Planning />}
      {tab === 'attendance' && <Attendance />}
      {tab === 'leaves' && <Leaves />}
      {tab === 'payroll' && <Payroll />}
      {tab === 'documents' && <Documents openEmp={setOpenEmp} />}
      {tab === 'reports' && <Reports />}
      {tab === 'settings' && <Settings />}
      {openEmp && <EmployeeSheet id={openEmp} onClose={() => setOpenEmp(null)} />}
    </Page>
  );
}

// ===================================================== Mon espace =====================================================
function Me() {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const [req, setReq] = useState(false);
  const [corr, setCorr] = useState(false);
  const [swap, setSwap] = useState<any>(null);
  const [leaves, setLeaves] = useState<any[]>([]);
  const load = useCallback(() => {
    get('/api/hr/me').then(setD).catch(err(toast));
    get('/api/hr/leaves?mine=true').then(setLeaves).catch(() => {});
  }, []);
  useEffect(load, [load]);
  if (!d) return <span>{t('common.loading')}</span>;
  if (!d.linked) return <div className="alert">{t('rh.notLinked')}</div>;
  const a = d.today;
  const act = async (action: string) => { try { await post('/api/hr/clock', { action }); toast('success', t(`rh.clk_${action}` as Key)); load(); } catch (e: any) { toast('error', e.message); } };
  const open = a?.clock_in && !a?.clock_out;
  return (
    <>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 14, alignItems: 'start' }}>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <h3 style={{ margin: 0 }}>{t('rh.clockTitle')}</h3>
          <div className="muted">{d.employee.matricule} · {name(d.employee)} · {d.employee.department_name}</div>
          <div className="sum-row"><span>{t('rh.in')}</span><b>{timeOf(a?.clock_in, locale)}</b></div>
          <div className="sum-row"><span>{t('rh.out')}</span><b>{timeOf(a?.clock_out, locale)}</b></div>
          <div className="sum-row"><span>{t('rh.break')}</span><b>{a?.break_minutes ?? 0} min{a?.break_started_at ? ` · ${t('rh.onBreak')}` : ''}</b></div>
          {a?.late_minutes > 0 && <div className="alert" style={{ color: '#B45309', borderColor: '#B45309' }}>{t('rh.late')} : {a.late_minutes} min</div>}
          <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
            {!a?.clock_in && <button className="btn primary" onClick={() => act('in')}>{t('rh.clockIn')}</button>}
            {open && !a.break_started_at && <button className="btn" onClick={() => act('break_start')}>{t('rh.breakStart')}</button>}
            {open && a.break_started_at && <button className="btn" onClick={() => act('break_end')}>{t('rh.breakEnd')}</button>}
            {open && <button className="btn primary" onClick={() => act('out')}>{t('rh.clockOut')}</button>}
            <button className="btn ghost" onClick={() => setCorr(true)}>{t('rh.askCorrection')}</button>
          </div>
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <h3 style={{ margin: 0 }}>{t('rh.leaveBalance')}</h3>
          <div className="sum-row"><span>{t('rh.balance')}</span><b style={{ fontSize: 20 }}>{d.balance.balance} j</b></div>
          <div className="sum-row muted"><span>{t('rh.pending')}</span><span>{d.balance.pending} j</span></div>
          <div className="sum-row muted"><span>{t('rh.taken')}</span><span>{d.balance.taken} j</span></div>
          <div className="sum-row muted"><span>{t('rh.available')}</span><b>{d.balance.available} j</b></div>
          <button className="btn primary" style={{ alignSelf: 'flex-start' }} onClick={() => setReq(true)}><Icon name="plus" size={14} />{t('rh.newLeave')}</button>
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <h3 style={{ margin: 0 }}>{t('rh.myPayslips')}</h3>
          {!d.payslips.length && <span className="muted">{t('common.none')}</span>}
          {d.payslips.map((p: any) => <a key={p.id} className="sum-row" href={`/api/hr/payslips/${p.id}/pdf`} target="_blank" rel="noreferrer"><span>{p.period} · {p.number}</span><b>{money(Number(p.net), locale)}</b></a>)}
        </div>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('rh.mySchedule')}</h3>
        <table className="table">
          <thead><tr><th>{t('rh.date')}</th><th>{t('rh.shift')}</th><th>{t('rh.hours')}</th><th /></tr></thead>
          <tbody>
            {!d.schedule.length && <tr><td colSpan={4} className="muted">{t('common.none')}</td></tr>}
            {d.schedule.map((s: any) => (
              <tr key={s.id}><td>{fmtDate(d10(s.work_date), locale)}</td><td>{s.rest ? <span className="muted">{t('rh.rest')}</span> : <span className="pill" style={{ background: s.color ?? '#E2E8F0', color: '#fff' }}>{s.shift_name ?? t('rh.custom')}</span>}</td>
                <td>{s.rest ? '' : `${t5(s.start_time)} – ${t5(s.end_time)}`}</td>
                <td>{!s.rest && d10(s.work_date) >= todayLocal() && d.colleagues.length > 0 && <button className="btn sm" onClick={() => setSwap({ date_a: d10(s.work_date), date_b: d10(s.work_date), target_id: '' })}>{t('rh.swap')}</button>}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
      <LeaveTable rows={leaves} onChanged={load} />
      {req && <LeaveModal onClose={() => setReq(false)} onDone={() => { setReq(false); load(); }} />}
      {corr && <CorrectionModal onClose={() => setCorr(false)} onDone={() => { setCorr(false); load(); }} />}
      {swap && (
        <Modal title={t('rh.swap')} onClose={() => setSwap(null)} size="sm" footer={<><button className="btn" onClick={() => setSwap(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!swap.target_id}
          onClick={async () => { try { await post('/api/hr/swaps', { ...swap, target_id: Number(swap.target_id) }); toast('success', t('rh.swapSent')); setSwap(null); } catch (e: any) { toast('error', e.message); } }}>{t('rh.send')}</button></>}>
          <Field label={t('rh.colleague')}><select className="input" value={swap.target_id} onChange={(e) => setSwap({ ...swap, target_id: e.target.value })}><option value="">—</option>{d.colleagues.map((c: any) => <option key={c.id} value={c.id}>{name(c)}</option>)}</select></Field>
          <Field label={t('rh.hisShift')}><input type="date" className="input" min={todayLocal()} value={swap.date_b} onChange={(e) => setSwap({ ...swap, date_b: e.target.value })} /></Field>
          <Field label={t('rh.reason')}><input className="input" value={swap.reason ?? ''} onChange={(e) => setSwap({ ...swap, reason: e.target.value })} /></Field>
        </Modal>
      )}
    </>
  );
}

function LeaveModal({ employee, onClose, onDone }: { employee?: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta } = useMeta();
  const [b, setB] = useState<any>({ type_id: '', start_date: todayLocal(), end_date: todayLocal(), start_time: '', end_time: '', reason: '', approve: false });
  const [pv, setPv] = useState<any>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [key] = useState(() => newOpKey('cg'));
  const type = meta?.leave_types?.find((x: any) => String(x.id) === String(b.type_id));
  const mgr = can('hr.manage') || can('hr.team');
  useEffect(() => {
    if (!b.start_date || !b.end_date || b.end_date < b.start_date) return;
    get(`/api/hr/leaves/preview?start_date=${b.start_date}&end_date=${b.end_date}${employee ? `&employee_id=${employee.id}` : ''}`).then(setPv).catch(() => setPv(null));
  }, [b.start_date, b.end_date, employee?.id]);
  const submit = async () => {
    try {
      const r = await postOnce('/api/hr/leaves', { employee_id: employee?.id, type_id: Number(b.type_id), start_date: b.start_date, end_date: type?.hourly ? b.start_date : b.end_date,
        start_time: type?.hourly ? b.start_time : null, end_time: type?.hourly ? b.end_time : null, reason: b.reason || null, approve: employee && mgr ? b.approve : undefined }, key);
      for (const f of files) await upload('/api/photos', f, { owner_type: 'leave_request', owner_id: String(r.id) }).catch(err(toast));
      toast('success', `${t('rh.leaveSent')} ${r.number}`);
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  const types = (meta?.leave_types ?? []).filter((x: any) => x.justified || (employee && mgr));
  return (
    <Modal title={`${t('rh.newLeave')}${employee ? ` — ${name(employee)}` : ''}`} onClose={onClose} footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!b.type_id} onClick={submit}>{t('rh.send')}</button></>}>
      <div className="form-grid">
        <Field label={t('rh.leaveType')}><select className="input" value={b.type_id} onChange={(e) => setB({ ...b, type_id: e.target.value })}><option value="">—</option>{types.map((x: any) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></Field>
        <Field label={t('rh.from')}><input type="date" className="input" value={b.start_date} onChange={(e) => setB({ ...b, start_date: e.target.value, end_date: e.target.value > b.end_date ? e.target.value : b.end_date })} /></Field>
        {!type?.hourly && <Field label={t('rh.to')}><input type="date" className="input" min={b.start_date} value={b.end_date} onChange={(e) => setB({ ...b, end_date: e.target.value })} /></Field>}
        {type?.hourly && <><Field label={t('rh.fromTime')}><input type="time" className="input" value={b.start_time} onChange={(e) => setB({ ...b, start_time: e.target.value })} /></Field><Field label={t('rh.toTime')}><input type="time" className="input" value={b.end_time} onChange={(e) => setB({ ...b, end_time: e.target.value })} /></Field></>}
      </div>
      {!type?.hourly && pv && <div className="alert" style={{ fontSize: 13 }}>{pv.days} {t('rh.workingDays')} · {t('rh.available')} : <b>{pv.balance.available} j</b>{type?.deducts_balance && pv.days > pv.balance.available ? ` — ${t('rh.insufficient')}` : ''}</div>}
      <Field label={t('rh.reason')}><input className="input" value={b.reason} onChange={(e) => setB({ ...b, reason: e.target.value })} /></Field>
      {type?.requires_document && <Field label={t('rh.proof')}><input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" multiple onChange={(e) => setFiles(Array.from(e.target.files ?? []))} /></Field>}
      {employee && mgr && <label className="row" style={{ gap: 8 }}><input type="checkbox" checked={b.approve} onChange={(e) => setB({ ...b, approve: e.target.checked })} />{t('rh.approveNow')}</label>}
    </Modal>
  );
}
function CorrectionModal({ employee, date, onClose, onDone }: { employee?: any; date?: string; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [b, setB] = useState({ work_date: date ?? todayLocal(), clock_in: '', clock_out: '', break_minutes: '', reason: '' });
  const iso = (d: string, tm: string) => (tm ? new Date(`${d}T${tm}:00`).toISOString() : null);
  const submit = async () => {
    try {
      const outDate = b.clock_out && b.clock_in && b.clock_out < b.clock_in ? addDays(b.work_date, 1) : b.work_date;
      const r = await post('/api/hr/attendance/corrections', { employee_id: employee?.id, work_date: b.work_date, clock_in: iso(b.work_date, b.clock_in), clock_out: iso(outDate, b.clock_out), break_minutes: b.break_minutes === '' ? null : Number(b.break_minutes), reason: b.reason });
      toast('success', r.status === 'approved' ? t('rh.corrected') : t('rh.correctionSent'));
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={`${t('rh.askCorrection')}${employee ? ` — ${name(employee)}` : ''}`} onClose={onClose} size="sm" footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={b.reason.trim().length < 5} onClick={submit}>{t('rh.send')}</button></>}>
      <Field label={t('rh.date')}><input type="date" className="input" max={todayLocal()} value={b.work_date} onChange={(e) => setB({ ...b, work_date: e.target.value })} /></Field>
      <div className="form-grid">
        <Field label={t('rh.in')}><input type="time" className="input" value={b.clock_in} onChange={(e) => setB({ ...b, clock_in: e.target.value })} /></Field>
        <Field label={t('rh.out')}><input type="time" className="input" value={b.clock_out} onChange={(e) => setB({ ...b, clock_out: e.target.value })} /></Field>
        <Field label={`${t('rh.break')} (min)`}><input type="number" min={0} className="input" value={b.break_minutes} onChange={(e) => setB({ ...b, break_minutes: e.target.value })} /></Field>
      </div>
      <Field label={t('rh.justification')}><textarea className="input" rows={2} value={b.reason} onChange={(e) => setB({ ...b, reason: e.target.value })} /></Field>
    </Modal>
  );
}

// ===================================================== Tableau de bord =====================================================
function Dash({ go, openEmp }: { go: (t: Tab) => void; openEmp: (id: number) => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const load = useCallback(() => { get('/api/hr/dashboard').then(setD).catch(err(toast)); }, []);
  useEffect(load, [load]);
  useLive(load, 60000);
  if (!d) return <span>{t('common.loading')}</span>;
  const k = d.kpi;
  const card = (label: string, v: any, color?: string, onClick?: () => void) => (
    <div className={`card kpi ${onClick ? 'clickable' : ''}`} style={{ borderInlineStart: color ? `4px solid ${color}` : undefined, cursor: onClick ? 'pointer' : undefined }} onClick={onClick}>
      <span className="label">{label}</span><span className="value" style={{ fontSize: typeof v === 'string' ? 20 : undefined }}>{v}</span>
    </div>
  );
  const max = Math.max(1, ...d.by_department.map((x: any) => x.n));
  const lvl = (l: string) => (l === 'danger' ? 'var(--danger)' : l === 'warning' ? '#B45309' : undefined);
  return (
    <>
      <div className="grid kpis">
        {card(t('rh.kTotal'), k.total, undefined, () => go('employees'))}
        {card(t('rh.kActive'), `${k.active} · ${k.left_} ${t('rh.kLeft')}`, '#15803D', () => go('employees'))}
        {card(t('rh.kPresent'), `${k.present} / ${k.scheduled}`, '#0E7490', () => go('attendance'))}
        {card(t('rh.kAbsent'), k.absent, k.absent ? '#B91C1C' : undefined, () => go('attendance'))}
        {card(t('rh.kOnLeave'), k.on_leave, '#1E40AF', () => go('leaves'))}
        {card(t('rh.kLate'), k.late, k.late ? '#B45309' : undefined, () => go('attendance'))}
        {card(t('rh.kContracts'), k.contracts_expiring, k.contracts_expiring ? '#B45309' : undefined)}
        {card(t('rh.kBirthdays'), k.birthdays, '#C9A227')}
        {k.payroll_base !== null && card(t('rh.kPayroll'), money(k.payroll_base, locale), '#7A1F2B', () => go('payroll'))}
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 14, alignItems: 'start' }}>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <h3 style={{ margin: 0 }}>{t('rh.alerts')} ({d.alerts.length})</h3>
          {!d.alerts.length && <span className="muted">{t('rh.noAlert')}</span>}
          {d.alerts.map((a: any, i: number) => <div key={i} className="alert" style={{ padding: '6px 10px', fontSize: 13, borderColor: lvl(a.level), color: lvl(a.level), cursor: a.ref?.employee_id ? 'pointer' : undefined }} onClick={() => a.ref?.employee_id && openEmp(a.ref.employee_id)}>{a.message}</div>)}
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <h3 style={{ margin: 0 }}>{t('rh.byDept')}</h3>
          {d.by_department.map((x: any) => <div key={x.code ?? x.department}><div className="sum-row" style={{ fontSize: 13 }}><span>{x.department}</span><b>{x.n}</b></div><div className="meter"><i style={{ width: `${(x.n / max) * 100}%` }} /></div></div>)}
          <h3 style={{ margin: '8px 0 0' }}>{t('rh.birthdays')}</h3>
          {!d.birthdays.length && <span className="muted">{t('common.none')}</span>}
          {d.birthdays.map((b: any) => <div key={b.id} className="sum-row" style={{ fontSize: 13 }}><span>🎂 {name(b)}</span><span className="muted">{b.day}</span></div>)}
          {d.last_payroll && <><h3 style={{ margin: '8px 0 0' }}>{t('rh.lastPayroll')} {d.last_payroll.period}</h3>
            <div className="sum-row" style={{ fontSize: 13 }}><span>{t('rh.gross')}</span><b>{money(Number(d.last_payroll.gross_total), locale)}</b></div>
            <div className="sum-row" style={{ fontSize: 13 }}><span>{t('rh.net')}</span><b>{money(Number(d.last_payroll.net_total), locale)}</b></div></>}
        </div>
      </div>
    </>
  );
}

// ===================================================== Employés =====================================================
function Employees({ openEmp }: { openEmp: (id: number) => void }) {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta } = useMeta();
  const [f, setF] = useState({ q: '', department: '', status: 'present' });
  const [rows, setRows] = useState<any[] | null>(null);
  const [add, setAdd] = useState(false);
  const load = useCallback(() => {
    const qs = new URLSearchParams();
    if (f.q) qs.set('q', f.q); if (f.department) qs.set('department', f.department); if (f.status) qs.set('status', f.status);
    get(`/api/hr/employees?${qs}`).then(setRows).catch(err(toast));
  }, [f.q, f.department, f.status]);
  useEffect(load, [load]);
  return (
    <>
      <div className="row">
        <input className="input" style={{ maxWidth: 260 }} placeholder={t('rh.search')} aria-label={t('rh.search')} value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} />
        <select className="input" style={{ width: 'auto' }} aria-label={t('rh.department')} value={f.department} onChange={(e) => setF({ ...f, department: e.target.value })}><option value="">{t('rh.allDepts')}</option>{(meta?.departments ?? []).map((d: any) => <option key={d.code} value={d.code}>{d.name}</option>)}</select>
        <select className="input" style={{ width: 'auto' }} aria-label={t('rh.status')} value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}>
          <option value="present">{t('rh.inWorkforce')}</option><option value="">{t('rh.all')}</option>{Object.keys(ST_COLORS).map((s) => <option key={s} value={s}>{t(`rh.st_${s}` as Key)}</option>)}
        </select>
        <span style={{ flex: 1 }} />
        {can('hr.manage') && <button className="btn primary" onClick={() => setAdd(true)}><Icon name="plus" size={14} />{t('rh.newEmployee')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('rh.matricule')}</th><th>{t('rh.employee')}</th><th>{t('rh.department')}</th><th>{t('rh.position')}</th><th>{t('rh.contract')}</th><th>{t('rh.status')}</th><th>{t('rh.phone')}</th>{can('hr.salary') && <th className="num">{t('rh.salary')}</th>}</tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
            {(rows ?? []).map((e) => (
              <tr key={e.id} style={{ cursor: 'pointer' }} onClick={() => openEmp(e.id)}>
                <td><b>{e.matricule}</b></td>
                <td><div className="row" style={{ gap: 8 }}>{e.photo_id ? <img src={`/api/photos/${e.photo_id}`} alt="" style={{ width: 28, height: 28, borderRadius: 99, objectFit: 'cover' }} /> : <span className="pill" style={{ width: 28, height: 28, borderRadius: 99, justifyContent: 'center' }}>{(e.first_name ?? '?')[0]}</span>}{name(e)}</div></td>
                <td>{e.department_name}</td><td>{e.position ?? ''}</td>
                <td>{e.contract_type ? `${t(`rh.ct_${e.contract_type}` as Key)}${e.contract_end ? ` → ${d10(e.contract_end)}` : ''}` : '—'}</td>
                <td><Pill map={ST_COLORS} s={e.effective_status} k="rh.st_" /></td><td>{e.phone ?? ''}</td>
                {can('hr.salary') && <td className="num">{e.base_salary !== null ? money(Number(e.base_salary)) : ''}</td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {add && <EmployeeModal init={{}} onClose={() => setAdd(false)} onDone={(e) => { setAdd(false); load(); if (e?.id) openEmp(e.id); }} />}
    </>
  );
}

function EmployeeModal({ init, onClose, onDone }: { init: any; onClose: () => void; onDone: (e?: any) => void }) {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta } = useMeta();
  const [b, setB] = useState<any>({
    matricule: init.matricule ?? '', first_name: init.first_name ?? '', last_name: init.last_name ?? '', gender: init.gender ?? '', birth_date: d10(init.birth_date), phone: init.phone ?? '', email: init.email ?? '',
    address: init.address ?? '', city: init.city ?? '', emergency_contact: init.emergency_contact ?? '', hire_date: d10(init.hire_date) || todayLocal(), department: init.department ?? '', position: init.position ?? '',
    manager_id: init.manager_id ?? '', notes: init.notes ?? '', leave_opening: init.leave_opening ?? 0,
    ct_kind: 'cdi', ct_end: '', ct_salary: '',
  });
  const set = (k: string) => (e: any) => setB({ ...b, [k]: e.target.value });
  const positions = (meta?.positions ?? []).filter((p: any) => p.department === b.department);
  const save = async () => {
    const body: any = {
      first_name: b.first_name, last_name: b.last_name, gender: b.gender || null, birth_date: b.birth_date || null, phone: b.phone || null, email: b.email || null, address: b.address || null, city: b.city || null,
      emergency_contact: b.emergency_contact || null, hire_date: b.hire_date || null, department: b.department, position: b.position || null, manager_id: b.manager_id ? Number(b.manager_id) : null, notes: b.notes || null, leave_opening: toNum(b.leave_opening),
    };
    if (b.matricule) body.matricule = b.matricule;
    if (!init.id && b.ct_salary && can('hr.salary')) body.contract = { kind: b.ct_kind, start_date: b.hire_date, end_date: b.ct_end || null, base_salary: toNum(b.ct_salary) };
    try { const r = init.id ? await patch(`/api/hr/employees/${init.id}`, body) : await post('/api/hr/employees', body); toast('success', t('rh.saved')); onDone(r); } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={init.id ? `${init.matricule} — ${name(init)}` : t('rh.newEmployee')} onClose={onClose} size="lg" footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!b.first_name.trim() || !b.last_name.trim() || !b.department} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('rh.matricule')}><input className="input" placeholder={t('rh.auto')} value={b.matricule} onChange={set('matricule')} /></Field>
        <Field label={t('rh.lastName')}><input className="input" value={b.last_name} onChange={set('last_name')} /></Field>
        <Field label={t('rh.firstName')}><input className="input" value={b.first_name} onChange={set('first_name')} /></Field>
        <Field label={t('rh.gender')}><select className="input" value={b.gender} onChange={set('gender')}><option value="">—</option><option value="F">{t('rh.female')}</option><option value="M">{t('rh.male')}</option></select></Field>
        <Field label={t('rh.birthDate')}><input type="date" className="input" value={b.birth_date} onChange={set('birth_date')} /></Field>
        <Field label={t('rh.phone')}><input className="input" value={b.phone} onChange={set('phone')} /></Field>
        <Field label={t('rh.email')}><input className="input" type="email" value={b.email} onChange={set('email')} /></Field>
        <Field label={t('rh.address')}><input className="input" value={b.address} onChange={set('address')} /></Field>
        <Field label={t('rh.city')}><input className="input" value={b.city} onChange={set('city')} /></Field>
        <Field label={t('rh.emergency')}><input className="input" value={b.emergency_contact} onChange={set('emergency_contact')} /></Field>
        <Field label={t('rh.hireDate')}><input type="date" className="input" value={b.hire_date} onChange={set('hire_date')} /></Field>
        <Field label={t('rh.department')}><select className="input" value={b.department} onChange={set('department')}><option value="">—</option>{(meta?.departments ?? []).filter((d: any) => d.active).map((d: any) => <option key={d.code} value={d.code}>{d.name}</option>)}</select></Field>
        <Field label={t('rh.position')}><input className="input" list="hr-positions" value={b.position} onChange={set('position')} /><datalist id="hr-positions">{positions.map((p: any) => <option key={p.id} value={p.name} />)}</datalist></Field>
        <Field label={t('rh.manager')}><select className="input" value={b.manager_id} onChange={set('manager_id')}><option value="">—</option>{(meta?.employees ?? []).filter((e: any) => e.id !== init.id).map((e: any) => <option key={e.id} value={e.id}>{name(e)} · {e.position ?? ''}</option>)}</select></Field>
        <Field label={t('rh.leaveOpening')}><input type="number" min={0} className="input" value={b.leave_opening} onChange={set('leave_opening')} /></Field>
      </div>
      {!init.id && can('hr.salary') && (
        <div className="card" style={{ background: 'var(--surface2)' }}>
          <h4 style={{ margin: '0 0 6px' }}>{t('rh.initialContract')}</h4>
          <div className="form-grid">
            <Field label={t('rh.contractType')}><select className="input" value={b.ct_kind} onChange={set('ct_kind')}>{Object.keys(meta?.contract_kinds ?? {}).map((k) => <option key={k} value={k}>{t(`rh.ct_${k}` as Key)}</option>)}</select></Field>
            {b.ct_kind !== 'cdi' && <Field label={t('rh.contractEnd')}><input type="date" className="input" min={b.hire_date} value={b.ct_end} onChange={set('ct_end')} /></Field>}
            <Field label={t('rh.baseSalary')}><input className="input" value={b.ct_salary} onChange={set('ct_salary')} /></Field>
          </div>
        </div>
      )}
      <Field label={t('rh.notes')}><textarea className="input" rows={2} value={b.notes} onChange={set('notes')} /></Field>
    </Modal>
  );
}

function EmployeeSheet({ id, onClose }: { id: number; onClose: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta } = useMeta();
  const [e, setE] = useState<any>(null);
  const [tab, setTab] = useState('info');
  const [modal, setModal] = useState<any>(null);
  const photo = useRef<HTMLInputElement>(null);
  const load = useCallback(() => { get(`/api/hr/employees/${id}`).then(setE).catch(err(toast)); }, [id]);
  useEffect(load, [load]);
  const run = async (fn: () => Promise<any>, msg: string) => { try { await fn(); toast('success', msg); setModal(null); load(); } catch (x: any) { toast('error', x.message); } };
  if (!e) return <Modal title="…" onClose={onClose}><span>{t('common.loading')}</span></Modal>;
  const mgr = can('hr.manage');
  const tabs = ['info', 'contracts', 'time', 'leaves', ...(e.base_salary !== null || e.payslips?.length ? ['pay'] : []), 'growth', 'docs', ...(can('users.manage') || e.users?.length ? ['access'] : []), ...(mgr ? ['history'] : [])];
  const row = (k: Key, v: any) => <div><span className="muted">{t(k)}</span><div><b>{v || '—'}</b></div></div>;
  const addPhoto = async (files: FileList | null) => { for (const f of Array.from(files ?? [])) await upload('/api/photos', f, { owner_type: 'employee', owner_id: String(id) }).catch(err(toast)); load(); };
  return (
    <Modal title={`${e.matricule} — ${name(e)}`} onClose={onClose} size="lg">
      <div className="row" style={{ gap: 12, alignItems: 'center' }}>
        <div style={{ width: 64, height: 64, borderRadius: 99, overflow: 'hidden', background: 'var(--surface2)', display: 'grid', placeItems: 'center', cursor: mgr ? 'pointer' : undefined }} onClick={() => mgr && photo.current?.click()} title={mgr ? t('rh.changePhoto') : undefined}>
          {e.photo_id ? <img src={`/api/photos/${e.photo_id}`} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <Icon name="users" size={26} />}
        </div>
        <input ref={photo} type="file" hidden accept="image/jpeg,image/png,image/webp" onChange={(x) => addPhoto(x.target.files)} />
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 16 }}>{name(e)}</div>
          <div className="muted">{e.position ?? ''} · {deptName(meta, e.department)}{e.manager_name ? ` · ${t('rh.manager')} : ${e.manager_name}` : ''}</div>
        </div>
        <Pill map={ST_COLORS} s={e.effective_status} k="rh.st_" />
      </div>
      <div className="seg" style={{ flexWrap: 'wrap' }}>{tabs.map((k) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{t(`rh.s_${k}` as Key)}</button>)}</div>

      {tab === 'info' && <>
        <div className="form-grid">
          {row('rh.hireDate', e.hire_date ? fmtDate(d10(e.hire_date), locale, { day: 'numeric', month: 'short', year: 'numeric' }) : '')}
          {row('rh.birthDate', e.birth_date ? fmtDate(d10(e.birth_date), locale, { day: 'numeric', month: 'short', year: 'numeric' }) : '')}
          {row('rh.phone', e.phone)}{row('rh.email', e.email)}{row('rh.address', [e.address, e.city].filter(Boolean).join(', '))}{row('rh.emergency', e.emergency_contact)}
          {row('rh.contract', e.contract_type ? `${t(`rh.ct_${e.contract_type}` as Key)}${e.contract_end ? ` → ${d10(e.contract_end)}` : ''}` : '')}
          {e.base_salary !== null && row('rh.baseSalary', money(Number(e.base_salary), locale))}
          {row('rh.leaveBalance', `${e.balance.balance} j`)}
          {mgr && row('rh.pinCode', e.has_pin ? '••••' : t('rh.noPin'))}
        </div>
        {e.notes && <p className="muted" style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{e.notes}</p>}
        {e.exit_date && <div className="alert">{t('rh.exit')} {d10(e.exit_date)} — {e.exit_reason}</div>}
        {mgr && <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          <button className="btn" onClick={() => setModal({ k: 'edit' })}>{t('common.edit')}</button>
          <button className="btn" onClick={() => setModal({ k: 'pin', pin: '' })}>{t('rh.setPin')}</button>
          <button className="btn" onClick={() => setModal({ k: 'adjust', days: '', reason: '' })}>{t('rh.adjustLeave')}</button>
          {e.status === 'active' && <button className="btn" onClick={() => setModal({ k: 'status', status: 'suspended' })}>{t('rh.suspend')}</button>}
          {e.status !== 'active' && <button className="btn" onClick={() => run(() => post(`/api/hr/employees/${id}/status`, { status: 'active' }), t('rh.saved'))}>{t('rh.reactivate')}</button>}
          {e.status !== 'left' && <button className="btn danger" onClick={() => setModal({ k: 'status', status: 'left', date: todayLocal() })}>{t('rh.recordExit')}</button>}
        </div>}
      </>}

      {tab === 'contracts' && <>
        {mgr && can('hr.salary') && e.status !== 'left' && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setModal({ k: 'contract', kind: 'cdd', start_date: e.contract_end ? addDays(d10(e.contract_end), 1) : todayLocal(), end_date: '', base_salary: e.base_salary ?? '', renew: !!e.contracts.length })}><Icon name="plus" size={14} />{e.contracts.length ? t('rh.renew') : t('rh.newContract')}</button>}
        {e.contracts.map((c: any) => (
          <div key={c.id} className="card" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 4, opacity: c.status === 'archived' ? 0.6 : 1 }}>
            <div className="row between"><b>{c.number} · {t(`rh.ct_${c.kind}` as Key)}</b><span className="pill">{t(`rh.cs_${c.status}` as Key)}</span></div>
            <span className="muted" style={{ fontSize: 13 }}>{fmtDate(d10(c.start_date), locale, { day: 'numeric', month: 'short', year: 'numeric' })} → {c.end_date ? fmtDate(d10(c.end_date), locale, { day: 'numeric', month: 'short', year: 'numeric' }) : t('rh.openEnded')} · {c.position ?? ''} · {Number(c.weekly_hours)} h/sem.{c.base_salary !== null ? ` · ${money(Number(c.base_salary), locale)}` : ''}</span>
            {(c.amendments as any[]).map((a) => <div key={a.id} style={{ fontSize: 12.5 }}>↳ {t('rh.amendment')} {d10(a.effective_date)} : {a.description}{a.new_salary !== null && a.new_salary !== undefined ? ` · ${money(Number(a.new_salary), locale)}` : ''}{a.new_end_date ? ` · → ${d10(a.new_end_date)}` : ''}</div>)}
            {mgr && <div className="row" style={{ gap: 6 }}>
              {c.status === 'active' && <button className="btn sm" onClick={() => setModal({ k: 'amend', contract: c.id, effective_date: todayLocal(), description: '', new_salary: '', new_position: '', new_end_date: '' })}>{t('rh.addAmendment')}</button>}
              {c.status === 'ended' && <button className="btn sm" onClick={() => run(() => post(`/api/hr/contracts/${c.id}/archive`, {}), t('rh.saved'))}>{t('rh.archive')}</button>}
            </div>}
          </div>
        ))}
        {!e.contracts.length && <span className="muted">{t('common.none')}</span>}
      </>}

      {tab === 'time' && <>
        <h4 style={{ margin: 0 }}>{t('rh.next14')}</h4>
        <div className="row" style={{ gap: 4, flexWrap: 'wrap' }}>{e.schedule.map((s: any) => <span key={s.id} className="pill" title={`${t5(s.start_time)}–${t5(s.end_time)}`} style={{ background: s.rest ? 'var(--surface2)' : s.color ?? '#475569', color: s.rest ? 'var(--muted)' : '#fff' }}>{fmtDate(d10(s.work_date), locale, { weekday: 'short', day: 'numeric' })} · {s.rest ? 'R' : s.code ?? t5(s.start_time)}</span>)}</div>
        <h4 style={{ margin: '6px 0 0' }}>{t('rh.lastAttendance')}</h4>
        <table className="table">
          <thead><tr><th>{t('rh.date')}</th><th>{t('rh.in')}</th><th>{t('rh.out')}</th><th>{t('rh.break')}</th><th>{t('rh.worked')}</th><th>{t('rh.late')}</th><th>{t('rh.overtime')}</th></tr></thead>
          <tbody>{e.attendance.map((a: any) => <tr key={a.id}><td>{fmtDate(d10(a.work_date), locale)}{a.corrected ? ' ✎' : ''}</td><td>{timeOf(a.clock_in, locale)}</td><td>{timeOf(a.clock_out, locale)}</td><td>{a.break_minutes} min</td><td>{hm(a.worked_minutes)}</td>
            <td style={{ color: a.late_minutes ? '#B45309' : undefined }}>{a.late_minutes ? `${a.late_minutes} min` : ''}</td><td>{a.overtime_minutes ? hm(a.overtime_minutes) : ''}</td></tr>)}</tbody>
        </table>
        {(can('hr.manage') || can('hr.team')) && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setModal({ k: 'correction' })}>{t('rh.askCorrection')}</button>}
      </>}

      {tab === 'leaves' && <>
        <div className="row" style={{ gap: 12, flexWrap: 'wrap' }}>
          <span>{t('rh.balance')} <b>{e.balance.balance} j</b></span><span className="muted">{t('rh.accrued')} {e.balance.accrued} j ({e.balance.months} {t('rh.months')})</span><span className="muted">{t('rh.taken')} {e.balance.taken} j</span><span className="muted">{t('rh.pending')} {e.balance.pending} j</span>
        </div>
        {(can('hr.manage') || can('hr.team')) && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setModal({ k: 'leave' })}><Icon name="plus" size={14} />{t('rh.newLeave')}</button>}
        <LeaveTable rows={e.leaves.map((l: any) => ({ ...l, first_name: e.first_name, last_name: e.last_name }))} onChanged={load} compact />
      </>}

      {tab === 'pay' && <>
        {can('hr.salary') && <>
          <div className="row between"><h4 style={{ margin: 0 }}>{t('rh.payItems')}</h4>{can('hr.payroll') && <button className="btn sm" onClick={() => setModal({ k: 'item', kind: 'bonus', label: '', amount: '', recurring: false, period: todayLocal().slice(0, 7), taxable: true, contributory: true })}><Icon name="plus" size={14} />{t('rh.addItem')}</button>}</div>
          {!e.pay_items.length && <span className="muted">{t('common.none')}</span>}
          {e.pay_items.map((i: any) => <div key={i.id} className="sum-row" style={{ fontSize: 13, opacity: i.active ? 1 : 0.5 }}><span>{t(`rh.pk_${i.kind}` as Key)} · {i.label} · {i.recurring ? t('rh.recurring') : i.period}{!i.taxable ? ` · ${t('rh.nonTaxable')}` : ''}</span>
            <span><b>{money(Number(i.amount), locale)}</b>{can('hr.payroll') && i.active && i.recurring && <button className="btn ghost sm" onClick={() => run(() => patch(`/api/hr/pay-items/${i.id}`, { active: false }), t('rh.saved'))}>✕</button>}</span></div>)}
        </>}
        <h4 style={{ margin: '6px 0 0' }}>{t('rh.advances')}</h4>
        {!e.advances.length && <span className="muted">{t('common.none')}</span>}
        {e.advances.map((a: any) => <div key={a.id} className="sum-row" style={{ fontSize: 13 }}><span>{d10(a.advance_date)} · {a.installments} × · {t(`rh.as_${a.status}` as Key)}</span><b>{money(Number(a.repaid), locale)} / {money(Number(a.amount), locale)}</b></div>)}
        {can('hr.payroll_pay') && e.status !== 'left' && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setModal({ k: 'advance', amount: '', installments: 1, first_period: todayLocal().slice(0, 7), method: 'cash' })}><Icon name="plus" size={14} />{t('rh.giveAdvance')}</button>}
        <h4 style={{ margin: '6px 0 0' }}>{t('rh.payslips')}</h4>
        {!e.payslips.length && <span className="muted">{t('common.none')}</span>}
        {e.payslips.map((p: any) => <a key={p.id} className="sum-row" href={`/api/hr/payslips/${p.id}/pdf`} target="_blank" rel="noreferrer" style={{ fontSize: 13 }}><span>{p.period} · {p.number}</span><b>{money(Number(p.net), locale)}</b></a>)}
      </>}

      {tab === 'growth' && <>
        <div className="row between"><h4 style={{ margin: 0 }}>{t('rh.evaluations')}</h4>{(can('hr.manage') || can('hr.team')) && <button className="btn sm" onClick={() => setModal({ k: 'eval' })}><Icon name="plus" size={14} />{t('rh.newEval')}</button>}</div>
        {!e.evaluations.length && <span className="muted">{t('common.none')}</span>}
        {e.evaluations.map((v: any) => (
          <div key={v.id} className="card" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 4 }}>
            <div className="row between"><b>{v.period} · {v.score !== null ? `${Number(v.score).toFixed(2)} / 5` : '—'}</b><span className="pill">{t(`rh.ev_${v.status}` as Key)}</span></div>
            <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{(v.criteria as any[]).map((c, i) => <span key={i} className="pill">{c.label} {'★'.repeat(c.score)}</span>)}</div>
            {(v.objectives as any[]).map((o, i) => <div key={i} style={{ fontSize: 12.5 }}>◎ {o.label} — {t(`rh.ob_${o.status}` as Key)}</div>)}
            {v.manager_comment && <div style={{ fontSize: 13 }}>{t('rh.managerComment')} : {v.manager_comment}</div>}
            {v.employee_comment && <div style={{ fontSize: 13 }} className="muted">{t('rh.employeeComment')} : {v.employee_comment}</div>}
            {v.status === 'draft' && (can('hr.manage') || can('hr.team')) && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => run(() => patch(`/api/hr/evaluations/${v.id}`, { status: 'final' }), t('rh.saved'))}>{t('rh.finalize')}</button>}
          </div>
        ))}
        <div className="row between"><h4 style={{ margin: '6px 0 0' }}>{t('rh.trainings')}</h4>{(can('hr.manage') || can('hr.team')) && <button className="btn sm" onClick={() => setModal({ k: 'training', title: '', provider: '', start_date: '', end_date: '', hours: '', status: 'planned' })}><Icon name="plus" size={14} />{t('rh.addTraining')}</button>}</div>
        {e.trainings.map((x: any) => <div key={x.id} className="sum-row" style={{ fontSize: 13 }}><span>{x.title}{x.provider ? ` · ${x.provider}` : ''}{x.hours ? ` · ${Number(x.hours)} h` : ''}</span><span className="pill">{t(`rh.tr_${x.status}` as Key)}</span></div>)}
        <div className="row between"><h4 style={{ margin: '6px 0 0' }}>{t('rh.skills')}</h4>{(can('hr.manage') || can('hr.team')) && <button className="btn sm" onClick={() => setModal({ k: 'skills', list: e.skills.map((s: any) => ({ skill: s.skill, level: s.level })) })}>{t('common.edit')}</button>}</div>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{e.skills.map((s: any) => <span key={s.id} className="pill">{s.skill} · {'●'.repeat(s.level)}{'○'.repeat(5 - s.level)}</span>)}</div>
      </>}

      {tab === 'docs' && <>
        {mgr && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setModal({ k: 'doc', kind: '', title: '', issue_date: '', expiry_date: '', confidential: true })}><Icon name="plus" size={14} />{t('rh.addDoc')}</button>}
        {!e.documents.length && <span className="muted">{t('common.none')}</span>}
        {e.documents.map((d: any) => <DocRow key={d.id} d={d} canAdd={mgr} onChanged={load} />)}
      </>}

      {tab === 'access' && <>
        {e.users.map((u: any) => (
          <div key={u.id} className="card" style={{ padding: 12, display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <b>@{u.username}</b><span className="pill">{u.role_name}</span><span className="pill" style={{ background: u.active ? '#DCFCE7' : '#FEE2E2', color: u.active ? '#166534' : '#991B1B' }}>{u.active ? t('rh.enabled') : t('rh.disabled')}</span>
            <span className="muted" style={{ fontSize: 12.5 }}>{u.last_login_at ? `${t('rh.lastLogin')} ${fmtDateTime(u.last_login_at, locale)}` : ''}</span>
            {can('users.manage') && u.role !== 'admin' && <span style={{ marginInlineStart: 'auto' }} className="row">
              <select className="input" style={{ width: 'auto' }} aria-label={t('rh.role')} value={u.role} onChange={(x) => run(() => patch(`/api/hr/users/${u.id}`, { role: x.target.value }), t('rh.saved'))}>{(meta?.roles ?? []).map((r: any) => <option key={r.code} value={r.code}>{r.name}</option>)}</select>
              <button className="btn sm" onClick={() => run(() => patch(`/api/hr/users/${u.id}`, { active: !u.active }), t('rh.saved'))}>{u.active ? t('rh.disable') : t('rh.enable')}</button>
              <button className="btn sm" onClick={() => setModal({ k: 'reset', user: u.id, password: '' })}>{t('rh.resetPassword')}</button>
            </span>}
          </div>
        ))}
        {can('users.manage') && e.status !== 'left' && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setModal({ k: 'access', username: `${(e.first_name ?? '').toLowerCase()}.${(e.last_name ?? '').toLowerCase().slice(0, 1)}`.replace(/[^a-z0-9._-]/g, ''), password: '', role: 'employee' })}><Icon name="plus" size={14} />{t('rh.createAccess')}</button>}
      </>}

      {tab === 'history' && <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>{e.history.map((h: any, i: number) => <div key={i} className="sum-row" style={{ fontSize: 12.5 }}><span>{fmtDateTime(h.created_at, locale)} · <b>{h.action}</b></span><span className="muted">{h.user ?? ''}</span></div>)}</div>}

      {modal?.k === 'edit' && <EmployeeModal init={e} onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {modal?.k === 'leave' && <LeaveModal employee={e} onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {modal?.k === 'correction' && <CorrectionModal employee={e} onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {modal?.k === 'eval' && <EvalModal employee={e} onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {modal?.k === 'status' && (
        <Modal title={modal.status === 'left' ? t('rh.recordExit') : t('rh.suspend')} onClose={() => setModal(null)} size="sm" footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!modal.reason?.trim()} onClick={() => run(() => post(`/api/hr/employees/${id}/status`, { status: modal.status, date: modal.date ?? null, reason: modal.reason }), t('rh.saved'))}>{t('common.confirm')}</button></>}>
          {modal.status === 'left' && <Field label={t('rh.exitDate')}><input type="date" className="input" value={modal.date} onChange={(x) => setModal({ ...modal, date: x.target.value })} /></Field>}
          <Field label={t('rh.reason')}><input className="input" value={modal.reason ?? ''} onChange={(x) => setModal({ ...modal, reason: x.target.value })} /></Field>
          <span className="muted" style={{ fontSize: 12.5 }}>{t('rh.exitHint')}</span>
        </Modal>
      )}
      {modal?.k === 'pin' && (
        <Modal title={t('rh.setPin')} onClose={() => setModal(null)} size="sm" footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!/^\d{4,6}$/.test(modal.pin)} onClick={() => run(() => post(`/api/hr/employees/${id}/pin`, { pin: modal.pin }), t('rh.saved'))}>{t('common.save')}</button></>}>
          <Field label={t('rh.pinCode')}><input className="input" inputMode="numeric" maxLength={6} value={modal.pin} onChange={(x) => setModal({ ...modal, pin: x.target.value.replace(/\D/g, '') })} /></Field>
        </Modal>
      )}
      {modal?.k === 'adjust' && (
        <Modal title={t('rh.adjustLeave')} onClose={() => setModal(null)} size="sm" footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!toNum(modal.days) || modal.reason.trim().length < 5} onClick={() => run(() => post(`/api/hr/employees/${id}/leave-adjust`, { days: toNum(modal.days), reason: modal.reason }), t('rh.saved'))}>{t('common.save')}</button></>}>
          <Field label={t('rh.daysPlusMinus')}><input className="input" value={modal.days} onChange={(x) => setModal({ ...modal, days: x.target.value })} /></Field>
          <Field label={t('rh.reason')}><input className="input" value={modal.reason} onChange={(x) => setModal({ ...modal, reason: x.target.value })} /></Field>
        </Modal>
      )}
      {modal?.k === 'contract' && (
        <Modal title={t('rh.newContract')} onClose={() => setModal(null)} footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!toNum(modal.base_salary)} onClick={() => run(() => post(`/api/hr/employees/${id}/contracts`, { kind: modal.kind, start_date: modal.start_date, end_date: modal.end_date || null, base_salary: toNum(modal.base_salary), renew: modal.renew }), t('rh.saved'))}>{t('common.save')}</button></>}>
          <div className="form-grid">
            <Field label={t('rh.contractType')}><select className="input" value={modal.kind} onChange={(x) => setModal({ ...modal, kind: x.target.value })}>{Object.keys(meta?.contract_kinds ?? {}).map((k) => <option key={k} value={k}>{t(`rh.ct_${k}` as Key)}</option>)}</select></Field>
            <Field label={t('rh.from')}><input type="date" className="input" value={modal.start_date} onChange={(x) => setModal({ ...modal, start_date: x.target.value })} /></Field>
            <Field label={t('rh.to')}><input type="date" className="input" min={modal.start_date} value={modal.end_date} onChange={(x) => setModal({ ...modal, end_date: x.target.value })} /></Field>
            <Field label={t('rh.baseSalary')}><input className="input" value={modal.base_salary} onChange={(x) => setModal({ ...modal, base_salary: x.target.value })} /></Field>
          </div>
        </Modal>
      )}
      {modal?.k === 'amend' && (
        <Modal title={t('rh.addAmendment')} onClose={() => setModal(null)} footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={modal.description.trim().length < 5} onClick={() => run(() => post(`/api/hr/contracts/${modal.contract}/amendments`, {
          effective_date: modal.effective_date, description: modal.description, new_salary: modal.new_salary ? toNum(modal.new_salary) : null, new_position: modal.new_position || null, new_end_date: modal.new_end_date || null }), t('rh.saved'))}>{t('common.save')}</button></>}>
          <div className="form-grid">
            <Field label={t('rh.effectiveDate')}><input type="date" className="input" value={modal.effective_date} onChange={(x) => setModal({ ...modal, effective_date: x.target.value })} /></Field>
            {can('hr.salary') && <Field label={t('rh.newSalary')}><input className="input" value={modal.new_salary} onChange={(x) => setModal({ ...modal, new_salary: x.target.value })} /></Field>}
            <Field label={t('rh.newPosition')}><input className="input" value={modal.new_position} onChange={(x) => setModal({ ...modal, new_position: x.target.value })} /></Field>
            <Field label={t('rh.newEnd')}><input type="date" className="input" value={modal.new_end_date} onChange={(x) => setModal({ ...modal, new_end_date: x.target.value })} /></Field>
          </div>
          <Field label={t('rh.description')}><textarea className="input" rows={2} value={modal.description} onChange={(x) => setModal({ ...modal, description: x.target.value })} /></Field>
        </Modal>
      )}
      {modal?.k === 'item' && (
        <Modal title={t('rh.addItem')} onClose={() => setModal(null)} footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!modal.label.trim() || !(toNum(modal.amount) > 0)} onClick={() => run(() => post('/api/hr/pay-items', {
          employee_id: id, kind: modal.kind, label: modal.label, amount: toNum(modal.amount), recurring: modal.recurring, period: modal.recurring ? null : modal.period, taxable: modal.taxable, contributory: modal.contributory }), t('rh.saved'))}>{t('common.save')}</button></>}>
          <div className="form-grid">
            <Field label={t('rh.kind')}><select className="input" value={modal.kind} onChange={(x) => setModal({ ...modal, kind: x.target.value })}>{['bonus', 'allowance', 'deduction'].map((k) => <option key={k} value={k}>{t(`rh.pk_${k}` as Key)}</option>)}</select></Field>
            <Field label={t('rh.label')}><input className="input" value={modal.label} onChange={(x) => setModal({ ...modal, label: x.target.value })} /></Field>
            <Field label={t('rh.amount')}><input className="input" value={modal.amount} onChange={(x) => setModal({ ...modal, amount: x.target.value })} /></Field>
            {!modal.recurring && <Field label={t('rh.month')}><input type="month" className="input" value={modal.period} onChange={(x) => setModal({ ...modal, period: x.target.value })} /></Field>}
          </div>
          <div className="row" style={{ gap: 14, flexWrap: 'wrap' }}>
            <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={modal.recurring} onChange={(x) => setModal({ ...modal, recurring: x.target.checked })} />{t('rh.recurring')}</label>
            {modal.kind !== 'deduction' && <><label className="row" style={{ gap: 6 }}><input type="checkbox" checked={modal.taxable} onChange={(x) => setModal({ ...modal, taxable: x.target.checked })} />{t('rh.taxable')}</label>
              <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={modal.contributory} onChange={(x) => setModal({ ...modal, contributory: x.target.checked })} />{t('rh.contributory')}</label></>}
          </div>
        </Modal>
      )}
      {modal?.k === 'advance' && (
        <Modal title={t('rh.giveAdvance')} onClose={() => setModal(null)} size="sm" footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!(toNum(modal.amount) > 0)} onClick={() => run(() => post('/api/hr/advances', { employee_id: id, amount: toNum(modal.amount), installments: Number(modal.installments), first_period: modal.first_period, method: modal.method }), t('rh.saved'))}>{t('common.save')}</button></>}>
          <Field label={t('rh.amount')}><input className="input" value={modal.amount} onChange={(x) => setModal({ ...modal, amount: x.target.value })} /></Field>
          <Field label={t('rh.installments')}><input type="number" min={1} max={24} className="input" value={modal.installments} onChange={(x) => setModal({ ...modal, installments: x.target.value })} /></Field>
          <Field label={t('rh.firstDeduction')}><input type="month" className="input" min={todayLocal().slice(0, 7)} value={modal.first_period} onChange={(x) => setModal({ ...modal, first_period: x.target.value })} /></Field>
          <Field label={t('rh.method')}><select className="input" value={modal.method} onChange={(x) => setModal({ ...modal, method: x.target.value })}>{['cash', 'cheque', 'transfer'].map((m) => <option key={m} value={m}>{t(`rh.m_${m}` as Key)}</option>)}</select></Field>
          <span className="muted" style={{ fontSize: 12.5 }}>{t('rh.advanceHint')}</span>
        </Modal>
      )}
      {modal?.k === 'training' && (
        <Modal title={t('rh.addTraining')} onClose={() => setModal(null)} footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={modal.title.trim().length < 2} onClick={() => run(() => post('/api/hr/trainings', {
          employee_id: id, title: modal.title, provider: modal.provider || null, start_date: modal.start_date || null, end_date: modal.end_date || null, hours: modal.hours ? toNum(modal.hours) : null, status: modal.status }), t('rh.saved'))}>{t('common.save')}</button></>}>
          <div className="form-grid">
            <Field label={t('rh.trainingTitle')}><input className="input" value={modal.title} onChange={(x) => setModal({ ...modal, title: x.target.value })} /></Field>
            <Field label={t('rh.provider')}><input className="input" value={modal.provider} onChange={(x) => setModal({ ...modal, provider: x.target.value })} /></Field>
            <Field label={t('rh.from')}><input type="date" className="input" value={modal.start_date} onChange={(x) => setModal({ ...modal, start_date: x.target.value })} /></Field>
            <Field label={t('rh.to')}><input type="date" className="input" value={modal.end_date} onChange={(x) => setModal({ ...modal, end_date: x.target.value })} /></Field>
            <Field label={t('rh.hours')}><input className="input" value={modal.hours} onChange={(x) => setModal({ ...modal, hours: x.target.value })} /></Field>
            <Field label={t('rh.status')}><select className="input" value={modal.status} onChange={(x) => setModal({ ...modal, status: x.target.value })}>{['planned', 'in_progress', 'done', 'cancelled'].map((s) => <option key={s} value={s}>{t(`rh.tr_${s}` as Key)}</option>)}</select></Field>
          </div>
        </Modal>
      )}
      {modal?.k === 'skills' && (
        <Modal title={t('rh.skills')} onClose={() => setModal(null)} footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" onClick={() => run(() => api('PUT', `/api/hr/employees/${id}/skills`, { skills: modal.list.filter((s: any) => s.skill.trim().length >= 2) }), t('rh.saved'))}>{t('common.save')}</button></>}>
          {modal.list.map((s: any, i: number) => (
            <div key={i} className="row" style={{ gap: 8 }}>
              <input className="input" style={{ flex: 1, width: 'auto' }} aria-label={t('rh.skill')} value={s.skill} onChange={(x) => setModal({ ...modal, list: modal.list.map((y: any, j: number) => (j === i ? { ...y, skill: x.target.value } : y)) })} />
              <div className="seg">{[1, 2, 3, 4, 5].map((n) => <button key={n} type="button" className={s.level === n ? 'on' : ''} onClick={() => setModal({ ...modal, list: modal.list.map((y: any, j: number) => (j === i ? { ...y, level: n } : y)) })}>{n}</button>)}</div>
            </div>
          ))}
          <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setModal({ ...modal, list: [...modal.list, { skill: '', level: 3 }] })}><Icon name="plus" size={14} />{t('rh.skill')}</button>
        </Modal>
      )}
      {modal?.k === 'doc' && (
        <Modal title={t('rh.addDoc')} onClose={() => setModal(null)} footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={modal.title.trim().length < 2 || modal.kind.trim().length < 2} onClick={async () => {
          try {
            const d = await post('/api/hr/documents', { employee_id: id, kind: modal.kind, title: modal.title, issue_date: modal.issue_date || null, expiry_date: modal.expiry_date || null, confidential: modal.confidential });
            for (const f of modal.files ?? []) await upload('/api/photos', f, { owner_type: 'hr_document', owner_id: String(d.id) });
            toast('success', t('rh.saved')); setModal(null); load();
          } catch (x: any) { toast('error', x.message); }
        }}>{t('common.save')}</button></>}>
          <div className="form-grid">
            <Field label={t('rh.docKind')}><input className="input" list="hr-doc-kinds" value={modal.kind} onChange={(x) => setModal({ ...modal, kind: x.target.value })} /><datalist id="hr-doc-kinds">{['Pièce d\'identité', 'Diplôme', 'Certificat médical', 'Contrat signé', 'Attestation', 'Casier judiciaire', 'Carte d\'hygiène', 'Permis de conduire'].map((k) => <option key={k} value={k} />)}</datalist></Field>
            <Field label={t('rh.docTitle')}><input className="input" value={modal.title} onChange={(x) => setModal({ ...modal, title: x.target.value })} /></Field>
            <Field label={t('rh.issueDate')}><input type="date" className="input" value={modal.issue_date} onChange={(x) => setModal({ ...modal, issue_date: x.target.value })} /></Field>
            <Field label={t('rh.expiryDate')}><input type="date" className="input" value={modal.expiry_date} onChange={(x) => setModal({ ...modal, expiry_date: x.target.value })} /></Field>
          </div>
          <Field label={t('rh.file')}><input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" multiple onChange={(x) => setModal({ ...modal, files: Array.from(x.target.files ?? []) })} /></Field>
          <label className="row" style={{ gap: 8 }}><input type="checkbox" checked={modal.confidential} onChange={(x) => setModal({ ...modal, confidential: x.target.checked })} />{t('rh.confidential')}</label>
        </Modal>
      )}
      {modal?.k === 'access' && (
        <Modal title={t('rh.createAccess')} onClose={() => setModal(null)} size="sm" footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={modal.username.length < 3 || modal.password.length < 8} onClick={() => run(() => post(`/api/hr/employees/${id}/access`, { username: modal.username, password: modal.password, role: modal.role }), t('rh.saved'))}>{t('common.save')}</button></>}>
          <Field label={t('rh.username')}><input className="input" value={modal.username} onChange={(x) => setModal({ ...modal, username: x.target.value })} /></Field>
          <Field label={t('rh.tempPassword')}><input className="input" value={modal.password} onChange={(x) => setModal({ ...modal, password: x.target.value })} /></Field>
          <Field label={t('rh.role')}><select className="input" value={modal.role} onChange={(x) => setModal({ ...modal, role: x.target.value })}>{(meta?.roles ?? []).map((r: any) => <option key={r.code} value={r.code}>{r.name}</option>)}</select></Field>
          <span className="muted" style={{ fontSize: 12.5 }}>{t('rh.accessHint')}</span>
        </Modal>
      )}
      {modal?.k === 'reset' && (
        <Modal title={t('rh.resetPassword')} onClose={() => setModal(null)} size="sm" footer={<><button className="btn" onClick={() => setModal(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={modal.password.length < 8} onClick={() => run(() => patch(`/api/hr/users/${modal.user}`, { password: modal.password }), t('rh.saved'))}>{t('common.save')}</button></>}>
          <Field label={t('rh.tempPassword')}><input className="input" value={modal.password} onChange={(x) => setModal({ ...modal, password: x.target.value })} /></Field>
        </Modal>
      )}
    </Modal>
  );
}
function DocRow({ d, canAdd, onChanged }: { d: any; canAdd: boolean; onChanged: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const ref = useRef<HTMLInputElement>(null);
  const exp = d10(d.expiry_date), T = todayLocal();
  return (
    <div className="sum-row" style={{ fontSize: 13, alignItems: 'center' }}>
      <span><b>{d.title}</b> <span className="muted">· {d.kind}{d.confidential ? ` · 🔒 ${t('rh.confidential')}` : ''}</span>{exp && <span style={{ color: exp < T ? 'var(--danger)' : exp <= addDays(T, 30) ? '#B45309' : undefined }}> · {t('rh.expires')} {fmtDate(exp, locale, { day: 'numeric', month: 'short', year: 'numeric' })}</span>}</span>
      <span className="row" style={{ gap: 4 }}>
        {(d.files ?? []).map((f: number) => <a key={f} className="btn sm" href={`/api/photos/${f}`} target="_blank" rel="noreferrer">📄</a>)}
        {canAdd && <><input ref={ref} type="file" hidden accept="image/jpeg,image/png,image/webp,application/pdf" onChange={async (x) => { for (const f of Array.from(x.target.files ?? [])) await upload('/api/photos', f, { owner_type: 'hr_document', owner_id: String(d.id) }).catch(err(toast)); onChanged(); }} /><button className="btn ghost sm" onClick={() => ref.current?.click()}>+</button></>}
      </span>
    </div>
  );
}
function EvalModal({ employee, onClose, onDone }: { employee: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [b, setB] = useState<any>({ period: `${todayLocal().slice(0, 4)}-${Number(todayLocal().slice(5, 7)) > 6 ? 'S2' : 'S1'}`, criteria: ['Qualité du travail', 'Ponctualité', 'Esprit d\'équipe', 'Relation client'].map((label) => ({ label, score: 3 })),
    objectives: '', strengths: '', improvements: '', manager_comment: '', status: 'draft' });
  const save = async (status: string) => {
    try {
      await post('/api/hr/evaluations', { employee_id: employee.id, period: b.period, criteria: b.criteria.filter((c: any) => c.label.trim().length >= 2), objectives: b.objectives.split('\n').map((s: string) => s.trim()).filter((s: string) => s.length >= 2).map((label: string) => ({ label, status: 'todo' })),
        strengths: b.strengths || null, improvements: b.improvements || null, manager_comment: b.manager_comment || null, status });
      toast('success', t('rh.saved')); onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={`${t('rh.newEval')} — ${name(employee)}`} onClose={onClose} size="lg" footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn" onClick={() => save('draft')}>{t('rh.draft')}</button><button className="btn primary" onClick={() => save('final')}>{t('rh.finalize')}</button></>}>
      <Field label={t('rh.period')}><input className="input" value={b.period} onChange={(e) => setB({ ...b, period: e.target.value })} /></Field>
      {b.criteria.map((c: any, i: number) => (
        <div key={i} className="row" style={{ gap: 8 }}>
          <input className="input" style={{ flex: 1, width: 'auto' }} aria-label={t('rh.criterion')} value={c.label} onChange={(e) => setB({ ...b, criteria: b.criteria.map((x: any, j: number) => (j === i ? { ...x, label: e.target.value } : x)) })} />
          <div className="seg">{[1, 2, 3, 4, 5].map((n) => <button key={n} type="button" className={c.score === n ? 'on' : ''} onClick={() => setB({ ...b, criteria: b.criteria.map((x: any, j: number) => (j === i ? { ...x, score: n } : x)) })}>{n}</button>)}</div>
        </div>
      ))}
      <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setB({ ...b, criteria: [...b.criteria, { label: '', score: 3 }] })}><Icon name="plus" size={14} />{t('rh.criterion')}</button>
      <Field label={t('rh.objectives')}><textarea className="input" rows={2} value={b.objectives} onChange={(e) => setB({ ...b, objectives: e.target.value })} /></Field>
      <div className="form-grid">
        <Field label={t('rh.strengths')}><textarea className="input" rows={2} value={b.strengths} onChange={(e) => setB({ ...b, strengths: e.target.value })} /></Field>
        <Field label={t('rh.improvements')}><textarea className="input" rows={2} value={b.improvements} onChange={(e) => setB({ ...b, improvements: e.target.value })} /></Field>
      </div>
      <Field label={t('rh.managerComment')}><textarea className="input" rows={2} value={b.manager_comment} onChange={(e) => setB({ ...b, manager_comment: e.target.value })} /></Field>
    </Modal>
  );
}

// ===================================================== Planning =====================================================
function Planning() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta } = useMeta();
  const [start, setStart] = useState(mondayOf(todayLocal()));
  const [dept, setDept] = useState('');
  const [d, setD] = useState<any>(null);
  const [cell, setCell] = useState<any>(null);
  const [rot, setRot] = useState<any>(null);
  const [swaps, setSwaps] = useState<any[]>([]);
  const days = useMemo(() => Array.from({ length: 7 }, (_, i) => addDays(start, i)), [start]);
  const load = useCallback(() => {
    get(`/api/hr/schedule?from=${start}&to=${addDays(start, 6)}${dept ? `&department=${dept}` : ''}`).then(setD).catch(err(toast));
    get('/api/hr/swaps').then(setSwaps).catch(() => {});
  }, [start, dept]);
  useEffect(load, [load]);
  const entry = (eid: number, day: string) => d?.entries.find((x: any) => x.employee_id === eid && d10(x.work_date) === day);
  const leave = (eid: number, day: string) => d?.leaves.find((x: any) => x.employee_id === eid && !x.hourly && d10(x.start_date) <= day && d10(x.end_date) >= day);
  const save = async (body: any) => { try { await api('PUT', '/api/hr/schedule', body); setCell(null); load(); } catch (e: any) { toast('error', e.message); } };
  const clear = async (eid: number, day: string) => { try { await api('DELETE', `/api/hr/schedule?employee_id=${eid}&work_date=${day}`); setCell(null); load(); } catch (e: any) { toast('error', e.message); } };
  const editable = d?.editable;
  const pending = swaps.filter((s) => s.status === 'pending');
  return (
    <>
      <div className="row">
        <button className="btn icon" aria-label={t('rh.prevWeek')} onClick={() => setStart(addDays(start, -7))}><Icon name="chevL" /></button>
        <b>{fmtDate(start, locale, { day: 'numeric', month: 'short' })} – {fmtDate(addDays(start, 6), locale, { day: 'numeric', month: 'short', year: 'numeric' })}</b>
        <button className="btn icon" aria-label={t('rh.nextWeek')} onClick={() => setStart(addDays(start, 7))}><Icon name="chevR" /></button>
        <button className="btn sm" onClick={() => setStart(mondayOf(todayLocal()))}>{t('common.today')}</button>
        {(can('hr.manage') || can('hr.view') || can('hr.salary')) && <select className="input" style={{ width: 'auto' }} aria-label={t('rh.department')} value={dept} onChange={(e) => setDept(e.target.value)}><option value="">{t('rh.allDepts')}</option>{(meta?.departments ?? []).map((x: any) => <option key={x.code} value={x.code}>{x.name}</option>)}</select>}
        <span style={{ flex: 1 }} />
        <div className="row" style={{ gap: 4 }}>{(meta?.shift_types ?? []).filter((s: any) => s.active).map((s: any) => <span key={s.id} className="pill" style={{ background: s.color, color: '#fff' }}>{s.code} · {t5(s.start_time)}–{t5(s.end_time)}</span>)}</div>
        {editable && <button className="btn" onClick={() => setRot({ employee_ids: [], start_date: start, end_date: addDays(start, 27), pattern: 'M M S S R N R', offset: 2 })}>{t('rh.rotation')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table" style={{ minWidth: 900 }}>
          <thead><tr><th>{t('rh.employee')}</th>{days.map((x) => <th key={x} style={{ textAlign: 'center', background: x === todayLocal() ? 'var(--surface2)' : undefined }}>{fmtDate(x, locale, { weekday: 'short', day: 'numeric' })}</th>)}</tr></thead>
          <tbody>
            {d && !d.employees.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
            {(d?.employees ?? []).map((e: any, i: number, arr: any[]) => (
              <Fragment key={e.id}>
                {(i === 0 || arr[i - 1].department !== e.department) && <tr key={`h${e.department}`}><td colSpan={8} style={{ background: 'var(--surface2)', fontWeight: 700, fontSize: 12.5 }}>{deptName(meta, e.department)}</td></tr>}
                <tr>
                  <td style={{ whiteSpace: 'nowrap' }}><b>{name(e)}</b><div className="muted" style={{ fontSize: 11.5 }}>{e.position ?? ''}</div></td>
                  {days.map((x) => {
                    const en = entry(e.id, x), lv = leave(e.id, x);
                    return (
                      <td key={x} style={{ textAlign: 'center', padding: 4, cursor: editable ? 'pointer' : undefined }} onClick={() => editable && setCell({ e, day: x, en, shift_type_id: en?.shift_type_id ?? '', start_time: t5(en?.start_time), end_time: t5(en?.end_time), zone: en?.zone ?? '' })}>
                        {lv ? <span className="pill" style={{ background: lv.color, color: '#fff', opacity: lv.status === 'pending' ? 0.55 : 1 }} title={lv.number}>{lv.type_name.split(' ')[0]}{lv.status === 'pending' ? ' ?' : ''}</span>
                          : en ? (en.rest ? <span className="muted">{t('rh.restShort')}</span> : <span className="pill" style={{ background: en.color ?? '#475569', color: '#fff' }} title={`${t5(en.start_time)}–${t5(en.end_time)}${en.zone ? ` · ${en.zone}` : ''}`}>{en.code ?? `${t5(en.start_time)}`}</span>)
                            : <span className="muted">·</span>}
                      </td>
                    );
                  })}
                </tr>
              </Fragment>
            ))}
          </tbody>
        </table>
      </div>
      {swaps.length > 0 && (
        <div className="card" style={{ padding: 0, overflow: 'auto' }}>
          <h3 style={{ padding: '12px 14px 0' }}>{t('rh.swaps')} {pending.length ? `(${pending.length})` : ''}</h3>
          <table className="table">
            <thead><tr><th>{t('rh.requester')}</th><th>{t('rh.colleague')}</th><th>{t('rh.dates')}</th><th>{t('rh.reason')}</th><th>{t('rh.status')}</th><th /></tr></thead>
            <tbody>{swaps.map((s) => <tr key={s.id}><td>{s.requester}</td><td>{s.target}</td><td>{d10(s.date_a)}{d10(s.date_a) !== d10(s.date_b) ? ` ⇄ ${d10(s.date_b)}` : ''}</td><td className="wrap">{s.reason ?? ''}</td><td><Pill map={LV_COLORS} s={s.status} k="rh.ls_" /></td>
              <td>{s.status === 'pending' && editable && <span className="row" style={{ gap: 4 }}><button className="btn sm primary" onClick={async () => { try { await post(`/api/hr/swaps/${s.id}/decide`, { approve: true }); load(); } catch (e: any) { toast('error', e.message); } }}>{t('rh.approve')}</button>
                <button className="btn sm" onClick={async () => { try { await post(`/api/hr/swaps/${s.id}/decide`, { approve: false }); load(); } catch (e: any) { toast('error', e.message); } }}>{t('rh.refuse')}</button></span>}</td></tr>)}</tbody>
          </table>
        </div>
      )}
      {cell && (
        <Modal title={`${name(cell.e)} — ${fmtDate(cell.day, locale, { weekday: 'long', day: 'numeric', month: 'long' })}`} onClose={() => setCell(null)} size="sm" footer={<>
          {cell.en && <button className="btn danger" onClick={() => clear(cell.e.id, cell.day)}>{t('rh.clear')}</button>}
          <button className="btn" onClick={() => save({ employee_id: cell.e.id, work_date: cell.day, rest: true })}>{t('rh.rest')}</button>
          <button className="btn primary" disabled={!cell.shift_type_id && !(cell.start_time && cell.end_time)} onClick={() => save({ employee_id: cell.e.id, work_date: cell.day, shift_type_id: cell.shift_type_id ? Number(cell.shift_type_id) : null, start_time: cell.shift_type_id ? null : cell.start_time, end_time: cell.shift_type_id ? null : cell.end_time, zone: cell.zone || null })}>{t('common.save')}</button></>}>
          <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{(meta?.shift_types ?? []).filter((s: any) => s.active).map((s: any) => <button key={s.id} className={`chip ${String(cell.shift_type_id) === String(s.id) ? 'on' : ''}`} onClick={() => setCell({ ...cell, shift_type_id: s.id })}>{s.code} · {s.name}</button>)}
            <button className={`chip ${!cell.shift_type_id ? 'on' : ''}`} onClick={() => setCell({ ...cell, shift_type_id: '' })}>{t('rh.custom')}</button></div>
          {!cell.shift_type_id && <div className="form-grid"><Field label={t('rh.fromTime')}><input type="time" className="input" value={cell.start_time} onChange={(x) => setCell({ ...cell, start_time: x.target.value })} /></Field><Field label={t('rh.toTime')}><input type="time" className="input" value={cell.end_time} onChange={(x) => setCell({ ...cell, end_time: x.target.value })} /></Field></div>}
          <Field label={t('rh.zone')}><input className="input" value={cell.zone} onChange={(x) => setCell({ ...cell, zone: x.target.value })} /></Field>
        </Modal>
      )}
      {rot && (
        <Modal title={t('rh.rotation')} onClose={() => setRot(null)} footer={<><button className="btn" onClick={() => setRot(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!rot.employee_ids.length || !rot.pattern.trim()} onClick={async () => {
          try { const r = await post('/api/hr/schedule/rotation', { employee_ids: rot.employee_ids, start_date: rot.start_date, end_date: rot.end_date, pattern: rot.pattern.trim().split(/[\s,]+/), offset_per_employee: Number(rot.offset) });
            toast(r.conflicts.length ? 'info' : 'success', `${r.done} ${t('rh.shiftsPlanned')}${r.conflicts.length ? ` · ${r.conflicts.length} ${t('rh.conflicts')} : ${r.conflicts.slice(0, 3).map((c: any) => `${c.date} ${c.message}`).join(' | ')}` : ''}`); setRot(null); load();
          } catch (e: any) { toast('error', e.message); } }}>{t('rh.apply')}</button></>}>
          <div className="form-grid">
            <Field label={t('rh.from')}><input type="date" className="input" value={rot.start_date} onChange={(x) => setRot({ ...rot, start_date: x.target.value })} /></Field>
            <Field label={t('rh.to')}><input type="date" className="input" min={rot.start_date} value={rot.end_date} onChange={(x) => setRot({ ...rot, end_date: x.target.value })} /></Field>
            <Field label={t('rh.pattern')}><input className="input" value={rot.pattern} onChange={(x) => setRot({ ...rot, pattern: x.target.value })} /></Field>
            <Field label={t('rh.offset')}><input type="number" min={0} max={28} className="input" value={rot.offset} onChange={(x) => setRot({ ...rot, offset: x.target.value })} /></Field>
          </div>
          <span className="muted" style={{ fontSize: 12.5 }}>{t('rh.patternHint')}</span>
          <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{(d?.employees ?? []).map((e: any) => <button key={e.id} className={`chip ${rot.employee_ids.includes(e.id) ? 'on' : ''}`} onClick={() => setRot({ ...rot, employee_ids: rot.employee_ids.includes(e.id) ? rot.employee_ids.filter((x: number) => x !== e.id) : [...rot.employee_ids, e.id] })}>{name(e)}</button>)}</div>
        </Modal>
      )}
    </>
  );
}

// ===================================================== Présences =====================================================
function Attendance() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [date, setDate] = useState(todayLocal());
  const [rows, setRows] = useState<any[] | null>(null);
  const [corrs, setCorrs] = useState<any[]>([]);
  const [corr, setCorr] = useState<any>(null);
  const load = useCallback(() => {
    get(`/api/hr/attendance?date=${date}`).then(setRows).catch(err(toast));
    get('/api/hr/attendance/corrections').then(setCorrs).catch(() => {});
  }, [date]);
  useEffect(load, [load]);
  useLive(load, 30000);
  const team = can('hr.manage') || can('hr.team');
  const clk = async (id: number, action: string) => { try { await post('/api/hr/attendance/clock', { employee_id: id, action }); load(); } catch (e: any) { toast('error', e.message); } };
  const state = (r: any) => (r.leave ? ['leave', r.leave] : r.clock_out ? ['done', t('rh.a_done')] : r.clock_in ? ['in', r.break_started_at ? t('rh.onBreak') : t('rh.a_in')] : r.start_time && !r.rest ? (date < todayLocal() || new Date(`${date}T${t5(r.start_time)}`) < new Date() ? ['absent', t('rh.a_absent')] : ['expected', t('rh.a_expected')]) : ['off', r.rest ? t('rh.rest') : '—']);
  const color: Record<string, string> = { leave: '#1E40AF', done: '#166534', in: '#0E7490', absent: '#B91C1C', expected: '#92400E', off: 'var(--muted)' };
  const pending = corrs.filter((c) => c.status === 'pending');
  return (
    <>
      <div className="row">
        <input type="date" className="input" style={{ width: 170 }} aria-label={t('rh.date')} value={date} max={todayLocal()} onChange={(e) => e.target.value && setDate(e.target.value)} />
        <span className="muted" style={{ flex: 1 }}>{rows ? `${rows.filter((r) => r.clock_in).length} ${t('rh.presentCount')} · ${rows.filter((r) => r.late_minutes > 0).length} ${t('rh.lateCount')}` : ''}</span>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('rh.employee')}</th><th>{t('rh.shift')}</th><th>{t('rh.status')}</th><th>{t('rh.in')}</th><th>{t('rh.out')}</th><th>{t('rh.break')}</th><th>{t('rh.worked')}</th><th>{t('rh.late')}</th><th>{t('rh.overtime')}</th><th /></tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={10} className="muted">{t('common.none')}</td></tr>}
            {(rows ?? []).map((r) => {
              const [k, label] = state(r);
              return (
                <tr key={r.employee_id}>
                  <td><b>{name(r)}</b><div className="muted" style={{ fontSize: 11.5 }}>{r.matricule} · {r.position ?? ''}</div></td>
                  <td>{r.start_time && !r.rest ? <span className="pill" style={{ background: r.color ?? '#475569', color: '#fff' }}>{r.shift_code ?? ''} {t5(r.start_time)}–{t5(r.end_time)}</span> : ''}</td>
                  <td style={{ color: color[k], fontWeight: 600 }}>{label}</td>
                  <td>{timeOf(r.clock_in, locale)}{r.source === 'terminal' ? ' ⌨' : r.corrected ? ' ✎' : ''}</td><td>{timeOf(r.clock_out, locale)}</td><td>{r.break_minutes ? `${r.break_minutes} min` : ''}</td>
                  <td>{r.worked_minutes ? hm(r.worked_minutes) : ''}</td><td style={{ color: r.late_minutes ? '#B45309' : undefined }}>{r.late_minutes ? `${r.late_minutes} min` : ''}</td><td>{r.overtime_minutes ? hm(r.overtime_minutes) : ''}</td>
                  <td>{team && <span className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                    {date === todayLocal() && !r.clock_in && !r.leave && <button className="btn sm" onClick={() => clk(r.employee_id, 'in')}>{t('rh.in')}</button>}
                    {date === todayLocal() && r.clock_in && !r.clock_out && <button className="btn sm" onClick={() => clk(r.employee_id, 'out')}>{t('rh.out')}</button>}
                    <button className="btn ghost sm" title={t('rh.askCorrection')} onClick={() => setCorr({ e: { id: r.employee_id, first_name: r.first_name, last_name: r.last_name } })}>✎</button>
                  </span>}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('rh.corrections')} {pending.length ? `(${pending.length})` : ''}</h3>
        <table className="table">
          <thead><tr><th>{t('rh.date')}</th><th>{t('rh.employee')}</th><th>{t('rh.correction')}</th><th>{t('rh.justification')}</th><th>{t('rh.requester')}</th><th>{t('rh.status')}</th><th /></tr></thead>
          <tbody>
            {!corrs.length && <tr><td colSpan={7} className="muted">{t('common.none')}</td></tr>}
            {corrs.map((c) => <tr key={c.id}><td>{fmtDate(d10(c.work_date), locale)}</td><td>{name(c)}</td><td>{c.clock_in ? `${t('rh.in')} ${timeOf(c.clock_in, locale)}` : ''} {c.clock_out ? `${t('rh.out')} ${timeOf(c.clock_out, locale)}` : ''} {c.break_minutes !== null ? `${t('rh.break')} ${c.break_minutes} min` : ''}</td>
              <td className="wrap">{c.reason}</td><td>{c.requester}</td><td><Pill map={LV_COLORS} s={c.status === 'approved' ? 'approved' : c.status} k="rh.ls_" /></td>
              <td>{c.status === 'pending' && can('hr.manage') && <span className="row" style={{ gap: 4 }}><button className="btn sm primary" onClick={async () => { try { await post(`/api/hr/attendance/corrections/${c.id}/decide`, { approve: true }); load(); } catch (e: any) { toast('error', e.message); } }}>{t('rh.approve')}</button>
                <button className="btn sm" onClick={async () => { try { await post(`/api/hr/attendance/corrections/${c.id}/decide`, { approve: false }); load(); } catch (e: any) { toast('error', e.message); } }}>{t('rh.refuse')}</button></span>}</td></tr>)}
          </tbody>
        </table>
      </div>
      {corr && <CorrectionModal employee={corr.e} date={date} onClose={() => setCorr(null)} onDone={() => { setCorr(null); load(); }} />}
    </>
  );
}

// ===================================================== Congés =====================================================
function LeaveTable({ rows, onChanged, compact }: { rows: any[]; onChanged: () => void; compact?: boolean }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [refuse, setRefuse] = useState<any>(null);
  const [cancel, setCancel] = useState<any>(null);
  const decide = async (id: number, approve: boolean, note?: string) => { try { await post(`/api/hr/leaves/${id}/decide`, { approve, note: note ?? null }); toast('success', approve ? t('rh.approved') : t('rh.refused')); onChanged(); } catch (e: any) { toast('error', e.message); } };
  const team = can('hr.manage') || can('hr.team');
  return (
    <div className="card" style={{ padding: 0, overflow: 'auto' }}>
      {!compact && <h3 style={{ padding: '12px 14px 0' }}>{t('rh.leaveRequests')}</h3>}
      <table className="table">
        <thead><tr><th>{t('rh.number')}</th>{!compact && <th>{t('rh.employee')}</th>}<th>{t('rh.leaveType')}</th><th>{t('rh.period')}</th><th className="num">{t('rh.days')}</th><th>{t('rh.status')}</th><th /></tr></thead>
        <tbody>
          {!rows.length && <tr><td colSpan={7} className="muted">{t('common.none')}</td></tr>}
          {rows.map((r) => (
            <tr key={r.id}>
              <td><b>{r.number}</b></td>{!compact && <td>{name(r)}</td>}
              <td><span className="pill" style={{ background: r.color, color: '#fff' }}>{r.type_name}</span>{(r.files ?? []).map((f: number) => <a key={f} href={`/api/photos/${f}`} target="_blank" rel="noreferrer"> 📎</a>)}</td>
              <td>{r.hourly ? `${fmtDate(d10(r.start_date), locale)} ${t5(r.start_time)}–${t5(r.end_time)}` : `${fmtDate(d10(r.start_date), locale)} → ${fmtDate(d10(r.end_date), locale)}`}{r.reason ? <div className="muted" style={{ fontSize: 12 }}>{r.reason}</div> : null}</td>
              <td className="num">{r.hourly ? `${Number(r.hours)} h` : Number(r.days)}</td>
              <td><Pill map={LV_COLORS} s={r.status} k="rh.ls_" />{r.decision_note ? <div className="muted" style={{ fontSize: 12 }}>{r.decision_note}</div> : null}</td>
              <td><span className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                {r.status === 'pending' && team && <><button className="btn sm primary" onClick={() => decide(r.id, true)}>{t('rh.approve')}</button><button className="btn sm" onClick={() => setRefuse(r)}>{t('rh.refuse')}</button></>}
                {(r.status === 'pending' || (r.status === 'approved' && can('hr.manage') && d10(r.start_date) > todayLocal())) && <button className="btn ghost sm" onClick={() => setCancel(r)}>{t('common.cancel')}</button>}
              </span></td>
            </tr>
          ))}
        </tbody>
      </table>
      {refuse && <ReasonModal title={`${t('rh.refuse')} ${refuse.number}`} onClose={() => setRefuse(null)} onSubmit={(note) => { const r = refuse; setRefuse(null); decide(r.id, false, note); }} />}
      {cancel && <ReasonModal title={`${t('common.cancel')} ${cancel.number}`} onClose={() => setCancel(null)} onSubmit={async (reason) => { const r = cancel; setCancel(null); try { await post(`/api/hr/leaves/${r.id}/cancel`, { reason }); onChanged(); } catch (e: any) { toast('error', e.message); } }} />}
    </div>
  );
}
function Leaves() {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [status, setStatus] = useState('pending');
  const [rows, setRows] = useState<any[]>([]);
  const [add, setAdd] = useState<any>(null);
  const { meta } = useMeta();
  const load = useCallback(() => { get(`/api/hr/leaves${status ? `?status=${status}` : ''}`).then(setRows).catch(err(toast)); }, [status]);
  useEffect(load, [load]);
  const team = can('hr.manage') || can('hr.team');
  return (
    <>
      <div className="row">
        <div className="seg">{['pending', 'approved', 'refused', ''].map((s) => <button key={s} className={status === s ? 'on' : ''} onClick={() => setStatus(s)}>{s ? t(`rh.ls_${s}` as Key) : t('rh.all')}</button>)}</div>
        <span style={{ flex: 1 }} />
        {team && <select className="input" style={{ width: 'auto' }} aria-label={t('rh.newLeave')} value="" onChange={(e) => { const emp = meta?.employees.find((x: any) => String(x.id) === e.target.value); if (emp) setAdd(emp); }}>
          <option value="">+ {t('rh.newLeaveFor')}</option>{(meta?.employees ?? []).map((e: any) => <option key={e.id} value={e.id}>{name(e)}</option>)}</select>}
        {can('hr.self') && <button className="btn primary" onClick={() => setAdd({})}><Icon name="plus" size={14} />{t('rh.myRequest')}</button>}
      </div>
      <LeaveTable rows={rows} onChanged={load} />
      {add && <LeaveModal employee={add.id ? add : undefined} onClose={() => setAdd(null)} onDone={() => { setAdd(null); load(); }} />}
    </>
  );
}

// ===================================================== Paie =====================================================
function Payroll() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [runs, setRuns] = useState<any[]>([]);
  const [open, setOpen] = useState<any>(null);
  const [period, setPeriod] = useState(todayLocal().slice(0, 7));
  const [pay, setPay] = useState<any>(null);
  const [adv, setAdv] = useState<any[]>([]);
  const load = useCallback(() => {
    get('/api/hr/payroll').then(setRuns).catch(err(toast));
    get('/api/hr/advances').then(setAdv).catch(() => {});
  }, []);
  useEffect(load, [load]);
  const openRun = (id: number) => get(`/api/hr/payroll/${id}`).then(setOpen).catch(err(toast));
  const act = async (fn: () => Promise<any>, msg: string) => { try { await fn(); toast('success', msg); load(); if (open) openRun(open.id); } catch (e: any) { toast('error', e.message); } };
  return (
    <>
      {can('hr.payroll') && (
        <div className="row">
          <input type="month" className="input" style={{ width: 170 }} aria-label={t('rh.month')} max={todayLocal().slice(0, 7)} value={period} onChange={(e) => setPeriod(e.target.value)} />
          <button className="btn primary" onClick={() => act(async () => { const r = await post('/api/hr/payroll/compute', { period }); await openRun(r.id); }, t('rh.computed'))}>{t('rh.compute')}</button>
          <span className="muted" style={{ fontSize: 12.5 }}>{t('rh.payrollHint')}</span>
        </div>
      )}
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('rh.month')}</th><th>{t('rh.status')}</th><th className="num">{t('rh.slips')}</th><th className="num">{t('rh.gross')}</th><th className="num">{t('rh.net')}</th><th className="num">{t('rh.employerCharges')}</th><th>{t('rh.computedBy')}</th><th>{t('rh.validatedBy')}</th></tr></thead>
          <tbody>
            {!runs.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
            {runs.map((r) => <tr key={r.id} style={{ cursor: 'pointer', opacity: r.status === 'cancelled' ? 0.5 : 1 }} onClick={() => openRun(r.id)}><td><b>{r.period}</b></td><td><span className="pill">{t(`rh.ps_${r.status}` as Key)}</span>{r.warnings?.length ? ' ⚠' : ''}</td>
              <td className="num">{r.slips}</td><td className="num">{money(Number(r.gross_total), locale)}</td><td className="num"><b>{money(Number(r.net_total), locale)}</b></td><td className="num">{money(Number(r.employer_total), locale)}</td><td>{r.computed_name ?? ''}</td><td>{r.validated_name ?? ''}</td></tr>)}
          </tbody>
        </table>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('rh.advances')}</h3>
        <table className="table">
          <thead><tr><th>{t('rh.date')}</th><th>{t('rh.employee')}</th><th className="num">{t('rh.amount')}</th><th className="num">{t('rh.repaid')}</th><th>{t('rh.installments')}</th><th>{t('rh.status')}</th></tr></thead>
          <tbody>
            {!adv.length && <tr><td colSpan={6} className="muted">{t('common.none')}</td></tr>}
            {adv.map((a) => <tr key={a.id}><td>{d10(a.advance_date)}</td><td>{name(a)}</td><td className="num">{money(Number(a.amount), locale)}</td><td className="num">{money(Number(a.repaid), locale)}</td><td>{a.installments} × {t('rh.from').toLowerCase()} {a.first_period}</td><td>{t(`rh.as_${a.status}` as Key)}</td></tr>)}
          </tbody>
        </table>
      </div>
      {open && (
        <Modal title={`${t('rh.payrollOf')} ${open.period}`} onClose={() => setOpen(null)} size="lg">
          <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
            <span className="pill">{t(`rh.ps_${open.status}` as Key)}</span>
            <span>{t('rh.gross')} <b>{money(Number(open.gross_total), locale)}</b></span><span>{t('rh.net')} <b>{money(Number(open.net_total), locale)}</b></span><span>{t('rh.employerCharges')} <b>{money(Number(open.employer_total), locale)}</b></span>
          </div>
          {(open.warnings ?? []).map((w: string, i: number) => <div key={i} className="alert" style={{ fontSize: 13, color: '#B45309', borderColor: '#B45309' }}>⚠ {w}</div>)}
          <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
            {open.status === 'draft' && can('hr.payroll') && <button className="btn" onClick={() => act(async () => { await post('/api/hr/payroll/compute', { period: open.period }); }, t('rh.computed'))}>{t('rh.recompute')}</button>}
            {open.status === 'draft' && can('hr.payroll') && <button className="btn primary" onClick={() => act(() => post(`/api/hr/payroll/${open.id}/validate`, {}), t('rh.validated'))}>{t('rh.validate')}</button>}
            {open.status === 'validated' && can('hr.payroll_pay') && <button className="btn primary" onClick={() => setPay({ method: 'transfer', reference: '' })}>{t('rh.pay')}</button>}
            {open.status === 'draft' && can('hr.payroll') && <button className="btn danger" onClick={() => act(() => post(`/api/hr/payroll/${open.id}/cancel`, {}), t('rh.saved')).then(() => setOpen(null))}>{t('common.cancel')}</button>}
            <span style={{ flex: 1 }} />
            {['pdf', 'xlsx', 'csv'].map((f) => <button key={f} className="btn sm" onClick={() => window.open(`/api/hr/payroll/${open.id}/export?format=${f}`, '_blank')}>{f === 'xlsx' ? 'Excel' : f.toUpperCase()}</button>)}
          </div>
          <span className="muted" style={{ fontSize: 12.5 }}>{t('rh.crossCheck')}</span>
          <table className="table">
            <thead><tr><th>{t('rh.employee')}</th><th className="num">{t('rh.baseSalary')}</th><th className="num">{t('rh.absences')}</th><th className="num">{t('rh.overtime')}</th><th className="num">{t('rh.gross')}</th><th className="num">{t('rh.contribs')}</th><th className="num">{t('rh.tax')}</th><th className="num">{t('rh.deductions')}</th><th className="num">{t('rh.net')}</th><th /></tr></thead>
            <tbody>{open.slips.map((p: any) => <tr key={p.id}><td><b>{p.full_name}</b><div className="muted" style={{ fontSize: 11.5 }}>{p.matricule} · {p.position ?? ''}</div></td><td className="num">{money(Number(p.base_salary), locale)}</td>
              <td className="num">{Number(p.absence_deduction) ? `− ${money(Number(p.absence_deduction), locale)}` : ''}</td><td className="num">{Number(p.overtime_amount) ? money(Number(p.overtime_amount), locale) : ''}</td><td className="num">{money(Number(p.gross), locale)}</td>
              <td className="num">{money(Number(p.employee_contrib), locale)}</td><td className="num">{money(Number(p.tax), locale)}</td><td className="num">{Number(p.deductions) + Number(p.advances) ? money(Number(p.deductions) + Number(p.advances), locale) : ''}</td>
              <td className="num"><b>{money(Number(p.net), locale)}</b></td><td><a className="btn sm" href={`/api/hr/payslips/${p.id}/pdf`} target="_blank" rel="noreferrer">PDF</a></td></tr>)}</tbody>
          </table>
          {pay && (
            <Modal title={t('rh.pay')} onClose={() => setPay(null)} size="sm" footer={<><button className="btn" onClick={() => setPay(null)}>{t('common.cancel')}</button><button className="btn primary" onClick={() => { const p = pay; setPay(null); act(() => post(`/api/hr/payroll/${open.id}/pay`, { method: p.method, reference: p.reference || null }), t('rh.paid')); }}>{t('common.confirm')}</button></>}>
              <Field label={t('rh.method')}><select className="input" value={pay.method} onChange={(e) => setPay({ ...pay, method: e.target.value })}>{['transfer', 'cheque', 'cash'].map((m) => <option key={m} value={m}>{t(`rh.m_${m}` as Key)}</option>)}</select></Field>
              <Field label={t('rh.reference')}><input className="input" value={pay.reference} onChange={(e) => setPay({ ...pay, reference: e.target.value })} /></Field>
              <span className="muted" style={{ fontSize: 12.5 }}>{t('rh.payHint')}</span>
            </Modal>
          )}
        </Modal>
      )}
    </>
  );
}

// ===================================================== Documents =====================================================
function Documents({ openEmp }: { openEmp: (id: number) => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [exp, setExp] = useState(true);
  const [rows, setRows] = useState<any[]>([]);
  useEffect(() => { get(`/api/hr/documents${exp ? '?expiring=60' : ''}`).then(setRows).catch(err(toast)); }, [exp]);
  const T = todayLocal();
  return (
    <>
      <div className="row"><div className="seg"><button className={exp ? 'on' : ''} onClick={() => setExp(true)}>{t('rh.expiring60')}</button><button className={!exp ? 'on' : ''} onClick={() => setExp(false)}>{t('rh.all')}</button></div></div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('rh.employee')}</th><th>{t('rh.docKind')}</th><th>{t('rh.docTitle')}</th><th>{t('rh.expiryDate')}</th><th /></tr></thead>
          <tbody>
            {!rows.length && <tr><td colSpan={5} className="muted">{t('common.none')}</td></tr>}
            {rows.map((d) => { const x = d10(d.expiry_date); return (
              <tr key={d.id} style={{ cursor: 'pointer' }} onClick={() => openEmp(d.employee_id)}><td>{d.matricule} · {name(d)}</td><td>{d.kind}{d.confidential ? ' 🔒' : ''}</td><td>{d.title}</td>
                <td style={{ color: x && x < T ? 'var(--danger)' : x && x <= addDays(T, 30) ? '#B45309' : undefined, fontWeight: 600 }}>{x ? fmtDate(x, locale, { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}</td><td>{(d.files ?? []).length ? `📄 ${d.files.length}` : ''}</td></tr>
            ); })}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ===================================================== Rapports =====================================================
function Reports() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const kinds = ['headcount', 'attendance', 'late', 'overtime', 'leave', ...(can('hr.salary') ? ['payroll'] : []), 'contracts', 'performance'];
  const [kind, setKind] = useState(kinds[0]);
  const [p, setP] = useState({ from: `${todayLocal().slice(0, 8)}01`, to: todayLocal() });
  const [r, setR] = useState<any>(null);
  const qs = `from=${p.from}&to=${p.to}`;
  useEffect(() => { setR(null); get(`/api/hr/reports/${kind}?${qs}`).then(setR).catch(err(toast)); }, [kind, qs]);
  const fmt = (c: any, v: any) => (v === null || v === undefined || v === '' ? '—' : c.money ? money(Number(v), locale) : String(v));
  return (
    <>
      <div className="row">
        <select className="input" style={{ width: 'auto' }} aria-label={t('rh.t_reports')} value={kind} onChange={(e) => setKind(e.target.value)}>{kinds.map((k) => <option key={k} value={k}>{t(`rh.rp_${k}` as Key)}</option>)}</select>
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('rh.from')} value={p.from} onChange={(e) => e.target.value && setP({ ...p, from: e.target.value })} />
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('rh.to')} value={p.to} min={p.from} onChange={(e) => e.target.value && setP({ ...p, to: e.target.value })} />
        <span style={{ flex: 1 }} />
        {['pdf', 'xlsx', 'csv'].map((f) => <button key={f} className="btn" onClick={() => window.open(`/api/hr/reports/${kind}?${qs}&format=${f}`, '_blank')}>{f === 'xlsx' ? 'Excel' : f.toUpperCase()}</button>)}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{r?.title ?? '…'}</h3>
        <table className="table">
          <thead><tr>{(r?.columns ?? []).map((c: any) => <th key={c.key} className={c.money ? 'num' : ''}>{c.label}</th>)}</tr></thead>
          <tbody>
            {r && !r.rows.length && <tr><td colSpan={r.columns.length} className="muted">{t('common.none')}</td></tr>}
            {(r?.rows ?? []).map((x: any, i: number) => <tr key={i}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : 'wrap'}>{fmt(c, x[c.key])}</td>)}</tr>)}
            {r?.total && r.rows.length > 0 && <tr style={{ fontWeight: 700, background: 'var(--surface2)' }}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : ''}>{r.total[c.key] !== undefined ? fmt(c, r.total[c.key]) : ''}</td>)}</tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ===================================================== Paramètres =====================================================
function Settings() {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const { meta, reload } = useMeta();
  const [s, setS] = useState<any>(null);
  const [dlg, setDlg] = useState<any>(null);
  useEffect(() => { get('/api/hr/settings').then(setS).catch(err(toast)); }, []);
  if (!s) return <span>{t('common.loading')}</span>;
  const save = async () => { try { setS(await api('PUT', '/api/hr/settings', s)); toast('success', t('rh.saved')); } catch (e: any) { toast('error', e.message); } };
  const num = (k: string) => (e: any) => setS({ ...s, [k]: Number(e.target.value) });
  const pay = can('hr.payroll'), hr = can('hr.manage');
  const DAYS = [0, 1, 2, 3, 4, 5, 6];
  const createRef = async (url: string, body: any) => { try { await post(url, body); toast('success', t('rh.saved')); setDlg(null); reload(); } catch (e: any) { toast('error', e.message); } };
  return (
    <>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12, maxWidth: 900 }}>
        <h3 style={{ margin: 0 }}>{t('rh.timeRules')}</h3>
        <div className="form-grid">
          <Field label={t('rh.lateTolerance')}><input type="number" disabled={!hr} className="input" value={s.late_tolerance_minutes} onChange={num('late_tolerance_minutes')} /></Field>
          <Field label={t('rh.otThreshold')}><input type="number" disabled={!hr} className="input" value={s.overtime_threshold_minutes} onChange={num('overtime_threshold_minutes')} /></Field>
          <Field label={t('rh.minRest')}><input type="number" disabled={!hr} className="input" value={s.min_rest_hours} onChange={num('min_rest_hours')} /></Field>
          <Field label={t('rh.leavePerMonth')}><input type="number" step="0.5" disabled={!hr} className="input" value={s.leave_days_per_month} onChange={num('leave_days_per_month')} /></Field>
          <Field label={t('rh.contractAlert')}><input type="number" disabled={!hr} className="input" value={s.contract_alert_days} onChange={num('contract_alert_days')} /></Field>
          <Field label={t('rh.docAlert')}><input type="number" disabled={!hr} className="input" value={s.document_alert_days} onChange={num('document_alert_days')} /></Field>
        </div>
        <Field label={t('rh.weeklyRest')}><div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{DAYS.map((d) => <button key={d} type="button" disabled={!hr} className={`chip ${s.weekly_rest_days.includes(d) ? 'on' : ''}`} onClick={() => setS({ ...s, weekly_rest_days: s.weekly_rest_days.includes(d) ? s.weekly_rest_days.filter((x: number) => x !== d) : [...s.weekly_rest_days, d] })}>{t(`rh.wd_${d}` as Key)}</button>)}</div></Field>
        <h3 style={{ margin: '8px 0 0' }}>{t('rh.payRules')}</h3>
        <div className="alert" style={{ fontSize: 13 }}>{t('rh.legalNote')}</div>
        <div className="form-grid">
          <Field label={t('rh.monthlyHours')}><input type="number" disabled={!pay} className="input" value={s.monthly_hours} onChange={num('monthly_hours')} /></Field>
          <Field label={t('rh.dayDivisor')}><input type="number" disabled={!pay} className="input" value={s.day_divisor} onChange={num('day_divisor')} /></Field>
          <Field label={t('rh.otRate')}><input type="number" disabled={!pay} className="input" value={s.overtime_rate_percent} onChange={num('overtime_rate_percent')} /></Field>
          <Field label={t('rh.payrollCategory')}><input disabled={!pay} className="input" value={s.payroll_category} onChange={(e) => setS({ ...s, payroll_category: e.target.value })} /></Field>
        </div>
        <h4 style={{ margin: 0 }}>{t('rh.contributions')}</h4>
        {s.contributions.map((c: any, i: number) => (
          <div key={i} className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
            <input className="input" style={{ width: 90 }} aria-label="Code" disabled={!pay} value={c.code} onChange={(e) => setS({ ...s, contributions: s.contributions.map((x: any, j: number) => (j === i ? { ...x, code: e.target.value } : x)) })} />
            <input className="input" style={{ flex: 1, width: 'auto' }} aria-label={t('rh.label')} disabled={!pay} value={c.label} onChange={(e) => setS({ ...s, contributions: s.contributions.map((x: any, j: number) => (j === i ? { ...x, label: e.target.value } : x)) })} />
            <input type="number" step="0.01" className="input" style={{ width: 100 }} aria-label="%" disabled={!pay} value={c.rate} onChange={(e) => setS({ ...s, contributions: s.contributions.map((x: any, j: number) => (j === i ? { ...x, rate: Number(e.target.value) } : x)) })} />
            <select className="input" style={{ width: 'auto' }} aria-label={t('rh.side')} disabled={!pay} value={c.side} onChange={(e) => setS({ ...s, contributions: s.contributions.map((x: any, j: number) => (j === i ? { ...x, side: e.target.value } : x)) })}><option value="employee">{t('rh.sideEmployee')}</option><option value="employer">{t('rh.sideEmployer')}</option></select>
            {pay && <button className="btn ghost sm" onClick={() => setS({ ...s, contributions: s.contributions.filter((_: any, j: number) => j !== i) })}>✕</button>}
          </div>
        ))}
        {pay && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setS({ ...s, contributions: [...s.contributions, { code: '', label: '', rate: 0, side: 'employee' }] })}><Icon name="plus" size={14} />{t('rh.addContribution')}</button>}
        <h4 style={{ margin: 0 }}>{t('rh.taxBrackets')}</h4>
        {s.tax_brackets.map((b: any, i: number) => (
          <div key={i} className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
            <span className="muted">{t('rh.from')}</span><input type="number" className="input" style={{ width: 130 }} aria-label={t('rh.from')} disabled={!pay} value={b.from} onChange={(e) => setS({ ...s, tax_brackets: s.tax_brackets.map((x: any, j: number) => (j === i ? { ...x, from: Number(e.target.value) } : x)) })} />
            <span className="muted">{t('rh.to')}</span><input type="number" className="input" style={{ width: 130 }} aria-label={t('rh.to')} placeholder="∞" disabled={!pay} value={b.to ?? ''} onChange={(e) => setS({ ...s, tax_brackets: s.tax_brackets.map((x: any, j: number) => (j === i ? { ...x, to: e.target.value === '' ? null : Number(e.target.value) } : x)) })} />
            <input type="number" step="0.01" className="input" style={{ width: 90 }} aria-label="%" disabled={!pay} value={b.rate} onChange={(e) => setS({ ...s, tax_brackets: s.tax_brackets.map((x: any, j: number) => (j === i ? { ...x, rate: Number(e.target.value) } : x)) })} /><span>%</span>
            {pay && <button className="btn ghost sm" onClick={() => setS({ ...s, tax_brackets: s.tax_brackets.filter((_: any, j: number) => j !== i) })}>✕</button>}
          </div>
        ))}
        {pay && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setS({ ...s, tax_brackets: [...s.tax_brackets, { from: s.tax_brackets.length ? s.tax_brackets[s.tax_brackets.length - 1].to ?? 0 : 0, to: null, rate: 0 }] })}><Icon name="plus" size={14} />{t('rh.addBracket')}</button>}
        <button className="btn primary" style={{ alignSelf: 'flex-start' }} onClick={save}>{t('common.save')}</button>
      </div>
      {hr && (
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 14, alignItems: 'start' }}>
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div className="row between"><h3 style={{ margin: 0 }}>{t('rh.departments')}</h3><button className="btn sm" onClick={() => setDlg({ k: 'dept', code: '', name: '' })}><Icon name="plus" size={14} /></button></div>
            {(meta?.departments ?? []).map((d: any) => (
              <div key={d.id} className="sum-row" style={{ fontSize: 13, opacity: d.active ? 1 : 0.5 }}>
                <span>{d.name} <span className="muted">· {d.code}</span></span>
                <select className="input" style={{ width: 'auto', maxWidth: 170 }} aria-label={t('rh.deptManager')} value={d.manager_employee_id ?? ''} onChange={async (e) => { try { await patch(`/api/hr/departments/${d.id}`, { manager_employee_id: e.target.value ? Number(e.target.value) : null }); reload(); } catch (x: any) { toast('error', x.message); } }}>
                  <option value="">{t('rh.noManager')}</option>{(meta?.employees ?? []).map((e: any) => <option key={e.id} value={e.id}>{name(e)}</option>)}
                </select>
              </div>
            ))}
          </div>
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div className="row between"><h3 style={{ margin: 0 }}>{t('rh.positions')}</h3><button className="btn sm" onClick={() => setDlg({ k: 'pos', department: 'reception', name: '', default_salary: '' })}><Icon name="plus" size={14} /></button></div>
            {!(meta?.positions ?? []).length && <span className="muted">{t('common.none')}</span>}
            {(meta?.positions ?? []).map((p: any) => <div key={p.id} className="sum-row" style={{ fontSize: 13 }}><span>{p.name} <span className="muted">· {deptName(meta, p.department)}</span></span>{p.default_salary && can('hr.salary') ? <b>{money(Number(p.default_salary))}</b> : null}</div>)}
          </div>
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div className="row between"><h3 style={{ margin: 0 }}>{t('rh.shiftTypes')}</h3><button className="btn sm" onClick={() => setDlg({ k: 'shift', code: '', name: '', start_time: '09:00', end_time: '17:00', break_minutes: 30, color: '#0E7490' })}><Icon name="plus" size={14} /></button></div>
            {(meta?.shift_types ?? []).map((x: any) => <div key={x.id} className="sum-row" style={{ fontSize: 13 }}><span><span className="pill" style={{ background: x.color, color: '#fff' }}>{x.code}</span> {x.name}</span><span>{t5(x.start_time)}–{t5(x.end_time)} · {x.break_minutes} min</span></div>)}
          </div>
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div className="row between"><h3 style={{ margin: 0 }}>{t('rh.leaveTypes')}</h3><button className="btn sm" onClick={() => setDlg({ k: 'ltype', code: '', name: '', paid: true, deducts_balance: false, hourly: false, requires_document: false, justified: true })}><Icon name="plus" size={14} /></button></div>
            {(meta?.leave_types ?? []).map((x: any) => <div key={x.id} className="sum-row" style={{ fontSize: 13 }}><span><span className="pill" style={{ background: x.color, color: '#fff' }}>{x.name}</span></span><span className="muted">{x.paid ? t('rh.paidLeave') : t('rh.unpaidLeave')}{x.deducts_balance ? ` · ${t('rh.deducts')}` : ''}{x.hourly ? ` · ${t('rh.hourly')}` : ''}</span></div>)}
          </div>
        </div>
      )}
      {dlg?.k === 'dept' && <Modal title={t('rh.departments')} onClose={() => setDlg(null)} size="sm" footer={<button className="btn primary" onClick={() => createRef('/api/hr/departments', { code: dlg.code, name: dlg.name })}>{t('common.save')}</button>}>
        <Field label="Code"><input className="input" value={dlg.code} onChange={(e) => setDlg({ ...dlg, code: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '') })} /></Field>
        <Field label={t('rh.name')}><input className="input" value={dlg.name} onChange={(e) => setDlg({ ...dlg, name: e.target.value })} /></Field></Modal>}
      {dlg?.k === 'pos' && <Modal title={t('rh.positions')} onClose={() => setDlg(null)} size="sm" footer={<button className="btn primary" onClick={() => createRef('/api/hr/positions', { department: dlg.department, name: dlg.name, default_salary: dlg.default_salary ? toNum(dlg.default_salary) : null })}>{t('common.save')}</button>}>
        <Field label={t('rh.department')}><select className="input" value={dlg.department} onChange={(e) => setDlg({ ...dlg, department: e.target.value })}>{(meta?.departments ?? []).map((d: any) => <option key={d.code} value={d.code}>{d.name}</option>)}</select></Field>
        <Field label={t('rh.name')}><input className="input" value={dlg.name} onChange={(e) => setDlg({ ...dlg, name: e.target.value })} /></Field>
        {can('hr.salary') && <Field label={t('rh.baseSalary')}><input className="input" value={dlg.default_salary} onChange={(e) => setDlg({ ...dlg, default_salary: e.target.value })} /></Field>}</Modal>}
      {dlg?.k === 'shift' && <Modal title={t('rh.shiftTypes')} onClose={() => setDlg(null)} size="sm" footer={<button className="btn primary" onClick={() => createRef('/api/hr/shift-types', { ...dlg, k: undefined, break_minutes: Number(dlg.break_minutes) })}>{t('common.save')}</button>}>
        <div className="form-grid"><Field label="Code"><input className="input" maxLength={4} value={dlg.code} onChange={(e) => setDlg({ ...dlg, code: e.target.value.toUpperCase() })} /></Field><Field label={t('rh.name')}><input className="input" value={dlg.name} onChange={(e) => setDlg({ ...dlg, name: e.target.value })} /></Field>
          <Field label={t('rh.fromTime')}><input type="time" className="input" value={dlg.start_time} onChange={(e) => setDlg({ ...dlg, start_time: e.target.value })} /></Field><Field label={t('rh.toTime')}><input type="time" className="input" value={dlg.end_time} onChange={(e) => setDlg({ ...dlg, end_time: e.target.value })} /></Field>
          <Field label={`${t('rh.break')} (min)`}><input type="number" className="input" value={dlg.break_minutes} onChange={(e) => setDlg({ ...dlg, break_minutes: e.target.value })} /></Field><Field label={t('rh.color')}><input type="color" className="input" value={dlg.color} onChange={(e) => setDlg({ ...dlg, color: e.target.value })} /></Field></div></Modal>}
      {dlg?.k === 'ltype' && <Modal title={t('rh.leaveTypes')} onClose={() => setDlg(null)} size="sm" footer={<button className="btn primary" onClick={() => createRef('/api/hr/leave-types', { ...dlg, k: undefined })}>{t('common.save')}</button>}>
        <Field label="Code"><input className="input" value={dlg.code} onChange={(e) => setDlg({ ...dlg, code: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '') })} /></Field>
        <Field label={t('rh.name')}><input className="input" value={dlg.name} onChange={(e) => setDlg({ ...dlg, name: e.target.value })} /></Field>
        {(['paid', 'deducts_balance', 'hourly', 'requires_document', 'justified'] as const).map((k) => <label key={k} className="row" style={{ gap: 8 }}><input type="checkbox" checked={dlg[k]} onChange={(e) => setDlg({ ...dlg, [k]: e.target.checked })} />{t(`rh.lt_${k}` as Key)}</label>)}</Modal>}
    </>
  );
}

// ===================================================== Borne de pointage =====================================================
export function ClockTerminal() {
  const { t, locale } = useI18n();
  const [m, setM] = useState('');
  const [pin, setPin] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [now, setNow] = useState(new Date());
  useEffect(() => { const i = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(i); }, []);
  useEffect(() => { if (!msg) return; const i = setTimeout(() => setMsg(null), 5000); return () => clearTimeout(i); }, [msg]);
  const submit = async (action = 'toggle') => {
    try {
      const r = await post('/api/hr/terminal/clock', { matricule: m, pin, action });
      setMsg({ ok: true, text: `${r.name} — ${t(`rh.clk_${r.action}` as Key)} ${timeOf(r.action === 'out' ? r.clock_out : new Date().toISOString(), locale)}${r.late_minutes && r.action === 'in' ? ` · ${t('rh.late')} ${r.late_minutes} min` : ''}` });
    } catch (e: any) { setMsg({ ok: false, text: e.message }); }
    setPin(''); setM('');
  };
  const key = (k: string) => setPin((p) => (k === '⌫' ? p.slice(0, -1) : p.length < 6 ? p + k : p));
  return (
    <Page>
      <div style={{ maxWidth: 420, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 14, textAlign: 'center' }}>
        <div style={{ fontSize: 46, fontWeight: 700, color: '#7A1F2B' }}>{now.toLocaleTimeString(locale === 'ar' ? 'ar-DZ' : locale, { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</div>
        <div className="muted">{now.toLocaleDateString(locale === 'ar' ? 'ar-DZ' : locale, { weekday: 'long', day: 'numeric', month: 'long' })}</div>
        {msg && <div className="alert" style={{ fontSize: 16, fontWeight: 600, color: msg.ok ? '#166534' : 'var(--danger)', borderColor: msg.ok ? '#166534' : 'var(--danger)' }}>{msg.text}</div>}
        <input className="input" style={{ fontSize: 22, textAlign: 'center' }} placeholder={t('rh.matricule')} aria-label={t('rh.matricule')} value={m} onChange={(e) => setM(e.target.value.toUpperCase())} autoFocus />
        <input className="input" style={{ fontSize: 22, textAlign: 'center', letterSpacing: 8 }} type="password" inputMode="numeric" placeholder={t('rh.pinCode')} aria-label={t('rh.pinCode')} value={pin} readOnly />
        <div className="grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', '⌫', '0', '✓'].map((k) => <button key={k} className={`btn ${k === '✓' ? 'primary' : ''}`} style={{ fontSize: 22, padding: '16px 0' }} disabled={k === '✓' && (!m || pin.length < 4)} onClick={() => (k === '✓' ? submit() : key(k))}>{k}</button>)}
        </div>
        <div className="row" style={{ gap: 8, justifyContent: 'center' }}>
          <button className="btn" disabled={!m || pin.length < 4} onClick={() => submit('break_start')}>{t('rh.breakStart')}</button>
          <button className="btn" disabled={!m || pin.length < 4} onClick={() => submit('break_end')}>{t('rh.breakEnd')}</button>
        </div>
        <span className="muted" style={{ fontSize: 12.5 }}>{t('rh.terminalHint')}</span>
      </div>
    </Page>
  );
}
