import { useCallback, useEffect, useMemo, useState } from 'react';
import { currency } from '../lib/format';
import { useSearchParams } from 'react-router-dom';
import { BarChart, LineChart, PieChart } from '../components/AnalyticsCharts';
import { Page } from '../components/Layout';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { del, get, patch, post } from '../lib/api';
import { useToast } from '../lib/context';
import { useRL } from '../lib/reportLabels';
import { useAuth } from '../lib/context';
import { MonthlyAccounts } from '../components/MonthlyAccounts';

type Unit = 'money' | 'pct' | 'int' | 'num' | 'days' | 'hours' | 'min' | 'score';
type Kpi = { key: string; label: string; value: number | null; prev: number | null; unit: Unit; better?: 'up' | 'down' | null; hint?: string; drill?: string };
type Chart = { key: string; title: string; type: 'line' | 'bar' | 'pie'; unit: Unit; labels: string[]; series: { name: string; values: number[] }[] };
type Col = { key: string; label: string; money?: boolean; unit?: Unit };
type Table = { key: string; title: string; columns: Col[]; rows: any[]; total?: any; drill?: string };
type Layout = { hidden?: { kpis?: string[]; charts?: string[]; tables?: string[] }; order?: { kpis?: string[]; charts?: string[]; tables?: string[] } };
type Filt = Record<string, string>;

const PRESETS = ['today', 'yesterday', 'week', 'month', 'last_month', 'year', 'last_year', 'custom'];
const FKEYS = ['room_type_id', 'floor_id', 'source', 'status', 'outlet', 'category', 'department'];

function useFmt() {
  const { locale } = useI18n();
  const nf = (n: number, d = 2) => new Intl.NumberFormat(locale, { maximumFractionDigits: d, minimumFractionDigits: 0 }).format(n);
  return (unit: Unit | undefined, v: any): string => {
    if (v === null || v === undefined || v === '') return '—';
    if (typeof v === 'string' && Number.isNaN(Number(v))) return v;
    const n = Number(v);
    switch (unit) {
      case 'money': return `${nf(n)} ${currency.symbol}`;
      case 'pct': return `${nf(n, 1)} %`;
      case 'int': return nf(n, 0);
      case 'days': return `${nf(n, 1)} j`;
      case 'hours': return `${nf(n, 1)} h`;
      case 'min': return `${nf(n, 0)} min`;
      case 'score': return `${nf(n, 2)} / 5`;
      default: return nf(n);
    }
  };
}
const qsOf = (f: Filt, extra: Record<string, any> = {}) => new URLSearchParams(Object.entries({ ...f, ...extra }).filter(([, v]) => v !== '' && v !== undefined && v !== null).map(([k, v]) => [k, String(v)])).toString();
function ordered<T extends { key: string }>(items: T[], order?: string[], hidden?: string[], showHidden = false) {
  const pos = (k: string) => { const i = order?.indexOf(k) ?? -1; return i < 0 ? 1000 + items.findIndex((x) => x.key === k) : i; };
  return [...items].sort((a, b) => pos(a.key) - pos(b.key)).filter((x) => showHidden || !hidden?.includes(x.key));
}

export function Reports() {
  const { can } = useAuth();
  const { t } = useI18n();
  const toast = useToast();
  const L = useRL();
  const fmt = useFmt();
  const [sp, setSp] = useSearchParams();
  const [meta, setMeta] = useState<any>(null);
  const [views, setViews] = useState<any[]>([]);
  const domain = meta?.domains.find((d: any) => d.key === sp.get('d'))?.key ?? meta?.domains[0]?.key;
  const dmeta = meta?.domains.find((d: any) => d.key === domain);
  const filt: Filt = useMemo(() => {
    const f: Filt = { preset: sp.get('preset') ?? 'year', compare: sp.get('compare') ?? 'prev', group: sp.get('group') ?? (sp.get('preset') ? '' : 'month') };
    if (f.preset === 'custom') { f.from = sp.get('from') ?? ''; f.to = sp.get('to') ?? ''; }
    for (const k of FKEYS) if (sp.get(k) && dmeta?.filters.includes(k)) f[k] = sp.get(k)!;
    return f;
  }, [sp, dmeta]);
  const setF = (patchF: Filt, d = domain) => { const n: Filt = { d, ...filt, ...patchF }; for (const k of Object.keys(n)) if (n[k] === '') delete n[k]; setSp(n as any, { replace: true }); };
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [custom, setCustom] = useState(false);
  const [layout, setLayout] = useState<Layout>({});
  const [drill, setDrill] = useState<{ key: string; extra?: Filt } | null>(null);
  const [saveDlg, setSaveDlg] = useState<any>(null);
  const [report, setReport] = useState<string>('');

  const loadViews = useCallback(() => get('/api/analytics/views').then(setViews).catch(() => {}), []);
  useEffect(() => { get('/api/analytics/meta').then(setMeta).catch((e) => setError(e.message)); loadViews(); }, []);
  // Vue par défaut : la mienne, sinon celle de mon rôle
  useEffect(() => {
    if (!domain) return;
    const mine = views.find((v) => v.kind === 'layout' && v.domain === domain && v.is_default && !v.role_view);
    const role = views.find((v) => v.kind === 'layout' && v.domain === domain && v.is_default && v.role_view);
    setLayout((mine ?? role)?.config ?? {});
  }, [domain, views]);
  const valid = filt.preset !== 'custom' || (filt.from && filt.to);
  const load = useCallback((fresh = false) => {
    if (!domain || !valid) return;
    setLoading(true); setError(null);
    get(`/api/analytics/${domain}?${qsOf(filt, fresh ? { fresh: 1 } : {})}`).then(setData).catch((e) => setError(e.message)).finally(() => setLoading(false));
  }, [domain, JSON.stringify(filt)]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { setReport(''); }, [domain]);

  if (error && !meta) return <Page><div className="alert">{error}</div></Page>;
  if (!meta) return <Page><span>{t('common.loading')}</span></Page>;
  if (!meta.domains.length) return <Page><div className="alert">{t('rp.noAccess')}</div></Page>;

  const opts = (k: string): { value: any; label: string }[] => {
    const o = meta.options[k];
    if (!o) return [];
    if (Array.isArray(o)) return o;
    return o[domain] ?? [];
  };
  const filtersFav = views.filter((v) => v.kind === 'filter' && (v.domain === domain || v.domain === '*'));
  const reportsSaved = views.filter((v) => v.kind === 'report');
  const kpis: Kpi[] = data ? ordered(data.kpis, layout.order?.kpis, layout.hidden?.kpis, custom) : [];
  const charts: Chart[] = data ? ordered(data.charts, layout.order?.charts, layout.hidden?.charts, custom) : [];
  const tables: Table[] = data ? ordered(data.tables, layout.order?.tables, layout.hidden?.tables, custom) : [];
  const toggle = (sec: 'kpis' | 'charts' | 'tables', k: string) => setLayout((l) => { const h = l.hidden?.[sec] ?? []; return { ...l, hidden: { ...l.hidden, [sec]: h.includes(k) ? h.filter((x) => x !== k) : [...h, k] } }; });
  const move = (sec: 'kpis' | 'charts' | 'tables', k: string, dir: -1 | 1) => setLayout((l) => {
    const all = ordered((data[sec] as any[]), l.order?.[sec], [], true).map((x) => x.key);
    const i = all.indexOf(k), j = i + dir;
    if (j < 0 || j >= all.length) return l;
    [all[i], all[j]] = [all[j], all[i]];
    return { ...l, order: { ...l.order, [sec]: all } };
  });
  const exportUrl = (fmtx: string) => `/api/analytics/${domain}/export?${qsOf(filt, { format: fmtx })}`;
  const P = data?.period;
  const periodTxt = P ? `${P.from.split('-').reverse().join('/')} → ${P.to.split('-').reverse().join('/')}${P.pfrom ? ` · ${t('rp.vs')} ${P.pfrom.split('-').reverse().join('/')} → ${P.pto.split('-').reverse().join('/')}` : ''}` : '';
  const Ctl = ({ sec, k }: { sec: 'kpis' | 'charts' | 'tables'; k: string }) => custom ? (
    <span className="row" style={{ gap: 2, flexWrap: 'nowrap' }} onClick={(e) => e.stopPropagation()}>
      <button className="btn ghost sm" aria-label={t('rp.moveUp')} onClick={() => move(sec, k, -1)}>↑</button>
      <button className="btn ghost sm" aria-label={t('rp.moveDown')} onClick={() => move(sec, k, 1)}>↓</button>
      <label className="chip" style={{ padding: '2px 8px' }}><input type="checkbox" checked={!layout.hidden?.[sec]?.includes(k)} onChange={() => toggle(sec, k)} /> {t('rp.shown')}</label>
    </span>
  ) : null;

  return (
    <Page>
      <div className="page-head" style={{ flexWrap: 'wrap', gap: 8 }}>
        <h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('rp.title')}</h1>
        {reportsSaved.length > 0 && (
          <select className="input" style={{ width: 'auto' }} aria-label={t('rp.savedReports')} value="" onChange={(e) => {
            const v = views.find((x) => x.id === Number(e.target.value)); if (!v) return;
            setSp({ d: v.domain, ...v.config.filters }, { replace: true }); setTimeout(() => setReport(v.config.report ?? ''), 50);
          }}>
            <option value="">{t('rp.savedReports')} ({reportsSaved.length})</option>
            {reportsSaved.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
          </select>
        )}
      </div>
      {can('finance.reports') && <MonthlyAccounts />}
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>
        {meta.domains.map((d: any) => <button key={d.key} className={domain === d.key ? 'on' : ''} onClick={() => { const f: Filt = { d: d.key, preset: filt.preset, compare: filt.compare }; if (filt.preset === 'custom') { f.from = filt.from; f.to = filt.to; } if (filt.group) f.group = filt.group; setSp(f as any, { replace: true }); setCustom(false); }}>{t(`rp.d_${d.key}` as Key)}</button>)}
      </div>

      {/* ------------------------------------------------ Filtres globaux */}
      <div className="card no-print" style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end', padding: 12 }}>
        <Field label={t('rp.period')}><select className="input" value={filt.preset} onChange={(e) => setF({ preset: e.target.value, ...(e.target.value === 'custom' ? { from: P?.from ?? '', to: P?.to ?? '' } : { from: '', to: '' }) })}>{PRESETS.map((p) => <option key={p} value={p}>{t(`rp.p_${p}` as Key)}</option>)}</select></Field>
        {filt.preset === 'custom' && <>
          <Field label={t('rp.from')}><input type="date" className="input" value={filt.from ?? ''} onChange={(e) => setF({ from: e.target.value })} /></Field>
          <Field label={t('rp.to')}><input type="date" className="input" value={filt.to ?? ''} min={filt.from} onChange={(e) => setF({ to: e.target.value })} /></Field>
        </>}
        <Field label={t('rp.compare')}><select className="input" value={filt.compare} onChange={(e) => setF({ compare: e.target.value })}><option value="prev">{t('rp.c_prev')}</option><option value="year">{t('rp.c_year')}</option><option value="none">{t('rp.c_none')}</option></select></Field>
        <Field label={t('rp.group')}><select className="input" value={filt.group} onChange={(e) => setF({ group: e.target.value })}><option value="">{t('rp.g_auto')}</option>{['day', 'week', 'month', 'year'].map((g) => <option key={g} value={g}>{t(`rp.g_${g}` as Key)}</option>)}</select></Field>
        {dmeta?.filters.map((k: string) => (
          <Field key={k} label={t(`rp.f_${k}` as Key)}>
            <select className="input" value={filt[k] ?? ''} onChange={(e) => setF({ [k]: e.target.value })}><option value="">{t('rp.all')}</option>{opts(k).map((o) => <option key={o.value} value={o.value}>{L(o.label)}</option>)}</select>
          </Field>
        ))}
        <span style={{ flex: 1 }} />
        {filtersFav.length > 0 && (
          <select className="input" style={{ width: 'auto' }} aria-label={t('rp.favorites')} value="" onChange={(e) => { const v = views.find((x) => x.id === Number(e.target.value)); if (v) setSp({ d: domain, ...v.config } as any, { replace: true }); }}>
            <option value="">★ {t('rp.favorites')}</option>{filtersFav.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
          </select>
        )}
        <button className="btn" title={t('rp.saveFilter')} onClick={() => setSaveDlg({ kind: 'filter', name: '' })}>☆</button>
        <button className="btn" onClick={() => load(true)} disabled={loading} title={t('rp.refresh')}>⟳</button>
      </div>

      <div className="row no-print" style={{ gap: 8, flexWrap: 'wrap' }}>
        <span className="muted" style={{ fontSize: 13 }}>{periodTxt}{data?.ms !== undefined ? ` · ${data.ms} ms` : ''}</span>
        <span style={{ flex: 1 }} />
        <button className={`btn ${custom ? 'primary' : ''}`} onClick={() => setCustom(!custom)}><Icon name="gear" size={14} />{custom ? t('rp.doneCustom') : t('rp.customize')}</button>
        {custom && <button className="btn" onClick={() => setSaveDlg({ kind: 'layout', name: `${t(`rp.d_${domain}` as Key)}`, is_default: true, role_code: '' })}>{t('rp.saveLayout')}</button>}
        {custom && <button className="btn ghost" onClick={() => setLayout({})}>{t('rp.resetLayout')}</button>}
        {['pdf', 'xlsx', 'csv'].map((f) => <a key={f} className="btn" href={exportUrl(f)} target="_blank" rel="noreferrer">{f === 'xlsx' ? 'Excel' : f.toUpperCase()}</a>)}
      </div>

      {error && <div className="alert" role="alert">{error} <button className="btn sm" onClick={() => load(true)}>{t('rp.retry')}</button></div>}
      {loading && !data && <div className="grid kpis">{Array.from({ length: 8 }).map((_, i) => <div key={i} className="card kpi skeleton" style={{ height: 92, opacity: 0.5 }} />)}</div>}

      {data && data.domain === domain && <div style={{ opacity: loading ? 0.55 : 1, transition: 'opacity .2s', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {/* ------------------------------------------------ Indicateurs */}
        <div className="grid kpis" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(210px, 1fr))' }}>
          {kpis.map((k) => <KpiCard key={k.key} k={k} fmt={fmt} hidden={layout.hidden?.kpis?.includes(k.key)} onDrill={k.drill && !custom ? () => setDrill({ key: k.drill! }) : undefined} ctl={<Ctl sec="kpis" k={k.key} />} />)}
        </div>
        {/* ------------------------------------------------ Graphiques */}
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 460px), 1fr))', gap: 14, alignItems: 'start' }}>
          {charts.map((c) => (
            <div key={c.key} className="card" style={{ display: 'flex', flexDirection: 'column', gap: 8, opacity: layout.hidden?.charts?.includes(c.key) ? 0.4 : 1, minWidth: 0 }}>
              <div className="row between" style={{ gap: 6 }}><h3 style={{ margin: 0, fontSize: 15 }}>{L(c.title)}</h3><Ctl sec="charts" k={c.key} /></div>
              {(() => { const props = { labels: c.labels.map((x) => L(x)), series: c.series.map((s) => ({ ...s, name: L(s.name) })), format: (n: number) => fmt(c.unit, n) };
                return c.type === 'line' ? <LineChart {...props} /> : c.type === 'bar' ? <BarChart {...props} /> : <PieChart {...props} />; })()}
            </div>
          ))}
        </div>
        {/* ------------------------------------------------ Tableaux */}
        {tables.map((tb) => (
          <div key={tb.key} className="card" style={{ padding: 0, overflow: 'auto', opacity: layout.hidden?.tables?.includes(tb.key) ? 0.4 : 1 }}>
            <div className="row between" style={{ padding: '12px 14px 4px', gap: 6 }}>
              <h3 style={{ margin: 0, fontSize: 15 }}>{L(tb.title)}</h3>
              <span className="row" style={{ gap: 6 }}>{tb.drill && !custom && <button className="btn sm" onClick={() => setDrill({ key: tb.drill! })}>{t('rp.detail')}</button>}<Ctl sec="tables" k={tb.key} /></span>
            </div>
            <DataTable cols={tb.columns} rows={tb.rows} total={tb.total} fmt={fmt} L={L} pageSize={25} />
          </div>
        ))}
        {data.notes?.length > 0 && <div className="muted" style={{ fontSize: 12.5 }}>{data.notes.map((n: string) => <div key={n}>ⓘ {L(n)}</div>)}</div>}

        {/* ------------------------------------------------ Rapports détaillés des modules */}
        {dmeta?.reports.length > 0 && (
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
              <h3 style={{ margin: 0, fontSize: 15, marginInlineEnd: 'auto' }}>{t('rp.detailedReports')}</h3>
              <select className="input" style={{ width: 'auto', maxWidth: '100%' }} aria-label={t('rp.detailedReports')} value={report} onChange={(e) => setReport(e.target.value)}>
                <option value="">{t('rp.chooseReport')}</option>{dmeta.reports.map((r: any) => <option key={r.key} value={r.key}>{L(r.title)}</option>)}
              </select>
              {report && <button className="btn" onClick={() => setSaveDlg({ kind: 'report', name: L(dmeta.reports.find((r: any) => r.key === report)?.title ?? '') })}>☆ {t('rp.saveReport')}</button>}
            </div>
            {report && <CatalogReport domain={domain} kind={report} filt={filt} fmt={fmt} L={L} />}
          </div>
        )}
      </div>}

      {drill && <DrillModal dkey={drill.key} filt={{ ...filt, ...(drill.extra ?? {}) }} fmt={fmt} L={L} onClose={() => setDrill(null)} />}
      {saveDlg && (
        <Modal title={saveDlg.kind === 'filter' ? t('rp.saveFilter') : saveDlg.kind === 'report' ? t('rp.saveReport') : t('rp.saveLayout')} onClose={() => setSaveDlg(null)} size="sm"
          footer={<><button className="btn" onClick={() => setSaveDlg(null)}>{t('common.cancel')}</button><button className="btn primary" disabled={!saveDlg.name.trim()} onClick={async () => {
            const { d: _d, ...f } = Object.fromEntries(sp.entries());
            const config = saveDlg.kind === 'layout' ? layout : saveDlg.kind === 'report' ? { filters: f, report } : f;
            try {
              await post('/api/analytics/views', { kind: saveDlg.kind, domain: saveDlg.kind === 'report' ? domain : domain, name: saveDlg.name.trim(), config, is_default: !!saveDlg.is_default, role_code: saveDlg.role_code || null });
              toast('success', t('rp.saved')); setSaveDlg(null); setCustom(false); loadViews();
            } catch (e: any) { toast('error', e.message); }
          }}>{t('common.save')}</button></>}>
          <Field label={t('rp.name')}><input className="input" autoFocus value={saveDlg.name} onChange={(e) => setSaveDlg({ ...saveDlg, name: e.target.value })} /></Field>
          {saveDlg.kind === 'layout' && <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={saveDlg.is_default} onChange={(e) => setSaveDlg({ ...saveDlg, is_default: e.target.checked })} />{t('rp.asDefault')}</label>}
          {saveDlg.kind === 'layout' && meta.can_manage_roles && (
            <Field label={t('rp.forRole')}><select className="input" value={saveDlg.role_code} onChange={(e) => setSaveDlg({ ...saveDlg, role_code: e.target.value, is_default: e.target.value ? true : saveDlg.is_default })}><option value="">{t('rp.justMe')}</option>{meta.roles.map((r: any) => <option key={r.code} value={r.code}>{r.name}</option>)}</select></Field>
          )}
        </Modal>
      )}
      <ViewsManager views={views} reload={loadViews} domain={domain} />
    </Page>
  );
}

function KpiCard({ k, fmt, onDrill, ctl, hidden }: { k: Kpi; fmt: (u: Unit, v: any) => string; onDrill?: () => void; ctl: any; hidden?: boolean }) {
  const { t } = useI18n();
  const L = useRL();
  const v = k.prev !== null && k.value !== null ? k.value - k.prev : null;
  const rate = v !== null && k.prev ? (v / Math.abs(k.prev)) * 100 : null;
  const good = v === null || v === 0 || !k.better ? null : (v > 0) === (k.better === 'up');
  const color = good === null ? 'var(--muted)' : good ? '#15803D' : 'var(--danger)';
  return (
    <div className={`card kpi ${onDrill ? 'clickable' : ''}`} role={onDrill ? 'button' : undefined} tabIndex={onDrill ? 0 : undefined} onKeyDown={(e) => e.key === 'Enter' && onDrill?.()}
      style={{ cursor: onDrill ? 'pointer' : undefined, opacity: hidden ? 0.4 : 1, borderInlineStart: `4px solid ${good === null ? 'var(--border)' : color}` }} onClick={onDrill} title={onDrill ? t('rp.clickDetail') : undefined}>
      <span className="label row between" style={{ gap: 4 }}>{L(k.label)}{onDrill && <span aria-hidden style={{ fontSize: 11 }}>↗</span>}</span>
      <span className="value" style={{ fontSize: 22 }}>{fmt(k.unit, k.value)}</span>
      {v !== null ? (
        <span style={{ fontSize: 12.5, color }}>{v > 0 ? '▲' : v < 0 ? '▼' : '■'} {rate === null ? (v === 0 ? '0 %' : 'n.s.') : `${rate > 0 ? '+' : ''}${Math.round(rate * 10) / 10} %`} <span className="muted">({t('rp.before')} {fmt(k.unit, k.prev)})</span></span>
      ) : k.hint ? <span className="hint">{L(k.hint)}</span> : <span className="hint">{t('rp.snapshot')}</span>}
      {v !== null && k.hint && <span className="hint" style={{ fontSize: 11.5 }}>{L(k.hint)}</span>}
      {ctl}
    </div>
  );
}

function DataTable({ cols, rows, total, fmt, L, pageSize = 50, onPage, count, page }: { cols: Col[]; rows: any[]; total?: any; fmt: (u: Unit, v: any) => string; L: (s: string) => string; pageSize?: number; onPage?: (p: number) => void; count?: number; page?: number }) {
  const { t } = useI18n();
  const [p, setP] = useState(1);
  const [sort, setSort] = useState<{ k: string; dir: 1 | -1 } | null>(null);
  useEffect(() => setP(1), [rows]);
  const server = !!onPage;
  const sorted = useMemo(() => (sort && !server ? [...rows].sort((a, b) => { const x = a[sort.k], y = b[sort.k]; const nx = Number(x), ny = Number(y); return (Number.isNaN(nx) || Number.isNaN(ny) ? String(x ?? '').localeCompare(String(y ?? '')) : nx - ny) * sort.dir; }) : rows), [rows, sort]);
  const cur = server ? page ?? 1 : p;
  const n = server ? count ?? rows.length : rows.length;
  const pages = Math.max(1, Math.ceil(n / pageSize));
  const view = server ? sorted : sorted.slice((p - 1) * pageSize, p * pageSize);
  const isNum = (c: Col) => !!(c.unit || c.money);
  const cell = (c: Col, v: any) => (isNum(c) ? fmt(c.money ? 'money' : c.unit!, v) : v === null || v === undefined ? '' : L(String(v)));
  return (
    <>
      <table className="table">
        <thead><tr>{cols.map((c) => <th key={c.key} className={isNum(c) ? 'num' : ''} style={{ cursor: server ? undefined : 'pointer', whiteSpace: 'nowrap' }} onClick={() => !server && setSort((s) => (s?.k === c.key ? { k: c.key, dir: s.dir === 1 ? -1 : 1 } : { k: c.key, dir: isNum(c) ? -1 : 1 }))}>{L(c.label)}{sort?.k === c.key ? (sort.dir === 1 ? ' ▲' : ' ▼') : ''}</th>)}</tr></thead>
        <tbody>
          {!rows.length && <tr><td colSpan={cols.length} className="muted">{t('rp.noData')}</td></tr>}
          {view.map((r, i) => <tr key={i}>{cols.map((c) => <td key={c.key} className={isNum(c) ? 'num' : 'wrap'}>{cell(c, r[c.key])}</td>)}</tr>)}
          {total && rows.length > 0 && <tr style={{ fontWeight: 700, background: 'var(--surface2)' }}>{cols.map((c) => <td key={c.key} className={isNum(c) ? 'num' : ''}>{total[c.key] !== undefined ? cell(c, total[c.key]) : ''}</td>)}</tr>}
        </tbody>
      </table>
      {pages > 1 && (
        <div className="row" style={{ justifyContent: 'center', gap: 8, padding: 8 }}>
          <button className="btn sm" disabled={cur <= 1} onClick={() => (server ? onPage!(cur - 1) : setP(cur - 1))}>‹</button>
          <span className="muted" style={{ fontSize: 13 }}>{cur} / {pages} · {n} {t('rp.lines')}</span>
          <button className="btn sm" disabled={cur >= pages} onClick={() => (server ? onPage!(cur + 1) : setP(cur + 1))}>›</button>
        </div>
      )}
    </>
  );
}

function DrillModal({ dkey, filt, fmt, L, onClose }: { dkey: string; filt: Filt; fmt: (u: Unit, v: any) => string; L: (s: string) => string; onClose: () => void }) {
  const { t } = useI18n();
  const [page, setPage] = useState(1);
  const [d, setD] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { setErr(null); get(`/api/analytics/drill/${dkey}?${qsOf(filt, { page, size: 50 })}`).then(setD).catch((e) => setErr(e.message)); }, [dkey, page]);
  return (
    <Modal title={d ? L(d.title) : '…'} onClose={onClose} size="lg">
      <div className="row" style={{ gap: 6 }}>
        <span className="muted" style={{ fontSize: 13, marginInlineEnd: 'auto' }}>{d ? `${d.count} ${t('rp.lines')}` : ''}</span>
        {['pdf', 'xlsx', 'csv'].map((f) => <a key={f} className="btn sm" href={`/api/analytics/drill/${dkey}?${qsOf(filt, { format: f })}`} target="_blank" rel="noreferrer">{f === 'xlsx' ? 'Excel' : f.toUpperCase()}</a>)}
      </div>
      {err && <div className="alert">{err}</div>}
      {!d && !err && <span>{t('common.loading')}</span>}
      {d && <div style={{ overflow: 'auto' }}><DataTable cols={d.columns} rows={d.rows} total={d.total} fmt={fmt} L={L} pageSize={d.page_size} onPage={setPage} count={d.count} page={page} /></div>}
    </Modal>
  );
}

function CatalogReport({ domain, kind, filt, fmt, L }: { domain: string; kind: string; filt: Filt; fmt: (u: Unit, v: any) => string; L: (s: string) => string }) {
  const { t } = useI18n();
  const [page, setPage] = useState(1);
  const [r, setR] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);
  const q = qsOf(filt);
  useEffect(() => { setPage(1); }, [kind, q]);
  useEffect(() => { setR(null); setErr(null); get(`/api/analytics/catalog/${domain}/${kind}?${qsOf(filt, { page, size: 50 })}`).then(setR).catch((e) => setErr(e.message)); }, [domain, kind, q, page]);
  if (err) return <div className="alert">{err}</div>;
  if (!r) return <span>{t('common.loading')}</span>;
  return (
    <>
      <div className="row" style={{ gap: 6 }}>
        <b style={{ marginInlineEnd: 'auto' }}>{L(r.title)}</b>
        {['pdf', 'xlsx', 'csv'].map((f) => <a key={f} className="btn sm" href={`/api/analytics/catalog/${domain}/${kind}?${qsOf(filt, { format: f })}`} target="_blank" rel="noreferrer">{f === 'xlsx' ? 'Excel' : f.toUpperCase()}</a>)}
      </div>
      <div style={{ overflow: 'auto' }}><DataTable cols={r.columns.map((c: any) => ({ ...c, unit: c.unit ?? (c.money ? 'money' : undefined) }))} rows={r.rows} total={page === Math.ceil(r.count / r.page_size) || r.count <= r.page_size ? r.total : null} fmt={fmt} L={L} pageSize={r.page_size} onPage={setPage} count={r.count} page={page} /></div>
    </>
  );
}

function ViewsManager({ views, reload, domain }: { views: any[]; reload: () => void; domain: string }) {
  const { t } = useI18n();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const mine = views.filter((v) => !v.role_view || v.can_edit !== false);
  if (!views.length) return null;
  return (
    <div className="no-print">
      <button className="btn ghost sm" onClick={() => setOpen(!open)}>{open ? '▾' : '▸'} {t('rp.myViews')} ({views.length})</button>
      {open && (
        <div className="card" style={{ padding: 0, overflow: 'auto', marginTop: 6 }}>
          <table className="table"><tbody>
            {mine.map((v) => (
              <tr key={v.id}>
                <td>{t(`rp.vk_${v.kind}` as Key)}</td><td>{v.domain === '*' ? '' : t(`rp.d_${v.domain}` as Key)}</td><td><b>{v.name}</b>{v.role_view ? <span className="pill" style={{ marginInlineStart: 6 }}>{t('rp.roleView')} : {v.role_code}</span> : null}{v.is_default ? <span className="pill" style={{ marginInlineStart: 6 }}>{t('rp.default')}</span> : null}</td>
                <td className="num" style={{ whiteSpace: 'nowrap' }}>
                  {v.kind === 'layout' && !v.is_default && v.domain === domain && <button className="btn sm" onClick={async () => { try { await patch(`/api/analytics/views/${v.id}`, { is_default: true }); reload(); } catch (e: any) { toast('error', e.message); } }}>{t('rp.makeDefault')}</button>}
                  <button className="btn ghost sm" aria-label={t('rp.delete')} onClick={async () => { if (!confirm(t('rp.confirmDelete'))) return; try { await del(`/api/analytics/views/${v.id}`); reload(); } catch (e: any) { toast('error', e.message); } }}>✕</button>
                </td>
              </tr>
            ))}
          </tbody></table>
        </div>
      )}
    </div>
  );
}

