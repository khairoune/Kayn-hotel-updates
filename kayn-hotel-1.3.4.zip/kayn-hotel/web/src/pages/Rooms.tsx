import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Page } from '../components/Layout';
import { ReservationPanel } from '../components/ReservationPanel';
import { BlockModal, HkPill, ROOM_STATUS_COLORS, RoomForm, RoomSheet, RoomStatusPill } from '../components/RoomSheet';
import { HK_COLORS, Icon } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { get } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, money } from '../lib/format';
import { useLive } from '../lib/useLive';
import { AmenitiesTab, FloorsTab, RatesTab, TypesTab } from './RoomCatalog';

type Tab = 'rooms' | 'types' | 'floors' | 'rates' | 'amenities';
const STATUSES = ['available', 'reserved', 'occupied', 'maintenance', 'out_of_service'];
const HKS = ['inspected', 'clean', 'to_inspect', 'cleaning', 'to_clean', 'dirty'];

export function Rooms() {
  const { t } = useI18n();
  const { can } = useAuth();
  const [sp, setSp] = useSearchParams();
  // l'onglet Tarifs n'apparaît qu'aux rôles qui ont accès aux tarifs (réservations ou gestion des chambres)
  const tabs = (['rooms', 'types', 'floors', 'rates', 'amenities'] as Tab[]).filter((k) => k !== 'rates' || can('reservations.view') || can('rooms.manage'));
  const tab = tabs.includes(sp.get('tab') as Tab) ? (sp.get('tab') as Tab) : 'rooms';
  const setTab = (k: Tab) => setSp(k === 'rooms' ? {} : { tab: k }, { replace: true });
  return (
    <Page>
      <div className="page-head">
        <h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('rm.title')}</h1>
      </div>
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>
        {tabs.map((k) => (
          <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>
            {t(({ rooms: 'rm.tabRooms', types: 'rm.tabTypes', floors: 'rm.tabFloors', rates: 'rm.tabRates', amenities: 'rm.tabAmenities' } as const)[k])}
          </button>
        ))}
      </div>
      {tab === 'rooms' && <RoomsTab />}
      {tab === 'types' && <TypesTab />}
      {tab === 'floors' && <FloorsTab />}
      {tab === 'rates' && <RatesTab />}
      {tab === 'amenities' && <AmenitiesTab />}
    </Page>
  );
}

function RoomsTab() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [rooms, setRooms] = useState<any[] | null>(null);
  const [types, setTypes] = useState<any[]>([]);
  const [floors, setFloors] = useState<any[]>([]);
  const [view, setView] = useState<'grid' | 'table'>(() => (localStorage.getItem('kh-rooms-view') as any) || 'grid');
  const [f, setF] = useState({ search: '', building_id: '', floor_id: '', room_type_id: '', status: '', hk: '', include_inactive: false });
  const [openId, setOpenId] = useState<number | null>(null);
  const [resId, setResId] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const [blockRoom, setBlockRoom] = useState<any>(null);

  useEffect(() => {
    Promise.all([get('/api/room-types/manage'), get('/api/floors/stats')]).then(([a, b]) => { setTypes(a); setFloors(b); }).catch(() => {});
  }, []);
  const load = useCallback(() => {
    const qs = new URLSearchParams();
    if (f.building_id) qs.set('building_id', f.building_id);
    if (f.floor_id) qs.set('floor_id', f.floor_id);
    if (f.room_type_id) qs.set('room_type_id', f.room_type_id);
    if (f.include_inactive) qs.set('include_inactive', 'true');
    get(`/api/rooms/manage?${qs}`).then(setRooms).catch((e) => toast('error', e.message));
  }, [f.building_id, f.floor_id, f.room_type_id, f.include_inactive]);
  useEffect(() => { load(); }, [load]);
  useLive(load);
  useEffect(() => { try { localStorage.setItem('kh-rooms-view', view); } catch { /* stockage indisponible */ } }, [view]);

  // Recherche, statut et propreté filtrés côté écran (instantané)
  const base = useMemo(() => (rooms ?? []).filter((r) => !f.search || r.number.toLowerCase().includes(f.search.trim().toLowerCase())), [rooms, f.search]);
  const effStatus = (r: any) => (r.active ? r.status : 'inactive');
  const list = base.filter((r) => (!f.status || effStatus(r) === f.status) && (!f.hk || r.hk_status === f.hk));
  const buildings = [...new Map(floors.map((x) => [x.building_id, x.building_name])).entries()];
  const groups = useMemo(() => {
    const m = new Map<string, any[]>();
    list.forEach((r) => {
      const k = `${r.building_name} · ${r.floor_name}`;
      m.set(k, [...(m.get(k) ?? []), r]);
    });
    return [...m.entries()];
  }, [list]);
  const set = (p: Partial<typeof f>) => setF({ ...f, ...p });
  const count = (fn: (r: any) => boolean) => base.filter(fn).length;

  return (
    <>
      <div className="row" style={{ gap: 6 }}>
        <button className={`chip ${!f.status ? 'on' : ''}`} onClick={() => set({ status: '' })}>{t('common.all')} <b>{base.length}</b></button>
        {[...STATUSES, ...(f.include_inactive ? ['inactive'] : [])].map((s) => (
          <button key={s} className={`chip ${f.status === s ? 'on' : ''}`} aria-pressed={f.status === s} onClick={() => set({ status: f.status === s ? '' : s })}>
            <span className="sw" style={{ background: ROOM_STATUS_COLORS[s].bg, border: `1px solid ${ROOM_STATUS_COLORS[s].fg}` }} />{t(`rs.${s}` as Key)} <b>{count((r) => effStatus(r) === s)}</b>
          </button>
        ))}
        <span style={{ width: 1, height: 22, background: 'var(--border)' }} />
        {HKS.map((h) => (
          <button key={h} className={`chip ${f.hk === h ? 'on' : ''}`} aria-pressed={f.hk === h} onClick={() => set({ hk: f.hk === h ? '' : h })}>
            <span className="sw" style={{ background: HK_COLORS[h] }} />{t(`hk.${h}` as Key)} <b>{count((r) => r.active && r.hk_status === h)}</b>
          </button>
        ))}
      </div>
      <div className="row">
        <div style={{ position: 'relative', flex: '1 1 160px', maxWidth: 220 }}>
          <input className="input" aria-label={t('rm.number')} placeholder={`${t('rm.number')}…`} value={f.search} onChange={(e) => set({ search: e.target.value })} />
        </div>
        {buildings.length > 1 && (
          <select className="input" style={{ width: 'auto' }} aria-label={t('rm.building')} value={f.building_id} onChange={(e) => set({ building_id: e.target.value, floor_id: '' })}>
            <option value="">{t('rm.allBuildings')}</option>
            {buildings.map(([id, n]) => <option key={id} value={id}>{n}</option>)}
          </select>
        )}
        <select className="input" style={{ width: 'auto' }} aria-label={t('rm.floor')} value={f.floor_id} onChange={(e) => set({ floor_id: e.target.value })}>
          <option value="">{t('rm.allFloors')}</option>
          {floors.filter((x) => !f.building_id || String(x.building_id) === f.building_id).map((x) => <option key={x.id} value={x.id}>{buildings.length > 1 ? `${x.building_name} · ` : ''}{x.name}</option>)}
        </select>
        <select className="input" style={{ width: 'auto' }} aria-label={t('rm.type')} value={f.room_type_id} onChange={(e) => set({ room_type_id: e.target.value })}>
          <option value="">{t('common.all')} — {t('rm.type')}</option>
          {types.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
        </select>
        <label className="row" style={{ gap: 6, fontSize: 13 }}><input type="checkbox" checked={f.include_inactive} onChange={(e) => set({ include_inactive: e.target.checked })} />{t('rm.inactive')}</label>
        <span className="spacer" style={{ flex: 1 }} />
        <div className="seg" role="group">
          <button className={view === 'grid' ? 'on' : ''} onClick={() => setView('grid')}>{t('rm.grid')}</button>
          <button className={view === 'table' ? 'on' : ''} onClick={() => setView('table')}>{t('rm.table')}</button>
        </div>
        {can('rooms.manage') && <button className="btn primary" onClick={() => setCreating(true)}><Icon name="plus" /> {t('rm.new')}</button>}
      </div>

      {!rooms ? t('common.loading') : !list.length ? <div className="card muted">{t('common.none')}</div> : view === 'grid' ? (
        groups.map(([g, rs]) => (
          <section key={g} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <h3 style={{ margin: '6px 0 0', fontSize: 14 }} className="muted">{g} <span style={{ fontWeight: 500 }}>· {rs.length}</span></h3>
            <div className="room-grid">
              {rs.map((r) => {
                const st = effStatus(r);
                const c = ROOM_STATUS_COLORS[st];
                return (
                  <button key={r.id} className={`room-card ${r.active ? '' : 'off'}`} style={{ borderTopColor: c.fg === '#FFFFFF' ? c.bg : c.fg }} onClick={() => setOpenId(r.id)} aria-label={`${t('common.room')} ${r.number}`}>
                    <div className="row between" style={{ flexWrap: 'nowrap' }}>
                      <b className="room-num">{r.number}</b>
                      <span className="hk-dot" title={t(`hk.${r.hk_status}` as Key)} style={{ background: HK_COLORS[r.hk_status] }} />
                    </div>
                    <span className="muted" style={{ fontSize: 12.5 }}>{r.type_name} · {r.capacity} pers.</span>
                    <RoomStatusPill status={st} />
                    <span className="room-sub">
                      {r.current ? <>{r.current.guest} · → {fmtDate(r.current.check_out, locale, { day: 'numeric', month: 'short' })}</>
                        : st === 'out_of_service' || st === 'maintenance' ? r.oos_reason ?? ''
                        : !r.active ? r.deactivation_reason
                        : r.next_arrival ? <>{t('rm.nextArrival')} : {fmtDate(r.next_arrival, locale, { day: 'numeric', month: 'short' })}</> : <>{money(r.base_rate + Number(r.rate_supplement || 0), locale)}</>}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>
        ))
      ) : (
        <div className="card" style={{ padding: 0, overflow: 'auto' }}>
          <table className="table">
            <thead>
              <tr>
                <th>{t('rm.number')}</th><th>{t('rm.type')}</th><th>{t('rm.building')}</th><th>{t('rm.floor')}</th><th>{t('rm.capacity')}</th><th>{t('rm.beds')}</th>
                <th>{t('rm.occupancy')}</th><th>{t('rm.cleanliness')}</th><th>{t('rm.current')}</th><th>{t('rm.nextArrival')}</th><th className="num">{t('ty.baseRate')}</th><th>{t('rm.amenities')}</th><th />
              </tr>
            </thead>
            <tbody>
              {list.map((r) => (
                <tr key={r.id} onClick={() => setOpenId(r.id)} style={{ cursor: 'pointer', opacity: r.active ? 1 : 0.6 }}>
                  <td><b>{r.number}</b></td><td>{r.type_name}</td><td>{r.building_name}</td><td>{r.floor_name}</td><td>{r.capacity}</td><td>{r.beds}</td>
                  <td><RoomStatusPill status={effStatus(r)} /></td><td>{r.active ? <HkPill hk={r.hk_status} /> : '—'}</td>
                  <td>{r.current?.guest ?? '—'}</td><td>{r.next_arrival ? fmtDate(r.next_arrival, locale) : '—'}</td>
                  <td className="num">{money(r.base_rate + Number(r.rate_supplement || 0), locale)}</td><td>{r.amenity_count}</td>
                  <td onClick={(e) => e.stopPropagation()}>
                    {can('maintenance.manage') && r.active && !['out_of_service'].includes(r.status) && <button className="btn sm ghost" onClick={() => setBlockRoom(r)}>{t('rm.block')}</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {openId && <RoomSheet id={openId} onClose={() => setOpenId(null)} onOpenReservation={(id) => setResId(id)} />}
      {resId && <ReservationPanel id={resId} onClose={() => setResId(null)} onChanged={load} />}
      {creating && <RoomForm room={null} onClose={() => setCreating(false)} onSaved={(id) => { setCreating(false); load(); setOpenId(id); }} />}
      {blockRoom && <BlockModal room={blockRoom} onClose={() => setBlockRoom(null)} onDone={() => { setBlockRoom(null); load(); }} />}
    </>
  );
}
