/** Assistant de première installation (base vide) : code d'installation, établissement, devise & taxes, exploitation, administrateur principal. */
import { useState } from 'react';
import { useI18n, type Key, type Lang } from '../i18n';
import { post } from '../lib/api';

const STEPS = ['code', 'hotel', 'finance', 'ops', 'admin'] as const;
export function Setup({ onDone }: { onDone: (username: string) => void }) {
  const { t, lang, setLang } = useI18n();
  const s = (k: string) => t(`setup.${k}` as Key);
  const [step, setStep] = useState(0);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState<any>({
    code: '',
    hotel: { name: '', commercial_name: '', address: '', city: '', country: 'Algérie', phone: '', email: '', nif: '', nis: '', rc: '', art: '', stars: '' },
    finance: { currency: 'DZD', currency_symbol: 'DA', vat_rate: '', room_vat: '', restaurant_vat: '', tourist_tax_per_adult_night: '0' },
    operations: { check_in_time: '14:00', check_out_time: '12:00', timezone: 'Africa/Algiers', primary_language: 'fr', cash_register: 'Caisse réception' },
    admin: { first_name: '', last_name: '', email: '', username: '', password: '', password2: '' },
  });
  const set = (g: string, k: string) => (e: any) => setF({ ...f, [g]: { ...f[g], [k]: e.target.value } });
  const In = (g: string, k: string, type = 'text', req = false) => (
    <div className="field"><label>{s(`${g}_${k}`)}{req ? ' *' : ''}</label><input className="input" type={type} value={f[g][k]} onChange={set(g, k)} autoComplete={type === 'password' ? 'new-password' : 'off'} /></div>
  );
  const need = (): string | null => {
    const k = STEPS[step];
    if (k === 'code' && f.code.trim().length < 6) return s('errCode');
    if (k === 'hotel' && (!f.hotel.name.trim() || !f.hotel.city.trim())) return s('errHotel');
    if (k === 'finance' && (f.finance.vat_rate === '' || !/^[A-Za-z]{3}$/.test(f.finance.currency))) return s('errFinance');
    if (k === 'admin') {
      if (!f.admin.first_name || !f.admin.last_name || f.admin.username.length < 3) return s('errAdmin');
      if (f.admin.password !== f.admin.password2) return s('errMismatch');
    }
    return null;
  };
  const next = async () => {
    const e = need(); if (e) { setErr(e); return; }
    setErr('');
    if (step < STEPS.length - 1) { setStep(step + 1); return; }
    setBusy(true);
    const num = (v: any) => (v === '' || v === null ? null : Number(String(v).replace(',', '.')));
    try {
      const { password2, ...adm } = f.admin;
      const r = await post('/api/setup', {
        code: f.code.trim(),
        hotel: { ...Object.fromEntries(Object.entries(f.hotel).filter(([, v]) => v !== '')), stars: f.hotel.stars ? Number(f.hotel.stars) : null },
        finance: { currency: f.finance.currency.toUpperCase(), currency_symbol: f.finance.currency_symbol, vat_rate: num(f.finance.vat_rate), room_vat: num(f.finance.room_vat), restaurant_vat: num(f.finance.restaurant_vat), tourist_tax_per_adult_night: num(f.finance.tourist_tax_per_adult_night) ?? 0 },
        operations: f.operations,
        admin: Object.fromEntries(Object.entries(adm).filter(([, v]) => v !== '')),
      });
      onDone(r.username);
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };
  const k = STEPS[step];
  return (
    <div className="login">
      <form className="login-card" style={{ width: 'min(620px, 100%)' }} onSubmit={(e) => { e.preventDefault(); next(); }}>
        <div className="row between">
          <div className="brand"><div className="brand-mark">K</div><div><div className="brand-name">KAYN Hotel</div><div className="brand-sub">{s('title')}</div></div></div>
          <div className="seg">{(['fr', 'ar', 'en'] as Lang[]).map((l) => <button type="button" key={l} className={lang === l ? 'on' : ''} onClick={() => setLang(l)}>{l === 'ar' ? 'ع' : l.toUpperCase()}</button>)}</div>
        </div>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{STEPS.map((x, i) => <span key={x} className="pill" style={{ background: i < step ? '#DCFCE7' : i === step ? '#7A1F2B' : 'var(--soft)', color: i < step ? '#166534' : i === step ? '#fff' : 'var(--muted)' }}>{i < step ? '✓' : i + 1}. {s(`st_${x}`)}</span>)}</div>
        <p className="muted" style={{ margin: 0, fontSize: 13 }}>{s(`hint_${k}`)}</p>
        {k === 'code' && <div className="field"><label>{s('code')}</label><input className="input" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value.toUpperCase() })} style={{ letterSpacing: 3, fontFamily: 'monospace', fontSize: 18 }} autoFocus /></div>}
        {k === 'hotel' && <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 10 }}>
          {In('hotel', 'name', 'text', true)}{In('hotel', 'commercial_name')}{In('hotel', 'address')}{In('hotel', 'city', 'text', true)}{In('hotel', 'country')}{In('hotel', 'phone')}{In('hotel', 'email', 'email')}
          <div className="field"><label>{s('hotel_stars')}</label><select className="input" value={f.hotel.stars} onChange={set('hotel', 'stars')}><option value="">—</option>{[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{'★'.repeat(n)}</option>)}</select></div>
          {In('hotel', 'nif')}{In('hotel', 'nis')}{In('hotel', 'rc')}{In('hotel', 'art')}
        </div>}
        {k === 'finance' && <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 10 }}>
          {In('finance', 'currency', 'text', true)}{In('finance', 'currency_symbol', 'text', true)}{In('finance', 'vat_rate', 'number', true)}{In('finance', 'room_vat', 'number')}{In('finance', 'restaurant_vat', 'number')}{In('finance', 'tourist_tax_per_adult_night', 'number')}
          <div className="alert info" style={{ gridColumn: '1 / -1', fontSize: 12.5 }}>{s('taxWarn')}</div>
        </div>}
        {k === 'ops' && <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 10 }}>
          {In('operations', 'check_in_time', 'time')}{In('operations', 'check_out_time', 'time')}
          <div className="field"><label>{s('operations_timezone')}</label><select className="input" value={f.operations.timezone} onChange={set('operations', 'timezone')}>{((Intl as any).supportedValuesOf?.('timeZone') ?? ['Africa/Algiers']).map((z: string) => <option key={z}>{z}</option>)}</select></div>
          <div className="field"><label>{s('operations_primary_language')}</label><select className="input" value={f.operations.primary_language} onChange={set('operations', 'primary_language')}><option value="fr">Français</option><option value="ar">العربية</option><option value="en">English</option></select></div>
          {In('operations', 'cash_register')}
        </div>}
        {k === 'admin' && <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 10 }}>
          {In('admin', 'last_name', 'text', true)}{In('admin', 'first_name', 'text', true)}{In('admin', 'username', 'text', true)}{In('admin', 'email', 'email')}{In('admin', 'password', 'password', true)}{In('admin', 'password2', 'password', true)}
          <div className="alert warning" style={{ gridColumn: '1 / -1', fontSize: 12.5 }}>{s('pwRule')}</div>
        </div>}
        {err && <div className="alert danger" role="alert">{err}</div>}
        <div className="row" style={{ gap: 8 }}>
          {step > 0 && <button type="button" className="btn" onClick={() => { setErr(''); setStep(step - 1); }}>{s('back')}</button>}
          <span style={{ flex: 1 }} />
          <button className="btn primary" type="submit" disabled={busy} style={{ minHeight: 42 }}>{step < STEPS.length - 1 ? s('next') : busy ? s('installing') : s('install')}</button>
        </div>
      </form>
    </div>
  );
}
