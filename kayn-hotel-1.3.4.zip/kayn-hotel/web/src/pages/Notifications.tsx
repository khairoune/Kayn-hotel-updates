import { useCallback, useState } from 'react';
import { Page } from '../components/Layout';
import { NotificationRow } from '../components/ReservationPanel';
import { useI18n, type Key } from '../i18n';
import { get, post } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { useLive } from '../lib/useLive';
import { useEffect } from 'react';

export function Notifications() {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [status, setStatus] = useState('pending');
  const [rows, setRows] = useState<any[] | null>(null);
  const load = useCallback(() => { get(`/api/notifications${status ? `?status=${status}` : ''}`).then(setRows).catch((e) => toast('error', e.message)); }, [status]);
  useEffect(() => { load(); }, [load]);
  useLive(load);
  const run = async () => {
    try {
      const r = await post('/api/notifications/run');
      toast('success', `${r.reminders} rappel(s) programmé(s) · ${r.sent} e-mail(s) envoyé(s)${r.skipped ? ` · ${r.skipped} en attente (serveur e-mail non configuré)` : ''}`);
      load();
    } catch (e: any) {
      toast('error', e.message);
    }
  };
  return (
    <Page>
      <div className="page-head">
        <div style={{ marginInlineEnd: 'auto' }}>
          <h1 className="page-title">{t('notif.title')}</h1>
          <div className="page-sub">Confirmations, modifications, annulations et rappels J-1. WhatsApp : envoi en un clic depuis le poste ; e-mail : envoi automatique dès que le serveur e-mail est configuré et qu'Internet est disponible.</div>
        </div>
        {can('reservations.edit') && <button className="btn primary" onClick={run}>{t('notif.run')}</button>}
      </div>
      <div className="row">
        {['pending', 'sent', 'failed', 'cancelled', ''].map((s) => (
          <button key={s || 'all'} className={`chip ${status === s ? 'on' : ''}`} onClick={() => setStatus(s)}>{s ? t(`notif.s.${s}` as Key) : t('common.all')}</button>
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 12 }}>
        {!rows && t('common.loading')}
        {rows?.length === 0 && <span className="muted">{t('common.none')}</span>}
        {rows?.map((n) => <NotificationRow key={n.id} n={n} showGuest onChange={load} />)}
      </div>
    </Page>
  );
}
