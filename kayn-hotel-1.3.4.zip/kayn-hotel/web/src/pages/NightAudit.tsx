import { useCallback, useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Page } from '../components/Layout';
import { ReasonModal, ReservationPanel } from '../components/ReservationPanel';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { get, post } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, fmtDateTime, money } from '../lib/format';
import { useLive } from '../lib/useLive';

type Tab = 'dashboard' | 'checklist' | 'anomalies' | 'finance' | 'cash' | 'closing' | 'history';
const fr = (d: string) => `${d.slice(8, 10)}/${d.slice(5, 7)}/${d.slice(0, 4)}`;
const DAY_COLORS: Record<string, [string, string]> = { open: ['#DBEAFE', '#1E3A8A'], checking: ['#FEF3C7', '#92400E'], ready: ['#DCFCE7', '#166534'], closed: ['#E2E8F0', '#334155'], reopened: ['#FCE7F3', '#9D174D'], suspended: ['#F1F5F9', '#64748B'] };
const CL_COLORS: Record<string, [string, string]> = { to_check: ['#F1F5F9', '#475569'], ok: ['#DCFCE7', '#166534'], anomaly: ['#FEE2E2', '#991B1B'], corrected: ['#E0F2FE', '#075985'], validated: ['#EDE9FE', '#5B21B6'] };
const SEV_COLORS: Record<string, [string, string]> = { info: ['#F1F5F9', '#475569'], warning: ['#FEF3C7', '#92400E'], critical: ['#FEE2E2', '#991B1B'] };
const AN_COLORS: Record<string, [string, string]> = { open: ['#FEE2E2', '#991B1B'], corrected: ['#DCFCE7', '#166534'], accepted: ['#EDE9FE', '#5B21B6'] };
const P = ({ map, s, k }: { map: Record<string, [string, string]>; s: string; k: string }) => { const { t } = useI18n(); const [bg, fg] = map[s] ?? ['#F1F5F9', '#475569']; return <span className="pill" style={{ background: bg, color: fg }}>{t(`${k}${s}` as Key)}</span>; };
const err = (toast: any) => (e: any) => toast('error', e.message);

export function NightAudit() {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [sp, setSp] = useSearchParams();
  const tabs: Tab[] = ['dashboard', 'checklist', 'anomalies', 'finance', 'cash', 'closing', ...(can('nightaudit.history') ? ['history' as Tab] : [])];
  const tab = tabs.includes(sp.get('tab') as Tab) ? (sp.get('tab') as Tab) : 'dashboard';
  const go = (k: Tab, extra: Record<string, string> = {}) => setSp({ tab: k, ...extra }, { replace: true });
  const [d, setD] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<number | null>(null);
  const load = useCallback(() => get('/api/night-audit/current').then(setD).catch(err(toast)), []);
  useEffect(() => { load(); }, [load]);
  useLive(load, 60000);
  const runCheck = async () => { setBusy(true); try { const r = await post('/api/night-audit/check', {}); toast(r.blocking ? 'info' : 'success', `${t('na.checkDone')} : ${r.blocking} ${t('na.blocking')}`); await load(); } catch (e: any) { toast('error', e.message); } finally { setBusy(false); } };
  if (!d) return <Page><span>{t('common.loading')}</span></Page>;
  const day = d.day;
  return (
    <Page>
      <div className="page-head" style={{ flexWrap: 'wrap', gap: 8 }}>
        <h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('na.title')}</h1>
        <span className="muted">{t('na.businessDate')}</span><b style={{ fontSize: 18 }}>{fr(day.business_date)}</b><P map={DAY_COLORS} s={day.status} k="na.ds_" />
        {can('nightaudit.check') && <button className="btn primary" disabled={busy} onClick={runCheck}><Icon name="search" size={14} />{busy ? t('na.checking') : t('na.runCheck')}</button>}
      </div>
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>{tabs.map((k) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => go(k)}>{t(`na.t_${k}` as Key)}{k === 'anomalies' && d.anomalies.blocking ? <span className="pill" style={{ background: '#FEE2E2', color: '#991B1B', marginInlineStart: 6 }}>{d.anomalies.blocking}</span> : null}</button>)}</div>
      {tab === 'dashboard' && <Dash d={d} go={go} openRes={setRes} />}
      {tab === 'checklist' && <Checklist d={d} reload={load} go={go} />}
      {tab === 'anomalies' && <Anomalies reload={load} item={sp.get('item') ?? ''} openRes={setRes} />}
      {tab === 'finance' && <Finance d={d} reload={load} />}
      {tab === 'cash' && <Cash reload={load} />}
      {tab === 'closing' && <Closing d={d} reload={load} go={go} />}
      {tab === 'history' && <History reload={load} />}
      {res && <ReservationPanel id={res} onClose={() => setRes(null)} onChanged={load} />}
    </Page>
  );
}

// ===================================================== Tableau de bord =====================================================
const STEPS = ['prep', 'control', 'correction', 'validation', 'closing', 'newday'];
function stepOf(d: any) {
  if (d.day.status === 'ready') return 3;
  if (!d.day.last_check_at) return 0;
  return d.anomalies.blocking ? 2 : 3;
}
function Dash({ d, go, openRes }: { d: any; go: (t: Tab, x?: any) => void; openRes: (id: number) => void }) {
  const { t, locale } = useI18n();
  const f = d.facts;
  const m = (n: number) => money(n, locale);
  const step = stepOf(d);
  const K = ({ label, value, hint, color, onClick }: any) => (
    <div className={`card kpi ${onClick ? 'clickable' : ''}`} style={{ borderInlineStart: color ? `4px solid ${color}` : undefined, cursor: onClick ? 'pointer' : undefined }} onClick={onClick}>
      <span className="label">{label}</span><span className="value" style={{ fontSize: 22 }}>{value}</span>{hint && <span className="hint">{hint}</span>}
    </div>
  );
  return (
    <>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
          {STEPS.map((s, i) => (
            <span key={s} className="row" style={{ gap: 6 }}>
              <span className="pill" style={{ background: i < step ? '#DCFCE7' : i === step ? '#7A1F2B' : 'var(--soft)', color: i < step ? '#166534' : i === step ? '#fff' : 'var(--muted)' }}>{i < step ? '✓' : i + 1}. {t(`na.st_${s}` as Key)}</span>
              {i < STEPS.length - 1 && <span className="muted">›</span>}
            </span>
          ))}
        </div>
        <div className="row" style={{ gap: 16, flexWrap: 'wrap', fontSize: 13 }}>
          <span>{t('na.lastClosure')} : <b>{d.last_closure ? `${fr(String(d.last_closure.business_date).slice(0, 10))} — ${fmtDateTime(d.last_closure.closed_at, locale)} (${d.last_closure.closed_by})` : '—'}</b></span>
          <span>{t('na.lastCheck')} : <b>{d.day.last_check_at ? fmtDateTime(d.day.last_check_at, locale) : t('na.never')}</b></span>
          {d.early && <span className="pill" style={{ background: '#FEF3C7', color: '#92400E' }}>{t('na.earlyHint')}</span>}
        </div>
      </div>
      <div className="grid kpis" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))' }}>
        <K label={t('na.arrivals')} value={f.arrivals} hint={f.arrivals_pending ? `${f.arrivals_pending} ${t('na.notArrived')}` : undefined} color={f.arrivals_pending ? '#B45309' : '#0E7490'} />
        <K label={t('na.departures')} value={f.departures} hint={f.departures_pending ? `${f.departures_pending} ${t('na.notDeparted')}` : undefined} color={f.departures_pending ? '#B45309' : '#0E7490'} />
        <K label={t('na.inHouse')} value={f.guests} color="#1E40AF" />
        <K label={t('na.occupied')} value={f.rooms.occupied} hint={`${f.rooms.occupancy} %`} color="#7A1F2B" />
        <K label={t('na.available')} value={f.rooms.available} color="#15803D" />
        <K label={t('na.oos')} value={f.rooms.oos} color="#52525B" />
        <K label={t('na.revenue')} value={m(f.revenue_total)} hint={f.revenue_pending ? `${m(f.revenue_pending)} ${t('na.toPost')}` : t('na.allPosted')} color="#C9A227" onClick={() => go('finance')} />
        <K label={t('na.collected')} value={m(f.collected)} color="#15803D" onClick={() => go('finance')} />
        <K label={t('na.expenses')} value={m(f.expenses_total)} color="#B91C1C" onClick={() => go('finance')} />
        <K label={t('na.unpaid')} value={f.unpaid_invoices.n} hint={m(f.unpaid_invoices.due)} color={f.unpaid_invoices.n ? '#B45309' : undefined} />
        <K label={t('na.pendingTx')} value={f.pending.total} hint={`${f.pending.rs_open} ${t('na.rsOpen')} · ${f.pending.cash_open} ${t('na.cashOpen')}`} color={f.pending.total ? '#B45309' : undefined} />
        <K label={t('na.anomalies')} value={d.anomalies.blocking} hint={`${d.anomalies.critical} ${t('na.sv_critical')} · ${d.anomalies.corrected + d.anomalies.accepted} ${t('na.handled')}`} color={d.anomalies.blocking ? '#B91C1C' : '#15803D'} onClick={() => go('anomalies')} />
      </div>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <h3 style={{ margin: 0 }}>{t('na.actionsRequired')}</h3>
        {!d.day.last_check_at && <span className="muted">{t('na.runFirst')}</span>}
        {d.day.last_check_at && !d.actions.length && <span style={{ color: '#15803D' }}>✓ {t('na.noAction')}</span>}
        {d.actions.map((a: any) => (
          <div key={a.id} className="sum-row" style={{ fontSize: 13, cursor: 'pointer', gap: 8 }} onClick={() => (a.ref_type === 'reservation' && a.ref_id ? openRes(a.ref_id) : go('anomalies', { item: a.item }))}>
            <span className="row" style={{ gap: 8, minWidth: 0 }}><P map={SEV_COLORS} s={a.severity} k="na.sv_" /><b>{t(`na.a_${a.code}` as Key)}</b><span className="muted" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.ref_label}</span></span>
            <span className="muted">›</span>
          </div>
        ))}
      </div>
    </>
  );
}

// ===================================================== Checklist =====================================================
function Checklist({ d, reload, go }: { d: any; reload: () => void; go: (t: Tab, x?: any) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [v, setV] = useState<any>(null);
  return (
    <div className="card" style={{ padding: 0, overflow: 'auto' }}>
      <table className="table">
        <thead><tr><th>#</th><th>{t('na.item')}</th><th>{t('na.status')}</th><th className="num">{t('na.toHandle')}</th><th className="num">{t('na.handled')}</th><th>{t('na.validatedBy')}</th><th /></tr></thead>
        <tbody>
          {d.checklist.map((c: any, i: number) => (
            <tr key={c.key}>
              <td>{i + 1}</td>
              <td style={{ cursor: c.key !== 'final' ? 'pointer' : undefined }} onClick={() => c.key !== 'final' && (c.key === 'cash' ? go('cash') : c.key === 'posting' ? go('finance') : go('anomalies', c.key === 'anomalies' ? {} : { item: c.key }))}><b>{t(`na.cl_${c.key}` as Key)}</b></td>
              <td><P map={CL_COLORS} s={c.status} k="na.cs_" /></td>
              <td className="num" style={{ color: c.open ? 'var(--danger)' : undefined, fontWeight: c.open ? 700 : undefined }}>{c.open || ''}</td>
              <td className="num">{c.handled || ''}{c.info ? <span className="muted"> (+{c.info} info)</span> : null}</td>
              <td style={{ fontSize: 12.5 }}>{c.validated_by ? `${c.validated_by} · ${fmtDateTime(c.validated_at, locale)}${c.note ? ` — ${c.note}` : ''}` : ''}</td>
              <td>{can('nightaudit.check') && !['final'].includes(c.key) && ['ok', 'corrected'].includes(c.status) && <button className="btn sm" onClick={() => setV({ key: c.key, note: '' })}>{t('na.validate')}</button>}
                {c.key === 'final' && <button className="btn sm" onClick={() => go('closing')}>{t('na.t_closing')} ›</button>}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {v && (
        <Modal title={`${t('na.validate')} — ${t(`na.cl_${v.key}` as Key)}`} onClose={() => setV(null)} size="sm" footer={<button className="btn primary" onClick={async () => { try { await post(`/api/night-audit/checklist/${v.key}/validate`, { note: v.note || null }); setV(null); reload(); } catch (e: any) { toast('error', e.message); } }}>{t('na.validate')}</button>}>
          <Field label={t('na.noteOptional')}><textarea className="input" rows={2} value={v.note} onChange={(e) => setV({ ...v, note: e.target.value })} /></Field>
        </Modal>
      )}
    </div>
  );
}

// ===================================================== Anomalies =====================================================
function Anomalies({ reload, item, openRes, dayId }: { reload: () => void; item: string; openRes: (id: number) => void; dayId?: number }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [status, setStatus] = useState('open');
  const [rows, setRows] = useState<any[]>([]);
  const [sel, setSel] = useState<number[]>([]);
  const [cur, setCur] = useState<any>(null);
  const [act, setAct] = useState<any>(null);
  const load = useCallback(() => {
    const qs = new URLSearchParams({ ...(status ? { status } : {}), ...(item ? { item } : {}), ...(dayId ? { day_id: String(dayId) } : {}) });
    get(`/api/night-audit/anomalies?${qs}`).then((r) => { setRows(r); setSel([]); }).catch(err(toast));
  }, [status, item, dayId]);
  useEffect(load, [load]);
  const openA = (id: number) => get(`/api/night-audit/anomalies/${id}`).then(setCur).catch(err(toast));
  const doAct = async (body: any, id = cur?.id) => { try { await post(`/api/night-audit/anomalies/${id}/action`, body); toast('success', t('na.saved')); setAct(null); load(); reload(); if (cur) openA(cur.id); } catch (e: any) { toast('error', e.message); } };
  const noShow = async (resId: number) => { const reason = prompt(t('na.noShowReason'), t('na.noShowDefault')); if (!reason) return; try { await post(`/api/reservations/${resId}/no-show`, { reason }); await post('/api/night-audit/check', {}); toast('success', t('na.saved')); setCur(null); load(); reload(); } catch (e: any) { toast('error', e.message); } };
  const link = (a: any) => a.ref_type === 'rs_order' ? '/restaurant' : a.ref_type === 'room' ? '/rooms' : ['invoice', 'payment', 'refund', 'expense', 'cash_session'].includes(a.ref_type) ? '/billing' : a.ref_type === 'cash_register' ? '/night-audit?tab=cash' : a.ref_type === 'posting' ? '/night-audit?tab=finance' : null;
  const selectable = rows.filter((a) => a.status === 'open' && a.severity !== 'info' && !['cash_count_missing', 'cash_count_unapproved', 'posting_pending', 'rs_not_transferred'].includes(a.code));
  return (
    <>
      <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
        <div className="seg">{[['open', 'na.f_open'], ['corrected,accepted', 'na.f_handled'], ['', 'na.f_all']].map(([v, k]) => <button key={v} className={status === v ? 'on' : ''} onClick={() => setStatus(v)}>{t(k as Key)}</button>)}</div>
        {item && <span className="chip on">{t(`na.cl_${item}` as Key)} <Link to="/night-audit?tab=anomalies" style={{ color: 'inherit' }}>✕</Link></span>}
        <span style={{ flex: 1 }} />
        {can('nightaudit.correct') && sel.length > 0 && <button className="btn" onClick={() => setAct({ action: 'bulk', text: '' })}>{t('na.acceptSelected')} ({sel.length})</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr>{can('nightaudit.correct') && !dayId && <th><input type="checkbox" aria-label={t('na.selectAll')} checked={sel.length > 0 && sel.length === selectable.length} onChange={(e) => setSel(e.target.checked ? selectable.map((a) => a.id) : [])} /></th>}
            <th>{t('na.severity')}</th><th>{t('na.type')}</th><th>{t('na.module')}</th><th>{t('na.reference')}</th><th>{t('na.description')}</th><th>{t('na.detectedAt')}</th><th>{t('na.responsible')}</th><th>{t('na.status')}</th></tr></thead>
          <tbody>
            {!rows.length && <tr><td colSpan={9} className="muted">{t('na.none')}</td></tr>}
            {rows.map((a) => (
              <tr key={a.id} style={{ cursor: 'pointer' }} onClick={() => openA(a.id)}>
                {can('nightaudit.correct') && !dayId && <td onClick={(e) => e.stopPropagation()}>{selectable.includes(a) && <input type="checkbox" aria-label={a.ref_label} checked={sel.includes(a.id)} onChange={(e) => setSel(e.target.checked ? [...sel, a.id] : sel.filter((x) => x !== a.id))} />}</td>}
                <td><P map={SEV_COLORS} s={a.severity} k="na.sv_" /></td><td><b>{t(`na.a_${a.code}` as Key)}</b></td><td>{t(`na.m_${a.module}` as Key)}</td><td>{a.ref_label ?? ''}</td>
                <td className="wrap" style={{ maxWidth: 380, fontSize: 13 }}>{a.description}</td><td style={{ fontSize: 12.5 }}>{fmtDateTime(a.detected_at, locale)}</td><td>{a.responsible ?? ''}</td>
                <td><P map={AN_COLORS} s={a.status} k="na.as_" />{a.events > 1 ? <span className="muted" style={{ fontSize: 11 }}> · {a.events}</span> : null}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {cur && (
        <Modal title={`${t(`na.a_${cur.code}` as Key)} — ${cur.ref_label ?? ''}`} onClose={() => setCur(null)} size="lg">
          <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}><P map={SEV_COLORS} s={cur.severity} k="na.sv_" /><P map={AN_COLORS} s={cur.status} k="na.as_" /><span className="pill">{t(`na.m_${cur.module}` as Key)}</span><span className="pill">{t(`na.cl_${cur.item}` as Key)}</span></div>
          <p style={{ margin: 0 }}>{cur.description}</p>
          {cur.resolution && <div className="alert info">{t('na.resolution')} : {cur.resolution}{cur.resolved_by_name ? ` — ${cur.resolved_by_name}` : ''}</div>}
          <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
            {cur.ref_type === 'reservation' && cur.ref_id && <button className="btn" onClick={() => { setCur(null); openRes(cur.ref_id); }}>{t('na.openReservation')}</button>}
            {cur.code === 'arrival_pending' && cur.status === 'open' && can('reservations.cancel') && <button className="btn danger" onClick={() => noShow(cur.ref_id)}>{t('na.markNoShow')}</button>}
            {link(cur) && <Link className="btn" to={link(cur)!}>{t('na.openModule')} ›</Link>}
            {cur.status === 'open' && can('nightaudit.correct') && cur.severity !== 'info' && <button className="btn primary" onClick={() => setAct({ action: 'accept', text: '' })}>{t('na.accept')}</button>}
            {cur.status !== 'open' && can('nightaudit.correct') && !dayId && <button className="btn ghost" onClick={() => setAct({ action: 'reopen', text: '' })}>{t('na.reopenAnomaly')}</button>}
            {(can('nightaudit.check') || can('nightaudit.correct')) && <button className="btn ghost" onClick={() => setAct({ action: 'comment', text: '' })}>{t('na.comment')}</button>}
          </div>
          <h4 style={{ margin: '6px 0 0' }}>{t('na.history')}</h4>
          {cur.history.map((h: any) => <div key={h.id} style={{ fontSize: 13 }}><span className="muted">{fmtDateTime(h.created_at, locale)} · {h.by_name ?? ''} · {t(`na.hk_${h.kind}` as Key)}</span>{h.text && <div>{h.text}</div>}</div>)}
        </Modal>
      )}
      {act && (
        <Modal title={act.action === 'bulk' ? t('na.acceptSelected') : t(`na.act_${act.action}` as Key)} onClose={() => setAct(null)} size="sm"
          footer={<button className="btn primary" disabled={(act.action === 'accept' || act.action === 'bulk') ? act.text.trim().length < 10 : act.text.trim().length < 2} onClick={async () => {
            if (act.action === 'bulk') { try { const r = await post('/api/night-audit/anomalies/accept', { ids: sel, text: act.text }); toast('success', `${r.accepted} ${t('na.acceptedN')}`); setAct(null); load(); reload(); } catch (e: any) { toast('error', e.message); } }
            else doAct({ action: act.action, text: act.text });
          }}>{t('common.save')}</button>}>
          <Field label={act.action === 'comment' ? t('na.comment') : t('na.justification')}><textarea className="input" rows={3} value={act.text} onChange={(e) => setAct({ ...act, text: e.target.value })} autoFocus /></Field>
          {(act.action === 'accept' || act.action === 'bulk') && <span className="muted" style={{ fontSize: 12.5 }}>{t('na.acceptHint')}</span>}
        </Modal>
      )}
    </>
  );
}

// ===================================================== Finances et comptabilisation =====================================================
function Finance({ d, reload }: { d: any; reload: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [p, setP] = useState<any>(null);
  const m = (n: number) => money(n, locale);
  const load = useCallback(() => get('/api/night-audit/postings').then(setP).catch(err(toast)), []);
  useEffect(() => { load(); }, [load]);
  const f = d.facts;
  const doPost = async () => { try { const r = await post('/api/night-audit/post', {}); await post('/api/night-audit/check', {}).catch(() => {}); toast('success', r.inserted ? `${r.inserted} ${t('na.postingsCreated')} · ${m(r.amount)}` : t('na.nothingToPost')); load(); reload(); } catch (e: any) { toast('error', e.message); } };
  const row = (label: string, value: any, strong = false) => <div className="sum-row" style={{ fontSize: 13.5 }}><span>{label}</span>{strong ? <b>{value}</b> : <span>{value}</span>}</div>;
  return (
    <>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 14, alignItems: 'start' }}>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          <h3 style={{ margin: '0 0 4px' }}>{t('na.invoices')}</h3>
          {row(t('na.invCreated'), f.invoices.created)}{row(t('na.invPaid'), f.invoices.paid)}{row(t('na.invPartial'), f.invoices.partial)}{row(t('na.invUnpaid'), f.invoices.unpaid)}
          {row(t('na.creditNotes'), f.invoices.credit_notes)}{row(t('na.billed'), m(f.invoices.billed), true)}{row(t('na.taxes'), m(f.invoices.taxes + f.invoices.tourist))}{row(t('na.discounts'), m(f.invoices.discounts))}
          {row(t('na.unpaidAll'), `${f.unpaid_invoices.n} · ${m(f.unpaid_invoices.due)}`, true)}
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          <h3 style={{ margin: '0 0 4px' }}>{t('na.payments')}</h3>
          {f.payments.map((x: any) => row(`${t(`na.pm_${x.method}` as Key)} (${x.n})`, m(x.amount)))}
          {!f.payments.length && <span className="muted">{t('na.none')}</span>}
          {row(t('na.incomes'), m(f.incomes))}{row(`${t('na.refunds')} (${f.refunds_n})`, `− ${m(f.refunds)}`)}{row(t('na.collected'), m(f.collected), true)}
          {row(t('na.cashMoves'), `${f.cash_movements.n} · +${m(f.cash_movements.in)} / −${m(f.cash_movements.out)}`)}{row(t('na.voided'), f.voided)}
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          <h3 style={{ margin: '0 0 4px' }}>{t('na.expenses')}</h3>
          {f.expenses.map((x: any) => row(`${x.category} (${x.n})`, m(x.amount)))}
          {!f.expenses.length && <span className="muted">{t('na.none')}</span>}
          {row(t('na.total'), m(f.expenses_total), true)}
        </div>
      </div>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          <h3 style={{ margin: 0, marginInlineEnd: 'auto' }}>{t('na.posting')}</h3>
          {p && <span className="muted" style={{ fontSize: 13 }}>{t('na.pending')} : <b style={{ color: p.preview.pending ? 'var(--danger)' : '#15803D' }}>{m(p.preview.pending)}</b> ({p.preview.pending_count})</span>}
          {can('nightaudit.post') && <button className="btn primary" disabled={!p?.preview.pending_count} onClick={doPost}>{t('na.postNow')}</button>}
        </div>
        <span className="muted" style={{ fontSize: 12.5 }}>{t('na.postingHint')}</span>
        {p && <table className="table"><thead><tr><th>{t('na.department')}</th><th className="num">{t('na.dayAmount')}</th><th className="num">{t('na.posted')}</th><th className="num">{t('na.pending')}</th></tr></thead>
          <tbody>{p.preview.by_dept.map((x: any) => <tr key={x.department}><td>{t(`na.dp_${x.department}` as Key)}</td><td className="num">{m(x.amount)}</td><td className="num">{m(x.posted)}</td><td className="num" style={{ color: x.pending ? 'var(--danger)' : undefined }}>{m(x.pending)}</td></tr>)}
            <tr style={{ fontWeight: 700, background: 'var(--surface2)' }}><td>{t('na.total')}</td><td className="num">{m(p.preview.total)}</td><td className="num">{m(p.preview.posted)}</td><td className="num">{m(p.preview.pending)}</td></tr></tbody></table>}
        {p?.postings.length > 0 && <details><summary style={{ cursor: 'pointer' }}>{t('na.entries')} ({p.postings.length})</summary>
          <table className="table"><thead><tr><th>{t('na.department')}</th><th>{t('na.reference')}</th><th>{t('na.description')}</th><th>{t('na.type')}</th><th className="num">{t('na.amountHt')}</th><th className="num">{t('na.taxes')}</th><th>{t('na.by')}</th></tr></thead>
            <tbody>{p.postings.map((x: any) => <tr key={x.id}><td>{t(`na.dp_${x.department}` as Key)}</td><td>{x.reference}</td><td className="wrap">{x.description}</td><td>{x.kind === 'adjustment' ? t('na.adjustment') : t('na.entry')}</td><td className="num">{m(Number(x.amount))}</td><td className="num">{m(Number(x.tax))}</td><td style={{ fontSize: 12.5 }}>{x.posted_by_name} · {fmtDateTime(x.posted_at, locale)}</td></tr>)}</tbody></table></details>}
      </div>
    </>
  );
}

// ===================================================== Caisse =====================================================
function Cash({ reload }: { reload: () => void }) {
  const { t, locale } = useI18n();
  const { can, me } = useAuth() as any;
  const toast = useToast();
  const [c, setC] = useState<any>(null);
  const [f, setF] = useState<Record<number, { counted: string; justification: string }>>({});
  const m = (n: any) => (n === null || n === undefined ? '—' : money(Number(n), locale));
  const load = useCallback(() => get('/api/night-audit/cash').then(setC).catch(err(toast)), []);
  useEffect(() => { load(); }, [load]);
  if (!c) return <span>{t('common.loading')}</span>;
  const save = async (r: any) => {
    const v = f[r.register_id];
    try { await post('/api/night-audit/cash/count', { register_id: r.register_id, counted: Number(String(v.counted).replace(',', '.').replace(/\s/g, '')), justification: v.justification || null }); await post('/api/night-audit/check', {}).catch(() => {}); toast('success', t('na.saved')); setF({ ...f, [r.register_id]: { counted: '', justification: '' } }); load(); reload(); } catch (e: any) { toast('error', e.message); }
  };
  return (
    <>
      <div className="alert info" style={{ fontSize: 13 }}>{t('na.cashHint')} {t('na.tolerance')} : {m(c.tolerance)} · {t('na.approvalThreshold')} : {m(c.approval_threshold)}</div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 14, alignItems: 'start' }}>
        {c.registers.map((r: any) => {
          const v = f[r.register_id] ?? { counted: '', justification: '' };
          const diff = v.counted !== '' && r.required ? Math.round((Number(String(v.counted).replace(',', '.').replace(/\s/g, '')) - r.expected) * 100) / 100 : null;
          return (
            <div key={r.register_id} className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <h3 style={{ margin: 0 }}>{r.name}</h3>
              {!r.required ? <span className="muted">{t('na.noSession')}</span> : <>
                <div className="sum-row"><span>{t('na.opening')}</span><span>{m(r.opening)}</span></div>
                <div className="sum-row"><span>{t('na.receipts')}</span><span>+ {m(r.receipts)}</span></div>
                <div className="sum-row"><span>{t('na.outflows')}</span><span>− {m(r.outflows)}</span></div>
                <div className="sum-row"><span>{t('na.refunds')}</span><span>− {m(r.refunds)}</span></div>
                <div className="sum-row" style={{ fontWeight: 700 }}><span>{t('na.expected')}</span><span>{m(r.expected)}</span></div>
                {r.count && <div className="alert" style={{ background: Number(r.count.difference) ? 'var(--warn-bg)' : 'var(--ok-bg)', fontSize: 13 }}>
                  {t('na.counted')} : <b>{m(r.count.counted)}</b> · {t('na.difference')} : <b>{m(r.count.difference)}</b> — {r.count.counted_by_name}, {fmtDateTime(r.count.counted_at, locale)}
                  {r.count.justification && <div>« {r.count.justification} »</div>}
                  {r.count.needs_approval && (r.count.approved_by ? <div>✓ {t('na.approvedBy')} {r.count.approved_by_name}</div> :
                    can('nightaudit.cash') && r.count.counted_by !== me?.id ? <button className="btn sm primary" style={{ marginTop: 6 }} onClick={async () => { const note = prompt(t('na.approvalNote')) ?? ''; try { await post(`/api/night-audit/cash/${r.count.id}/approve`, { note: note || null }); await post('/api/night-audit/check', {}).catch(() => {}); toast('success', t('na.saved')); load(); reload(); } catch (e: any) { toast('error', e.message); } }}>{t('na.approve')}</button>
                      : <div style={{ color: 'var(--danger)' }}>{t('na.needsApproval')}</div>)}
                </div>}
                {can('nightaudit.cash') && <>
                  <Field label={r.count ? t('na.recount') : t('na.countedAmount')}><input className="input" inputMode="decimal" value={v.counted} onChange={(e) => setF({ ...f, [r.register_id]: { ...v, counted: e.target.value } })} /></Field>
                  {diff !== null && !Number.isNaN(diff) && <div style={{ fontWeight: 600, color: diff ? 'var(--danger)' : '#15803D' }}>{t('na.difference')} : {m(diff)}{Math.abs(diff) > c.approval_threshold ? ` — ${t('na.needsApproval')}` : ''}</div>}
                  {diff !== null && Math.abs(diff) > c.tolerance && <Field label={t('na.justification')}><textarea className="input" rows={2} value={v.justification} onChange={(e) => setF({ ...f, [r.register_id]: { ...v, justification: e.target.value } })} /></Field>}
                  <button className="btn primary" disabled={v.counted === '' || (diff !== null && Math.abs(diff) > c.tolerance && v.justification.trim().length < 5)} onClick={() => save(r)}>{t('na.saveCount')}</button>
                </>}
              </>}
            </div>
          );
        })}
      </div>
      {c.counts.length > 0 && <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('na.countHistory')}</h3>
        <table className="table"><thead><tr><th>{t('na.date')}</th><th>{t('na.register')}</th><th className="num">{t('na.expected')}</th><th className="num">{t('na.counted')}</th><th className="num">{t('na.difference')}</th><th>{t('na.justification')}</th><th>{t('na.by')}</th><th>{t('na.approvedBy')}</th></tr></thead>
          <tbody>{c.counts.map((x: any) => <tr key={x.id} style={{ opacity: x.superseded ? 0.5 : 1 }}><td>{fmtDateTime(x.counted_at, locale)}</td><td>{x.register}</td><td className="num">{m(x.expected)}</td><td className="num">{m(x.counted)}</td><td className="num">{m(x.difference)}</td><td className="wrap">{x.justification ?? ''}</td><td>{x.counted_by_name}</td><td>{x.approved_by_name ?? (x.needs_approval ? '⏳' : '')}</td></tr>)}</tbody></table>
      </div>}
    </>
  );
}

// ===================================================== Validation et clôture =====================================================
function Closing({ d, reload, go }: { d: any; reload: () => void; go: (t: Tab, x?: any) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [confirm, setConfirm] = useState<string | null>(null);
  const [problems, setProblems] = useState<string[]>([]);
  const [done, setDone] = useState<any>(null);
  const f = d.facts;
  const D = d.day.business_date;
  const m = (n: number) => money(n, locale);
  const validate = async () => { setProblems([]); try { await post('/api/night-audit/validate', {}); toast('success', t('na.validated')); reload(); } catch (e: any) { setProblems(e.details?.problems ?? [e.message]); reload(); } };
  const close = async () => { try { const r = await post('/api/night-audit/close', { confirm }); setConfirm(null); setDone(r); toast('success', `${t('na.closedOk')} ${fr(r.closed)}`); reload(); } catch (e: any) { toast('error', e.message); setConfirm(null); reload(); } };
  if (done) return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-start' }}>
      <h3 style={{ margin: 0, color: '#15803D' }}>✓ {t('na.closedOk')} {fr(done.closed)}</h3>
      <span>{t('na.newDay')} : <b>{fr(done.next_business_date)}</b> · {t('na.postedAtClose')} : {done.posted.inserted} ({m(done.posted.amount)})</span>
      <div className="row" style={{ gap: 6 }}>{['pdf', 'xlsx', 'csv'].map((x) => <a key={x} className="btn" target="_blank" rel="noreferrer" href={`/api/night-audit/days/${d.day.id}/report?format=${x}`}>{x === 'xlsx' ? 'Excel' : x.toUpperCase()}</a>)}<button className="btn" onClick={() => { setDone(null); go('dashboard'); }}>{t('na.t_dashboard')}</button></div>
    </div>
  );
  return (
    <>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <h3 style={{ margin: 0 }}>{t('na.summary')} — {fmtDate(D, locale, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</h3>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 6, fontSize: 13.5 }}>
          <span>{t('na.occupancy')} : <b>{f.rooms.occupancy} %</b> ({f.rooms.sold})</span><span>{t('na.arrivals')} : <b>{f.arrivals}</b></span><span>{t('na.departures')} : <b>{f.departures}</b></span><span>{t('na.inHouse')} : <b>{f.guests}</b></span>
          <span>{t('na.revenue')} : <b>{m(f.revenue_total)}</b></span><span>{t('na.collected')} : <b>{m(f.collected)}</b></span><span>{t('na.expenses')} : <b>{m(f.expenses_total)}</b></span><span>{t('na.unpaid')} : <b>{f.unpaid_invoices.n} · {m(f.unpaid_invoices.due)}</b></span>
        </div>
        <div className="row" style={{ gap: 6 }}>{['pdf', 'xlsx', 'csv'].map((x) => <a key={x} className="btn sm" target="_blank" rel="noreferrer" href={`/api/night-audit/days/${d.day.id}/report?format=${x}`}>{t('na.provisional')} {x === 'xlsx' ? 'Excel' : x.toUpperCase()}</a>)}</div>
      </div>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <h3 style={{ margin: 0 }}>{t('na.remaining')}</h3>
        {d.anomalies.blocking ? <div className="alert danger">{d.anomalies.blocking} {t('na.blockingLeft')} <button className="btn sm" onClick={() => go('anomalies')}>{t('na.t_anomalies')} ›</button></div>
          : <div className="alert" style={{ background: 'var(--ok-bg)' }}>✓ {t('na.noBlocking')} ({d.anomalies.corrected} {t('na.as_corrected')} · {d.anomalies.accepted} {t('na.as_accepted')} · {d.anomalies.info} info)</div>}
        {d.early && <div className="alert warning">{t('na.earlyHint')}</div>}
        {problems.length > 0 && <div className="alert danger">{problems.map((p) => <div key={p}>• {p}</div>)}</div>}
        <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          {can('nightaudit.close') && d.day.status !== 'ready' && <button className="btn primary" onClick={validate}>{t('na.validateDay')}</button>}
          {can('nightaudit.close') && d.day.status === 'ready' && <span className="pill" style={{ background: '#DCFCE7', color: '#166534' }}>✓ {t('na.ds_ready')}</span>}
          {can('nightaudit.close') && <button className="btn danger" disabled={d.day.status !== 'ready'} onClick={() => setConfirm('')}><Icon name="key" size={14} />{t('na.closeDay')}</button>}
          {!can('nightaudit.close') && <span className="muted">{t('na.noClosePerm')}</span>}
        </div>
      </div>
      {confirm !== null && (
        <Modal title={t('na.closeDay')} onClose={() => setConfirm(null)} size="sm" footer={<><button className="btn" onClick={() => setConfirm(null)}>{t('common.cancel')}</button><button className="btn danger" disabled={confirm !== fr(D)} onClick={close}>{t('na.closeConfirmBtn')}</button></>}>
          <div className="alert warning">{t('na.irreversible')}</div>
          <Field label={`${t('na.typeDate')} ${fr(D)}`}><input className="input" value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder={fr(D)} autoFocus /></Field>
        </Modal>
      )}
    </>
  );
}

// ===================================================== Historique =====================================================
function History({ reload }: { reload: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [rows, setRows] = useState<any[]>([]);
  const [reopen, setReopen] = useState<any>(null);
  const [ev, setEv] = useState<any>(null);
  const load = useCallback(() => get('/api/night-audit/history').then(setRows).catch(err(toast)), []);
  useEffect(() => { load(); }, [load]);
  const m = (n: any) => (n === null || n === undefined ? '' : money(Number(n), locale));
  const lastClosed = rows.find((r) => r.status === 'closed');
  return (
    <div className="card" style={{ padding: 0, overflow: 'auto' }}>
      <table className="table">
        <thead><tr><th>{t('na.businessDate')}</th><th>{t('na.status')}</th><th>{t('na.closedAt')}</th><th>{t('na.closedBy')}</th><th className="num">{t('na.revenue')}</th><th className="num">{t('na.collected')}</th><th className="num">{t('na.expenses')}</th><th className="num">{t('na.cashDiff')}</th><th className="num">{t('na.anomalies')}</th><th>{t('na.report')}</th><th /></tr></thead>
        <tbody>
          {!rows.length && <tr><td colSpan={11} className="muted">{t('na.none')}</td></tr>}
          {rows.map((r) => (
            <tr key={r.id}>
              <td><b>{fr(r.business_date)}</b>{r.version > 1 ? <span className="muted"> · v{r.version}</span> : null}{r.reopen_count ? <span className="pill" style={{ marginInlineStart: 6, background: '#FCE7F3', color: '#9D174D' }}>{t('na.reopenedN')} {r.reopen_count}</span> : null}</td>
              <td><P map={DAY_COLORS} s={r.status} k="na.ds_" /></td><td>{r.closed_at ? fmtDateTime(r.closed_at, locale) : ''}</td><td>{r.closed_by ?? ''}</td>
              <td className="num">{m(r.revenue)}</td><td className="num">{m(r.collected)}</td><td className="num">{m(r.expenses)}</td>
              <td className="num" style={{ color: Number(r.cash_difference) ? 'var(--danger)' : undefined }}>{m(r.cash_difference)}</td>
              <td className="num">{r.closure_id ? `${r.anomalies} (${r.anomalies_resolved}✓ ${r.anomalies_accepted}✎)` : ''}</td>
              <td style={{ whiteSpace: 'nowrap' }}>{['pdf', 'xlsx', 'csv'].map((x) => <a key={x} className="btn sm ghost" target="_blank" rel="noreferrer" href={`/api/night-audit/days/${r.id}/report?format=${x}`}>{x === 'xlsx' ? 'XLS' : x.toUpperCase()}</a>)}</td>
              <td style={{ whiteSpace: 'nowrap' }}><button className="btn sm ghost" onClick={() => get(`/api/night-audit/days/${r.id}/events`).then((e) => setEv({ day: r, events: e })).catch(err(toast))}>{t('na.journal')}</button>
                {can('nightaudit.reopen') && lastClosed?.id === r.id && <button className="btn sm danger" onClick={() => setReopen(r)}>{t('na.reopen')}</button>}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {reopen && <ReasonModal title={`${t('na.reopen')} ${fr(reopen.business_date)}`} onClose={() => setReopen(null)} onSubmit={async (reason) => {
        if (!confirm(t('na.reopenConfirm'))) return;
        try { await post(`/api/night-audit/days/${reopen.id}/reopen`, { reason }); toast('success', t('na.saved')); setReopen(null); load(); reload(); } catch (e: any) { toast('error', e.message); }
      }} />}
      {ev && (
        <Modal title={`${t('na.journal')} — ${fr(ev.day.business_date)}`} onClose={() => setEv(null)}>
          {ev.events.map((e: any) => <div key={e.id} style={{ fontSize: 13 }}><span className="muted">{fmtDateTime(e.created_at, locale)} · {e.by_name ?? ''}</span> <b>{t(`na.ev_${e.kind}` as Key)}</b>{e.detail?.reason ? ` — ${e.detail.reason}` : ''}{e.detail?.difference !== undefined ? ` — ${m(e.detail.difference)}` : ''}</div>)}
        </Modal>
      )}
    </div>
  );
}
