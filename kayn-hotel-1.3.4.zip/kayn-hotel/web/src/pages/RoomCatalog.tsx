import { useCallback, useEffect, useState } from 'react';
import { AmenityPicker, PhotoStrip, amenityName, toNum } from '../components/RoomSheet';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { api, del, get, patch, post } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, money } from '../lib/format';
import { useLive } from '../lib/useLive';

function useList(url: string) {
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null);
  const load = useCallback(() => get(url).then(setRows).catch((e) => toast('error', e.message)), [url]);
  useEffect(() => { load(); }, [load]);
  useLive(load, 60000);
  return [rows, load] as const;
}
function useRun() {
  const toast = useToast();
  return async (fn: () => Promise<unknown>, ok: string) => {
    try { await fn(); toast('success', ok); return true; } catch (e: any) { toast('error', e.message); return false; }
  };
}
const optNum = (v: unknown) => (v === '' || v === null || v === undefined ? null : toNum(v));

// ===================================================== Types =====================================================
const TYPE_PRESETS = ['Single', 'Double', 'Twin', 'Triple', 'Quadruple', 'Suite', 'Familiale', 'Deluxe', 'Standard', 'Executive'];

export function TypesTab() {
  const { t, locale, lang } = useI18n();
  const { can } = useAuth();
  const run = useRun();
  const [types, load] = useList('/api/room-types/manage');
  const [amenities] = useList('/api/amenities');
  const [edit, setEdit] = useState<any | null | undefined>(undefined);
  const manage = can('rooms.manage');
  return (
    <>
      <div className="row between">
        <span className="muted" style={{ fontSize: 13 }}>{types?.filter((x) => x.active).length ?? 0} catégories actives — tarifs semaine / week-end, capacité et équipements par défaut.</span>
        {manage && <button className="btn primary" onClick={() => setEdit(null)}><Icon name="plus" /> {t('ty.new')}</button>}
      </div>
      {!types ? t('common.loading') : (
        <div className="type-grid">
          {types.map((ty) => (
            <div key={ty.id} className="card type-card" style={{ opacity: ty.active ? 1 : 0.55 }}>
              {ty.photo_id ? <img src={`/api/photos/${ty.photo_id}`} alt="" className="type-photo" /> : <div className="type-photo empty"><Icon name="bed" size={28} /></div>}
              <div className="row between" style={{ flexWrap: 'nowrap' }}>
                <b style={{ fontSize: 16 }}>{ty.name}</b><span className="pill" style={{ background: 'var(--soft)' }}>{ty.code}</span>
              </div>
              <span className="muted" style={{ fontSize: 12.5 }}>{ty.category} · {ty.capacity} pers. ({ty.max_adults} ad. / {ty.max_children} enf.) · {ty.beds} lit(s){ty.bed_type ? ` ${ty.bed_type}` : ''}{ty.area_m2 ? ` · ${ty.area_m2} m²` : ''}</span>
              <div className="row" style={{ gap: 14 }}>
                <span><span className="muted" style={{ fontSize: 12 }}>{t('ty.baseRate')}</span><br /><b>{money(ty.base_rate, locale)}</b></span>
                <span><span className="muted" style={{ fontSize: 12 }}>{t('ty.weekendRate')}</span><br /><b>{ty.weekend_rate ? money(ty.weekend_rate, locale) : '='}</b></span>
                <span><span className="muted" style={{ fontSize: 12 }}>{t('ty.rooms')}</span><br /><b>{ty.room_count}</b></span>
              </div>
              <span className="muted" style={{ fontSize: 12 }}>{(ty.amenity_ids ?? []).map((id: number) => amenities?.find((a) => a.id === id)).filter(Boolean).map((a: any) => amenityName(a, lang)).join(' · ')}</span>
              {manage && (
                <div className="row" style={{ gap: 6, marginTop: 'auto' }}>
                  <button className="btn sm" onClick={() => setEdit(ty)}>{t('common.edit')}</button>
                  {ty.active
                    ? <button className="btn sm ghost danger" onClick={() => run(() => post(`/api/room-types/${ty.id}/deactivate`), 'Type désactivé.').then(load)}>{t('ty.deactivate')}</button>
                    : <button className="btn sm ghost" onClick={() => run(() => post(`/api/room-types/${ty.id}/activate`), 'Type réactivé.').then(load)}>{t('ty.activate')}</button>}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      {edit !== undefined && amenities && <TypeForm type={edit} amenities={amenities} existing={types ?? []} onClose={() => setEdit(undefined)} onSaved={() => { setEdit(undefined); load(); }} />}
    </>
  );
}

function TypeForm({ type, amenities, existing, onClose, onSaved }: { type: any | null; amenities: any[]; existing: any[]; onClose: () => void; onSaved: () => void }) {
  const { t } = useI18n();
  const run = useRun();
  const [f, setF] = useState<any>(() => type
    ? { ...type, description: type.description ?? '', bed_type: type.bed_type ?? '', area_m2: type.area_m2 ?? '', weekend_rate: type.weekend_rate ?? '', amenity_ids: type.amenity_ids ?? [] }
    : { code: '', name: '', category: 'Standard', description: '', capacity: 2, max_adults: 2, max_children: 1, beds: 1, bed_type: '', area_m2: '', base_rate: '', weekend_rate: '', child_rate: 0, amenity_ids: amenities.filter((a) => a.builtin && ['wifi', 'ac', 'tv', 'bathroom'].includes(a.code)).map((a) => a.id) });
  const set = (p: any) => setF({ ...f, ...p });
  const save = async () => {
    const body = {
      code: f.code.trim(), name: f.name.trim(), category: f.category, description: f.description || null,
      capacity: toNum(f.capacity), max_adults: toNum(f.max_adults), max_children: toNum(f.max_children), beds: toNum(f.beds),
      bed_type: f.bed_type || null, area_m2: optNum(f.area_m2), base_rate: toNum(f.base_rate), weekend_rate: optNum(f.weekend_rate), child_rate: toNum(f.child_rate),
      amenity_ids: f.amenity_ids,
    };
    if (await run(() => (type ? patch(`/api/room-types/${type.id}`, body) : post('/api/room-types', body)), type ? 'Type mis à jour.' : 'Type créé.')) onSaved();
  };
  const preset = (name: string) => {
    const cap: Record<string, number> = { Single: 1, Double: 2, Twin: 2, Triple: 3, Quadruple: 4, Suite: 2, Familiale: 4, Deluxe: 2, Standard: 2, Executive: 2 };
    const code = name.slice(0, 3).toUpperCase();
    set({ name, code: existing.some((x) => x.code === code) ? '' : code, capacity: cap[name], max_adults: cap[name], beds: name === 'Twin' ? 2 : Math.max(1, cap[name] - 1) });
  };
  return (
    <Modal title={type ? `${t('ty.edit')} ${type.name}` : t('ty.new')} onClose={onClose} size="lg"
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.code || !f.name || f.base_rate === ''} onClick={save}>{t('common.save')}</button></>}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {!type && (
          <div className="row" style={{ gap: 6 }}>
            <span className="muted" style={{ fontSize: 13 }}>Modèles :</span>
            {TYPE_PRESETS.filter((p) => !existing.some((x) => x.name === p)).map((p) => <button key={p} className="chip" onClick={() => preset(p)}>{p}</button>)}
            <span className="muted" style={{ fontSize: 12 }}>ou saisissez un type personnalisé</span>
          </div>
        )}
        <div className="section">
          <h3>{t('rm.tInfo')}</h3>
          <div className="form-grid">
            <Field label={t('ty.name')} htmlFor="ty-name"><input id="ty-name" className="input" value={f.name} onChange={(e) => set({ name: e.target.value })} /></Field>
            <Field label={t('ty.code')} htmlFor="ty-code"><input id="ty-code" className="input" maxLength={12} value={f.code} onChange={(e) => set({ code: e.target.value.toUpperCase() })} /></Field>
            <Field label={t('ty.category')} htmlFor="ty-cat">
              <select id="ty-cat" className="input" value={f.category} onChange={(e) => set({ category: e.target.value })}>
                {['Économique', 'Standard', 'Supérieure', 'Deluxe', 'Suite'].map((x) => <option key={x}>{x}</option>)}
                {!['Économique', 'Standard', 'Supérieure', 'Deluxe', 'Suite'].includes(f.category) && <option>{f.category}</option>}
              </select>
            </Field>
            <Field label={t('rm.capacity')} htmlFor="ty-cap"><input id="ty-cap" className="input" inputMode="numeric" value={f.capacity} onChange={(e) => set({ capacity: e.target.value })} /></Field>
            <Field label={t('ty.maxAdults')} htmlFor="ty-ma"><input id="ty-ma" className="input" inputMode="numeric" value={f.max_adults} onChange={(e) => set({ max_adults: e.target.value })} /></Field>
            <Field label={t('ty.maxChildren')} htmlFor="ty-mc"><input id="ty-mc" className="input" inputMode="numeric" value={f.max_children} onChange={(e) => set({ max_children: e.target.value })} /></Field>
            <Field label={t('rm.beds')} htmlFor="ty-beds"><input id="ty-beds" className="input" inputMode="numeric" value={f.beds} onChange={(e) => set({ beds: e.target.value })} /></Field>
            <Field label={t('ty.bedType')} htmlFor="ty-bt"><input id="ty-bt" className="input" placeholder="Ex. : 1 lit 160 cm" value={f.bed_type} onChange={(e) => set({ bed_type: e.target.value })} /></Field>
            <Field label={t('ty.area')} htmlFor="ty-area"><input id="ty-area" className="input" inputMode="decimal" value={f.area_m2} onChange={(e) => set({ area_m2: e.target.value })} /></Field>
          </div>
          <Field label={t('rm.description')} htmlFor="ty-desc"><textarea id="ty-desc" className="input" rows={2} value={f.description} onChange={(e) => set({ description: e.target.value })} /></Field>
        </div>
        <div className="section">
          <h3>{t('rm.tabRates')}</h3>
          <div className="form-grid">
            <Field label={`${t('ty.baseRate')} (DA)`} htmlFor="ty-br"><input id="ty-br" className="input" inputMode="decimal" value={f.base_rate} onChange={(e) => set({ base_rate: e.target.value })} /></Field>
            <Field label={`${t('ty.weekendRate')} (DA)`} htmlFor="ty-wr"><input id="ty-wr" className="input" inputMode="decimal" placeholder="= tarif de base" value={f.weekend_rate} onChange={(e) => set({ weekend_rate: e.target.value })} /></Field>
            <Field label={`${t('ty.childRate')} (DA)`} htmlFor="ty-cr"><input id="ty-cr" className="input" inputMode="decimal" value={f.child_rate} onChange={(e) => set({ child_rate: e.target.value })} /></Field>
          </div>
        </div>
        <div className="section">
          <h3>{t('rm.amenities')}</h3>
          <AmenityPicker amenities={amenities} value={f.amenity_ids} onChange={(v) => set({ amenity_ids: v })} />
        </div>
        {type && (
          <div className="section">
            <h3>{t('rm.photos')}</h3>
            <TypePhotos typeId={type.id} />
          </div>
        )}
      </div>
    </Modal>
  );
}

function TypePhotos({ typeId }: { typeId: number }) {
  const [photos, load] = useList(`/api/photos?owner_type=room_type&owner_id=${typeId}`);
  return <PhotoStrip photos={photos ?? []} ownerType="room_type" ownerId={typeId} editable onChanged={load} />;
}

// ============================================== Étages & bâtiments ==============================================
export function FloorsTab() {
  const { t } = useI18n();
  const { can } = useAuth();
  const run = useRun();
  const [floors, load] = useList('/api/floors/stats');
  const [buildings, loadB] = useList('/api/buildings');
  const [form, setForm] = useState<null | { kind: 'floor' | 'building'; row: any }>(null);
  const manage = can('rooms.manage');
  const reload = () => { load(); loadB(); };
  return (
    <>
      <div className="row between">
        <span className="muted" style={{ fontSize: 13 }}>Suppression contrôlée : un étage contenant des chambres (même désactivées) ne peut pas être supprimé.</span>
        {manage && (
          <div className="row" style={{ gap: 6 }}>
            <button className="btn" onClick={() => setForm({ kind: 'building', row: null })}><Icon name="plus" /> {t('fl.newBuilding')}</button>
            <button className="btn primary" onClick={() => setForm({ kind: 'floor', row: null })}><Icon name="plus" /> {t('fl.newFloor')}</button>
          </div>
        )}
      </div>
      {!floors || !buildings ? t('common.loading') : buildings.map((b) => {
        const fl = floors.filter((x) => x.building_id === b.id);
        const tot = fl.reduce((s, x) => s + x.rooms, 0);
        const occ = fl.reduce((s, x) => s + x.occupied, 0);
        return (
          <div key={b.id} className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="row between">
              <div>
                <b style={{ fontSize: 16 }}>{b.name}</b> <span className="pill" style={{ background: 'var(--soft)' }}>{b.code}</span>
                <div className="muted" style={{ fontSize: 12.5 }}>{fl.length} étage(s) · {tot} chambre(s) · occupation {tot ? Math.round((occ / tot) * 100) : 0} %</div>
              </div>
              {manage && (
                <div className="row" style={{ gap: 6 }}>
                  <button className="btn sm" onClick={() => setForm({ kind: 'building', row: b })}>{t('common.edit')}</button>
                  {!fl.length && <button className="btn sm ghost danger" onClick={() => confirm(`Supprimer ${b.name} ?`) && run(() => del(`/api/buildings/${b.id}`), 'Bâtiment supprimé.').then(reload)}>{t('fl.delete')}</button>}
                </div>
              )}
            </div>
            <div style={{ overflow: 'auto' }}>
              <table className="table">
                <thead><tr><th>{t('rm.floor')}</th><th className="num">{t('common.rooms')}</th><th className="num">{t('rs.available')}</th><th className="num">{t('rs.reserved')}</th><th className="num">{t('rs.occupied')}</th><th className="num">{t('hk.to_clean')}</th><th className="num">{t('rs.out_of_service')}</th><th className="num">{t('rm.capacity')}</th><th>{t('rm.occupancy')}</th><th /></tr></thead>
                <tbody>
                  {fl.map((x) => {
                    const pct = x.rooms ? Math.round((x.occupied / x.rooms) * 100) : 0;
                    return (
                      <tr key={x.id}>
                        <td><b>{x.name}</b> <span className="muted">· niv. {x.number}</span></td>
                        <td className="num">{x.rooms}</td><td className="num">{x.available}</td><td className="num">{x.reserved}</td><td className="num">{x.occupied}</td>
                        <td className="num">{x.dirty}</td><td className="num">{x.out_of_service + x.maintenance}</td><td className="num">{x.beds_capacity}</td>
                        <td style={{ minWidth: 120 }}><div className="meter" style={{ height: 8, borderRadius: 4, background: 'var(--soft)', overflow: 'hidden' }}><div style={{ width: `${pct}%`, height: '100%', background: 'var(--primary)' }} /></div><span className="muted" style={{ fontSize: 11 }}>{pct} %</span></td>
                        <td>{manage && (
                          <div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                            <button className="btn sm ghost" onClick={() => setForm({ kind: 'floor', row: x })}>{t('common.edit')}</button>
                            <button className="btn sm ghost danger" disabled={x.rooms > 0} title={x.rooms > 0 ? 'Réaffectez d’abord les chambres' : ''} onClick={() => confirm(`Supprimer ${x.name} ?`) && run(() => del(`/api/floors/${x.id}`), 'Étage supprimé.').then(reload)}>{t('fl.delete')}</button>
                          </div>
                        )}</td>
                      </tr>
                    );
                  })}
                  {!fl.length && <tr><td colSpan={10} className="muted">{t('common.none')}</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        );
      })}
      {form && buildings && <FloorForm kind={form.kind} row={form.row} buildings={buildings} floors={floors ?? []} onClose={() => setForm(null)} onSaved={() => { setForm(null); reload(); }} />}
    </>
  );
}

function FloorForm({ kind, row, buildings, floors, onClose, onSaved }: { kind: 'floor' | 'building'; row: any; buildings: any[]; floors: any[]; onClose: () => void; onSaved: () => void }) {
  const { t } = useI18n();
  const run = useRun();
  const nextLevel = Math.max(-1, ...floors.filter((x) => x.building_id === buildings[0]?.id).map((x) => x.number)) + 1;
  const [f, setF] = useState<any>(() => kind === 'floor'
    ? (row ? { building_id: row.building_id, number: row.number, name: row.name, description: row.description ?? '' } : { building_id: buildings[0]?.id, number: nextLevel, name: nextLevel === 0 ? 'Rez-de-chaussée' : `Étage ${nextLevel}`, description: '' })
    : (row ? { code: row.code, name: row.name, description: row.description ?? '' } : { code: '', name: '', description: '' }));
  const set = (p: any) => setF({ ...f, ...p });
  const save = async () => {
    const body = kind === 'floor'
      ? { building_id: Number(f.building_id), number: Math.round(toNum(f.number)), name: f.name.trim(), description: f.description || null }
      : { code: f.code.trim(), name: f.name.trim(), description: f.description || null };
    const url = kind === 'floor' ? '/api/floors' : '/api/buildings';
    if (await run(() => (row ? patch(`${url}/${row.id}`, body) : post(url, body)), 'Enregistré.')) onSaved();
  };
  return (
    <Modal title={kind === 'floor' ? (row ? `${t('common.edit')} ${row.name}` : t('fl.newFloor')) : (row ? `${t('common.edit')} ${row.name}` : t('fl.newBuilding'))} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!String(f.name).trim()} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        {kind === 'floor' ? (
          <>
            <Field label={t('rm.building')} htmlFor="fl-b"><select id="fl-b" className="input" value={f.building_id} onChange={(e) => set({ building_id: e.target.value })}>{buildings.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select></Field>
            <Field label={t('fl.number')} htmlFor="fl-n"><input id="fl-n" className="input" inputMode="numeric" value={f.number} onChange={(e) => set({ number: e.target.value })} /></Field>
          </>
        ) : <Field label={t('ty.code')} htmlFor="fl-c"><input id="fl-c" className="input" maxLength={10} value={f.code} onChange={(e) => set({ code: e.target.value.toUpperCase() })} /></Field>}
        <Field label={t('fl.name')} htmlFor="fl-name"><input id="fl-name" className="input" value={f.name} onChange={(e) => set({ name: e.target.value })} /></Field>
      </div>
      <div style={{ marginTop: 12 }}><Field label={t('rm.description')} htmlFor="fl-d"><input id="fl-d" className="input" value={f.description} onChange={(e) => set({ description: e.target.value })} /></Field></div>
    </Modal>
  );
}

// ===================================================== Tarifs =====================================================
const PLAN_KINDS = ['standard', 'corporate', 'agency', 'group', 'negotiated', 'promo'];

export function RatesTab() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const run = useRun();
  const [plans, loadPlans] = useList('/api/rate-plans');
  const [seasons, loadSeasons] = useList('/api/rate-seasons');
  const [types] = useList('/api/room-types/manage');
  const [planForm, setPlanForm] = useState<any | null | undefined>(undefined);
  const [seasonForm, setSeasonForm] = useState<any | null | undefined>(undefined);
  const [weekend, setWeekend] = useState<number[] | null>(null);
  const manage = can('rooms.manage');
  useEffect(() => { get('/api/settings').then((s) => setWeekend(s.weekend_nights ?? [4, 5])).catch(() => setWeekend([4, 5])); }, []);
  const adj = (type: string, v: number) => (type === 'none' ? '—' : type === 'percent' ? `${v > 0 ? '+' : ''}${v} %` : type === 'fixed' ? money(v, locale) : `${v > 0 ? '+' : ''}${money(v, locale)}`);
  const saveWeekend = (v: number[]) => run(() => api('PUT', '/api/settings', { weekend_nights: v }), 'Nuits week-end enregistrées.').then((ok) => ok && setWeekend(v));

  return (
    <>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <h3 style={{ margin: 0 }}>{t('rt.weekend')}</h3>
        <span className="muted" style={{ fontSize: 12.5 }}>Nuit du … au lendemain. Par défaut jeudi et vendredi soir (week-end algérien).</span>
        <div className="row" style={{ gap: 6 }}>
          {[0, 1, 2, 3, 4, 5, 6].map((d) => {
            const on = weekend?.includes(d);
            return <button key={d} className={`chip ${on ? 'on' : ''}`} disabled={!manage || !weekend} aria-pressed={on} onClick={() => weekend && saveWeekend(on ? weekend.filter((x) => x !== d) : [...weekend, d].sort())}>{t(`dow.${d}` as Key)}</button>;
          })}
        </div>
      </div>

      <div className="row between"><h3 style={{ margin: 0 }}>{t('rt.plans')}</h3>{manage && <button className="btn primary" onClick={() => setPlanForm(null)}><Icon name="plus" /> {t('rt.newPlan')}</button>}</div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('ty.code')}</th><th>{t('ty.name')}</th><th>{t('rt.kind')}</th><th>{t('rt.adjust')}</th><th>{t('rt.company')}</th><th>{t('rt.minNights')}</th><th>{t('rt.validFrom')}</th><th>{t('rt.fixedPrices')}</th><th /></tr></thead>
          <tbody>
            {(plans ?? []).map((p) => (
              <tr key={p.id} style={{ opacity: p.active ? 1 : 0.5 }}>
                <td><b>{p.code}</b></td><td>{p.name}</td><td>{t(`pk.${p.kind}` as Key)}</td><td>{adj(p.adjustment_type, p.adjustment_value)}</td>
                <td>{p.company_name ?? '—'}</td><td>{p.min_nights}</td>
                <td>{p.valid_from || p.valid_to ? `${fmtDate(p.valid_from, locale, { day: 'numeric', month: 'short', year: '2-digit' })} → ${fmtDate(p.valid_to, locale, { day: 'numeric', month: 'short', year: '2-digit' })}` : '—'}</td>
                <td>{p.prices.length ? `${p.prices.length} catégorie(s)` : '—'}</td>
                <td>{manage && p.kind !== 'standard' && (
                  <div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                    <button className="btn sm ghost" onClick={() => setPlanForm(p)}>{t('common.edit')}</button>
                    <button className="btn sm ghost" onClick={() => run(() => patch(`/api/rate-plans/${p.id}`, { active: !p.active }), p.active ? 'Tarif désactivé.' : 'Tarif activé.').then(loadPlans)}>{p.active ? t('ty.deactivate') : t('ty.activate')}</button>
                  </div>
                )}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="row between"><h3 style={{ margin: 0 }}>{t('rt.seasons')}</h3>{manage && <button className="btn primary" onClick={() => setSeasonForm(null)}><Icon name="plus" /> {t('rt.newSeason')}</button>}</div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('ty.name')}</th><th>{t('rt.kind')}</th><th>{t('rm.from')}</th><th>{t('rt.validTo')}</th><th>{t('rm.type')}</th><th>{t('rt.adjust')}</th><th /></tr></thead>
          <tbody>
            {(seasons ?? []).map((s) => (
              <tr key={s.id} style={{ opacity: s.active ? 1 : 0.5 }}>
                <td><b>{s.name}</b></td>
                <td><span className="pill" style={{ background: s.kind === 'high' ? '#FEE2E2' : s.kind === 'low' ? '#DBEAFE' : 'var(--gold-soft)', color: s.kind === 'high' ? '#991B1B' : s.kind === 'low' ? '#1E3A8A' : 'var(--gold-text)' }}>{t(`sk.${s.kind}` as Key)}</span></td>
                <td>{fmtDate(s.start_date, locale)}</td><td>{fmtDate(s.end_date, locale)}</td>
                <td>{s.room_type_id ? types?.find((x) => x.id === s.room_type_id)?.name : t('rt.allTypes')}</td><td>{adj(s.adjustment_type, s.adjustment_value)}</td>
                <td>{manage && (
                  <div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                    <button className="btn sm ghost" onClick={() => setSeasonForm(s)}>{t('common.edit')}</button>
                    <button className="btn sm ghost danger" onClick={() => confirm(`Supprimer « ${s.name} » ?`) && run(() => del(`/api/rate-seasons/${s.id}`), 'Période supprimée.').then(loadSeasons)}>{t('fl.delete')}</button>
                  </div>
                )}</td>
              </tr>
            ))}
            {seasons && !seasons.length && <tr><td colSpan={7} className="muted">{t('common.none')}</td></tr>}
          </tbody>
        </table>
      </div>
      <QuoteSimulator types={types ?? []} plans={(plans ?? []).filter((p) => p.active)} />
      {planForm !== undefined && types && <PlanForm plan={planForm} types={types.filter((x) => x.active)} onClose={() => setPlanForm(undefined)} onSaved={() => { setPlanForm(undefined); loadPlans(); }} />}
      {seasonForm !== undefined && types && <SeasonForm season={seasonForm} types={types.filter((x) => x.active)} onClose={() => setSeasonForm(undefined)} onSaved={() => { setSeasonForm(undefined); loadSeasons(); }} />}
    </>
  );
}

function PlanForm({ plan, types, onClose, onSaved }: { plan: any | null; types: any[]; onClose: () => void; onSaved: () => void }) {
  const { t } = useI18n();
  const run = useRun();
  const [f, setF] = useState<any>(() => plan
    ? { ...plan, company_name: plan.company_name ?? '', valid_from: plan.valid_from ?? '', valid_to: plan.valid_to ?? '', description: plan.description ?? '', prices: Object.fromEntries(plan.prices.map((x: any) => [x.room_type_id, x.price])) }
    : { code: '', name: '', kind: 'corporate', adjustment_type: 'percent', adjustment_value: -10, company_name: '', min_nights: 1, valid_from: '', valid_to: '', description: '', prices: {} });
  const set = (p: any) => setF({ ...f, ...p });
  const save = async () => {
    const body = {
      code: f.code.trim(), name: f.name.trim(), kind: f.kind, adjustment_type: f.adjustment_type, adjustment_value: toNum(f.adjustment_value),
      company_name: f.company_name.trim() || null, ...(f.company_name.trim() ? {} : { guest_id: null }), min_nights: Math.max(1, Math.round(toNum(f.min_nights))),
      valid_from: f.valid_from || null, valid_to: f.valid_to || null, description: f.description || null,
      prices: types.map((ty) => ({ room_type_id: ty.id, price: optNum(f.prices[ty.id]) })),
    };
    if (await run(() => (plan ? patch(`/api/rate-plans/${plan.id}`, body) : post('/api/rate-plans', body)), plan ? 'Tarif mis à jour.' : 'Tarif créé.')) onSaved();
  };
  return (
    <Modal title={plan ? `${t('common.edit')} ${plan.name}` : t('rt.newPlan')} onClose={onClose} size="lg"
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.code || !f.name} onClick={save}>{t('common.save')}</button></>}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div className="form-grid">
          <Field label={t('ty.name')} htmlFor="rp-n"><input id="rp-n" className="input" value={f.name} onChange={(e) => set({ name: e.target.value })} /></Field>
          <Field label={t('ty.code')} htmlFor="rp-c"><input id="rp-c" className="input" maxLength={12} value={f.code} onChange={(e) => set({ code: e.target.value.toUpperCase() })} /></Field>
          <Field label={t('rt.kind')} htmlFor="rp-k"><select id="rp-k" className="input" value={f.kind} onChange={(e) => set({ kind: e.target.value })}>{PLAN_KINDS.filter((k) => k !== 'standard').map((k) => <option key={k} value={k}>{t(`pk.${k}` as Key)}</option>)}</select></Field>
          <Field label={t('rt.adjust')} htmlFor="rp-at"><select id="rp-at" className="input" value={f.adjustment_type} onChange={(e) => set({ adjustment_type: e.target.value })}><option value="none">{t('rt.adjNone')}</option><option value="percent">{t('rt.adjPercent')}</option><option value="amount">{t('rt.adjAmount')}</option></select></Field>
          {f.adjustment_type !== 'none' && <Field label={t('common.amount')} htmlFor="rp-av"><input id="rp-av" className="input" inputMode="decimal" value={f.adjustment_value} onChange={(e) => set({ adjustment_value: e.target.value })} /></Field>}
          <Field label={t('rt.minNights')} htmlFor="rp-mn"><input id="rp-mn" className="input" inputMode="numeric" value={f.min_nights} onChange={(e) => set({ min_nights: e.target.value })} /></Field>
          <Field label={t('rt.validFrom')} htmlFor="rp-vf"><input id="rp-vf" type="date" className="input" value={f.valid_from} onChange={(e) => set({ valid_from: e.target.value })} /></Field>
          <Field label={t('rt.validTo')} htmlFor="rp-vt"><input id="rp-vt" type="date" className="input" value={f.valid_to} onChange={(e) => set({ valid_to: e.target.value })} /></Field>
        </div>
        {(f.kind === 'negotiated' || f.kind === 'corporate' || f.kind === 'agency') && (
          <Field label={t('rt.company')} htmlFor="rp-co"><input id="rp-co" className="input" placeholder="Laisser vide = tarif ouvert à tous" value={f.company_name} onChange={(e) => set({ company_name: e.target.value })} /></Field>
        )}
        <div className="section">
          <h3>{t('rt.fixedPrices')}</h3>
          <span className="muted" style={{ fontSize: 12.5 }}>Un prix fixe remplace le tarif de la catégorie (semaine et week-end) ; l'ajustement s'applique ensuite.</span>
          <div className="form-grid">
            {types.map((ty) => (
              <Field key={ty.id} label={`${ty.name} (${money(ty.base_rate)})`} htmlFor={`rp-p${ty.id}`}>
                <input id={`rp-p${ty.id}`} className="input" inputMode="decimal" placeholder="—" value={f.prices[ty.id] ?? ''} onChange={(e) => set({ prices: { ...f.prices, [ty.id]: e.target.value } })} />
              </Field>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
}

function SeasonForm({ season, types, onClose, onSaved }: { season: any | null; types: any[]; onClose: () => void; onSaved: () => void }) {
  const { t } = useI18n();
  const run = useRun();
  const [f, setF] = useState<any>(() => season ? { ...season, room_type_id: season.room_type_id ?? '' } : { name: '', kind: 'high', start_date: '', end_date: '', room_type_id: '', adjustment_type: 'percent', adjustment_value: 20, active: true });
  const set = (p: any) => setF({ ...f, ...p });
  const save = async () => {
    const body = { name: f.name.trim(), kind: f.kind, start_date: f.start_date, end_date: f.end_date, room_type_id: f.room_type_id ? Number(f.room_type_id) : null, adjustment_type: f.adjustment_type, adjustment_value: toNum(f.adjustment_value), active: !!f.active };
    if (await run(() => (season ? patch(`/api/rate-seasons/${season.id}`, body) : post('/api/rate-seasons', body)), 'Période enregistrée.')) onSaved();
  };
  return (
    <Modal title={season ? `${t('common.edit')} ${season.name}` : t('rt.newSeason')} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.name || !f.start_date || !f.end_date} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('ty.name')} htmlFor="se-n"><input id="se-n" className="input" placeholder="Ex. : Été 2027" value={f.name} onChange={(e) => set({ name: e.target.value })} /></Field>
        <Field label={t('rt.kind')} htmlFor="se-k"><select id="se-k" className="input" value={f.kind} onChange={(e) => set({ kind: e.target.value })}>{['high', 'low', 'event'].map((k) => <option key={k} value={k}>{t(`sk.${k}` as Key)}</option>)}</select></Field>
        <Field label={t('rm.from')} htmlFor="se-s"><input id="se-s" type="date" className="input" value={f.start_date} onChange={(e) => set({ start_date: e.target.value })} /></Field>
        <Field label={`${t('rt.validTo')} (inclus)`} htmlFor="se-e"><input id="se-e" type="date" className="input" min={f.start_date} value={f.end_date} onChange={(e) => set({ end_date: e.target.value })} /></Field>
        <Field label={t('rm.type')} htmlFor="se-t"><select id="se-t" className="input" value={f.room_type_id} onChange={(e) => set({ room_type_id: e.target.value })}><option value="">{t('rt.allTypes')}</option>{types.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></Field>
        <Field label={t('rt.adjust')} htmlFor="se-at"><select id="se-at" className="input" value={f.adjustment_type} onChange={(e) => set({ adjustment_type: e.target.value })}><option value="percent">{t('rt.adjPercent')}</option><option value="amount">{t('rt.adjAmount')}</option><option value="fixed">{t('rt.fixed')}</option></select></Field>
        <Field label={t('common.amount')} htmlFor="se-av"><input id="se-av" className="input" inputMode="decimal" value={f.adjustment_value} onChange={(e) => set({ adjustment_value: e.target.value })} /></Field>
      </div>
    </Modal>
  );
}

/** Simulateur : prix réel calculé par le moteur tarifaire (même calcul que la réservation). */
function QuoteSimulator({ types, plans }: { types: any[]; plans: any[] }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [rooms, setRooms] = useState<any[]>([]);
  const [q, setQ] = useState({ room_id: '', check_in: '', check_out: '', rate_plan_id: '', meal_plan: 'RO', adults: 2 });
  const [res, setRes] = useState<any>(null);
  useEffect(() => { get('/api/rooms/manage').then(setRooms).catch(() => {}); }, []);
  useEffect(() => {
    if (!q.room_id || !q.check_in || !q.check_out || q.check_out <= q.check_in) { setRes(null); return; }
    post('/api/rates/quote', { check_in: q.check_in, check_out: q.check_out, meal_plan: q.meal_plan, rate_plan_id: q.rate_plan_id ? Number(q.rate_plan_id) : null, rooms: [{ room_id: Number(q.room_id), adults: q.adults, children: 0 }] })
      .then(setRes).catch((e) => toast('error', e.message));
  }, [q]);
  const set = (p: any) => setQ({ ...q, ...p });
  const r0 = res?.rooms?.[0];
  return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <h3 style={{ margin: 0 }}>Simulateur de prix</h3>
      <div className="form-grid">
        <Field label={t('common.room')} htmlFor="qs-r"><select id="qs-r" className="input" value={q.room_id} onChange={(e) => set({ room_id: e.target.value })}><option value="">—</option>{rooms.map((r) => <option key={r.id} value={r.id}>{r.number} · {r.type_name}</option>)}</select></Field>
        <Field label={t('rm.from')} htmlFor="qs-a"><input id="qs-a" type="date" className="input" value={q.check_in} onChange={(e) => set({ check_in: e.target.value })} /></Field>
        <Field label={t('rt.validTo')} htmlFor="qs-b"><input id="qs-b" type="date" className="input" min={q.check_in} value={q.check_out} onChange={(e) => set({ check_out: e.target.value })} /></Field>
        <Field label={t('form.ratePlan')} htmlFor="qs-p"><select id="qs-p" className="input" value={q.rate_plan_id} onChange={(e) => set({ rate_plan_id: e.target.value })}><option value="">{t('pk.standard')}</option>{plans.filter((p) => p.kind !== 'standard').map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
        <Field label={t('res.meal')} htmlFor="qs-m"><select id="qs-m" className="input" value={q.meal_plan} onChange={(e) => set({ meal_plan: e.target.value })}>{['RO', 'BB', 'HB', 'FB'].map((m) => <option key={m} value={m}>{t(`meal.${m}` as Key)}</option>)}</select></Field>
      </div>
      {res?.plan_error && <div className="alert">{res.plan_error}</div>}
      {r0 && (
        <div style={{ overflow: 'auto' }}>
          <table className="table">
            <thead><tr><th>Nuit</th><th className="num">Prix</th><th>Détail</th></tr></thead>
            <tbody>
              {r0.nights.map((n: any) => <tr key={n.date}><td>{fmtDate(n.date, locale)}</td><td className="num">{money(n.price, locale)}</td><td className="muted" style={{ fontSize: 12 }}>{[n.weekend && 'week-end', n.season].filter(Boolean).join(' · ')}</td></tr>)}
              <tr><td><b>{t('common.total')}</b> ({r0.nights.length} {t('common.nights')})</td><td className="num"><b>{money(r0.total, locale)}</b></td><td className="muted">moy. {money(r0.avg, locale)} / nuit</td></tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ================================================== Équipements ==================================================
export function AmenitiesTab() {
  const { t, lang } = useI18n();
  const { can } = useAuth();
  const run = useRun();
  const [rows, load] = useList('/api/amenities');
  const [f, setF] = useState({ name_fr: '', name_en: '', name_ar: '' });
  const [edit, setEdit] = useState<any>(null);
  const manage = can('rooms.manage');
  const add = async () => {
    if (await run(() => post('/api/amenities', { name_fr: f.name_fr.trim(), name_en: f.name_en.trim() || undefined, name_ar: f.name_ar.trim() || undefined }), 'Équipement ajouté.')) {
      setF({ name_fr: '', name_en: '', name_ar: '' });
      load();
    }
  };
  return (
    <>
      {manage && (
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <h3 style={{ margin: 0 }}>{t('am.new')}</h3>
          <div className="form-grid">
            <Field label="Français" htmlFor="am-fr"><input id="am-fr" className="input" placeholder="Ex. : Machine à café" value={f.name_fr} onChange={(e) => setF({ ...f, name_fr: e.target.value })} /></Field>
            <Field label="English" htmlFor="am-en"><input id="am-en" className="input" placeholder="Coffee machine" value={f.name_en} onChange={(e) => setF({ ...f, name_en: e.target.value })} /></Field>
            <Field label="العربية" htmlFor="am-ar"><input id="am-ar" className="input" dir="rtl" placeholder="آلة القهوة" value={f.name_ar} onChange={(e) => setF({ ...f, name_ar: e.target.value })} /></Field>
          </div>
          <div><button className="btn primary" disabled={f.name_fr.trim().length < 2} onClick={add}><Icon name="plus" /> {t('common.add')}</button></div>
        </div>
      )}
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>Français</th><th>English</th><th>العربية</th><th className="num">{t('common.rooms')}</th><th /><th /></tr></thead>
          <tbody>
            {(rows ?? []).map((a) => (
              <tr key={a.id} style={{ opacity: a.active ? 1 : 0.5 }}>
                {edit?.id === a.id ? (
                  <>
                    <td><input className="input" aria-label="Français" value={edit.name_fr} onChange={(e) => setEdit({ ...edit, name_fr: e.target.value })} /></td>
                    <td><input className="input" aria-label="English" value={edit.name_en} onChange={(e) => setEdit({ ...edit, name_en: e.target.value })} /></td>
                    <td><input className="input" aria-label="العربية" dir="rtl" value={edit.name_ar} onChange={(e) => setEdit({ ...edit, name_ar: e.target.value })} /></td>
                  </>
                ) : <><td><b>{a.name_fr}</b></td><td>{a.name_en}</td><td dir="rtl">{a.name_ar}</td></>}
                <td className="num">{a.room_count}</td>
                <td>{a.builtin ? <span className="pill" style={{ background: 'var(--soft)' }}>Standard</span> : <span className="pill" style={{ background: 'var(--gold-soft)', color: 'var(--gold-text)' }}>{t('am.custom')}</span>}</td>
                <td>{manage && (edit?.id === a.id ? (
                  <div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                    <button className="btn sm primary" onClick={() => run(() => patch(`/api/amenities/${a.id}`, { name_fr: edit.name_fr, name_en: edit.name_en, name_ar: edit.name_ar }), 'Enregistré.').then((ok) => { if (ok) { setEdit(null); load(); } })}>{t('common.save')}</button>
                    <button className="btn sm ghost" onClick={() => setEdit(null)}>{t('common.cancel')}</button>
                  </div>
                ) : (
                  <div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                    <button className="btn sm ghost" onClick={() => setEdit(a)}>{t('common.edit')}</button>
                    <button className="btn sm ghost" onClick={() => run(() => patch(`/api/amenities/${a.id}`, { active: !a.active }), a.active ? 'Équipement masqué.' : 'Équipement réactivé.').then(load)}>{a.active ? t('ty.deactivate') : t('ty.activate')}</button>
                  </div>
                ))}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <span className="muted" style={{ fontSize: 12 }}>Langue d'affichage actuelle : {lang.toUpperCase()} — {(rows ?? []).filter((a) => a.active).map((a) => amenityName(a, lang)).slice(0, 5).join(', ')}…</span>
    </>
  );
}
