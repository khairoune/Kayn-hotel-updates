import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Page } from '../components/Layout';
import { ReasonModal } from '../components/ReservationPanel';
import { Field, HK_COLORS, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { api, get, newOpKey, patch, post, postOnce, upload } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, fmtDateTime, money, todayLocal } from '../lib/format';
import { useLive } from '../lib/useLive';

type Tab = 'board' | 'tasks' | 'staff' | 'inspection' | 'linen' | 'lost' | 'reports' | 'settings';
const HK_ORDER = ['dirty', 'to_clean', 'cleaning', 'to_inspect', 'clean', 'inspected'];
const KINDS = ['checkout_clean', 'stayover', 'arrival_prep', 'deep_clean', 'inspection', 'turndown', 'other'];
const PRIOS = ['urgent', 'high', 'normal', 'low'];
const TASK_ST = ['todo', 'in_progress', 'to_inspect', 'validated', 'done', 'cancelled'];
const hhmm = (d: string | null | undefined) => (d ? new Date(d).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '');
const monthStart = () => `${todayLocal().slice(0, 8)}01`;

function HkBadge({ st }: { st: string }) {
  const { t } = useI18n();
  return <span className="pill" style={{ background: HK_COLORS[st] ?? '#555', color: '#fff' }}>{t(`hk.${st}` as Key)}</span>;
}
function Prio({ p }: { p: string }) {
  const { t } = useI18n();
  return <span className={`pill prio-${p}`}>{t(`hkx.p_${p}` as Key)}</span>;
}
function Meter({ v }: { v: number }) {
  return <div className={`meter ${v >= 100 ? 'ok' : ''}`} role="progressbar" aria-valuenow={v} aria-valuemin={0} aria-valuemax={100}><i style={{ width: `${Math.min(100, v)}%` }} /></div>;
}
const err = (toast: any) => (e: any) => toast('error', e.message);

export function Housekeeping() {
  const { t } = useI18n();
  const { can } = useAuth();
  const [sp, setSp] = useSearchParams();
  const tabs = ([['board', 'housekeeping.view'], ['tasks', 'housekeeping.view'], ['staff', 'housekeeping.view'], ['inspection', 'housekeeping.inspect'], ['linen', 'housekeeping.view'],
    ['lost', can('lostfound.manage') ? 'lostfound.manage' : 'lostfound.record'], ['reports', 'housekeeping.reports'], ['settings', 'housekeeping.manage']] as [Tab, string][])
    .filter(([, p]) => can(p)).map(([k]) => k);
  const tab = tabs.includes(sp.get('tab') as Tab) ? (sp.get('tab') as Tab) : tabs[0];
  const [task, setTask] = useState<number | null>(null);
  return (
    <Page>
      <div className="page-head"><h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('hk.title')}</h1></div>
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>
        {tabs.map((k) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setSp({ tab: k }, { replace: true })}>{t(`hkx.t_${k}` as Key)}</button>)}
      </div>
      {tab === 'board' && <Board openTask={setTask} />}
      {tab === 'tasks' && <Tasks openTask={setTask} />}
      {tab === 'staff' && <Staff />}
      {tab === 'inspection' && <Inspection />}
      {tab === 'linen' && <Linen />}
      {tab === 'lost' && <Lost />}
      {tab === 'reports' && <Reports />}
      {tab === 'settings' && <Settings />}
      {task && <TaskDrawer id={task} onClose={() => setTask(null)} />}
    </Page>
  );
}

// ===================================================== Tableau =====================================================
function Board({ openTask }: { openTask: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [b, setB] = useState<any>(null);
  const [filter, setFilter] = useState('');
  const [oosRoom, setOosRoom] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const load = useCallback(() => { get('/api/housekeeping/board').then(setB).catch(err(toast)); }, []);
  useEffect(load, [load]);
  useLive(load, 20000);
  if (!b) return <span>{t('common.loading')}</span>;
  const k = b.kpi;
  const act = async (fn: () => Promise<any>, ok?: string) => { try { setBusy(true); const r = await fn(); if (ok) toast('success', ok.replace('{n}', String(r?.assigned ?? ''))); load(); } catch (e: any) { toast('error', e.message); } finally { setBusy(false); } };
  const keys = ['to_clean', 'cleaning', 'to_inspect', 'clean', 'inspected', 'dnd', 'out_of_service'];
  const count = (s: string) => b.rooms.filter((r: any) => (s === 'to_clean' ? ['dirty', 'to_clean'].includes(r.display) : r.display === s)).length;
  const list = b.rooms.filter((r: any) => !filter || (filter === 'to_clean' ? ['dirty', 'to_clean'].includes(r.display) : filter === 'occupied' ? r.occupied : r.display === filter));
  return (
    <>
      <div className="grid kpis">
        {[['hkx.kToClean', k.to_clean, HK_COLORS.to_clean], ['hkx.kCleaning', k.cleaning, HK_COLORS.cleaning], ['hkx.kToInspect', k.to_inspect, HK_COLORS.to_inspect],
          ['hkx.kReady', k.clean, HK_COLORS.inspected], ['hkx.kOccupied', k.occupied, HK_COLORS.occupied], ['hkx.kOos', k.out_of_service, HK_COLORS.oos]].map(([l, v, c]) => (
          <div key={l} className="card kpi" style={{ borderInlineStart: `4px solid ${c}` }}><span className="label">{t(l as Key)}</span><span className="value">{v}</span></div>
        ))}
        <div className="card kpi"><span className="label">{t('hkx.kProgress')} · {k.tasks.finished}/{k.tasks.total}</span><span className="value">{k.progress} %</span><Meter v={k.progress} /></div>
      </div>
      <div className="row">
        <button className={`chip ${!filter ? 'on' : ''}`} onClick={() => setFilter('')}>{t('common.all')} <b>{b.rooms.length}</b></button>
        {keys.map((s) => (
          <button key={s} className={`chip ${filter === s ? 'on' : ''}`} aria-pressed={filter === s} onClick={() => setFilter(filter === s ? '' : s)}>
            <span className="sw" style={{ background: HK_COLORS[s] }} />{t(`hk.${s}` as Key)} <b>{count(s)}</b>
          </button>
        ))}
        <button className={`chip ${filter === 'occupied' ? 'on' : ''}`} onClick={() => setFilter(filter === 'occupied' ? '' : 'occupied')}><span className="sw" style={{ background: HK_COLORS.occupied }} />{t('hkx.occupied')} <b>{k.occupied}</b></button>
        <span style={{ flex: 1 }} />
        {k.tasks.late > 0 && <span className="pill prio-urgent">{k.tasks.late} {t('hkx.late')}</span>}
        {k.tasks.unassigned > 0 && <span className="pill prio-high">{k.tasks.unassigned} {t('hkx.unassigned')}</span>}
        {can('housekeeping.manage') && <>
          <button className="btn" disabled={busy} onClick={() => act(() => post('/api/housekeeping/generate', {}), t('hkx.generated'))}><Icon name="list" />{t('hkx.generate')}</button>
          <button className="btn primary" disabled={busy} onClick={() => act(() => post('/api/housekeeping/auto-assign', {}), t('hkx.assignedN'))}><Icon name="users" />{t('hkx.autoAssign')}</button>
        </>}
      </div>
      <div className="hk-grid">
        {list.map((r: any) => (
          <div key={r.id} className={`hk-card ${r.task ? 'clickable' : ''}`} onClick={() => r.task && openTask(r.task.id)} role={r.task ? 'button' : undefined} tabIndex={r.task ? 0 : undefined}
            onKeyDown={(e) => e.key === 'Enter' && r.task && openTask(r.task.id)}>
            <div className="top" style={{ borderColor: HK_COLORS[r.display] }} />
            <div className="row between">
              <div className="row" style={{ gap: 8 }}><b style={{ fontSize: 20 }}>{r.number}</b><span className="muted" style={{ fontSize: 12 }}>{r.type_name}</span></div>
              <HkBadge st={r.display} />
            </div>
            <div className="row" style={{ gap: 6, fontSize: 12.5 }}>
              {r.occupied ? <span className="pill" style={{ background: '#DBEAFE', color: '#1E3A8A' }}>{r.departure ? t('hkx.departureToday') : t('hkx.occupied')}</span> : <span className="muted">{t('hk.free')}</span>}
              {r.dnd && <span className="pill" style={{ background: HK_COLORS.dnd, color: '#fff' }}>{t('hk.dnd')}</span>}
              {r.arrival && <span className="pill" style={{ background: '#F59E0B', color: '#3B1D02' }}>{t('hk.arrivalToday')}</span>}
            </div>
            {r.arrival && <span style={{ fontSize: 12.5 }}>→ {r.arrival.guest}</span>}
            {r.task && (
              <div style={{ fontSize: 12.5, display: 'flex', flexDirection: 'column', gap: 4 }}>
                <div className="row" style={{ gap: 6 }}><b>{t(`hkx.k_${r.task.kind}` as Key)}</b><Prio p={r.task.priority} />{r.task.refusal_count > 0 && <span className="pill prio-urgent">{t('hkx.refused')} ×{r.task.refusal_count}</span>}</div>
                <span className="muted">{r.task.assignee ?? t('hkx.unassigned')} · {t(`hkx.s_${r.task.status}` as Key)}{r.task.due_at ? ` · ${t('hkx.due')} ${hhmm(r.task.due_at)}` : ''}</span>
              </div>
            )}
            <span className="muted" style={{ fontSize: 11.5 }}>{r.hk_updated_at ? fmtDateTime(r.hk_updated_at, locale) : ''}</span>
            <div className="row" style={{ gap: 6 }} onClick={(e) => e.stopPropagation()}>
              {can('housekeeping.dnd') && r.occupied && <button className="btn sm ghost" onClick={() => act(() => post(`/api/rooms/${r.id}/dnd`, { on: !r.dnd }))}>{r.dnd ? t('hkx.dndOff') : t('hk.dnd')}</button>}
              {can('housekeeping.update') && !r.out_of_service && (
                <select className="input" style={{ width: 'auto', padding: '4px 8px', fontSize: 12.5 }} aria-label={t('hkx.changeStatus')} value="" onChange={(e) => e.target.value && act(() => post(`/api/rooms/${r.id}/housekeeping`, { status: e.target.value }))}>
                  <option value="">{t('hkx.changeStatus')}…</option>
                  {HK_ORDER.filter((s) => s !== r.hk_status).map((s) => <option key={s} value={s}>{t(`hk.${s}` as Key)}</option>)}
                </select>
              )}
              {can('maintenance.manage') && (r.out_of_service
                ? <button className="btn sm" onClick={() => act(() => post(`/api/rooms/${r.id}/out-of-service`, { out_of_service: false }))}>{t('hk.backService')}</button>
                : !r.occupied && <button className="btn sm ghost danger" onClick={() => setOosRoom(r)}>{t('hk.setOos')}</button>)}
            </div>
          </div>
        ))}
      </div>
      {oosRoom && <ReasonModal title={`${t('hk.setOos')} — ${oosRoom.number}`} onClose={() => setOosRoom(null)} onSubmit={(reason) => { act(() => post(`/api/rooms/${oosRoom.id}/out-of-service`, { out_of_service: true, reason })); setOosRoom(null); }} />}
      <p className="muted" style={{ fontSize: 12.5 }}>{fmtDate(b.date, locale)} · {t('hkx.boardHint')}</p>
    </>
  );
}

// ===================================================== Tâches =====================================================
function Tasks({ openTask }: { openTask: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const manage = can('housekeeping.manage');
  const [f, setF] = useState({ date: todayLocal(), status: '', employee_id: '', mine: !manage && !can('housekeeping.inspect') });
  const [rows, setRows] = useState<any[] | null>(null);
  const [staff, setStaff] = useState<any[]>([]);
  const [creating, setCreating] = useState(false);
  const load = useCallback(() => {
    const qs = new URLSearchParams({ date: f.date });
    if (f.status) qs.set('status', f.status);
    if (f.employee_id) qs.set('employee_id', f.employee_id);
    if (f.mine) qs.set('mine', '1');
    get(`/api/housekeeping/tasks?${qs}`).then(setRows).catch(err(toast));
  }, [f]);
  useEffect(load, [load]);
  useLive(load, 20000);
  useEffect(() => { if (manage) get(`/api/housekeeping/staff?date=${f.date}`).then(setStaff).catch(() => {}); }, [f.date]);
  const act = async (fn: () => Promise<any>) => { try { await fn(); load(); } catch (e: any) { toast('error', e.message); } };
  return (
    <>
      <div className="row">
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('hkx.date')} value={f.date} onChange={(e) => e.target.value && setF({ ...f, date: e.target.value })} />
        <select className="input" style={{ width: 'auto' }} aria-label={t('hkx.status')} value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}>
          <option value="">{t('hkx.allStatus')}</option>{TASK_ST.map((s) => <option key={s} value={s}>{t(`hkx.s_${s}` as Key)}</option>)}
        </select>
        {manage && <select className="input" style={{ width: 'auto' }} aria-label={t('hkx.employee')} value={f.employee_id} onChange={(e) => setF({ ...f, employee_id: e.target.value })}>
          <option value="">{t('hkx.allStaff')}</option>{staff.filter((e) => e.active).map((e) => <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>)}
        </select>}
        {(manage || can('housekeeping.inspect')) && <label className="check" style={{ alignItems: 'center' }}><input type="checkbox" checked={f.mine} onChange={(e) => setF({ ...f, mine: e.target.checked })} />{t('hkx.mine')}</label>}
        <span style={{ flex: 1 }} />
        {manage && <button className="btn primary" onClick={() => setCreating(true)}><Icon name="plus" />{t('hkx.newTask')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('common.room')}</th><th>{t('hkx.task')}</th><th>{t('hkx.priority')}</th><th>{t('hkx.status')}</th><th>{t('hkx.assignee')}</th><th>{t('hkx.due')}</th><th>{t('hkx.times')}</th><th /></tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={8} className="muted">{f.mine ? t('hkx.noMine') : t('common.none')}</td></tr>}
            {(rows ?? []).map((x) => (
              <tr key={x.id}>
                <td><b>{x.room_number}</b> <span className="muted" style={{ fontSize: 12 }}>{x.room_type}</span>{x.dnd && <span className="pill" style={{ background: HK_COLORS.dnd, color: '#fff', marginInlineStart: 6 }}>{t('hk.dnd')}</span>}</td>
                <td>{t(`hkx.k_${x.kind}` as Key)}{x.refusal_count > 0 && <span className="pill prio-urgent" style={{ marginInlineStart: 6 }}>{t('hkx.refused')} ×{x.refusal_count}</span>}{x.comments > 0 && <span className="muted"> · 💬{x.comments}</span>}</td>
                <td>{manage && ['todo', 'in_progress'].includes(x.status)
                  ? <select className="input" style={{ width: 'auto', padding: '3px 6px' }} aria-label={t('hkx.priority')} value={x.priority} onChange={(e) => act(() => patch(`/api/housekeeping/tasks/${x.id}`, { priority: e.target.value }))}>{PRIOS.map((p) => <option key={p} value={p}>{t(`hkx.p_${p}` as Key)}</option>)}</select>
                  : <Prio p={x.priority} />}</td>
                <td>{t(`hkx.s_${x.status}` as Key)}</td>
                <td>{manage && ['todo', 'in_progress'].includes(x.status)
                  ? <select className="input" style={{ width: 'auto', padding: '3px 6px' }} aria-label={t('hkx.assignee')} value={x.assigned_to ?? ''} onChange={(e) => act(() => post(`/api/housekeeping/tasks/${x.id}/assign`, { employee_id: e.target.value ? Number(e.target.value) : null }))}>
                      <option value="">— {t('hkx.unassigned')} —</option>
                      {staff.filter((e) => e.active || e.id === x.assigned_to).map((e) => <option key={e.id} value={e.id}>{e.first_name} {e.last_name} ({e.rooms})</option>)}
                    </select>
                  : x.assignee ?? <span className="muted">{t('hkx.unassigned')}</span>}</td>
                <td className={x.late ? 'late' : ''}>{x.due_at ? hhmm(x.due_at) : '—'}{x.late ? ` · ${t('hkx.late')}` : ''}</td>
                <td className="muted" style={{ fontSize: 12.5 }}>{x.started_at ? `${hhmm(x.started_at)} → ${hhmm(x.completed_at) || '…'}` : ''}</td>
                <td className="pin-end"><div className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
                  {can('housekeeping.update') && x.status === 'todo' && x.kind !== 'inspection' && <button className="btn sm" onClick={() => act(() => post(`/api/housekeeping/tasks/${x.id}/start`))}>{t('hk.start')}</button>}
                  {can('housekeeping.update') && x.status === 'in_progress' && <button className="btn sm primary" onClick={() => act(() => post(`/api/housekeeping/tasks/${x.id}/finish`))}>{t('hk.done')}</button>}
                  <button className="btn sm ghost" onClick={() => openTask(x.id)}>{t('hkx.detail')}</button>
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {creating && <NewTaskModal staff={staff} onClose={() => setCreating(false)} onDone={() => { setCreating(false); load(); }} />}
    </>
  );
}

function NewTaskModal({ staff, onClose, onDone }: { staff: any[]; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [rooms, setRooms] = useState<any[]>([]);
  const [f, setF] = useState({ room_id: '', kind: 'deep_clean', priority: 'normal', due: '', employee_id: '', notes: '' });
  useEffect(() => { get('/api/rooms').then(setRooms).catch(() => {}); }, []);
  const save = async () => {
    try {
      await post('/api/housekeeping/tasks', { room_id: Number(f.room_id), kind: f.kind, priority: f.priority, due_at: f.due ? `${todayLocal()}T${f.due}:00` : null, employee_id: f.employee_id ? Number(f.employee_id) : null, notes: f.notes || null });
      toast('success', t('hkx.taskCreated'));
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={t('hkx.newTask')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.room_id} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('common.room')}><select className="input" value={f.room_id} onChange={(e) => setF({ ...f, room_id: e.target.value })}><option value="">—</option>{rooms.map((r) => <option key={r.id} value={r.id}>{r.number} · {r.type_name} · {t(`hk.${r.hk_status}` as Key)}</option>)}</select></Field>
        <Field label={t('hkx.task')}><select className="input" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}>{KINDS.map((k) => <option key={k} value={k}>{t(`hkx.k_${k}` as Key)}</option>)}</select></Field>
        <Field label={t('hkx.priority')}><select className="input" value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value })}>{PRIOS.map((p) => <option key={p} value={p}>{t(`hkx.p_${p}` as Key)}</option>)}</select></Field>
        <Field label={t('hkx.dueTime')}><input type="time" className="input" value={f.due} onChange={(e) => setF({ ...f, due: e.target.value })} /></Field>
        <Field label={t('hkx.assignee')}><select className="input" value={f.employee_id} onChange={(e) => setF({ ...f, employee_id: e.target.value })}><option value="">—</option>{staff.filter((e) => e.active).map((e) => <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>)}</select></Field>
      </div>
      <Field label={t('hkx.notes')}><textarea className="input" rows={2} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field>
    </Modal>
  );
}

function TaskDrawer({ id, onClose }: { id: number; onClose: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [x, setX] = useState<any>(null);
  const [c, setC] = useState({ kind: 'comment', text: '', priority: 'normal' });
  const [mb, setMb] = useState<any[] | null>(null);
  const [qty, setQty] = useState<Record<number, number>>({});
  const [cancel, setCancel] = useState(false);
  const load = useCallback(() => { get(`/api/housekeeping/tasks/${id}`).then(setX).catch(err(toast)); }, [id]);
  useEffect(load, [load]);
  const act = async (fn: () => Promise<any>, ok?: string) => { try { await fn(); if (ok) toast('success', ok); load(); } catch (e: any) { toast('error', e.message); } };
  if (!x) return null;
  const open = ['todo', 'in_progress'].includes(x.status);
  return (
    <Modal size="lg" title={`${t('common.room')} ${x.room_number} — ${t(`hkx.k_${x.kind}` as Key)}`} onClose={onClose}
      footer={<>
        {can('housekeeping.manage') && ['todo', 'in_progress', 'to_inspect'].includes(x.status) && <button className="btn ghost danger" onClick={() => setCancel(true)}>{t('hkx.cancelTask')}</button>}
        <span style={{ flex: 1 }} />
        {can('housekeeping.update') && x.status === 'todo' && x.kind !== 'inspection' && <button className="btn" onClick={() => act(() => post(`/api/housekeeping/tasks/${id}/start`))}>{t('hk.start')}</button>}
        {can('housekeeping.update') && x.status === 'in_progress' && <button className="btn primary" onClick={() => act(() => post(`/api/housekeeping/tasks/${id}/finish`), t('hkx.finished'))}>{t('hk.done')}</button>}
      </>}>
      <div className="kv">
        <div><span>{t('hkx.status')}</span><b>{t(`hkx.s_${x.status}` as Key)}</b></div>
        <div><span>{t('hkx.roomStatus')}</span><b><HkBadge st={x.hk_status} /></b></div>
        <div><span>{t('hkx.priority')}</span><b><Prio p={x.priority} /></b></div>
        <div><span>{t('hkx.assignee')}</span><b>{x.assignee ?? '—'}</b></div>
        <div><span>{t('hkx.due')}</span><b>{x.due_at ? fmtDateTime(x.due_at, locale) : '—'}</b></div>
        <div><span>{t('hkx.times')}</span><b>{x.started_at ? `${hhmm(x.started_at)} → ${hhmm(x.completed_at) || '…'}` : '—'}</b></div>
        {x.inspected_at && <div><span>{t('hkx.inspectedAt')}</span><b>{fmtDateTime(x.inspected_at, locale)}</b></div>}
        {x.cancel_reason && <div><span>{t('hkx.cancelReason')}</span><b>{x.cancel_reason}</b></div>}
      </div>
      {x.notes && <p style={{ margin: 0 }}>📝 {x.notes}</p>}
      {x.inspections.length > 0 && (
        <div className="section"><h3>{t('hkx.inspections')}</h3>
          {x.inspections.map((i: any) => (
            <div key={i.id} style={{ fontSize: 13 }}>
              <b style={{ color: i.result === 'passed' ? '#15803D' : 'var(--danger)' }}>{i.result === 'passed' ? t('hkx.passed') : t('hkx.failed')} · {i.score} %</b> — {i.inspector}, {fmtDateTime(i.created_at, locale)}
              {i.items.filter((it: any) => !it.ok).length > 0 && <div className="muted">✗ {i.items.filter((it: any) => !it.ok).map((it: any) => it.label).join(' · ')}</div>}
              {i.remarks && <div>« {i.remarks} »</div>}
              {i.photos && <div className="photo-strip">{i.photos.map((p: number) => <a key={p} href={`/api/photos/${p}`} target="_blank" rel="noreferrer"><img src={`/api/photos/${p}`} alt="" style={{ height: 60, borderRadius: 8 }} /></a>)}</div>}
            </div>
          ))}
        </div>
      )}
      <div className="section"><h3>{t('hkx.comments')}</h3>
        {x.comments.map((m: any) => (
          <div key={m.id} style={{ fontSize: 13 }}>
            <span className="pill" style={m.kind === 'issue' ? { background: '#FEE2E2', color: '#991B1B' } : m.kind === 'minibar' ? { background: '#FEF3C7', color: '#92400E' } : {}}>{t(`hkx.c_${m.kind}` as Key)}</span> {m.text}
            <span className="muted"> — {m.author}, {fmtDateTime(m.created_at, locale)}{m.ticket_id ? ` · ${t('hkx.ticket')} #${m.ticket_id}` : ''}</span>
          </div>
        ))}
        {can('housekeeping.update') && x.status !== 'cancelled' && (
          <div className="row" style={{ alignItems: 'flex-end' }}>
            <div className="seg">{['comment', 'issue'].map((k) => <button key={k} className={c.kind === k ? 'on' : ''} onClick={() => setC({ ...c, kind: k })}>{t(`hkx.c_${k}` as Key)}</button>)}</div>
            {c.kind === 'issue' && <select className="input" style={{ width: 'auto' }} aria-label={t('hkx.priority')} value={c.priority} onChange={(e) => setC({ ...c, priority: e.target.value })}>{PRIOS.map((p) => <option key={p} value={p}>{t(`hkx.p_${p}` as Key)}</option>)}</select>}
            <input className="input" style={{ flex: 1, minWidth: 200 }} aria-label={t('hkx.comments')} placeholder={c.kind === 'issue' ? t('hkx.issuePh') : t('hkx.commentPh')} value={c.text} onChange={(e) => setC({ ...c, text: e.target.value })} />
            <button className="btn" disabled={c.text.trim().length < 2} onClick={() => act(() => post(`/api/housekeeping/tasks/${id}/comments`, c).then(() => setC({ ...c, text: '' })), c.kind === 'issue' ? t('hkx.issueSent') : undefined)}>{t('common.save')}</button>
          </div>
        )}
      </div>
      {can('housekeeping.minibar') && open && (
        <div className="section"><h3>{t('hkx.minibar')}</h3>
          {!mb ? <button className="btn sm" onClick={() => get('/api/housekeeping/minibar-items').then(setMb).catch(err(toast))}>{t('hkx.minibarOpen')}</button> : (
            <>
              <div className="form-grid">{mb.map((s) => (
                <Field key={s.id} label={`${s.name} · ${money(Number(s.price), locale)}`}><input type="number" min={0} max={50} className="input" value={qty[s.id] ?? 0} onChange={(e) => setQty({ ...qty, [s.id]: Math.max(0, Number(e.target.value)) })} /></Field>
              ))}</div>
              <button className="btn primary" disabled={!Object.values(qty).some((v) => v > 0)} onClick={() => act(() => post(`/api/housekeeping/tasks/${id}/minibar`, { lines: Object.entries(qty).filter(([, v]) => v > 0).map(([k, v]) => ({ service_id: Number(k), quantity: v })) }).then(() => setQty({})), t('hkx.minibarDone'))}>{t('hkx.minibarPost')}</button>
            </>
          )}
        </div>
      )}
      {x.history.length > 0 && (
        <details><summary className="muted" style={{ cursor: 'pointer' }}>{t('hkx.history')} ({x.history.length})</summary>
          {x.history.map((h: any, i: number) => <div key={i} className="muted" style={{ fontSize: 12.5 }}>{fmtDateTime(h.created_at, locale)} · {h.user_name} · {h.action}</div>)}
        </details>
      )}
      {cancel && <ReasonModal title={t('hkx.cancelTask')} onClose={() => setCancel(false)} onSubmit={(reason) => { setCancel(false); act(() => post(`/api/housekeeping/tasks/${id}/cancel`, { reason })); }} />}
    </Modal>
  );
}

// ===================================================== Personnel =====================================================
function Staff() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const manage = can('housekeeping.manage');
  const [date, setDate] = useState(todayLocal());
  const [rows, setRows] = useState<any[] | null>(null);
  const [edit, setEdit] = useState<Record<number, any>>({});
  const [adding, setAdding] = useState(false);
  const [tasks, setTasks] = useState<any[]>([]);
  const load = useCallback(() => {
    get(`/api/housekeeping/staff?date=${date}`).then(setRows).catch(err(toast));
    if (manage) get(`/api/housekeeping/tasks?date=${date}`).then(setTasks).catch(() => {});
  }, [date]);
  useEffect(load, [load]);
  useLive(load, 30000);
  const act = async (fn: () => Promise<any>, ok?: string) => { try { await fn(); if (ok) toast('success', ok); load(); } catch (e: any) { toast('error', e.message); } };
  const shift = (e: any) => edit[e.id] ?? { start_time: (e.start_time ?? '08:00').slice(0, 5), end_time: (e.end_time ?? '16:00').slice(0, 5), zone: e.zone ?? '' };
  const unassigned = tasks.filter((x) => !x.assigned_to && ['todo', 'in_progress'].includes(x.status));
  return (
    <>
      <div className="row">
        <input type="date" className="input" style={{ width: 160 }} aria-label="Date" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} />
        <span className="muted">{fmtDate(date, locale)}</span>
        <span style={{ flex: 1 }} />
        {manage && unassigned.length > 0 && <span className="pill prio-high">{unassigned.length} {t('hkx.unassigned')}</span>}
        {manage && <button className="btn" onClick={() => act(() => post('/api/housekeeping/auto-assign', { date }), t('hkx.assignDone'))}><Icon name="users" />{t('hkx.autoAssign')}</button>}
        {manage && <button className="btn primary" onClick={() => setAdding(true)}><Icon name="plus" />{t('hkx.addStaff')}</button>}
      </div>
      {rows && !rows.length && <div className="card muted">{t('hkx.noStaff')}</div>}
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 12 }}>
        {(rows ?? []).map((e) => {
          const s = shift(e);
          return (
            <div key={e.id} className="card staff-card" style={{ opacity: e.active ? 1 : 0.55 }}>
              <div className="row between">
                <div><b>{e.first_name} {e.last_name}</b><div className="muted" style={{ fontSize: 12 }}>{e.position}{e.username ? ` · @${e.username}` : ''}</div></div>
                <span className="pill" style={e.shift_id ? { background: '#DCFCE7', color: '#166534' } : {}}>{e.shift_id ? (e.ended_at ? t('hkx.shiftEnded') : e.started_at ? t('hkx.onDuty') : t('hkx.planned')) : t('hkx.off')}</span>
              </div>
              <div className="row between" style={{ fontSize: 13 }}>
                <span>{t('hkx.rooms')} <b>{e.rooms}</b> / {e.max_rooms} · {e.planned_minutes} min</span><span><b>{e.progress} %</b></span>
              </div>
              <Meter v={e.progress} />
              <div className="row" style={{ gap: 4 }}>{e.tasks.map((x: any) => <span key={x.id} className="pill" title={t(`hkx.k_${x.kind}` as Key)} style={{ background: ['done', 'validated'].includes(x.status) ? '#DCFCE7' : x.status === 'to_inspect' ? '#EDE9FE' : x.status === 'in_progress' ? '#FEF3C7' : 'var(--surface2)' }}>{x.room}</span>)}</div>
              <div className="muted" style={{ fontSize: 12.5 }}>
                {t('hkx.real')} : {e.started_at ? hhmm(e.started_at) : '—'} → {e.ended_at ? hhmm(e.ended_at) : '—'}{e.first_start ? ` · ${t('hkx.firstRoom')} ${hhmm(e.first_start)}` : ''}{e.last_end ? ` · ${t('hkx.lastRoom')} ${hhmm(e.last_end)}` : ''}
              </div>
              {manage && e.active && (
                <div className="row" style={{ gap: 6 }}>
                  <input type="time" className="input" style={{ width: 132 }} aria-label={t('hkx.start')} value={s.start_time} onChange={(ev) => setEdit({ ...edit, [e.id]: { ...s, start_time: ev.target.value } })} />
                  <input type="time" className="input" style={{ width: 132 }} aria-label={t('hkx.end')} value={s.end_time} onChange={(ev) => setEdit({ ...edit, [e.id]: { ...s, end_time: ev.target.value } })} />
                  <input className="input" style={{ width: 110 }} placeholder={t('hkx.zone')} aria-label={t('hkx.zone')} value={s.zone} onChange={(ev) => setEdit({ ...edit, [e.id]: { ...s, zone: ev.target.value } })} />
                  <button className="btn sm primary" onClick={() => act(() => api('PUT', '/api/housekeeping/shifts', { employee_id: e.id, work_date: date, ...s, zone: s.zone || null }), t('hkx.shiftSaved'))}>{e.shift_id ? t('common.save') : t('hkx.plan')}</button>
                  {e.shift_id && !e.started_at && <button className="btn sm ghost" onClick={() => act(() => api('PUT', '/api/housekeeping/shifts', { employee_id: e.id, work_date: date, off: true }))}>{t('hkx.setOff')}</button>}
                </div>
              )}
              <div className="row" style={{ gap: 6 }}>
                {date === todayLocal() && e.active && can('housekeeping.update') && !e.started_at && <button className="btn sm" onClick={() => act(() => post('/api/housekeeping/shifts/clock', { employee_id: e.id, action: 'in' }))}>{t('hkx.clockIn')}</button>}
                {date === todayLocal() && e.started_at && !e.ended_at && can('housekeeping.update') && <button className="btn sm" onClick={() => act(() => post('/api/housekeeping/shifts/clock', { employee_id: e.id, action: 'out' }))}>{t('hkx.clockOut')}</button>}
                {manage && <button className="btn sm ghost" onClick={() => act(() => patch(`/api/housekeeping/staff/${e.id}`, { active: !e.active }))}>{e.active ? t('hkx.deactivate') : t('hkx.reactivate')}</button>}
              </div>
            </div>
          );
        })}
      </div>
      {adding && <StaffModal onClose={() => setAdding(false)} onDone={() => { setAdding(false); load(); }} />}
    </>
  );
}

function StaffModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [f, setF] = useState({ first_name: '', last_name: '', position: 'Femme de chambre', phone: '', max_rooms: 14, access: false, username: '', password: '', role: 'housekeeping' });
  const save = async () => {
    try {
      await post('/api/housekeeping/staff', { first_name: f.first_name, last_name: f.last_name, position: f.position, phone: f.phone || null, max_rooms: f.max_rooms, access: f.access ? { username: f.username, password: f.password, role: f.role } : null });
      toast('success', t('hkx.staffAdded'));
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={t('hkx.addStaff')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.first_name || !f.last_name} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('hkx.lastName')}><input className="input" value={f.last_name} onChange={(e) => setF({ ...f, last_name: e.target.value })} /></Field>
        <Field label={t('hkx.firstName')}><input className="input" value={f.first_name} onChange={(e) => setF({ ...f, first_name: e.target.value })} /></Field>
        <Field label={t('hkx.position')}><input className="input" value={f.position} onChange={(e) => setF({ ...f, position: e.target.value })} /></Field>
        <Field label={t('hkx.phone')}><input className="input" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
        <Field label={t('hkx.maxRooms')}><input type="number" min={1} max={40} className="input" value={f.max_rooms} onChange={(e) => setF({ ...f, max_rooms: Number(e.target.value) })} /></Field>
      </div>
      {can('users.manage') && <label className="check"><input type="checkbox" checked={f.access} onChange={(e) => setF({ ...f, access: e.target.checked })} />{t('hkx.giveAccess')}</label>}
      {f.access && (
        <div className="form-grid">
          <Field label={t('login.username')}><input className="input" value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} /></Field>
          <Field label={t('hkx.tmpPassword')}><input className="input" type="text" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></Field>
          <Field label={t('hkx.role')}><select className="input" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}><option value="housekeeping">{t('hkx.r_housekeeping')}</option><option value="hk_supervisor">{t('hkx.r_hk_supervisor')}</option></select></Field>
        </div>
      )}
    </Modal>
  );
}

// ===================================================== Inspection =====================================================
function Inspection() {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [b, setB] = useState<any>(null);
  const [hist, setHist] = useState<any[]>([]);
  const [room, setRoom] = useState<any>(null);
  const load = useCallback(() => {
    get('/api/housekeeping/board').then(setB).catch(err(toast));
    get('/api/housekeeping/inspections').then(setHist).catch(() => {});
  }, []);
  useEffect(load, [load]);
  useLive(load, 20000);
  if (!b) return <span>{t('common.loading')}</span>;
  const queue = b.rooms.filter((r: any) => r.hk_status === 'to_inspect' || (r.hk_status === 'clean' && !r.occupied));
  queue.sort((a: any, c: any) => Number(!!c.arrival) - Number(!!a.arrival) || Number(c.hk_status === 'to_inspect') - Number(a.hk_status === 'to_inspect'));
  return (
    <>
      <h3 style={{ margin: 0 }}>{t('hkx.toInspect')} ({queue.length})</h3>
      {!queue.length && <div className="card muted">{t('hkx.nothingToInspect')}</div>}
      <div className="hk-grid">
        {queue.map((r: any) => (
          <button key={r.id} className="hk-card clickable" style={{ textAlign: 'start', font: 'inherit', color: 'inherit' }} onClick={() => setRoom(r)}>
            <div className="top" style={{ borderColor: HK_COLORS[r.hk_status] }} />
            <div className="row between"><b style={{ fontSize: 20 }}>{r.number}</b><HkBadge st={r.hk_status} /></div>
            <span className="muted" style={{ fontSize: 12.5 }}>{r.type_name}{r.task?.assignee ? ` · ${r.task.assignee}` : ''}</span>
            {r.arrival && <span className="pill" style={{ background: '#F59E0B', color: '#3B1D02', alignSelf: 'flex-start' }}>{t('hk.arrivalToday')} · {r.arrival.guest}</span>}
            <span className="btn sm primary" style={{ alignSelf: 'flex-start' }}>{t('hk.inspect')}</span>
          </button>
        ))}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('hkx.todayInspections')}</h3>
        <table className="table">
          <thead><tr><th>{t('hkx.time')}</th><th>{t('common.room')}</th><th>{t('hkx.result')}</th><th className="num">Score</th><th>{t('hkx.inspector')}</th><th>{t('hkx.cleanedBy')}</th><th>{t('hkx.remarks')}</th></tr></thead>
          <tbody>
            {!hist.length && <tr><td colSpan={7} className="muted">{t('common.none')}</td></tr>}
            {hist.map((i) => (
              <tr key={i.id}><td>{fmtDateTime(i.created_at, locale)}</td><td><b>{i.room}</b></td>
                <td><span className="pill" style={i.result === 'passed' ? { background: '#DCFCE7', color: '#166534' } : { background: '#FEE2E2', color: '#991B1B' }}>{i.result === 'passed' ? t('hkx.passed') : t('hkx.failed')}</span></td>
                <td className="num">{i.score} %</td><td>{i.inspector}</td><td>{i.cleaner ?? '—'}</td><td className="wrap">{i.remarks ?? ''}{i.photos ? ` 📷${i.photos.length}` : ''}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
      {room && <InspectModal room={room} onClose={() => setRoom(null)} onDone={() => { setRoom(null); load(); }} />}
    </>
  );
}

function InspectModal({ room, onClose, onDone }: { room: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [items, setItems] = useState<any[] | null>(null);
  const [ok, setOk] = useState<Record<number, boolean | undefined>>({});
  const [remarks, setRemarks] = useState('');
  const [ticket, setTicket] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState(false);
  const [min, setMin] = useState(80);
  useEffect(() => {
    get('/api/housekeeping/checklist').then((l) => { setItems(l); setOk(Object.fromEntries(l.map((i: any) => [i.id, true]))); }).catch(err(toast));
    get('/api/housekeeping/settings').then((s) => setMin(s.min_score)).catch(() => {});
  }, []);
  const groups = useMemo(() => { const g: Record<string, any[]> = {}; (items ?? []).forEach((i) => (g[i.category] ||= []).push(i)); return g; }, [items]);
  if (!items) return null;
  const answered = items.every((i) => ok[i.id] !== undefined);
  const score = items.length ? Math.round((items.filter((i) => ok[i.id]).length * 100) / items.length) : 100;
  const critKo = items.filter((i) => i.critical && ok[i.id] === false);
  const canPass = answered && !critKo.length && score >= min;
  const submit = async (decision: 'pass' | 'fail') => {
    try {
      setBusy(true);
      const ins = await post('/api/housekeeping/inspections', { room_id: room.id, decision, remarks: remarks || null, create_ticket: ticket, items: items.map((i) => ({ item_id: i.id, ok: !!ok[i.id] })) });
      for (const f of files) await upload('/api/photos', f, { owner_type: 'inspection', owner_id: String(ins.id) });
      toast('success', decision === 'pass' ? t('hkx.passedMsg') : t('hkx.failedMsg'));
      onDone();
    } catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  return (
    <Modal size="lg" title={`${t('hk.inspect')} — ${t('common.room')} ${room.number}`} onClose={onClose}
      footer={<>
        <span className="muted">Score <b style={{ color: score >= min ? '#15803D' : 'var(--danger)' }}>{score} %</b> (min {min} %)</span>
        <span style={{ flex: 1 }} />
        <button className="btn danger" disabled={busy || !answered} onClick={() => submit('fail')}>{t('hkx.refuse')}</button>
        <button className="btn primary" disabled={busy || !canPass} onClick={() => submit('pass')}>{t('hkx.validate')}</button>
      </>}>
      {Object.entries(groups).map(([cat, list]) => (
        <div key={cat} className="section"><h3>{cat}</h3>
          {list.map((i) => (
            <div key={i.id} className={`ck ${ok[i.id] === false ? 'ko' : ''}`}>
              <span>{i.label}{i.critical && <b style={{ color: 'var(--danger)' }}> *</b>}</span>
              <div className="seg" role="group" aria-label={i.label}>
                <button className={ok[i.id] === true ? 'on' : ''} onClick={() => setOk({ ...ok, [i.id]: true })}>✓ {t('hkx.ok')}</button>
                <button className={ok[i.id] === false ? 'on' : ''} onClick={() => setOk({ ...ok, [i.id]: false })}>✗ {t('hkx.ko')}</button>
              </div>
            </div>
          ))}
        </div>
      ))}
      {critKo.length > 0 && <div className="alert">{t('hkx.criticalKo')} : {critKo.map((i) => i.label).join(', ')}</div>}
      <Field label={t('hkx.remarks')}><textarea className="input" rows={2} value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder={t('hkx.remarksPh')} /></Field>
      <label className="check"><input type="checkbox" checked={ticket} onChange={(e) => setTicket(e.target.checked)} />{t('hkx.createTicket')}</label>
      <Field label={`${t('hkx.photos')} (${files.length})`}><input type="file" accept="image/jpeg,image/png,image/webp" multiple capture="environment" className="input" onChange={(e) => setFiles(Array.from(e.target.files ?? []).slice(0, 6))} /></Field>
      <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>* {t('hkx.criticalHint')}</p>
    </Modal>
  );
}

// ===================================================== Linge =====================================================
function Linen() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const m = can('linen.manage');
  const [items, setItems] = useState<any[] | null>(null);
  const [batches, setBatches] = useState<any[]>([]);
  const [moves, setMoves] = useState<any[]>([]);
  const [move, setMove] = useState<any>(null);
  const [send, setSend] = useState(false);
  const [ret, setRet] = useState<number | null>(null);
  const [newItem, setNewItem] = useState(false);
  const load = useCallback(() => {
    get('/api/linen').then(setItems).catch(err(toast));
    get('/api/linen/batches').then(setBatches).catch(() => {});
    get('/api/linen/movements').then(setMoves).catch(() => {});
  }, []);
  useEffect(load, [load]);
  useLive(load);
  if (!items) return <span>{t('common.loading')}</span>;
  const tot = (k: string) => items.filter((i) => i.active).reduce((a, i) => a + i[k], 0);
  return (
    <>
      <div className="grid kpis">
        {[['hkx.lClean', 'qty_clean'], ['hkx.lInUse', 'qty_in_use'], ['hkx.lDirty', 'qty_dirty'], ['hkx.lLaundry', 'qty_laundry']].map(([l, k]) => <div key={k} className="card kpi"><span className="label">{t(l as Key)}</span><span className="value">{tot(k)}</span></div>)}
        <div className="card kpi"><span className="label">{t('hkx.belowPar')}</span><span className="value" style={{ color: items.some((i) => i.below_par && i.active) ? 'var(--danger)' : undefined }}>{items.filter((i) => i.below_par && i.active).length}</span></div>
      </div>
      <div className="row">
        <span style={{ flex: 1 }} />
        {m && <button className="btn" onClick={() => setNewItem(true)}><Icon name="plus" />{t('hkx.newItem')}</button>}
        {m && <button className="btn primary" disabled={!tot('qty_dirty')} onClick={() => setSend(true)}>{t('hkx.sendLaundry')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('hkx.item')}</th><th className="num">{t('hkx.lClean')}</th><th className="num">{t('hkx.lInUse')}</th><th className="num">{t('hkx.lDirty')}</th><th className="num">{t('hkx.lLaundry')}</th><th className="num">{t('hkx.par')}</th><th className="num">Total</th><th /></tr></thead>
          <tbody>
            {items.map((i) => (
              <tr key={i.id} style={{ opacity: i.active ? 1 : 0.5 }}>
                <td><b>{i.name}</b> <span className="muted" style={{ fontSize: 12 }}>{i.code}</span></td>
                <td className="num" style={i.below_par ? { color: 'var(--danger)', fontWeight: 700 } : {}}>{i.qty_clean}</td>
                <td className="num">{i.qty_in_use}</td><td className="num">{i.qty_dirty}</td><td className="num">{i.qty_laundry}</td><td className="num muted">{i.par_level}</td>
                <td className="num">{i.qty_clean + i.qty_in_use + i.qty_dirty + i.qty_laundry}</td>
                <td className="pin-end">{m && <button className="btn sm" onClick={() => setMove(i)}>{t('hkx.movement')}</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('hkx.batches')}</h3>
        <table className="table">
          <thead><tr><th>Réf.</th><th>{t('hkx.provider')}</th><th>{t('hkx.sentAt')}</th><th className="num">{t('hkx.sent')}</th><th className="num">{t('hkx.returned')}</th><th>{t('hkx.status')}</th><th className="num">{t('hkx.cost')}</th><th /></tr></thead>
          <tbody>
            {!batches.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
            {batches.map((b) => (
              <tr key={b.id}><td><b>{b.ref}</b></td><td>{b.provider ?? '—'}</td><td>{fmtDateTime(b.sent_at, locale)}</td><td className="num">{b.sent}</td><td className="num">{b.returned}</td>
                <td>{t(`hkx.b_${b.status}` as Key)}</td><td className="num">{b.cost ? money(Number(b.cost), locale) : '—'}</td>
                <td className="pin-end">{m && b.status !== 'returned' && <button className="btn sm primary" onClick={() => setRet(b.id)}>{t('hkx.receive')}</button>}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
      <details className="card"><summary style={{ cursor: 'pointer', fontWeight: 600 }}>{t('hkx.moveHistory')} ({moves.length})</summary>
        <table className="table">
          <thead><tr><th>{t('hkx.time')}</th><th>{t('hkx.item')}</th><th>{t('hkx.movement')}</th><th className="num">Qté</th><th>{t('common.room')}</th><th>{t('hkx.reason')}</th><th>{t('hkx.user')}</th></tr></thead>
          <tbody>{moves.map((x) => <tr key={x.id}><td>{fmtDateTime(x.created_at, locale)}</td><td>{x.item}</td><td>{t(`hkx.m_${x.kind}` as Key)}{x.batch ? ` · ${x.batch}` : ''}</td><td className="num">{x.quantity}</td><td>{x.room ?? ''}</td><td className="wrap">{x.reason ?? ''}</td><td>{x.user_name}</td></tr>)}</tbody>
        </table>
      </details>
      {move && <MoveModal item={move} onClose={() => setMove(null)} onDone={() => { setMove(null); load(); }} />}
      {send && <SendModal items={items.filter((i) => i.qty_dirty > 0)} onClose={() => setSend(false)} onDone={() => { setSend(false); load(); }} />}
      {ret && <ReturnModal id={ret} onClose={() => setRet(null)} onDone={() => { setRet(null); load(); }} />}
      {newItem && <ItemModal onClose={() => setNewItem(false)} onDone={() => { setNewItem(false); load(); }} />}
    </>
  );
}

function MoveModal({ item, onClose, onDone }: { item: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [rooms, setRooms] = useState<any[]>([]);
  const [f, setF] = useState({ kind: 'issue', quantity: 1, room_id: '', reason: '', from: 'dirty' });
  useEffect(() => { get('/api/rooms').then(setRooms).catch(() => {}); }, []);
  const save = async () => {
    try {
      await post('/api/linen/movements', { item_id: item.id, kind: f.kind, quantity: f.quantity, room_id: f.room_id ? Number(f.room_id) : null, reason: f.reason || null, from: ['discard', 'adjust'].includes(f.kind) ? f.from : undefined });
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={`${t('hkx.movement')} — ${item.name}`} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.quantity} onClick={save}>{t('common.save')}</button></>}>
      <p className="muted" style={{ margin: 0 }}>{t('hkx.lClean')} {item.qty_clean} · {t('hkx.lInUse')} {item.qty_in_use} · {t('hkx.lDirty')} {item.qty_dirty} · {t('hkx.lLaundry')} {item.qty_laundry}</p>
      <div className="form-grid">
        <Field label={t('hkx.movement')}><select className="input" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}>{['purchase', 'issue', 'collect', 'discard', 'adjust'].map((k) => <option key={k} value={k}>{t(`hkx.m_${k}` as Key)}</option>)}</select></Field>
        <Field label={f.kind === 'adjust' ? t('hkx.qtyAdjust') : t('hkx.qty')}><input type="number" className="input" min={f.kind === 'adjust' ? -9999 : 1} value={f.quantity} onChange={(e) => setF({ ...f, quantity: Math.trunc(Number(e.target.value)) })} /></Field>
        {['discard', 'adjust'].includes(f.kind) && <Field label={t('hkx.stockOf')}><select className="input" value={f.from} onChange={(e) => setF({ ...f, from: e.target.value })}>{['clean', 'in_use', 'dirty', 'laundry'].map((k) => <option key={k} value={k}>{t(`hkx.l_${k}` as Key)}</option>)}</select></Field>}
        {['issue', 'collect'].includes(f.kind) && <Field label={`${t('common.room')} (${t('hkx.optional')})`}><select className="input" value={f.room_id} onChange={(e) => setF({ ...f, room_id: e.target.value })}><option value="">—</option>{rooms.map((r) => <option key={r.id} value={r.id}>{r.number}</option>)}</select></Field>}
      </div>
      <Field label={`${t('hkx.reason')}${['discard', 'adjust'].includes(f.kind) ? ' *' : ''}`}><input className="input" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} /></Field>
    </Modal>
  );
}

function SendModal({ items, onClose, onDone }: { items: any[]; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('ln'));
  const [provider, setProvider] = useState('');
  const [q, setQ] = useState<Record<number, number>>(Object.fromEntries(items.map((i) => [i.id, i.qty_dirty])));
  const save = async () => {
    try {
      const b = await postOnce('/api/linen/batches', { provider: provider || null, lines: Object.entries(q).filter(([, v]) => v > 0).map(([k, v]) => ({ item_id: Number(k), quantity: v })) }, key);
      toast('success', `${t('hkx.batchSent')} ${b.ref}`);
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={t('hkx.sendLaundry')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!Object.values(q).some((v) => v > 0)} onClick={save}>{t('hkx.send')}</button></>}>
      <Field label={t('hkx.provider')}><input className="input" value={provider} onChange={(e) => setProvider(e.target.value)} placeholder={t('hkx.providerPh')} /></Field>
      <div className="form-grid">{items.map((i) => <Field key={i.id} label={`${i.name} (${t('hkx.lDirty')} ${i.qty_dirty})`}><input type="number" className="input" min={0} max={i.qty_dirty} value={q[i.id]} onChange={(e) => setQ({ ...q, [i.id]: Math.max(0, Math.min(i.qty_dirty, Math.trunc(Number(e.target.value)))) })} /></Field>)}</div>
    </Modal>
  );
}

function ReturnModal({ id, onClose, onDone }: { id: number; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [b, setB] = useState<any>(null);
  const [q, setQ] = useState<Record<number, number>>({});
  const [close, setClose] = useState(false);
  const [cost, setCost] = useState('');
  const [method, setMethod] = useState('transfer');
  useEffect(() => { get(`/api/linen/batches/${id}`).then((x) => { setB(x); setQ(Object.fromEntries(x.lines.map((l: any) => [l.item_id, l.pending]))); }).catch(err(toast)); }, [id]);
  if (!b) return null;
  const missing = b.lines.reduce((a: number, l: any) => a + l.pending - (q[l.item_id] ?? 0), 0);
  const save = async () => {
    try {
      await post(`/api/linen/batches/${id}/return`, { lines: Object.entries(q).map(([k, v]) => ({ item_id: Number(k), quantity: v })), close, cost: cost ? Number(cost.replace(',', '.')) : null, method });
      toast('success', t('hkx.received'));
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={`${t('hkx.receive')} — ${b.ref}`} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" onClick={save}>{t('common.save')}</button></>}>
      <table className="table">
        <thead><tr><th>{t('hkx.item')}</th><th className="num">{t('hkx.sent')}</th><th className="num">{t('hkx.returned')}</th><th className="num">{t('hkx.backNow')}</th></tr></thead>
        <tbody>{b.lines.map((l: any) => <tr key={l.item_id}><td>{l.name}</td><td className="num">{l.sent}</td><td className="num">{l.returned}</td>
          <td className="num"><input type="number" className="input" style={{ width: 90 }} min={0} max={l.pending} aria-label={l.name} value={q[l.item_id] ?? 0} onChange={(e) => setQ({ ...q, [l.item_id]: Math.max(0, Math.min(l.pending, Math.trunc(Number(e.target.value)))) })} /></td></tr>)}</tbody>
      </table>
      {missing > 0 && <label className="check"><input type="checkbox" checked={close} onChange={(e) => setClose(e.target.checked)} />{t('hkx.closeMissing').replace('{n}', String(missing))}</label>}
      <div className="form-grid">
        <Field label={`${t('hkx.cost')} (${t('hkx.optional')})`}><input className="input" inputMode="decimal" value={cost} onChange={(e) => setCost(e.target.value)} /></Field>
        {cost && <Field label={t('hkx.payMethod')}><select className="input" value={method} onChange={(e) => setMethod(e.target.value)}>{['transfer', 'cash', 'cheque', 'card'].map((k) => <option key={k} value={k}>{t(`pm.${k}` as Key)}</option>)}</select></Field>}
      </div>
      {cost && <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>{t('hkx.costHint')}</p>}
    </Modal>
  );
}

function ItemModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [f, setF] = useState({ code: '', name: '', category: 'bed', par_level: 0, unit_cost: 0 });
  const save = async () => { try { await post('/api/linen', f); onDone(); } catch (e: any) { toast('error', e.message); } };
  return (
    <Modal title={t('hkx.newItem')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.code || f.name.length < 2} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label="Code"><input className="input" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} /></Field>
        <Field label={t('hkx.item')}><input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label={t('hkx.category')}><select className="input" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{['bed', 'bath', 'table', 'other'].map((k) => <option key={k} value={k}>{t(`hkx.lc_${k}` as Key)}</option>)}</select></Field>
        <Field label={t('hkx.par')}><input type="number" min={0} className="input" value={f.par_level} onChange={(e) => setF({ ...f, par_level: Number(e.target.value) })} /></Field>
      </div>
    </Modal>
  );
}

// ===================================================== Objets trouvés =====================================================
const LF_CATS = ['clothing', 'electronics', 'documents', 'jewelry', 'money', 'keys', 'bag', 'other'];
function Lost() {
  const { t, locale } = useI18n();
  const { can, me } = useAuth();
  const toast = useToast();
  const [f, setF] = useState({ status: '', search: '' });
  const [rows, setRows] = useState<any[] | null>(null);
  const [adding, setAdding] = useState(false);
  const [st, setSt] = useState<{ item: any; status: string } | null>(null);
  const load = useCallback(() => {
    const qs = new URLSearchParams({ search: f.search });
    if (f.status) qs.set('status', f.status);
    get(`/api/lost-found?${qs}`).then(setRows).catch(err(toast));
  }, [f]);
  useEffect(() => { const h = setTimeout(load, 200); return () => clearTimeout(h); }, [load]);
  useLive(load);
  const next: Record<string, string[]> = { pending: ['stored', 'returned', 'archived'], stored: ['returned', 'archived'], returned: [], archived: [] };
  return (
    <>
      <div className="row">
        <button className={`chip ${!f.status ? 'on' : ''}`} onClick={() => setF({ ...f, status: '' })}>{t('common.all')}</button>
        {['pending', 'stored', 'returned', 'archived'].map((s) => <button key={s} className={`chip ${f.status === s ? 'on' : ''}`} onClick={() => setF({ ...f, status: f.status === s ? '' : s })}>{t(`hkx.lf_${s}` as Key)}</button>)}
        <input className="input" style={{ width: 220 }} placeholder={t('common.search')} aria-label={t('common.search')} value={f.search} onChange={(e) => setF({ ...f, search: e.target.value })} />
        <span style={{ flex: 1 }} />
        {can('lostfound.record') && <button className="btn primary" onClick={() => setAdding(true)}><Icon name="plus" />{t('hkx.declare')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>Réf.</th><th>{t('hkx.foundAt')}</th><th>{t('hkx.place')}</th><th>{t('hkx.description')}</th><th>{t('hkx.foundBy')}</th><th>{t('hkx.lastGuest')}</th><th>{t('hkx.status')}</th><th /></tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={8} className="muted">{t('common.none')}</td></tr>}
            {(rows ?? []).map((x) => (
              <tr key={x.id}>
                <td><b>{x.ref}</b></td><td>{fmtDateTime(x.found_at, locale)}</td><td>{x.room ? `${t('common.room')} ${x.room}` : x.location}</td>
                <td className="wrap">{t(`hkx.lfc_${x.category}` as Key)} — {x.description}{x.value_note ? <span className="muted"> · {x.value_note}</span> : null}
                  {x.photos && <div className="photo-strip">{x.photos.map((p: number) => <a key={p} href={`/api/photos/${p}`} target="_blank" rel="noreferrer"><img src={`/api/photos/${p}`} alt="" style={{ height: 44, borderRadius: 6 }} /></a>)}</div>}</td>
                <td>{x.found_by_name}</td>
                <td className="wrap">{x.g_last || x.g_company ? `${x.g_company ?? `${x.g_last ?? ''} ${x.g_first ?? ''}`}${x.g_phone ? ` · ${x.g_phone}` : ''}` : '—'}</td>
                <td><span className="pill">{t(`hkx.lf_${x.status}` as Key)}</span>
                  {x.storage_location && x.status === 'stored' && <div className="muted" style={{ fontSize: 12 }}>{x.storage_location}</div>}
                  {x.status === 'returned' && <div className="muted" style={{ fontSize: 12 }}>{x.returned_to} · {x.returned_by_name}</div>}
                  {x.status === 'archived' && <div className="muted" style={{ fontSize: 12 }}>{x.archived_reason}</div>}</td>
                <td className="pin-end"><div className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
                  {can('lostfound.manage') && next[x.status].map((s) => <button key={s} className="btn sm" onClick={() => setSt({ item: x, status: s })}>{t(`hkx.lfa_${s}` as Key)}</button>)}
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {adding && <LostModal defaultName={me?.full_name ?? ''} onClose={() => setAdding(false)} onDone={() => { setAdding(false); load(); }} />}
      {st && <LostStatusModal item={st.item} status={st.status} onClose={() => setSt(null)} onDone={() => { setSt(null); load(); }} />}
    </>
  );
}

function LostModal({ defaultName, onClose, onDone }: { defaultName: string; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [rooms, setRooms] = useState<any[]>([]);
  const [key] = useState(() => newOpKey('lf'));
  const [f, setF] = useState({ room_id: '', location: '', category: 'other', description: '', found_by_name: defaultName, value_note: '' });
  const [file, setFile] = useState<File | null>(null);
  useEffect(() => { get('/api/rooms').then(setRooms).catch(() => {}); }, []);
  const save = async () => {
    try {
      const r = await postOnce('/api/lost-found', { ...f, room_id: f.room_id ? Number(f.room_id) : null, location: f.location || null, value_note: f.value_note || null }, key);
      if (file) await upload('/api/photos', file, { owner_type: 'lost_item', owner_id: String(r.id) });
      toast('success', `${t('hkx.lfRecorded')} ${r.ref}`);
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={t('hkx.declare')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={f.description.trim().length < 3 || (!f.room_id && !f.location)} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('common.room')}><select className="input" value={f.room_id} onChange={(e) => setF({ ...f, room_id: e.target.value })}><option value="">—</option>{rooms.map((r) => <option key={r.id} value={r.id}>{r.number}</option>)}</select></Field>
        <Field label={t('hkx.orPlace')}><input className="input" value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} placeholder={t('hkx.placePh')} /></Field>
        <Field label={t('hkx.category')}><select className="input" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{LF_CATS.map((k) => <option key={k} value={k}>{t(`hkx.lfc_${k}` as Key)}</option>)}</select></Field>
        <Field label={t('hkx.foundBy')}><input className="input" value={f.found_by_name} onChange={(e) => setF({ ...f, found_by_name: e.target.value })} /></Field>
      </div>
      <Field label={t('hkx.description')}><textarea className="input" rows={2} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
      <Field label={t('hkx.valueNote')}><input className="input" value={f.value_note} onChange={(e) => setF({ ...f, value_note: e.target.value })} /></Field>
      <Field label={t('hkx.photo')}><input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" className="input" onChange={(e) => setFile(e.target.files?.[0] ?? null)} /></Field>
    </Modal>
  );
}

function LostStatusModal({ item, status, onClose, onDone }: { item: any; status: string; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [v, setV] = useState('');
  const field = status === 'stored' ? 'storage_location' : status === 'returned' ? 'returned_to' : 'reason';
  const save = async () => { try { await post(`/api/lost-found/${item.id}/status`, { status, [field]: v }); onDone(); } catch (e: any) { toast('error', e.message); } };
  return (
    <Modal size="sm" title={`${t(`hkx.lfa_${status}` as Key)} — ${item.ref}`} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={v.trim().length < 2} onClick={save}>{t('common.confirm')}</button></>}>
      <Field label={t(`hkx.lff_${status}` as Key)}><input className="input" autoFocus value={v} onChange={(e) => setV(e.target.value)} /></Field>
      {status === 'returned' && <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>{t('hkx.idCheck')}</p>}
    </Modal>
  );
}

// ===================================================== Rapports =====================================================
function Reports() {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [kind, setKind] = useState('done');
  const [p, setP] = useState({ from: monthStart(), to: todayLocal() });
  const [r, setR] = useState<any>(null);
  const qs = `from=${p.from}&to=${p.to}`;
  useEffect(() => { setR(null); get(`/api/housekeeping/reports/${kind}?${qs}`).then(setR).catch(err(toast)); }, [kind, qs]);
  return (
    <>
      <div className="row">
        <select className="input" style={{ width: 'auto' }} aria-label={t('hkx.t_reports')} value={kind} onChange={(e) => setKind(e.target.value)}>
          {['done', 'late', 'performance', 'inspections', 'linen', 'daily'].map((k) => <option key={k} value={k}>{t(`hkx.rp_${k}` as Key)}</option>)}
        </select>
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('bi.from')} value={p.from} onChange={(e) => e.target.value && setP({ ...p, from: e.target.value })} />
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('bi.to')} value={p.to} min={p.from} onChange={(e) => e.target.value && setP({ ...p, to: e.target.value })} />
        <span style={{ flex: 1 }} />
        {['pdf', 'xlsx', 'csv'].map((f) => <button key={f} className="btn" onClick={() => window.open(`/api/housekeeping/reports/${kind}?${qs}&format=${f}`, '_blank')}>{f === 'xlsx' ? 'Excel' : f.toUpperCase()}</button>)}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{r?.title ?? '…'} <span className="muted" style={{ fontWeight: 500 }}>· {fmtDate(p.from, locale)} → {fmtDate(p.to, locale)}</span></h3>
        <table className="table">
          <thead><tr>{(r?.columns ?? []).map((c: any) => <th key={c.key}>{c.label}</th>)}</tr></thead>
          <tbody>
            {r && !r.rows.length && <tr><td colSpan={r.columns.length} className="muted">{t('common.none')}</td></tr>}
            {(r?.rows ?? []).map((x: any, i: number) => <tr key={i}>{r.columns.map((c: any) => <td key={c.key} className="wrap">{x[c.key] === null || x[c.key] === undefined || x[c.key] === '' ? '—' : String(x[c.key])}</td>)}</tr>)}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ===================================================== Réglages =====================================================
function Settings() {
  const { t } = useI18n();
  const toast = useToast();
  const [s, setS] = useState<any>(null);
  const [list, setList] = useState<any[]>([]);
  const [n, setN] = useState({ category: 'Chambre', label: '', critical: false });
  const loadList = () => get('/api/housekeeping/checklist?all=1').then(setList).catch(err(toast));
  useEffect(() => { get('/api/housekeeping/settings').then(setS).catch(err(toast)); loadList(); }, []);
  if (!s) return <span>{t('common.loading')}</span>;
  const save = async () => { try { setS(await api('PUT', '/api/housekeeping/settings', s)); toast('success', t('set.saved')); } catch (e: any) { toast('error', e.message); } };
  const upd = async (id: number, b: any) => { try { await patch(`/api/housekeeping/checklist/${id}`, b); loadList(); } catch (e: any) { toast('error', e.message); } };
  return (
    <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: 14, alignItems: 'start' }}>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <h3 style={{ margin: 0 }}>{t('hkx.rules')}</h3>
        <label className="check"><input type="checkbox" checked={s.inspection_required} onChange={(e) => setS({ ...s, inspection_required: e.target.checked })} />{t('hkx.inspectionRequired')}</label>
        <label className="check"><input type="checkbox" checked={s.stayover_daily} onChange={(e) => setS({ ...s, stayover_daily: e.target.checked })} />{t('hkx.stayoverDaily')}</label>
        <Field label={t('hkx.minScore')}><input type="number" min={0} max={100} className="input" style={{ width: 120 }} value={s.min_score} onChange={(e) => setS({ ...s, min_score: Number(e.target.value) })} /></Field>
        <h3 style={{ margin: 0 }}>{t('hkx.standardTimes')}</h3>
        <div className="form-grid">{KINDS.map((k) => <Field key={k} label={t(`hkx.k_${k}` as Key)}><input type="number" min={1} max={600} className="input" value={s.minutes[k] ?? 30} onChange={(e) => setS({ ...s, minutes: { ...s.minutes, [k]: Number(e.target.value) } })} /></Field>)}</div>
        <button className="btn primary" style={{ alignSelf: 'flex-start' }} onClick={save}>{t('common.save')}</button>
      </div>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <h3 style={{ margin: 0 }}>{t('hkx.checklist')}</h3>
        {list.map((i) => (
          <div key={i.id} className="ck" style={{ opacity: i.active ? 1 : 0.5 }}>
            <span><span className="muted" style={{ fontSize: 12 }}>{i.category} · </span>{i.label}</span>
            <div className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
              <label className="check" style={{ fontSize: 12.5 }}><input type="checkbox" checked={i.critical} onChange={(e) => upd(i.id, { critical: e.target.checked })} />{t('hkx.critical')}</label>
              <button className="btn sm ghost" onClick={() => upd(i.id, { active: !i.active })}>{i.active ? t('hkx.deactivate') : t('hkx.reactivate')}</button>
            </div>
          </div>
        ))}
        <div className="row" style={{ alignItems: 'flex-end' }}>
          <input className="input" style={{ width: 130 }} aria-label={t('hkx.category')} value={n.category} onChange={(e) => setN({ ...n, category: e.target.value })} />
          <input className="input" style={{ flex: 1, minWidth: 160 }} aria-label={t('hkx.point')} placeholder={t('hkx.point')} value={n.label} onChange={(e) => setN({ ...n, label: e.target.value })} />
          <label className="check" style={{ alignItems: 'center' }}><input type="checkbox" checked={n.critical} onChange={(e) => setN({ ...n, critical: e.target.checked })} />{t('hkx.critical')}</label>
          <button className="btn" disabled={n.label.trim().length < 2} onClick={async () => { try { await post('/api/housekeeping/checklist', n); setN({ ...n, label: '' }); loadList(); } catch (e: any) { toast('error', e.message); } }}><Icon name="plus" />{t('hkx.add')}</button>
        </div>
      </div>
    </div>
  );
}
