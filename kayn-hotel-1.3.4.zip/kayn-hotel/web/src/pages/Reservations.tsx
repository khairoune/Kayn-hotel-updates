import { useCallback, useEffect, useMemo, useState } from 'react';
import { Page } from '../components/Layout';
import { NewReservation } from '../components/NewReservation';
import { ReservationPanel } from '../components/ReservationPanel';
import { Icon, StatusPill } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { get } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, money } from '../lib/format';
import { useLive } from '../lib/useLive';

const STATUSES = ['pending', 'confirmed', 'checked_in', 'checked_out', 'cancelled', 'no_show'];
const SORTS = ['arrival_desc', 'arrival_asc', 'departure_asc', 'created_desc', 'balance_desc'];
const EMPTY = { status: [] as string[], booker_type: '', source: '', room_type_id: '', arrival_from: '', arrival_to: '', stay_on: '', balance_due: false };

export function Reservations() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [f, setF] = useState(EMPTY);
  const [sort, setSort] = useState('arrival_desc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [showFilters, setShowFilters] = useState(false);
  const [types, setTypes] = useState<any[]>([]);
  const [data, setData] = useState<{ total: number; total_due: number; rows: any[] } | null>(null);
  const [panel, setPanel] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);

  useEffect(() => { get('/api/room-types').then(setTypes).catch(() => {}); }, []);

  const params = useMemo(() => {
    const p = new URLSearchParams({ sort, page: String(page), page_size: String(pageSize) });
    if (search.trim()) p.set('search', search.trim());
    if (f.status.length) p.set('status', f.status.join(','));
    for (const k of ['booker_type', 'source', 'room_type_id', 'arrival_from', 'arrival_to', 'stay_on'] as const) if (f[k]) p.set(k, String(f[k]));
    if (f.balance_due) p.set('balance_due', 'true');
    return p;
  }, [search, f, sort, page, pageSize]);

  const load = useCallback(() => { get(`/api/reservations?${params}`).then(setData).catch((e) => toast('error', e.message)); }, [params]);
  useEffect(() => {
    const h = setTimeout(load, 200);
    return () => clearTimeout(h);
  }, [load]);
  useLive(load);

  const set = (patch: Partial<typeof EMPTY>) => { setF({ ...f, ...patch }); setPage(1); };
  const exportUrl = (format: 'xlsx' | 'pdf') => {
    const p = new URLSearchParams(params);
    p.delete('page');
    p.delete('page_size');
    p.set('format', format);
    return `/api/reservations/export?${p}`;
  };
  const activeFilters = f.status.length + ['booker_type', 'source', 'room_type_id', 'arrival_from', 'arrival_to', 'stay_on'].filter((k) => (f as any)[k]).length + (f.balance_due ? 1 : 0);
  const pages = data ? Math.max(1, Math.ceil(data.total / pageSize)) : 1;
  const m = (n: number) => money(n, locale);

  return (
    <Page>
      <div className="page-head">
        <div style={{ marginInlineEnd: 'auto' }}>
          <h1 className="page-title">{t('res.title')}</h1>
          <div className="page-sub">{data?.total ?? 0} {t('res.title').toLowerCase()} · {t('list.totalDue')} : <b>{m(data?.total_due ?? 0)}</b></div>
        </div>
        <div className="row no-print" style={{ gap: 6 }}>
          <a className="btn" href={exportUrl('xlsx')}>{t('list.excel')}</a>
          <a className="btn" href={exportUrl('pdf')} target="_blank" rel="noreferrer">{t('list.pdf')}</a>
          <button className="btn" onClick={() => window.print()}><Icon name="print" size={16} /> {t('list.print')}</button>
          {can('reservations.create') && <button className="btn primary" onClick={() => setCreating(true)}><Icon name="plus" size={16} /> {t('plan.new')}</button>}
        </div>
      </div>

      <div className="row no-print">
        <div style={{ position: 'relative' }}>
          <input className="input" style={{ width: 300, paddingInlineStart: 34 }} placeholder="N°, nom, téléphone, chambre, groupe…" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} aria-label={t('common.search')} autoFocus />
          <span style={{ position: 'absolute', insetInlineStart: 10, top: 11, color: 'var(--muted)' }}><Icon name="search" size={16} /></span>
        </div>
        {STATUSES.map((s) => (
          <button key={s} className={`chip ${f.status.includes(s) ? 'on' : ''}`} aria-pressed={f.status.includes(s)}
            onClick={() => set({ status: f.status.includes(s) ? f.status.filter((x) => x !== s) : [...f.status, s] })}>
            <StatusPill status={s} label={t(`st.${s}` as Key)} />
          </button>
        ))}
        <button className={`btn ${showFilters ? 'primary' : ''}`} onClick={() => setShowFilters(!showFilters)}>{t('list.filters')}{activeFilters ? ` (${activeFilters})` : ''}</button>
        <select className="input" style={{ width: 200 }} value={sort} onChange={(e) => { setSort(e.target.value); setPage(1); }} aria-label={t('list.sort')}>
          {SORTS.map((s) => <option key={s} value={s}>{t('list.sort')} : {t(`sort.${s}` as Key)}</option>)}
        </select>
      </div>

      {showFilters && (
        <div className="filters no-print">
          <label className="field"><span style={{ fontSize: 12, fontWeight: 600 }}>{t('res.type')}</span>
            <select className="input" value={f.booker_type} onChange={(e) => set({ booker_type: e.target.value })}><option value="">{t('common.all')}</option>{['individual', 'group', 'company', 'agency'].map((x) => <option key={x} value={x}>{t(`bt.${x}` as Key)}</option>)}</select></label>
          <label className="field"><span style={{ fontSize: 12, fontWeight: 600 }}>{t('res.source')}</span>
            <select className="input" value={f.source} onChange={(e) => set({ source: e.target.value })}><option value="">{t('common.all')}</option>{['walk_in', 'phone', 'email', 'company', 'agency', 'website', 'other'].map((x) => <option key={x} value={x}>{t(`src.${x}` as Key)}</option>)}</select></label>
          <label className="field"><span style={{ fontSize: 12, fontWeight: 600 }}>{t('form.roomType')}</span>
            <select className="input" value={f.room_type_id} onChange={(e) => set({ room_type_id: e.target.value })}><option value="">{t('common.all')}</option>{types.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></label>
          <label className="field"><span style={{ fontSize: 12, fontWeight: 600 }}>{t('list.arrFrom')}</span><input type="date" className="input" value={f.arrival_from} onChange={(e) => set({ arrival_from: e.target.value })} /></label>
          <label className="field"><span style={{ fontSize: 12, fontWeight: 600 }}>{t('list.arrTo')}</span><input type="date" className="input" value={f.arrival_to} onChange={(e) => set({ arrival_to: e.target.value })} /></label>
          <label className="field"><span style={{ fontSize: 12, fontWeight: 600 }}>{t('list.stayOn')}</span><input type="date" className="input" value={f.stay_on} onChange={(e) => set({ stay_on: e.target.value })} /></label>
          <label className="row" style={{ gap: 8, fontSize: 13, alignSelf: 'end', minHeight: 40 }}><input type="checkbox" checked={f.balance_due} onChange={(e) => set({ balance_due: e.target.checked })} /> {t('list.balanceDue')}</label>
          <button className="btn" style={{ alignSelf: 'end' }} onClick={() => { setF(EMPTY); setSearch(''); setPage(1); }}>{t('list.reset')}</button>
        </div>
      )}

      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead>
            <tr>
              <th>{t('res.code')}</th><th>{t('res.guest')}</th><th>{t('list.phone')}</th><th>{t('list.roomType')}</th><th>{t('list.roomNo')}</th>
              <th>{t('res.arrival')}</th><th>{t('res.departure')}</th><th className="num">{t('list.nights')}</th><th className="num">{t('list.persons')}</th>
              <th className="num">{t('common.total')}</th><th className="num">{t('list.deposit')}</th><th className="num">{t('list.remaining')}</th>
              <th>{t('res.source')}</th><th>{t('res.status')}</th>
            </tr>
          </thead>
          <tbody>
            {data?.rows.map((r) => (
              <tr key={r.id} className="click" onClick={() => setPanel(r.id)} tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && setPanel(r.id)}>
                <td><b>{r.code}</b></td>
                <td className="wrap" style={{ minWidth: 160 }}>
                  <b>{r.guest_name}</b>
                  {(r.group_name || r.payer_name) && <div className="muted" style={{ fontSize: 12 }}>{[r.group_name, r.payer_name].filter(Boolean).join(' · ')}</div>}
                </td>
                <td>{r.phone ?? '—'}</td>
                <td>{r.room_types ?? '—'}</td>
                <td>{r.rooms ?? '—'}{r.room_count > 1 && <span className="muted" style={{ fontSize: 12 }}> ({r.room_count})</span>}</td>
                <td>{fmtDate(r.check_in, locale, { day: '2-digit', month: '2-digit', year: 'numeric' })}</td>
                <td>{fmtDate(r.check_out, locale, { day: '2-digit', month: '2-digit', year: 'numeric' })}</td>
                <td className="num">{r.nights}</td>
                <td className="num">{r.persons}</td>
                <td className="num">{m(r.total)}</td>
                <td className="num">{m(r.paid_net)}</td>
                <td className="num" style={{ fontWeight: 700, color: r.balance > 0 ? 'var(--warn-text)' : undefined }}>{m(Math.max(0, r.balance))}</td>
                <td>{t(`src.${r.source}` as Key)}</td>
                <td><StatusPill status={r.status} label={t(`st.${r.status}` as Key)} /></td>
              </tr>
            ))}
            {data && data.rows.length === 0 && <tr><td colSpan={14} className="muted">{t('common.none')}</td></tr>}
            {!data && <tr><td colSpan={14}>{t('common.loading')}</td></tr>}
          </tbody>
        </table>
      </div>
      <div className="row no-print">
        <button className="btn sm" disabled={page <= 1} onClick={() => setPage(1)}>«</button>
        <button className="btn sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>‹</button>
        <span className="muted">{page} / {pages}</span>
        <button className="btn sm" disabled={page >= pages} onClick={() => setPage(page + 1)}>›</button>
        <button className="btn sm" disabled={page >= pages} onClick={() => setPage(pages)}>»</button>
        <select className="input" style={{ width: 110, minHeight: 32 }} value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }} aria-label={t('list.perPage')}>
          {[25, 50, 100].map((n) => <option key={n} value={n}>{n} {t('list.perPage')}</option>)}
        </select>
      </div>
      {panel !== null && <ReservationPanel id={panel} onClose={() => setPanel(null)} onChanged={load} />}
      {creating && <NewReservation onClose={() => setCreating(false)} onCreated={(r) => { setCreating(false); load(); setPanel(r.id); }} />}
    </Page>
  );
}
