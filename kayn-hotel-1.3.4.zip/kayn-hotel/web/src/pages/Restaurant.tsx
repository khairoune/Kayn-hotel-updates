import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Page } from '../components/Layout';
import { ReasonModal } from '../components/ReservationPanel';
import { Field, Icon, Modal } from '../components/ui';
import { useI18n, type Key } from '../i18n';
import { api, get, newOpKey, patch, post, postOnce, upload } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { addDays, fmtDate, fmtDateTime, money, todayLocal, currency } from '../lib/format';
import { useLive } from '../lib/useLive';

type Tab = 'dashboard' | 'orders' | 'floor' | 'kitchen' | 'roomservice' | 'breakfast' | 'bar' | 'menu' | 'stock' | 'reports' | 'settings';
const ST_COLORS: Record<string, [string, string]> = {
  new: ['#E0E7FF', '#3730A3'], confirmed: ['#DBEAFE', '#1E40AF'], preparing: ['#FEF3C7', '#92400E'], ready: ['#DCFCE7', '#166534'], served: ['#F1F5F9', '#475569'], cancelled: ['#FEE2E2', '#991B1B'],
};
const TABLE_COLORS: Record<string, string> = { available: '#15803D', occupied: '#B91C1C', reserved: '#C9A227', to_clean: '#7C3AED' };
const KITCHEN_ST: Record<string, string> = { pending: '#94A3B8', sent: '#1D4ED8', preparing: '#D97706', ready: '#15803D', served: '#64748B' };
const ALLERGENS = ['gluten', 'crustaceans', 'eggs', 'fish', 'peanuts', 'soy', 'milk', 'nuts', 'celery', 'mustard', 'sesame', 'sulphites', 'lupin', 'molluscs'];
const hhmm = (d: string | null | undefined) => (d ? new Date(d).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '');
const mins = (a: string | null | undefined, b?: string | null) => (a ? Math.max(0, Math.round(((b ? new Date(b).getTime() : Date.now()) - new Date(a).getTime()) / 60000)) : null);
const toNum = (v: string) => Number(String(v).replace(',', '.').replace(/\s/g, '')) || 0;
const err = (toast: any) => (e: any) => toast('error', e.message);

function StatusPill({ s }: { s: string }) {
  const { t } = useI18n();
  const [bg, fg] = ST_COLORS[s] ?? ST_COLORS.new;
  return <span className="pill" style={{ background: bg, color: fg }}>{t(`rt.s_${s}` as Key)}</span>;
}
function SettlePill({ s }: { s: string }) {
  const { t } = useI18n();
  const c = s === 'open' ? { background: '#FFEDD5', color: '#9A3412' } : s === 'cancelled' ? { background: '#FEE2E2', color: '#991B1B' } : { background: '#DCFCE7', color: '#166534' };
  return <span className="pill" style={c}>{t(`rt.st_${s}` as Key)}</span>;
}

export function Restaurant() {
  const { t } = useI18n();
  const { can } = useAuth();
  const [sp, setSp] = useSearchParams();
  const tabs = ([['dashboard', ['restaurant.view']], ['orders', ['restaurant.view']], ['floor', ['restaurant.view']], ['kitchen', ['restaurant.kitchen', 'restaurant.bar']],
    ['roomservice', ['restaurant.view']], ['breakfast', ['breakfast.manage']], ['bar', ['restaurant.bar']], ['menu', ['restaurant.menu']], ['stock', ['stock.view', 'stock.manage']],
    ['reports', ['restaurant.reports']], ['settings', ['restaurant.menu']]] as [Tab, string[]][]).filter(([, ps]) => ps.some((p) => can(p))).map(([k]) => k);
  const tab = tabs.includes(sp.get('tab') as Tab) ? (sp.get('tab') as Tab) : tabs[0];
  const [open, setOpen] = useState<number | null>(null);
  return (
    <Page>
      <div className="page-head"><h1 className="page-title" style={{ marginInlineEnd: 'auto' }}>{t('rt.title')}</h1></div>
      <div className="tabs" style={{ padding: 0, overflowX: 'auto' }}>
        {tabs.map((k) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setSp({ tab: k }, { replace: true })}>{t(`rt.t_${k}` as Key)}</button>)}
      </div>
      {tab === 'dashboard' && <Dash openOrder={setOpen} />}
      {tab === 'orders' && <Orders openOrder={setOpen} />}
      {tab === 'floor' && <Floor openOrder={setOpen} />}
      {tab === 'kitchen' && <Kitchen />}
      {tab === 'roomservice' && <RoomService openOrder={setOpen} />}
      {tab === 'breakfast' && <Breakfast />}
      {tab === 'bar' && <Bar openOrder={setOpen} />}
      {tab === 'menu' && <MenuAdmin />}
      {tab === 'stock' && <Stock />}
      {tab === 'reports' && <Reports />}
      {tab === 'settings' && <RsSettings />}
      {open && <OrderEditor id={open} onClose={() => setOpen(null)} />}
    </Page>
  );
}

// ===================================================== Tableau de bord =====================================================
function Dash({ openOrder }: { openOrder: (id: number) => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [range, setRange] = useState<'day' | 'week' | 'month'>('day');
  const [d, setD] = useState<any>(null);
  const from = range === 'day' ? todayLocal() : range === 'week' ? addDays(todayLocal(), -6) : `${todayLocal().slice(0, 8)}01`;
  const load = useCallback(() => { get(`/api/rs/dashboard?from=${from}&to=${todayLocal()}`).then(setD).catch(err(toast)); }, [from]);
  useEffect(load, [load]);
  useLive(load, 20000);
  if (!d) return <span>{t('common.loading')}</span>;
  const k = d.kpi;
  const max = Math.max(1, ...d.series.map((s: any) => s.revenue));
  return (
    <>
      <div className="row">
        <div className="seg">{(['day', 'week', 'month'] as const).map((r) => <button key={r} className={range === r ? 'on' : ''} onClick={() => setRange(r)}>{t(`rt.r_${r}` as Key)}</button>)}</div>
        <span className="muted">{fmtDate(from, locale)} → {fmtDate(todayLocal(), locale)}</span>
      </div>
      <div className="grid kpis">
        {k.revenue !== null && <div className="card kpi"><span className="label">{t('rt.kRevenue')}</span><span className="value" style={{ fontSize: 21 }}>{money(k.revenue, locale)}</span></div>}
        <div className="card kpi"><span className="label">{t('rt.kOrders')}</span><span className="value">{k.orders}</span></div>
        <div className="card kpi" style={{ borderInlineStart: '4px solid #3730A3' }}><span className="label">{t('rt.kPending')}</span><span className="value">{k.pending}</span></div>
        <div className="card kpi" style={{ borderInlineStart: '4px solid #D97706' }}><span className="label">{t('rt.kPreparing')}</span><span className="value">{k.preparing}</span></div>
        <div className="card kpi" style={{ borderInlineStart: '4px solid #15803D' }}><span className="label">{t('rt.kReady')}</span><span className="value">{k.ready}</span></div>
        <div className="card kpi"><span className="label">{t('rt.kServed')}</span><span className="value">{k.served_today}</span></div>
        <div className="card kpi"><span className="label">{t('rt.kTables')}</span><span className="value">{k.tables_occupied} / {k.tables_total}</span><span className="muted" style={{ fontSize: 12 }}>{k.tables_available} {t('rt.free')}</span></div>
        {k.avg_ticket !== null && <div className="card kpi"><span className="label">{t('rt.kAvg')}</span><span className="value" style={{ fontSize: 21 }}>{money(k.avg_ticket, locale)}</span></div>}
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 14, alignItems: 'start' }}>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <h3 style={{ margin: 0 }}>{t('rt.topItems')}</h3>
          {!d.top.length && <span className="muted">{t('common.none')}</span>}
          {d.top.map((x: any, i: number) => (
            <div key={x.name} className="sum-row"><span>{i + 1}. {x.name}</span><span><b>{x.qty}</b>{k.revenue !== null ? <span className="muted"> · {money(x.revenue, locale)}</span> : null}</span></div>
          ))}
        </div>
        {d.series.length > 0 && (
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <h3 style={{ margin: 0 }}>{t('rt.revenueByDay')}</h3>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 4, height: 150 }}>
              {d.series.map((s: any) => (
                <div key={s.day} title={`${fmtDate(s.day, locale)} · ${money(s.revenue, locale)}`} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                  <div style={{ width: '100%', maxWidth: 34, height: `${Math.max(2, (s.revenue / max) * 120)}px`, background: 'var(--primary)', borderRadius: 4 }} />
                  <span className="muted" style={{ fontSize: 10.5 }}>{s.day.slice(8)}</span>
                </div>
              ))}
            </div>
            {d.outlets.map((o: any) => <div key={o.outlet} className="sum-row"><span>{t(`rt.o_${o.outlet}` as Key)} · {o.orders}</span><b>{money(o.revenue, locale)}</b></div>)}
          </div>
        )}
        {d.low_stock.length > 0 && (
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 6, borderColor: 'var(--danger)' }}>
            <h3 style={{ margin: 0, color: 'var(--danger)' }}>{t('rt.lowStock')}</h3>
            {d.low_stock.map((p: any) => <div key={p.id} className="sum-row"><span>{p.name}</span><b>{Number(p.stock_qty)} {p.unit} <span className="muted">/ min {Number(p.min_stock)}</span></b></div>)}
          </div>
        )}
      </div>
      <Orders openOrder={openOrder} live />
    </>
  );
}

// ===================================================== Commandes =====================================================
function Orders({ openOrder, live }: { openOrder: (id: number) => void; live?: boolean }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [f, setF] = useState({ open: true, date: todayLocal(), outlet: '', search: '' });
  const [rows, setRows] = useState<any[] | null>(null);
  const [creating, setCreating] = useState(false);
  const load = useCallback(() => {
    const qs = new URLSearchParams({ date: f.date, search: f.search });
    if (f.open || live) qs.set('open', '1');
    if (f.outlet) qs.set('outlet', f.outlet);
    get(`/api/rs/orders?${qs}`).then(setRows).catch(err(toast));
  }, [f, live]);
  useEffect(() => { const h = setTimeout(load, 150); return () => clearTimeout(h); }, [load]);
  useLive(load, 15000);
  return (
    <>
      {live ? <h3 style={{ margin: '6px 0 0' }}>{t('rt.openOrders')}</h3> : (
        <div className="row">
          <div className="seg"><button className={f.open ? 'on' : ''} onClick={() => setF({ ...f, open: true })}>{t('rt.inProgress')}</button><button className={!f.open ? 'on' : ''} onClick={() => setF({ ...f, open: false })}>{t('rt.history')}</button></div>
          {!f.open && <input type="date" className="input" style={{ width: 160 }} aria-label="Date" value={f.date} onChange={(e) => e.target.value && setF({ ...f, date: e.target.value })} />}
          <select className="input" style={{ width: 'auto' }} aria-label={t('rt.outlet')} value={f.outlet} onChange={(e) => setF({ ...f, outlet: e.target.value })}>
            <option value="">{t('rt.allOutlets')}</option>{['restaurant', 'bar', 'room_service', 'breakfast'].map((o) => <option key={o} value={o}>{t(`rt.o_${o}` as Key)}</option>)}
          </select>
          <input className="input" style={{ width: 200 }} placeholder={t('common.search')} aria-label={t('common.search')} value={f.search} onChange={(e) => setF({ ...f, search: e.target.value })} />
          <span style={{ flex: 1 }} />
          {(can('restaurant.order') || can('restaurant.bar')) && <button className="btn primary" onClick={() => setCreating(true)}><Icon name="plus" />{t('rt.newOrder')}</button>}
        </div>
      )}
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>N°</th><th>{t('rt.outlet')}</th><th>{t('rt.where')}</th><th>{t('rt.guest')}</th><th>{t('rt.time')}</th><th className="num">{t('rt.items')}</th><th className="num">Total</th><th>{t('rt.status')}</th><th>{t('rt.settlement')}</th><th>{t('rt.waiter')}</th></tr></thead>
          <tbody>
            {rows && !rows.length && <tr><td colSpan={10} className="muted">{t('common.none')}</td></tr>}
            {(rows ?? []).map((o) => (
              <tr key={o.id} style={{ cursor: 'pointer' }} onClick={() => openOrder(o.id)}>
                <td><b>{o.number}</b>{o.priority !== 'normal' && <span className="pill prio-urgent" style={{ marginInlineStart: 6 }}>{t(`rt.p_${o.priority}` as Key)}</span>}</td>
                <td>{t(`rt.o_${o.outlet}` as Key)}</td>
                <td>{o.table_number ? `${t('rt.table')} ${o.table_number}` : o.room_number ? `${t('common.room')} ${o.room_number}` : t('rt.counter')}</td>
                <td>{o.guest_name ?? '—'}</td>
                <td>{f.open || live ? `${hhmm(o.created_at)} · ${mins(o.created_at, o.served_at)} min` : fmtDateTime(o.created_at, locale)}</td>
                <td className="num">{o.lines}</td><td className="num">{money(Number(o.total), locale)}</td>
                <td><StatusPill s={o.status} /></td><td><SettlePill s={o.settlement} /></td><td>{o.waiter ?? ''}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {creating && <NewOrderModal onClose={() => setCreating(false)} onDone={(id) => { setCreating(false); load(); openOrder(id); }} />}
    </>
  );
}

function NewOrderModal({ preset, onClose, onDone }: { preset?: { outlet?: string; table_id?: number; room_id?: number }; onClose: () => void; onDone: (id: number) => void }) {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [tables, setTables] = useState<any[]>([]);
  const [rooms, setRooms] = useState<any[]>([]);
  const [key] = useState(() => newOpKey('rso'));
  const [f, setF] = useState({ outlet: preset?.outlet ?? (can('restaurant.order') ? 'restaurant' : 'bar'), table_id: preset?.table_id ? String(preset.table_id) : '', room_id: preset?.room_id ? String(preset.room_id) : '', covers: 2, guest_name: '', notes: '', priority: 'normal' });
  useEffect(() => {
    get('/api/rs/tables').then(setTables).catch(() => {});
    get('/api/rs/in-house').then(setRooms).catch(() => {});
  }, []);
  const save = async () => {
    try {
      const o = await postOnce('/api/rs/orders', { outlet: f.outlet, table_id: f.table_id ? Number(f.table_id) : null, room_id: f.room_id ? Number(f.room_id) : null, covers: f.covers, guest_name: f.guest_name || null, notes: f.notes || null, priority: f.priority }, key);
      onDone(o.id);
    } catch (e: any) { toast('error', e.message); }
  };
  const free = tables.filter((x) => !x.merged_into && (x.display !== 'occupied' || String(x.id) === f.table_id));
  return (
    <Modal title={t('rt.newOrder')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={f.outlet === 'room_service' && !f.room_id} onClick={save}>{t('rt.open')}</button></>}>
      <div className="seg">{['restaurant', 'bar', 'room_service', 'breakfast'].filter((o) => o !== 'bar' || can('restaurant.bar') || can('restaurant.order')).map((o) => <button key={o} className={f.outlet === o ? 'on' : ''} onClick={() => setF({ ...f, outlet: o, table_id: o === 'room_service' ? '' : f.table_id })}>{t(`rt.o_${o}` as Key)}</button>)}</div>
      <div className="form-grid">
        {f.outlet !== 'room_service' && <Field label={t('rt.table')}><select className="input" value={f.table_id} onChange={(e) => setF({ ...f, table_id: e.target.value })}><option value="">{t('rt.counter')}</option>{free.map((x) => <option key={x.id} value={x.id}>{x.number} · {x.capacity} p. · {t(`rt.tb_${x.display}` as Key)}</option>)}</select></Field>}
        <Field label={f.outlet === 'room_service' ? `${t('common.room')} *` : `${t('common.room')} (${t('rt.optional')})`}><select className="input" value={f.room_id} onChange={(e) => setF({ ...f, room_id: e.target.value })}><option value="">—</option>{rooms.map((r) => <option key={r.room_id} value={r.room_id}>{r.room} · {r.guest}{r.dnd ? ' · DND' : ''}</option>)}</select></Field>
        <Field label={t('rt.covers')}><input type="number" min={1} max={60} className="input" value={f.covers} onChange={(e) => setF({ ...f, covers: Math.max(1, Number(e.target.value)) })} /></Field>
        {!f.room_id && <Field label={t('rt.guest')}><input className="input" value={f.guest_name} onChange={(e) => setF({ ...f, guest_name: e.target.value })} /></Field>}
        <Field label={t('rt.priority')}><select className="input" value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value })}>{['normal', 'high', 'urgent'].map((p) => <option key={p} value={p}>{t(`rt.p_${p}` as Key)}</option>)}</select></Field>
      </div>
      <Field label={t('rt.notes')}><input className="input" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} placeholder={t('rt.notesPh')} /></Field>
    </Modal>
  );
}

// ---------- Éditeur de commande : carte, lignes, cuisine, service, remise, règlement ----------
function OrderEditor({ id, onClose }: { id: number; onClose: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [o, setO] = useState<any>(null);
  const [menu, setMenu] = useState<any>(null);
  const [cat, setCat] = useState('');
  const [search, setSearch] = useState('');
  const [pick, setPick] = useState<any>(null);
  const [modal, setModal] = useState<'' | 'settle' | 'discount' | 'cancel' | 'move'>('');
  const [cancelLine, setCancelLine] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const load = useCallback(() => { get(`/api/rs/orders/${id}`).then(setO).catch(err(toast)); }, [id]);
  useEffect(load, [load]);
  useEffect(() => { if (o?.outlet) get(`/api/rs/menu/current?outlet=${o.outlet}`).then(setMenu).catch(() => {}); }, [o?.outlet]);
  const act = async (fn: () => Promise<any>, ok?: string) => {
    try { setBusy(true); const r = await fn(); if (r?.warnings?.length) r.warnings.forEach((w: string) => toast('info', w)); if (r?.stock_alerts?.length) toast('info', `${t('rt.lowStock')} : ${r.stock_alerts.join(' · ')}`); if (ok) toast('success', ok); load(); return r; }
    catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  const editable = o && o.status !== 'cancelled' && o.settlement === 'open';
  const orderPerm = can('restaurant.order') || can('restaurant.bar');
  const add = (item: any, qty = 1, option_ids: number[] = [], comment = '') => act(() => post(`/api/rs/orders/${id}/lines`, { lines: [{ item_id: item.id, quantity: qty, option_ids, comment: comment || null }] }));
  const cats = useMemo(() => [...new Map((menu?.items ?? []).map((i: any) => [i.category_id, i.category])).entries()], [menu]);
  const items = (menu?.items ?? []).filter((i: any) => (!cat || String(i.category_id) === cat) && (!search || i.name.toLowerCase().includes(search.toLowerCase())));
  if (!o) return null;
  const active = o.lines.filter((l: any) => !l.cancelled);
  const pending = active.some((l: any) => l.kitchen_status === 'pending');
  const allReady = active.length > 0 && active.every((l: any) => ['ready', 'served'].includes(l.kitchen_status)) && o.status !== 'served';
  const where = o.table_number ? `${t('rt.table')} ${o.table_number}` : o.room_number ? `${t('common.room')} ${o.room_number}` : t('rt.counter');
  return (
    <Modal size="lg" title={`${o.number} — ${t(`rt.o_${o.outlet}` as Key)} · ${where}`} onClose={onClose}
      footer={<>
        {editable && orderPerm && <button className="btn ghost danger" onClick={() => setModal('cancel')}>{t('rt.cancelOrder')}</button>}
        {editable && orderPerm && o.outlet !== 'room_service' && can('restaurant.order') && <button className="btn ghost" onClick={() => setModal('move')}>{t('rt.move')}</button>}
        {editable && can('restaurant.discount') && active.length > 0 && <button className="btn ghost" onClick={() => setModal('discount')}>{t('rt.discount')}</button>}
        <span style={{ flex: 1 }} />
        {o.status !== 'cancelled' && pending && orderPerm && <button className="btn" disabled={busy} onClick={() => act(() => post(`/api/rs/orders/${id}/confirm`), t('rt.sentMsg'))}>{t('rt.send')}</button>}
        {allReady && (orderPerm || can('roomservice.deliver')) && <button className="btn" disabled={busy} onClick={() => act(() => post(`/api/rs/orders/${id}/serve`), o.outlet === 'room_service' ? t('rt.deliveredMsg') : t('rt.servedMsg'))}>{o.outlet === 'room_service' ? t('rt.delivered') : t('rt.serve')}</button>}
        {editable && can('restaurant.settle') && active.length > 0 && <button className="btn primary" onClick={() => setModal('settle')}>{t('rt.settle')} · {money(Number(o.total), locale)}</button>}
      </>}>
      <div className="row" style={{ gap: 8 }}>
        <StatusPill s={o.status} /><SettlePill s={o.settlement} />
        {o.guest_name && <span>👤 <b>{o.guest_name}</b>{o.reservation_code ? <span className="muted"> · {o.reservation_code}</span> : null}</span>}
        <span className="muted">{o.covers} {t('rt.coversShort')} · {hhmm(o.created_at)} · {o.waiter ?? ''}</span>
        {o.invoice_number && <span className="pill">{o.invoice_number}</span>}
        {o.notes && <span>📝 {o.notes}</span>}
      </div>
      <div className="grid" style={{ gridTemplateColumns: editable && orderPerm ? 'minmax(0, 1.25fr) minmax(0, 1fr)' : '1fr', gap: 14, alignItems: 'start' }}>
        {editable && orderPerm && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div className="row" style={{ gap: 6 }}>
              <button className={`chip ${!cat ? 'on' : ''}`} onClick={() => setCat('')}>{t('common.all')}</button>
              {cats.map(([cid, name]) => <button key={String(cid)} className={`chip ${cat === String(cid) ? 'on' : ''}`} onClick={() => setCat(String(cid))}>{String(name)}</button>)}
              <input className="input" style={{ flex: 1, minWidth: 120 }} placeholder={t('common.search')} aria-label={t('common.search')} value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            {menu?.menus?.length > 0 && <span className="muted" style={{ fontSize: 12 }}>{t('rt.currentMenu')} : {menu.menus.map((m: any) => m.name).join(' · ')}</span>}
            {menu?.outside_hours && <span className="pill prio-high" style={{ alignSelf: 'flex-start' }}>{t('rt.outsideHours')}</span>}
            <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 8, maxHeight: 420, overflow: 'auto' }}>
              {items.map((i: any) => (
                <button key={i.id} className="hk-card clickable" disabled={!i.orderable || busy} style={{ textAlign: 'start', font: 'inherit', color: 'inherit', padding: 10, gap: 4, opacity: i.orderable ? 1 : 0.45 }}
                  onClick={() => (i.options.length ? setPick(i) : add(i))}>
                  {i.photo_id && <img src={`/api/photos/${i.photo_id}`} alt="" style={{ width: '100%', height: 70, objectFit: 'cover', borderRadius: 8 }} />}
                  <b style={{ fontSize: 13.5 }}>{i.name}</b>
                  <span className="muted" style={{ fontSize: 12 }}>{money(i.price, locale)}{i.options.length ? ' +' : ''}</span>
                  {!i.orderable && <span className="pill prio-urgent">{i.unavailable_reason === 'stock' ? t('rt.outOfStock') : t('rt.unavailable')}</span>}
                  {i.orderable && i.portions !== null && i.portions <= 5 && <span className="pill prio-high">{i.portions} {t('rt.left')}</span>}
                </button>
              ))}
            </div>
          </div>
        )}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {!o.lines.length && <span className="muted">{t('rt.emptyOrder')}</span>}
          {o.lines.map((l: any) => (
            <div key={l.id} className="ck" style={{ gridTemplateColumns: '1fr auto', opacity: l.cancelled ? 0.5 : 1, textDecoration: l.cancelled ? 'line-through' : undefined }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <span><b>{l.quantity} ×</b> {l.name} <span className="muted">· {money(Number(l.unit_price) * l.quantity, locale)}</span></span>
                {l.options.length > 0 && <span className="muted" style={{ fontSize: 12 }}>{l.options.map((x: any) => x.name).join(', ')}</span>}
                {l.comment && <span style={{ fontSize: 12, color: '#B45309' }}>⚠ {l.comment}</span>}
                {l.cancelled && <span style={{ fontSize: 12 }} className="muted">{l.cancel_reason}</span>}
              </div>
              <div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                {!l.cancelled && <span className="pill" style={{ background: KITCHEN_ST[l.kitchen_status], color: '#fff' }}>{t(`rt.k_${l.kitchen_status}` as Key)}</span>}
                {editable && orderPerm && !l.cancelled && l.kitchen_status === 'pending' && <>
                  <button className="btn sm ghost" aria-label="−" disabled={l.quantity <= 1 || busy} onClick={() => act(() => patch(`/api/rs/lines/${l.id}`, { quantity: l.quantity - 1 }))}>−</button>
                  <button className="btn sm ghost" aria-label="+" disabled={busy} onClick={() => act(() => patch(`/api/rs/lines/${l.id}`, { quantity: l.quantity + 1 }))}>+</button>
                </>}
                {editable && orderPerm && !l.cancelled && <button className="btn sm ghost danger" aria-label={t('rt.removeLine')} title={t('rt.removeLine')} onClick={() => (l.kitchen_status === 'pending' ? act(() => post(`/api/rs/lines/${l.id}/cancel`, {})) : setCancelLine(l))}>✕</button>}
              </div>
            </div>
          ))}
          <div className="section" style={{ gap: 2 }}>
            <div className="sum-row"><span>{t('rt.subtotal')}</span><span>{money(Number(o.subtotal), locale)}</span></div>
            {Number(o.discount_total) > 0 && <div className="sum-row"><span>{t('rt.discount')} {o.discount_type === 'percent' ? `${Number(o.discount_value)} %` : ''} <span className="muted">({o.discount_reason})</span></span><span>− {money(Number(o.discount_total), locale)}</span></div>}
            <div className="sum-row"><span>{t('rt.tax')}</span><span>{money(Number(o.tax_total), locale)}</span></div>
            <div className="sum-row big"><span>Total</span><span>{money(Number(o.total), locale)}</span></div>
          </div>
          {o.charges.length > 0 && <div className="muted" style={{ fontSize: 12.5 }}>{t('rt.onFolio')} : {o.charges.length} {t('rt.lines')}</div>}
          {o.outlet === 'room_service' && (
            <div className="muted" style={{ fontSize: 12.5 }}>{t('rt.ordered')} {hhmm(o.created_at)} · {t('rt.outAt')} {hhmm(o.out_at) || '—'} · {t('rt.deliveredAt')} {hhmm(o.served_at) || '—'}{o.assignee ? ` · ${o.assignee}` : ''}</div>
          )}
          {o.history.length > 0 && <details><summary className="muted" style={{ cursor: 'pointer' }}>{t('rt.historyLog')} ({o.history.length})</summary>
            {o.history.map((h: any, i: number) => <div key={i} className="muted" style={{ fontSize: 12 }}>{fmtDateTime(h.created_at, locale)} · {h.user_name} · {h.action}</div>)}</details>}
        </div>
      </div>
      {pick && <OptionsModal item={pick} onClose={() => setPick(null)} onAdd={(q, ids, c) => { setPick(null); add(pick, q, ids, c); }} />}
      {modal === 'settle' && <SettleModal order={o} onClose={() => setModal('')} onDone={(r) => { setModal(''); load(); if (r?.stock_alerts?.length) toast('info', `${t('rt.lowStock')} : ${r.stock_alerts.join(' · ')}`); }} />}
      {modal === 'discount' && <DiscountModal order={o} onClose={() => setModal('')} onDone={() => { setModal(''); load(); }} />}
      {modal === 'move' && <MoveModal order={o} onClose={() => setModal('')} onDone={() => { setModal(''); load(); }} />}
      {modal === 'cancel' && <ReasonModal title={`${t('rt.cancelOrder')} — ${o.number}`} onClose={() => setModal('')} onSubmit={(reason) => { setModal(''); act(() => post(`/api/rs/orders/${id}/cancel`, { reason }), t('rt.cancelledMsg')); }} />}
      {cancelLine && <ReasonModal title={`${t('rt.removeLine')} — ${cancelLine.name}`} onClose={() => setCancelLine(null)} onSubmit={(reason) => { const l = cancelLine; setCancelLine(null); act(() => post(`/api/rs/lines/${l.id}/cancel`, { reason })); }} />}
    </Modal>
  );
}

function OptionsModal({ item, onClose, onAdd }: { item: any; onClose: () => void; onAdd: (qty: number, ids: number[], comment: string) => void }) {
  const { t, locale } = useI18n();
  const variants = item.options.filter((o: any) => o.kind === 'variant');
  const sups = item.options.filter((o: any) => o.kind === 'supplement');
  const [v, setV] = useState<number | null>(variants[0]?.id ?? null);
  const [s, setS] = useState<number[]>([]);
  const [qty, setQty] = useState(1);
  const [comment, setComment] = useState('');
  const unit = Number(item.price) + [...(v ? [v] : []), ...s].reduce((a, id) => a + Number(item.options.find((o: any) => o.id === id)?.price_delta ?? 0), 0);
  return (
    <Modal size="sm" title={item.name} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={variants.length > 0 && !v} onClick={() => onAdd(qty, [...(v ? [v] : []), ...s], comment)}>{t('rt.add')} · {money(unit * qty, locale)}</button></>}>
      {item.description && <p className="muted" style={{ margin: 0 }}>{item.description}</p>}
      {item.allergens?.length > 0 && <p style={{ margin: 0, fontSize: 12.5 }}>⚠ {item.allergens.map((a: string) => t(`rt.al_${a}` as Key)).join(', ')}</p>}
      {variants.length > 0 && <Field label={t('rt.variant')}><div className="seg" style={{ flexWrap: 'wrap' }}>{variants.map((o: any) => <button key={o.id} className={v === o.id ? 'on' : ''} onClick={() => setV(o.id)}>{o.name}{Number(o.price_delta) ? ` (+${Number(o.price_delta)})` : ''}</button>)}</div></Field>}
      {sups.length > 0 && <Field label={t('rt.supplements')}><div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>{sups.map((o: any) => <label key={o.id} className="check"><input type="checkbox" checked={s.includes(o.id)} onChange={(e) => setS(e.target.checked ? [...s, o.id] : s.filter((x) => x !== o.id))} />{o.name} (+{Number(o.price_delta)})</label>)}</div></Field>}
      <div className="form-grid">
        <Field label={t('rt.qty')}><input type="number" min={1} max={100} className="input" value={qty} onChange={(e) => setQty(Math.max(1, Math.trunc(Number(e.target.value))))} /></Field>
      </div>
      <Field label={t('rt.instructions')}><input className="input" value={comment} onChange={(e) => setComment(e.target.value)} placeholder={t('rt.instructionsPh')} /></Field>
    </Modal>
  );
}

function SettleModal({ order, onClose, onDone }: { order: any; onClose: () => void; onDone: (r: any) => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('rss'));
  const [mode, setMode] = useState<'pay' | 'room' | 'invoice'>(order.room_id ? 'room' : 'pay');
  const total = Number(order.total);
  const [cash, setCash] = useState(String(total));
  const [card, setCard] = useState('0');
  const [last4, setLast4] = useState('');
  const [given, setGiven] = useState('');
  const [rooms, setRooms] = useState<any[]>([]);
  const [room, setRoom] = useState(order.room_id ? String(order.room_id) : '');
  const [bill, setBill] = useState({ company_name: '', nif: '', address: '' });
  const [busy, setBusy] = useState(false);
  useEffect(() => { get('/api/rs/in-house').then(setRooms).catch(() => {}); }, []);
  const paid = toNum(cash) + toNum(card);
  const ok = mode === 'room' ? !!room : mode === 'invoice' ? bill.company_name.trim().length > 1 : Math.round(paid * 100) === Math.round(total * 100) && (toNum(card) === 0 || /^\d{4}$/.test(last4));
  const save = async () => {
    try {
      setBusy(true);
      const payments = [...(toNum(cash) > 0 ? [{ method: 'cash', amount: toNum(cash) }] : []), ...(toNum(card) > 0 ? [{ method: 'card', amount: toNum(card), card_last4: last4 }] : [])];
      const r = await postOnce(`/api/rs/orders/${order.id}/settle`, mode === 'pay' ? { mode, payments } : mode === 'room' ? { mode, room_id: Number(room) } : { mode, bill_to: { kind: 'company', company_name: bill.company_name, nif: bill.nif || null, address: bill.address || null } }, key);
      toast('success', mode === 'room' ? t('rt.roomMsg') : mode === 'invoice' ? `${t('rt.invoiceMsg')}` : t('rt.paidMsg'));
      onDone(r);
    } catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  return (
    <Modal title={`${t('rt.settle')} — ${order.number}`} onClose={onClose} footer={<><span className="muted">Total <b>{money(total, locale)}</b></span><span style={{ flex: 1 }} /><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!ok || busy} onClick={save}>{t('common.confirm')}</button></>}>
      <div className="seg">{(['pay', 'room', 'invoice'] as const).map((m) => <button key={m} className={mode === m ? 'on' : ''} onClick={() => setMode(m)}>{t(`rt.m_${m}` as Key)}</button>)}</div>
      {mode === 'pay' && (
        <>
          <div className="form-grid">
            <Field label={t('pm.cash')}><input className="input" inputMode="decimal" value={cash} onChange={(e) => { setCash(e.target.value); setCard(String(Math.max(0, Math.round((total - toNum(e.target.value)) * 100) / 100))); }} /></Field>
            <Field label={t('pm.card')}><input className="input" inputMode="decimal" value={card} onChange={(e) => { setCard(e.target.value); setCash(String(Math.max(0, Math.round((total - toNum(e.target.value)) * 100) / 100))); }} /></Field>
            {toNum(card) > 0 && <Field label={t('pay.last4')}><input className="input" maxLength={4} inputMode="numeric" value={last4} onChange={(e) => setLast4(e.target.value.replace(/\D/g, ''))} /></Field>}
            {toNum(cash) > 0 && <Field label={t('rt.given')}><input className="input" inputMode="decimal" value={given} onChange={(e) => setGiven(e.target.value)} /></Field>}
          </div>
          {toNum(given) > toNum(cash) && <div className="alert">{t('rt.change')} : <b>{money(Math.round((toNum(given) - toNum(cash)) * 100) / 100, locale)}</b></div>}
          {Math.round(paid * 100) !== Math.round(total * 100) && <span className="muted" style={{ color: 'var(--danger)' }}>{t('rt.mustEqual')}</span>}
          <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>{t('rt.payHint')}</p>
        </>
      )}
      {mode === 'room' && (
        <>
          <Field label={t('common.room')}><select className="input" value={room} onChange={(e) => setRoom(e.target.value)}><option value="">—</option>{rooms.map((r) => <option key={r.room_id} value={r.room_id}>{r.room} · {r.guest} · {r.code}</option>)}</select></Field>
          <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>{t('rt.roomHint')}</p>
        </>
      )}
      {mode === 'invoice' && (
        <div className="form-grid">
          <Field label={t('rt.company')}><input className="input" value={bill.company_name} onChange={(e) => setBill({ ...bill, company_name: e.target.value })} /></Field>
          <Field label="NIF"><input className="input" value={bill.nif} onChange={(e) => setBill({ ...bill, nif: e.target.value })} /></Field>
          <Field label={t('rt.address')}><input className="input" value={bill.address} onChange={(e) => setBill({ ...bill, address: e.target.value })} /></Field>
        </div>
      )}
    </Modal>
  );
}

function DiscountModal({ order, onClose, onDone }: { order: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [f, setF] = useState({ type: order.discount_type ?? 'percent', value: String(Number(order.discount_value) || ''), reason: order.discount_reason ?? '' });
  const save = async (remove = false) => {
    try { await post(`/api/rs/orders/${order.id}/discount`, remove ? { type: null, value: 0 } : { type: f.type, value: toNum(f.value), reason: f.reason }); onDone(); } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal size="sm" title={t('rt.discount')} onClose={onClose} footer={<>{order.discount_type && <button className="btn ghost danger" onClick={() => save(true)}>{t('rt.removeDiscount')}</button>}<span style={{ flex: 1 }} /><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!toNum(f.value) || f.reason.trim().length < 2} onClick={() => save()}>{t('common.save')}</button></>}>
      <div className="seg"><button className={f.type === 'percent' ? 'on' : ''} onClick={() => setF({ ...f, type: 'percent' })}>%</button><button className={f.type === 'amount' ? 'on' : ''} onClick={() => setF({ ...f, type: 'amount' })}>{currency.symbol}</button></div>
      <Field label={t('rt.value')}><input className="input" inputMode="decimal" value={f.value} onChange={(e) => setF({ ...f, value: e.target.value })} /></Field>
      <Field label={t('rt.reason')}><input className="input" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} /></Field>
    </Modal>
  );
}

function MoveModal({ order, onClose, onDone }: { order: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [tables, setTables] = useState<any[]>([]);
  const [v, setV] = useState('');
  useEffect(() => { get('/api/rs/tables').then(setTables).catch(() => {}); }, []);
  return (
    <Modal size="sm" title={t('rt.move')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!v} onClick={async () => { try { await post(`/api/rs/orders/${order.id}/move`, { table_id: Number(v) }); onDone(); } catch (e: any) { toast('error', e.message); } }}>{t('common.confirm')}</button></>}>
      <Field label={t('rt.toTable')}><select className="input" value={v} onChange={(e) => setV(e.target.value)}><option value="">—</option>{tables.filter((x) => !x.merged_into && x.display !== 'occupied').map((x) => <option key={x.id} value={x.id}>{x.number} · {x.capacity} p.</option>)}</select></Field>
    </Modal>
  );
}

// ===================================================== Plan de salle =====================================================
function Floor({ openOrder }: { openOrder: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [tables, setTables] = useState<any[] | null>(null);
  const [bookings, setBookings] = useState<any[]>([]);
  const [newFor, setNewFor] = useState<any>(null);
  const [merge, setMerge] = useState<number[] | null>(null);
  const [booking, setBooking] = useState<any>(null);
  const load = useCallback(() => {
    get('/api/rs/tables').then(setTables).catch(err(toast));
    get('/api/rs/bookings').then(setBookings).catch(() => {});
  }, []);
  useEffect(load, [load]);
  useLive(load, 15000);
  const act = async (fn: () => Promise<any>, ok?: string) => { try { await fn(); if (ok) toast('success', ok); load(); } catch (e: any) { toast('error', e.message); } };
  if (!tables) return <span>{t('common.loading')}</span>;
  const areas = [...new Set(tables.map((x) => x.area))];
  const click = (x: any) => {
    if (merge) { setMerge(merge.includes(x.id) ? merge.filter((i) => i !== x.id) : [...merge, x.id]); return; }
    if (x.order) openOrder(x.order.id);
    else if (x.merged_into) { const m = tables.find((y) => y.id === x.merged_into); if (m?.order) openOrder(m.order.id); else if (can('restaurant.order')) setNewFor(m); }
    else if (can('restaurant.order')) setNewFor(x);
  };
  return (
    <>
      <div className="row">
        {(['available', 'occupied', 'reserved', 'to_clean'] as const).map((s) => <span key={s} className="chip"><span className="sw" style={{ background: TABLE_COLORS[s] }} />{t(`rt.tb_${s}` as Key)} <b>{tables.filter((x) => !x.merged_into && x.display === s).length}</b></span>)}
        <span style={{ flex: 1 }} />
        {can('restaurant.order') && (merge
          ? <><span className="muted">{t('rt.mergeHint')}</span><button className="btn ghost" onClick={() => setMerge(null)}>{t('common.cancel')}</button>
            <button className="btn primary" disabled={merge.length < 2} onClick={() => act(() => post(`/api/rs/tables/${merge[0]}/merge`, { table_ids: merge.slice(1) }), t('rt.merged')).then(() => setMerge(null))}>{t('rt.merge')} ({merge.length})</button></>
          : <><button className="btn" onClick={() => setMerge([])}>{t('rt.mergeTables')}</button><button className="btn" onClick={() => setBooking({})}><Icon name="planning" />{t('rt.bookTable')}</button></>)}
      </div>
      {areas.map((a) => (
        <div key={a} className="section"><h3>{a}</h3>
          <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 10 }}>
            {tables.filter((x) => x.area === a).map((x) => (
              <button key={x.id} onClick={() => click(x)} className="hk-card clickable"
                style={{ font: 'inherit', color: 'inherit', textAlign: 'start', borderWidth: 2, borderColor: merge?.includes(x.id) ? 'var(--gold)' : TABLE_COLORS[x.display], borderRadius: x.shape === 'round' ? 40 : 14, minHeight: 120 }}>
                <div className="row between"><b style={{ fontSize: 22 }}>{x.number}</b><span className="muted">{x.capacity} p.</span></div>
                <span className="pill" style={{ background: TABLE_COLORS[x.display], color: '#fff', alignSelf: 'flex-start' }}>{t(`rt.tb_${x.display}` as Key)}</span>
                {x.merged_into_number && <span className="muted" style={{ fontSize: 12 }}>⇄ {t('rt.with')} {x.merged_into_number}</span>}
                {x.order && <span style={{ fontSize: 12.5 }}>{x.order.number} · {money(Number(x.order.total), locale)} · {mins(x.order.created_at)} min</span>}
                {x.booking && !x.order && <span style={{ fontSize: 12.5 }}>🕒 {hhmm(x.booking.starts_at)} · {x.booking.guest_name} ({x.booking.party_size})</span>}
                <div className="row" style={{ gap: 4 }} onClick={(e) => e.stopPropagation()}>
                  {can('restaurant.order') && x.display === 'to_clean' && <span role="button" tabIndex={0} className="btn sm" onClick={() => act(() => post(`/api/rs/tables/${x.id}/status`, { status: 'available' }))}>{t('rt.cleaned')}</span>}
                  {can('restaurant.order') && (x.merged_into || tables.some((y) => y.merged_into === x.id)) && <span role="button" tabIndex={0} className="btn sm ghost" onClick={() => act(() => post(`/api/rs/tables/${x.id}/split`), t('rt.splitDone'))}>{t('rt.split')}</span>}
                </div>
              </button>
            ))}
          </div>
        </div>
      ))}
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('rt.bookingsToday')}</h3>
        <table className="table">
          <thead><tr><th>{t('rt.time')}</th><th>{t('rt.table')}</th><th>{t('rt.guest')}</th><th className="num">{t('rt.covers')}</th><th>{t('rt.phone')}</th><th>{t('rt.status')}</th><th /></tr></thead>
          <tbody>
            {!bookings.length && <tr><td colSpan={7} className="muted">{t('common.none')}</td></tr>}
            {bookings.map((b) => (
              <tr key={b.id}><td>{hhmm(b.starts_at)}</td><td>{b.table_number}</td><td>{b.guest_name}{b.room_number ? ` · ${t('common.room')} ${b.room_number}` : ''}</td><td className="num">{b.party_size}</td><td>{b.phone ?? ''}</td><td>{t(`rt.b_${b.status}` as Key)}</td>
                <td className="pin-end">{b.status === 'booked' && can('restaurant.order') && <div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                  <button className="btn sm" onClick={() => act(() => post(`/api/rs/bookings/${b.id}/status`, { status: 'seated' })).then(() => { const tb = tables.find((x) => x.id === b.table_id); if (tb && !tb.order) setNewFor({ ...tb, covers: b.party_size, guest: b.guest_name }); })}>{t('rt.seat')}</button>
                  <button className="btn sm ghost" onClick={() => act(() => post(`/api/rs/bookings/${b.id}/status`, { status: 'no_show' }))}>{t('rt.noShow')}</button>
                  <button className="btn sm ghost danger" onClick={() => act(() => post(`/api/rs/bookings/${b.id}/status`, { status: 'cancelled' }))}>✕</button>
                </div>}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
      {newFor && <NewOrderModal preset={{ outlet: 'restaurant', table_id: newFor.id }} onClose={() => setNewFor(null)} onDone={(id) => { setNewFor(null); load(); openOrder(id); }} />}
      {booking && <BookingModal tables={tables.filter((x) => !x.merged_into)} onClose={() => setBooking(null)} onDone={() => { setBooking(null); load(); }} />}
    </>
  );
}

function BookingModal({ tables, onClose, onDone }: { tables: any[]; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [rooms, setRooms] = useState<any[]>([]);
  const [f, setF] = useState({ table_id: '', guest_name: '', phone: '', room_id: '', party_size: 2, date: todayLocal(), time: '20:00', duration_min: 90, notes: '' });
  useEffect(() => { get('/api/rs/in-house').then(setRooms).catch(() => {}); }, []);
  const save = async () => {
    try {
      await post('/api/rs/bookings', { table_id: Number(f.table_id), guest_name: f.guest_name, phone: f.phone || null, room_id: f.room_id ? Number(f.room_id) : null, party_size: f.party_size,
        starts_at: new Date(`${f.date}T${f.time}:00`).toISOString(), duration_min: f.duration_min, notes: f.notes || null });
      toast('success', t('rt.booked'));
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={t('rt.bookTable')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!f.table_id || f.guest_name.trim().length < 2} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('rt.table')}><select className="input" value={f.table_id} onChange={(e) => setF({ ...f, table_id: e.target.value })}><option value="">—</option>{tables.map((x) => <option key={x.id} value={x.id}>{x.number} · {x.capacity} p.</option>)}</select></Field>
        <Field label={t('rt.date')}><input type="date" className="input" min={todayLocal()} value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} /></Field>
        <Field label={t('rt.time')}><input type="time" className="input" value={f.time} onChange={(e) => setF({ ...f, time: e.target.value })} /></Field>
        <Field label={t('rt.covers')}><input type="number" min={1} max={60} className="input" value={f.party_size} onChange={(e) => setF({ ...f, party_size: Math.max(1, Number(e.target.value)) })} /></Field>
        <Field label={t('rt.guest')}><input className="input" value={f.guest_name} onChange={(e) => setF({ ...f, guest_name: e.target.value })} /></Field>
        <Field label={t('rt.phone')}><input className="input" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
        <Field label={`${t('common.room')} (${t('rt.optional')})`}><select className="input" value={f.room_id} onChange={(e) => { const r = rooms.find((x) => String(x.room_id) === e.target.value); setF({ ...f, room_id: e.target.value, guest_name: r ? r.guest : f.guest_name }); }}><option value="">—</option>{rooms.map((r) => <option key={r.room_id} value={r.room_id}>{r.room} · {r.guest}</option>)}</select></Field>
        <Field label={t('rt.duration')}><input type="number" min={15} max={480} step={15} className="input" value={f.duration_min} onChange={(e) => setF({ ...f, duration_min: Number(e.target.value) })} /></Field>
      </div>
    </Modal>
  );
}

// ===================================================== Cuisine (KDS) =====================================================
function Kitchen() {
  const { t } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const both = can('restaurant.kitchen') && can('restaurant.bar');
  const [station, setStation] = useState<string>(both ? '' : can('restaurant.kitchen') ? 'kitchen' : 'bar');
  const [kind, setKind] = useState('');
  const [rows, setRows] = useState<any[] | null>(null);
  const [, tick] = useState(0);
  const load = useCallback(() => {
    const qs = new URLSearchParams();
    if (station) qs.set('station', station);
    if (kind) qs.set('kind', kind);
    get(`/api/rs/kitchen?${qs}`).then(setRows).catch(err(toast));
  }, [station, kind]);
  useEffect(load, [load]);
  useLive(load, 8000);
  useEffect(() => { const h = setInterval(() => tick((x) => x + 1), 30000); return () => clearInterval(h); }, []);
  const act = async (id: number, action: 'start' | 'ready', st: string | null) => { try { await post(`/api/rs/orders/${id}/kitchen`, { action, station: st }); load(); } catch (e: any) { toast('error', e.message); } };
  const stations = both ? ['', 'kitchen', 'pastry', 'bar'] : can('restaurant.kitchen') ? ['kitchen', 'pastry'] : ['bar'];
  return (
    <>
      <div className="row">
        <div className="seg">{stations.map((s) => <button key={s} className={station === s ? 'on' : ''} onClick={() => setStation(s)}>{s ? t(`rt.ks_${s}` as Key) : t('common.all')}</button>)}</div>
        <select className="input" style={{ width: 'auto' }} aria-label={t('rt.category')} value={kind} onChange={(e) => setKind(e.target.value)}>
          <option value="">{t('rt.allKinds')}</option>{['starter', 'main', 'dessert', 'drink', 'breakfast'].map((k) => <option key={k} value={k}>{t(`rt.c_${k}` as Key)}</option>)}
        </select>
        <span className="muted">{rows?.length ?? 0} {t('rt.inQueue')}</span>
      </div>
      {rows && !rows.length && <div className="card muted" style={{ textAlign: 'center', padding: 40 }}>{t('rt.kitchenEmpty')}</div>}
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12, alignItems: 'start' }}>
        {(rows ?? []).map((o) => {
          const w = mins(o.confirmed_at ?? o.created_at) ?? 0;
          const color = w >= 25 ? '#B91C1C' : w >= 15 ? '#D97706' : '#15803D';
          const st = station || null;
          const anySent = o.lines.some((l: any) => l.kitchen_status === 'sent');
          const anyTodo = o.lines.some((l: any) => ['sent', 'preparing'].includes(l.kitchen_status));
          const allowed = (s: string | null) => (s === 'bar' ? can('restaurant.bar') : s ? can('restaurant.kitchen') : both);
          return (
            <div key={o.id} className="card" style={{ padding: 0, borderTop: `6px solid ${color}`, display: 'flex', flexDirection: 'column' }}>
              <div className="row between" style={{ padding: '10px 12px', background: 'var(--surface2)' }}>
                <div><b style={{ fontSize: 18 }}>{o.table_number ? `${t('rt.table')} ${o.table_number}` : o.room_number ? `🛎 ${t('common.room')} ${o.room_number}` : t(`rt.o_${o.outlet}` as Key)}</b>
                  <div className="muted" style={{ fontSize: 12 }}>{o.number} · {o.waiter ?? ''} · {o.covers} {t('rt.coversShort')}</div></div>
                <div style={{ textAlign: 'end' }}><b style={{ fontSize: 20, color }}>{w} min</b>{o.priority !== 'normal' && <div><span className="pill prio-urgent">{t(`rt.p_${o.priority}` as Key)}</span></div>}</div>
              </div>
              <div style={{ padding: '8px 12px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                {o.notes && <div style={{ fontSize: 13, color: '#B45309' }}>📝 {o.notes}</div>}
                {o.lines.map((l: any) => (
                  <div key={l.id} style={{ display: 'flex', gap: 8, alignItems: 'flex-start', opacity: l.kitchen_status === 'ready' ? 0.55 : 1 }}>
                    <b style={{ fontSize: 18, minWidth: 30 }}>{l.quantity}×</b>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 15, fontWeight: 600, textDecoration: l.kitchen_status === 'ready' ? 'line-through' : undefined }}>{l.name}</div>
                      {l.options.length > 0 && <div style={{ fontSize: 12.5 }}>{l.options.map((x: any) => x.name).join(', ')}</div>}
                      {l.comment && <div style={{ fontSize: 13, color: '#B91C1C', fontWeight: 600 }}>⚠ {l.comment}</div>}
                    </div>
                    <span className="pill" style={{ background: KITCHEN_ST[l.kitchen_status], color: '#fff' }}>{t(`rt.k_${l.kitchen_status}` as Key)}</span>
                  </div>
                ))}
                {o.cancelled.length > 0 && <div style={{ fontSize: 12.5, color: 'var(--danger)' }}>✕ {t('rt.cancelledLines')} : {o.cancelled.map((c: any) => `${c.quantity}× ${c.name}`).join(', ')}</div>}
              </div>
              {allowed(st) && anyTodo && (
                <div className="row" style={{ padding: '0 12px 12px', gap: 6 }}>
                  {anySent && <button className="btn" style={{ flex: 1 }} onClick={() => act(o.id, 'start', st)}>{t('rt.startPrep')}</button>}
                  <button className="btn primary" style={{ flex: 1 }} onClick={() => act(o.id, 'ready', st)}>{t('rt.markReady')}</button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </>
  );
}

// ===================================================== Room service =====================================================
function RoomService({ openOrder }: { openOrder: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [rooms, setRooms] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [staff, setStaff] = useState<any[]>([]);
  const [newFor, setNewFor] = useState<any>(null);
  const load = useCallback(() => {
    get('/api/rs/in-house').then(setRooms).catch(err(toast));
    get('/api/rs/orders?outlet=room_service&open=1').then(setOrders).catch(() => {});
  }, []);
  useEffect(() => { load(); get('/api/rs/staff').then(setStaff).catch(() => {}); }, [load]);
  useLive(load, 15000);
  const act = async (fn: () => Promise<any>, ok?: string) => { try { await fn(); if (ok) toast('success', ok); load(); } catch (e: any) { toast('error', e.message); } };
  return (
    <>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('rt.rsInProgress')} ({orders.length})</h3>
        <table className="table">
          <thead><tr><th>N°</th><th>{t('common.room')}</th><th>{t('rt.guest')}</th><th>{t('rt.ordered')}</th><th>{t('rt.status')}</th><th>{t('rt.deliverer')}</th><th>{t('rt.outAt')}</th><th className="num">Total</th><th /></tr></thead>
          <tbody>
            {!orders.length && <tr><td colSpan={9} className="muted">{t('common.none')}</td></tr>}
            {orders.map((o) => (
              <tr key={o.id}>
                <td><button className="link" onClick={() => openOrder(o.id)}>{o.number}</button></td><td><b>{o.room_number}</b></td><td>{o.guest_name}</td>
                <td>{hhmm(o.created_at)} · {mins(o.created_at)} min</td><td><StatusPill s={o.status} /></td>
                <td>{can('restaurant.order') || can('roomservice.deliver')
                  ? <select className="input" style={{ width: 'auto', padding: '3px 6px' }} aria-label={t('rt.deliverer')} value={o.assigned_to ?? ''} onChange={(e) => act(() => post(`/api/rs/orders/${o.id}/room-service`, { action: 'assign', user_id: e.target.value ? Number(e.target.value) : null }))}>
                      <option value="">—</option>{staff.map((s) => <option key={s.id} value={s.id}>{s.full_name}</option>)}</select> : o.assignee ?? '—'}</td>
                <td>{hhmm(o.out_at) || '—'}</td><td className="num">{money(Number(o.total), locale)}</td>
                <td className="pin-end"><div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                  {o.status === 'new' && <button className="btn sm" onClick={() => act(() => post(`/api/rs/orders/${o.id}/confirm`), t('rt.sentMsg'))}>{t('rt.send')}</button>}
                  {o.status === 'ready' && !o.out_at && <button className="btn sm" onClick={() => act(() => post(`/api/rs/orders/${o.id}/room-service`, { action: 'out' }))}>{t('rt.goDeliver')}</button>}
                  {o.status === 'ready' && <button className="btn sm primary" onClick={() => act(() => post(`/api/rs/orders/${o.id}/serve`), t('rt.deliveredMsg'))}>{t('rt.delivered')}</button>}
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h3 style={{ margin: 0 }}>{t('rt.inHouse')} ({rooms.length})</h3>
      <div className="hk-grid">
        {rooms.map((r) => (
          <div key={r.room_id} className="hk-card">
            <div className="row between"><b style={{ fontSize: 20 }}>{r.room}</b>{r.vip && <span className="pill" style={{ background: 'var(--gold)', color: '#24252A' }}>VIP</span>}</div>
            <span>{r.guest}</span>
            <span className="muted" style={{ fontSize: 12 }}>{r.code} · {r.meal_plan} · {r.adults + r.children} p.</span>
            {r.dnd && <span className="pill" style={{ background: '#BE185D', color: '#fff', alignSelf: 'flex-start' }}>{t('hk.dnd')}</span>}
            {r.has_open && <span className="pill prio-high" style={{ alignSelf: 'flex-start' }}>{t('rt.rsOpen')}</span>}
            {can('restaurant.order') && <button className="btn sm primary" style={{ alignSelf: 'flex-start' }} onClick={() => setNewFor(r)}>🛎 {t('rt.orderRoom')}</button>}
          </div>
        ))}
      </div>
      {newFor && <NewOrderModal preset={{ outlet: 'room_service', room_id: newFor.room_id }} onClose={() => setNewFor(null)} onDone={(id) => { setNewFor(null); load(); openOrder(id); }} />}
    </>
  );
}

// ===================================================== Petit-déjeuner =====================================================
function Breakfast() {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [date, setDate] = useState(todayLocal());
  const [d, setD] = useState<any>(null);
  const [search, setSearch] = useState('');
  const [rec, setRec] = useState<any>(null);
  const load = useCallback(() => { get(`/api/rs/breakfast?date=${date}`).then(setD).catch(err(toast)); }, [date]);
  useEffect(load, [load]);
  useLive(load, 20000);
  if (!d) return <span>{t('common.loading')}</span>;
  const quick = async (r: any) => { try { await post('/api/rs/breakfast', { rr_id: r.rr_id, included: r.remaining, extra: 0, date }); toast('success', `${t('common.room')} ${r.room} : ${r.remaining} ${t('rt.bfDone')}`); load(); } catch (e: any) { toast('error', e.message); } };
  const rows = d.rows.filter((r: any) => !search || `${r.room} ${r.guest}`.toLowerCase().includes(search.toLowerCase()));
  return (
    <>
      <div className="row">
        <input type="date" className="input" style={{ width: 160 }} aria-label="Date" max={todayLocal()} value={date} onChange={(e) => e.target.value && setDate(e.target.value)} />
        <span className="muted">🕒 {d.hours.start} – {d.hours.end}{d.extra_price !== null ? ` · ${t('rt.bfExtraPrice')} ${money(d.extra_price, locale)}` : ''}</span>
        <input className="input" style={{ width: 200 }} placeholder={t('common.search')} aria-label={t('common.search')} value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      <div className="grid kpis">
        <div className="card kpi"><span className="label">{t('rt.bfEntitled')}</span><span className="value">{d.totals.entitled}</span></div>
        <div className="card kpi"><span className="label">{t('rt.bfUsed')}</span><span className="value">{d.totals.used}</span></div>
        <div className="card kpi"><span className="label">{t('rt.bfRemaining')}</span><span className="value">{d.totals.entitled - d.totals.used}</span></div>
        <div className="card kpi"><span className="label">{t('rt.bfExtra')}</span><span className="value">{d.totals.extra}</span></div>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('common.room')}</th><th>{t('rt.guest')}</th><th>{t('rt.plan')}</th><th className="num">{t('rt.bfEntitled')}</th><th className="num">{t('rt.bfUsed')}</th><th className="num">{t('rt.bfExtra')}</th><th /></tr></thead>
          <tbody>
            {!rows.length && <tr><td colSpan={7} className="muted">{t('common.none')}</td></tr>}
            {rows.map((r: any) => (
              <tr key={r.rr_id} style={r.entitled && r.remaining === 0 ? { background: 'var(--ok-bg)' } : {}}>
                <td><b>{r.room}</b></td><td>{r.guest}{r.vip ? ' ⭐' : ''}</td><td>{r.meal_plan}</td><td className="num">{r.entitled}</td><td className="num">{r.used}</td><td className="num">{r.extra}</td>
                <td className="pin-end"><div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                  {r.remaining > 0 && <button className="btn sm primary" onClick={() => quick(r)}>✓ {r.remaining} {t('rt.included')}</button>}
                  <button className="btn sm" onClick={() => setRec(r)}>{t('rt.bfRecord')}</button>
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {d.log.length > 0 && <details className="card"><summary style={{ cursor: 'pointer', fontWeight: 600 }}>{t('rt.bfLog')} ({d.log.length})</summary>
        {d.log.map((l: any) => <div key={l.id} className="muted" style={{ fontSize: 12.5 }}>{hhmm(l.created_at)} · {t('common.room')} {l.room} · {l.included} {t('rt.included')} + {l.extra} {t('rt.paid')}{l.late ? ` · ${t('rt.late')}` : ''} · {l.recorded_by_name}</div>)}</details>}
      {rec && <BreakfastModal row={rec} date={date} onClose={() => setRec(null)} onDone={() => { setRec(null); load(); }} />}
    </>
  );
}
function BreakfastModal({ row, date, onClose, onDone }: { row: any; date: string; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('bf'));
  const [inc, setInc] = useState(row.remaining);
  const [extra, setExtra] = useState(0);
  return (
    <Modal size="sm" title={`${t('rt.bfRecord')} — ${t('common.room')} ${row.room}`} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={inc + extra === 0} onClick={async () => {
      try { const r = await postOnce('/api/rs/breakfast', { rr_id: row.rr_id, included: inc, extra, date }, key); if (r.late) toast('info', t('rt.lateMsg')); onDone(); } catch (e: any) { toast('error', e.message); }
    }}>{t('common.save')}</button></>}>
      <p style={{ margin: 0 }}>{row.guest} · {row.meal_plan} · {t('rt.bfRemaining')} : <b>{row.remaining}</b></p>
      <div className="form-grid">
        <Field label={t('rt.included')}><input type="number" min={0} max={row.remaining} className="input" value={inc} onChange={(e) => setInc(Math.max(0, Math.min(row.remaining, Math.trunc(Number(e.target.value)))))} /></Field>
        <Field label={t('rt.bfExtra')}><input type="number" min={0} max={30} className="input" value={extra} onChange={(e) => setExtra(Math.max(0, Math.trunc(Number(e.target.value))))} /></Field>
      </div>
      {extra > 0 && <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>{t('rt.bfExtraHint')}</p>}
    </Modal>
  );
}

// ===================================================== Bar =====================================================
function Bar({ openOrder }: { openOrder: (id: number) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [key, setKey] = useState(() => newOpKey('bar'));
  const load = useCallback(() => {
    get('/api/stock/products').then((p) => setProducts(p.filter((x: any) => /boisson|bar|drink/i.test(x.category)))).catch(() => {});
    get('/api/rs/orders?outlet=bar&open=1').then(setOrders).catch(err(toast));
  }, []);
  useEffect(load, [load]);
  useLive(load, 15000);
  const counter = async () => {
    try { const o = await postOnce('/api/rs/orders', { outlet: 'bar', covers: 1 }, key); setKey(newOpKey('bar')); openOrder(o.id); load(); } catch (e: any) { toast('error', e.message); }
  };
  return (
    <>
      <div className="row">
        <button className="btn primary" onClick={counter}><Icon name="plus" />{t('rt.counterSale')}</button>
        <span className="muted">{t('rt.barHint')}</span>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{t('rt.barOrders')} ({orders.length})</h3>
        <table className="table">
          <thead><tr><th>N°</th><th>{t('rt.where')}</th><th>{t('rt.time')}</th><th className="num">Total</th><th>{t('rt.status')}</th><th>{t('rt.settlement')}</th></tr></thead>
          <tbody>
            {!orders.length && <tr><td colSpan={6} className="muted">{t('common.none')}</td></tr>}
            {orders.map((o) => <tr key={o.id} style={{ cursor: 'pointer' }} onClick={() => openOrder(o.id)}><td><b>{o.number}</b></td><td>{o.table_number ? `${t('rt.table')} ${o.table_number}` : o.room_number ? `${t('common.room')} ${o.room_number}` : t('rt.counter')}</td>
              <td>{hhmm(o.created_at)}</td><td className="num">{money(Number(o.total), locale)}</td><td><StatusPill s={o.status} /></td><td><SettlePill s={o.settlement} /></td></tr>)}
          </tbody>
        </table>
      </div>
      {(can('stock.view') || can('stock.manage')) && (
        <div className="card" style={{ padding: 0, overflow: 'auto' }}>
          <h3 style={{ padding: '12px 14px 0' }}>{t('rt.drinksStock')}</h3>
          <table className="table">
            <thead><tr><th>{t('rt.product')}</th><th className="num">{t('rt.stock')}</th><th className="num">{t('rt.min')}</th><th>{t('rt.usedIn')}</th></tr></thead>
            <tbody>
              {!products.length && <tr><td colSpan={4} className="muted">{t('common.none')}</td></tr>}
              {products.map((p) => <tr key={p.id}><td>{p.name}</td><td className="num" style={p.low ? { color: 'var(--danger)', fontWeight: 700 } : {}}>{Number(p.stock_qty)} {p.unit}</td><td className="num muted">{Number(p.min_stock)}</td><td className="muted wrap">{p.used_in ?? ''}</td></tr>)}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}

// ===================================================== Carte & menus =====================================================
function MenuAdmin() {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [items, setItems] = useState<any[] | null>(null);
  const [cats, setCats] = useState<any[]>([]);
  const [menus, setMenus] = useState<any[]>([]);
  const [edit, setEdit] = useState<any>(null);
  const [menuEdit, setMenuEdit] = useState<any>(null);
  const [cat, setCat] = useState('');
  const load = useCallback(() => {
    get('/api/rs/items?all=1').then(setItems).catch(err(toast));
    get('/api/rs/categories').then(setCats).catch(() => {});
    get('/api/rs/menus').then(setMenus).catch(() => {});
  }, []);
  useEffect(load, [load]);
  const act = async (fn: () => Promise<any>) => { try { await fn(); load(); } catch (e: any) { toast('error', e.message); } };
  if (!items) return <span>{t('common.loading')}</span>;
  const list = items.filter((i) => !cat || String(i.category_id) === cat);
  return (
    <>
      <div className="row">
        <button className={`chip ${!cat ? 'on' : ''}`} onClick={() => setCat('')}>{t('common.all')} <b>{items.length}</b></button>
        {cats.map((c) => <button key={c.id} className={`chip ${cat === String(c.id) ? 'on' : ''}`} onClick={() => setCat(String(c.id))}>{c.name} <b>{items.filter((i) => i.category_id === c.id).length}</b></button>)}
        <span style={{ flex: 1 }} />
        <button className="btn primary" onClick={() => setEdit({})}><Icon name="plus" />{t('rt.newItem')}</button>
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th /><th>{t('rt.dish')}</th><th>{t('rt.category')}</th><th className="num">{t('rt.price')}</th><th>{t('rt.optionsCol')}</th><th>{t('rt.allergens')}</th><th>{t('rt.stockCol')}</th><th>{t('rt.available')}</th><th /></tr></thead>
          <tbody>
            {list.map((i) => (
              <tr key={i.id} style={{ opacity: i.active ? 1 : 0.5 }}>
                <td>{i.photo_id ? <img src={`/api/photos/${i.photo_id}`} alt="" style={{ width: 44, height: 44, objectFit: 'cover', borderRadius: 8 }} /> : null}</td>
                <td><b>{i.name}</b>{i.description && <div className="muted" style={{ fontSize: 12, maxWidth: 260 }}>{i.description}</div>}</td>
                <td>{i.category}</td><td className="num">{money(i.price, locale)}</td>
                <td className="muted" style={{ fontSize: 12 }}>{i.options.filter((o: any) => o.active).map((o: any) => o.name).join(', ')}</td>
                <td style={{ fontSize: 12 }}>{i.allergens.map((a: string) => t(`rt.al_${a}` as Key)).join(', ')}</td>
                <td style={{ fontSize: 12 }}>{i.portions === null ? '—' : <span style={i.portions < 1 ? { color: 'var(--danger)', fontWeight: 700 } : {}}>{i.portions} {t('rt.portions')}</span>}</td>
                <td><label className="check"><input type="checkbox" checked={i.available} disabled={!i.active} onChange={(e) => act(() => patch(`/api/rs/items/${i.id}`, { available: e.target.checked }))} />{i.available ? t('rt.yes') : t('rt.unavailable')}</label></td>
                <td className="pin-end"><div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                  <button className="btn sm" onClick={() => setEdit(i)}>{t('rt.edit')}</button>
                  <button className="btn sm ghost" onClick={() => act(() => patch(`/api/rs/items/${i.id}`, { active: !i.active }))}>{i.active ? t('rt.deactivate') : t('rt.reactivate')}</button>
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="row"><h3 style={{ margin: 0, marginInlineEnd: 'auto' }}>{t('rt.menus')}</h3><button className="btn" onClick={() => setMenuEdit({})}><Icon name="plus" />{t('rt.newMenu')}</button></div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('rt.menu')}</th><th>{t('rt.outletsCol')}</th><th>{t('rt.hours')}</th><th>{t('rt.days')}</th><th>{t('rt.dailyMenu')}</th><th className="num">{t('rt.dishes')}</th><th /></tr></thead>
          <tbody>
            {!menus.length && <tr><td colSpan={7} className="muted">{t('rt.noMenus')}</td></tr>}
            {menus.map((m) => (
              <tr key={m.id} style={{ opacity: m.active ? 1 : 0.5 }}><td><b>{m.name}</b>{m.set_price ? <span className="muted"> · {money(Number(m.set_price), locale)}</span> : null}</td>
                <td>{m.outlets.map((o: string) => t(`rt.o_${o}` as Key)).join(', ')}</td><td>{m.start_time.slice(0, 5)} – {m.end_time.slice(0, 5)}</td>
                <td style={{ fontSize: 12 }}>{m.days.length === 7 ? t('rt.everyDay') : m.days.map((d: number) => t(`rt.d_${d}` as Key)).join(' ')}</td>
                <td>{m.menu_date ? fmtDate(m.menu_date, locale) : '—'}</td><td className="num">{m.item_ids.length}</td>
                <td className="pin-end"><button className="btn sm" onClick={() => setMenuEdit(m)}>{t('rt.edit')}</button></td></tr>
            ))}
          </tbody>
        </table>
      </div>
      {edit && <ItemModal item={edit.id ? edit : null} cats={cats} onClose={() => setEdit(null)} onDone={() => { setEdit(null); load(); }} />}
      {menuEdit && <MenuModal menu={menuEdit.id ? menuEdit : null} items={items.filter((i) => i.active)} onClose={() => setMenuEdit(null)} onDone={() => { setMenuEdit(null); load(); }} />}
    </>
  );
}

function ItemModal({ item, cats, onClose, onDone }: { item: any; cats: any[]; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [products, setProducts] = useState<any[]>([]);
  const [f, setF] = useState({ category_id: String(item?.category_id ?? cats[0]?.id ?? ''), name: item?.name ?? '', description: item?.description ?? '', price: String(item?.price ?? ''), station: item?.station ?? '',
    prep_minutes: item?.prep_minutes ?? 10, ingredients: item?.ingredients ?? '', allergens: (item?.allergens ?? []) as string[] });
  const [opts, setOpts] = useState<any[]>((item?.options ?? []).filter((o: any) => o.active).map((o: any) => ({ id: o.id, kind: o.kind, name: o.name, price_delta: String(Number(o.price_delta)) })));
  const [recipe, setRecipe] = useState<any[]>((item?.recipe ?? []).map((r: any) => ({ product_id: String(r.product_id), quantity: String(Number(r.quantity)) })));
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { get('/api/stock/products').then(setProducts).catch(() => {}); }, []);
  const save = async () => {
    try {
      setBusy(true);
      const body = { category_id: Number(f.category_id), name: f.name, description: f.description || null, price: toNum(f.price), station: f.station || null, prep_minutes: Number(f.prep_minutes), ingredients: f.ingredients || null, allergens: f.allergens };
      const it = item ? await patch(`/api/rs/items/${item.id}`, body) : await post('/api/rs/items', body);
      await api('PUT', `/api/rs/items/${it.id}/options`, { options: opts.filter((o) => o.name.trim()).map((o) => ({ ...(o.id ? { id: o.id } : {}), kind: o.kind, name: o.name, price_delta: toNum(o.price_delta) })) });
      await api('PUT', `/api/rs/items/${it.id}/recipe`, { lines: recipe.filter((r) => r.product_id && toNum(r.quantity) > 0).map((r) => ({ product_id: Number(r.product_id), quantity: toNum(r.quantity) })) });
      if (file) await upload('/api/photos', file, { owner_type: 'menu_item', owner_id: String(it.id) });
      toast('success', t('rt.saved'));
      onDone();
    } catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  return (
    <Modal size="lg" title={item ? `${t('rt.edit')} — ${item.name}` : t('rt.newItem')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={busy || f.name.trim().length < 2 || !f.category_id || f.price === ''} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('rt.dish')}><input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label={t('rt.category')}><select className="input" value={f.category_id} onChange={(e) => setF({ ...f, category_id: e.target.value })}>{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
        <Field label={`${t('rt.price')} (HT)`}><input className="input" inputMode="decimal" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} /></Field>
        <Field label={t('rt.station')}><select className="input" value={f.station} onChange={(e) => setF({ ...f, station: e.target.value })}><option value="">{t('rt.fromCategory')}</option>{['kitchen', 'pastry', 'bar', 'none'].map((s) => <option key={s} value={s}>{t(`rt.ks_${s}` as Key)}</option>)}</select></Field>
        <Field label={t('rt.prepMin')}><input type="number" min={0} max={240} className="input" value={f.prep_minutes} onChange={(e) => setF({ ...f, prep_minutes: Number(e.target.value) })} /></Field>
        <Field label={t('rt.photo')}><input type="file" accept="image/jpeg,image/png,image/webp" className="input" onChange={(e) => setFile(e.target.files?.[0] ?? null)} /></Field>
      </div>
      <Field label={t('rt.description')}><textarea className="input" rows={2} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
      <Field label={t('rt.ingredients')}><input className="input" value={f.ingredients} onChange={(e) => setF({ ...f, ingredients: e.target.value })} /></Field>
      <Field label={t('rt.allergens')}><div className="row" style={{ gap: 6 }}>{ALLERGENS.map((a) => <label key={a} className="check" style={{ fontSize: 13 }}><input type="checkbox" checked={f.allergens.includes(a)} onChange={(e) => setF({ ...f, allergens: e.target.checked ? [...f.allergens, a] : f.allergens.filter((x) => x !== a) })} />{t(`rt.al_${a}` as Key)}</label>)}</div></Field>
      <div className="section"><h3>{t('rt.variantsSupps')}</h3>
        {opts.map((o, i) => (
          <div key={i} className="row" style={{ gap: 6 }}>
            <select className="input" style={{ width: 'auto' }} aria-label={t('rt.optionsCol')} value={o.kind} onChange={(e) => setOpts(opts.map((x, j) => (j === i ? { ...x, kind: e.target.value } : x)))}><option value="variant">{t('rt.variant')}</option><option value="supplement">{t('rt.supplement')}</option></select>
            <input className="input" style={{ flex: 1 }} aria-label="Nom" value={o.name} onChange={(e) => setOpts(opts.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} />
            <input className="input" style={{ width: 110 }} inputMode="decimal" aria-label="+ DA" value={o.price_delta} onChange={(e) => setOpts(opts.map((x, j) => (j === i ? { ...x, price_delta: e.target.value } : x)))} />
            <button className="btn sm ghost danger" onClick={() => setOpts(opts.filter((_, j) => j !== i))}>✕</button>
          </div>
        ))}
        <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setOpts([...opts, { kind: 'supplement', name: '', price_delta: '0' }])}><Icon name="plus" />{t('rt.addOption')}</button>
      </div>
      <div className="section"><h3>{t('rt.recipe')}</h3>
        <p className="muted" style={{ margin: 0, fontSize: 12.5 }}>{t('rt.recipeHint')}</p>
        {recipe.map((r, i) => (
          <div key={i} className="row" style={{ gap: 6 }}>
            <select className="input" style={{ flex: 1 }} aria-label={t('rt.product')} value={r.product_id} onChange={(e) => setRecipe(recipe.map((x, j) => (j === i ? { ...x, product_id: e.target.value } : x)))}><option value="">—</option>{products.filter((p) => p.active).map((p) => <option key={p.id} value={p.id}>{p.name} ({p.unit})</option>)}</select>
            <input className="input" style={{ width: 110 }} inputMode="decimal" aria-label={t('rt.qty')} value={r.quantity} onChange={(e) => setRecipe(recipe.map((x, j) => (j === i ? { ...x, quantity: e.target.value } : x)))} />
            <button className="btn sm ghost danger" onClick={() => setRecipe(recipe.filter((_, j) => j !== i))}>✕</button>
          </div>
        ))}
        <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setRecipe([...recipe, { product_id: '', quantity: '1' }])}><Icon name="plus" />{t('rt.addIngredient')}</button>
      </div>
    </Modal>
  );
}

function MenuModal({ menu, items, onClose, onDone }: { menu: any; items: any[]; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [f, setF] = useState({ name: menu?.name ?? '', outlets: (menu?.outlets ?? ['restaurant']) as string[], days: (menu?.days ?? [0, 1, 2, 3, 4, 5, 6]) as number[], start_time: menu?.start_time?.slice(0, 5) ?? '12:00',
    end_time: menu?.end_time?.slice(0, 5) ?? '15:00', menu_date: menu?.menu_date?.slice(0, 10) ?? '', set_price: menu?.set_price ? String(Number(menu.set_price)) : '', active: menu?.active ?? true, item_ids: (menu?.item_ids ?? []) as number[] });
  const groups = useMemo(() => { const g: Record<string, any[]> = {}; items.forEach((i) => (g[i.category] ||= []).push(i)); return g; }, [items]);
  const toggle = <T,>(arr: T[], v: T) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);
  const save = async () => {
    try {
      const body = { ...f, menu_date: f.menu_date || null, set_price: f.set_price ? toNum(f.set_price) : null };
      if (menu) await api('PUT', `/api/rs/menus/${menu.id}`, body); else await post('/api/rs/menus', body);
      onDone();
    } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal size="lg" title={menu ? menu.name : t('rt.newMenu')} onClose={onClose} footer={<><label className="check" style={{ marginInlineEnd: 'auto' }}><input type="checkbox" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} />{t('rt.active')}</label><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={f.name.trim().length < 2 || !f.outlets.length || !f.days.length} onClick={save}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('rt.menu')}><input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder={t('rt.menuPh')} /></Field>
        <Field label={t('rt.from')}><input type="time" className="input" value={f.start_time} onChange={(e) => setF({ ...f, start_time: e.target.value })} /></Field>
        <Field label={t('rt.to')}><input type="time" className="input" value={f.end_time} onChange={(e) => setF({ ...f, end_time: e.target.value })} /></Field>
        <Field label={t('rt.dailyMenu')}><input type="date" className="input" value={f.menu_date} onChange={(e) => setF({ ...f, menu_date: e.target.value })} /></Field>
        <Field label={t('rt.setPrice')}><input className="input" inputMode="decimal" value={f.set_price} onChange={(e) => setF({ ...f, set_price: e.target.value })} /></Field>
      </div>
      <Field label={t('rt.outletsCol')}><div className="row" style={{ gap: 8 }}>{['restaurant', 'bar', 'room_service', 'breakfast'].map((o) => <label key={o} className="check"><input type="checkbox" checked={f.outlets.includes(o)} onChange={() => setF({ ...f, outlets: toggle(f.outlets, o) })} />{t(`rt.o_${o}` as Key)}</label>)}</div></Field>
      <Field label={t('rt.days')}><div className="row" style={{ gap: 8 }}>{[0, 1, 2, 3, 4, 5, 6].map((d) => <label key={d} className="check"><input type="checkbox" checked={f.days.includes(d)} onChange={() => setF({ ...f, days: toggle(f.days, d) })} />{t(`rt.d_${d}` as Key)}</label>)}</div></Field>
      {Object.entries(groups).map(([g, list]) => (
        <div key={g} className="section"><h3>{g}</h3><div className="row" style={{ gap: 8 }}>{list.map((i) => <label key={i.id} className="check"><input type="checkbox" checked={f.item_ids.includes(i.id)} onChange={() => setF({ ...f, item_ids: toggle(f.item_ids, i.id) })} />{i.name}</label>)}</div></div>
      ))}
    </Modal>
  );
}

// ===================================================== Stock =====================================================
function Stock() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const m = can('stock.manage');
  const [rows, setRows] = useState<any[] | null>(null);
  const [moves, setMoves] = useState<any[]>([]);
  const [move, setMove] = useState<any>(null);
  const [adding, setAdding] = useState(false);
  const load = useCallback(() => {
    get('/api/stock/products').then(setRows).catch(err(toast));
    get('/api/stock/movements').then(setMoves).catch(() => {});
  }, []);
  useEffect(load, [load]);
  useLive(load);
  if (!rows) return <span>{t('common.loading')}</span>;
  return (
    <>
      <div className="row">
        <span className="chip">{t('rt.articles')} <b>{rows.length}</b></span>
        <span className="chip" style={rows.some((r) => r.low) ? { borderColor: 'var(--danger)', color: 'var(--danger)' } : {}}>{t('rt.lowStock')} <b>{rows.filter((r) => r.low).length}</b></span>
        <span style={{ flex: 1 }} />
        {m && <button className="btn primary" onClick={() => setAdding(true)}><Icon name="plus" />{t('rt.newProduct')}</button>}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table className="table">
          <thead><tr><th>{t('rt.product')}</th><th>{t('rt.category')}</th><th className="num">{t('rt.stock')}</th><th className="num">{t('rt.min')}</th><th className="num">{t('rt.cost')}</th><th>{t('rt.usedIn')}</th><th /></tr></thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id} style={{ opacity: p.active ? 1 : 0.5 }}>
                <td><b>{p.name}</b>{p.code ? <span className="muted"> {p.code}</span> : null}</td><td>{p.category}</td>
                <td className="num" style={p.low ? { color: 'var(--danger)', fontWeight: 700 } : {}}>{Number(p.stock_qty)} {p.unit}{p.low ? ' ⚠' : ''}</td>
                <td className="num muted">{Number(p.min_stock)}</td><td className="num">{money(Number(p.cost_price), locale)}</td><td className="muted wrap" style={{ fontSize: 12 }}>{p.used_in ?? ''}</td>
                <td className="pin-end">{m && <button className="btn sm" onClick={() => setMove(p)}>{t('rt.movement')}</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <details className="card"><summary style={{ cursor: 'pointer', fontWeight: 600 }}>{t('rt.moveHistory')} ({moves.length})</summary>
        <table className="table">
          <thead><tr><th>{t('rt.time')}</th><th>{t('rt.product')}</th><th>{t('rt.movement')}</th><th className="num">Qté</th><th className="num">{t('rt.after')}</th><th>{t('rt.reason')}</th><th>{t('rt.user')}</th></tr></thead>
          <tbody>{moves.map((x) => <tr key={x.id}><td>{fmtDateTime(x.created_at, locale)}</td><td>{x.product}</td><td>{t(`rt.mv_${x.kind}` as Key)}{x.order_number ? ` · ${x.order_number}` : ''}</td><td className="num">{Number(x.quantity)}</td><td className="num">{x.stock_after === null ? '' : Number(x.stock_after)}</td><td className="wrap">{x.reason ?? ''}</td><td>{x.user_name}</td></tr>)}</tbody>
        </table>
      </details>
      {move && <StockMoveModal p={move} onClose={() => setMove(null)} onDone={() => { setMove(null); load(); }} />}
      {adding && <ProductModal onClose={() => setAdding(false)} onDone={() => { setAdding(false); load(); }} />}
    </>
  );
}
function StockMoveModal({ p, onClose, onDone }: { p: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [f, setF] = useState({ kind: 'in', quantity: '', reason: '' });
  return (
    <Modal size="sm" title={`${t('rt.movement')} — ${p.name}`} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!toNum(f.quantity)} onClick={async () => {
      try { await post('/api/stock/movements', { product_id: p.id, kind: f.kind, quantity: toNum(f.quantity), reason: f.reason || null }); onDone(); } catch (e: any) { toast('error', e.message); }
    }}>{t('common.save')}</button></>}>
      <p className="muted" style={{ margin: 0 }}>{t('rt.stock')} : {Number(p.stock_qty)} {p.unit}</p>
      <div className="seg">{['in', 'waste', 'adjust'].map((k) => <button key={k} className={f.kind === k ? 'on' : ''} onClick={() => setF({ ...f, kind: k })}>{t(`rt.mv_${k}` as Key)}</button>)}</div>
      <Field label={f.kind === 'adjust' ? t('rt.qtyAdjust') : `${t('rt.qty')} (${p.unit})`}><input className="input" inputMode="decimal" value={f.quantity} onChange={(e) => setF({ ...f, quantity: e.target.value })} /></Field>
      <Field label={`${t('rt.reason')}${f.kind !== 'in' ? ' *' : ''}`}><input className="input" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} placeholder={f.kind === 'in' ? t('rt.supplierPh') : ''} /></Field>
    </Modal>
  );
}
function ProductModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [f, setF] = useState({ name: '', category: 'Cuisine', unit: 'kg', min_stock: '', cost_price: '', initial: '' });
  return (
    <Modal title={t('rt.newProduct')} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={f.name.trim().length < 2} onClick={async () => {
      try { await post('/api/stock/products', { name: f.name, category: f.category, unit: f.unit, min_stock: toNum(f.min_stock), cost_price: toNum(f.cost_price), initial: toNum(f.initial) || undefined }); onDone(); } catch (e: any) { toast('error', e.message); }
    }}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('rt.product')}><input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label={t('rt.category')}><input className="input" list="stock-cats" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} /><datalist id="stock-cats"><option value="Cuisine" /><option value="Boissons" /><option value="Petit-déjeuner" /><option value="Pâtisserie" /></datalist></Field>
        <Field label={t('rt.unit')}><input className="input" list="stock-units" value={f.unit} onChange={(e) => setF({ ...f, unit: e.target.value })} /><datalist id="stock-units"><option value="kg" /><option value="g" /><option value="L" /><option value="bouteille" /><option value="unité" /></datalist></Field>
        <Field label={t('rt.min')}><input className="input" inputMode="decimal" value={f.min_stock} onChange={(e) => setF({ ...f, min_stock: e.target.value })} /></Field>
        <Field label={t('rt.cost')}><input className="input" inputMode="decimal" value={f.cost_price} onChange={(e) => setF({ ...f, cost_price: e.target.value })} /></Field>
        <Field label={t('rt.initialStock')}><input className="input" inputMode="decimal" value={f.initial} onChange={(e) => setF({ ...f, initial: e.target.value })} /></Field>
      </div>
    </Modal>
  );
}

// ===================================================== Rapports & réglages =====================================================
function Reports() {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [kind, setKind] = useState('daily');
  const [p, setP] = useState({ from: `${todayLocal().slice(0, 8)}01`, to: todayLocal() });
  const [r, setR] = useState<any>(null);
  const qs = `from=${p.from}&to=${p.to}`;
  useEffect(() => { setR(null); get(`/api/rs/reports/${kind}?${qs}`).then(setR).catch(err(toast)); }, [kind, qs]);
  const fmt = (c: any, v: any) => (v === null || v === undefined || v === '' ? '—' : c.money ? money(Number(v), locale) : String(v));
  return (
    <>
      <div className="row">
        <select className="input" style={{ width: 'auto' }} aria-label={t('rt.t_reports')} value={kind} onChange={(e) => setKind(e.target.value)}>
          {['daily', 'monthly', 'category', 'items', 'cancelled', 'prep', 'waiters', 'room_service', 'breakfast', 'stock'].map((k) => <option key={k} value={k}>{t(`rt.rp_${k}` as Key)}</option>)}
        </select>
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('bi.from')} value={p.from} onChange={(e) => e.target.value && setP({ ...p, from: e.target.value })} />
        <input type="date" className="input" style={{ width: 160 }} aria-label={t('bi.to')} value={p.to} min={p.from} onChange={(e) => e.target.value && setP({ ...p, to: e.target.value })} />
        <span style={{ flex: 1 }} />
        {['pdf', 'xlsx', 'csv'].map((f) => <button key={f} className="btn" onClick={() => window.open(`/api/rs/reports/${kind}?${qs}&format=${f}`, '_blank')}>{f === 'xlsx' ? 'Excel' : f.toUpperCase()}</button>)}
      </div>
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <h3 style={{ padding: '12px 14px 0' }}>{r?.title ?? '…'} <span className="muted" style={{ fontWeight: 500 }}>· {fmtDate(p.from, locale)} → {fmtDate(p.to, locale)}</span></h3>
        <table className="table">
          <thead><tr>{(r?.columns ?? []).map((c: any) => <th key={c.key} className={c.money ? 'num' : ''}>{c.label}</th>)}</tr></thead>
          <tbody>
            {r && !r.rows.length && <tr><td colSpan={r.columns.length} className="muted">{t('common.none')}</td></tr>}
            {(r?.rows ?? []).map((x: any, i: number) => <tr key={i}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : 'wrap'}>{fmt(c, x[c.key])}</td>)}</tr>)}
            {r?.total && r.rows.length > 0 && <tr style={{ fontWeight: 700, background: 'var(--surface2)' }}>{r.columns.map((c: any) => <td key={c.key} className={c.money ? 'num' : ''}>{r.total[c.key] !== undefined ? fmt(c, r.total[c.key]) : ''}</td>)}</tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function RsSettings() {
  const { t } = useI18n();
  const toast = useToast();
  const [s, setS] = useState<any>(null);
  const [tables, setTables] = useState<any[]>([]);
  const [nt, setNt] = useState({ number: '', capacity: 4, area: 'Salle', shape: 'square' });
  const loadT = () => get('/api/rs/tables').then(setTables).catch(() => {});
  useEffect(() => { get('/api/rs/settings').then(setS).catch(err(toast)); loadT(); }, []);
  if (!s) return <span>{t('common.loading')}</span>;
  const save = async () => { try { setS(await api('PUT', '/api/rs/settings', s)); toast('success', t('set.saved')); } catch (e: any) { toast('error', e.message); } };
  return (
    <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: 14, alignItems: 'start' }}>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <h3 style={{ margin: 0 }}>{t('rt.rules')}</h3>
        <div className="form-grid">
          <Field label={t('rt.bfStart')}><input type="time" className="input" value={s.breakfast_start} onChange={(e) => setS({ ...s, breakfast_start: e.target.value })} /></Field>
          <Field label={t('rt.bfEnd')}><input type="time" className="input" value={s.breakfast_end} onChange={(e) => setS({ ...s, breakfast_end: e.target.value })} /></Field>
          <Field label={t('rt.bfService')}><input className="input" value={s.breakfast_service_code} onChange={(e) => setS({ ...s, breakfast_service_code: e.target.value })} /></Field>
          <Field label={t('rt.maxDiscount')}><input type="number" min={0} max={100} className="input" value={s.max_discount_percent} onChange={(e) => setS({ ...s, max_discount_percent: Number(e.target.value) })} /></Field>
        </div>
        <label className="check"><input type="checkbox" checked={s.stock_block} onChange={(e) => setS({ ...s, stock_block: e.target.checked })} />{t('rt.stockBlock')}</label>
        <label className="check"><input type="checkbox" checked={s.table_to_clean} onChange={(e) => setS({ ...s, table_to_clean: e.target.checked })} />{t('rt.tableToClean')}</label>
        <p className="muted" style={{ fontSize: 12.5, margin: 0 }}>{t('rt.taxHint')}</p>
        <button className="btn primary" style={{ alignSelf: 'flex-start' }} onClick={save}>{t('common.save')}</button>
      </div>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <h3 style={{ margin: 0 }}>{t('rt.tables')}</h3>
        {tables.map((x) => (
          <div key={x.id} className="ck">
            <span><b>{x.number}</b> · {x.area} · {x.capacity} p.</span>
            <button className="btn sm ghost" onClick={async () => { try { await patch(`/api/rs/tables/${x.id}`, { active: false }); loadT(); } catch (e: any) { toast('error', e.message); } }}>{t('rt.deactivate')}</button>
          </div>
        ))}
        <div className="row" style={{ alignItems: 'flex-end' }}>
          <input className="input" style={{ width: 80 }} placeholder="N°" aria-label="N°" value={nt.number} onChange={(e) => setNt({ ...nt, number: e.target.value })} />
          <input className="input" style={{ width: 120 }} aria-label={t('rt.area')} value={nt.area} onChange={(e) => setNt({ ...nt, area: e.target.value })} />
          <input type="number" min={1} max={40} className="input" style={{ width: 80 }} aria-label={t('rt.covers')} value={nt.capacity} onChange={(e) => setNt({ ...nt, capacity: Number(e.target.value) })} />
          <select className="input" style={{ width: 'auto' }} aria-label="Forme" value={nt.shape} onChange={(e) => setNt({ ...nt, shape: e.target.value })}><option value="square">▢</option><option value="round">◯</option><option value="long">▭</option></select>
          <button className="btn" disabled={!nt.number} onClick={async () => { try { await post('/api/rs/tables', nt); setNt({ ...nt, number: '' }); loadT(); } catch (e: any) { toast('error', e.message); } }}><Icon name="plus" />{t('rt.add')}</button>
        </div>
      </div>
    </div>
  );
}
