import { useEffect, useState } from 'react';
import { useI18n, type Key } from '../i18n';
import { get, patch, post, api } from '../lib/api';
import { useToast } from '../lib/context';
import { addDays, money, todayLocal, currency } from '../lib/format';
import { ReasonModal } from './ReservationPanel';
import { Field, Modal } from './ui';

const MEALS = ['RO', 'BB', 'HB', 'FB'];

export function EditReservation({ r, onClose, onSaved }: { r: any; onClose: () => void; onSaved: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [g, setG] = useState({
    last_name: r.guest.last_name ?? '', first_name: r.guest.first_name ?? '', phone: r.guest.phone ?? '', email: r.guest.email ?? '',
    nationality: r.guest.nationality ?? '', address: r.guest.address ?? '', language: r.guest.language ?? 'fr',
  });
  const [info, setInfo] = useState({
    meal_plan: r.meal_plan, source: r.source, booker_type: r.booker_type, group_name: r.group_name ?? '', billing_mode: r.billing_mode,
    special_requests: r.special_requests ?? '', notes: r.notes ?? '', payer: r.payer?.company_name ?? '',
    disc_type: (r.discount_type ?? 'percent') as 'percent' | 'amount', disc_value: r.discount_value ? String(r.discount_value) : '',
  });
  const [busy, setBusy] = useState(false);
  const [cancelRr, setCancelRr] = useState<any>(null);
  const editable = !['cancelled', 'no_show', 'checked_out'].includes(r.status);

  const saveInfo = async () => {
    setBusy(true);
    try {
      await patch(`/api/reservations/${r.id}`, {
        guest: g, meal_plan: info.meal_plan, source: info.source, booker_type: info.booker_type, group_name: info.group_name || null,
        billing_mode: info.billing_mode, special_requests: info.special_requests || null, notes: info.notes || null,
        discount: Number(info.disc_value) > 0 ? { type: info.disc_type, value: Number(info.disc_value) } : null,
        payer: info.booker_type === 'company' || info.booker_type === 'agency' ? (info.payer.trim() ? { kind: info.booker_type, company_name: info.payer.trim() } : null) : null,
      });
      toast('success', 'Réservation modifiée.');
      onSaved();
    } catch (e: any) {
      toast('error', e.message);
    } finally {
      setBusy(false);
    }
  };

  const active = r.rooms.filter((x: any) => ['pending', 'confirmed', 'checked_in'].includes(x.status));
  return (
    <Modal title={`${t('form.edit')} — ${r.code}`} onClose={onClose} size="lg"
      footer={<><button className="btn" onClick={onClose}>{t('common.close')}</button>{editable && <button className="btn primary" disabled={busy} onClick={saveInfo}>{t('common.save')}</button>}</>}>
      {!editable && <div className="alert warning">Réservation clôturée : seules la consultation et l'impression sont possibles.</div>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 14 }}>
        <div className="section">
          <h3>{t('form.client')}</h3>
          <div className="form-grid">
            <Field label={t('new.lastName')} htmlFor="e-ln"><input id="e-ln" className="input" value={g.last_name} onChange={(e) => setG({ ...g, last_name: e.target.value })} disabled={!editable} /></Field>
            <Field label={t('new.firstName')} htmlFor="e-fn"><input id="e-fn" className="input" value={g.first_name} onChange={(e) => setG({ ...g, first_name: e.target.value })} disabled={!editable} /></Field>
            <Field label={t('new.phone')} htmlFor="e-ph"><input id="e-ph" className="input" value={g.phone} onChange={(e) => setG({ ...g, phone: e.target.value })} disabled={!editable} /></Field>
            <Field label={t('new.email')} htmlFor="e-em"><input id="e-em" className="input" value={g.email} onChange={(e) => setG({ ...g, email: e.target.value })} disabled={!editable} /></Field>
            <Field label={t('new.nationality')} htmlFor="e-nat"><input id="e-nat" className="input" value={g.nationality} onChange={(e) => setG({ ...g, nationality: e.target.value })} disabled={!editable} /></Field>
            <Field label={t('form.address')} htmlFor="e-ad"><input id="e-ad" className="input" value={g.address} onChange={(e) => setG({ ...g, address: e.target.value })} disabled={!editable} /></Field>
            <Field label={t('new.language')} htmlFor="e-lang"><select id="e-lang" className="input" value={g.language} disabled={!editable} onChange={(e) => setG({ ...g, language: e.target.value })}>{['fr', 'en', 'ar'].map((l) => <option key={l} value={l}>{t(`lang.${l}` as Key)}</option>)}</select></Field>
          </div>
        </div>
        <div className="section">
          <h3>{t('form.extra')}</h3>
          <div className="form-grid">
            <Field label={t('res.meal')} htmlFor="e-meal"><select id="e-meal" className="input" value={info.meal_plan} disabled={!editable} onChange={(e) => setInfo({ ...info, meal_plan: e.target.value })}>{MEALS.map((x) => <option key={x} value={x}>{t(`meal.${x}` as Key)}</option>)}</select></Field>
            <Field label={t('res.source')} htmlFor="e-src"><select id="e-src" className="input" value={info.source} disabled={!editable} onChange={(e) => setInfo({ ...info, source: e.target.value })}>{['walk_in', 'phone', 'email', 'company', 'agency', 'website', 'other'].map((x) => <option key={x} value={x}>{t(`src.${x}` as Key)}</option>)}</select></Field>
            <Field label={t('new.booker')} htmlFor="e-bk"><select id="e-bk" className="input" value={info.booker_type} disabled={!editable} onChange={(e) => setInfo({ ...info, booker_type: e.target.value })}>{['individual', 'group', 'company', 'agency'].map((x) => <option key={x} value={x}>{t(`bt.${x}` as Key)}</option>)}</select></Field>
            {(info.booker_type === 'company' || info.booker_type === 'agency') && <Field label={t('new.company')} htmlFor="e-payer"><input id="e-payer" className="input" value={info.payer} disabled={!editable} onChange={(e) => setInfo({ ...info, payer: e.target.value })} /></Field>}
            <Field label={t('new.group')} htmlFor="e-group"><input id="e-group" className="input" value={info.group_name} disabled={!editable} onChange={(e) => setInfo({ ...info, group_name: e.target.value })} /></Field>
            <Field label={t('form.billing')} htmlFor="e-bill"><select id="e-bill" className="input" value={info.billing_mode} disabled={!editable} onChange={(e) => setInfo({ ...info, billing_mode: e.target.value })}><option value="common">{t('form.billCommon')}</option><option value="individual">{t('form.billIndividual')}</option></select></Field>
            <div className="row" style={{ gap: 6, alignItems: 'flex-end' }}>
              <Field label={t('form.discount')} htmlFor="e-disc"><input id="e-disc" className="input" style={{ width: 110 }} value={info.disc_value} disabled={!editable} onChange={(e) => setInfo({ ...info, disc_value: e.target.value })} placeholder="0" /></Field>
              <div className="seg"><button className={info.disc_type === 'percent' ? 'on' : ''} onClick={() => setInfo({ ...info, disc_type: 'percent' })}>%</button><button className={info.disc_type === 'amount' ? 'on' : ''} onClick={() => setInfo({ ...info, disc_type: 'amount' })}>{currency.symbol}</button></div>
            </div>
          </div>
          <Field label={t('form.special')} htmlFor="e-spec"><textarea id="e-spec" className="input" rows={2} value={info.special_requests} disabled={!editable} onChange={(e) => setInfo({ ...info, special_requests: e.target.value })} /></Field>
          <Field label={t('form.internal')} htmlFor="e-notes"><textarea id="e-notes" className="input" rows={2} value={info.notes} disabled={!editable} onChange={(e) => setInfo({ ...info, notes: e.target.value })} /></Field>
        </div>
      </div>

      <div className="section">
        <h3>{t('common.rooms')} · {t('form.changeRoom')} · {t('form.dates')}</h3>
        {active.map((rr: any) => (
          <RoomEditor key={rr.id} rr={rr} canCancel={active.length > 1 && rr.status !== 'checked_in'} onCancel={() => setCancelRr(rr)} onSaved={onSaved} />
        ))}
        {r.rooms.filter((x: any) => !active.includes(x)).map((rr: any) => (
          <div key={rr.id} className="muted" style={{ fontSize: 13 }}>{t('common.room')} {rr.room_number} · {t(`st.${rr.status}` as Key)} · {rr.check_in} → {rr.check_out}</div>
        ))}
        {editable && <AddRoom r={r} onSaved={onSaved} />}
      </div>
      <div className="muted" style={{ fontSize: 12 }}>{t('common.total')} : {money(r.total, locale)} · {t('common.balance')} : {money(r.balance, locale)}</div>
      {cancelRr && (
        <ReasonModal title={`${t('form.cancelRoom')} ${cancelRr.room_number}`} onClose={() => setCancelRr(null)}
          onSubmit={async (reason) => {
            try { await post(`/api/reservation-rooms/${cancelRr.id}/cancel`, { reason }); toast('success', `Chambre ${cancelRr.room_number} annulée et libérée.`); setCancelRr(null); onSaved(); }
            catch (e: any) { toast('error', e.message); }
          }} />
      )}
    </Modal>
  );
}

function RoomEditor({ rr, canCancel, onCancel, onSaved }: { rr: any; canCancel: boolean; onCancel: () => void; onSaved: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [roomId, setRoomId] = useState(rr.room_id);
  const [ci, setCi] = useState(rr.check_in);
  const [co, setCo] = useState(rr.check_out);
  const [adults, setAdults] = useState(rr.adults);
  const [children, setChildren] = useState(rr.children);
  const [price, setPrice] = useState(rr.custom_rate ? String(rr.rack_rate) : '');
  const [occupant, setOccupant] = useState(rr.occupant_name ?? '');
  const [rooms, setRooms] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const inHouse = rr.status === 'checked_in';
  const t0 = todayLocal();

  useEffect(() => {
    if (co <= ci) return;
    get(`/api/availability?check_in=${ci}&check_out=${co}&exclude_rr=${rr.id}`).then(setRooms).catch(() => {});
  }, [ci, co]);

  const dirty = roomId !== rr.room_id || ci !== rr.check_in || co !== rr.check_out || adults !== rr.adults || children !== rr.children || (price !== '' && Number(price) !== Number(rr.rack_rate));
  const apply = async () => {
    setBusy(true);
    try {
      const body: any = {};
      if (roomId !== rr.room_id) body.room_id = roomId;
      if (ci !== rr.check_in) body.check_in = ci;
      if (co !== rr.check_out) body.check_out = co;
      if (adults !== rr.adults) body.adults = adults;
      if (children !== rr.children) body.children = children;
      if (price !== '' && Number(price) !== Number(rr.rack_rate)) body.rate = Number(price);
      await patch(`/api/reservation-rooms/${rr.id}`, body);
      toast('success', `Chambre mise à jour (planning actualisé).`);
      onSaved();
    } catch (e: any) {
      toast('error', e.message);
    } finally {
      setBusy(false);
    }
  };
  const saveOccupant = async () => {
    try {
      const parts = occupant.trim().split(' ');
      await api('PUT', `/api/reservation-rooms/${rr.id}/occupant`, { guest: occupant.trim() ? { last_name: parts[0], first_name: parts.slice(1).join(' ') || null } : null });
      toast('success', 'Occupant enregistré.');
      onSaved();
    } catch (e: any) {
      toast('error', e.message);
    }
  };
  const options = [{ id: rr.room_id, number: rr.room_number, type_name: rr.room_type }, ...rooms.filter((x) => x.id !== rr.room_id)];
  return (
    <div className="card" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div className="row between">
        <b>{t('common.room')} {rr.room_number} · {rr.room_type}</b>
        <span className="muted" style={{ fontSize: 12 }}>{t(`st.${rr.status}` as Key)} · {money(Number(rr.rate), locale)} / nuit</span>
      </div>
      <div className="form-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))' }}>
        <Field label={t('common.room')}><select className="input" value={roomId} onChange={(e) => setRoomId(Number(e.target.value))}>{options.map((o) => <option key={o.id} value={o.id}>{o.number} · {o.type_name}</option>)}</select></Field>
        <Field label={t('res.arrival')}><input type="date" className="input" value={ci} min={inHouse ? undefined : t0} disabled={inHouse} onChange={(e) => { setCi(e.target.value); if (e.target.value >= co) setCo(addDays(e.target.value, 1)); }} /></Field>
        <Field label={t('res.departure')}><input type="date" className="input" value={co} min={addDays(ci, 1)} onChange={(e) => setCo(e.target.value)} /></Field>
        <Field label={t('new.adults')}><input type="number" className="input" min={1} max={8} value={adults} onChange={(e) => setAdults(Math.max(1, Number(e.target.value)))} /></Field>
        <Field label={t('new.children')}><input type="number" className="input" min={0} max={8} value={children} onChange={(e) => setChildren(Math.max(0, Number(e.target.value)))} /></Field>
        <Field label={`${t('form.pricePerNight')} (${t('form.rateCustom').toLowerCase()})`}><input className="input" inputMode="decimal" placeholder={String(rr.rack_rate)} value={price} onChange={(e) => setPrice(e.target.value)} /></Field>
      </div>
      <div className="row">
        <button className="btn primary sm" disabled={!dirty || busy} onClick={apply}>{t('form.apply')}</button>
        <button className="btn sm" onClick={() => setCo(addDays(co, 1))}>+1 nuit</button>
        <button className="btn sm" disabled={co <= addDays(ci, 1)} onClick={() => setCo(addDays(co, -1))}>−1 nuit</button>
        <input className="input" style={{ maxWidth: 220, minHeight: 32 }} placeholder={t('form.occupant')} value={occupant} onChange={(e) => setOccupant(e.target.value)} aria-label={t('form.occupant')} />
        <button className="btn sm" onClick={saveOccupant} disabled={(rr.occupant_name ?? '') === occupant}>{t('common.save')}</button>
        {canCancel && <button className="btn sm danger" style={{ marginInlineStart: 'auto' }} onClick={onCancel}>{t('form.cancelRoom')}</button>}
      </div>
    </div>
  );
}

function AddRoom({ r, onSaved }: { r: any; onSaved: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const t0 = todayLocal();
  const [ci, setCi] = useState(r.check_in < t0 ? t0 : r.check_in);
  const [co, setCo] = useState(r.check_out <= (r.check_in < t0 ? t0 : r.check_in) ? addDays(t0, 1) : r.check_out);
  const [rooms, setRooms] = useState<any[]>([]);
  const [roomId, setRoomId] = useState(0);
  const [adults, setAdults] = useState(1);
  useEffect(() => {
    if (co <= ci) return;
    get(`/api/availability?check_in=${ci}&check_out=${co}`).then((x) => { setRooms(x); setRoomId(x[0]?.id ?? 0); }).catch(() => {});
  }, [ci, co]);
  const add = async () => {
    try {
      await post(`/api/reservations/${r.id}/rooms`, { room_id: roomId, check_in: ci, check_out: co, adults });
      toast('success', 'Chambre ajoutée au groupe et au planning.');
      onSaved();
    } catch (e: any) {
      toast('error', e.message);
    }
  };
  return (
    <div className="row" style={{ alignItems: 'flex-end', borderTop: '1px dashed var(--border)', paddingTop: 10 }}>
      <b style={{ fontSize: 13 }}>{t('form.addRoom')}</b>
      <Field label={t('res.arrival')}><input type="date" className="input" value={ci} min={t0} onChange={(e) => setCi(e.target.value)} /></Field>
      <Field label={t('res.departure')}><input type="date" className="input" value={co} min={addDays(ci, 1)} onChange={(e) => setCo(e.target.value)} /></Field>
      <Field label={t('common.room')}><select className="input" value={roomId} onChange={(e) => setRoomId(Number(e.target.value))}>{rooms.map((o) => <option key={o.id} value={o.id}>{o.number} · {o.type_name}</option>)}</select></Field>
      <Field label={t('new.adults')}><input type="number" className="input" style={{ width: 80 }} min={1} value={adults} onChange={(e) => setAdults(Math.max(1, Number(e.target.value)))} /></Field>
      <button className="btn" disabled={!roomId} onClick={add}>+ {t('form.addRoom')}</button>
    </div>
  );
}
