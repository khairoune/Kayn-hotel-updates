import { useEffect, useMemo, useState } from 'react';
import { useI18n, type Key } from '../i18n';
import { get, post } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { addDays, diffDays, money, todayLocal, currency } from '../lib/format';
import { Field, Modal } from './ui';
import { IdScan } from './IdScan';

interface Props {
  initial?: { room_id?: number; check_in?: string };
  onClose: () => void;
  onCreated: (reservation: any) => void;
}

type Sel = { adults: number; children: number; price: string; occupant: string };
const MEALS = ['RO', 'BB', 'HB', 'FB'] as const;
const r2 = (n: number) => Math.round(n * 100) / 100;

export interface Settings { meal_supplements: Record<string, number>; vat_rate: number; tourist_tax_per_adult_night: number; deposit_policy?: any; cancellation_policy?: any; default_guest_language?: string }

export function useSettings() {
  const [s, setS] = useState<Settings>({ meal_supplements: { RO: 0, BB: 0, HB: 0, FB: 0 }, vat_rate: 0, tourist_tax_per_adult_night: 0 });
  useEffect(() => { get('/api/settings').then(setS).catch(() => {}); }, []);
  return s;
}

/** Calcul identique au serveur : prix public, remise, TVA, taxe de séjour. */
export function computeTotals(lines: { rack: number; nights: number; adults: number }[], disc: { type: 'percent' | 'amount'; value: number } | null, s: Settings) {
  const gross = r2(lines.reduce((a, l) => a + l.rack * l.nights, 0));
  let discount = 0;
  if (disc && disc.value > 0) {
    if (disc.type === 'percent') discount = r2(lines.reduce((a, l) => a + r2((l.rack * Math.min(100, disc.value)) / 100) * l.nights, 0));
    else {
      const nights = lines.reduce((a, l) => a + l.nights, 0);
      const each = nights ? r2(disc.value / nights) : 0;
      discount = r2(lines.reduce((a, l) => a + Math.min(l.rack, each) * l.nights, 0));
    }
  }
  const net = r2(gross - discount);
  const vat = r2((net * Number(s.vat_rate || 0)) / 100);
  const tourist = r2(Number(s.tourist_tax_per_adult_night || 0) * lines.reduce((a, l) => a + l.adults * l.nights, 0));
  return { gross, discount, net, vat, tourist, total: r2(net + vat + tourist) };
}

export function NewReservation({ initial, onClose, onCreated }: Props) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const settings = useSettings();
  const t0 = todayLocal();
  const startDate = initial?.check_in && initial.check_in >= t0 ? initial.check_in : t0;
  const [checkIn, setCheckIn] = useState(startDate);
  const [checkOut, setCheckOut] = useState(addDays(startDate, 1));
  const [meal, setMeal] = useState<(typeof MEALS)[number]>('BB');
  const [booker, setBooker] = useState<'individual' | 'group' | 'company' | 'agency'>('individual');
  const [source, setSource] = useState('phone');
  const [status, setStatus] = useState<'confirmed' | 'pending'>('confirmed');
  const [rateMode, setRateMode] = useState<'standard' | 'custom'>('standard');
  const [plans, setPlans] = useState<any[]>([]);
  const [planId, setPlanId] = useState(0);
  const [quote, setQuote] = useState<{ rooms: Record<number, { avg: number; total: number }>; error: string | null }>({ rooms: {}, error: null });
  const [discType, setDiscType] = useState<'percent' | 'amount'>('percent');
  const [discValue, setDiscValue] = useState('');
  const [billing, setBilling] = useState<'common' | 'individual'>('common');
  const [guestSearch, setGuestSearch] = useState('');
  const [found, setFound] = useState<any[]>([]);
  const [guestId, setGuestId] = useState<number | null>(null);
  const [g, setG] = useState<Record<string, any>>({ last_name: '', first_name: '', phone: '', email: '', nationality: 'Algérienne', address: '', id_doc_type: 'cni', id_doc_number: '', language: '' });
  const [scanId, setScanId] = useState<number | null>(null);
  const [override, setOverride] = useState(false);
  const [payer, setPayer] = useState('');
  const [groupName, setGroupName] = useState('');
  const [special, setSpecial] = useState('');
  const [notes, setNotes] = useState('');
  const [types, setTypes] = useState<any[]>([]);
  const [typeFilter, setTypeFilter] = useState(0);
  const [count, setCount] = useState(1);
  const [defAdults, setDefAdults] = useState(1);
  const [defChildren, setDefChildren] = useState(0);
  const [available, setAvailable] = useState<any[]>([]);
  const [selected, setSelected] = useState<Record<number, Sel>>({});
  const [deposit, setDeposit] = useState('');
  const [depMethod, setDepMethod] = useState('cash');
  const [depRef, setDepRef] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const nights = diffDays(checkIn, checkOut);

  useEffect(() => {
    get('/api/room-types').then(setTypes).catch(() => {});
    get('/api/rate-plans').then((p) => setPlans(p.filter((x: any) => x.active))).catch(() => {});
  }, []);
  useEffect(() => {
    if (nights < 1) { setAvailable([]); return; }
    get(`/api/availability?check_in=${checkIn}&check_out=${checkOut}`).then((rows) => {
      setAvailable(rows);
      setSelected((s) => {
        const keep = Object.fromEntries(Object.entries(s).filter(([id]) => rows.some((r: any) => r.id === Number(id))));
        if (initial?.room_id && Object.keys(s).length === 0 && rows.some((r: any) => r.id === initial.room_id)) {
          const room = rows.find((r: any) => r.id === initial.room_id);
          return { [initial.room_id]: { adults: 1, children: 0, price: String(room.base_rate), occupant: '' } };
        }
        return keep;
      });
    }).catch((e) => setErr(e.message));
  }, [checkIn, checkOut]);
  useEffect(() => {
    if (guestSearch.trim().length < 2 || guestId) { setFound([]); return; }
    const h = setTimeout(() => get(`/api/guests?search=${encodeURIComponent(guestSearch)}&kind=person`).then(setFound).catch(() => {}), 250);
    return () => clearTimeout(h);
  }, [guestSearch, guestId]);

  const supp = (adults: number) => Number(settings.meal_supplements?.[meal] ?? 0) * adults;
  const plan = plans.find((p) => p.id === planId);
  const quoteKey = JSON.stringify([checkIn, checkOut, meal, planId, payer, Object.entries(selected).map(([id, x]) => [id, x.adults, x.children])]);
  useEffect(() => {
    if (rateMode !== 'standard' || nights < 1 || !Object.keys(selected).length) { setQuote({ rooms: {}, error: null }); return; }
    const payerMatches = plan?.guest_id && payer.trim().toLowerCase() === String(plan.company_name ?? '').toLowerCase();
    const h = setTimeout(() => post('/api/rates/quote', {
      check_in: checkIn, check_out: checkOut, meal_plan: meal, rate_plan_id: planId || null, payer_guest_id: payerMatches ? plan.guest_id : null,
      rooms: Object.entries(selected).map(([id, x]) => ({ room_id: Number(id), adults: x.adults, children: x.children })),
    }).then((r) => setQuote({ rooms: Object.fromEntries(r.rooms.map((x: any) => [x.room_id, { avg: x.avg, total: x.total }])), error: r.plan_error })).catch(() => {}), 200);
    return () => clearTimeout(h);
  }, [quoteKey, rateMode]);
  const pickPlan = (id: number) => {
    setPlanId(id);
    const p = plans.find((x) => x.id === id);
    if (p?.company_name) { setPayer(p.company_name); if (booker === 'individual' || booker === 'group') setBooker(p.kind === 'agency' ? 'agency' : 'company'); }
  };
  const roomOf = (id: number) => available.find((r) => r.id === id);
  const rackOf = (id: number, s: Sel) => {
    const room = roomOf(id);
    if (!room) return 0;
    if (rateMode === 'custom') return Number(s.price.replace(',', '.')) || 0;
    return quote.rooms[id]?.avg ?? Number(room.base_rate) + supp(s.adults);
  };
  const lines = Object.entries(selected).filter(([id]) => roomOf(Number(id))).map(([id, s]) => ({ rack: rackOf(Number(id), s), nights: Math.max(0, nights), adults: s.adults }));
  const disc = Number(discValue) > 0 ? { type: discType, value: Number(discValue) } : null;
  const totals = useMemo(() => computeTotals(lines, disc, settings), [JSON.stringify(lines), discType, discValue, settings]);
  const depositN = Number(deposit.replace(/\s/g, '').replace(',', '.')) || 0;
  const pol = settings.deposit_policy;
  const depRequired = pol && pol.mode !== 'none' && !(pol.exempt_sources ?? []).includes(source) ? r2((totals.total * Number(pol.percent || 0)) / 100) : 0;
  const roomCount = Object.keys(selected).length;

  const autoPick = () => {
    const pool = available.filter((r) => (!typeFilter || r.type_id === typeFilter) && !selected[r.id] && r.capacity >= defAdults + defChildren);
    const need = Math.max(0, count - roomCount);
    if (pool.length < need) toast('info', `Seulement ${pool.length} chambre(s) libre(s) de ce type.`);
    const add: Record<number, Sel> = {};
    pool.slice(0, need).forEach((r) => (add[r.id] = { adults: defAdults, children: defChildren, price: String(Number(r.base_rate) + supp(defAdults)), occupant: '' }));
    setSelected({ ...selected, ...add });
    if (count > 1 && booker === 'individual') setBooker('group');
  };
  const toggleRoom = (r: any) => setSelected((s) => {
    const n = { ...s };
    if (n[r.id]) delete n[r.id];
    else n[r.id] = { adults: Math.min(defAdults, r.capacity), children: 0, price: String(Number(r.base_rate) + supp(defAdults)), occupant: '' };
    return n;
  });
  const setSel = (id: number, patch: Partial<Sel>) => setSelected((s) => ({ ...s, [id]: { ...s[id], ...patch } }));

  const submit = async () => {
    setErr('');
    if (!guestId && !g.last_name.trim()) return setErr('Le nom du client est obligatoire.');
    if (roomCount === 0) return setErr('Choisissez au moins une chambre.');
    if ((booker === 'company' || booker === 'agency') && !payer.trim()) return setErr('Indiquez la société ou l\'agence.');
    if (rateMode === 'custom' && lines.some((l) => !(l.rack > 0))) return setErr('Indiquez le prix par nuit de chaque chambre.');
    if (depositN > 0 && (depMethod === 'cheque' || depMethod === 'transfer') && !depRef.trim()) return setErr('Référence obligatoire pour un chèque ou un virement.');
    setBusy(true);
    try {
      const body = {
        guest: guestId ? { id: guestId } : { ...g, kind: 'person', language: g.language || settings.default_guest_language || 'fr' },
        payer: booker === 'company' || booker === 'agency' ? { kind: booker, company_name: payer.trim() } : null,
        booker_type: booker, group_name: groupName || null, source, status, check_in: checkIn, check_out: checkOut, meal_plan: meal,
        rate_mode: rateMode, rate_plan_id: rateMode === 'standard' && planId ? planId : null, discount: disc, billing_mode: roomCount > 1 ? billing : 'common',
        special_requests: special || null, notes: notes || null,
        rooms: Object.entries(selected).map(([id, s]) => ({
          room_id: Number(id), adults: s.adults, children: s.children,
          rate: rateMode === 'custom' ? Number(s.price.replace(',', '.')) : undefined,
          guest: s.occupant.trim() ? { last_name: s.occupant.trim().split(' ')[0], first_name: s.occupant.trim().split(' ').slice(1).join(' ') || null } : null,
        })),
        deposit: depositN > 0 ? { amount: depositN, method: depMethod, reference: depRef || null } : null,
        override_policy: override || undefined,
      };
      const res = await post('/api/reservations', body);
      // la photo scannée est rattachée à la fiche du client (effacement automatique selon la durée de conservation)
      if (scanId && res.guest_id) post(`/api/id-scans/${scanId}/use`, { guest_id: res.guest_id }).catch(() => {});
      toast('success', `Réservation ${res.code} créée et ajoutée au planning.`);
      onCreated(res);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  const floors = [...new Set(available.filter((r) => !typeFilter || r.type_id === typeFilter).map((r) => r.floor))];
  const m = (n: number) => money(n, locale);
  return (
    <Modal title={t('plan.new')} onClose={onClose} size="lg"
      footer={<>
        <span style={{ marginInlineEnd: 'auto', fontWeight: 600 }}>{t('form.totalTtc')} : {m(totals.total)} · {t('form.remaining')} : {m(Math.max(0, totals.total - depositN))}</span>
        <button className="btn" onClick={onClose}>{t('common.cancel')}</button>
        <button className="btn primary" disabled={busy || nights < 1} onClick={submit}>{t('new.create')}</button>
      </>}>
      <div className="res-grid">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, minWidth: 0 }}>
          {/* ===== Client ===== */}
          <div className="section">
            <h3>{t('form.client')}</h3>
            <div style={{ position: 'relative' }}>
              <input className="input" placeholder={`${t('new.existing')} : ${t('common.search')}`} value={guestSearch} onChange={(e) => { setGuestSearch(e.target.value); setGuestId(null); }} aria-label={t('new.existing')} />
              {found.length > 0 && (
                <div className="card" style={{ position: 'absolute', zIndex: 5, insetInline: 0, top: 44, padding: 4, maxHeight: 220, overflowY: 'auto' }}>
                  {found.map((f) => (
                    <button key={f.id} className="btn ghost" style={{ width: '100%', justifyContent: 'flex-start' }}
                      onClick={() => { setGuestId(f.id); setGuestSearch(`${f.last_name ?? ''} ${f.first_name ?? ''}`.trim()); setFound([]); }}>
                      {f.last_name} {f.first_name} <span className="muted">· {f.phone ?? f.email ?? f.id_doc_number ?? ''}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            {guestId ? (
              <div className="alert info row between">{t('new.existing')} : <b>{guestSearch}</b><button className="btn sm ghost" onClick={() => { setGuestId(null); setGuestSearch(''); }}>×</button></div>
            ) : (
              <>
              <IdScan context="reservation" onFill={(x, id) => {
                setScanId(id);
                // seules les valeurs lues remplacent la saisie ; l'agent peut tout corriger ensuite
                setG({ ...g, ...Object.fromEntries(Object.entries({ last_name: x.last_name, first_name: x.first_name, nationality: x.nationality, id_doc_type: x.id_doc_type === 'other' ? 'other' : x.id_doc_type,
                  id_doc_number: x.id_doc_number, birth_date: x.birth_date, gender: x.gender, id_doc_expiry: x.id_doc_expiry, country: x.issuing_country }).filter(([, v]) => v)) });
              }} />
              <div className="form-grid">
                <Field label={`${t('new.lastName')} *`} htmlFor="g-ln"><input id="g-ln" className="input" value={g.last_name} onChange={(e) => setG({ ...g, last_name: e.target.value })} /></Field>
                <Field label={t('new.firstName')} htmlFor="g-fn"><input id="g-fn" className="input" value={g.first_name} onChange={(e) => setG({ ...g, first_name: e.target.value })} /></Field>
                <Field label={t('new.phone')} htmlFor="g-ph"><input id="g-ph" className="input" inputMode="tel" value={g.phone} onChange={(e) => setG({ ...g, phone: e.target.value })} /></Field>
                <Field label={t('new.email')} htmlFor="g-em"><input id="g-em" className="input" type="email" value={g.email} onChange={(e) => setG({ ...g, email: e.target.value })} /></Field>
                <Field label={t('new.nationality')} htmlFor="g-nat"><input id="g-nat" className="input" value={g.nationality} onChange={(e) => setG({ ...g, nationality: e.target.value })} /></Field>
                <Field label={t('form.address')} htmlFor="g-ad"><input id="g-ad" className="input" value={g.address} onChange={(e) => setG({ ...g, address: e.target.value })} /></Field>
                <Field label={t('new.docType')} htmlFor="g-dt">
                  <select id="g-dt" className="input" value={g.id_doc_type} onChange={(e) => setG({ ...g, id_doc_type: e.target.value })}>
                    <option value="cni">CNI</option><option value="passport">Passeport</option><option value="permis">Permis</option><option value="other">Autre</option>
                  </select>
                </Field>
                <Field label={t('new.docNumber')} htmlFor="g-dn"><input id="g-dn" className="input" value={g.id_doc_number} onChange={(e) => setG({ ...g, id_doc_number: e.target.value })} /></Field>
                <Field label={t('new.language')} htmlFor="g-lang">
                  <select id="g-lang" className="input" value={g.language || settings.default_guest_language || 'fr'} onChange={(e) => setG({ ...g, language: e.target.value })}>
                    {['fr', 'en', 'ar'].map((l) => <option key={l} value={l}>{t(`lang.${l}` as Key)}</option>)}
                  </select>
                </Field>
              </div>
              </>
            )}
          </div>

          {/* ===== Séjour ===== */}
          <div className="section">
            <h3>{t('form.stay')}</h3>
            <div className="form-grid">
              <Field label={t('res.arrival')} htmlFor="n-ci"><input id="n-ci" type="date" className="input" min={t0} value={checkIn} onChange={(e) => { setCheckIn(e.target.value); if (e.target.value >= checkOut) setCheckOut(addDays(e.target.value, 1)); }} /></Field>
              <Field label={t('res.departure')} htmlFor="n-co"><input id="n-co" type="date" className="input" min={addDays(checkIn, 1)} value={checkOut} onChange={(e) => setCheckOut(e.target.value)} /></Field>
              <Field label={t('list.nights')}><div className="input" style={{ display: 'flex', alignItems: 'center', fontWeight: 700 }}>{Math.max(0, nights)}</div></Field>
              <Field label={t('res.meal')} htmlFor="n-meal">
                <select id="n-meal" className="input" value={meal} onChange={(e) => setMeal(e.target.value as any)}>{MEALS.map((x) => <option key={x} value={x}>{t(`meal.${x}` as Key)}</option>)}</select>
              </Field>
              <Field label={t('new.adults')} htmlFor="n-ad"><input id="n-ad" className="input" type="number" min={1} max={6} value={defAdults} onChange={(e) => setDefAdults(Math.max(1, Number(e.target.value)))} /></Field>
              <Field label={t('new.children')} htmlFor="n-ch"><input id="n-ch" className="input" type="number" min={0} max={6} value={defChildren} onChange={(e) => setDefChildren(Math.max(0, Number(e.target.value)))} /></Field>
              <Field label={t('form.roomType')} htmlFor="n-type">
                <select id="n-type" className="input" value={typeFilter} onChange={(e) => setTypeFilter(Number(e.target.value))}>
                  <option value={0}>{t('plan.allTypes')}</option>
                  {types.map((x) => <option key={x.id} value={x.id}>{x.name} · {m(Number(x.base_rate))}</option>)}
                </select>
              </Field>
              <Field label={t('form.roomCount')} htmlFor="n-count"><input id="n-count" className="input" type="number" min={1} max={40} value={count} onChange={(e) => setCount(Math.max(1, Number(e.target.value)))} /></Field>
            </div>
            <div className="row between">
              <span className="muted" style={{ fontSize: 13 }}>{available.length} {t('plan.free')} · {roomCount} {t('common.rooms').toLowerCase()}</span>
              <button className="btn sm" onClick={autoPick} disabled={nights < 1}>{t('form.autoPick')}</button>
            </div>
            {available.length === 0 && nights > 0 && <div className="alert warning">{t('new.noRoom')}</div>}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, maxHeight: 150, overflowY: 'auto' }}>
              {floors.map((f) => (
                <div key={f} className="row" style={{ gap: 6 }}>
                  <span className="muted" style={{ fontSize: 12, width: 44 }}>Ét. {f}</span>
                  {available.filter((r) => r.floor === f && (!typeFilter || r.type_id === typeFilter)).map((r) => (
                    <button key={r.id} className={`chip ${selected[r.id] ? 'on' : ''}`} onClick={() => toggleRoom(r)} aria-pressed={!!selected[r.id]} title={`${r.type_name} · ${r.capacity} pers.`}>
                      {r.number} <span style={{ opacity: .7, fontSize: 11 }}>{r.type_name}</span>
                    </button>
                  ))}
                </div>
              ))}
            </div>
          </div>
        {/* ===== Complémentaires ===== */}
        <div className="section">
          <h3>{t('form.extra')}</h3>
          <div className="form-grid">
            <Field label={t('new.booker')} htmlFor="n-bk">
              <select id="n-bk" className="input" value={booker} onChange={(e) => { const v = e.target.value as any; setBooker(v); if (v === 'company' || v === 'agency') setSource(v); }}>
                {['individual', 'group', 'company', 'agency'].map((x) => <option key={x} value={x}>{t(`bt.${x}` as Key)}</option>)}
              </select>
            </Field>
            {(booker === 'company' || booker === 'agency') && <Field label={t('new.company')} htmlFor="n-payer"><input id="n-payer" className="input" value={payer} onChange={(e) => setPayer(e.target.value)} /></Field>}
            {(booker !== 'individual' || roomCount > 1) && <Field label={t('new.group')} htmlFor="n-group"><input id="n-group" className="input" value={groupName} onChange={(e) => setGroupName(e.target.value)} /></Field>}
            {roomCount > 1 && (
              <Field label={t('form.billing')} htmlFor="n-bill">
                <select id="n-bill" className="input" value={billing} onChange={(e) => setBilling(e.target.value as any)}><option value="common">{t('form.billCommon')}</option><option value="individual">{t('form.billIndividual')}</option></select>
              </Field>
            )}
            <Field label={t('res.source')} htmlFor="n-src">
              <select id="n-src" className="input" value={source} onChange={(e) => setSource(e.target.value)}>
                {['walk_in', 'phone', 'email', 'company', 'agency', 'website', 'other'].map((x) => <option key={x} value={x}>{t(`src.${x}` as Key)}</option>)}
              </select>
            </Field>
            <Field label={t('new.status')} htmlFor="n-st">
              <select id="n-st" className="input" value={status} onChange={(e) => setStatus(e.target.value as any)}><option value="confirmed">{t('st.confirmed')}</option><option value="pending">{t('st.pending')}</option></select>
            </Field>
          </div>
          <div className="form-grid">
            <Field label={t('form.special')} htmlFor="n-spec"><textarea id="n-spec" className="input" rows={2} value={special} onChange={(e) => setSpecial(e.target.value)} /></Field>
            <Field label={t('form.internal')} htmlFor="n-notes"><textarea id="n-notes" className="input" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
          </div>
        </div>
        </div>

        {/* ===== Finances ===== */}
        <div className="section res-summary">
          <h3>{t('form.finance')}</h3>
          <Field label={t('form.rate')} htmlFor="n-rate">
            <select id="n-rate" className="input" value={rateMode} onChange={(e) => setRateMode(e.target.value as any)}>
              <option value="standard">{t('form.rateStandard')}</option><option value="custom">{t('form.rateCustom')}</option>
            </select>
          </Field>
          {rateMode === 'standard' && plans.length > 1 && (
            <Field label={t('form.ratePlan')} htmlFor="n-plan">
              <select id="n-plan" className="input" value={planId} onChange={(e) => pickPlan(Number(e.target.value))}>
                <option value={0}>{t('pk.standard')}</option>
                {plans.filter((p) => p.kind !== 'standard').map((p) => <option key={p.id} value={p.id}>{p.name}{p.company_name ? ` — ${p.company_name}` : ''}</option>)}
              </select>
            </Field>
          )}
          {rateMode === 'standard' && quote.error && <div className="alert" style={{ fontSize: 12.5 }}>{quote.error}</div>}
          {Object.entries(selected).map(([id, s]) => {
            const room = roomOf(Number(id));
            if (!room) return null;
            return (
              <div key={id} style={{ borderBottom: '1px solid var(--soft)', paddingBottom: 8, display: 'flex', flexDirection: 'column', gap: 6 }}>
                <div className="row between"><b>{t('common.room')} {room.number}</b><span className="muted" style={{ fontSize: 12 }}>{room.type_name} · max {room.capacity}</span></div>
                <div className="row" style={{ gap: 6 }}>
                  <label className="row" style={{ gap: 4, fontSize: 12 }}>{t('new.adults')}<input className="input" style={{ width: 60, minHeight: 34 }} type="number" min={1} max={room.capacity} value={s.adults} onChange={(e) => setSel(Number(id), { adults: Math.max(1, Number(e.target.value)) })} /></label>
                  <label className="row" style={{ gap: 4, fontSize: 12 }}>{t('new.children')}<input className="input" style={{ width: 60, minHeight: 34 }} type="number" min={0} max={room.capacity} value={s.children} onChange={(e) => setSel(Number(id), { children: Math.max(0, Number(e.target.value)) })} /></label>
                </div>
                {rateMode === 'custom'
                  ? <label className="row" style={{ gap: 6, fontSize: 12 }}>{t('form.pricePerNight')}<input className="input" style={{ width: 120, minHeight: 34 }} inputMode="decimal" value={s.price} onChange={(e) => setSel(Number(id), { price: e.target.value })} /></label>
                  : <span style={{ fontSize: 13 }}>{t('form.pricePerNight')} : <b>{m(rackOf(Number(id), s))}</b>{quote.rooms[Number(id)] && nights > 1 ? <span className="muted"> (moy. · {m(quote.rooms[Number(id)].total)})</span> : null}</span>}
                {roomCount > 1 && <input className="input" style={{ minHeight: 34 }} placeholder={`${t('form.occupant')} (${t('new.lastName')} ${t('new.firstName')})`} value={s.occupant} onChange={(e) => setSel(Number(id), { occupant: e.target.value })} aria-label={t('form.occupant')} />}
              </div>
            );
          })}
          <div className="row" style={{ gap: 6 }}>
            <Field label={t('form.discount')} htmlFor="n-disc"><input id="n-disc" className="input" inputMode="decimal" value={discValue} onChange={(e) => setDiscValue(e.target.value)} placeholder="0" style={{ width: 120 }} /></Field>
            <div className="seg" style={{ alignSelf: 'flex-end' }}>
              <button className={discType === 'percent' ? 'on' : ''} onClick={() => setDiscType('percent')}>%</button>
              <button className={discType === 'amount' ? 'on' : ''} onClick={() => setDiscType('amount')}>{currency.symbol}</button>
            </div>
          </div>
          <div>
            <div className="sum-row"><span className="muted">{t('form.gross')}</span><span>{m(totals.gross)}</span></div>
            {totals.discount > 0 && <div className="sum-row"><span className="muted">{t('form.discount')}</span><span>− {m(totals.discount)}</span></div>}
            <div className="sum-row"><span className="muted">{t('form.vat')} ({settings.vat_rate} %)</span><span>{m(totals.vat)}</span></div>
            <div className="sum-row"><span className="muted">{t('form.touristTax')}</span><span>{m(totals.tourist)}</span></div>
            <div className="sum-row big"><span>{t('form.totalTtc')}</span><span>{m(totals.total)}</span></div>
          </div>
          {can('payments.create') && (
            <>
              <div className="row" style={{ gap: 6 }}>
                <Field label={`${t('new.deposit')} (DA)`} htmlFor="n-dep"><input id="n-dep" className="input" inputMode="decimal" value={deposit} onChange={(e) => setDeposit(e.target.value)} placeholder="0" style={{ width: 130 }} /></Field>
                <Field label={t('common.method')} htmlFor="n-dm">
                  <select id="n-dm" className="input" value={depMethod} onChange={(e) => setDepMethod(e.target.value)}>{['cash', 'card', 'cheque', 'transfer', 'company_account'].map((x) => <option key={x} value={x}>{t(`pm.${x}` as Key)}</option>)}</select>
                </Field>
              </div>
              {depositN > 0 && depMethod !== 'cash' && <Field label={t('common.reference')} htmlFor="n-dref"><input id="n-dref" className="input" value={depRef} onChange={(e) => setDepRef(e.target.value)} /></Field>}
            </>
          )}
          <div className="sum-row big" style={{ color: 'var(--primary)' }}><span>{t('form.remaining')}</span><span>{m(Math.max(0, totals.total - depositN))}</span></div>
          {depRequired > 0 && (
            <div className={`alert ${depositN >= depRequired ? 'info' : 'warning'}`} style={{ fontSize: 13 }}>
              {t('pol.depositRequired')} ({settings.deposit_policy.percent} %) : <b>{m(depRequired)}</b>
              {depositN < depRequired && status === 'confirmed' && <div>{settings.deposit_policy.mode === 'block' ? t('pol.willBlock') : t('pol.willPending')}</div>}
              {depositN < depRequired && status === 'confirmed' && can('reservations.override_policy') && (
                <label className="row" style={{ gap: 6, marginTop: 6 }}><input type="checkbox" checked={override} onChange={(e) => setOverride(e.target.checked)} /> {t('pol.override')}</label>
              )}
            </div>
          )}
        </div>

      </div>
      {err && <div className="alert danger" role="alert">{err}</div>}
    </Modal>
  );
}
