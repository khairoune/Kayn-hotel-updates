import { useEffect, useRef, useState, type ReactNode } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { HELP, type HelpVideo } from '../lib/help';
import { useI18n, type Key, type Lang } from '../i18n';
import { get, patch, post } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { Field, Icon, Modal } from './ui';

const NAV: { to: string; icon: string; key: Key; perm: string | string[] }[] = [
  { to: '/planning', icon: 'planning', key: 'nav.planning', perm: 'planning.view' },
  { to: '/frontoffice', icon: 'key', key: 'nav.frontoffice', perm: 'reservations.view' },
  { to: '/reservations', icon: 'list', key: 'nav.reservations', perm: 'reservations.view' },
  { to: '/guests', icon: 'users', key: 'nav.guests', perm: 'guests.view' },
  { to: '/billing', icon: 'money', key: 'nav.billing', perm: 'invoices.view' },
  { to: '/rooms', icon: 'door', key: 'nav.rooms', perm: 'rooms.view' },
  { to: '/housekeeping', icon: 'broom', key: 'nav.housekeeping', perm: 'housekeeping.view' },
  { to: '/restaurant', icon: 'fork', key: 'nav.restaurant', perm: 'restaurant.view' },
  { to: '/stock', icon: 'box', key: 'nav.stock', perm: 'stock.view' },
  { to: '/maintenance', icon: 'wrench', key: 'nav.maintenance', perm: 'maintenance.report' },
  { to: '/rh', icon: 'team', key: 'nav.hr', perm: 'hr.self' },
  { to: '/crm', icon: 'heart', key: 'nav.crm', perm: 'crm.view' },
  { to: '/night-audit', icon: 'moon', key: 'nav.nightAudit', perm: 'nightaudit.view' },
  { to: '/rapports', icon: 'chart', key: 'nav.reports', perm: 'reports.view' },
  { to: '/pointage', icon: 'clock', key: 'nav.clock', perm: 'hr.terminal' },
  { to: '/notifications', icon: 'bell', key: 'nav.notifications', perm: 'reservations.view' },
  { to: '/settings', icon: 'gear', key: 'nav.settings', perm: 'settings.manage' },
  { to: '/admin', icon: 'key', key: 'nav.admin', perm: ['admin.view', 'users.manage', 'roles.manage', 'security.manage', 'audit.view', 'backups.manage'] },
];

function useStored<T>(key: string, initial: T): [T, (v: T) => void] {
  const [v, setV] = useState<T>(() => {
    const s = localStorage.getItem(key);
    return s === null ? initial : (JSON.parse(s) as T);
  });
  return [v, (x: T) => { localStorage.setItem(key, JSON.stringify(x)); setV(x); }];
}

export function Layout() {
  const { t, lang, setLang } = useI18n();
  const { me, logout, can } = useAuth();
  const [night, setNight] = useStored('kh.night', false);
  const [mini, setMini] = useStored('kh.navMini', false);
  const [autoFs, setAutoFs] = useStored('kh.autoFs', true);
  const [fs, setFs] = useState(!!document.fullscreenElement);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [pwOpen, setPwOpen] = useState(false);
  const tried = useRef(false);

  useEffect(() => {
    document.documentElement.dataset.theme = night ? 'dark' : 'light';
  }, [night]);
  useEffect(() => {
    const h = () => setFs(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', h);
    return () => document.removeEventListener('fullscreenchange', h);
  }, []);
  useEffect(() => {
    if (me?.must_change_password) setPwOpen(true);
  }, [me?.must_change_password]);

  const goFs = () => document.documentElement.requestFullscreen?.().catch(() => {});
  const toggleFs = () => {
    tried.current = true;
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else goFs();
  };
  const onFirstGesture = () => {
    if (autoFs && !tried.current && !document.fullscreenElement) {
      tried.current = true;
      goFs();
    }
  };
  const changeLang = (l: Lang) => {
    setLang(l);
    patch('/api/auth/language', { language: l }).catch(() => {});
  };

  return (
    <div className="app" onPointerDown={onFirstGesture}>
      <header className="topbar">
        <button className="btn ghost icon show-sm" aria-label="Menu" onClick={() => setMobileOpen(!mobileOpen)}><Icon name="menu" /></button>
        <div className="brand">
          {me?.hotel.logo_id ? <img src={`/api/hotel/logo/${me.hotel.logo_id}`} alt="" style={{ height: 34, maxWidth: 70, objectFit: 'contain', borderRadius: 6 }} /> : <div className="brand-mark">K</div>}
          <div>
            <div className="brand-name">KAYN Hotel</div>
            <div className="brand-sub">{me?.hotel.commercial_name || me?.hotel.name}</div>
          </div>
        </div>
        <div className="spacer" />
        <div className="seg" role="group" aria-label="Langue">
          {(['fr', 'ar', 'en'] as Lang[]).map((l) => (
            <button key={l} className={lang === l ? 'on' : ''} onClick={() => changeLang(l)}>{l === 'ar' ? 'ع' : l.toUpperCase()}</button>
          ))}
        </div>
        <button className="btn hide-sm" onClick={toggleFs} title={fs ? t('top.exitFullscreen') : t('top.fullscreen')}>
          <Icon name={fs ? 'shrink' : 'expand'} size={16} /> {fs ? t('top.exitFullscreen') : t('top.fullscreen')}
        </button>
        <button className="btn" onClick={() => setNight(!night)} aria-label={night ? t('top.day') : t('top.night')}>
          <Icon name={night ? 'sun' : 'moon'} size={16} /> <span className="hide-sm">{night ? t('top.day') : t('top.night')}</span>
        </button>
        <div className="row hide-sm" style={{ gap: 8 }}>
          <div className="brand-mark" style={{ background: 'var(--soft)', color: 'var(--text)', width: 34, height: 34, borderRadius: 99, fontSize: 13 }}>
            {me?.full_name.split(' ').map((p) => p[0]).slice(0, 2).join('')}
          </div>
          <div style={{ lineHeight: 1.15 }}>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{me?.full_name} · {me?.role_name}</div>
            <div className="brand-sub">{me?.device?.name}</div>
          </div>
        </div>
        <Help />
        <Directory />
        <Bell />
        <button className="btn icon" title={t('top.changePassword')} aria-label={t('top.changePassword')} onClick={() => setPwOpen(true)}><Icon name="key" size={16} /></button>
        <button className="btn icon" title={t('top.logout')} aria-label={t('top.logout')} onClick={logout}><Icon name="logout" size={16} /></button>
      </header>
      <div className="body">
        <nav className={`sidebar ${mini ? 'mini' : ''} ${mobileOpen ? 'open' : ''}`} aria-label="Menu principal">
          <button className="nav-item hide-sm" onClick={() => setMini(!mini)} title={mini ? t('nav.expand') : t('nav.collapse')} style={{ color: '#A1A1AA' }}>
            <Icon name={mini ? 'chevR' : 'chevL'} /> <span className="nav-label">{t('nav.collapse')}</span>
          </button>
          {NAV.filter((n) => ([] as string[]).concat(n.perm).some(can)).map((n) => (
            <NavLink key={n.to} to={n.to} end={n.to === '/'} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`} title={t(n.key)} onClick={() => setMobileOpen(false)}>
              <Icon name={n.icon} /> <span className="nav-label">{t(n.key)}</span>
            </NavLink>
          ))}
          <div className="side-foot">
            {!mini && (
              <label className="row" style={{ gap: 8, cursor: 'pointer', color: '#D4D4D8', fontSize: 13 }}>
                <input type="checkbox" checked={autoFs} onChange={(e) => setAutoFs(e.target.checked)} style={{ accentColor: '#C9A227' }} />
                {t('top.autoFs')}
              </label>
            )}
            <span>{mini ? `v${__APP_VERSION__}` : `KAYN Hotel ${__APP_VERSION__} · ${t('app.offline')}`}</span>
          </div>
        </nav>
        <Outlet />
      </div>
      {pwOpen && <ChangePassword forced={!!me?.must_change_password} onClose={() => setPwOpen(false)} />}
    </div>
  );
}

/** Assistant d'aide intégré (hors-ligne) : aide de l'écran courant + recherche dans toutes les fiches. */
function Help() {
  const { t, lang } = useI18n();
  const loc = useLocation();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [openIdx, setOpenIdx] = useState<string | null>(null);
  const L = (p: (typeof HELP)[number]) => (lang === 'ar' ? p.ar : p.fr);
  const cur = HELP.find((p) => p.path === loc.pathname) ?? HELP.find((p) => p.path !== '/' && p.path !== '*' && loc.pathname.startsWith(p.path));
  const norm = (x: string) => x.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const words = norm(q).split(/\s+/).filter(Boolean);
  const results = words.length ? HELP.flatMap((p) => L(p).items.map((it, i) => ({ page: L(p).title, key: `${p.path}#${i}`, it })))
    .filter(({ page, it }) => { const h = norm(`${page} ${it[0]} ${it[1]}`); return words.every((w) => h.includes(w)); }) : [];
  const general = HELP.find((p) => p.path === '*')!;
  const Item = ({ k, it, page }: { k: string; it: [string, string]; page?: string }) => (
    <div style={{ borderBottom: '1px solid var(--border)' }}>
      <button className="btn ghost" style={{ width: '100%', justifyContent: 'space-between', textAlign: 'start', whiteSpace: 'normal', fontWeight: 600 }} onClick={() => setOpenIdx(openIdx === k ? null : k)} aria-expanded={openIdx === k}>
        <span>{page && <span className="muted" style={{ fontWeight: 400 }}>{page} · </span>}{it[0]}</span><span aria-hidden>{openIdx === k ? '−' : '+'}</span>
      </button>
      {openIdx === k && <p style={{ margin: '0 12px 12px', lineHeight: 1.55 }}>{it[1]}</p>}
    </div>
  );
  return (
    <>
      <button className="btn icon" aria-label={t('help.title')} title={t('help.title')} onClick={() => { setOpen(true); setOpenIdx(null); }}><b aria-hidden style={{ fontSize: 15 }}>?</b></button>
      {open && <Modal title={t('help.title')} onClose={() => setOpen(false)} size="lg">
        <input className="input" placeholder={t('help.search')} value={q} onChange={(e) => setQ(e.target.value)} autoFocus style={{ marginBottom: 10 }} />
        <div style={{ maxHeight: '62vh', overflow: 'auto' }}>
          {words.length > 0 ? (<>
            <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>{results.length} {t('help.results')}</div>
            {results.map((r) => <Item key={r.key} k={r.key} it={r.it} page={r.page} />)}
            {!results.length && <p className="muted">{t('help.none')}</p>}
          </>) : (<>
            {(cur?.videos ?? general.videos ?? []).length > 0 && <>
              <h3 style={{ margin: '4px 0 6px' }}>🎬 {t('help.videos')}</h3>
              <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 10, marginBottom: 10 }}>
                {(cur?.videos ?? general.videos ?? []).map((v: HelpVideo) => (
                  <figure key={v.src} style={{ margin: 0 }}>
                    <video src={v.src} poster={v.poster} controls preload="none" style={{ width: '100%', borderRadius: 10, background: '#000', aspectRatio: '16 / 9' }} />
                    <figcaption style={{ fontSize: 13, marginTop: 4 }}><b>{lang === 'ar' ? v.ar : v.fr}</b> <span className="muted">· {v.length}</span></figcaption>
                  </figure>))}
              </div>
            </>}
            {cur && <><h3 style={{ margin: '4px 0 6px' }}>{t('help.thisPage')} : {L(cur).title}</h3>{L(cur).items.map((it, i) => <Item key={i} k={`c${i}`} it={it} />)}</>}
            <h3 style={{ margin: '16px 0 6px' }}>{L(general).title}</h3>
            {L(general).items.map((it, i) => <Item key={i} k={`g${i}`} it={it} />)}
            <h3 style={{ margin: '16px 0 6px' }}>{t('help.allPages')}</h3>
            <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>{HELP.filter((p) => p.path !== '*').map((p) => <button key={p.path} className="btn sm" onClick={() => setQ(L(p).title)}>{L(p).title}</button>)}</div>
          </>)}
        </div>
      </Modal>}
    </>
  );
}

/** Annuaire du personnel : tous les numéros, appel (tel:) et WhatsApp en un clic. */
function Directory() {
  const { t } = useI18n();
  const d = (k: string) => t(`dir.${k}` as Key);
  const [open, setOpen] = useState(false);
  const [rows, setRows] = useState<any[] | null>(null);
  const [q, setQ] = useState('');
  const [dep, setDep] = useState('');
  useEffect(() => { if (open && !rows) get('/api/directory').then(setRows).catch(() => setRows([])); }, [open]);
  const wa = (p: string) => { let x = p.replace(/[^\d+]/g, ''); if (x.startsWith('+')) x = x.slice(1); else if (x.startsWith('00')) x = x.slice(2); else if (x.startsWith('0') && x.length === 10) x = '213' + x.slice(1); return x; };
  const deps = [...new Set((rows ?? []).map((r) => r.department).filter(Boolean))] as string[];
  const list = (rows ?? []).filter((r) => (!dep || r.department === dep) && (!q || `${r.last_name} ${r.first_name} ${r.job_title ?? ''} ${r.phone ?? ''}`.toLowerCase().includes(q.toLowerCase())));
  return (
    <>
      <button className="btn icon" aria-label={d('title')} title={d('title')} onClick={() => setOpen(true)}><span aria-hidden style={{ fontSize: 15 }}>📞</span></button>
      {open && <Modal title={d('title')} onClose={() => setOpen(false)} size="lg">
        <div className="row" style={{ gap: 8, flexWrap: 'wrap', marginBottom: 8 }}>
          <input className="input" style={{ maxWidth: 260 }} placeholder={d('search')} value={q} onChange={(e) => setQ(e.target.value)} autoFocus />
          <select className="input" style={{ maxWidth: 220 }} value={dep} onChange={(e) => setDep(e.target.value)}><option value="">{d('allDeps')}</option>{deps.map((x) => <option key={x}>{x}</option>)}</select>
          <span className="muted" style={{ fontSize: 12 }}>{list.length} {d('people')} · {list.filter((r) => r.phone).length} {d('withPhone')}</span>
        </div>
        {!rows && <span className="muted">…</span>}
        <div style={{ maxHeight: '62vh', overflow: 'auto' }}>
          <table className="table" style={{ fontSize: 13.5 }}>
            <thead><tr><th>{d('name')}</th><th>{d('job')}</th><th>{d('dep')}</th><th>{d('phone')}</th><th /></tr></thead>
            <tbody>{list.map((r) => (
              <tr key={r.key}>
                <td><b>{r.last_name} {r.first_name ?? ''}</b></td>
                <td className="muted">{r.job_title ?? '—'}</td>
                <td className="muted">{r.department ?? '—'}</td>
                <td>{r.phone ? <a href={`tel:${r.phone.replace(/\s/g, '')}`} dir="ltr" style={{ fontWeight: 600 }}>{r.phone}</a> : <span className="muted">{d('noPhone')}</span>}</td>
                <td className="row" style={{ gap: 4 }}>{r.phone && <>
                  <a className="btn sm" href={`tel:${r.phone.replace(/\s/g, '')}`} title={d('call')}>📞</a>
                  <a className="btn sm" href={`https://wa.me/${wa(r.phone)}`} target="_blank" rel="noreferrer" title="WhatsApp">💬</a>
                  <button className="btn sm ghost" title={d('copy')} onClick={() => navigator.clipboard?.writeText(r.phone)}>⧉</button>
                </>}</td>
              </tr>))}
              {rows && !list.length && <tr><td colSpan={5} className="muted">{t('common.none')}</td></tr>}
            </tbody>
          </table>
        </div>
        <p className="muted" style={{ fontSize: 11.5, marginBottom: 0 }}>{d('hint')}</p>
      </Modal>}
    </>
  );
}

/** Cloche : notifications internes réelles (sécurité, stock bas, maintenance, sauvegardes…). */
function Bell() {
  const { t, locale } = useI18n();
  const [d, setD] = useState<any>({ unread: 0, items: [] });
  const [open, setOpen] = useState(false);
  const load = () => get('/api/me/notifications').then(setD).catch(() => {});
  useEffect(() => { load(); const i = setInterval(load, 60_000); return () => clearInterval(i); }, []);
  const COL: Record<string, string> = { danger: '#B91C1C', warning: '#B45309', info: '#1E40AF' };
  return (
    <div style={{ position: 'relative' }}>
      <button className="btn icon" aria-label={t('top.notifs')} title={t('top.notifs')} onClick={() => setOpen(!open)}>
        <Icon name="bell" size={16} />{d.unread > 0 && <span style={{ position: 'absolute', top: -4, insetInlineEnd: -4, background: '#B91C1C', color: '#fff', borderRadius: 99, fontSize: 10, minWidth: 16, height: 16, display: 'grid', placeItems: 'center', padding: '0 4px' }}>{d.unread > 99 ? '99+' : d.unread}</span>}
      </button>
      {open && <div className="card" style={{ position: 'absolute', insetInlineEnd: 0, top: 40, width: 340, maxHeight: 420, overflow: 'auto', zIndex: 50, padding: 8, boxShadow: '0 10px 30px rgba(0,0,0,.18)' }}>
        <div className="row" style={{ padding: '4px 6px' }}><b style={{ flex: 1 }}>{t('top.notifs')}</b>{d.unread > 0 && <button className="btn sm ghost" onClick={() => post('/api/me/notifications/read', { all: true }).then(load)}>{t('top.readAll')}</button>}</div>
        {!d.items.length && <div className="muted" style={{ padding: 8 }}>{t('top.noNotif')}</div>}
        {d.items.map((n: any) => (
          <a key={n.id} href={n.link ?? '#'} onClick={() => { if (!n.read_at) post('/api/me/notifications/read', { ids: [n.id] }).then(load); setOpen(false); }}
            style={{ display: 'block', padding: '8px 6px', borderBottom: '1px solid var(--border)', color: 'inherit', textDecoration: 'none', opacity: n.read_at ? 0.6 : 1, borderInlineStart: `3px solid ${COL[n.severity] ?? '#999'}`, paddingInlineStart: 8 }}>
            <div style={{ fontWeight: n.read_at ? 400 : 600, fontSize: 13 }}>{n.title}</div>
            {n.body && <div className="muted" style={{ fontSize: 12 }}>{n.body}</div>}
            <div className="muted" style={{ fontSize: 11 }}>{new Intl.DateTimeFormat(locale, { dateStyle: 'short', timeStyle: 'short' }).format(new Date(n.created_at))}</div>
          </a>))}
      </div>}
    </div>
  );
}

export function Page({ children, fixed }: { children: ReactNode; fixed?: boolean }) {
  return <main className={`main ${fixed ? 'fixed' : ''}`}>{children}</main>;
}

function ChangePassword({ onClose, forced }: { onClose: () => void; forced: boolean }) {
  const { t } = useI18n();
  const toast = useToast();
  const { refresh } = useAuth();
  const [cur, setCur] = useState('');
  const [next, setNext] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      await post('/api/auth/change-password', { current: cur, next });
      toast('success', 'Mot de passe modifié.');
      await refresh();
      onClose();
    } catch (e: any) {
      toast('error', e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal title={t('top.changePassword')} onClose={forced ? () => {} : onClose} size="sm"
      footer={<>{!forced && <button className="btn" onClick={onClose}>{t('common.cancel')}</button>}<button className="btn primary" disabled={busy || !cur || !next} onClick={submit}>{t('common.save')}</button></>}>
      {forced && <div className="alert info">Première connexion : choisissez un nouveau mot de passe (8 caractères minimum, lettres et chiffres).</div>}
      <Field label="Mot de passe actuel" htmlFor="pw-cur"><input id="pw-cur" className="input" type="password" value={cur} onChange={(e) => setCur(e.target.value)} autoComplete="current-password" /></Field>
      <Field label="Nouveau mot de passe" htmlFor="pw-new"><input id="pw-new" className="input" type="password" value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" /></Field>
    </Modal>
  );
}
