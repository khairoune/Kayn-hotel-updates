import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { useI18n, type Key } from '../i18n';
import { get, newOpKey, postOnce } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, fmtDateTime, money } from '../lib/format';
import { ReasonModal } from './ReservationPanel';
import { Field, Icon, Modal } from './ui';

export const toNum = (v: unknown) => {
  const n = Number(String(v ?? '').replace(/\s/g, '').replace(',', '.'));
  return Number.isFinite(n) ? n : 0;
};
const cents = (v: number) => Math.round(v * 100);
export const INV_STYLE: Record<string, React.CSSProperties> = {
  issued: { background: '#FEE2E2', color: '#991B1B' }, partially_paid: { background: '#FEF3C7', color: '#92400E' }, paid: { background: '#DCFCE7', color: '#166534' },
  credited: { background: 'var(--soft)', color: 'var(--muted)' }, proforma: { background: '#E0E7FF', color: '#3730A3' }, cancelled: { background: 'var(--soft)', color: 'var(--muted)' },
};
export function InvStatus({ s, type }: { s: string; type?: string }) {
  const { t } = useI18n();
  if (type === 'credit_note') return <span className="pill" style={{ background: '#EDE9FE', color: '#5B21B6' }}>{t('bi.t.credit_note')}</span>;
  return <span className="pill" style={INV_STYLE[s]}>{t(`bi.s.${s}` as Key)}</span>;
}
export const openPdf = (id: number) => window.open(`/api/invoices/${id}/pdf`, '_blank');
export const printInv = (id: number) => window.open(`/print/invoice/${id}`, '_blank');
const Sum = ({ l, v, b }: { l: ReactNode; v: ReactNode; b?: boolean }) => <div className={`sum-row ${b ? 'big' : ''}`}><span>{l}</span><span>{v}</span></div>;

/** Champs de paiement communs (carte : 4 derniers chiffres seulement, jamais le numéro complet). */
export function PayFields({ p, set, amountLabel, online }: { p: any; set: (x: any) => void; amountLabel: string; online?: boolean }) {
  const { t } = useI18n();
  const methods = ['cash', 'card', 'cheque', 'transfer', 'company_account', ...(online ? ['online'] : [])];
  return (
    <div className="form-grid">
      <Field label={amountLabel} htmlFor="bp-a"><input id="bp-a" className="input" inputMode="decimal" value={p.amount} onChange={(e) => set({ ...p, amount: e.target.value })} /></Field>
      <Field label={t('common.method')} htmlFor="bp-m"><select id="bp-m" className="input" value={p.method} onChange={(e) => set({ ...p, method: e.target.value })}>{methods.map((m) => <option key={m} value={m}>{t(`pm.${m}` as Key)}</option>)}</select></Field>
      {p.method !== 'cash' && <Field label={p.method === 'card' ? t('pay.auth') : t('common.reference')} htmlFor="bp-r"><input id="bp-r" className="input" value={p.reference} onChange={(e) => set({ ...p, reference: e.target.value })} /></Field>}
      {p.method === 'card' && <Field label={t('pay.last4')} htmlFor="bp-l4"><input id="bp-l4" className="input" inputMode="numeric" maxLength={4} value={p.card_last4 ?? ''} onChange={(e) => set({ ...p, card_last4: e.target.value.replace(/\D/g, '').slice(0, 4) })} /></Field>}
    </div>
  );
}
export const payBody = (p: any) => ({ amount: toNum(p.amount), method: p.method, reference: p.reference || null, card_last4: p.method === 'card' && p.card_last4 ? p.card_last4 : null });

// ===================================================== Détail d'une facture =====================================================
export function InvoiceDrawer({ id, onClose, onChanged }: { id: number; onClose: () => void; onChanged?: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [inv, setInv] = useState<any>(null);
  const [modal, setModal] = useState<null | 'credit' | 'split' | 'pay'>(null);
  const [openId, setOpenId] = useState<number | null>(null);
  const load = useCallback(() => get(`/api/invoices/${id}`).then(setInv).catch((e) => toast('error', e.message)), [id]);
  useEffect(() => { load(); }, [load]);
  const done = () => { setModal(null); load(); onChanged?.(); };
  if (openId) return <InvoiceDrawer id={openId} onClose={() => setOpenId(null)} onChanged={onChanged} />;
  return (
    <>
      <div className="drawer-overlay" onClick={onClose} />
      <aside className="drawer wide" role="dialog" aria-label={inv?.number ?? t('bi.invoices')}>
        {!inv ? <div className="modal-body">{t('common.loading')}</div> : (
          <>
            <div className="modal-head" style={{ alignItems: 'flex-start' }}>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
                <div className="row" style={{ gap: 8 }}><InvStatus s={inv.status} type={inv.type} /><span className="muted" style={{ fontSize: 12 }}>{t(`bi.t.${inv.type}` as Key)} · {fmtDateTime(inv.issued_at, locale)}</span></div>
                <h2 style={{ fontSize: 21 }}>{inv.number}</h2>
                <span className="muted" style={{ fontSize: 13 }}>{inv.bill_to?.name}{inv.reservation ? ` · ${inv.reservation.code}` : ''}</span>
              </div>
              <button className="btn ghost icon" aria-label={t('common.close')} onClick={onClose}><Icon name="close" /></button>
            </div>
            <div className="row" style={{ padding: '0 20px 12px', gap: 6 }}>
              <button className="btn sm" onClick={() => openPdf(inv.id)}><Icon name="print" size={16} /> {t('bi.pdf')}</button>
              <button className="btn sm" onClick={() => printInv(inv.id)}>{t('bi.print')}</button>
              {inv.type === 'invoice' && !inv.reservation_id && inv.due > 0 && can('payments.create') && <button className="btn sm primary" onClick={() => setModal('pay')}>{t('bi.pay')}</button>}
              {inv.type === 'invoice' && inv.status !== 'credited' && can('invoices.credit') && <button className="btn sm" onClick={() => setModal('credit')}>{t('bi.credit')}</button>}
              {inv.type === 'invoice' && inv.status !== 'credited' && !inv.credits.length && can('invoices.credit') && <button className="btn sm" onClick={() => setModal('split')}>{t('bi.split')}</button>}
            </div>
            <div className="modal-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 12 }}>
              {inv.original && <div className="alert">{t('bi.t.credit_note')} — <button className="link" onClick={() => setOpenId(inv.original.id)}>{inv.original.number}</button>{inv.reason ? ` · ${inv.reason}` : ''}</div>}
              <div className="kv">
                <div><span>{t('bi.billTo')}</span><b>{inv.bill_to?.name}</b>{inv.bill_to?.nif && <span>NIF {inv.bill_to.nif}</span>}{inv.bill_to?.address && <span>{inv.bill_to.address}</span>}</div>
                <div><span>{t('bi.stay')}</span><b>{inv.reservation ? `${inv.reservation.code} · ${fmtDate(inv.reservation.check_in, locale, { day: 'numeric', month: 'short' })} → ${fmtDate(inv.reservation.check_out, locale, { day: 'numeric', month: 'short' })}` : '—'}</b></div>
              </div>
              <div style={{ overflow: 'auto' }}>
                <table className="table">
                  <thead><tr><th>{t('ch.desc')}</th><th className="num">{t('bi.qty')}</th><th className="num">{t('bi.unit')}</th><th className="num">{t('bi.vat')}</th><th className="num">{t('bi.amountHt')}</th></tr></thead>
                  <tbody>{inv.items.map((i: any) => (
                    <tr key={i.id}><td className="wrap">{i.description}{Number(i.discount) ? <div className="muted" style={{ fontSize: 12 }}>{t('bi.discount')} − {money(Number(i.discount), locale)}</div> : null}</td>
                      <td className="num">{Number(i.quantity)}</td><td className="num">{money(Number(i.unit_price), locale)}</td><td className="num">{i.kind === 'tourist_tax' ? '—' : `${Number(i.tax_rate)} %`}</td><td className="num">{money(Number(i.total), locale)}</td></tr>
                  ))}</tbody>
                </table>
              </div>
              <div className="section" style={{ marginInlineStart: 'auto', minWidth: 300 }}>
                <Sum l={t('bi.subtotal')} v={money(Number(inv.subtotal), locale)} />
                {Number(inv.discount_total) !== 0 && <Sum l={`dont ${t('bi.discount').toLowerCase()}`} v={`− ${money(Number(inv.discount_total), locale)}`} />}
                {(inv.tax_breakdown ?? []).map((g: any) => <Sum key={g.rate} l={`${t('bi.vat')} ${Number(g.rate)} % / ${money(Number(g.base), locale)}`} v={money(Number(g.tax), locale)} />)}
                {Number(inv.tourist_tax_total) !== 0 && <Sum l={t('bi.tourist')} v={money(Number(inv.tourist_tax_total), locale)} />}
                <Sum l={t('bi.total')} v={money(Number(inv.total), locale)} b />
                {inv.type === 'invoice' && <>
                  {inv.credited > 0 && <Sum l={t('bi.credited')} v={`− ${money(inv.credited, locale)}`} />}
                  <Sum l={t('bi.netPaid')} v={money(inv.net_paid, locale)} />
                  {!inv.reservation_id && <Sum l={t('bi.due')} v={money(inv.due, locale)} b />}
                </>}
              </div>
              {inv.credits.length > 0 && (
                <div className="section"><h3>{t('bi.credited')}</h3>
                  {inv.credits.map((c: any) => <div key={c.id} className="row between"><button className="link" onClick={() => setOpenId(c.id)}>{c.number}</button><span className="muted">{c.reason}</span><b>{money(Number(c.total), locale)}</b></div>)}
                </div>
              )}
              {inv.type === 'invoice' && inv.payments.length > 0 && (
                <div className="section"><h3>{t('res.payments')}</h3>
                  {inv.payments.map((p: any) => <div key={p.id} className="row between" style={{ opacity: p.void ? 0.5 : 1, textDecoration: p.void ? 'line-through' : undefined, fontSize: 13 }}><span>{fmtDateTime(p.received_at, locale)} · {t(`pm.${p.method}` as Key)}{p.card_last4 ? ` ••${p.card_last4}` : ''}{p.reference ? ` · ${p.reference}` : ''}</span><b>{money(Number(p.amount), locale)}</b></div>)}
                  {inv.refunds.map((f: any) => <div key={`r${f.id}`} className="row between" style={{ fontSize: 13 }}><span>{fmtDateTime(f.created_at, locale)} · {t('bi.refund')} · {f.reason}</span><b>− {money(Number(f.amount), locale)}</b></div>)}
                </div>
              )}
              {inv.notes && <p className="muted" style={{ fontSize: 12 }}>{inv.notes}</p>}
            </div>
          </>
        )}
      </aside>
      {modal === 'credit' && inv && <CreditNoteModal inv={inv} onClose={() => setModal(null)} onDone={done} />}
      {modal === 'split' && inv && <SplitModal inv={inv} onClose={() => setModal(null)} onDone={done} />}
      {modal === 'pay' && inv && <InvoicePayModal inv={inv} onClose={() => setModal(null)} onDone={done} />}
    </>
  );
}

function CreditNoteModal({ inv, onClose, onDone }: { inv: any; onClose: () => void; onDone: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('cn'));
  const [mode, setMode] = useState<'commercial' | 'cancel_reissue'>('commercial');
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const canReissue = !inv.credits.length;
  const submit = async () => {
    setBusy(true);
    try {
      const r = await postOnce(`/api/invoices/${inv.id}/credit-note`, { mode, reason, amount: mode === 'commercial' && amount ? toNum(amount) : null }, key);
      toast('success', `${r.number} : ${money(Number(r.total), locale)}`);
      onDone();
    } catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  return (
    <Modal title={`${t('bi.creditTitle')} — ${inv.number}`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={busy || reason.trim().length < 3} onClick={submit}>{t('common.confirm')}</button></>}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <label className="check"><input type="radio" checked={mode === 'commercial'} onChange={() => setMode('commercial')} /> {t('bi.creditCommercial')}</label>
        <label className="check" style={{ opacity: canReissue ? 1 : 0.5 }}><input type="radio" disabled={!canReissue} checked={mode === 'cancel_reissue'} onChange={() => setMode('cancel_reissue')} /> {t('bi.creditReissue')}</label>
        {mode === 'commercial' && <Field label={t('bi.amountTtc')} htmlFor="cn-a"><input id="cn-a" className="input" inputMode="decimal" placeholder={money(Number(inv.total) - inv.credited, locale)} value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>}
        <Field label={`${t('bi.reason')} *`} htmlFor="cn-r"><input id="cn-r" className="input" value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
        <span className="muted" style={{ fontSize: 12.5 }}>La facture d'origine n'est jamais modifiée : l'avoir porte son propre numéro (série AV) et reste lié à la facture.</span>
      </div>
    </Modal>
  );
}

function SplitModal({ inv, onClose, onDone }: { inv: any; onClose: () => void; onDone: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('split'));
  const [parts, setParts] = useState([{ name: inv.bill_to?.name ?? '', amount: '' }, { name: '', amount: '' }]);
  const [busy, setBusy] = useState(false);
  const total = cents(Number(inv.total));
  const given = parts.slice(0, -1).reduce((s, p) => s + cents(toNum(p.amount)), 0);
  const last = total - given;
  const submit = async () => {
    setBusy(true);
    try {
      const body = { reason: 'Partage de la facture', parts: parts.map((p, i) => ({ guest: { kind: 'person', last_name: p.name.trim() }, amount: i < parts.length - 1 ? toNum(p.amount) : undefined })) };
      const r = await postOnce(`/api/invoices/${inv.id}/split`, body, key);
      toast('success', `${r.length} factures : ${r.map((x: any) => x.number).join(', ')}`);
      onDone();
    } catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  return (
    <Modal title={`${t('bi.splitTitle')} — ${inv.number} (${money(Number(inv.total), locale)})`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={busy || last <= 0 || parts.some((p, i) => !p.name.trim() || (i < parts.length - 1 && !(toNum(p.amount) > 0)))} onClick={submit}>{t('common.confirm')}</button></>}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {parts.map((p, i) => (
          <div key={i} className="row" style={{ flexWrap: 'nowrap' }}>
            <input className="input" aria-label={t('bi.client')} placeholder={t('bi.client')} value={p.name} onChange={(e) => setParts(parts.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} />
            {i < parts.length - 1
              ? <input className="input" style={{ width: 150 }} aria-label={t('common.amount')} inputMode="decimal" placeholder="0" value={p.amount} onChange={(e) => setParts(parts.map((x, j) => (j === i ? { ...x, amount: e.target.value } : x)))} />
              : <b style={{ width: 150, textAlign: 'end', color: last <= 0 ? 'var(--danger)' : undefined }}>{money(last / 100, locale)}</b>}
            {parts.length > 2 && <button className="btn ghost icon" aria-label="Retirer" onClick={() => setParts(parts.filter((_, j) => j !== i))}><Icon name="close" /></button>}
          </div>
        ))}
        <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setParts([...parts.slice(0, -1), { name: '', amount: '' }, parts[parts.length - 1]])}><Icon name="plus" size={16} /> {t('bi.addPart')}</button>
        <span className="muted" style={{ fontSize: 12.5 }}>Le dernier client reçoit le reste exact. La facture d'origine est annulée par avoir et une facture est émise par client (TVA répartie au prorata).</span>
      </div>
    </Modal>
  );
}

function InvoicePayModal({ inv, onClose, onDone }: { inv: any; onClose: () => void; onDone: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('ipay'));
  const [p, setP] = useState<any>({ amount: String(inv.due), method: 'cash', reference: '' });
  const [online, setOnline] = useState(false);
  useEffect(() => { get('/api/settings').then((s) => setOnline(!!s.payment_gateway?.enabled)).catch(() => {}); }, []);
  const submit = async () => {
    try { await postOnce(`/api/invoices/${inv.id}/payments`, payBody(p), key); toast('success', `${money(toNum(p.amount), locale)} — ${inv.number}`); onDone(); } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={`${t('bi.pay')} — ${inv.number}`} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!(toNum(p.amount) > 0)} onClick={submit}>{t('common.confirm')}</button></>}>
      <p className="muted">{t('bi.due')} : <b>{money(inv.due, locale)}</b></p>
      <PayFields p={p} set={setP} amountLabel={t('common.amount')} online={online} />
    </Modal>
  );
}

// ===================================================== Facture libre =====================================================
const CATS = ['service', 'restaurant', 'breakfast', 'room_service', 'minibar', 'laundry', 'transfer', 'parking', 'room', 'other'];
export function ManualInvoiceModal({ onClose, onDone }: { onClose: () => void; onDone: (id: number) => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('minv'));
  const [g, setG] = useState({ kind: 'company', name: '', nif: '', address: '', phone: '' });
  const [lines, setLines] = useState([{ description: '', category: 'service', quantity: '1', unit_price: '', discount: '' }]);
  const [rates, setRates] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState(false);
  useEffect(() => { get('/api/settings').then((s) => setRates({ ...Object.fromEntries(CATS.map((c) => [c, Number(s.vat_rate ?? 0)])), ...(s.tax_rates ?? {}) })).catch(() => {}); }, []);
  const upd = (i: number, p: any) => setLines(lines.map((l, j) => (j === i ? { ...l, ...p } : l)));
  const calc = lines.map((l) => {
    const net = Math.round(cents(toNum(l.unit_price)) * toNum(l.quantity)) - cents(toNum(l.discount));
    const r = rates[l.category] ?? 0;
    const tax = Math.sign(net) * Math.floor((Math.abs(net) * Math.round(r * 100) * 2 + 10000) / 20000);
    return { net, tax };
  });
  const ht = calc.reduce((s, c) => s + c.net, 0);
  const tva = calc.reduce((s, c) => s + c.tax, 0);
  const submit = async () => {
    setBusy(true);
    try {
      const guest = g.kind === 'person' ? { kind: 'person', last_name: g.name, phone: g.phone || null, address: g.address || null } : { kind: g.kind, company_name: g.name, nif: g.nif || null, address: g.address || null, phone: g.phone || null };
      const r = await postOnce('/api/invoices/manual', { guest, lines: lines.map((l) => ({ description: l.description, category: l.category, quantity: toNum(l.quantity), unit_price: toNum(l.unit_price), discount: toNum(l.discount) || undefined })) }, key);
      toast('success', `${r.number} : ${money(Number(r.total), locale)}`);
      onDone(r.id);
    } catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  const ok = g.name.trim().length >= 2 && lines.every((l) => l.description.trim().length >= 2 && toNum(l.quantity) > 0 && l.unit_price !== '');
  return (
    <Modal size="lg" title={t('bi.newInvoice')} onClose={onClose}
      footer={<><span className="muted" style={{ marginInlineEnd: 'auto' }}>{t('bi.subtotal')} {money(ht / 100, locale)} · {t('bi.vat')} {money(tva / 100, locale)} · <b>{t('bi.total')} {money((ht + tva) / 100, locale)}</b></span><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!ok || busy} onClick={submit}>{t('common.save')}</button></>}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div className="section">
          <h3>{t('bi.billTo')}</h3>
          <div className="form-grid">
            <Field label={t('bi.type')} htmlFor="mi-k"><select id="mi-k" className="input" value={g.kind} onChange={(e) => setG({ ...g, kind: e.target.value })}><option value="company">Société</option><option value="agency">Agence</option><option value="person">Particulier</option></select></Field>
            <Field label={`${g.kind === 'person' ? t('id.lastName') : 'Raison sociale'} *`} htmlFor="mi-n"><input id="mi-n" className="input" value={g.name} onChange={(e) => setG({ ...g, name: e.target.value })} /></Field>
            {g.kind !== 'person' && <Field label="NIF" htmlFor="mi-nif"><input id="mi-nif" className="input" value={g.nif} onChange={(e) => setG({ ...g, nif: e.target.value })} /></Field>}
            <Field label={t('id.address')} htmlFor="mi-ad"><input id="mi-ad" className="input" value={g.address} onChange={(e) => setG({ ...g, address: e.target.value })} /></Field>
          </div>
        </div>
        <div className="section">
          <h3>{t('bi.lines')}</h3>
          {lines.map((l, i) => (
            <div key={i} className="inv-line">
              <input className="input" aria-label={t('ch.desc')} placeholder={t('ch.desc')} value={l.description} onChange={(e) => upd(i, { description: e.target.value })} />
              <select className="input" aria-label={t('bi.category')} value={l.category} onChange={(e) => upd(i, { category: e.target.value })}>{CATS.map((c) => <option key={c} value={c}>{t(`tax.c.${c}` as Key)} ({rates[c] ?? 0} %)</option>)}</select>
              <input className="input" aria-label={t('bi.qty')} inputMode="decimal" value={l.quantity} onChange={(e) => upd(i, { quantity: e.target.value })} />
              <input className="input" aria-label={t('bi.unit')} placeholder={t('bi.unit')} inputMode="decimal" value={l.unit_price} onChange={(e) => upd(i, { unit_price: e.target.value })} />
              <input className="input" aria-label={t('bi.discount')} placeholder={`${t('bi.discount')} (DA)`} inputMode="decimal" value={l.discount} onChange={(e) => upd(i, { discount: e.target.value })} />
              <b className="num">{money(calc[i].net / 100, locale)}</b>
              <button className="btn ghost icon" aria-label="Retirer" disabled={lines.length === 1} onClick={() => setLines(lines.filter((_, j) => j !== i))}><Icon name="close" /></button>
            </div>
          ))}
          <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={() => setLines([...lines, { description: '', category: 'service', quantity: '1', unit_price: '', discount: '' }])}><Icon name="plus" size={16} /> {t('bi.addLine')}</button>
        </div>
      </div>
    </Modal>
  );
}

// ===================================================== Folio d'un dossier =====================================================
export function FolioTab({ reservationId, onChanged }: { reservationId: number; onChanged: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [f, setF] = useState<any>(null);
  const [inv, setInv] = useState<number | null>(null);
  const [transfer, setTransfer] = useState<any>(null);
  const [voidId, setVoidId] = useState<number | null>(null);
  const [refund, setRefund] = useState(false);
  const load = useCallback(() => get(`/api/reservations/${reservationId}/folio`).then(setF).catch((e) => toast('error', e.message)), [reservationId]);
  useEffect(() => { load(); }, [load]);
  const changed = () => { load(); onChanged(); };
  const act = async (url: string, ok: string) => {
    try { const r = await postOnce(url, {}, newOpKey('f')); toast('success', `${ok}${r?.number ? ` ${r.number}` : ''}`); changed(); if (r?.id) setInv(r.id); } catch (e: any) { toast('error', e.message); }
  };
  if (!f) return <span>{t('common.loading')}</span>;
  const active = f.invoices.find((x: any) => x.type === 'invoice' && x.status !== 'credited');
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div className="row" style={{ gap: 6 }}>
        {can('invoices.create') && !['cancelled', 'no_show'].includes(f.status) && <button className="btn sm" onClick={() => act(`/api/reservations/${reservationId}/invoices/proforma`, t('bi.proforma'))}>{t('bi.proforma')}</button>}
        {can('invoices.create') && ['checked_out', 'cancelled', 'no_show'].includes(f.status) && !active && f.totals.total > 0 && <button className="btn sm primary" onClick={() => act(`/api/reservations/${reservationId}/invoices`, t('bi.t.invoice'))}>{t('bi.stayInvoice')}</button>}
        {can('frontoffice.refund') && f.totals.balance < 0 && <button className="btn sm" onClick={() => setRefund(true)}>{t('bi.refund')} {money(-f.totals.balance, locale)}</button>}
      </div>
      <div className="section">
        <h3>{t('bi.byCategory')}</h3>
        {f.categories.filter((c: any) => c.total !== 0).map((c: any) => <Sum key={c.kind} l={`${c.label}${c.count > 1 ? ` (${c.count})` : ''}`} v={money(c.total, locale)} />)}
        <Sum l={t('co.taxes')} v={money(f.totals.vat + f.totals.tourist, locale)} />
        <Sum l={t('common.total')} v={money(f.totals.total, locale)} b />
        <Sum l={t('common.paid')} v={money(f.totals.paid, locale)} />
        <Sum l={t('common.balance')} v={money(f.totals.balance, locale)} b />
      </div>
      {f.rooms.length > 1 && (
        <div className="section"><h3>{t('bi.roomsBalance')}</h3>
          {f.rooms.map((r: any) => <Sum key={r.rr_id} l={`${t('common.room')} ${r.room} · ${r.guest}${r.scope === 'reservation' ? ' (dossier commun)' : ''}`} v={money(r.balance, locale)} />)}
        </div>
      )}
      <div className="section">
        <h3>{t('co.extras')}</h3>
        {!f.charges.length && <span className="muted">{t('common.none')}</span>}
        {f.charges.map((c: any) => (
          <div key={c.id} className="row between" style={{ fontSize: 13, opacity: c.void ? 0.5 : 1, flexWrap: 'nowrap' }}>
            <span style={{ textDecoration: c.void ? 'line-through' : undefined, minWidth: 0 }}>{fmtDate(c.service_date, locale, { day: 'numeric', month: 'short' })} · {c.description} × {Number(c.quantity)} <span className="muted">· {t('bi.vat')} {Number(c.tax_rate)} %</span>{c.void && c.void_reason ? <span className="muted"> — {c.void_reason}</span> : null}</span>
            <span className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
              <b>{money(Number(c.total), locale)}</b>
              {!c.void && c.kind !== 'adjustment' && !['checked_out', 'cancelled', 'no_show'].includes(f.status) && can('frontoffice.charges') && <button className="btn sm ghost" onClick={() => setTransfer(c)}>{t('bi.transfer')}</button>}
              {!c.void && c.kind !== 'adjustment' && f.status !== 'checked_out' && can('payments.void') && <button className="btn sm ghost danger" onClick={() => setVoidId(c.id)} aria-label="Annuler">×</button>}
            </span>
          </div>
        ))}
      </div>
      {f.invoices.length > 0 && (
        <div className="section"><h3>{t('bi.invoices')}</h3>
          {f.invoices.map((i: any) => <div key={i.id} className="row between" style={{ fontSize: 13 }}><button className="link" onClick={() => setInv(i.id)}>{i.number}</button><InvStatus s={i.status} type={i.type} /><b>{money(Number(i.total), locale)}</b></div>)}
        </div>
      )}
      {inv && <InvoiceDrawer id={inv} onClose={() => setInv(null)} onChanged={changed} />}
      {transfer && <TransferModal charge={transfer} targets={f.transfer_targets} onClose={() => setTransfer(null)} onDone={() => { setTransfer(null); changed(); }} />}
      {voidId && <ReasonModal title="Annuler la prestation" onClose={() => setVoidId(null)} onSubmit={(reason) => postOnce(`/api/charges/${voidId}/void`, { reason }, newOpKey('v')).then(() => { setVoidId(null); changed(); }).catch((e) => toast('error', e.message))} />}
      {refund && <RefundModal reservationId={reservationId} max={-f.totals.balance} onClose={() => setRefund(false)} onDone={() => { setRefund(false); changed(); }} />}
    </div>
  );
}

function TransferModal({ charge, targets, onClose, onDone }: { charge: any; targets: any[]; onClose: () => void; onDone: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('tr'));
  const [to, setTo] = useState('');
  const [reason, setReason] = useState('');
  const submit = async () => {
    const tg = targets.find((x) => String(x.rr_id) === to);
    try { await postOnce(`/api/charges/${charge.id}/transfer`, { reservation_id: tg.reservation_id, reservation_room_id: tg.rr_id, reason }, key); toast('success', `${charge.description} → ${tg.label}`); onDone(); } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={`${t('bi.transfer')} — ${charge.description} (${money(Number(charge.total), locale)})`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!to || reason.trim().length < 2} onClick={submit}>{t('common.confirm')}</button></>}>
      <Field label={t('bi.transferTo')} htmlFor="tr-to"><select id="tr-to" className="input" value={to} onChange={(e) => setTo(e.target.value)}><option value="">—</option>{targets.filter((x) => x.rr_id !== charge.reservation_room_id).map((x) => <option key={x.rr_id} value={x.rr_id}>{x.label}</option>)}</select></Field>
      <div style={{ marginTop: 10 }}><Field label={`${t('bi.reason')} *`} htmlFor="tr-r"><input id="tr-r" className="input" value={reason} onChange={(e) => setReason(e.target.value)} /></Field></div>
    </Modal>
  );
}

export function RefundModal({ reservationId, max, onClose, onDone }: { reservationId: number; max: number; onClose: () => void; onDone: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [key] = useState(() => newOpKey('rf'));
  const [x, setX] = useState({ amount: String(max), method: 'cash', reason: '' });
  const submit = async () => {
    try { await postOnce(`/api/reservations/${reservationId}/refunds`, { amount: toNum(x.amount), method: x.method, reason: x.reason }, key); toast('success', `${t('bi.refund')} ${money(toNum(x.amount), locale)}`); onDone(); } catch (e: any) { toast('error', e.message); }
  };
  return (
    <Modal title={`${t('bi.refund')} (max ${money(max, locale)})`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={!(toNum(x.amount) > 0) || toNum(x.amount) > max || x.reason.trim().length < 3} onClick={submit}>{t('common.confirm')}</button></>}>
      <div className="form-grid">
        <Field label={t('common.amount')} htmlFor="rf-a"><input id="rf-a" className="input" inputMode="decimal" value={x.amount} onChange={(e) => setX({ ...x, amount: e.target.value })} /></Field>
        <Field label={t('common.method')} htmlFor="rf-m"><select id="rf-m" className="input" value={x.method} onChange={(e) => setX({ ...x, method: e.target.value })}>{['cash', 'card', 'cheque', 'transfer'].map((m) => <option key={m} value={m}>{t(`pm.${m}` as Key)}</option>)}</select></Field>
      </div>
      <div style={{ marginTop: 10 }}><Field label={`${t('bi.reason')} *`} htmlFor="rf-r"><input id="rf-r" className="input" value={x.reason} onChange={(e) => setX({ ...x, reason: e.target.value })} /></Field></div>
    </Modal>
  );
}
