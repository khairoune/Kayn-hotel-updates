import { CrmSummary } from './CrmCard';
import { useCallback, useEffect, useState } from 'react';
import { useI18n, type Key } from '../i18n';
import { get, newOpKey, post, postOnce } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, fmtDateTime, money, todayLocal } from '../lib/format';
import { EditReservation } from './EditReservation';
import { FolioTab } from './Billing';
import { ChargeModal, CheckInWizard, CheckOutModal, ExtendModal, printRegistration, RoomChangeModal } from './FrontDesk';
import { Field, Icon, Modal, StatusPill } from './ui';

const ACTIONS: Record<string, string> = {
  create: 'Création', update: 'Modification', move: 'Déplacement / dates', confirm: 'Confirmation', cancel: 'Annulation', no_show: 'Non-présentation',
  check_in: 'Check-in', check_out: 'Check-out', void: 'Annulation de paiement',
};

export function ReservationPanel({ id, onClose, onChanged }: { id: number; onClose: () => void; onChanged: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [r, setR] = useState<any>(null);
  const [tab, setTab] = useState<'details' | 'folio' | 'payments' | 'history' | 'notifications'>('details');
  const [notifs, setNotifs] = useState<any[] | null>(null);
  const [editing, setEditing] = useState(false);
  const [history, setHistory] = useState<any[] | null>(null);
  const [modal, setModal] = useState<null | 'pay' | 'cancel' | 'noshow'>(null);
  const [busy, setBusy] = useState(false);
  const [voidId, setVoidId] = useState<number | null>(null);
  const [fo, setFo] = useState<null | { kind: 'checkin' | 'checkout' | 'move' | 'extend' | 'charge'; rr?: number }>(null);

  const load = useCallback(async () => {
    try {
      setR(await get(`/api/reservations/${id}`));
    } catch (e: any) {
      toast('error', e.message);
      onClose();
    }
  }, [id]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    if (tab === 'history') get(`/api/reservations/${id}/history`).then(setHistory).catch((e) => toast('error', e.message));
    if (tab === 'notifications') get(`/api/notifications?reservation_id=${id}`).then(setNotifs).catch((e) => toast('error', e.message));
  }, [tab, id, r?.updated_at]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && !modal && !editing && onClose();
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [modal, editing, onClose]);

  const run = async (fn: () => Promise<any>, ok: string) => {
    setBusy(true);
    try {
      const res = await fn();
      toast('success', ok);
      if (res?.invoice) window.open(`/print/invoice/${res.invoice.id}`, '_blank');
      await load();
      onChanged();
    } catch (e: any) {
      toast('error', e.message);
    } finally {
      setBusy(false);
    }
  };

  const today = todayLocal();
  return (
    <>
      <div className="drawer-overlay" onClick={onClose} />
      <aside className="drawer" role="dialog" aria-label={t('res.details')}>
        {!r ? (
          <div className="modal-body">{t('common.loading')}</div>
        ) : (
          <>
            <div className="modal-head" style={{ alignItems: 'flex-start' }}>
              <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 6 }}>
                <div className="row" style={{ gap: 8 }}>
                  <StatusPill status={r.status} label={t(`st.${r.status}` as Key)} />
                  <span className="muted" style={{ fontSize: 12 }}>{r.code} · {t(`bt.${r.booker_type}` as Key)}</span>
                </div>
                <h2 style={{ fontSize: 19 }}>{r.guest_name}</h2>
                {r.payer && <span className="muted" style={{ fontSize: 13 }}>{t('new.company')} : {r.payer.company_name}</span>}
                {r.group_name && <span className="muted" style={{ fontSize: 13 }}>{t('new.group')} : {r.group_name}</span>}
              </div>
              <button className="btn ghost icon" aria-label={t('common.close')} onClick={onClose}><Icon name="close" /></button>
            </div>
            <div className="tabs">
              {(['details', 'folio', 'payments', 'history', 'notifications'] as const).map((k) => (
                <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{t(`res.${k}` as Key)}</button>
              ))}
            </div>
            <div className="modal-body" style={{ flex: 1 }}>
              {tab === 'details' && (
                <>
                  <div className="kv">
                    <div><span>{t('res.arrival')}</span><b>{fmtDate(r.check_in, locale)}</b></div>
                    <div><span>{t('res.departure')}</span><b>{fmtDate(r.check_out, locale)}</b></div>
                    <div><span>{t('res.meal')}</span><b>{t(`meal.${r.meal_plan}` as Key)}</b></div>
                    <div><span>{t('res.persons')}</span><b>{r.adults + r.children}</b></div>
                    <div><span>{t('res.source')}</span><b>{t(`src.${r.source}` as Key)}</b></div>
                    <div><span>{t('new.phone')}</span><b>{r.guest.phone ?? '—'}</b></div>
                  </div>
                  {r.guest?.id && <CrmSummary guestId={r.guest.id} reservationId={r.id} onChanged={() => { load?.(); onChanged?.(); }} />}
                  {r.rooms.map((rr: any) => (
                    <div key={rr.id} className="card" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
                      <div className="row between">
                        <b>{t('common.room')} {rr.room_number} · {rr.room_type}{rr.occupant_name ? ` · ${rr.occupant_name}` : ''}</b>
                        <StatusPill status={rr.status} label={t(`st.${rr.status}` as Key)} />
                      </div>
                      <span className="muted" style={{ fontSize: 13 }}>{fmtDate(rr.check_in, locale)} → {fmtDate(rr.check_out, locale)} · {rr.nights} {t('common.nights')} × {money(rr.rate, locale)}</span>
                      <div className="row">
                        {can('frontoffice.checkin') && ['pending', 'confirmed'].includes(rr.status) && rr.check_in <= today && (
                          <button className="btn primary sm" onClick={() => setFo({ kind: 'checkin', rr: rr.id })}>{t('res.checkin')}</button>
                        )}
                        {can('frontoffice.checkout') && rr.status === 'checked_in' && (
                          <button className="btn primary sm" onClick={() => setFo({ kind: 'checkout', rr: rr.id })}>{t('res.checkout')}</button>
                        )}
                        {rr.status === 'checked_in' && can('frontoffice.charges') && <button className="btn sm" onClick={() => setFo({ kind: 'charge', rr: rr.id })}>+ {t('fo.charge')}</button>}
                        {['pending', 'confirmed', 'checked_in'].includes(rr.status) && can('reservations.edit') && <button className="btn sm ghost" onClick={() => setFo({ kind: 'move', rr: rr.id })}>{t('fo.move')}</button>}
                        {['pending', 'confirmed', 'checked_in'].includes(rr.status) && can('reservations.edit') && <button className="btn sm ghost" onClick={() => setFo({ kind: 'extend', rr: rr.id })}>{t('fo.extend')}</button>}
                        {rr.stay_id && <button className="btn sm ghost" onClick={() => printRegistration(rr.id)}>{t('fo.card')}</button>}
                      </div>
                    </div>
                  ))}
                  <div className="card" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {r.discount_total > 0 && <div className="row between"><span className="muted">{t('form.discount')}</span><span>− {money(r.discount_total, locale)}</span></div>}
                    {r.tax_total > 0 && <div className="row between"><span className="muted">{t('form.taxes')}</span><span>{money(r.tax_total, locale)}</span></div>}
                    <div className="row between"><span className="muted">{t('common.total')}</span><b>{money(r.total, locale)}</b></div>
                    <div className="row between"><span className="muted">{t('res.deposits')}</span><span>{money(r.deposits, locale)}</span></div>
                    <div className="row between"><span className="muted">{t('common.paid')}</span><b>{money(r.paid - r.refunded, locale)}</b></div>
                    <div className="row between"><b>{t('common.balance')}</b>
                      <span className="pill" style={r.balance > 0 ? { background: '#F59E0B', color: '#3B1D02' } : { background: '#0E7490', color: '#fff' }}>
                        {r.balance > 0 ? money(r.balance, locale) : r.balance < 0 ? `Avoir ${money(-r.balance, locale)}` : t('common.settled')}
                      </span>
                    </div>
                  </div>
                  {r.deposit_required > 0 && (
                    <div className={`alert ${r.paid - r.refunded >= r.deposit_required ? 'info' : 'warning'}`}>
                      {t('pol.depositRequired')} : <b>{money(r.deposit_required, locale)}</b> · {t('common.paid')} : {money(r.paid - r.refunded, locale)}
                    </div>
                  )}
                  {r.cancellation_fee > 0 && <div className="alert danger">{t('pol.fee')} : <b>{money(r.cancellation_fee, locale)}</b></div>}
                  {r.special_requests && <div className="alert warning"><b>{t('form.special')} :</b> {r.special_requests}</div>}
                  {r.notes && <div className="alert info"><b>{t('form.internal')} :</b> {r.notes}</div>}
                  {r.cancel_reason && <div className="alert danger">{t('common.reason')} : {r.cancel_reason}</div>}
                </>
              )}
              {tab === 'folio' && <FolioTab reservationId={r.id} onChanged={async () => { await load(); onChanged(); }} />}
              {tab === 'payments' && (
                <>
                  {r.payments.length === 0 && <span className="muted">{t('common.none')}</span>}
                  {r.payments.map((p: any) => (
                    <div key={p.id} className="row between card" style={{ padding: 10, opacity: p.void ? 0.55 : 1 }}>
                      <div>
                        <b style={{ textDecoration: p.void ? 'line-through' : undefined }}>{money(p.amount, locale)}</b> · {t(`pm.${p.method}` as Key)}{p.kind === 'deposit' ? ' · acompte' : ''}
                        <div className="muted" style={{ fontSize: 12 }}>{fmtDateTime(p.received_at, locale)} · {p.received_by_name}{p.reference ? ` · ${p.reference}` : ''}</div>
                        {p.void && <div style={{ fontSize: 12, color: 'var(--danger)' }}>Annulé : {p.void_reason}</div>}
                      </div>
                      {!p.void && can('payments.void') && (
                        <button className="btn sm danger" onClick={() => setVoidId(p.id)}>{t('common.cancel')}</button>
                      )}
                    </div>
                  ))}
                  {r.invoices.map((i: any) => (
                    <a key={i.id} className="btn" href={`/print/invoice/${i.id}`} target="_blank" rel="noreferrer"><Icon name="print" size={16} /> {t('res.invoice')} {i.number} · {money(i.total, locale)}</a>
                  ))}
                </>
              )}
              {tab === 'notifications' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {!notifs && t('common.loading')}
                  {notifs?.length === 0 && <span className="muted">Aucun message : ajoutez un téléphone ou un e-mail au client.</span>}
                  {notifs?.map((n) => <NotificationRow key={n.id} n={n} onChange={() => get(`/api/notifications?reservation_id=${id}`).then(setNotifs)} />)}
                </div>
              )}
              {tab === 'history' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {!history && t('common.loading')}
                  {history?.map((h) => (
                    <div key={h.id} style={{ fontSize: 13, borderInlineStart: '3px solid var(--gold)', paddingInlineStart: 10 }}>
                      <b>{ACTIONS[h.action] ?? h.action}</b> <span className="muted">· {h.entity}</span>
                      <div className="muted" style={{ fontSize: 12 }}>{fmtDateTime(h.created_at, locale)} · {h.user_name ?? 'système'}</div>
                      {h.action === 'move' && h.before && <div style={{ fontSize: 12 }}>{h.before.check_in} → {h.before.check_out} ⇒ {h.after.check_in} → {h.after.check_out}</div>}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="modal-foot" style={{ justifyContent: 'flex-start' }}>
              {can('payments.create') && !['cancelled', 'no_show'].includes(r.status) && <button className="btn primary" onClick={() => setModal('pay')}><Icon name="money" size={16} /> {t('res.pay')}</button>}
              {can('reservations.edit') && r.status === 'pending' && <button className="btn" disabled={busy} onClick={() => run(() => post(`/api/reservations/${r.id}/confirm`), 'Réservation confirmée.')}>{t('res.confirm')}</button>}
              {can('reservations.override_policy') && r.status === 'pending' && r.deposit_required > r.paid - r.refunded && <button className="btn ghost" disabled={busy} onClick={() => run(() => post(`/api/reservations/${r.id}/confirm`, { override: true }), 'Réservation confirmée (dérogation tracée).')}>{t('pol.confirmAnyway')}</button>}
              {can('reservations.edit') && <button className="btn" onClick={() => setEditing(true)}>{t('res.edit')}</button>}
              <a className="btn" href={`/print/reservation/${r.id}`} target="_blank" rel="noreferrer"><Icon name="print" size={16} /> {t('res.voucher')}</a>
              <a className="btn" href={`/api/reservations/${r.id}/voucher.pdf`} target="_blank" rel="noreferrer">{t('res.voucherPdf')}</a>
              {can('reservations.cancel') && ['pending', 'confirmed'].includes(r.status) && r.check_in <= today && <button className="btn danger" onClick={() => setModal('noshow')}>{t('res.noshow')}</button>}
              {can('reservations.cancel') && ['pending', 'confirmed'].includes(r.status) && <button className="btn danger" onClick={() => setModal('cancel')}>{t('res.cancel')}</button>}
            </div>
          </>
        )}
      </aside>
      {editing && r && <EditReservation r={r} onClose={() => setEditing(false)} onSaved={async () => { await load(); onChanged(); }} />}
      {voidId !== null && (
        <ReasonModal title="Annuler le paiement" onClose={() => setVoidId(null)}
          onSubmit={(reason) => run(() => post(`/api/payments/${voidId}/void`, { reason }), 'Paiement annulé (tracé dans le journal).').then(() => setVoidId(null))} />
      )}
      {fo?.kind === 'checkin' && <CheckInWizard rrId={fo.rr} onClose={() => setFo(null)} onDone={async () => { await load(); onChanged(); }} />}
      {fo?.kind === 'checkout' && <CheckOutModal rrId={fo.rr!} onClose={() => setFo(null)} onDone={async () => { await load(); onChanged(); }} />}
      {fo?.kind === 'move' && <RoomChangeModal rrId={fo.rr!} onClose={() => setFo(null)} onDone={async () => { await load(); onChanged(); }} />}
      {fo?.kind === 'extend' && <ExtendModal rrId={fo.rr!} onClose={() => setFo(null)} onDone={async () => { await load(); onChanged(); }} />}
      {fo?.kind === 'charge' && r && <ChargeModal reservationId={r.id} rrId={fo.rr} onClose={() => setFo(null)} onDone={async () => { await load(); onChanged(); }} />}
      {modal === 'pay' && r &&<PaymentModal reservation={r} onClose={() => setModal(null)} onDone={async () => { setModal(null); await load(); onChanged(); }} />}
      {(modal === 'cancel' || modal === 'noshow') && r && (
        <CancelModal r={r} noShow={modal === 'noshow'} onClose={() => setModal(null)}
          onSubmit={(reason, waive) => run(() => post(`/api/reservations/${r.id}/${modal === 'cancel' ? 'cancel' : 'no-show'}`, { reason, waive_fee: waive || undefined }), modal === 'cancel' ? 'Réservation annulée, dates libérées.' : 'Non-présentation enregistrée.').then(() => setModal(null))} />
      )}
    </>
  );
}

export function PaymentModal({ reservation, onClose, onDone }: { reservation: any; onClose: () => void; onDone: () => void }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const [amount, setAmount] = useState(reservation.balance > 0 ? String(reservation.balance) : '');
  const [method, setMethod] = useState('cash');
  const [kind, setKind] = useState(reservation.status === 'checked_in' || reservation.status === 'checked_out' ? 'payment' : 'deposit');
  const [ref, setRef] = useState('');
  const [rrId, setRrId] = useState<number | 0>(0);
  const [last4, setLast4] = useState('');
  const [online, setOnline] = useState(false);
  const [busy, setBusy] = useState(false);
  const [key] = useState(() => newOpKey('pay'));
  useEffect(() => { get('/api/settings').then((x) => setOnline(!!x.payment_gateway?.enabled)).catch(() => {}); }, []);
  const submit = async () => {
    setBusy(true);
    try {
      await postOnce(`/api/reservations/${reservation.id}/payments`, { amount: Number(amount.replace(/\s/g, '').replace(',', '.')), method, kind, reference: ref || null, reservation_room_id: rrId || null, card_last4: method === 'card' && last4 ? last4 : null }, key);
      toast('success', `Paiement de ${money(Number(amount), locale)} enregistré.`);
      onDone();
    } catch (e: any) {
      toast('error', e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal title={`${t('res.pay')} — ${reservation.guest_name}`} onClose={onClose} size="sm"
      footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={busy || !(Number(amount) > 0)} onClick={submit}>{t('common.save')}</button></>}>
      <div className="row between"><span className="muted">{t('common.balance')}</span><b>{money(reservation.balance, locale)}</b></div>
      <Field label={`${t('common.amount')} (DA)`} htmlFor="pay-amount"><input id="pay-amount" className="input" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} autoFocus /></Field>
      <Field label={t('common.method')} htmlFor="pay-method">
        <select id="pay-method" className="input" value={method} onChange={(e) => setMethod(e.target.value)}>
          {['cash', 'card', 'cheque', 'transfer', 'company_account', ...(online ? ['online'] : [])].map((m) => <option key={m} value={m}>{t(`pm.${m}` as Key)}</option>)}
        </select>
      </Field>
      {reservation.rooms.length > 1 && (
        <Field label={t('common.room')} htmlFor="pay-room">
          <select id="pay-room" className="input" value={rrId} onChange={(e) => setRrId(Number(e.target.value))}>
            <option value={0}>Toute la réservation</option>
            {reservation.rooms.filter((x: any) => !['cancelled', 'no_show'].includes(x.status)).map((x: any) => <option key={x.id} value={x.id}>{x.room_number}{x.occupant_name ? ` · ${x.occupant_name}` : ''}</option>)}
          </select>
        </Field>
      )}
      <div className="seg">
        <button className={kind === 'deposit' ? 'on' : ''} onClick={() => setKind('deposit')}>Acompte</button>
        <button className={kind === 'payment' ? 'on' : ''} onClick={() => setKind('payment')}>Règlement</button>
      </div>
      {(method === 'cheque' || method === 'transfer' || method === 'card' || method === 'online') && (
        <Field label={(method === 'card' ? t('pay.auth') : t('common.reference')) + (method === 'card' ? '' : ' *')} htmlFor="pay-ref"><input id="pay-ref" className="input" value={ref} onChange={(e) => setRef(e.target.value)} /></Field>
      )}
      {method === 'card' && <Field label={t('pay.last4')} htmlFor="pay-l4"><input id="pay-l4" className="input" inputMode="numeric" maxLength={4} value={last4} onChange={(e) => setLast4(e.target.value.replace(/\D/g, '').slice(0, 4))} /></Field>}
    </Modal>
  );
}

export function ReasonModal({ title, defaultReason, onClose, onSubmit }: { title: string; defaultReason?: string; onClose: () => void; onSubmit: (r: string) => void }) {
  const { t } = useI18n();
  const [reason, setReason] = useState(defaultReason ?? '');
  return (
    <Modal title={title} onClose={onClose} size="sm"
      footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={reason.trim().length < 2} onClick={() => onSubmit(reason.trim())}>{t('common.confirm')}</button></>}>
      <Field label={t('common.reason')} htmlFor="reason"><textarea id="reason" className="input" rows={3} value={reason} onChange={(e) => setReason(e.target.value)} autoFocus /></Field>
    </Modal>
  );
}

export function NotificationRow({ n, onChange, showGuest }: { n: any; onChange: () => void; showGuest?: boolean }) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const act = async (a: string) => {
    try { await post(`/api/notifications/${n.id}/${a}`); onChange(); } catch (e: any) { toast('error', e.message); }
  };
  const colors: Record<string, { bg: string; fg: string }> = {
    pending: { bg: '#FEF3C7', fg: '#92400E' }, sent: { bg: '#E0F2F1', fg: '#0B5563' }, failed: { bg: '#FEE2E2', fg: '#991B1B' }, cancelled: { bg: '#E7E5E4', fg: '#44403C' },
  };
  const c = colors[n.status];
  const [lang, setLang] = useState<string>(n.language ?? 'fr');
  const [view, setView] = useState<{ subject: string; body: string; whatsapp_url: string | null } | null>(null);
  const pickLang = async (l: string) => {
    setLang(l);
    if (l === n.language) { setView(null); return; }
    try { setView(await get(`/api/notifications/${n.id}/preview?lang=${l}`)); } catch (e: any) { toast('error', e.message); }
  };
  const subject = view?.subject ?? n.subject;
  const body = view?.body ?? n.body;
  const waUrl = view?.whatsapp_url ?? n.whatsapp_url;
  return (
    <div className="card" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 6, opacity: n.status === 'cancelled' ? 0.6 : 1 }}>
      <div className="row between">
        <b>{t(`notif.k.${n.kind}` as Key)} · {n.channel === 'whatsapp' ? 'WhatsApp' : 'E-mail'}{showGuest ? ` · ${n.guest_name} (${n.code})` : ''}</b>
        <span className="pill" style={{ background: c.bg, color: c.fg }}>{t(`notif.s.${n.status}` as Key)}</span>
      </div>
      <span className="muted" style={{ fontSize: 12 }}>{n.recipient} · {fmtDateTime(n.created_at, locale)}{n.last_error && n.status === 'pending' ? ` · ${n.last_error}` : ''}</span>
      <div className="row between">
        <div className="seg" role="group" aria-label="Langue du message">
          {['fr', 'en', 'ar'].map((l) => <button key={l} className={lang === l ? 'on' : ''} onClick={() => pickLang(l)}>{l === 'ar' ? 'ع' : l.toUpperCase()}</button>)}
        </div>
      </div>
      <details open={!!view}><summary style={{ cursor: 'pointer', fontSize: 13 }} dir={lang === 'ar' ? 'rtl' : 'ltr'}>{subject}</summary><pre dir={lang === 'ar' ? 'rtl' : 'ltr'} style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit', fontSize: 13, margin: '8px 0 0' }}>{body}</pre></details>
      {n.status === 'pending' && (
        <div className="row">
          {waUrl && <a className="btn sm primary" href={waUrl} target="_blank" rel="noreferrer" onClick={() => setTimeout(() => act('mark-sent'), 400)}>{t('notif.sendWa')}</a>}
          <button className="btn sm" onClick={() => act('mark-sent')}>{t('notif.markSent')}</button>
          <button className="btn sm ghost" onClick={() => act('cancel')}>{t('common.cancel')}</button>
        </div>
      )}
      {n.status === 'failed' && <button className="btn sm" onClick={() => act('retry')}>{t('notif.retry')}</button>}
    </div>
  );
}

function CancelModal({ r, noShow, onClose, onSubmit }: { r: any; noShow: boolean; onClose: () => void; onSubmit: (reason: string, waive: boolean) => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const [reason, setReason] = useState(noShow ? 'Client non présenté' : '');
  const [waive, setWaive] = useState(false);
  const [q, setQ] = useState<any>(null);
  useEffect(() => { get(`/api/reservations/${r.id}/cancellation-quote${noShow ? '?no_show=true' : ''}`).then(setQ).catch(() => {}); }, [r.id, noShow]);
  const fee = q?.applies && !waive ? q.fee : 0;
  const paid = q?.paid ?? 0;
  return (
    <Modal title={noShow ? t('res.noshow') : t('res.cancel')} onClose={onClose} size="sm"
      footer={<><button className="btn" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={reason.trim().length < 2} onClick={() => onSubmit(reason.trim(), waive)}>{t('common.confirm')}</button></>}>
      {q && (
        <div className={`alert ${q.applies ? 'warning' : 'info'}`}>
          {!noShow && <div>{t('pol.hoursLeft')} : <b>{Math.max(0, Math.round(q.hours_before_arrival))} h</b></div>}
          {q.applies ? <div>{t('pol.fee')} : <b>{money(q.fee, locale)}</b></div> : <div>{t('pol.noFee')}</div>}
          <div>{t('common.paid')} : {money(paid, locale)}</div>
          <div><b>{fee - paid >= 0 ? t('pol.toPay') : t('pol.refund')} : {money(Math.abs(fee - paid), locale)}</b></div>
        </div>
      )}
      {q?.applies && can('reservations.override_policy') && (
        <label className="row" style={{ gap: 8, fontSize: 14 }}><input type="checkbox" checked={waive} onChange={(e) => setWaive(e.target.checked)} /> {t('pol.waive')}</label>
      )}
      <Field label={t('common.reason')} htmlFor="c-reason"><textarea id="c-reason" className="input" rows={3} value={reason} onChange={(e) => setReason(e.target.value)} autoFocus /></Field>
    </Modal>
  );
}
