import { useCallback, useEffect, useRef, useState } from 'react';
import { useI18n, type Key } from '../i18n';
import { del, get, patch, post, upload } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate, fmtDateTime, money, todayLocal } from '../lib/format';
import { ReasonModal } from './ReservationPanel';
import { Field, HK_COLORS, Icon, Modal } from './ui';

/** Couleurs d'occupation (distinctes de la propreté). */
export const ROOM_STATUS_COLORS: Record<string, { bg: string; fg: string }> = {
  available: { bg: '#DCFCE7', fg: '#166534' },
  reserved: { bg: '#FEF3C7', fg: '#92400E' },
  occupied: { bg: '#1E3A8A', fg: '#FFFFFF' },
  maintenance: { bg: '#FFEDD5', fg: '#9A3412' },
  out_of_service: { bg: '#3F3F46', fg: '#FFFFFF' },
  inactive: { bg: '#E7E5E4', fg: '#57534E' },
};

export function RoomStatusPill({ status }: { status: string }) {
  const { t } = useI18n();
  const c = ROOM_STATUS_COLORS[status] ?? ROOM_STATUS_COLORS.available;
  return <span className="pill" style={{ background: c.bg, color: c.fg }}>{t(`rs.${status}` as Key)}</span>;
}

export function HkPill({ hk }: { hk: string }) {
  const { t } = useI18n();
  return <span className="pill" style={{ background: 'transparent', color: HK_COLORS[hk] ?? '#555', border: `1px solid ${HK_COLORS[hk] ?? '#999'}` }}><span style={{ width: 7, height: 7, borderRadius: 9, background: HK_COLORS[hk] }} />{t(`hk.${hk}` as Key)}</span>;
}

export const amenityName = (a: any, lang: string) => (lang === 'ar' ? a.name_ar : lang === 'en' ? a.name_en : a.name_fr) || a.name_fr;
export const toNum = (v: unknown) => {
  const n = Number(String(v ?? '').replace(/\s/g, '').replace(',', '.'));
  return Number.isFinite(n) ? n : 0;
};
const optNum = (v: unknown) => (v === '' || v === null || v === undefined ? null : toNum(v));

// ================= Galerie photos =================
export function PhotoStrip({ photos, ownerType, ownerId, editable, onChanged }: { photos: any[]; ownerType: 'room' | 'room_type'; ownerId: number; editable: boolean; onChanged: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [zoom, setZoom] = useState<number | null>(null);
  const onFile = async (files: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    try {
      for (const f of Array.from(files)) await upload('/api/photos', f, { owner_type: ownerType, owner_id: String(ownerId) });
      toast('success', 'Photo ajoutée.');
      onChanged();
    } catch (e: any) {
      toast('error', e.message);
    } finally {
      setBusy(false);
      if (ref.current) ref.current.value = '';
    }
  };
  const remove = async (id: number) => {
    if (!confirm('Supprimer cette photo ?')) return;
    try { await del(`/api/photos/${id}`); onChanged(); } catch (e: any) { toast('error', e.message); }
  };
  return (
    <div className="photo-strip">
      {photos.map((p) => (
        <div key={p.id} className="photo">
          <img src={`/api/photos/${p.id}`} alt="" loading="lazy" onClick={() => setZoom(p.id)} />
          {editable && <button className="photo-del" aria-label="Supprimer la photo" onClick={() => remove(p.id)}><Icon name="close" size={14} /></button>}
        </div>
      ))}
      {editable && (
        <button className="photo add" onClick={() => ref.current?.click()} disabled={busy}>
          <Icon name="plus" /> <span>{busy ? '…' : t('rm.addPhoto')}</span>
        </button>
      )}
      {!editable && !photos.length && <span className="muted" style={{ fontSize: 13 }}>{t('common.none')}</span>}
      <input ref={ref} type="file" accept="image/jpeg,image/png,image/webp" multiple hidden onChange={(e) => onFile(e.target.files)} />
      {zoom && (
        <div className="overlay" onClick={() => setZoom(null)} style={{ zIndex: 300 }}>
          <img src={`/api/photos/${zoom}`} alt="" style={{ maxWidth: '92vw', maxHeight: '88vh', borderRadius: 12 }} />
        </div>
      )}
    </div>
  );
}

// ================= Sélecteur d'équipements =================
export function AmenityPicker({ amenities, value, onChange }: { amenities: any[]; value: number[]; onChange: (v: number[]) => void }) {
  const { lang } = useI18n();
  return (
    <div className="row" style={{ gap: 6 }}>
      {amenities.filter((a) => a.active || value.includes(a.id)).map((a) => {
        const on = value.includes(a.id);
        return (
          <button type="button" key={a.id} className={`chip ${on ? 'on' : ''}`} aria-pressed={on} onClick={() => onChange(on ? value.filter((x) => x !== a.id) : [...value, a.id])}>
            {on ? '✓ ' : ''}{amenityName(a, lang)}
          </button>
        );
      })}
    </div>
  );
}

// ================= Formulaire chambre =================
export function RoomForm({ room, onClose, onSaved }: { room: any | null; onClose: () => void; onSaved: (id: number) => void }) {
  const { t, lang } = useI18n();
  const toast = useToast();
  const [ref, setRef] = useState<{ types: any[]; floors: any[]; amenities: any[] } | null>(null);
  const [f, setF] = useState<any>(() => room ? {
    number: room.number, floor_id: room.floor_id, room_type_id: room.room_type_id, capacity: room.capacity ?? '', beds: room.beds ?? '',
    description: room.description ?? '', features: room.features ?? [], amenity_ids: (room.amenities ?? []).map((a: any) => a.id), rate_supplement: room.rate_supplement ?? 0, notes: room.notes ?? '',
  } : { number: '', floor_id: '', room_type_id: '', capacity: '', beds: '', description: '', features: [], amenity_ids: null, rate_supplement: 0, notes: '' });
  const [feat, setFeat] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    Promise.all([get('/api/room-types/manage'), get('/api/floors/stats'), get('/api/amenities')])
      .then(([types, floors, amenities]) => {
        setRef({ types, floors, amenities });
        if (!room) setF((x: any) => ({ ...x, floor_id: x.floor_id || floors[0]?.id || '', room_type_id: x.room_type_id || types.find((y: any) => y.active)?.id || '' }));
      })
      .catch((e) => toast('error', e.message));
  }, []);
  const type = ref?.types.find((x) => x.id === Number(f.room_type_id));
  // Nouvelle chambre : les équipements du type sont proposés par défaut
  const amenityIds: number[] = f.amenity_ids ?? (type?.amenity_ids ?? []);
  const set = (p: any) => setF({ ...f, ...p });
  const addFeat = () => {
    const v = feat.trim();
    if (v && !f.features.includes(v)) set({ features: [...f.features, v] });
    setFeat('');
  };

  const save = async () => {
    setBusy(true);
    try {
      const body = {
        number: String(f.number).trim(), floor_id: Number(f.floor_id), room_type_id: Number(f.room_type_id),
        capacity: optNum(f.capacity), beds: optNum(f.beds), description: f.description || null, features: f.features,
        amenity_ids: amenityIds, rate_supplement: toNum(f.rate_supplement), notes: f.notes || null,
      };
      const r = room ? await patch(`/api/rooms/${room.id}`, body) : await post('/api/rooms', body);
      toast('success', room ? 'Chambre mise à jour.' : `Chambre ${body.number} créée — visible dans le planning.`);
      onSaved(room?.id ?? r.id);
    } catch (e: any) {
      toast('error', e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title={room ? `${t('rm.edit')} ${room.number}` : t('rm.new')} onClose={onClose} size="lg"
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={busy || !ref || !String(f.number).trim()} onClick={save}>{t('common.save')}</button></>}>
      {!ref ? t('common.loading') : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="section">
            <h3>{t('rm.tInfo')}</h3>
            <div className="form-grid">
              <Field label={t('rm.number')} htmlFor="rf-num"><input id="rf-num" className="input" value={f.number} onChange={(e) => set({ number: e.target.value })} autoFocus={!room} /></Field>
              <Field label={`${t('rm.building')} / ${t('rm.floor')}`} htmlFor="rf-floor">
                <select id="rf-floor" className="input" value={f.floor_id} onChange={(e) => set({ floor_id: e.target.value })}>
                  {ref.floors.map((x) => <option key={x.id} value={x.id}>{x.building_name} — {x.name}</option>)}
                </select>
              </Field>
              <Field label={t('rm.type')} htmlFor="rf-type">
                <select id="rf-type" className="input" value={f.room_type_id} onChange={(e) => set({ room_type_id: e.target.value })}>
                  {ref.types.filter((x) => x.active || x.id === room?.room_type_id).map((x) => <option key={x.id} value={x.id}>{x.name} — {money(x.base_rate)}</option>)}
                </select>
              </Field>
              <Field label={`${t('rm.capacity')} (${type?.capacity ?? '—'} par défaut)`} htmlFor="rf-cap"><input id="rf-cap" className="input" inputMode="numeric" placeholder={String(type?.capacity ?? '')} value={f.capacity} onChange={(e) => set({ capacity: e.target.value })} /></Field>
              <Field label={`${t('rm.beds')} (${type?.beds ?? '—'} par défaut)`} htmlFor="rf-beds"><input id="rf-beds" className="input" inputMode="numeric" placeholder={String(type?.beds ?? '')} value={f.beds} onChange={(e) => set({ beds: e.target.value })} /></Field>
              <Field label={t('rm.supplement')} htmlFor="rf-sup"><input id="rf-sup" className="input" inputMode="decimal" value={f.rate_supplement} onChange={(e) => set({ rate_supplement: e.target.value })} /></Field>
            </div>
            <Field label={t('rm.description')} htmlFor="rf-desc"><textarea id="rf-desc" className="input" rows={2} value={f.description} onChange={(e) => set({ description: e.target.value })} /></Field>
          </div>
          <div className="section">
            <h3>{t('rm.features')}</h3>
            <div className="row" style={{ gap: 6 }}>
              {f.features.map((x: string) => (
                <span key={x} className="pill" style={{ background: 'var(--gold-soft)', color: 'var(--gold-text)' }}>{x}
                  <button className="btn ghost sm" style={{ padding: 0, minHeight: 0 }} aria-label={`Retirer ${x}`} onClick={() => set({ features: f.features.filter((y: string) => y !== x) })}>×</button>
                </span>
              ))}
            </div>
            <div className="row">
              <input className="input" style={{ flex: 1, minWidth: 200 }} placeholder={t('rm.featuresHint')} value={feat} onChange={(e) => setFeat(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addFeat(); } }} />
              <button className="btn" onClick={addFeat}>{t('common.add')}</button>
            </div>
          </div>
          <div className="section">
            <h3>{t('rm.amenities')}</h3>
            <AmenityPicker amenities={ref.amenities} value={amenityIds} onChange={(v) => set({ amenity_ids: v })} />
            {!room && f.amenity_ids === null && <span className="muted" style={{ fontSize: 12 }}>Équipements du type {type?.name} proposés par défaut ({lang.toUpperCase()}).</span>}
          </div>
        </div>
      )}
    </Modal>
  );
}

// ================= Hors service / maintenance datée =================
export function BlockModal({ room, onClose, onDone }: { room: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  // Chambre occupée : le blocage commence au départ du client
  const start = room.current?.check_out && room.current.check_out > todayLocal() ? room.current.check_out.slice(0, 10) : todayLocal();
  const [b, setB] = useState({ kind: 'out_of_service', start_date: start, end_date: '', reason: '', priority: 'normal' });
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      await post(`/api/rooms/${room.id}/blocks`, { ...b, end_date: b.end_date || null });
      toast('success', 'Blocage enregistré, ticket de maintenance créé. Le planning est mis à jour.');
      onDone();
    } catch (e: any) {
      toast('error', e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal title={`${t('rm.block')} — ${room.number}`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={busy || b.reason.trim().length < 2} onClick={submit}>{t('common.confirm')}</button></>}>
      <div className="form-grid">
        <Field label={t('rm.blockKind')} htmlFor="bk-kind">
          <select id="bk-kind" className="input" value={b.kind} onChange={(e) => setB({ ...b, kind: e.target.value })}>
            <option value="out_of_service">{t('rm.kOos')}</option><option value="maintenance">{t('rm.kMaint')}</option>
          </select>
        </Field>
        <Field label={t('rm.priority')} htmlFor="bk-pr">
          <select id="bk-pr" className="input" value={b.priority} onChange={(e) => setB({ ...b, priority: e.target.value })}>
            {['low', 'normal', 'high', 'urgent'].map((p) => <option key={p} value={p}>{t(`rm.p.${p}` as Key)}</option>)}
          </select>
        </Field>
        <Field label={t('rm.from')} htmlFor="bk-from"><input id="bk-from" type="date" className="input" value={b.start_date} onChange={(e) => setB({ ...b, start_date: e.target.value })} /></Field>
        <Field label={t('rm.to')} htmlFor="bk-to"><input id="bk-to" type="date" className="input" min={b.start_date} value={b.end_date} onChange={(e) => setB({ ...b, end_date: e.target.value })} /></Field>
      </div>
      <div style={{ marginTop: 12 }}>
        <Field label={t('common.reason')} htmlFor="bk-reason"><input id="bk-reason" className="input" placeholder="Ex. : fuite salle de bain, climatiseur en panne…" value={b.reason} onChange={(e) => setB({ ...b, reason: e.target.value })} /></Field>
      </div>
      <p className="muted" style={{ fontSize: 12.5, marginBottom: 0 }}>
        Hors service : la chambre ne peut pas être réservée sur ces dates (refus si une réservation existe déjà). Maintenance : intervention planifiée, la chambre reste vendable.
      </p>
    </Modal>
  );
}

export function TicketModal({ room, onClose, onDone }: { room: any; onClose: () => void; onDone: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [x, setX] = useState({ title: '', description: '', priority: 'normal', category: 'other' });
  const submit = async () => {
    try {
      await post(`/api/rooms/${room.id}/tickets`, { ...x, description: x.description || null });
      toast('success', 'Incident enregistré.');
      onDone();
    } catch (e: any) {
      toast('error', e.message);
    }
  };
  const CATS: Record<string, string> = { plumbing: 'Plomberie', electricity: 'Électricité', hvac: 'Climatisation / chauffage', furniture: 'Mobilier', it: 'TV / Wi-Fi', cleaning: 'Propreté', other: 'Autre' };
  return (
    <Modal title={`${t('rm.ticket')} — ${room.number}`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>{t('common.cancel')}</button><button className="btn primary" disabled={x.title.trim().length < 2} onClick={submit}>{t('common.save')}</button></>}>
      <div className="form-grid">
        <Field label={t('rm.ticketTitle')} htmlFor="tk-t"><input id="tk-t" className="input" value={x.title} onChange={(e) => setX({ ...x, title: e.target.value })} autoFocus /></Field>
        <Field label="Catégorie" htmlFor="tk-c">
          <select id="tk-c" className="input" value={x.category} onChange={(e) => setX({ ...x, category: e.target.value })}>
            {Object.entries(CATS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
        <Field label={t('rm.priority')} htmlFor="tk-p">
          <select id="tk-p" className="input" value={x.priority} onChange={(e) => setX({ ...x, priority: e.target.value })}>
            {['low', 'normal', 'high', 'urgent'].map((p) => <option key={p} value={p}>{t(`rm.p.${p}` as Key)}</option>)}
          </select>
        </Field>
      </div>
      <div style={{ marginTop: 12 }}>
        <Field label={t('rm.description')} htmlFor="tk-d"><textarea id="tk-d" className="input" rows={3} value={x.description} onChange={(e) => setX({ ...x, description: e.target.value })} /></Field>
      </div>
    </Modal>
  );
}

// ================= Fiche chambre (panneau latéral) =================
type Tab = 'info' | 'res' | 'guests' | 'cleaning' | 'maint' | 'log';
export function RoomSheet({ id, onClose, onOpenReservation }: { id: number; onClose: () => void; onOpenReservation?: (id: number) => void }) {
  const { t, locale, lang } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [r, setR] = useState<any>(null);
  const [tab, setTab] = useState<Tab>('info');
  const [modal, setModal] = useState<null | 'edit' | 'block' | 'ticket' | 'deactivate'>(null);
  const [releaseId, setReleaseId] = useState<number | null>(null);
  const [resolveId, setResolveId] = useState<number | null>(null);

  const load = useCallback(() => get(`/api/rooms/${id}`).then(setR).catch((e) => toast('error', e.message)), [id]);
  useEffect(() => { setR(null); load(); }, [load]);
  const run = async (fn: () => Promise<unknown>, ok: string) => {
    try { await fn(); toast('success', ok); await load(); } catch (e: any) { toast('error', e.message); }
  };
  const manage = can('rooms.manage');
  const maint = can('maintenance.manage');
  const activeBlocks = (r?.blocks ?? []).filter((b: any) => b.status === 'active');
  const openTickets = (r?.tickets ?? []).filter((x: any) => ['new', 'assigned', 'in_progress', 'waiting_parts'].includes(x.status));
  const resLink = (x: any) => onOpenReservation
    ? <button className="btn ghost sm" style={{ padding: '0 4px' }} onClick={() => onOpenReservation(x.reservation_id)}>{x.code}</button>
    : <span className="muted">{x.code}</span>;

  return (
    <>
      <div className="drawer-overlay" onClick={onClose} />
      <aside className="drawer wide" role="dialog" aria-label={t('rm.sheet')}>
        {!r ? <div className="modal-body">{t('common.loading')}</div> : (
          <>
            <div className="modal-head" style={{ alignItems: 'flex-start' }}>
              <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 6 }}>
                <div className="row" style={{ gap: 8 }}>
                  <RoomStatusPill status={r.status} />
                  {r.active && <HkPill hk={r.hk_status} />}
                </div>
                <h2 style={{ fontSize: 22 }}>{t('common.room')} {r.number} <span className="muted" style={{ fontSize: 15, fontWeight: 500 }}>· {r.type.name}</span></h2>
                <span className="muted" style={{ fontSize: 13 }}>{r.building_name} · {r.floor_name}</span>
              </div>
              <button className="btn ghost icon" aria-label={t('common.close')} onClick={onClose}><Icon name="close" /></button>
            </div>
            <div className="row" style={{ padding: '0 20px 12px', gap: 6 }}>
              {manage && r.active && <button className="btn sm" onClick={() => setModal('edit')}>{t('common.edit')}</button>}
              {maint && r.active && <button className="btn sm" onClick={() => setModal('block')}>{t('rm.block')}</button>}
              {maint && <button className="btn sm" onClick={() => setModal('ticket')}>{t('rm.ticket')}</button>}
              {manage && (r.active
                ? <button className="btn sm ghost danger" onClick={() => setModal('deactivate')}>{t('rm.deactivate')}</button>
                : <button className="btn sm primary" onClick={() => run(() => post(`/api/rooms/${r.id}/reactivate`), 'Chambre réactivée, de nouveau réservable.')}>{t('rm.reactivate')}</button>)}
            </div>
            {!r.active && <div className="alert" style={{ margin: '0 20px 12px' }}>{t('rs.inactive')} — {r.deactivation_reason}</div>}
            {activeBlocks.map((b: any) => (
              <div key={b.id} className="alert" style={{ margin: '0 20px 10px', display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
                <span style={{ flex: 1 }}><b>{b.kind === 'out_of_service' ? t('rs.out_of_service') : t('rs.maintenance')}</b> · {fmtDate(b.start_date, locale)} → {b.end_date ? fmtDate(b.end_date, locale) : '…'} · {b.reason}</span>
                {maint && <button className="btn sm" onClick={() => setReleaseId(b.id)}>{t('rm.release')}</button>}
              </div>
            ))}
            <div className="tabs" style={{ overflowX: 'auto' }}>
              {(['info', 'res', 'guests', 'cleaning', 'maint', 'log'] as Tab[]).map((k) => {
                const key = { info: 'rm.tInfo', res: 'rm.tRes', guests: 'rm.tGuests', cleaning: 'rm.tCleaning', maint: 'rm.tMaint', log: 'rm.tLog' }[k] as Key;
                const badge = k === 'res' ? r.upcoming.length : k === 'maint' ? openTickets.length : 0;
                return <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{t(key)}{badge ? ` (${badge})` : ''}</button>;
              })}
            </div>
            <div className="modal-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 14 }}>
              {tab === 'info' && (
                <>
                  <div className="kv">
                    <div><span>{t('rm.type')}</span><b>{r.type.name} ({r.type.code})</b></div>
                    <div><span>{t('rm.priceTonight')}</span><b>{money(r.price_tonight?.price, locale)}</b></div>
                    <div><span>{t('rm.capacity')}</span><b>{r.eff_capacity} pers. · {r.type.max_adults} ad. / {r.type.max_children} enf.</b></div>
                    <div><span>{t('rm.beds')}</span><b>{r.eff_beds}{r.type.bed_type ? ` · ${r.type.bed_type}` : ''}</b></div>
                    <div><span>{t('ty.area')}</span><b>{r.type.area_m2 ? `${r.type.area_m2} m²` : '—'}</b></div>
                    <div><span>{t('rm.supplement')}</span><b>{Number(r.rate_supplement) ? money(r.rate_supplement, locale) : '—'}</b></div>
                  </div>
                  {r.current && (
                    <div className="card" style={{ padding: 12, borderInlineStart: '4px solid #1E3A8A' }}>
                      <div className="muted" style={{ fontSize: 12 }}>{t('rm.current')}</div>
                      <div className="row between"><b>{r.current.guest_name}</b>{resLink(r.current)}</div>
                      <span style={{ fontSize: 13 }}>{fmtDate(r.current.check_in, locale)} → {fmtDate(r.current.check_out, locale)}</span>
                    </div>
                  )}
                  {(r.description || r.features?.length > 0) && (
                    <div className="section">
                      <h3>{t('rm.description')}</h3>
                      {r.description && <p style={{ margin: 0, fontSize: 14 }}>{r.description}</p>}
                      <div className="row" style={{ gap: 6 }}>{(r.features ?? []).map((x: string) => <span key={x} className="pill" style={{ background: 'var(--gold-soft)', color: 'var(--gold-text)' }}>{x}</span>)}</div>
                    </div>
                  )}
                  <div className="section">
                    <h3>{t('rm.amenities')} ({r.amenities.length})</h3>
                    <div className="row" style={{ gap: 6 }}>
                      {r.amenities.length ? r.amenities.map((a: any) => <span key={a.id} className="chip" style={{ cursor: 'default' }}>{amenityName(a, lang)}</span>) : <span className="muted">{t('common.none')}</span>}
                    </div>
                  </div>
                  <div className="section">
                    <h3>{t('rm.photos')}</h3>
                    <PhotoStrip photos={r.photos} ownerType="room" ownerId={r.id} editable={manage} onChanged={load} />
                    {r.type_photos.length > 0 && <><span className="muted" style={{ fontSize: 12 }}>Photos du type {r.type.name}</span><PhotoStrip photos={r.type_photos} ownerType="room_type" ownerId={r.type.id} editable={false} onChanged={load} /></>}
                  </div>
                </>
              )}
              {tab === 'res' && (
                <List empty={!r.upcoming.length && !r.current}>
                  {r.current && <Line left={<><b>{r.current.guest_name}</b> {resLink(r.current)}</>} right={<span className="pill" style={{ background: '#1E3A8A', color: '#fff' }}>{t('rs.occupied')}</span>} sub={`${fmtDate(r.current.check_in, locale)} → ${fmtDate(r.current.check_out, locale)}`} />}
                  {r.upcoming.map((x: any) => <Line key={x.rr_id} left={<><b>{x.guest_name}</b> {resLink(x)}</>} right={<span className={`pill st-${x.status}`}>{t(`st.${x.status}` as Key)}</span>} sub={`${fmtDate(x.check_in, locale)} → ${fmtDate(x.check_out, locale)}`} />)}
                </List>
              )}
              {tab === 'guests' && (
                <List empty={!r.history.length}>
                  {r.history.map((x: any) => <Line key={x.rr_id} left={<><b>{x.guest_name}</b> {resLink(x)}</>} right={<span className="num">{money(x.rate, locale)}</span>} sub={`${fmtDate(x.check_in, locale)} → ${fmtDate(x.check_out, locale)}`} />)}
                </List>
              )}
              {tab === 'cleaning' && (
                <List empty={!r.cleaning.length}>
                  {r.cleaning.map((x: any) => (
                    <Line key={x.id} left={<b>{({ checkout_clean: 'Ménage départ', stayover: 'Recouche', inspection: 'Inspection', deep_clean: 'Grand ménage' } as any)[x.kind] ?? x.kind}</b>}
                      right={<span className="pill" style={{ background: x.status === 'done' ? 'var(--ok-bg)' : 'var(--warn-bg)', color: x.status === 'done' ? 'var(--ok)' : 'var(--warn-text)' }}>{({ todo: 'À faire', in_progress: 'En cours', done: 'Terminé', cancelled: 'Annulé' } as any)[x.status]}</span>}
                      sub={`${fmtDateTime(x.created_at, locale)}${x.completed_at ? ` → ${fmtDateTime(x.completed_at, locale)}` : ''}${x.completed_by_name ? ` · ${x.completed_by_name}` : ''}`} />
                  ))}
                </List>
              )}
              {tab === 'maint' && (
                <>
                  <List empty={!r.tickets.length}>
                    {r.tickets.map((x: any) => (
                      <div key={x.id} className="card" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 4 }}>
                        <div className="row between"><b>{x.title}</b><span className="pill" style={TICKET_STYLE[x.status]}>{x.number ? `${x.number} · ` : ''}{t(`mt.ts_${x.status}` as Key)}</span></div>
                        <span className="muted" style={{ fontSize: 12.5 }}>{t(`rm.p.${x.priority}` as Key)} · {fmtDateTime(x.created_at, locale)} · {x.reported_by_name ?? '—'}</span>
                        {x.description && <span style={{ fontSize: 13 }}>{x.description}</span>}
                        {x.resolution && <span style={{ fontSize: 13 }}>✓ {x.resolution} {x.resolved_by_name ? `— ${x.resolved_by_name}` : ''}</span>}
                        {maint && ['new', 'assigned', 'in_progress', 'waiting_parts'].includes(x.status) && (
                          <div className="row" style={{ gap: 6 }}>
                            {['new', 'assigned'].includes(x.status) && <button className="btn sm" onClick={() => run(() => post(`/api/tickets/${x.id}/start`), 'Intervention en cours.')}>{t('rm.start')}</button>}
                            <button className="btn sm primary" onClick={() => setResolveId(x.id)}>{t('rm.resolve')}</button>
                          </div>
                        )}
                      </div>
                    ))}
                  </List>
                  {r.blocks.length > 0 && <h4 style={{ margin: '6px 0 0' }}>Blocages</h4>}
                  {r.blocks.map((b: any) => (
                    <Line key={b.id} left={<b>{b.kind === 'out_of_service' ? t('rs.out_of_service') : t('rs.maintenance')} · {b.reason}</b>}
                      right={<span className="pill" style={b.status === 'active' ? { background: '#3F3F46', color: '#fff' } : { background: 'var(--soft)' }}>{b.status === 'active' ? 'Actif' : 'Levé'}</span>}
                      sub={`${fmtDate(b.start_date, locale)} → ${b.end_date ? fmtDate(b.end_date, locale) : '…'} · ${b.created_by_name ?? ''}${b.released_at ? ` · levé le ${fmtDateTime(b.released_at, locale)}` : ''}`} />
                  ))}
                </>
              )}
              {tab === 'log' && (
                <List empty={!r.changes.length}>
                  {r.changes.map((x: any, i: number) => <Line key={i} left={<b>{LOG_LABEL[x.action] ?? x.action}</b>} right={<span className="muted" style={{ fontSize: 12 }}>{x.user_name ?? 'Système'}</span>} sub={`${fmtDateTime(x.created_at, locale)}${x.after ? ' · ' + summarize(x.after) : ''}`} />)}
                </List>
              )}
            </div>
          </>
        )}
      </aside>
      {modal === 'edit' && r && <RoomForm room={r} onClose={() => setModal(null)} onSaved={() => { setModal(null); load(); }} />}
      {modal === 'block' && r && <BlockModal room={r} onClose={() => setModal(null)} onDone={() => { setModal(null); load(); }} />}
      {modal === 'ticket' && r && <TicketModal room={r} onClose={() => setModal(null)} onDone={() => { setModal(null); setTab('maint'); load(); }} />}
      {modal === 'deactivate' && r && (
        <ReasonModal title={`${t('rm.deactivate')} ${r.number}`} onClose={() => setModal(null)}
          onSubmit={(reason) => run(() => post(`/api/rooms/${r.id}/deactivate`, { reason }), 'Chambre désactivée : retirée du planning, historique conservé.').then(() => setModal(null))} />
      )}
      {releaseId && (
        <ReasonModal title={t('rm.release')} defaultReason="Intervention terminée" onClose={() => setReleaseId(null)}
          onSubmit={(resolution) => run(() => post(`/api/room-blocks/${releaseId}/release`, { resolution, needs_cleaning: true }), 'Chambre remise en service — marquée « À nettoyer ».').then(() => setReleaseId(null))} />
      )}
      {resolveId && (
        <ReasonModal title={t('rm.resolution')} onClose={() => setResolveId(null)}
          onSubmit={(resolution) => run(() => post(`/api/tickets/${resolveId}/resolve`, { resolution }), 'Incident résolu.').then(() => setResolveId(null))} />
      )}
    </>
  );
}

const TICKET_STYLE: Record<string, React.CSSProperties> = {
  open: { background: '#FEE2E2', color: '#991B1B' }, new: { background: '#FEE2E2', color: '#991B1B' }, assigned: { background: '#DBEAFE', color: '#1E40AF' }, in_progress: { background: '#FEF3C7', color: '#92400E' },
  waiting_parts: { background: '#FFEDD5', color: '#9A3412' }, closed: { background: '#E2E8F0', color: '#334155' },
  resolved: { background: '#DCFCE7', color: '#166534' }, cancelled: { background: 'var(--soft)', color: 'var(--muted)' },
};
const LOG_LABEL: Record<string, string> = {
  create: 'Création', update: 'Modification', deactivate: 'Désactivation', reactivate: 'Réactivation', out_of_service: 'Mise hors service',
  maintenance: 'Maintenance planifiée', back_in_service: 'Remise en service', incident: 'Incident signalé', housekeeping: 'Propreté', add_photo: 'Photo ajoutée', delete_photo: 'Photo supprimée',
};
function summarize(o: any) {
  if (!o || typeof o !== 'object') return '';
  return Object.entries(o).filter(([, v]) => v !== null && typeof v !== 'object').slice(0, 4).map(([k, v]) => `${k}: ${v}`).join(', ');
}
function List({ empty, children }: { empty: boolean; children: React.ReactNode }) {
  const { t } = useI18n();
  return empty ? <span className="muted">{t('common.none')}</span> : <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>{children}</div>;
}
function Line({ left, right, sub }: { left: React.ReactNode; right?: React.ReactNode; sub?: string }) {
  return (
    <div className="card" style={{ padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 2 }}>
      <div className="row between" style={{ flexWrap: 'nowrap' }}><span style={{ minWidth: 0 }}>{left}</span>{right}</div>
      {sub && <span className="muted" style={{ fontSize: 12.5 }}>{sub}</span>}
    </div>
  );
}
