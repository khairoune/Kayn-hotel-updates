import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useI18n, type Key } from '../i18n';
import { get, post } from '../lib/api';
import { useAuth, useToast } from '../lib/context';
import { fmtDate } from '../lib/format';

export const CRM_STATUS_COLORS: Record<string, [string, string]> = { standard: ['#F1F5F9', '#475569'], loyal: ['#DCFCE7', '#166534'], vip: ['#7A1F2B', '#FFFFFF'], company: ['#DBEAFE', '#1E40AF'] };
export function CrmStatus({ s }: { s: string }) {
  const { t } = useI18n();
  const [bg, fg] = CRM_STATUS_COLORS[s] ?? CRM_STATUS_COLORS.standard;
  return <span className="pill" style={{ background: bg, color: fg }}>{t(`crm.st_${s}` as Key)}</span>;
}

/** Résumé CRM affiché à la réservation et au check-in : statut, fidélité, préférences, occasions, réclamations ouvertes. */
export function CrmSummary({ guestId, reservationId, onChanged }: { guestId: number; reservationId?: number; onChanged?: () => void }) {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const toast = useToast();
  const [s, setS] = useState<any>(null);
  useEffect(() => { if (guestId && (can('guests.view') || can('crm.view'))) get(`/api/crm/clients/${guestId}/summary`).then(setS).catch(() => {}); }, [guestId]);
  if (!s) return null;
  const memberDiscount = async () => {
    try { const r = await post(`/api/crm/reservations/${reservationId}/member-discount`, {}); toast('success', `${t('crm.memberDiscountApplied')} ${r.percent} %`); onChanged?.(); } catch (e: any) { toast('error', e.message); }
  };
  const important = s.status === 'vip' || s.open_complaints.length > 0 || s.occasions.length > 0;
  return (
    <div className="card" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 6, borderInlineStart: `4px solid ${important ? '#C9A227' : 'var(--border)'}`, background: important ? 'var(--gold-soft, #FBF6E9)' : undefined }}>
      <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
        <b style={{ fontSize: 13 }}>{t('crm.profile')}</b><CrmStatus s={s.status} />
        {s.tier && <span className="pill" style={{ background: s.tier.color, color: '#fff' }}>{s.tier.name} · {s.points} pts</span>}
        {!s.tier && s.loyalty_number && <span className="pill">{s.points} pts</span>}
        <span className="muted" style={{ fontSize: 12 }}>{s.stays} {t('crm.staysShort')}{s.last_stay ? ` · ${t('crm.lastStay')} ${fmtDate(String(s.last_stay).slice(0, 10), locale, { day: 'numeric', month: 'short', year: 'numeric' })}` : ''}</span>
        {can('crm.view') && <Link to={`/crm?tab=clients&id=${s.id}`} className="btn ghost sm" style={{ marginInlineStart: 'auto' }}>{s.code} →</Link>}
      </div>
      {s.occasions.map((o: any, i: number) => <div key={i} style={{ fontSize: 13, color: '#92400E' }}>🎉 {o.label} — {fmtDate(o.date, locale, { day: 'numeric', month: 'long' })}</div>)}
      {s.open_complaints.map((c: any) => <div key={c.number} style={{ fontSize: 13, color: 'var(--danger)' }}>⚠ {c.number} · {c.title}</div>)}
      {s.preferred_room_type && <div style={{ fontSize: 13 }}>🛏 {t('crm.prefRoomType')} : <b>{s.preferred_room_type}</b></div>}
      {s.preferences.filter((p: any) => p.category !== 'occasion').map((p: any, i: number) => <div key={i} style={{ fontSize: 13 }}>• <span className="muted">{t(`crm.pc_${p.category}` as Key)} :</span> {p.value}</div>)}
      {s.legacy_preferences && <div style={{ fontSize: 13 }}>• {s.legacy_preferences}</div>}
      {reservationId && s.tier && Number(s.tier.discount_percent) > 0 && can('crm.loyalty') && <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={memberDiscount}>{t('crm.applyMemberDiscount')} ({Number(s.tier.discount_percent)} %)</button>}
    </div>
  );
}
