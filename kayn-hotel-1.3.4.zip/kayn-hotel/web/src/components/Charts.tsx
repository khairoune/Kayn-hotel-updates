import { useState } from 'react';

interface Pt { label: string; value: number; future?: boolean }

/** Histogramme simple (SVG), avec info-bulle au survol. */
export function BarChart({ data, format, height = 180, color = '#7A1F2B' }: { data: Pt[]; format: (n: number) => string; height?: number; color?: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(1, ...data.map((d) => d.value));
  const w = 100 / data.length;
  return (
    <div style={{ position: 'relative' }}>
      <svg viewBox={`0 0 100 ${height}`} preserveAspectRatio="none" style={{ width: '100%', height, display: 'block' }} role="img" aria-label="Histogramme">
        {[0.25, 0.5, 0.75].map((g) => (
          <line key={g} x1="0" x2="100" y1={height * g} y2={height * g} stroke="var(--soft)" strokeWidth="0.3" vectorEffect="non-scaling-stroke" />
        ))}
        {data.map((d, i) => {
          const h = (d.value / max) * (height - 6);
          return (
            <rect key={i} x={i * w + w * 0.15} width={w * 0.7} y={height - h} height={h} rx="0.6"
              fill={d.future ? 'none' : color} stroke={d.future ? color : 'none'} strokeDasharray={d.future ? '2 2' : undefined} vectorEffect="non-scaling-stroke"
              opacity={hover === null || hover === i ? 1 : 0.45}
              onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} />
          );
        })}
      </svg>
      <div className="row between muted" style={{ fontSize: 11, marginTop: 4 }}>
        <span>{data[0]?.label}</span>
        <span>{data[Math.floor(data.length / 2)]?.label}</span>
        <span>{data[data.length - 1]?.label}</span>
      </div>
      {hover !== null && (
        <div style={{ position: 'absolute', top: 0, insetInlineStart: `${Math.min(80, hover * w)}%`, background: 'var(--side)', color: '#fff', padding: '6px 10px', borderRadius: 8, fontSize: 12, pointerEvents: 'none', whiteSpace: 'nowrap' }}>
          {data[hover].label} · <b>{format(data[hover].value)}</b>
        </div>
      )}
    </div>
  );
}
