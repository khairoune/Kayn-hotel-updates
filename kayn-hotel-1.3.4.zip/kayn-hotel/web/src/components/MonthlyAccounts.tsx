import { useEffect, useState } from 'react';
import { useI18n } from '../i18n';
import { get } from '../lib/api';
import { fmtDate, money } from '../lib/format';
import { BarChart } from './Charts';

/** Comptabilité par mois (12 derniers mois) : CA, encaissements, dépenses, écart, occupation. */
export function MonthlyAccounts() {
  const { t, locale } = useI18n();
  const [rows, setRows] = useState<any[] | null>(null);
  useEffect(() => { get('/api/monthly-accounts').then((r) => setRows(r.months)).catch(() => setRows([])); }, []);
  if (!rows?.length) return null;
  const cur = rows[rows.length - 1], prev = rows[rows.length - 2];
  const m = (n: number) => money(n);
  const tile = (label: string, v: string, hint?: string, accent?: string) => (
    <div className="card kpi" style={{ borderInlineStart: accent ? `4px solid ${accent}` : undefined }}>
      <div className="muted" style={{ fontSize: 12 }}>{label}</div><div style={{ fontSize: 22, fontWeight: 700 }}>{v}</div>{hint && <div className="muted" style={{ fontSize: 12 }}>{hint}</div>}
    </div>);
  return (
    <div className="card" style={{ marginBottom: 14 }}>
      <h3 style={{ marginTop: 0 }}>{t('dash.monthTable')} — {fmtDate(`${cur.month}-01`, locale, { month: 'long', year: 'numeric' })}</h3>
      <div className="grid kpis" style={{ marginBottom: 12 }}>
        {tile(t('dash.colRev'), m(cur.revenue), prev ? `${t('dash.prevMonth')} : ${m(prev.revenue)}` : undefined, '#C9A227')}
        {tile(t('dash.colPay'), m(cur.payments), prev ? `${t('dash.prevMonth')} : ${m(prev.payments)}` : undefined)}
        {tile(t('dash.colExp'), m(cur.expenses), prev ? `${t('dash.prevMonth')} : ${m(prev.expenses)}` : undefined)}
        {tile(t('dash.colGap'), m(cur.gap), undefined, '#15803D')}
        {tile(t('dash.occupancy'), `${cur.occupancy.toFixed(1)} %`, prev ? `${t('dash.prevMonth')} : ${prev.occupancy.toFixed(1)} %` : undefined)}
      </div>
      <BarChart data={rows.map((x) => ({ label: fmtDate(`${x.month}-01`, locale, { month: 'short', year: '2-digit' }), value: x.revenue }))} format={m} />
      <div className="table-wrap" style={{ marginTop: 10 }}><table className="table">
        <thead><tr><th>{t('dash.colMonth')}</th><th className="num">{t('dash.colRev')}</th><th className="num">{t('dash.colPay')}</th><th className="num">{t('dash.colExp')}</th><th className="num">{t('dash.colGap')}</th><th className="num">{t('dash.occupancy')}</th></tr></thead>
        <tbody>{[...rows].reverse().map((x) => (
          <tr key={x.month}><td>{fmtDate(`${x.month}-01`, locale, { month: 'long', year: 'numeric' })}</td><td className="num">{m(x.revenue)}</td><td className="num">{m(x.payments)}</td><td className="num">{m(x.expenses)}</td><td className="num"><b style={{ color: x.gap < 0 ? '#B91C1C' : undefined }}>{m(x.gap)}</b></td><td className="num">{x.occupancy.toFixed(1)} %</td></tr>
        ))}</tbody>
      </table></div>
    </div>
  );
}
