import { useEffect, useRef, useState } from 'react';

/** Graphiques SVG du centre de rapports (courbes, barres groupées, anneau), sans dépendance externe. */
export const PALETTE = ['#7A1F2B', '#C9A227', '#0E7490', '#1E40AF', '#15803D', '#B45309', '#7C3AED', '#DB2777', '#52525B', '#0F766E'];
type Series = { name: string; values: number[] };
type Props = { labels: string[]; series: Series[]; format: (n: number) => string; height?: number; onPick?: (i: number) => void };

function useWidth() {
  const ref = useRef<HTMLDivElement>(null);
  const [w, setW] = useState(600);
  useEffect(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver((e) => setW(Math.max(220, Math.round(e[0].contentRect.width))));
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);
  return { ref, w };
}
const short = (n: number) => { const a = Math.abs(n); return a >= 1e6 ? `${(n / 1e6).toFixed(1)} M` : a >= 1e4 ? `${Math.round(n / 1e3)} k` : a >= 1000 ? `${(n / 1e3).toFixed(1)} k` : String(Math.round(n * 10) / 10); };
const Legend = ({ series }: { series: { name: string }[] }) => (
  <div className="row" style={{ gap: 12, flexWrap: 'wrap', fontSize: 12, marginTop: 6 }}>
    {series.map((s, i) => <span key={s.name} className="row" style={{ gap: 5 }}><i style={{ width: 10, height: 10, borderRadius: 3, background: PALETTE[i % PALETTE.length], display: 'inline-block' }} />{s.name}</span>)}
  </div>
);
const Empty = ({ h }: { h: number }) => <div className="muted" style={{ height: h, display: 'grid', placeItems: 'center', fontSize: 13 }}>—</div>;

function Axes({ labels, w, h, pad, max, min, format }: { labels: string[]; w: number; h: number; pad: { l: number; b: number; t: number }; max: number; min: number; format: (n: number) => string }) {
  const Y = (v: number) => pad.t + (h - pad.t - pad.b) * (1 - (v - min) / (max - min || 1));
  const every = Math.max(1, Math.ceil(labels.length / Math.max(2, Math.floor((w - pad.l) / 70))));
  const step = (w - pad.l) / Math.max(1, labels.length);
  return (
    <g>
      {[0, 0.25, 0.5, 0.75, 1].map((g) => { const v = min + (max - min) * g; return (
        <g key={g}><line x1={pad.l} x2={w} y1={Y(v)} y2={Y(v)} stroke="var(--soft)" /><text x={pad.l - 6} y={Y(v) + 4} textAnchor="end" fontSize="10.5" fill="var(--muted)">{short(v)}</text></g>); })}
      {labels.map((l, i) => i % every === 0 && <text key={i} x={pad.l + i * step + step / 2} y={h - 6} textAnchor="middle" fontSize="10.5" fill="var(--muted)">{l.length > 10 ? l.slice(5) : l}</text>)}
      <title>{format(max)}</title>
    </g>
  );
}

export function LineChart({ labels, series, format, height = 220, onPick }: Props) {
  const { ref, w } = useWidth();
  const [hover, setHover] = useState<number | null>(null);
  const all = series.flatMap((s) => s.values);
  if (!labels.length || !all.length) return <div ref={ref}><Empty h={height} /></div>;
  const max = Math.max(0, ...all) * 1.08 || 1, min = Math.min(0, ...all);
  const pad = { l: 46, b: 22, t: 8 };
  const step = (w - pad.l) / Math.max(1, labels.length);
  const X = (i: number) => pad.l + i * step + step / 2;
  const Y = (v: number) => pad.t + (height - pad.t - pad.b) * (1 - (v - min) / (max - min || 1));
  return (
    <div ref={ref} dir="ltr" style={{ position: 'relative' }}>
      <svg width={w} height={height} role="img" aria-label={series.map((s) => s.name).join(', ')} onMouseLeave={() => setHover(null)}>
        <Axes labels={labels} w={w} h={height} pad={pad} max={max} min={min} format={format} />
        {series.map((s, si) => (
          <g key={s.name}>
            <polyline fill="none" stroke={PALETTE[si % PALETTE.length]} strokeWidth="2.2" strokeLinejoin="round" points={s.values.map((v, i) => `${X(i)},${Y(v)}`).join(' ')} />
            {labels.length <= 40 && s.values.map((v, i) => <circle key={i} cx={X(i)} cy={Y(v)} r={hover === i ? 4.5 : 2.6} fill={PALETTE[si % PALETTE.length]} />)}
          </g>
        ))}
        {labels.map((_, i) => <rect key={i} x={X(i) - step / 2} y={0} width={step} height={height - pad.b} fill="transparent" style={{ cursor: onPick ? 'pointer' : 'default' }} onMouseEnter={() => setHover(i)} onClick={() => onPick?.(i)} />)}
        {hover !== null && <line x1={X(hover)} x2={X(hover)} y1={pad.t} y2={height - pad.b} stroke="var(--border)" strokeDasharray="3 3" pointerEvents="none" />}
      </svg>
      {hover !== null && <Tip x={X(hover)} w={w} title={labels[hover]} rows={series.map((s, i) => ({ name: s.name, v: format(s.values[hover]), c: PALETTE[i % PALETTE.length] }))} />}
      {series.length > 1 && <Legend series={series} />}
    </div>
  );
}

export function BarChart({ labels, series, format, height = 220, onPick }: Props) {
  const { ref, w } = useWidth();
  const [hover, setHover] = useState<number | null>(null);
  const all = series.flatMap((s) => s.values);
  if (!labels.length || !all.length) return <div ref={ref}><Empty h={height} /></div>;
  const horizontal = labels.some((l) => l.length > 12) && labels.length <= 15;
  if (horizontal) {
    const max = Math.max(1, ...all);
    const rowH = 26, H = labels.length * rowH + 4, lw = Math.min(170, w * 0.36);
    return (
      <div ref={ref} dir="ltr" style={{ position: 'relative' }}>
        <svg width={w} height={H} role="img" aria-label={series[0]?.name}>
          {labels.map((l, i) => (
            <g key={i} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} onClick={() => onPick?.(i)} style={{ cursor: onPick ? 'pointer' : 'default' }}>
              <text x={lw - 6} y={i * rowH + 17} textAnchor="end" fontSize="11.5" fill="var(--text)">{l.length > 26 ? `${l.slice(0, 25)}…` : l}</text>
              {series.map((s, si) => { const bw = ((w - lw - 70) * Math.max(0, s.values[i])) / max; const bh = (rowH - 8) / series.length; return (
                <rect key={si} x={lw} y={i * rowH + 4 + si * bh} width={Math.max(1, bw)} height={bh - 1} rx="3" fill={PALETTE[si % PALETTE.length]} opacity={hover === null || hover === i ? 1 : 0.5} />); })}
              <text x={lw + ((w - lw - 70) * Math.max(0, ...series.map((s) => s.values[i]))) / max + 6} y={i * rowH + 17} fontSize="11" fill="var(--muted)">{format(series[0].values[i])}</text>
            </g>
          ))}
        </svg>
        {series.length > 1 && <Legend series={series} />}
      </div>
    );
  }
  const max = Math.max(0, ...all) * 1.08 || 1, min = Math.min(0, ...all);
  const pad = { l: 46, b: 22, t: 8 };
  const step = (w - pad.l) / Math.max(1, labels.length);
  const Y = (v: number) => pad.t + (height - pad.t - pad.b) * (1 - (v - min) / (max - min || 1));
  const bw = (step * 0.72) / series.length;
  return (
    <div ref={ref} dir="ltr" style={{ position: 'relative' }}>
      <svg width={w} height={height} role="img" aria-label={series.map((s) => s.name).join(', ')} onMouseLeave={() => setHover(null)}>
        <Axes labels={labels} w={w} h={height} pad={pad} max={max} min={min} format={format} />
        {series.map((s, si) => s.values.map((v, i) => (
          <rect key={`${si}-${i}`} x={pad.l + i * step + step * 0.14 + si * bw} y={Math.min(Y(v), Y(0))} width={Math.max(1, bw - 1)} height={Math.max(0.5, Math.abs(Y(0) - Y(v)))} rx="2"
            fill={PALETTE[si % PALETTE.length]} opacity={hover === null || hover === i ? 1 : 0.5} />
        )))}
        {labels.map((_, i) => <rect key={i} x={pad.l + i * step} y={0} width={step} height={height - pad.b} fill="transparent" style={{ cursor: onPick ? 'pointer' : 'default' }} onMouseEnter={() => setHover(i)} onClick={() => onPick?.(i)} />)}
      </svg>
      {hover !== null && <Tip x={pad.l + hover * step + step / 2} w={w} title={labels[hover]} rows={series.map((s, i) => ({ name: s.name, v: format(s.values[hover]), c: PALETTE[i % PALETTE.length] }))} />}
      {series.length > 1 && <Legend series={series} />}
    </div>
  );
}

export function PieChart({ labels, series, format, height = 220, onPick }: Props) {
  const [hover, setHover] = useState<number | null>(null);
  const vals = (series[0]?.values ?? []).map((v) => Math.max(0, v));
  const sum = vals.reduce((a, b) => a + b, 0);
  if (!sum) return <Empty h={height} />;
  const R = height / 2 - 6, r = R * 0.58, cx = R + 6, cy = height / 2;
  let a = -Math.PI / 2;
  const arcs = vals.map((v, i) => {
    const b = a + (v / sum) * Math.PI * 2;
    const large = b - a > Math.PI ? 1 : 0;
    const p = (ang: number, rad: number) => `${cx + rad * Math.cos(ang)},${cy + rad * Math.sin(ang)}`;
    const d = v / sum >= 0.9999 ? `M ${p(0, R)} A ${R} ${R} 0 1 1 ${p(Math.PI, R)} A ${R} ${R} 0 1 1 ${p(0, R)} M ${p(0, r)} A ${r} ${r} 0 1 0 ${p(Math.PI, r)} A ${r} ${r} 0 1 0 ${p(0, r)} Z`
      : `M ${p(a, R)} A ${R} ${R} 0 ${large} 1 ${p(b, R)} L ${p(b, r)} A ${r} ${r} 0 ${large} 0 ${p(a, r)} Z`;
    a = b;
    return { d, i };
  });
  const cur = hover ?? vals.indexOf(Math.max(...vals));
  return (
    <div className="row" style={{ gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
      <svg style={{ direction: "ltr" }} width={R * 2 + 12} height={height} role="img" aria-label={series[0]?.name} onMouseLeave={() => setHover(null)}>
        {arcs.map(({ d, i }) => vals[i] > 0 && <path key={i} d={d} fill={PALETTE[i % PALETTE.length]} fillRule="evenodd" opacity={hover === null || hover === i ? 1 : 0.45} onMouseEnter={() => setHover(i)} onClick={() => onPick?.(i)} style={{ cursor: onPick ? 'pointer' : 'default' }} />)}
        <text x={cx} y={cy - 2} textAnchor="middle" fontSize="15" fontWeight="700" fill="var(--text)">{Math.round((vals[cur] / sum) * 1000) / 10} %</text>
        <text x={cx} y={cy + 15} textAnchor="middle" fontSize="10.5" fill="var(--muted)">{(labels[cur] ?? '').slice(0, 16)}</text>
      </svg>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 5, fontSize: 12.5, flex: 1, minWidth: 150 }}>
        {labels.map((l, i) => (
          <div key={l} className="row between" style={{ gap: 8, opacity: hover === null || hover === i ? 1 : 0.55, cursor: onPick ? 'pointer' : 'default' }} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} onClick={() => onPick?.(i)}>
            <span className="row" style={{ gap: 6 }}><i style={{ width: 10, height: 10, borderRadius: 3, background: PALETTE[i % PALETTE.length], display: 'inline-block', flex: '0 0 10px' }} />{l}</span>
            <b style={{ whiteSpace: 'nowrap' }}>{format(vals[i])} <span className="muted" style={{ fontWeight: 400 }}>· {Math.round((vals[i] / sum) * 1000) / 10} %</span></b>
          </div>
        ))}
      </div>
    </div>
  );
}

function Tip({ x, w, title, rows }: { x: number; w: number; title: string; rows: { name: string; v: string; c: string }[] }) {
  const left = Math.min(Math.max(0, x - 80), w - 170);
  return (
    <div style={{ position: 'absolute', top: 4, left, background: 'var(--side)', color: '#fff', padding: '6px 10px', borderRadius: 8, fontSize: 12, pointerEvents: 'none', minWidth: 150, zIndex: 2 }}>
      <div style={{ fontWeight: 600, marginBottom: 2 }}>{title}</div>
      {rows.map((r) => <div key={r.name} className="row between" style={{ gap: 10 }}><span><i style={{ width: 8, height: 8, borderRadius: 2, background: r.c, display: 'inline-block', marginInlineEnd: 5 }} />{r.name}</span><b>{r.v}</b></div>)}
    </div>
  );
}
