/**
 * Saisie de la pièce d'identité : 1) à la main (formulaire habituel), 2) scan avec le téléphone (QR code),
 * 3) import d'une photo / d'un scanner depuis le poste. La lecture (MRZ) est faite localement par le serveur ;
 * l'agent vérifie le résultat avant de remplir le formulaire.
 */
import { useEffect, useRef, useState } from 'react';
import { useI18n, type Key } from '../i18n';
import { get, post, upload } from '../lib/api';
import { useToast } from '../lib/context';
import { Modal } from './ui';

export type IdFields = { last_name: string | null; first_name: string | null; birth_date: string | null; gender: 'M' | 'F' | null; nationality: string | null; nationality_code: string | null;
  id_doc_type: 'passport' | 'cni' | 'other'; id_doc_number: string | null; id_doc_expiry: string | null; issuing_country: string | null };

export function IdScan({ context, onFill }: { context: 'reservation' | 'checkin' | 'guest'; onFill: (f: IdFields, scanId: number) => void }) {
  const { t } = useI18n();
  const s = (k: string) => t(`scan.${k}` as Key);
  const toast = useToast();
  const [scan, setScan] = useState<any>(null);
  const [mode, setMode] = useState<'phone' | 'upload' | null>(null);
  const [urlIdx, setUrlIdx] = useState(0);
  const [busy, setBusy] = useState(false);
  const [v, setV] = useState(0);
  const fileRef = useRef<HTMLInputElement>(null);

  // suivi du téléphone : interrogation toutes les 2 s tant que la photo n'est pas reçue
  useEffect(() => {
    if (!scan || mode !== 'phone' || ['read', 'unreadable', 'used', 'expired'].includes(scan.status)) return;
    const i = setInterval(() => get(`/api/id-scans/${scan.id}`).then((x) => { setScan((o: any) => ({ ...o, ...x })); if (x.uploads !== scan.uploads) setV((n) => n + 1); }).catch(() => {}), 2000);
    return () => clearInterval(i);
  }, [scan?.id, scan?.status, scan?.uploads, mode]);

  const start = async (m: 'phone' | 'upload') => {
    setBusy(true);
    try {
      const x = await post('/api/id-scans', { context });
      setScan(x); setMode(m); setUrlIdx(0);
      if (m === 'upload') setTimeout(() => fileRef.current?.click(), 50);
    } catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  const sendFile = async (file: File) => {
    setBusy(true);
    try { const x = await upload(`/api/id-scans/${scan.id}/upload`, file, {}); setScan((o: any) => ({ ...o, ...x })); setV((n) => n + 1); }
    catch (e: any) { toast('error', e.message); } finally { setBusy(false); }
  };
  const close = () => { setScan(null); setMode(null); };
  const fill = async () => {
    const f = scan.result?.fields as IdFields;
    if (!f) return;
    onFill(f, scan.id);
    post(`/api/id-scans/${scan.id}/use`, {}).catch(() => {});
    toast('success', s('filled'));
    close();
  };
  const res = scan?.result;
  const f: IdFields | null = res?.fields ?? null;
  const rows: [string, string | null][] = f ? [['lastName', f.last_name], ['firstName', f.first_name], ['birthDate', f.birth_date], ['gender', f.gender], ['nationality', f.nationality],
    ['docType', f.id_doc_type === 'passport' ? s('passport') : f.id_doc_type === 'cni' ? s('cni') : s('other')], ['docNumber', f.id_doc_number], ['expiry', f.id_doc_expiry]] : [];
  const expired = f?.id_doc_expiry && f.id_doc_expiry < new Date().toISOString().slice(0, 10);

  return (
    <>
      <div className="row" style={{ gap: 8, flexWrap: 'wrap', alignItems: 'center', margin: '4px 0 10px' }}>
        <button type="button" className="btn sm" disabled={busy} onClick={() => start('phone')}>📱 {s('phone')}</button>
        <button type="button" className="btn sm" disabled={busy} onClick={() => start('upload')}>🖼️ {s('upload')}</button>
        <span className="muted" style={{ fontSize: 12 }}>{s('orManual')}</span>
        <input ref={fileRef} type="file" accept="image/jpeg,image/png" hidden onChange={(e) => { const x = e.target.files?.[0]; if (x) sendFile(x); e.target.value = ''; }} />
      </div>
      {scan && (
        <Modal title={mode === 'phone' ? s('phoneTitle') : s('uploadTitle')} onClose={close} size="lg"
          footer={<>
            <button className="btn" onClick={close}>{t('common.cancel')}</button>
            {mode === 'upload' && <button className="btn" disabled={busy} onClick={() => fileRef.current?.click()}>{s('otherPhoto')}</button>}
            <button className="btn primary" disabled={!f} onClick={fill}>{s('fill')}</button>
          </>}>
          <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 16, alignItems: 'start' }}>
            {mode === 'phone' && !['read', 'unreadable'].includes(scan.status) && (
              <div style={{ textAlign: 'center' }}>
                <div style={{ background: '#fff', padding: 8, borderRadius: 10, display: 'inline-block' }} dangerouslySetInnerHTML={{ __html: scan.qrs?.[urlIdx] ?? scan.qr ?? '' }} />
                {scan.urls?.length ? <div style={{ fontSize: 12, wordBreak: 'break-all', marginTop: 6 }}><code>{scan.urls[urlIdx]}</code></div> : <div className="alert danger">{s('noLan')}</div>}
                {scan.urls?.length > 1 && <select className="input" style={{ marginTop: 6 }} value={urlIdx} onChange={(e) => setUrlIdx(Number(e.target.value))}>{scan.urls.map((u: string, i: number) => <option key={u} value={i}>{u.split('/scan/')[0]}</option>)}</select>}
              </div>
            )}
            <div>
              {mode === 'phone' && !['read', 'unreadable'].includes(scan.status) && <>
                <ol style={{ paddingInlineStart: 18, margin: 0, fontSize: 14 }}>{['p1', 'p2', 'p3', 'p4'].map((k) => <li key={k} style={{ marginBottom: 6 }}>{s(k)}</li>)}</ol>
                <div className="alert info" style={{ marginTop: 10 }}>{scan.status === 'uploaded' ? `⏳ ${s('reading')}` : `⏳ ${s('waiting')}`}</div>
                <p className="muted" style={{ fontSize: 12 }}>{s('wifiHint')}</p>
              </>}
              {mode === 'upload' && !res && <div className="alert info">{busy ? `⏳ ${s('reading')}` : s('uploadHint')}</div>}
              {res && <>
                {res.valid ? <div className="alert info">✓ {s('ok')}</div> : res.read ? <div className="alert warning">{s('partial')}</div> : <div className="alert warning">{s('unreadable')}</div>}
                {expired && <div className="alert danger">{s('expired')}</div>}
                {f && <table className="table" style={{ fontSize: 13 }}><tbody>{rows.map(([k, val]) => <tr key={k}><td className="muted">{t(`id.${k}` as Key)}</td><td><b>{val ?? '—'}</b></td></tr>)}</tbody></table>}
                {mode === 'phone' && <p className="muted" style={{ fontSize: 12 }}>{s('retakeHint')}</p>}
              </>}
            </div>
            {scan.has_image && <div><img src={`/api/id-scans/${scan.id}/image?v=${v}`} alt={s('photo')} style={{ width: '100%', borderRadius: 8, border: '1px solid var(--border)' }} /></div>}
          </div>
          <p className="muted" style={{ fontSize: 11.5, marginBottom: 0 }}>🔒 {s('privacy')}</p>
        </Modal>
      )}
    </>
  );
}
