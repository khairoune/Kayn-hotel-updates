import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { get, post, setUnauthorizedHandler } from './api';
import { setCurrency } from './format';

export interface Me {
  id: number;
  username: string;
  full_name: string;
  role: string;
  role_name: string;
  language: string;
  must_change_password: boolean;
  permissions: string[];
  hotel: { id: number; name: string; commercial_name?: string | null; city: string; currency?: string; currency_symbol?: string; decimals?: number; logo_id?: number | null; languages?: string[]; primary_language?: string };
  device: { id: number; name: string } | null;
}

interface AuthCtx {
  me: Me | null;
  loading: boolean;
  refresh: () => Promise<void>;
  logout: () => Promise<void>;
  can: (p: string) => boolean;
}

const Auth = createContext<AuthCtx>(null as unknown as AuthCtx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      const m = await get<Me>('/api/auth/me');
      setCurrency(m.hotel?.currency_symbol, m.hotel?.decimals);
      setMe(m);
    } catch {
      setMe(null);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    setUnauthorizedHandler(() => setMe(null));
    refresh();
  }, [refresh]);
  const logout = async () => {
    await post('/api/auth/logout').catch(() => {});
    setMe(null);
  };
  const can = (p: string) => !!me?.permissions.includes(p);
  return <Auth.Provider value={{ me, loading, refresh, logout, can }}>{children}</Auth.Provider>;
}
export const useAuth = () => useContext(Auth);

// ===== Notifications =====
type ToastKind = 'success' | 'error' | 'info';
interface Toast { id: number; kind: ToastKind; text: string }
const ToastCtx = createContext<(kind: ToastKind, text: string) => void>(() => {});

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const push = useCallback((kind: ToastKind, text: string) => {
    const id = Date.now() + Math.random();
    setItems((x) => [...x.slice(-3), { id, kind, text }]);
    setTimeout(() => setItems((x) => x.filter((t) => t.id !== id)), kind === 'error' ? 7000 : 4000);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        {items.map((t) => (
          <div key={t.id} className={`toast ${t.kind}`}>
            <span style={{ flex: 1 }}>{t.text}</span>
            <button className="btn ghost sm" aria-label="Fermer" onClick={() => setItems((x) => x.filter((y) => y.id !== t.id))}>×</button>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
export const useToast = () => useContext(ToastCtx);
