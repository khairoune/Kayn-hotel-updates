export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
  }
}

let onUnauthorized: (() => void) | null = null;
export const setUnauthorizedHandler = (fn: () => void) => {
  onUnauthorized = fn;
};

/** Diffusion des modifications entre les écrans et les onglets ouverts (synchronisation planning ↔ réservations). */
const channel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('kayn-hotel') : null;
const listeners = new Set<() => void>();
channel?.addEventListener('message', () => listeners.forEach((l) => l()));
export function onDataChanged(fn: () => void) {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}
function notifyChanged() {
  channel?.postMessage('changed');
  setTimeout(() => listeners.forEach((l) => l()), 0);
}

/** Clé d'opération unique (fonctionne aussi en HTTP sur le réseau local, où crypto.randomUUID est indisponible). */
export function newOpKey(prefix = 'op') {
  const b = new Uint8Array(16);
  crypto.getRandomValues(b);
  return `${prefix}-${Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('')}`;
}

export async function api<T = any>(method: string, url: string, body?: unknown, opts: { key?: string } = {}): Promise<T> {
  const res = await fetch(url, {
    method,
    credentials: 'same-origin',
    headers: { 'x-kayn-client': 'web', ...(body !== undefined ? { 'content-type': 'application/json' } : {}), ...(opts.key ? { 'idempotency-key': opts.key } : {}) },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    if (res.status === 401 && onUnauthorized && !url.includes('/auth/login')) onUnauthorized();
    throw new ApiError(res.status, data?.error ?? 'error', data?.message ?? `Erreur ${res.status}`);
  }
  if (method !== 'GET' && !url.includes('/auth/') && !url.includes('/quote') && !url.includes('/preview')) notifyChanged();
  return data as T;
}

export const get = <T = any>(url: string) => api<T>('GET', url);
export const post = <T = any>(url: string, body: unknown = {}) => api<T>('POST', url, body);
/** POST protégé contre la double exécution : la même clé (créée à l'ouverture du formulaire) n'est exécutée qu'une fois. */
export const postOnce = <T = any>(url: string, body: unknown, key: string) => api<T>('POST', url, body, { key });
export const patch = <T = any>(url: string, body: unknown) => api<T>('PATCH', url, body);

export const del = <T = any>(url: string) => api<T>('DELETE', url);

/** Envoi d'un fichier (photos) — multipart, avec l'en-tête anti-CSRF. */
export async function upload<T = any>(url: string, file: File, fields: Record<string, string>): Promise<T> {
  const fd = new FormData();
  Object.entries(fields).forEach(([k, v]) => fd.append(k, v));
  fd.append('file', file);
  const res = await fetch(url, { method: 'POST', credentials: 'same-origin', headers: { 'x-kayn-client': 'web' }, body: fd });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) throw new ApiError(res.status, data?.error ?? 'error', data?.message ?? `Erreur ${res.status}`);
  notifyChanged();
  return data as T;
}
