/** Guide d'aide intégré (hors-ligne) : une fiche par écran + questions générales. EN reprend le français. */
export type HelpItem = [question: string, answer: string];
export type HelpVideo = { src: string; poster: string; fr: string; ar: string; length: string };
export type HelpPage = { path: string; fr: { title: string; items: HelpItem[] }; ar: { title: string; items: HelpItem[] }; videos?: HelpVideo[] };

/** Vidéos de formation (fichiers locaux : fonctionnent sans Internet). */
export const VIDEOS: Record<string, HelpVideo> = {
  checkin: { src: '/aide/checkin.mp4', poster: '/aide/checkin.jpg', fr: "Check-in d'un client qui a réservé (scan de la pièce, paiement, signature)", ar: 'تسجيل دخول زبون لديه حجز (مسح الوثيقة، الدفع، التوقيع)', length: '1 min 09' },
  caisse: { src: '/aide/caisse.mp4', poster: '/aide/caisse.jpg', fr: 'La caisse : encaisser au départ, clôturer, rouvrir', ar: 'الصندوق: التحصيل عند المغادرة، الغلق، إعادة الفتح', length: '1 min 03' },
};

export const HELP: HelpPage[] = [
  {
    path: '/planning',
    fr: { title: 'Planning', items: [
      ['Comment créer une réservation ?', "Bouton « Nouvelle réservation », ou cliquez sur une case vide du planning (chambre + date). Choisissez un client existant ou créez-le, puis les dates, la chambre et la formule."],
      ['Comment changer de chambre ou de dates ?', "Glissez la barre de la réservation vers une autre ligne ou d'autres jours. Tirez le bord de la barre pour prolonger ou raccourcir. Le tarif est recalculé."],
      ['Que signifient les couleurs ?', "Chaque couleur correspond à un statut : en attente, confirmée, en séjour, partie. La légende est en haut du planning."],
      ['Le client ne paie pas mais la réservation est « confirmée »', "C'est le réglage « Politique d'acompte » (Paramètres). En mode « aucune », une réservation est confirmée sans paiement. Mettez « en attente si pas d'acompte » ou « bloquer »."],
    ] },
    ar: { title: 'المخطط', items: [
      ['كيف أنشئ حجزًا؟', 'زر «حجز جديد» أو اضغط على خانة فارغة (غرفة + تاريخ). اختر زبونًا موجودًا أو أنشئ زبونًا جديدًا، ثم التواريخ والغرفة والصيغة.'],
      ['كيف أغيّر الغرفة أو التواريخ؟', 'اسحب شريط الحجز إلى سطر آخر أو أيام أخرى. اسحب طرف الشريط للتمديد أو التقصير. يُعاد حساب السعر.'],
      ['ماذا تعني الألوان؟', 'كل لون يمثّل حالة: في الانتظار، مؤكّد، مقيم، غادر. الدليل في أعلى المخطط.'],
      ['الزبون لم يدفع لكن الحجز «مؤكّد»', 'هذا إعداد «سياسة العربون» في الإعدادات. في وضع «بدون» يُؤكَّد الحجز بلا دفع. اختر «في الانتظار دون عربون» أو «منع».'],
    ] },
  },
  {
    path: '/frontoffice', videos: [VIDEOS.checkin, VIDEOS.caisse],
    fr: { title: 'Réception (Front Office)', items: [
      ['Comment faire un check-in ?', "Onglet Arrivées → « Check-in ». L'assistant a 4 étapes : Identité (fiche de police), Chambre, Paiement, Validation. Le client n'apparaît « en séjour » qu'après la dernière étape « Valider »."],
      ["Comment scanner la pièce d'identité ?", "À l'étape Identité : « 📱 Scanner avec mon téléphone » (scannez le QR avec le téléphone puis photographiez la pièce) ou « 🖼️ Importer une photo ». Vérifiez toujours les champs remplis."],
      ['La chambre est refusée au check-in', "La chambre doit être « propre » ou « inspectée ». Demandez au housekeeping de la terminer ou choisissez une autre chambre."],
      ['Comment faire un check-out ?', "Onglet Départs → « Check-out » : encaissez le solde. La facture est créée automatiquement et la chambre passe « à nettoyer »."],
    ] },
    ar: { title: 'الاستقبال', items: [
      ['كيف أسجّل دخول زبون؟', 'تبويب الوصول ← «تسجيل الدخول». المعالج من 4 مراحل: الهوية (بطاقة الشرطة)، الغرفة، الدفع، التأكيد. لا يظهر الزبون «مقيمًا» إلا بعد الضغط على «تأكيد» في الأخير.'],
      ['كيف أمسح بطاقة الهوية؟', 'في مرحلة الهوية: «📱 المسح بالهاتف» (امسح رمز QR بالهاتف ثم صوّر البطاقة) أو «🖼️ استيراد صورة». تحقّق دائمًا من الخانات المملوءة.'],
      ['الغرفة مرفوضة عند الدخول', 'يجب أن تكون الغرفة «نظيفة» أو «مفحوصة». اطلب من التنظيف إنهاءها أو اختر غرفة أخرى.'],
      ['كيف أسجّل خروج زبون؟', 'تبويب المغادرة ← «تسجيل الخروج»: حصّل الباقي. تُنشأ الفاتورة تلقائيًا وتصبح الغرفة «للتنظيف».'],
    ] },
  },
  {
    path: '/reservations',
    fr: { title: 'Réservations', items: [
      ['Comment retrouver une réservation ?', "Tapez le nom, le téléphone ou le numéro dans la recherche ; filtrez par statut ou par dates."],
      ['Comment annuler ?', "Ouvrez la réservation → « Annuler » : le motif est obligatoire et enregistré. Des frais peuvent s'appliquer selon la politique d'annulation."],
      ['Comment encaisser un acompte ?', "Ouvrez la réservation → « Encaisser ». Pour une carte, saisissez seulement les 4 derniers chiffres."],
    ] },
    ar: { title: 'الحجوزات', items: [
      ['كيف أجد حجزًا؟', 'اكتب الاسم أو الهاتف أو الرقم في البحث، وصفِّ حسب الحالة أو التواريخ.'],
      ['كيف ألغي حجزًا؟', 'افتح الحجز ← «إلغاء»: السبب إجباري ومسجّل. قد تُطبَّق رسوم حسب سياسة الإلغاء.'],
      ['كيف أحصّل عربونًا؟', 'افتح الحجز ← «تحصيل». للبطاقة البنكية أدخل آخر 4 أرقام فقط.'],
    ] },
  },
  {
    path: '/guests',
    fr: { title: 'Clients', items: [
      ['Comment ajouter un client ?', "Bouton « Nouveau client », ou directement depuis une nouvelle réservation."],
      ['Deux fiches pour le même client', "Utilisez « Fusionner » sur la fiche en double : l'historique des séjours est regroupé."],
      ["Où voir l'historique ?", "Ouvrez la fiche : séjours, factures, préférences et pièces d'identité scannées."],
    ] },
    ar: { title: 'الزبائن', items: [
      ['كيف أضيف زبونًا؟', 'زر «زبون جديد»، أو مباشرة من حجز جديد.'],
      ['ملفّان لنفس الزبون', 'استعمل «دمج» على الملف المكرّر: يُجمع سجلّ الإقامات.'],
      ['أين أرى السجلّ؟', 'افتح الملف: الإقامات، الفواتير، التفضيلات ووثائق الهوية الممسوحة.'],
    ] },
  },
  {
    path: '/billing', videos: [VIDEOS.caisse],
    fr: { title: 'Facturation & caisse', items: [
      ['Comment choisir le mois ?', "En haut à droite : choisissez le mois. Vous pouvez aussi saisir des dates précises (du … au …)."],
      ['Ouvrir et fermer la caisse', "Onglet Caisse : « Ouvrir » en début de service (fond de caisse), « Fermer » en fin de service avec le montant compté. Un écart doit être justifié."],
      ['Corriger une facture', "Une facture émise ne se modifie pas : créez un « Avoir »."],
      ['Annuler un paiement', "Bouton « Annuler » sur le paiement, motif obligatoire (droit de responsable). Le paiement n'est jamais effacé."],
      ['Saisir une dépense', "Onglet Dépenses → « Nouvelle dépense » : date, catégorie, montant, justificatif."],
    ] },
    ar: { title: 'الفوترة والصندوق', items: [
      ['كيف أختار الشهر؟', 'في الأعلى: اختر الشهر. يمكنك أيضًا إدخال تواريخ محدّدة (من … إلى …).'],
      ['فتح وغلق الصندوق', 'تبويب الصندوق: «فتح» في بداية الخدمة (رصيد البداية)، «غلق» في النهاية مع المبلغ المعدود. يجب تبرير أي فرق.'],
      ['تصحيح فاتورة', 'الفاتورة الصادرة لا تُعدَّل: أنشئ «فاتورة تصحيحية (Avoir)».'],
      ['إلغاء دفعة', 'زر «إلغاء» على الدفعة، السبب إجباري (صلاحية مسؤول). الدفعة لا تُحذف أبدًا.'],
      ['تسجيل مصروف', 'تبويب المصاريف ← «مصروف جديد»: التاريخ، الفئة، المبلغ، الوصل.'],
    ] },
  },
  {
    path: '/rooms',
    fr: { title: 'Chambres', items: [
      ["Changer l'état d'une chambre", "Cliquez sur la chambre : propre, à nettoyer, inspectée, hors service (avec motif)."],
      ['Ajouter une chambre ou un type', "Onglet Catalogue (administrateur) : types, capacités, tarifs, équipements."],
      ['Chambre hors service', "Elle n'est plus vendable tant qu'elle n'est pas remise en service (souvent après une intervention de maintenance)."],
    ] },
    ar: { title: 'الغرف', items: [
      ['تغيير حالة غرفة', 'اضغط على الغرفة: نظيفة، للتنظيف، مفحوصة، خارج الخدمة (مع السبب).'],
      ['إضافة غرفة أو نوع', 'تبويب الكتالوج (المدير): الأنواع، السعة، الأسعار، التجهيزات.'],
      ['غرفة خارج الخدمة', 'لا تُباع حتى تُعاد إلى الخدمة (غالبًا بعد تدخل الصيانة).'],
    ] },
  },
  {
    path: '/housekeeping',
    fr: { title: 'Housekeeping', items: [
      ['Nettoyer une chambre', "« Commencer » puis « Terminer » : la chambre passe « à inspecter »."],
      ['Inspection', "La gouvernante coche la checklist. Un point critique non conforme renvoie la chambre « à nettoyer »."],
      ['Panne ou objet trouvé', "« Déclarer une panne » (part en Maintenance) ou « Objets trouvés »."],
    ] },
    ar: { title: 'التنظيف', items: [
      ['تنظيف غرفة', '«بدء» ثم «إنهاء»: تصبح الغرفة «للفحص».'],
      ['الفحص', 'المشرفة تملأ قائمة التحقق. أي نقطة حرجة غير مطابقة تعيد الغرفة «للتنظيف».'],
      ['عطل أو شيء مفقود', '«التصريح بعطل» (يذهب إلى الصيانة) أو «الأشياء المعثور عليها».'],
    ] },
  },
  {
    path: '/restaurant',
    fr: { title: 'Restaurant & services', items: [
      ['Prendre une commande', "Choisissez la table → « Nouvelle commande » → plats → « Envoyer en cuisine »."],
      ['Mettre sur la chambre', "Au règlement : « Sur la chambre » ajoute la note au compte du client hébergé."],
      ['Room service', "Point de vente « Room service » + numéro de chambre ; la consommation est portée automatiquement sur son compte."],
    ] },
    ar: { title: 'المطعم والخدمات', items: [
      ['أخذ طلب', 'اختر الطاولة ← «طلب جديد» ← الأطباق ← «إرسال إلى المطبخ».'],
      ['تحميل على الغرفة', 'عند الدفع: «على الغرفة» يضيف الفاتورة إلى حساب الزبون المقيم.'],
      ['خدمة الغرف', 'نقطة البيع «خدمة الغرف» + رقم الغرفة؛ يُضاف الاستهلاك تلقائيًا إلى حسابه.'],
    ] },
  },
  {
    path: '/stock',
    fr: { title: 'Stocks & achats', items: [
      ['Entrée de marchandise', "« Entrée » à la réception d'une commande : article, quantité, prix, lot si besoin."],
      ['Stock minimum', "Une alerte apparaît quand un article passe sous son minimum. Créez une demande d'achat."],
      ['Inventaire', "Onglet Inventaire : saisissez les quantités comptées, les écarts sont enregistrés avec motif."],
    ] },
    ar: { title: 'المخزون والمشتريات', items: [
      ['إدخال سلعة', '«إدخال» عند استلام طلبية: المادة، الكمية، السعر، الدفعة إن لزم.'],
      ['الحدّ الأدنى', 'يظهر تنبيه عندما تنزل مادة تحت حدّها الأدنى. أنشئ طلب شراء.'],
      ['الجرد', 'تبويب الجرد: أدخل الكميات المعدودة، تُسجَّل الفروق مع السبب.'],
    ] },
  },
  {
    path: '/maintenance',
    fr: { title: 'Maintenance', items: [
      ['Déclarer une panne', "« Déclarer une panne » : chambre ou équipement, priorité, description, photo."],
      ['Suivi par le technicien', "Démarrer → pièces et durée → clôturer. Le responsable valide."],
      ['Maintenance préventive', "Onglet Préventif : tâches planifiées ; elles passent « en retard » si non faites à temps."],
    ] },
    ar: { title: 'الصيانة', items: [
      ['التصريح بعطل', '«التصريح بعطل»: الغرفة أو التجهيز، الأولوية، الوصف، صورة.'],
      ['متابعة التقني', 'بدء ← القطع والمدة ← إغلاق. المسؤول يصادق.'],
      ['الصيانة الوقائية', 'تبويب الوقائي: مهام مبرمجة؛ تصبح «متأخرة» إن لم تُنجز في وقتها.'],
    ] },
  },
  {
    path: '/rh',
    fr: { title: 'Ressources humaines', items: [
      ['Ajouter un employé', "« Nouvel employé » : identité, poste, service, téléphone (il apparaît alors dans l'annuaire 📞)."],
      ['Congés', "L'employé demande, le responsable valide ou refuse."],
      ['Pointage', "Sur la borne : matricule + code. Les retards et absences s'affichent au tableau de bord."],
    ] },
    ar: { title: 'الموارد البشرية', items: [
      ['إضافة موظف', '«موظف جديد»: الهوية، المنصب، المصلحة، الهاتف (يظهر حينها في دليل الهاتف 📞).'],
      ['العطل', 'الموظف يطلب، والمسؤول يقبل أو يرفض.'],
      ['تسجيل الحضور', 'على الجهاز: الرقم + الرمز. التأخرات والغيابات تظهر في لوحة القيادة.'],
    ] },
  },
  {
    path: '/crm',
    fr: { title: 'CRM & Clients', items: [
      ['Clients VIP', "Marquez un client VIP sur sa fiche : il est signalé à l'arrivée."],
      ['Réclamations', "Enregistrez la réclamation, affectez un responsable, clôturez avec la solution."],
      ['Satisfaction', "Les notes des questionnaires donnent la moyenne affichée au tableau de bord."],
    ] },
    ar: { title: 'علاقات الزبائن', items: [
      ['زبائن VIP', 'ضع علامة VIP على ملف الزبون: يُنبَّه عليه عند الوصول.'],
      ['الشكاوى', 'سجّل الشكوى، عيّن مسؤولًا، وأغلقها مع الحل.'],
      ['الرضا', 'تقييمات الاستبيانات تعطي المعدل المعروض في لوحة القيادة.'],
    ] },
  },
  {
    path: '/night-audit',
    fr: { title: 'Night audit', items: [
      ['Les étapes', "Lancer les vérifications → traiter chaque anomalie → compter la caisse → Comptabiliser → Valider → Clôturer (saisir la date pour confirmer)."],
      ['Après la clôture', "La journée suivante s'ouvre automatiquement. Une journée clôturée ne peut plus être modifiée."],
    ] },
    ar: { title: 'التدقيق الليلي', items: [
      ['المراحل', 'تشغيل الفحوص ← معالجة كل خلل ← عدّ الصندوق ← التسجيل المحاسبي ← المصادقة ← الإغلاق (أدخل التاريخ للتأكيد).'],
      ['بعد الإغلاق', 'يُفتح اليوم الموالي تلقائيًا. اليوم المغلق لا يمكن تعديله.'],
    ] },
  },
  {
    path: '/rapports',
    fr: { title: 'Rapports & statistiques', items: [
      ['Comptabilité par mois', "En haut de Rapports : chiffre d'affaires, encaissements, dépenses, « CA − dépenses » et occupation du mois en cours, puis les 12 derniers mois. « CA − dépenses » n'est pas un bénéfice comptable officiel."],
      ['Voir par mois', "Période « Cette année » et regroupement « Mois » (réglage par défaut). Changez la période en haut."],
      ['Comparer', "« Comparer à » : période précédente ou même période l'an dernier."],
      ['Exporter', "Boutons Excel / PDF en haut du rapport."],
    ] },
    ar: { title: 'التقارير والإحصائيات', items: [
      ['المحاسبة حسب الشهر', 'في أعلى التقارير: رقم الأعمال، التحصيلات، المصاريف، «رقم الأعمال − المصاريف» ونسبة الإشغال للشهر الجاري، ثم آخر 12 شهرًا. ليس ربحًا محاسبيًا رسميًا.'],
      ['العرض حسب الشهر', 'الفترة «هذه السنة» والتجميع «شهر» (الإعداد الافتراضي). غيّر الفترة في الأعلى.'],
      ['المقارنة', '«مقارنة مع»: الفترة السابقة أو نفس الفترة من السنة الماضية.'],
      ['التصدير', 'أزرار Excel / PDF في أعلى التقرير.'],
    ] },
  },
  {
    path: '/notifications',
    fr: { title: 'Notifications', items: [
      ['Pourquoi « À envoyer » ?', "Le serveur e-mail n'est pas configuré. Paramètres → Serveur e-mail → « Configurer Gmail », puis « Envoyer un e-mail de test »."],
      ['Envoi automatique', "Une fois configuré, les confirmations et rappels partent seuls en moins d'une minute (Internet nécessaire)."],
    ] },
    ar: { title: 'الإشعارات', items: [
      ['لماذا «للإرسال»؟', 'خادم البريد غير مُعدّ. الإعدادات ← خادم البريد ← «إعداد Gmail»، ثم «إرسال بريد تجريبي».'],
      ['الإرسال التلقائي', 'بعد الإعداد، تُرسل التأكيدات والتذكيرات تلقائيًا في أقل من دقيقة (يلزم الإنترنت).'],
    ] },
  },
  {
    path: '/settings',
    fr: { title: 'Paramètres', items: [
      ["Infos de l'hôtel", "Nom, adresse, logo, devise, horaires de check-in / check-out, taxes."],
      ['Gmail', "« Configurer Gmail » : adresse Gmail + mot de passe d'application (16 lettres, créé dans votre compte Google après la validation en 2 étapes)."],
      ['Acompte', "« Politique d'acompte » : aucune, en attente sans acompte, ou bloquer."],
      ['Rapport mensuel au directeur', "Cochez « Envoyer automatiquement le 1er du mois » et saisissez l'e-mail du directeur. Le PDF du mois écoulé part le 1er à partir de 7 h. « Voir le PDF » pour un aperçu, « Envoyer maintenant » pour un mois précis."],
    ] },
    ar: { title: 'الإعدادات', items: [
      ['معلومات الفندق', 'الاسم، العنوان، الشعار، العملة، أوقات الدخول والخروج، الضرائب.'],
      ['Gmail', '«إعداد Gmail»: عنوان Gmail + كلمة مرور التطبيق (16 حرفًا، تُنشأ في حساب Google بعد تفعيل التحقق بخطوتين).'],
      ['العربون', '«سياسة العربون»: بدون، في الانتظار دون عربون، أو منع.'],
      ['التقرير الشهري للمدير', 'فعّل «الإرسال التلقائي في أول الشهر» وأدخل بريد المدير. يُرسل PDF الشهر الماضي في الأول من الشهر ابتداءً من 7 صباحًا. «عرض PDF» للمعاينة و«إرسال الآن» لشهر محدّد.'],
    ] },
  },
  {
    path: '/admin',
    fr: { title: 'Administration', items: [
      ['Créer un utilisateur', "Onglet Utilisateurs → « Nouveau » : rôle, identifiant, mot de passe provisoire."],
      ['Sauvegardes', "Onglet Sauvegardes : « Sauvegarder maintenant » et « Tester la restauration ». Une sauvegarde automatique est faite chaque jour et avant chaque mise à jour."],
      ['Mises à jour', "Quand une nouvelle version existe, la cloche 🔔 l'annonce. Cliquez sur la notification puis « Installer » : sauvegarde, installation et redémarrage en 1 minute environ."],
      ['Journal', "Onglet Journal : qui a fait quoi et quand."],
    ] },
    ar: { title: 'الإدارة', items: [
      ['إنشاء مستخدم', 'تبويب المستخدمون ← «جديد»: الدور، المعرّف، كلمة مرور مؤقتة.'],
      ['النسخ الاحتياطية', 'تبويب النسخ: «نسخ الآن» و«اختبار الاسترجاع». نسخة تلقائية كل يوم وقبل كل تحديث.'],
      ['التحديثات', 'عند صدور نسخة جديدة يعلن عنها الجرس 🔔. اضغط على الإشعار ثم «تثبيت»: نسخ احتياطي، تثبيت وإعادة تشغيل في دقيقة تقريبًا.'],
      ['السجل', 'تبويب السجل: من فعل ماذا ومتى.'],
    ] },
  },
  {
    path: '*', videos: [VIDEOS.checkin, VIDEOS.caisse],
    fr: { title: 'Questions générales', items: [
      ['Trouver le numéro d\'un collègue', "Bouton 📞 en haut, à côté de la cloche : annuaire du personnel avec appel, WhatsApp et copie."],
      ['Changer de langue', "FR / ع / EN en haut de l'écran."],
      ['Mot de passe oublié', "Demandez à l'administrateur de le réinitialiser (Administration → Utilisateurs)."],
      ["L'écran affiche « connexion refusée »", "Le serveur KAYN Hotel est arrêté. Sur le PC serveur, lancez 2-DEMARRER.bat ."],
      ['Règles d\'or', "Un compte par personne, jamais de numéro de carte complet, un motif pour chaque annulation ou remise, et prévenez votre responsable en cas d'erreur."],
    ] },
    ar: { title: 'أسئلة عامة', items: [
      ['إيجاد رقم زميل', 'زر 📞 في الأعلى بجانب الجرس: دليل الموظفين مع الاتصال وواتساب والنسخ.'],
      ['تغيير اللغة', 'FR / ع / EN في أعلى الشاشة.'],
      ['نسيت كلمة المرور', 'اطلب من المدير إعادة تعيينها (الإدارة ← المستخدمون).'],
      ['الشاشة تعرض «رفض الاتصال»', 'خادم KAYN Hotel متوقف. على الحاسوب الخادم شغّل 2-DEMARRER.bat.'],
      ['القواعد الذهبية', 'حساب لكل شخص، لا رقم بطاقة كامل أبدًا، سبب لكل إلغاء أو تخفيض، وأخبر مسؤولك عند أي خطأ.'],
    ] },
  },
];
