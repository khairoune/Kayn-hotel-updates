const DAY = 86_400_000;

export function todayLocal(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function addDays(d: string, n: number): string {
  const t = Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10)) + n * DAY;
  return new Date(t).toISOString().slice(0, 10);
}

export function diffDays(a: string, b: string): number {
  return Math.round((Date.UTC(+b.slice(0, 4), +b.slice(5, 7) - 1, +b.slice(8, 10)) - Date.UTC(+a.slice(0, 4), +a.slice(5, 7) - 1, +a.slice(8, 10))) / DAY);
}

export const toDate = (d: string) => new Date(Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10)));

export function fmtDate(d: string | null | undefined, locale: string, opts: Intl.DateTimeFormatOptions = { weekday: 'short', day: 'numeric', month: 'short' }) {
  if (!d) return '—';
  return new Intl.DateTimeFormat(locale, { ...opts, timeZone: 'UTC' }).format(toDate(d.slice(0, 10)));
}

export function fmtDateTime(d: string | null | undefined, locale: string) {
  if (!d) return '—';
  return new Intl.DateTimeFormat(locale, { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(d));
}

/** Devise de l'établissement (Administration → Finances), chargée avec la session. */
export const currency = { symbol: 'DA', decimals: 2 };
export function setCurrency(symbol?: string | null, decimals?: number | null) {
  if (symbol) currency.symbol = symbol;
  if (decimals === 0 || decimals === 2) currency.decimals = decimals;
}
export function money(n: number | null | undefined, locale = 'fr-FR') {
  if (n === null || n === undefined) return '—';
  return new Intl.NumberFormat(locale, { maximumFractionDigits: currency.decimals, minimumFractionDigits: 0 }).format(n) + ' ' + currency.symbol;
}

export function weekday(d: string) {
  return toDate(d).getUTCDay();
}

/** Week-end algérien : vendredi et samedi */
export const isWeekend = (d: string) => [5, 6].includes(weekday(d));
