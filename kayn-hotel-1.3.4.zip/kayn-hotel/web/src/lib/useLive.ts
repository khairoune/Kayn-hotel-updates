import { useEffect } from 'react';
import { onDataChanged } from './api';

/** Recharge les données : après toute modification (cet onglet ou un autre), au retour sur l'onglet, et périodiquement. */
export function useLive(load: () => void, intervalMs = 30000) {
  useEffect(() => {
    const off = onDataChanged(load);
    const onFocus = () => document.visibilityState === 'visible' && load();
    document.addEventListener('visibilitychange', onFocus);
    const h = setInterval(() => document.visibilityState === 'visible' && load(), intervalMs);
    return () => { off(); document.removeEventListener('visibilitychange', onFocus); clearInterval(h); };
  }, [load, intervalMs]);
}
