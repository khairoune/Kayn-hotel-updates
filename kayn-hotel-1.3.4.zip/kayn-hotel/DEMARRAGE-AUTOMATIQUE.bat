@echo off
chcp 65001 >nul
cd /d "%~dp0"
net session >nul 2>nul || (echo [!] Clic droit sur ce fichier ^> "Executer en tant qu'administrateur". & pause & exit /b 1)
echo Le serveur KAYN Hotel demarrera automatiquement a chaque allumage de ce PC (meme sans session ouverte).
schtasks /create /f /tn "KAYN Hotel" /sc onstart /ru SYSTEM /rl HIGHEST /tr "cmd /c cd /d \"%~dp0server\" && node dist\index.js >> data\logs\console.log 2>&1"
if errorlevel 1 (echo [!] Echec de la creation de la tache planifiee. & pause & exit /b 1)
echo Tache "KAYN Hotel" creee. Pour la supprimer : schtasks /delete /tn "KAYN Hotel" /f
pause
